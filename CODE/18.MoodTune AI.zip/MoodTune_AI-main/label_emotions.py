import pandas as pd
from transformers import pipeline

# Load a pre-trained emotion classifier
classifier = pipeline("text-classification", 
                       model="Panda0116/emotion-classification-model", 
                       top_k=1)

df = pd.read_csv("data/all_songs.csv")
df = df.dropna(subset=["Lyric"])          # remove rows with no lyrics
df = df.head(6000)                          

from collections import Counter

def get_song_emotion(lyrics):
    lyrics = str(lyrics)
    length = len(lyrics)
    
    if length < 100:
        # very short lyrics - just classify the whole thing
        chunks = [lyrics]
    else:
        # sample beginning, middle, and end of the song
        beginning = lyrics[:400]
        middle_start = max(0, (length // 2) - 200)
        middle = lyrics[middle_start:middle_start + 400]
        end = lyrics[-400:]
        chunks = [beginning, middle, end]
    
    predictions = []
    for chunk in chunks:
        if chunk.strip():
            result = classifier(chunk, truncation=True, max_length=512)[0][0]
            predictions.append(result["label"])
    
    if not predictions:
        return "LABEL_1"  # default to Happy if something went wrong
    
    # majority vote - most common prediction wins
    most_common = Counter(predictions).most_common(1)[0][0]
    return most_common

emotions = []
for lyrics in df["Lyric"]:
    emotion_label = get_song_emotion(lyrics)
    emotions.append(emotion_label) 

df["emotion"] = emotions
emotion_map = {
    "LABEL_0": "Sad",          # sadness
    "LABEL_1": "Happy",        # joy
    "LABEL_2": "Love",         # love - genuine label now
    "LABEL_3": "Anger",        # anger
    "LABEL_4": "Fear",         # fear
    "LABEL_5": "Motivational"  # surprise - closest available substitute
}# Map the model's emotions to our 6 target categories


df["emotion"] = df["emotion"].map(emotion_map)
df.to_csv("data/songs_labeled.csv", index=False)
print("Done! Labeled data saved.")
print(df[["Title", "emotion"]].head(10))