"""
add_motivational_songs.py
--------------------------
Merges manually-curated Motivational-category songs into MoodTune AI's
existing labeled dataset, ahead of a retrain.

USAGE (run from your project root, e.g. on the HP Omen laptop):
    python add_motivational_songs.py

BEFORE RUNNING:
1. Open new_motivational_candidates_template.csv and fill in the `Lyric`
   column for each song using lyrics you've sourced yourself (Genius,
   a licensed lyrics API, or your own copies). Rows left blank in `Lyric`
   are skipped automatically -- you don't have to fill in all of them
   in one pass.
2. Double check the LABEL_COL / column names below match your actual
   data/songs_labeled.csv schema. Adjust if your columns are named
   differently (e.g. "emotion" instead of "Emotion").

WHAT THIS SCRIPT DOES:
- Loads your existing labeled dataset.
- Loads the candidate CSV (only rows with non-empty Lyric are used).
- Normalizes titles the same way explore_data.py does (strips the
  hidden zero-width-space character bug) so duplicate detection works
  correctly against titles like "thank u, next".
- For each candidate:
    - If the title already exists in your dataset -> reports the
      existing label and does NOT overwrite it automatically (prints
      a suggestion instead, since silently relabeling could hide a
      genuine labeling decision you should make yourself).
    - If it's new -> appends it as a new row with Emotion=Motivational.
- Writes the result to songs_labeled_v2.csv (does NOT touch your
  original file, so nothing is destructive).
- Prints the updated class distribution and the new inverse-frequency
  class weights, ready to paste into train_model.py's WeightedTrainer.
"""

import pandas as pd
import sys
import os

# ---- CONFIG: adjust these if your schema differs ----
EXISTING_DATA_PATH = "data/songs_labeled.csv"
CANDIDATES_PATH = "new_motivational_candidates_template.csv"
OUTPUT_PATH = "data/songs_labeled_v2.csv"
TITLE_COL = "Title"
LABEL_COL = "emotion"          # change to "label" or similar if different
LYRIC_COL = "Lyric"
TARGET_LABEL = "Motivational"

ZERO_WIDTH_SPACE = "\u200b"


def normalize_title(title: str) -> str:
    """Same normalization as explore_data.py's title-matching fix."""
    if not isinstance(title, str):
        return ""
    return title.replace(ZERO_WIDTH_SPACE, "").strip().lower()


def main():
    if not os.path.exists(EXISTING_DATA_PATH):
        sys.exit(f"Could not find {EXISTING_DATA_PATH}. Run this from your project root.")
    if not os.path.exists(CANDIDATES_PATH):
        sys.exit(f"Could not find {CANDIDATES_PATH}. Place it in your project root first.")

    existing = pd.read_csv(EXISTING_DATA_PATH)
    candidates = pd.read_csv(CANDIDATES_PATH)

    if LABEL_COL not in existing.columns:
        sys.exit(
            f"Column '{LABEL_COL}' not found in {EXISTING_DATA_PATH}. "
            f"Available columns: {list(existing.columns)}. "
            f"Update LABEL_COL at the top of this script and rerun."
        )

    existing["_norm_title"] = existing[TITLE_COL].apply(normalize_title)

    before_counts = existing[LABEL_COL].value_counts()
    print("=== BEFORE ===")
    print(before_counts.to_string())
    print()

    new_rows = []
    skipped_no_lyric = []
    already_exists = []

    for _, row in candidates.iterrows():
        lyric = row.get(LYRIC_COL, "")
        if not isinstance(lyric, str) or not lyric.strip():
            skipped_no_lyric.append(row[TITLE_COL])
            continue

        norm = normalize_title(row[TITLE_COL])
        match = existing[existing["_norm_title"] == norm]

        if len(match) > 0:
            current_label = match.iloc[0][LABEL_COL]
            already_exists.append((row[TITLE_COL], current_label))
            continue

        new_row = {col: row.get(col, "") for col in existing.columns if col != "_norm_title"}
        new_row[LABEL_COL] = TARGET_LABEL
        new_rows.append(new_row)

    if skipped_no_lyric:
        print(f"Skipped {len(skipped_no_lyric)} candidate(s) with no lyric filled in yet:")
        for t in skipped_no_lyric:
            print(f"  - {t}")
        print()

    if already_exists:
        print(f"{len(already_exists)} candidate(s) already exist in your dataset "
              f"under a different/same label (NOT auto-relabeled):")
        for title, label in already_exists:
            flag = "  <- already Motivational" if label == TARGET_LABEL else "  <- consider reviewing"
            print(f"  - {title}: currently labeled '{label}'{flag}")
        print()

    if not new_rows:
        print("No new rows to add. Fill in more lyrics in the candidates CSV and rerun.")
        return

    added_df = pd.DataFrame(new_rows)
    existing = existing.drop(columns=["_norm_title"])
    updated = pd.concat([existing, added_df], ignore_index=True)
    updated.to_csv(OUTPUT_PATH, index=False)

    after_counts = updated[LABEL_COL].value_counts()
    print(f"Added {len(new_rows)} new Motivational song(s).")
    print(f"Saved updated dataset to {OUTPUT_PATH} (original file untouched).")
    print()
    print("=== AFTER ===")
    print(after_counts.to_string())
    print()

    # Suggested inverse-frequency class weights for WeightedTrainer
    total = after_counts.sum()
    print("=== Suggested class weights for train_model.py's WeightedTrainer ===")
    print("(inverse frequency, same formula as your original checkpoint-1794 run)")
    weights = {}
    for label, count in after_counts.items():
        weights[label] = round(total / (len(after_counts) * count), 4)
    for label, w in sorted(weights.items()):
        print(f"  {label}: {w}")
    print()
    print("Paste these into your WeightedTrainer's weight dict, then retrain on")
    print(f"{OUTPUT_PATH} instead of the original songs_labeled.csv.")
    print("Recommend keeping the ORIGINAL 46-song Motivational labels intact within")
    print("this file (don't relabel them) -- only new songs were added above, so")
    print("checkpoint-1794's known behavior on existing songs won't shift unexpectedly.")


if __name__ == "__main__":
    main()
