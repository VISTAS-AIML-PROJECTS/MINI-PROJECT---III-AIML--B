MoodTune AI 🎵

Song Emotion Analysis and Emotion-Based Music Recommendation Using DistilBERT

MoodTune AI is a mini-project that analyzes the emotional content of song lyrics using a fine-tuned DistilBERT model and recommends songs that belong to the predicted emotion category.

📌 Project Overview

MoodTune AI accepts a song name as input, retrieves its lyrics, predicts the dominant emotion, and recommends up to five songs from the same emotion category. Recommended songs include YouTube links for playback.

The system classifies songs into six emotion categories:

* 😊 Happy
* 😢 Sad
* ❤️ Love
* 😠 Anger
* 😨 Fear
* 💪 Motivational

✨ Features

* Song lyrics retrieval using a song name
* Emotion classification using fine-tuned DistilBERT
* Six emotion categories
* Emotion-based song recommendations
* Confidence score display
* YouTube links for recommended songs
* Flask-based web interface

🛠️ Technology Stack

* Programming Language: Python 3.11
* Deep Learning Model: DistilBERT (distilbert-base-uncased)
* Model Framework: Hugging Face Transformers
* Backend: Flask
* Data Processing: Pandas
* Machine Learning Utilities: Scikit-learn
* Frontend: HTML and CSS

📂 Dataset

The project uses a song lyrics dataset collected from 21 artists.

* Raw dataset: 6,027 records
* Original labeled dataset: 5,910 records
* Expanded labeled dataset: 5,941 records
* Emotion classes: Six

The dataset was prepared and labeled for emotion classification. Additional data preparation and class-imbalance experiments were conducted to improve performance on underrepresented emotions.

🧠 Model Training and Evaluation

Several training approaches were evaluated to address class imbalance.

Experiment	Accuracy	Motivational F1-score
Baseline model	72%	0.00
Class balancing (resampling)	51%	0.00
Class-weighted loss	70%	0.42
Expanded dataset approach (final)	67.6%	0.52

The final model achieved 67.6% accuracy, with a 0.52 F1-score for the Motivational class. These results demonstrate improved recognition of the underrepresented Motivational category compared with the earlier experiments.

🚀 Running the Project Locally

1. Clone the repository

git clone https://github.com/harish44-1060/MoodTune_AI.git
cd MoodTune_AI

2. Create and activate a virtual environment

python -m venv venv

Windows:

venv\Scripts\activate

3. Install dependencies

Install the packages listed in requirements.txt:

pip install -r requirements.txt

4. Run the application

python main.py

Open the local URL displayed in your terminal in a web browser.

Note: The application requires its trained model files and the dataset files expected by the source code. The model weights are stored using Git Large File Storage (Git LFS), so ensure the required files are downloaded correctly.

📁 Project Structure

MoodTune_AI/
├── main.py
├── app_logic.py
├── templates/
├── data/
├── moodtune_model_final/
├── moodtune_model_v2/
├── moodtune_model_v3/
├── train_model.py
├── label_emotions.py
├── balance_dataset.py
├── evaluate_model.py
├── README.md
└── requirements.txt

Note: The structure above summarizes the main project files; actual contents may vary.

🎯 Applications

* Emotion-aware music discovery
* Personalized music recommendation
* Natural Language Processing (NLP) applications
* Music information retrieval
* Emotion classification research

⚠️ Limitations

* Emotion predictions depend on the quality and availability of song lyrics.
* A song may express multiple emotions, while the model predicts a dominant category.
* The model’s performance varies between emotion classes.
* Song recommendations depend on the available dataset and lyrics retrieval.

🔮 Future Enhancements

* Improve classification accuracy with additional high-quality labeled data.
* Further improve performance across all six emotion categories.
* Add user preferences and personalized recommendations.
* Improve lyrics retrieval reliability.
* Deploy the application as an online web service.

📚 Reference

Revathy, V. R., Anitha S. Pillai, and Fatemah Daneshfar. “LyEmoBERT: Classification of Lyrics’ Emotion and Recommendation Using a Pre-trained Model.” Procedia Computer Science, vol. 218, 2023, pp. 1196–1208.

👨‍💻 Project Team

Harish LG, Sagadevan S, and Lakshan P
B.Tech Computer Science and Engineering (AI & ML)
Vels Institute of Science, Technology & Advanced Studies (VISTAS), Chennai.

⸻

MoodTune AI — Understanding the emotion behind every song. 🎶
