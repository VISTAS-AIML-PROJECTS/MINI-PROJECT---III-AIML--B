"""
find_best_checkpoint.py
------------------------
Evaluates each saved epoch checkpoint from your most recent training run
and prints accuracy + per-class F1 for all of them side by side, so you
can manually pick the checkpoint with the best overall balance -- instead
of relying on automatic "best by accuracy" selection, which ignored the
Motivational class specifically.

USAGE:
    python find_best_checkpoint.py

Run this from your project root (same place you run train_model.py).
It uses the exact same data-loading and split logic as evaluate_model.py,
so results are directly comparable.
"""

import pandas as pd
import torch
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
from transformers import DistilBertTokenizer, DistilBertForSequenceClassification
import os

DATA_PATH = "data/songs_labeled_v2.csv"
CHECKPOINTS = [594, 1188, 1782, 2376, 2970]  # adjust if your step numbers differ
RESULTS_DIR = "results"

df = pd.read_csv(DATA_PATH)
df = df.dropna(subset=["Lyric", "emotion"])

labels = sorted(df["emotion"].unique())
label2id = {label: i for i, label in enumerate(labels)}
df["label"] = df["emotion"].map(label2id)

_, test_texts, _, test_labels = train_test_split(
    df["Lyric"].astype(str).tolist(), df["label"].tolist(), test_size=0.2, random_state=42,
    stratify=df["label"].tolist()
)

for step in CHECKPOINTS:
    checkpoint_path = os.path.join(RESULTS_DIR, f"checkpoint-{step}")
    if not os.path.exists(checkpoint_path):
        print(f"Checkpoint {step} not found, skipping.")
        continue

    print(f"\n{'='*60}")
    print(f"CHECKPOINT: {checkpoint_path}")
    print(f"{'='*60}")

    tokenizer = DistilBertTokenizer.from_pretrained(checkpoint_path)
    model = DistilBertForSequenceClassification.from_pretrained(checkpoint_path)
    model.eval()

    predictions = []
    for text in test_texts:
        inputs = tokenizer(text, return_tensors="pt", truncation=True, padding=True, max_length=256)
        with torch.no_grad():
            outputs = model(**inputs)
        pred = torch.argmax(outputs.logits, dim=1).item()
        predictions.append(pred)

    acc = accuracy_score(test_labels, predictions)
    print(f"Accuracy: {acc:.4f}")
    print(classification_report(test_labels, predictions, target_names=labels))
