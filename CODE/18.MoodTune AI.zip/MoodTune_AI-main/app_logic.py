import pandas as pd
import torch
from transformers import DistilBertTokenizer, DistilBertForSequenceClassification
import torch.nn.functional as F

# Load your trained model
tokenizer = DistilBertTokenizer.from_pretrained("moodtune_model_final")
model = DistilBertForSequenceClassification.from_pretrained("moodtune_model_final")
model.eval()

# Load your labeled dataset (for lookup + recommendations)
df = pd.read_csv("data/songs_labeled_v2.csv")
df["Title"] = df["Title"].str.replace("\u200b", "", regex=False).str.strip()

id2label = model.config.id2label

def get_lyrics_by_song_name(song_name):
    match = df[df["Title"].str.lower() == song_name.lower()]
    if match.empty:
        return None
    return match.iloc[0]["Lyric"]

def predict_emotion(lyrics):
    inputs = tokenizer(str(lyrics), return_tensors="pt", truncation=True, padding=True, max_length=256)
    with torch.no_grad():
        outputs = model(**inputs)
    probs = F.softmax(outputs.logits, dim=1)
    confidence, predicted_class = torch.max(probs, dim=1)
    emotion = id2label[predicted_class.item()]
    return emotion, round(confidence.item() * 100, 2)

def recommend_songs(emotion, exclude_song=None, top_n=5):
    matches = df[df["emotion"] == emotion]
    if exclude_song:
        matches = matches[matches["Title"].str.lower() != exclude_song.lower()]
    return matches["Title"].sample(n=min(top_n, len(matches)), random_state=None).tolist()

def analyze_song(song_name):
    lyrics = get_lyrics_by_song_name(song_name)
    if lyrics is None:
        return {"error": "Song not found in dataset"}
    emotion, confidence = predict_emotion(lyrics)
    recommendations = recommend_songs(emotion, exclude_song=song_name)
    recommendations_with_links = [
        {
            "title": song,
            "youtube_search": song.replace(' ', '+'),
        }
        for song in recommendations
    ]
    return {
        "song": song_name,
        "emotion": emotion,
        "confidence": confidence,
        "recommendations": recommendations_with_links
    }
    # Quick test
if __name__ == "__main__":   
    result = analyze_song("thank u, next")
    print(result)