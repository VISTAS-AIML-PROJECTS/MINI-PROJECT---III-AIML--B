import pandas as pd
from sklearn.model_selection import train_test_split
from transformers import DistilBertTokenizer, DistilBertForSequenceClassification, Trainer, TrainingArguments
import torch

# Load labeled data
df = pd.read_csv("data/songs_labeled_v2.csv")
df = df.dropna(subset=["Lyric", "emotion"])

# Convert emotion labels to numbers
labels = sorted(df["emotion"].unique())
label2id = {label: i for i, label in enumerate(labels)}
id2label = {i: label for label, i in label2id.items()}
df["label"] = df["emotion"].map(label2id)

print("Emotion categories found:", labels)

# Split into train/test
train_texts, test_texts, train_labels, test_labels = train_test_split(
    df["Lyric"].astype(str).tolist(), df["label"].tolist(), test_size=0.2, random_state=42,
    stratify=df["label"].tolist()
)


# Load tokenizer and model
tokenizer = DistilBertTokenizer.from_pretrained("distilbert-base-uncased")
model = DistilBertForSequenceClassification.from_pretrained(
    "distilbert-base-uncased", num_labels=len(labels)
)
model.config.id2label = id2label
model.config.label2id = label2id

# Tokenize
train_encodings = tokenizer(train_texts, truncation=True, padding=True, max_length=256)
test_encodings = tokenizer(test_texts, truncation=True, padding=True, max_length=256)
# Calculate class weights (rarer emotions get higher weight)
class_counts = df["emotion"].value_counts()
weights = torch.tensor([1.0 / class_counts[label] for label in labels], dtype=torch.float)
weights = weights / weights.sum() * len(weights)
print("Class weights:", dict(zip(labels, weights.tolist())))
class SongDataset(torch.utils.data.Dataset):
    def __init__(self, encodings, labels):
        self.encodings = encodings
        self.labels = labels
    def __getitem__(self, idx):
        item = {k: torch.tensor(v[idx]) for k, v in self.encodings.items()}
        item["labels"] = torch.tensor(self.labels[idx])
        return item
    def __len__(self):
        return len(self.labels)

train_dataset = SongDataset(train_encodings, train_labels)
test_dataset = SongDataset(test_encodings, test_labels)

# Training settings
training_args = TrainingArguments(
    output_dir="./results",
    num_train_epochs=5,
    per_device_train_batch_size=8,
    per_device_eval_batch_size=8,
    learning_rate=2e-5,
    eval_strategy="epoch",
    save_strategy="epoch",
    load_best_model_at_end=True,
    metric_for_best_model="macro_f1",
)

from torch.nn import CrossEntropyLoss

class WeightedTrainer(Trainer):
    def compute_loss(self, model, inputs, return_outputs=False, **kwargs):
        labels_batch = inputs.pop("labels")
        outputs = model(**inputs)
        logits = outputs.logits
        loss_fct = CrossEntropyLoss(weight=weights.to(logits.device))
        loss = loss_fct(logits.view(-1, model.config.num_labels), labels_batch.view(-1))
        return (loss, outputs) if return_outputs else loss

from sklearn.metrics import accuracy_score, f1_score

def compute_metrics(eval_pred):
    predictions, labels_true = eval_pred
    predictions = predictions.argmax(axis=-1)
    acc = accuracy_score(labels_true, predictions)
    macro_f1 = f1_score(labels_true, predictions, average="macro")
    return {"accuracy": acc, "macro_f1": macro_f1}
trainer = WeightedTrainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=test_dataset,
)

trainer.train()

# Save the finished model
model.save_pretrained("./moodtune_model_v4")
tokenizer.save_pretrained("./moodtune_model_v4")
print("Model saved to ./moodtune_model_v4")