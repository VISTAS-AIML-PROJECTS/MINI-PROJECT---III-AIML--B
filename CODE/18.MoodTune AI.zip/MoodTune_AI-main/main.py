from flask import Flask, render_template, request
from app_logic import analyze_song

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def home():
    result = None
    if request.method == "POST":
        song_name = request.form["song_name"]
        result = analyze_song(song_name)
    return render_template("index.html", result=result)

if __name__ == "__main__":
    app.run(debug=False)
    
