import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
from transformers import DistilBertTokenizer, DistilBertForSequenceClassification
import torch

# Load labeled data (same split logic as training)
df = pd.read_csv("data/songs_labeled_v2.csv")
df = df.dropna(subset=["Lyric", "emotion"])

labels = sorted(df["emotion"].unique())
label2id = {label: i for i, label in enumerate(labels)}
df["label"] = df["emotion"].map(label2id)

train_texts, test_texts, train_labels, test_labels = train_test_split(
    df["Lyric"].astype(str).tolist(), df["label"].tolist(), test_size=0.2, random_state=42,
    stratify=df["label"].tolist()
)

# Load your trained model
tokenizer = DistilBertTokenizer.from_pretrained("./moodtune_model_final")
model = DistilBertForSequenceClassification.from_pretrained("./moodtune_model_final")
model.eval()

# Predict on test set
predictions = []
for text in test_texts:
    inputs = tokenizer(text, return_tensors="pt", truncation=True, padding=True, max_length=256)
    with torch.no_grad():
        outputs = model(**inputs)
    pred = torch.argmax(outputs.logits, dim=1).item()
    predictions.append(pred)

# Print results
print("Accuracy:", accuracy_score(test_labels, predictions))
print("\nDetailed report:")
print(classification_report(test_labels, predictions, target_names=labels))
from sklearn.metrics import confusion_matrix
import numpy as np

print("\nConfusion Matrix:")
cm = confusion_matrix(test_labels, predictions)
print("Rows = actual, Columns = predicted")
print("Labels order:", labels)
print(cm)