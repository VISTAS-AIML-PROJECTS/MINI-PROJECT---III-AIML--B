import pandas as pd

df = pd.read_csv("data/songs_labeled.csv")
df = df.dropna(subset=["Lyric", "emotion"])

print("Before balancing:")
print(df["emotion"].value_counts())

# Cap each emotion category at a maximum count
# This reduces the dominance of Happy/Anger without needing to fabricate data
MAX_PER_CLASS = 350

balanced_parts = []
for emotion in df["emotion"].unique():
    subset = df[df["emotion"] == emotion]
    if len(subset) > MAX_PER_CLASS:
        subset = subset.sample(n=MAX_PER_CLASS, random_state=42)
    balanced_parts.append(subset)

balanced_df = pd.concat(balanced_parts, ignore_index=True)
balanced_df = balanced_df.sample(frac=1, random_state=42).reset_index(drop=True)  # shuffle

print("\nAfter balancing:")
print(balanced_df["emotion"].value_counts())

balanced_df.to_csv("data/songs_labeled_balanced.csv", index=False)
print("\nSaved as data/songs_labeled_balanced.csv")