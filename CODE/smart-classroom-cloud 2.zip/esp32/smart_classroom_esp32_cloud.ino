#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>

// ===================== WIFI SETTINGS =====================
const char* WIFI_SSID     = "YOUR_WIFI_NAME";      // <-- change (must be 2.4 GHz)
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";  // <-- change

// ===================== CLOUD SETTINGS ====================
const char* API_URL = "https://YOUR-BACKEND-NAME.onrender.com/api/data";  // <-- your Render URL + /api/data
const char* API_KEY = "change-this-to-a-long-random-secret";              // <-- SAME as API_KEY on Render
const unsigned long SEND_INTERVAL_MS = 3000;   // send to the cloud every 3 seconds

// ===================== SENSOR PINS =======================
const int NOISE_PIN = 34;   // Noise sensor analog output (AO / OUT) -> GPIO34 (ADC1, input only)
const int RADAR_PIN = 27;   // LD2410 OUT pin -> GPIO27

// ===================== NOISE SENSOR ======================
// Works with KY-038 (AO pin) or MAX4466 (OUT pin).
// dB is APPROXIMATE. Calibrate these two numbers with a phone dB-meter app:
const float NOISE_REF_P2P   = 20.0;  // sensor reading (peak-to-peak) in a quiet room
const float DB_AT_REF       = 40.0;  // real dB of that quiet room
const int   NOISE_WINDOW_MS = 50;    // sampling window
float noiseDb = 0;

// ===================== RADAR SENSOR ======================
// LD2410 OUT: HIGH = presence detected, LOW = nobody

// ===================== OCCUPANCY / CAMERA ================
// Not handled on this board. The camera / people-counting program sends the count
// directly to the backend: POST <backend>/api/occupancy  {"count": N}

float readNoiseDb() {
  unsigned long start = millis();
  int sigMax = 0, sigMin = 4095;
  while (millis() - start < NOISE_WINDOW_MS) {
    int s = analogRead(NOISE_PIN);
    if (s > sigMax) sigMax = s;
    if (s < sigMin) sigMin = s;
  }
  float p2p = (float)(sigMax - sigMin);
  if (p2p < 1) p2p = 1;
  float db = DB_AT_REF + 20.0 * log10(p2p / NOISE_REF_P2P);
  if (db < 30) db = 30;
  if (db > 120) db = 120;
  return db;
}

void sendToCloud() {
  if (WiFi.status() != WL_CONNECTED) return;

  WiFiClientSecure client;
  client.setInsecure();               // skips certificate check (fine for a college demo)
  HTTPClient http;
  http.setTimeout(8000);              // Render may take a while when waking up
  if (!http.begin(client, API_URL)) {
    Serial.println("http.begin failed");
    return;
  }
  http.addHeader("Content-Type", "application/json");
  http.addHeader("x-api-key", API_KEY);

  int radar = (digitalRead(RADAR_PIN) == HIGH) ? 1 : 0;
  String body = "{\"noise\":" + String(noiseDb, 1) + ",\"radar\":" + String(radar) + "}";

  int code = http.POST(body);
  Serial.print("POST ");
  Serial.print(body);
  Serial.print(" -> HTTP ");
  Serial.println(code);               // 201 = success, 401 = wrong API key, negative = network/TLS error
  http.end();
}

void setup() {
  Serial.begin(115200);
  delay(500);

  pinMode(RADAR_PIN, INPUT);
  analogReadResolution(12);
  noiseDb = readNoiseDb();

  Serial.print("Connecting to WiFi");
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println();
  Serial.print("ESP32 IP address: ");
  Serial.println(WiFi.localIP());
}

unsigned long lastNoise = 0;
unsigned long lastSend = 0;
unsigned long lastWifiCheck = 0;

void loop() {
  if (millis() - lastNoise >= 200) {       // update noise ~5 times/second
    lastNoise = millis();
    float n = readNoiseDb();
    noiseDb = 0.6 * noiseDb + 0.4 * n;     // light smoothing
  }

  if (millis() - lastSend >= SEND_INTERVAL_MS) {
    lastSend = millis();
    sendToCloud();
  }

  if (WiFi.status() != WL_CONNECTED && millis() - lastWifiCheck > 10000) {
    lastWifiCheck = millis();
    Serial.println("WiFi lost, reconnecting...");
    WiFi.disconnect();
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  }
}
