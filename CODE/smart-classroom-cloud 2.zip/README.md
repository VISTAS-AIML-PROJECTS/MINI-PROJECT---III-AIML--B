# Smart Classroom Monitor (cloud version)

ESP32 -> Render (Node/Express API) -> MongoDB Atlas -> Netlify dashboard

- `backend/`  Node.js API (deploy on Render, Root Directory = backend)
- `frontend/` Static dashboard (deploy on Netlify, Base directory = frontend)
- `esp32/`    Arduino sketch that POSTs noise + radar to the API

Setup order: MongoDB Atlas -> Render -> edit API_BASE in frontend/script.js -> Netlify -> flash ESP32.
Camera/occupancy counts are sent by the counting program to POST /api/occupancy (header x-api-key).
