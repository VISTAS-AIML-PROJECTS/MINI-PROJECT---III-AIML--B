-- Curated product catalogue: the "best product in every category" guide.

CREATE TABLE catalog_categories (
  slug        TEXT PRIMARY KEY CHECK (slug GLOB '[a-z0-9-]*'),
  name        TEXT NOT NULL,
  singular    TEXT NOT NULL,
  tagline     TEXT NOT NULL,
  banner      TEXT NOT NULL,
  sort_order  INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT NOT NULL,
  updated_at  TEXT NOT NULL
);

CREATE TABLE catalog_products (
  id            TEXT PRIMARY KEY,
  slug          TEXT NOT NULL UNIQUE CHECK (slug GLOB '[a-z0-9-]*'),
  category_slug TEXT NOT NULL REFERENCES catalog_categories(slug) ON UPDATE CASCADE ON DELETE RESTRICT,
  name          TEXT NOT NULL,
  brand         TEXT NOT NULL,
  price_inr     INTEGER NOT NULL CHECK (price_inr > 0),
  price_note    TEXT,
  variant       TEXT,
  released      TEXT,
  specs_json    TEXT NOT NULL DEFAULT '{}',
  sources_json  TEXT NOT NULL DEFAULT '[]',
  pros_json     TEXT NOT NULL DEFAULT '[]',
  cons_json     TEXT NOT NULL DEFAULT '[]',
  image_path    TEXT,
  status        TEXT NOT NULL DEFAULT 'published' CHECK (status IN ('published', 'draft')),
  checked_at    TEXT NOT NULL,
  created_at    TEXT NOT NULL,
  updated_at    TEXT NOT NULL
);
CREATE INDEX idx_catalog_products_category ON catalog_products(category_slug, status, price_inr);

CREATE TABLE search_log (
  id          TEXT PRIMARY KEY,
  query       TEXT NOT NULL,
  category    TEXT,
  budget_inr  INTEGER,
  results     INTEGER NOT NULL,
  created_at  TEXT NOT NULL
);
CREATE INDEX idx_search_log_created ON search_log(created_at DESC);

-- Live AI search results, cached so repeat searches are instant and free.
CREATE TABLE search_cache (
  key         TEXT PRIMARY KEY,
  query       TEXT NOT NULL,
  result_json TEXT NOT NULL,
  created_at  TEXT NOT NULL
);
CREATE INDEX idx_search_cache_created ON search_cache(created_at);
