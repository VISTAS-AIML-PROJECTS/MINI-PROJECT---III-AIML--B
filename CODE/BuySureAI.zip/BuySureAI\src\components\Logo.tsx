/** The BuySure mark: an inspection loupe whose rim is cut by an audit line. */
export function LogoMark({ title }: { title?: string }) {
  return (
    <svg viewBox="0 0 32 32" role={title ? "img" : undefined} aria-hidden={title ? undefined : true} aria-label={title}>
      <circle cx="14" cy="14" r="9.5" fill="none" stroke="currentColor" strokeWidth="2.2" />
      <path d="M21 21l7 7" stroke="currentColor" strokeWidth="2.6" strokeLinecap="square" />
      <path d="M2 14h24" stroke="#b0301c" strokeWidth="2" />
      <path d="M9.5 10.5l3 3 5-5" fill="none" stroke="currentColor" strokeWidth="1.8" />
    </svg>
  );
}
