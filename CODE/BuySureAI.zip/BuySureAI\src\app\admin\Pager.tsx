import Link from "next/link";

export function Pager({ page, total, pageSize, base, params }: { page: number; total: number; pageSize: number; base: string; params: Record<string, string | undefined> }) {
  const pages = Math.max(1, Math.ceil(total / pageSize));
  const href = (p: number) => {
    const sp = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) if (v) sp.set(k, v);
    sp.set("page", String(p));
    return `${base}?${sp}`;
  };
  return (
    <nav className="pagination" aria-label="Pagination">
      <span className="muted">{total} total · page {page} of {pages}</span>
      {page > 1 && <Link href={href(page - 1)} className="btn btn-secondary btn-small">Previous</Link>}
      {page < pages && <Link href={href(page + 1)} className="btn btn-secondary btn-small">Next</Link>}
    </nav>
  );
}
