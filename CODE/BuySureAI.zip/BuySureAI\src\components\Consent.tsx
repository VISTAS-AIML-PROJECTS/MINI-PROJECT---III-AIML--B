"use client";

import { useEffect, useState } from "react";
import Script from "next/script";
import { usePathname } from "next/navigation";
import Link from "next/link";
import { getConsent, setConsent } from "@/lib/analytics";

/**
 * Cookie consent + Google Analytics loader. GA is not requested at all until the visitor opts in,
 * and IP anonymisation / ad signals are disabled. The banner can be reopened from the footer.
 */
export function ConsentAndAnalytics({ gaId }: { gaId: string | null }) {
  const [consent, setLocal] = useState<"granted" | "denied" | null | "unknown">("unknown");
  const [open, setOpen] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    const c = getConsent();
    setLocal(c);
    setOpen(c === null && Boolean(gaId));
    const reopen = () => setOpen(true);
    const update = (e: Event) => setLocal((e as CustomEvent).detail);
    window.addEventListener("bs-open-consent", reopen);
    window.addEventListener("bs-consent", update);
    return () => {
      window.removeEventListener("bs-open-consent", reopen);
      window.removeEventListener("bs-consent", update);
    };
  }, [gaId]);

  // SPA navigations: report page views manually.
  useEffect(() => {
    if (consent === "granted" && gaId && typeof window.gtag === "function") {
      window.gtag("event", "page_view", { page_path: pathname });
    }
  }, [pathname, consent, gaId]);

  const choose = (v: "granted" | "denied") => {
    setConsent(v);
    setLocal(v);
    setOpen(false);
    if (v === "denied") {
      // Remove any GA cookies set earlier on this domain.
      for (const c of document.cookie.split(";")) {
        const name = c.split("=")[0].trim();
        if (name.startsWith("_ga")) document.cookie = `${name}=; Max-Age=0; Path=/; Domain=${location.hostname.replace(/^www\./, ".")}`;
      }
    }
  };

  return (
    <>
      {gaId && consent === "granted" && (
        <>
          <Script src={`https://www.googletagmanager.com/gtag/js?id=${encodeURIComponent(gaId)}`} strategy="afterInteractive" />
          <Script id="ga-init" strategy="afterInteractive">
            {`window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}window.gtag=gtag;gtag('js',new Date());gtag('config',${JSON.stringify(gaId)},{send_page_view:false,allow_google_signals:false,allow_ad_personalization_signals:false});`}
          </Script>
        </>
      )}
      {open && (
        <section className="consent" role="dialog" aria-modal="false" aria-labelledby="consent-title">
          <h2 id="consent-title">Analytics cookies</h2>
          <p>
            We would like to use Google Analytics to count visits and see which pages help people. It sets cookies and
            sends your IP address to Google. Essential cookies (your sign-in) are always on. See the{" "}
            <Link href="/privacy#cookies">cookie section of our privacy policy</Link>.
          </p>
          <div className="btn-row">
            <button className="btn" onClick={() => choose("granted")}>Allow analytics</button>
            <button className="btn btn-secondary" onClick={() => choose("denied")}>Essential only</button>
          </div>
        </section>
      )}
    </>
  );
}

export function CookieSettingsButton() {
  return (
    <button className="btn-link" style={{ color: "inherit" }} onClick={() => window.dispatchEvent(new Event("bs-open-consent"))}>
      Cookie settings
    </button>
  );
}
