import type { Metadata } from "next";
import Link from "next/link";
import { Fragment } from "react";
import { SearchBox } from "@/components/shop/SearchBox";
import { ProductCard } from "@/components/shop/ProductCard";
import { listCategories } from "@/lib/catalog/repo";
import { topPicks } from "@/lib/catalog/picks";
import { pageMeta, JsonLd } from "@/lib/seo";
import { absoluteUrl, site } from "@/lib/site";

export const revalidate = 600;

export const metadata: Metadata = {
  ...pageMeta({
    title: "Search any product. Get the best one.",
    description:
      "Search any product, paste a link from any store, or snap a photo. BuySure AI checks it against the best alternatives in its category and shows you which one to buy, with the numbers and sources.",
    path: "/",
  }),
  title: { absolute: "BuySure AI: search any product, get the best one" },
};

export default async function Home() {
  const categories = await listCategories();
  const allPicks = await Promise.all(categories.map((c) => topPicks(c.slug)));
  return (
    <>
      <section className="search-hero">
        <div className="wrap">
          <span className="eyebrow">Not every product. Only the one worth buying.</span>
          <h1>Search anything. <em>Get the best one.</em></h1>
          <p className="lede">
            Type a product, paste a link from Amazon, Flipkart or any store, or snap a photo. BuySure researches it, checks its
            specs, and ranks it against the best alternatives in its category.
          </p>
          <SearchBox autoFocus />
        </div>
      </section>

      {categories.map((c, i) => {
        const picks = allPicks[i];
        if (!picks.length) return null;
        return (
          <Fragment key={c.slug}>
            {i > 0 && i % 2 === 0 && (
              <section className="banner" aria-label={c.banner}>
                <div className="wrap">
                  <div>
                    <h2>{c.banner}.</h2>
                    <p>{c.tagline}</p>
                  </div>
                  <Link href={`/best/${c.slug}`} className="btn">See the best {c.name.toLowerCase()}</Link>
                </div>
              </section>
            )}
            <section className="rail" aria-labelledby={`rail-${c.slug}`}>
              <div className="wrap">
                <div className="rail-head">
                  <div>
                    <h2 id={`rail-${c.slug}`}>{c.name}</h2>
                    <p>{c.tagline}</p>
                  </div>
                  <Link href={`/best/${c.slug}`}>See all →</Link>
                </div>
                <div className="cards">
                  {picks.map((p) => (
                    <ProductCard
                      key={p.item.id}
                      href={`/p/${p.item.slug}`}
                      category={c.slug}
                      brand={p.item.brand}
                      name={p.item.name}
                      priceInr={p.item.priceInr}
                      badge={p.badge || null}
                      score={p.item.score}
                      why={p.item.reasons[0] ?? null}
                      imagePath={p.item.imagePath}
                    />
                  ))}
                </div>
              </div>
            </section>
          </Fragment>
        );
      })}

      <section className="banner" aria-label="Anything else">
        <div className="wrap">
          <div>
            <h2>Anything else? Just ask.</h2>
            <p>Air fryers, running shoes, monitors, baby strollers: live search researches any product sold in India and finds the best one for you.</p>
          </div>
          <Link href="/search?q=best%20air%20fryer%20for%20a%20family%20of%20four" className="btn">Try a search</Link>
        </div>
      </section>

      <section className="section">
        <div className="wrap">
          <span className="eyebrow">How BuySure decides</span>
          <h2 style={{ maxWidth: "20ch" }}>Numbers, not hype</h2>
          <ol className="steps">
            <li><strong>Find</strong>Works out exactly what you&apos;re looking at, from words, a link or a photo, and its category and price band.</li>
            <li><strong>Check</strong>Pulls current Indian prices and specs from sources you can open, and flags specs that break physics.</li>
            <li><strong>Rank</strong>Scores every option on measurable criteria you can re-weight, and tells you which to buy and why.</li>
          </ol>
          <p style={{ marginTop: 28 }} className="muted">
            No affiliate commission, no paid placements, nothing bought on your behalf. <Link href="/how-it-works">Read the methodology</Link>.
          </p>
        </div>
      </section>

      <JsonLd
        data={[
          {
            "@context": "https://schema.org",
            "@type": "WebSite",
            name: site.name,
            url: absoluteUrl("/"),
            potentialAction: { "@type": "SearchAction", target: `${absoluteUrl("/search")}?q={search_term_string}`, "query-input": "required name=search_term_string" },
          },
        ]}
      />
    </>
  );
}
