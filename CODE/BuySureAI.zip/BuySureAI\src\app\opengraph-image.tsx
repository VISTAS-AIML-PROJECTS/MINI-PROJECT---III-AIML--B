import { ImageResponse } from "next/og";

export const alt = "BuySure AI: every listing is a claim. We test it.";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

/** Social preview card in the site's evidence-file style. */
export default function OgImage() {
  const rows = [
    ["Review integrity", "duplicate clusters · spike days", "WARN", "#8d5507"],
    ["Battery vs. body volume", "428 Wh/L vs 405 Wh/L ceiling", "FAIL", "#b0301c"],
    ["True cost", "+ charger not in box", "NOTE", "#4b473e"],
  ];
  return new ImageResponse(
    (
      <div style={{ width: "100%", height: "100%", background: "#f1ece1", display: "flex", flexDirection: "column", padding: "64px 72px", color: "#1a1915", fontFamily: "serif" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 18, fontSize: 34 }}>
          <svg width="52" height="52" viewBox="0 0 32 32">
            <circle cx="14" cy="14" r="9" fill="none" stroke="#1a1915" strokeWidth="2.4" />
            <path d="M21 21l7 7" stroke="#1a1915" strokeWidth="3" />
            <path d="M2 14h24" stroke="#b0301c" strokeWidth="2" />
          </svg>
          <span>BuySure AI</span>
        </div>
        <div style={{ fontSize: 76, lineHeight: 1.05, marginTop: 44, display: "flex", flexDirection: "column" }}>
          <span>Every listing is a claim.</span>
          <span style={{ color: "#b0301c", fontStyle: "italic" }}>We test it.</span>
        </div>
        <div style={{ display: "flex", flexDirection: "column", marginTop: "auto", borderTop: "3px solid #1a1915" }}>
          {rows.map(([a, b, s, c]) => (
            <div key={a} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "12px 0", borderBottom: "1px solid #c9bfaa", fontSize: 26, fontFamily: "monospace" }}>
              <span style={{ display: "flex", gap: 24 }}><span>{a}</span><span style={{ color: "#6e685b" }}>{b}</span></span>
              <span style={{ color: c, border: `3px solid ${c}`, padding: "4px 10px", fontSize: 20 }}>{s}</span>
            </div>
          ))}
        </div>
      </div>
    ),
    size,
  );
}
