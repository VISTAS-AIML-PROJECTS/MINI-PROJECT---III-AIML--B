import type { Metadata } from "next";
import { requireUser } from "@/lib/auth/guard";
import { listWatches } from "@/lib/repos/watches";
import { WatchesClient } from "./WatchesClient";

export const metadata: Metadata = { title: "Price watches" };

export default async function WatchesPage() {
  const user = await requireUser("/dashboard/watches");
  return (
    <>
      <h1 style={{ fontSize: "var(--step-3)" }}>Price watches</h1>
      <p className="muted" style={{ maxWidth: "68ch" }}>
        Log the price whenever you check a listing. When the latest price reaches your target, you get a notification (and an email if the
        server has email set up). BuySure never buys anything for you.
      </p>
      <WatchesClient initial={await listWatches(user.id)} />
    </>
  );
}
