"use client";

export default function GlobalError({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <html lang="en-IN">
      <body style={{ fontFamily: "Georgia, serif", background: "#f1ece1", color: "#1a1915", padding: "64px 20px" }}>
        <h1>BuySure AI is having trouble loading.</h1>
        <p>Please try again in a moment.</p>
        <button onClick={reset} style={{ padding: "10px 18px", background: "#1a1915", color: "#f1ece1", border: 0, cursor: "pointer" }}>Try again</button>
      </body>
    </html>
  );
}
