"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { api } from "@/lib/client-api";
import { FieldError, useForm } from "@/components/forms";
import { track } from "@/lib/analytics";
import { safeNext } from "@/lib/safe-next";


export function LoginForm() {
  const router = useRouter();
  const next = safeNext(useSearchParams().get("next"));
  const f = useForm();
  const submit = f.handle(async (fd) => {
    const res = await api<{ role: string }>("/api/auth/login", { body: { email: fd.get("email"), password: fd.get("password") } });
    if (!res.ok) return res;
    track("login");
    router.push(next);
    router.refresh();
  });
  return (
    <form onSubmit={submit} noValidate>
      {f.error && <div className="notice notice-error" role="alert">{f.error}</div>}
      <div className="field">
        <label htmlFor="l-email">Email</label>
        <input id="l-email" name="email" type="email" autoComplete="email" required aria-invalid={!!f.fields.email} aria-describedby="l-email-err" />
        <FieldError id="l-email-err" msg={f.fields.email} />
      </div>
      <div className="field">
        <label htmlFor="l-password">Password</label>
        <input id="l-password" name="password" type="password" autoComplete="current-password" required aria-invalid={!!f.fields.password} aria-describedby="l-password-err" />
        <FieldError id="l-password-err" msg={f.fields.password} />
      </div>
      <button className="btn" style={{ width: "100%" }} disabled={f.busy}>{f.busy ? "Signing in…" : "Sign in"}</button>
      <p className="small" style={{ marginTop: 16 }}>
        <Link href="/forgot-password">Forgot your password?</Link> · New here? <Link href={`/register${next !== "/dashboard" ? `?next=${encodeURIComponent(next)}` : ""}`}>Create an account</Link>
      </p>
    </form>
  );
}

export function RegisterForm() {
  const router = useRouter();
  const next = safeNext(useSearchParams().get("next"));
  const f = useForm();
  const submit = f.handle(async (fd) => {
    const res = await api("/api/auth/register", {
      body: { name: fd.get("name"), email: fd.get("email"), password: fd.get("password"), acceptTerms: fd.get("acceptTerms") === "on", website: fd.get("website") },
    });
    if (!res.ok) return res;
    track("sign_up");
    router.push(next);
    router.refresh();
  });
  return (
    <form onSubmit={submit} noValidate>
      {f.error && <div className="notice notice-error" role="alert">{f.error}</div>}
      <div className="field">
        <label htmlFor="r-name">Name</label>
        <input id="r-name" name="name" autoComplete="name" required maxLength={80} aria-invalid={!!f.fields.name} aria-describedby="r-name-err" />
        <FieldError id="r-name-err" msg={f.fields.name} />
      </div>
      <div className="field">
        <label htmlFor="r-email">Email</label>
        <input id="r-email" name="email" type="email" autoComplete="email" required aria-invalid={!!f.fields.email} aria-describedby="r-email-err" />
        <FieldError id="r-email-err" msg={f.fields.email} />
      </div>
      <div className="field">
        <label htmlFor="r-password">Password</label>
        <input id="r-password" name="password" type="password" autoComplete="new-password" required minLength={10} aria-invalid={!!f.fields.password} aria-describedby="r-password-hint r-password-err" />
        <span id="r-password-hint" className="hint">At least 10 characters, with a number or symbol.</span>
        <FieldError id="r-password-err" msg={f.fields.password} />
      </div>
      <div className="hp" aria-hidden="true">
        <label htmlFor="r-website">Leave this empty</label>
        <input id="r-website" name="website" tabIndex={-1} autoComplete="off" />
      </div>
      <div className="field">
        <label className="check" htmlFor="r-terms">
          <input id="r-terms" name="acceptTerms" type="checkbox" required aria-describedby="r-terms-err" />
          <span>I am 18 or older and accept the <Link href="/terms" target="_blank">terms</Link> and <Link href="/privacy" target="_blank">privacy policy</Link>.</span>
        </label>
        <FieldError id="r-terms-err" msg={f.fields.acceptTerms} />
      </div>
      <button className="btn" style={{ width: "100%" }} disabled={f.busy}>{f.busy ? "Creating account…" : "Create account"}</button>
      <p className="small" style={{ marginTop: 16 }}>Already have an account? <Link href="/login">Sign in</Link></p>
    </form>
  );
}

export function ForgotForm() {
  const [sent, setSent] = useState<string | null>(null);
  const f = useForm();
  const submit = f.handle(async (fd) => {
    const res = await api<{ message: string }>("/api/auth/forgot", { body: { email: fd.get("email") } });
    if (!res.ok) return res;
    setSent(res.data.message);
  });
  if (sent) return <div className="notice notice-ok" role="status">{sent}</div>;
  return (
    <form onSubmit={submit} noValidate>
      {f.error && <div className="notice notice-error" role="alert">{f.error}</div>}
      <div className="field">
        <label htmlFor="f-email">Email</label>
        <input id="f-email" name="email" type="email" autoComplete="email" required aria-describedby="f-email-err" />
        <FieldError id="f-email-err" msg={f.fields.email} />
      </div>
      <button className="btn" style={{ width: "100%" }} disabled={f.busy}>{f.busy ? "Sending…" : "Send reset link"}</button>
      <p className="small" style={{ marginTop: 16 }}><Link href="/login">Back to sign in</Link></p>
    </form>
  );
}

export function ResetForm() {
  const token = useSearchParams().get("token") ?? "";
  const [done, setDone] = useState(false);
  const f = useForm();
  const submit = f.handle(async (fd) => {
    if (fd.get("password") !== fd.get("confirm")) {
      return { ok: false, status: 422, error: "The passwords do not match.", fields: { confirm: "Does not match." } };
    }
    const res = await api("/api/auth/reset", { body: { token, password: fd.get("password") } });
    if (!res.ok) return res;
    setDone(true);
  });
  if (!token) return <div className="notice notice-error">This link is missing its token. <Link href="/forgot-password">Request a new link</Link>.</div>;
  if (done) return <div className="notice notice-ok" role="status">Password changed. You have been signed out everywhere. <Link href="/login">Sign in</Link> with your new password.</div>;
  return (
    <form onSubmit={submit} noValidate>
      {f.error && <div className="notice notice-error" role="alert">{f.error}</div>}
      <div className="field">
        <label htmlFor="n-password">New password</label>
        <input id="n-password" name="password" type="password" autoComplete="new-password" required minLength={10} aria-describedby="n-password-err" />
        <FieldError id="n-password-err" msg={f.fields.password} />
      </div>
      <div className="field">
        <label htmlFor="n-confirm">Confirm new password</label>
        <input id="n-confirm" name="confirm" type="password" autoComplete="new-password" required minLength={10} aria-describedby="n-confirm-err" />
        <FieldError id="n-confirm-err" msg={f.fields.confirm} />
      </div>
      <button className="btn" style={{ width: "100%" }} disabled={f.busy}>{f.busy ? "Saving…" : "Set new password"}</button>
    </form>
  );
}
