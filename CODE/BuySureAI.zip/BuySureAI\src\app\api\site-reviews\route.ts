import { handler, json, readJson, limit } from "@/lib/api";
import { siteReviewSchema } from "@/lib/validation";
import { approvedSiteReviews, mySiteReview, upsertSiteReview } from "@/lib/repos/misc";

export const GET = handler({}, async (_req, { user }) =>
  json({ reviews: await approvedSiteReviews(), mine: user ? await mySiteReview(user.id) : null }),
);

export const POST = handler({ auth: "user" }, async (req, { user }) => {
  await limit(`site-review:${user!.id}`, 10, 3600);
  const data = await readJson(req, siteReviewSchema, 5_000);
  await upsertSiteReview(user!.id, data);
  return json({ ok: true, status: "pending" }, 201);
});
