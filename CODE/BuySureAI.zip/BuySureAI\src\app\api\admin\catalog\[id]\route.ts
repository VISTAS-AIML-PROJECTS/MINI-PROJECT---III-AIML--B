import { handler, json, readJson, ApiError } from "@/lib/api";
import { adminGetProduct, deleteProduct, upsertProduct } from "@/lib/catalog/repo";
import { adminLog } from "@/lib/repos/misc";
import { removeImage } from "@/lib/media";
import { db } from "@/lib/db";
import { catalogProductSchema } from "@/lib/validation";

type P = { id: string };

export const PATCH = handler<P>({ auth: "admin" }, async (req, { params, user }) => {
  const cur = await adminGetProduct(params.id);
  if (!cur) throw new ApiError(404, "Product not found.");
  const d = await readJson(req, catalogProductSchema, 50_000);
  if (d.slug !== cur.slug && (await db.get("SELECT 1 FROM catalog_products WHERE slug = ?", d.slug))) throw new ApiError(409, "That slug is already used.", { slug: "Already used." });
  await upsertProduct(cur.id, d);
  await adminLog(user!.id, "catalog.update", cur.id, { slug: d.slug, status: d.status });
  return json({ ok: true });
});

export const DELETE = handler<P>({ auth: "admin" }, async (_req, { params, user }) => {
  const cur = await adminGetProduct(params.id);
  if (!cur) throw new ApiError(404, "Product not found.");
  await deleteProduct(cur.id);
  await removeImage(cur.imagePath);
  await adminLog(user!.id, "catalog.delete", cur.id, { slug: cur.slug });
  return json({ ok: true });
});
