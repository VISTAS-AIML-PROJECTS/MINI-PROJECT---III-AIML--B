import { AsyncLocalStorage } from "node:async_hooks";
import fs from "node:fs";
import path from "node:path";
import type { DatabaseSync } from "node:sqlite";
import type { Pool, PoolClient } from "pg";

/**
 * Async database layer with two drivers:
 *  - PostgreSQL (DATABASE_URL set): production, e.g. Supabase via its connection pooler.
 *  - SQLite via node:sqlite (DATABASE_PATH): local development and tests, zero setup.
 * SQL is written once with `?` placeholders and portable syntax; Postgres gets `$n` placeholders.
 * Migrations live in migrations/<driver>/NNN_name.sql and are applied automatically.
 */

export type Param = string | number | boolean | null | Buffer | Uint8Array;
type Row = Record<string, unknown>;

export interface Driver {
  kind: "sqlite" | "postgres";
  all<T = Row>(sql: string, params: Param[]): Promise<T[]>;
  run(sql: string, params: Param[]): Promise<{ changes: number }>;
  transaction<T>(fn: () => Promise<T>): Promise<T>;
  exec(sql: string): Promise<void>;
  close(): Promise<void>;
}

/** Converts `?` placeholders to `$1, $2…`, skipping quoted strings. */
export function toPgPlaceholders(sql: string) {
  let n = 0;
  let out = "";
  let quote: string | null = null;
  for (const ch of sql) {
    if (quote) {
      if (ch === quote) quote = null;
      out += ch;
    } else if (ch === "'" || ch === '"') {
      quote = ch;
      out += ch;
    } else if (ch === "?") {
      out += `$${++n}`;
    } else out += ch;
  }
  return out;
}

// ── SQLite ─────────────────────────────────────────────────────────────────────────────────

export async function sqliteDriver(file: string): Promise<Driver> {
  const { DatabaseSync } = await import("node:sqlite");
  if (file !== ":memory:") fs.mkdirSync(path.dirname(file), { recursive: true });
  const d: DatabaseSync = new DatabaseSync(file);
  d.exec("PRAGMA foreign_keys = ON");
  d.exec("PRAGMA busy_timeout = 5000");
  if (file !== ":memory:") d.exec("PRAGMA journal_mode = WAL");

  // One connection is shared, so a transaction must not interleave with other requests' queries.
  const tx = new AsyncLocalStorage<{ depth: number }>();
  let lock: Promise<void> = Promise.resolve();
  const waitTurn = async () => { if (!tx.getStore()) await lock; };
  const norm = (p: Param[]) => p.map((v) => (typeof v === "boolean" ? (v ? 1 : 0) : v)) as never[];

  const drv: Driver = {
    kind: "sqlite",
    async all<T>(sql: string, params: Param[]) {
      await waitTurn();
      return d.prepare(sql).all(...norm(params)) as T[];
    },
    async run(sql, params) {
      await waitTurn();
      const r = d.prepare(sql).run(...norm(params));
      return { changes: Number(r.changes) };
    },
    async exec(sql) { await waitTurn(); d.exec(sql); },
    async transaction<T>(fn: () => Promise<T>) {
      const store = tx.getStore();
      if (store) {
        const sp = `sp${store.depth}`;
        d.exec(`SAVEPOINT ${sp}`);
        store.depth++;
        try { const out = await fn(); d.exec(`RELEASE ${sp}`); return out; }
        catch (e) { d.exec(`ROLLBACK TO ${sp}; RELEASE ${sp}`); throw e; }
        finally { store.depth--; }
      }
      const prev = lock;
      let release!: () => void;
      lock = new Promise((r) => (release = r));
      await prev;
      try {
        return await tx.run({ depth: 0 }, async () => {
          d.exec("BEGIN");
          try { const out = await fn(); d.exec("COMMIT"); return out; }
          catch (e) { d.exec("ROLLBACK"); throw e; }
        });
      } finally { release(); }
    },
    async close() { d.close(); },
  };
  return drv;
}

// ── PostgreSQL ─────────────────────────────────────────────────────────────────────────────

export async function postgresDriver(url: string): Promise<Driver> {
  const pg = await import("pg");
  // COUNT/SUM return int8 and AVG returns numeric; our values fit in JS numbers.
  pg.default.types.setTypeParser(20, (v: string) => Number(v));
  pg.default.types.setTypeParser(1700, (v: string) => Number(v));
  const pool: Pool = new pg.default.Pool({
    connectionString: url,
    max: Number(process.env.DATABASE_POOL_MAX ?? 3),
    idleTimeoutMillis: 10_000,
    connectionTimeoutMillis: 10_000,
    ssl: /sslmode=disable|localhost|127\.0\.0\.1/.test(url) ? undefined : { rejectUnauthorized: false },
  });
  // Optional isolated schema (used by the smoke test against a real database). Needs a
  // session-mode connection, because SET does not persist across transaction-mode pooling.
  const schema = process.env.DATABASE_SCHEMA;
  if (schema) {
    if (!/^[a-z_][a-z0-9_]{0,40}$/.test(schema)) throw new Error("Invalid DATABASE_SCHEMA");
    pool.on("connect", (c) => { c.query(`SET search_path TO ${schema}`).catch(() => {}); });
  }
  const tx = new AsyncLocalStorage<{ client: PoolClient; depth: number }>();
  const q = (sql: string, params: Param[]) => {
    const client = tx.getStore()?.client ?? pool;
    return client.query(toPgPlaceholders(sql), params as unknown[]);
  };
  return {
    kind: "postgres",
    async all<T>(sql: string, params: Param[]) { return (await q(sql, params)).rows as T[]; },
    async run(sql, params) { return { changes: (await q(sql, params)).rowCount ?? 0 }; },
    async exec(sql) { await (tx.getStore()?.client ?? pool).query(sql); },
    async transaction<T>(fn: () => Promise<T>) {
      const store = tx.getStore();
      if (store) {
        const sp = `sp${store.depth}`;
        await store.client.query(`SAVEPOINT ${sp}`);
        store.depth++;
        try { const out = await fn(); await store.client.query(`RELEASE SAVEPOINT ${sp}`); return out; }
        catch (e) { await store.client.query(`ROLLBACK TO SAVEPOINT ${sp}`); throw e; }
        finally { store.depth--; }
      }
      const client = await pool.connect();
      try {
        return await tx.run({ client, depth: 0 }, async () => {
          await client.query("BEGIN");
          try { const out = await fn(); await client.query("COMMIT"); return out; }
          catch (e) { await client.query("ROLLBACK"); throw e; }
        });
      } finally { client.release(); }
    },
    async close() { await pool.end(); },
  };
}

// ── Migrations ─────────────────────────────────────────────────────────────────────────────

export async function migrate(d: Driver) {
  const dir = path.join(process.cwd(), "migrations", d.kind);
  await d.exec("CREATE TABLE IF NOT EXISTS schema_migrations (name TEXT PRIMARY KEY, applied_at TEXT NOT NULL)");
  const applied = new Set((await d.all<{ name: string }>("SELECT name FROM schema_migrations", [])).map((r) => r.name));
  const files = fs.readdirSync(dir).filter((f) => /^\d+_.+\.sql$/.test(f)).sort();
  for (const file of files) {
    if (applied.has(file)) continue;
    const sql = fs.readFileSync(path.join(dir, file), "utf8");
    try {
      await d.transaction(async () => {
        await d.exec(sql);
        await d.run("INSERT INTO schema_migrations (name, applied_at) VALUES (?, ?)", [file, new Date().toISOString()]);
      });
    } catch (err) {
      // Another instance may have applied it concurrently; re-check before failing.
      const done = await d.all("SELECT 1 FROM schema_migrations WHERE name = ?", [file]);
      if (!done.length) throw new Error(`Migration ${file} failed: ${(err as Error).message}`);
    }
  }
}

export async function openDriver(opts: { url?: string; file: string }): Promise<Driver> {
  const d = opts.url ? await postgresDriver(opts.url) : await sqliteDriver(opts.file);
  await migrate(d);
  return d;
}
