import { round } from "./text";

export type Observation = { priceInr: number; observedAt: string };

export type PriceForecast = {
  observations: number;
  current: number | null;
  low: number | null;
  high: number | null;
  slopePerWeek: number | null;
  timesAtOrBelowTarget: number;
  probability: number | null;
  horizonDays: number;
  note: string;
};

/** Standard normal CDF via the Abramowitz–Stegun erf approximation (error < 1.5e-7). */
export function normCdf(x: number) {
  const z = Math.abs(x) / Math.SQRT2;
  const t = 1 / (1 + 0.3275911 * z);
  const erf = 1 - ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-z * z);
  return x >= 0 ? (1 + erf) / 2 : (1 - erf) / 2;
}

/**
 * Probability that the price touches `target` within `horizonDays`, modelling log-price as a
 * Brownian motion with drift fitted to the user's own observations (first-passage formula).
 * Real prices move in steps around sales, so this is a rough statistical estimate, and the UI
 * says so. Needs at least 5 observations spread over at least 3 days.
 */
export function forecastPrice(obs: Observation[], target: number, horizonDays = 14): PriceForecast {
  const pts = obs
    .map((o) => ({ p: o.priceInr, t: new Date(o.observedAt).getTime() }))
    .filter((o) => o.p > 0 && Number.isFinite(o.t))
    .sort((a, b) => a.t - b.t);
  const base: PriceForecast = {
    observations: pts.length,
    current: pts.at(-1)?.p ?? null,
    low: pts.length ? Math.min(...pts.map((x) => x.p)) : null,
    high: pts.length ? Math.max(...pts.map((x) => x.p)) : null,
    slopePerWeek: null,
    timesAtOrBelowTarget: pts.filter((x) => x.p <= target).length,
    probability: null,
    horizonDays,
    note: "",
  };
  if (!pts.length) return { ...base, note: "No price observations yet." };
  const current = pts.at(-1)!.p;
  if (current <= target) return { ...base, probability: 1, note: "The latest observed price is already at or below your target." };

  const spanDays = (pts.at(-1)!.t - pts[0].t) / 86400_000;
  if (pts.length < 5 || spanDays < 3) {
    return { ...base, note: `Need at least 5 observations over 3+ days for an estimate (have ${pts.length} over ${round(spanDays, 1)} days).` };
  }

  // Least-squares slope of price vs. time, reported as INR per week.
  const xs = pts.map((x) => (x.t - pts[0].t) / 86400_000);
  const mx = xs.reduce((s, x) => s + x, 0) / xs.length;
  const my = pts.reduce((s, x) => s + x.p, 0) / pts.length;
  const sxx = xs.reduce((s, x) => s + (x - mx) ** 2, 0);
  const slope = sxx ? xs.reduce((s, x, i) => s + (x - mx) * (pts[i].p - my), 0) / sxx : 0;

  // Drift and volatility of log price per day.
  const rets: { r: number; dt: number }[] = [];
  for (let i = 1; i < pts.length; i++) {
    const dt = (pts[i].t - pts[i - 1].t) / 86400_000;
    if (dt <= 0) continue;
    rets.push({ r: Math.log(pts[i].p / pts[i - 1].p), dt: Math.max(dt, 0.25) });
  }
  const totalDt = rets.reduce((s, x) => s + x.dt, 0);
  const mu = rets.reduce((s, x) => s + x.r, 0) / totalDt;
  const variance = rets.length > 1 ? rets.reduce((s, x) => s + (x.r - mu * x.dt) ** 2 / x.dt, 0) / (rets.length - 1) : 0;
  const sigma = Math.sqrt(variance);
  const b = Math.log(target / current); // barrier below zero
  const T = horizonDays;

  let probability: number;
  if (sigma < 1e-6) {
    probability = mu * T <= b ? 1 : 0;
  } else {
    const s = sigma * Math.sqrt(T);
    const reflected = Math.exp(Math.min(50, (2 * mu * b) / variance)) * normCdf((b + mu * T) / s);
    probability = normCdf((b - mu * T) / s) + reflected;
  }
  probability = Math.min(1, Math.max(0, probability));

  return {
    ...base,
    slopePerWeek: Math.round(slope * 7),
    probability: round(probability, 3),
    note: "Random-walk estimate fitted to your observations. Festival sales and launches cause jumps the model cannot foresee.",
  };
}
