import "server-only";
import { db, newId, now } from "../db";
import { ApiError } from "../api";
import { forecastPrice, type PriceForecast } from "../engine/price";
import { sendEmail } from "../email";
import { env } from "../env";
import { log } from "../logger";

export type WatchRow = {
  id: string;
  user_id: string;
  product_name: string;
  url: string | null;
  target_price_inr: number;
  active: number;
  triggered_at: string | null;
  created_at: string;
  updated_at: string;
};

export type WatchView = {
  id: string;
  productName: string;
  url: string | null;
  targetPriceInr: number;
  active: boolean;
  triggeredAt: string | null;
  createdAt: string;
  observations: { id: string; priceInr: number; observedAt: string; note: string | null }[];
  forecast: PriceForecast;
};

async function observationsFor(watchId: string) {
  return (await db.all<{ id: string; price_inr: number; observed_at: string; note: string | null }>(
      "SELECT id, price_inr, observed_at, note FROM price_observations WHERE watch_id = ? ORDER BY observed_at",
      watchId,
    ))
    .map((o) => ({ id: o.id, priceInr: o.price_inr, observedAt: o.observed_at, note: o.note }));
}

export async function watchView(w: WatchRow): Promise<WatchView> {
  const observations = await observationsFor(w.id);
  return {
    id: w.id,
    productName: w.product_name,
    url: w.url,
    targetPriceInr: w.target_price_inr,
    active: w.active === 1,
    triggeredAt: w.triggered_at,
    createdAt: w.created_at,
    observations,
    forecast: forecastPrice(observations, w.target_price_inr, 14),
  };
}

export async function listWatches(userId: string): Promise<WatchView[]> {
  return Promise.all((await db.all<WatchRow>("SELECT * FROM price_watches WHERE user_id = ? ORDER BY created_at DESC LIMIT 100", userId)).map(watchView));
}

export async function getOwnedWatch(id: string, userId: string): Promise<WatchRow> {
  const row = await db.get<WatchRow>("SELECT * FROM price_watches WHERE id = ? AND user_id = ?", id, userId);
  if (!row) throw new ApiError(404, "Price watch not found.");
  return row;
}

export async function createWatch(userId: string, d: { productName: string; url?: string | null; targetPriceInr: number }) {
  const n = (await db.get<{ n: number }>("SELECT COUNT(*) AS n FROM price_watches WHERE user_id = ?", userId))!.n;
  if (n >= 100) throw new ApiError(409, "You can keep at most 100 price watches.");
  const id = newId();
  const t = now();
  await db.run(
    "INSERT INTO price_watches (id, user_id, product_name, url, target_price_inr, active, created_at, updated_at) VALUES (?, ?, ?, ?, ?, 1, ?, ?)",
    id, userId, d.productName, d.url ?? null, d.targetPriceInr, t, t,
  );
  return id;
}

export async function updateWatch(w: WatchRow, d: { targetPriceInr?: number; active?: boolean }) {
  const targetChanged = d.targetPriceInr !== undefined && d.targetPriceInr !== w.target_price_inr;
  await db.run(
    "UPDATE price_watches SET target_price_inr = ?, active = ?, triggered_at = ?, updated_at = ? WHERE id = ?",
    d.targetPriceInr ?? w.target_price_inr,
    d.active === undefined ? w.active : d.active ? 1 : 0,
    targetChanged ? null : w.triggered_at, // a new target re-arms the alert
    now(),
    w.id,
  );
}

export async function deleteWatch(id: string) {
  await db.run("DELETE FROM price_watches WHERE id = ?", id);
}

export async function addObservation(w: WatchRow, d: { priceInr: number; observedAt: string; note?: string | null }) {
  const n = (await db.get<{ n: number }>("SELECT COUNT(*) AS n FROM price_observations WHERE watch_id = ?", w.id))!.n;
  if (n >= 1000) throw new ApiError(409, "This watch already has 1,000 observations.");
  await db.run(
    "INSERT INTO price_observations (id, watch_id, price_inr, observed_at, note, created_at) VALUES (?, ?, ?, ?, ?, ?)",
    newId(), w.id, d.priceInr, new Date(d.observedAt).toISOString(), d.note ?? null, now(),
  );
}

export async function deleteObservation(watchId: string, observationId: string) {
  await db.run("DELETE FROM price_observations WHERE id = ? AND watch_id = ?", observationId, watchId);
}

const inr = (n: number) => `₹${n.toLocaleString("en-IN")}`;

/**
 * Fires the alert for a watch whose latest observed price has reached its target. Idempotent:
 * `triggered_at` is set once and only cleared when the user changes the target.
 */
export async function evaluateWatch(watchId: string): Promise<boolean> {

  const w = await db.get<WatchRow & { email: string; name: string }>(
    "SELECT w.*, u.email, u.name FROM price_watches w JOIN users u ON u.id = w.user_id WHERE w.id = ?",
    watchId,
  );
  if (!w || !w.active || w.triggered_at) return false;
  const latest = await db.get<{ price_inr: number; observed_at: string }>(
    "SELECT price_inr, observed_at FROM price_observations WHERE watch_id = ? ORDER BY observed_at DESC LIMIT 1",
    watchId,
  );
  if (!latest || latest.price_inr > w.target_price_inr) return false;

  const title = `${w.product_name} hit your target`;
  const body = `Latest observed price ${inr(latest.price_inr)} is at or below your target of ${inr(w.target_price_inr)}.`;
  await db.transaction(async () => {
    await db.run("UPDATE price_watches SET triggered_at = ?, updated_at = ? WHERE id = ?", now(), now(), w.id);
    await db.run(
      "INSERT INTO notifications (id, user_id, title, body, link, created_at) VALUES (?, ?, ?, ?, ?, ?)",
      newId(), w.user_id, title, body, "/dashboard/watches", now(),
    );
  });
  try {
    await sendEmail({
      to: w.email,
      subject: title,
      text: `Hi ${w.name},\n\n${body}\n\nReview it before buying: ${env.APP_URL}/dashboard/watches\n\nBuySure AI never buys anything on your behalf.\n`,
    });
  } catch (err) {
    log.error("Price alert email failed", err, { watchId });
  }
  return true;
}

export async function evaluateAllWatches() {
  const ids = (await db.all<{ id: string }>("SELECT id FROM price_watches WHERE active = 1 AND triggered_at IS NULL")).map((r) => r.id);
  let fired = 0;
  for (const id of ids) if (await evaluateWatch(id)) fired++;
  return { checked: ids.length, fired };
}
