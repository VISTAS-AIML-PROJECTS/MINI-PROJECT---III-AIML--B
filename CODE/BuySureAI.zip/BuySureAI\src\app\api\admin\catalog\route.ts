import { handler, json, readJson, ApiError } from "@/lib/api";
import { upsertProduct } from "@/lib/catalog/repo";
import { catalogProductSchema } from "@/lib/validation";
import { adminLog } from "@/lib/repos/misc";
import { db } from "@/lib/db";

export const POST = handler({ auth: "admin" }, async (req, { user }) => {
  const d = await readJson(req, catalogProductSchema, 50_000);
  if ((await db.get("SELECT 1 FROM catalog_products WHERE slug = ?", d.slug))) throw new ApiError(409, "That slug is already used.", { slug: "Already used." });
  const id = await upsertProduct(null, d);
  await adminLog(user!.id, "catalog.create", id, { slug: d.slug });
  return json({ id }, 201);
});
