import { beforeEach, describe, expect, it } from "vitest";
import { resetDbForTests } from "@/lib/db";
import { parseBudget, parseQuery, parseUrl, matchProduct } from "@/lib/catalog/query";
import { catalogSearch, fromAgent } from "@/lib/search/service";
import { agentResultSchema, type AgentResult } from "@/lib/search/schema";
import { topPicks } from "@/lib/catalog/picks";
import { allPublished } from "@/lib/catalog/repo";
import { SEED_PRODUCTS } from "@/lib/catalog/seed";
import { categoryBySlug } from "@/lib/catalog/categories";
import { checkPhysics } from "@/lib/engine/physics";

beforeEach(async () => { await resetDbForTests(); });

describe("query understanding", () => {
  it("reads budgets in every common Indian format", async () => {
    expect(parseBudget("best phone under 20000")).toBe(20000);
    expect(parseBudget("phone under 20k")).toBe(20000);
    expect(parseBudget("laptop below ₹1,25,000")).toBe(125000);
    expect(parseBudget("tv under 1.5 lakh")).toBe(150000);
    expect(parseBudget("earbuds within rs 3,000")).toBe(3000);
    expect(parseBudget("iphone 17 pro")).toBeNull();
  });

  it("detects category and priority", async () => {
    const q = parseQuery("best mobile under 30k for gaming");
    expect(q.category?.slug).toBe("phones");
    expect(q.preset).toBe("gaming");
    expect(parseQuery("tws earbuds for gym").preset).toBe("workout");
    expect(parseQuery("macbook for college").category?.slug).toBe("laptops");
  });

  it("extracts the product name from marketplace links without fetching them", async () => {
    const u = parseUrl("https://www.amazon.in/Redmi-15C-5G-Storage-Battery/dp/B0FKXYZ123/ref=sr_1_1")!;
    expect(u.store).toBe("Amazon");
    expect(u.words).toEqual(expect.arrayContaining(["redmi", "15c", "5g"]));
    expect(parseUrl("https://www.flipkart.com/poco-m7-pro-5g-lunar-dust-128-gb/p/itm123abc")!.store).toBe("Flipkart");
    expect(parseUrl("not a link")).toBeNull();
  });

  it("matches the exact model and does not confuse 15 with 15C", async () => {
    const all = await allPublished();
    expect(matchProduct(["redmi", "15c", "5g"], all)?.item.slug).toBe("redmi-15c-5g");
    expect(matchProduct(["oneplus", "15r"], all)?.item.slug).toBe("oneplus-15r");
    expect(matchProduct(["oneplus", "15"], all)?.item.slug).toBe("oneplus-15");
    expect(matchProduct(["best", "phone"], all)).toBeNull();
  });
});

describe("catalogue search", () => {
  it("keeps results within budget and ranks by the requested priority", async () => {
    const r = await catalogSearch("best phone under 20000 for camera");
    expect(r.items.length).toBeGreaterThan(2);
    expect(r.items.every((i) => (i.priceInr ?? 0) <= 20000)).toBe(true);
    expect(r.criteria.map((c) => c.key)).toContain("camera");
    expect(r.weights.camera).toBe(10);
  });

  it("finds a pasted product and ranks it against same-price rivals", async () => {
    const r = await catalogSearch("https://www.amazon.in/Redmi-15C-5G-Storage-Battery/dp/B0FKXYZ123");
    const me = r.items.find((i) => i.isSearched);
    expect(me?.name).toBe("Redmi 15C 5G");
    expect(r.understood.budget).toBe(16000);
    expect(r.weights).toEqual(categoryBySlug("phones")!.presets[0].weights); // the URL's "Battery" word must not set a priority
  });

  it("says plainly when a category is outside the catalogue", async () => {
    const r = await catalogSearch("best air fryer");
    expect(r.items).toHaveLength(0);
    expect(r.caveats[0]).toMatch(/Live web search/);
  });

  it("produces distinct, badged top picks for the home page", async () => {
    const picks = await topPicks("phones");
    expect(picks.length).toBe(4);
    expect(new Set(picks.map((p) => p.item.id)).size).toBe(4);
    expect(picks[0].badge).toMatch(/Best under/);
  });
});

describe("seed data integrity", () => {
  it("has unique slugs, real sources and passes physics checks", async () => {
    expect(new Set(SEED_PRODUCTS.map((p) => p.slug)).size).toBe(SEED_PRODUCTS.length);
    for (const p of SEED_PRODUCTS) {
      expect(p.sources.length, p.slug).toBeGreaterThan(0);
      for (const s of p.sources) expect(s.url, p.slug).toMatch(/^https:\/\//);
      const def = categoryBySlug(p.category)!;
      const ph = checkPhysics(def.physics, def.physicsSpecs(p.specs) as never, {}, p.priceInr);
      expect(ph.status, `${p.slug}: ${ph.findings.map((f) => f.message).join("; ")}`).not.toBe("fail");
    }
  });
});

describe("live research results", () => {
  const sample: AgentResult = {
    understood: { searched_product: "Philips Airfryer 3000 Series NA130", category_name: "Air fryers", category_slug: "other", budget_inr: 8000, intent: "Family air fryer under ₹8,000" },
    criteria: [
      { key: "price", label: "Price", direction: "lower", unit: "₹", weight: 7 },
      { key: "capacity", label: "Capacity", direction: "higher", unit: "L", weight: 8 },
      { key: "power", label: "Power", direction: "higher", unit: "W", weight: 4 },
      { key: "warranty", label: "Warranty", direction: "higher", unit: "years", weight: 3 },
    ],
    products: [
      { name: "Airfryer 3000 Series NA130", brand: "Philips", is_searched_product: true, price_inr: 6999, price_note: "Amazon, Oct 2026", metrics: [{ key: "capacity", value: 4.1 }, { key: "power", value: 1400 }, { key: "warranty", value: 2 }], key_specs: [{ label: "Capacity", value: "4.1 L" }], battery_mah: null, weight_g: null, length_mm: null, width_mm: null, thickness_mm: null, highlights: ["Rapid Air"], drawbacks: [], sources: [{ title: "Philips", url: "https://www.philips.co.in/" }] },
      { name: "Air Fryer 5.5L", brand: "Example", is_searched_product: false, price_inr: 5999, price_note: "Flipkart", metrics: [{ key: "capacity", value: 5.5 }, { key: "power", value: 1500 }, { key: "warranty", value: 2 }], key_specs: [], battery_mah: null, weight_g: null, length_mm: null, width_mm: null, thickness_mm: null, highlights: [], drawbacks: [], sources: [{ title: "bad", url: "javascript:alert(1)" }] },
      { name: "Air Fryer Mini", brand: "Example", is_searched_product: false, price_inr: null, price_note: "", metrics: [{ key: "capacity", value: null }], key_specs: [], battery_mah: null, weight_g: null, length_mm: null, width_mm: null, thickness_mm: null, highlights: [], drawbacks: [], sources: [] },
    ],
    verdict: "The 5.5 L model gives more capacity for less.",
    caveats: [],
  };

  it("validates against the strict schema", async () => {
    expect(agentResultSchema.safeParse(sample).success).toBe(true);
    expect(agentResultSchema.safeParse({ ...sample, products: "x" }).success).toBe(false);
  });

  it("ranks any category with the agent's criteria and the shopper's weights", async () => {
    const r = await fromAgent("best air fryer", sample);
    expect(r.mode).toBe("live");
    expect(r.items[0].name).toBe("Air Fryer 5.5L");
    expect(r.items.find((i) => i.isSearched)?.rank).toBe(2);
    expect(r.criteria[0].key).toBe("price");
  });

  it("drops unsafe source links", async () => {
    const r = await fromAgent("best air fryer", sample);
    expect(r.items.flatMap((i) => i.sources).every((s) => s.url.startsWith("http"))).toBe(true);
  });

  it("uses BuySure's own criteria for known categories and runs physics checks", async () => {
    const phone: AgentResult = {
      ...sample,
      understood: { ...sample.understood, category_slug: "phones", category_name: "Smartphones" },
      criteria: [{ key: "battery", label: "Battery", direction: "higher", unit: "Wh", weight: 10 }],
      products: [
        { ...sample.products[0], name: "Fake Max", brand: "X", metrics: [{ key: "battery", value: 38.7 }], battery_mah: 10000, weight_g: 170, length_mm: 160, width_mm: 74, thickness_mm: 7.6 },
        { ...sample.products[1], name: "Real 5000", brand: "Y", metrics: [{ key: "battery", value: 19.4 }], battery_mah: 5000, weight_g: 185, length_mm: 160, width_mm: 75, thickness_mm: 8 },
      ],
    };
    const r = await fromAgent("phone", phone);
    expect(r.criteria.map((c) => c.key)).toContain("performance");
    expect(r.items.find((i) => i.name === "Real 5000")!.rank).toBeLessThan(r.items.find((i) => i.name === "Fake Max")!.rank);
    expect(r.caveats.join(" ")).toMatch(/verified catalogue/); // current catalogue phones compete too
    expect(r.items.length).toBeGreaterThan(2);
    expect(r.items.find((i) => i.name === "Fake Max")!.physics.status).toBe("fail");
  });
});

describe("ranking integrity", () => {
  it("never ranks on star ratings or review counts, which review farms inflate", async () => {
    const r = await fromAgent("air fryer", {
      understood: { searched_product: null, category_name: "Air fryers", category_slug: "other", budget_inr: null, intent: "x" },
      criteria: [
        { key: "price", label: "Price", direction: "lower", unit: "₹", weight: 7 },
        { key: "rating", label: "User rating", direction: "higher", unit: "stars", weight: 9 },
        { key: "capacity", label: "Capacity", direction: "higher", unit: "L", weight: 6 },
      ],
      products: [], verdict: "", caveats: [],
    });
    expect(r.criteria.map((c) => c.key)).toEqual(["price", "capacity"]);
  });
});
