import type { Metadata } from "next";
import { Breadcrumbs } from "@/components/Breadcrumbs";
import { pageMeta } from "@/lib/seo";
import { site } from "@/lib/site";
import { ContactForm } from "./ContactForm";

export const metadata: Metadata = pageMeta({
  title: "Contact us",
  description: "Questions, bug reports, privacy requests or partnership enquiries for BuySure AI. We reply to every message within 2 business days.",
  path: "/contact",
});

export default async function ContactPage({ searchParams }: { searchParams: Promise<{ topic?: string }> }) {
  const { topic } = await searchParams;
  return (
    <div className="wrap">
      <Breadcrumbs items={[{ name: "Contact", path: "/contact" }]} />
      <header className="page-head">
        <span className="eyebrow">Contact</span>
        <h1>Write to us</h1>
        <p className="lede">{site.responseTime} Privacy and data requests are handled first.</p>
      </header>
      <div className="grid-2" style={{ gap: 48, paddingBottom: 80, alignItems: "start" }}>
        <ContactForm defaultTopic={topic} />
        <aside>
          <h2 style={{ fontSize: "var(--step-1)" }}>Other ways to reach us</h2>
          {site.contactEmail ? (
            <p>Email: <a href={`mailto:${site.contactEmail}`}>{site.contactEmail}</a></p>
          ) : (
            <p className="muted">The form is the fastest way to reach us. Every message goes to a person.</p>
          )}
          {site.businessAddress ? (
            <>
              <h2 style={{ fontSize: "var(--step-1)", marginTop: 28 }}>Registered office</h2>
              <address style={{ fontStyle: "normal" }}>{site.businessAddress}</address>
              <p>
                <a href={`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(site.businessAddress)}`} target="_blank" rel="noopener noreferrer">
                  Get directions (opens Google Maps)
                </a>
              </p>
            </>
          ) : (
            <p className="small muted">BuySure AI is an online service and does not receive visitors in person.</p>
          )}
          <h2 style={{ fontSize: "var(--step-1)", marginTop: 28 }}>Before you write</h2>
          <ul className="small">
            <li>To delete your data, use Settings → Delete account. It is immediate.</li>
            <li>For a wrong verdict on a shared report, include the link and the correct certification details.</li>
          </ul>
        </aside>
      </div>
    </div>
  );
}
