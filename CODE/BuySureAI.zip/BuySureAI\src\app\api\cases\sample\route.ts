import { handler, json, limit } from "@/lib/api";
import { createCase, createProduct, importReviews } from "@/lib/repos/cases";
import { sampleCase } from "@/lib/sample-data";
import { db } from "@/lib/db";

/** Copies the fictional sample case into the user's workspace so they can edit and re-audit it. */
export const POST = handler({ auth: "user" }, async (_req, { user }) => {
  await limit(`sample-case:${user!.id}`, 5, 3600);
  const s = sampleCase();
  const id = await db.transaction(async () => {
    const caseId = await createCase(user!.id, { title: s.title, category: s.category, budgetInr: s.budgetInr });
    for (const p of s.products) {
      const { key: _key, reviews, ...data } = p;
      const pid = await createProduct(caseId, { ...data, specs: data.specs, certified: data.certified, scores: data.scores, cost: data.cost });
      await importReviews(pid, reviews.map((r) => ({ ...r, body: r.body })), false);
    }
    return caseId;
  });
  return json({ id }, 201);
});
