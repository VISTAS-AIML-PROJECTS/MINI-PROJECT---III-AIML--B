import "server-only";
import { db, newId, now } from "../db";

export type UserRow = {
  id: string;
  email: string;
  name: string;
  password_hash: string;
  role: "user" | "admin";
  disabled_at: string | null;
  created_at: string;
  updated_at: string;
};

export const findUserByEmail = (email: string) => db.get<UserRow>("SELECT * FROM users WHERE email = ?", email.toLowerCase());
export const findUserById = (id: string) => db.get<UserRow>("SELECT * FROM users WHERE id = ?", id);

export async function createUser(data: { email: string; name: string; passwordHash: string; role?: "user" | "admin" }) {
  const id = newId();
  const t = now();
  await db.run(
    "INSERT INTO users (id, email, name, password_hash, role, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
    id, data.email.toLowerCase(), data.name, data.passwordHash, data.role ?? "user", t, t,
  );
  return id;
}

export async function updateUserName(id: string, name: string) {
  await db.run("UPDATE users SET name = ?, updated_at = ? WHERE id = ?", name, now(), id);
}

export async function updatePasswordHash(id: string, hash: string) {
  await db.run("UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?", hash, now(), id);
}

export async function deleteUser(id: string) {
  await db.run("DELETE FROM users WHERE id = ?", id);
}

/** Everything we hold about a user, for the data-export (right of access) feature. */
export async function exportUserData(id: string) {
  const user = await db.get("SELECT id, email, name, role, created_at, updated_at FROM users WHERE id = ?", id);
  const cases = await db.all("SELECT id, title, category, budget_inr, weights_json, share_slug, created_at, updated_at FROM cases WHERE user_id = ?", id);
  const products = await db.all("SELECT p.* FROM products p JOIN cases c ON c.id = p.case_id WHERE c.user_id = ?", id);
  const reviews = await db.all(
    "SELECT r.* FROM reviews r JOIN products p ON p.id = r.product_id JOIN cases c ON c.id = p.case_id WHERE c.user_id = ?",
    id,
  );
  const watches = await db.all("SELECT * FROM price_watches WHERE user_id = ?", id);
  const observations = await db.all("SELECT o.* FROM price_observations o JOIN price_watches w ON w.id = o.watch_id WHERE w.user_id = ?", id);
  const notifications = await db.all("SELECT * FROM notifications WHERE user_id = ?", id);
  const siteReview = await db.get("SELECT rating, body, display_name, status, created_at FROM site_reviews WHERE user_id = ?", id);
  return { exportedAt: now(), user, cases, products, reviews, watches, observations, notifications, siteReview: siteReview ?? null };
}
