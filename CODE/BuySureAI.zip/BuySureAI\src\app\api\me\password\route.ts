import { handler, json, readJson, limit, ApiError } from "@/lib/api";
import { changePasswordSchema } from "@/lib/validation";
import { findUserById, updatePasswordHash } from "@/lib/repos/users";
import { hashPassword, verifyPassword } from "@/lib/auth/password";
import { createSession, destroyAllSessions } from "@/lib/auth/session";

export const POST = handler({ auth: "user" }, async (req, { user }) => {
  await limit(`change-password:${user!.id}`, 5, 900);
  const { currentPassword, newPassword } = await readJson(req, changePasswordSchema, 2_000);
  const row = (await findUserById(user!.id))!;
  if (!(await verifyPassword(currentPassword, row.password_hash))) {
    throw new ApiError(401, "Current password is incorrect.", { currentPassword: "Current password is incorrect." });
  }
  await updatePasswordHash(row.id, await hashPassword(newPassword));
  await destroyAllSessions(row.id); // other devices are signed out
  await createSession(row.id, req.headers.get("user-agent"));
  return json({ ok: true });
});
