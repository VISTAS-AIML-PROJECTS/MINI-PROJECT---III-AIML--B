import Link from "next/link";
import { requireAdmin } from "@/lib/auth/guard";
import { listSiteReviewsForModeration } from "@/lib/repos/misc";
import { dateTime } from "@/lib/format";
import { AdminButton } from "../AdminActions";
import { Pager } from "../Pager";

const STATUSES = ["pending", "approved", "rejected"] as const;

export default async function AdminReviews({ searchParams }: { searchParams: Promise<{ status?: string; page?: string }> }) {
  await requireAdmin();
  const sp = await searchParams;
  const status = STATUSES.includes(sp.status as (typeof STATUSES)[number]) ? sp.status! : "pending";
  const page = Math.max(1, Number(sp.page) || 1);
  const { total, items } = await listSiteReviewsForModeration(status, page);
  return (
    <>
      <h1 style={{ fontSize: "var(--step-3)" }}>Review moderation</h1>
      <p className="muted small">Approve reviews that are genuine and on-topic, including critical ones. Reject only spam, abuse or personal data.</p>
      <nav className="btn-row" aria-label="Filter by status" style={{ marginBottom: 18 }}>
        {STATUSES.map((s) => <Link key={s} href={`/admin/reviews?status=${s}`} className={`btn btn-small ${status === s ? "" : "btn-secondary"}`}>{s}</Link>)}
      </nav>
      {items.length ? (
        <ul className="list-plain">
          {items.map((r) => (
            <li key={r.id} className="panel">
              <div className="panel-head">
                <div>
                  <strong>{r.display_name}</strong> · {r.rating}★
                  <div className="small muted">{r.email} · {dateTime(r.created_at)}</div>
                </div>
                <div className="btn-row" style={{ gap: 6 }}>
                  {r.status !== "approved" && <AdminButton url={`/api/admin/site-reviews/${r.id}`} body={{ status: "approved" }} label="Approve" />}
                  {r.status !== "rejected" && <AdminButton url={`/api/admin/site-reviews/${r.id}`} body={{ status: "rejected" }} label="Reject" danger />}
                </div>
              </div>
              <p style={{ margin: 0 }}>{r.body}</p>
            </li>
          ))}
        </ul>
      ) : <div className="empty"><p className="muted" style={{ margin: 0 }}>Nothing {status}.</p></div>}
      <Pager page={page} total={total} pageSize={25} base="/admin/reviews" params={{ status }} />
    </>
  );
}
