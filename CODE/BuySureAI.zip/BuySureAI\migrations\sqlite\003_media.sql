-- Uploaded product photos, stored in the database so serverless hosts need no disk.
CREATE TABLE media (
  name        TEXT PRIMARY KEY,
  mime        TEXT NOT NULL,
  data        BLOB NOT NULL,
  created_at  TEXT NOT NULL
);
