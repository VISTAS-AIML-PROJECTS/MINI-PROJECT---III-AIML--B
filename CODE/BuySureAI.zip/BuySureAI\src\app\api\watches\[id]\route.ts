import { handler, json, readJson } from "@/lib/api";
import { watchUpdateSchema } from "@/lib/validation";
import { deleteWatch, evaluateWatch, getOwnedWatch, updateWatch } from "@/lib/repos/watches";

type P = { id: string };

export const PATCH = handler<P>({ auth: "user" }, async (req, { params, user }) => {
  const w = await getOwnedWatch(params.id, user!.id);
  const data = await readJson(req, watchUpdateSchema, 2_000);
  await updateWatch(w, data);
  const fired = await evaluateWatch(w.id);
  return json({ ok: true, fired });
});

export const DELETE = handler<P>({ auth: "user" }, async (_req, { params, user }) => {
  const w = await getOwnedWatch(params.id, user!.id);
  await deleteWatch(w.id);
  return json({ ok: true });
});
