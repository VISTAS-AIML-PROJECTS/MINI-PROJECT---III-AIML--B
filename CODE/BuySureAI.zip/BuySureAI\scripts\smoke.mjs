/**
 * End-to-end smoke test against the PRODUCTION build.
 *   npm run build && npm run test:smoke
 * Starts `next start` on a throwaway database, then exercises pages, SEO files, security
 * headers, auth, CSRF, IDOR, admin protection, validation, rate limits, forms, audits,
 * sharing, price alerts and internal links over real HTTP. Exits non-zero on any failure.
 */
import { spawn, spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import os from "node:os";

const PORT = Number(process.env.SMOKE_PORT ?? 3100);
const BASE = `http://localhost:${PORT}`;
const dbFile = path.join(os.tmpdir(), `buysure-smoke-${Date.now()}.db`);
const env = {
  ...process.env,
  NODE_ENV: "production",
  PORT: String(PORT),
  APP_URL: BASE,
  NEXT_PUBLIC_SITE_URL: BASE,
  DATABASE_PATH: dbFile,
  SESSION_SECRET: "smoke-test-secret-smoke-test-secret-0123456789",
  CRON_SECRET: "smoke-cron-secret",
};

let failures = 0;
let passes = 0;
const ok = (cond, msg) => {
  if (cond) { passes++; console.log(`  ✓ ${msg}`); }
  else { failures++; console.log(`  ✗ ${msg}`); }
};
const section = (t) => console.log(`\n${t}`);

class Client {
  constructor() { this.cookie = ""; }
  async req(p, { method = "GET", body, origin = BASE, headers = {} } = {}) {
    const h = { ...headers };
    if (this.cookie) h.cookie = this.cookie;
    if (origin && method !== "GET") h.origin = origin;
    if (body !== undefined) h["content-type"] = "application/json";
    const res = await fetch(BASE + p, { method, headers: h, body: body !== undefined ? JSON.stringify(body) : undefined, redirect: "manual" });
    const set = res.headers.getSetCookie?.() ?? [];
    for (const c of set) {
      const [pair] = c.split(";");
      if (/Max-Age=0|Expires=Thu, 01 Jan 1970/i.test(c) || pair.endsWith("=")) this.cookie = "";
      else this.cookie = pair;
    }
    const text = await res.text();
    let json = null;
    try { json = JSON.parse(text); } catch {}
    return { status: res.status, headers: res.headers, text, json };
  }
}

async function waitForServer() {
  for (let i = 0; i < 60; i++) {
    try { const r = await fetch(`${BASE}/api/health`); if (r.ok) return; } catch {}
    await new Promise((r) => setTimeout(r, 500));
  }
  throw new Error("Server did not start");
}

const meta = (html, re) => (html.match(re) ?? [])[1];

async function main() {
  const server = spawn(process.execPath, [path.join("node_modules", "next", "dist", "bin", "next"), "start", "-p", String(PORT)], { env, stdio: ["ignore", "pipe", "pipe"] });
  let serverLog = "";
  server.stdout.on("data", (d) => (serverLog += d));
  server.stderr.on("data", (d) => (serverLog += d));
  try {
    await waitForServer();
    const anon = new Client();

    section("Public pages, metadata and SEO");
    const pages = ["/", "/demo", "/how-it-works", "/faq", "/about", "/contact", "/contact/thanks", "/reviews", "/privacy", "/terms", "/login", "/register", "/forgot-password"];
    const titles = new Map();
    const internalLinks = new Set();
    for (const p of pages) {
      const r = await anon.req(p);
      const title = meta(r.text, /<title>([^<]*)<\/title>/);
      const desc = meta(r.text, /<meta name="description" content="([^"]*)"/);
      const canonical = meta(r.text, /<link rel="canonical" href="([^"]*)"/);
      const h1s = (r.text.match(/<h1[\s>]/g) ?? []).length;
      ok(r.status === 200, `${p} → 200`);
      ok(Boolean(title) && Boolean(desc) && desc.length > 40, `${p} has title and meta description`);
      ok(/^https?:\/\/[^/]+/.test(canonical ?? "") && new URL(canonical).pathname.replace(/\/$/, "") === p.replace(/\/$/, ""), `${p} canonical is absolute and correct (${canonical})`);
      ok(h1s === 1, `${p} has exactly one h1 (found ${h1s})`);
      ok(/property="og:image"/.test(r.text), `${p} has og:image`);
      if (titles.has(title)) ok(false, `${p} title duplicates ${titles.get(title)}`);
      titles.set(title, p);
      for (const m of r.text.matchAll(/href="(\/[^"#?]*)/g)) internalLinks.add(m[1]);
      const imgs = [...r.text.matchAll(/<img\b[^>]*>/g)].map((m) => m[0]);
      ok(imgs.every((i) => /\balt="/.test(i)), `${p} images all have alt text`);
    }
    ok(titles.size === pages.length, "all page titles are unique");

    const nf = await anon.req("/definitely-not-a-page");
    ok(nf.status === 404 && /does not exist/.test(nf.text), "custom 404 page with status 404");
    const robots = await anon.req("/robots.txt");
    ok(robots.status === 200 && /Disallow: \/admin/.test(robots.text) && /Sitemap:/.test(robots.text), "robots.txt disallows private areas and links sitemap");
    const sm = await anon.req("/sitemap.xml");
    ok(sm.status === 200 && sm.text.includes("/how-it-works</loc>") && !sm.text.includes("/dashboard"), "sitemap.xml lists public pages only");
    const og = await fetch(`${BASE}/opengraph-image`);
    ok(og.status === 200 && og.headers.get("content-type")?.includes("image/png"), "social preview image renders");
    ok((await fetch(`${BASE}/icon.svg`)).status === 200, "favicon served");
    ok((await fetch(`${BASE}/manifest.webmanifest`)).status === 200, "web manifest served");
    const home = await anon.req("/");
    ok(/application\/ld\+json/.test(home.text) && /"@type":"Organization"/.test(home.text), "structured data present");

    section("Security headers");
    const h = home.headers;
    ok(/default-src 'self'/.test(h.get("content-security-policy") ?? ""), "Content-Security-Policy set");
    ok(h.get("x-frame-options") === "DENY", "X-Frame-Options DENY");
    ok(h.get("x-content-type-options") === "nosniff", "X-Content-Type-Options nosniff");
    ok(Boolean(h.get("strict-transport-security")), "HSTS set in production");
    ok(!h.get("x-powered-by"), "X-Powered-By removed");

    section("Health and demo");
    ok((await anon.req("/api/health")).json?.status === "ok", "health check ok");
    const demo = await anon.req("/api/demo/audit", { method: "POST", body: { weights: { price: 10 } } });
    ok(demo.status === 200 && demo.json.report.products.length === 4, "demo audit runs the engine");
    ok(demo.json.report.products.find((p) => p.id === "kestrel-max").disqualified, "demo flags the impossible battery");

    section("Authentication and CSRF");
    const alice = new Client();
    const noOrigin = await alice.req("/api/auth/register", { method: "POST", origin: null, body: { name: "A", email: "alice@example.com", password: "longpassword1", acceptTerms: true } });
    ok(noOrigin.status === 403, "state-changing request without Origin is blocked (CSRF)");
    const evil = await alice.req("/api/auth/register", { method: "POST", origin: "https://evil.example", body: { name: "A", email: "alice@example.com", password: "longpassword1", acceptTerms: true } });
    ok(evil.status === 403, "cross-site Origin is blocked (CSRF)");
    const bad = await alice.req("/api/auth/register", { method: "POST", body: { name: "", email: "nope", password: "short", acceptTerms: false } });
    ok(bad.status === 422 && bad.json.fields?.email && bad.json.fields?.password, "invalid registration returns field errors");
    const reg = await alice.req("/api/auth/register", { method: "POST", body: { name: "Alice", email: "alice@example.com", password: "longpassword1", acceptTerms: true } });
    ok(reg.status === 201 && alice.cookie.startsWith("__Host-bs_session="), "registration signs the user in with a __Host- cookie");
    const dup = await new Client().req("/api/auth/register", { method: "POST", body: { name: "A2", email: "ALICE@example.com", password: "longpassword1", acceptTerms: true } });
    ok(dup.status === 409, "duplicate email (case-insensitive) rejected");
    const me = await alice.req("/api/me");
    ok(me.json.user?.email === "alice@example.com" && !("password_hash" in me.json.user), "/api/me returns the user without secrets");
    ok((await anon.req("/api/cases")).status === 401, "protected API requires sign-in");
    const dash = await anon.req("/dashboard");
    ok([307, 308].includes(dash.status) && /\/login\?next=/.test(dash.headers.get("location") ?? ""), "dashboard redirects anonymous users to login");

    section("Cases, audits and sharing");
    const created = await alice.req("/api/cases/sample", { method: "POST", body: {} });
    ok(created.status === 201, "sample case copied into account");
    const caseId = created.json.id;
    const audit = await alice.req(`/api/cases/${caseId}/audit`, { method: "POST", body: {} });
    ok(audit.status === 201 && audit.json.audit.report.ranking.length === 4, "audit runs and is stored");
    const casePage = await alice.req(`/dashboard/cases/${caseId}`);
    ok(casePage.status === 200 && casePage.text.includes("Kestrel Max"), "case workspace renders for owner");
    const prod = await alice.req(`/api/cases/${caseId}/products`, { method: "POST", body: { name: "Test phone", priceInr: 12000, url: "javascript:alert(1)" } });
    ok(prod.status === 422, "javascript: URL rejected by server validation");
    const xss = await alice.req(`/api/cases/${caseId}/products`, { method: "POST", body: { name: "<script>alert(1)</script>", priceInr: 12000 } });
    ok(xss.status === 201, "product with markup in its name accepted as plain text");
    const casePage2 = await alice.req(`/dashboard/cases/${caseId}`);
    ok(!casePage2.text.includes("<script>alert(1)</script>"), "markup in user data is escaped when rendered");
    const share = await alice.req(`/api/cases/${caseId}/share`, { method: "POST", body: { enabled: true } });
    ok(Boolean(share.json?.shareSlug), "share link created");
    const shared = await anon.req(`/r/${share.json.shareSlug}`);
    ok(shared.status === 200 && /noindex/.test(shared.text), "shared report is public but noindex");
    await alice.req(`/api/cases/${caseId}/share`, { method: "POST", body: { enabled: false } });
    ok((await anon.req(`/r/${share.json.shareSlug}`)).status === 404, "revoked share link 404s");
    const narr = await alice.req(`/api/cases/${caseId}/narrative`, { method: "POST", body: {} });
    ok([200, 502, 503].includes(narr.status) && !/stack|Error:/.test(narr.text), `narrative endpoint degrades cleanly when the AI service is unavailable (${narr.status})`);

    section("Authorization (IDOR and admin)");
    const bob = new Client();
    await bob.req("/api/auth/register", { method: "POST", body: { name: "Bob", email: "bob@example.com", password: "longpassword2", acceptTerms: true } });
    ok((await bob.req(`/api/cases/${caseId}`)).status === 404, "another user cannot read the case");
    ok((await bob.req(`/api/cases/${caseId}`, { method: "DELETE" })).status === 404, "another user cannot delete the case");
    const aliceProducts = (await alice.req(`/api/cases/${caseId}`)).json.products;
    ok((await bob.req(`/api/products/${aliceProducts[0].id}`, { method: "PATCH", body: { priceInr: 1 } })).status === 404, "another user cannot edit a product");
    ok((await bob.req(`/api/products/${aliceProducts[0].id}/reviews`)).status === 404, "another user cannot read imported reviews");
    ok((await bob.req("/api/admin/users")).status === 403, "admin API forbidden to normal users");
    ok((await bob.req(`/api/admin/users/${"x".repeat(36)}`, { method: "PATCH", body: { role: "admin" } })).status === 403, "privilege escalation via admin API blocked");
    ok((await bob.req("/admin")).status === 404, "admin pages hidden (404) from normal users");
    ok((await anon.req("/api/cron", { method: "POST" })).status === 401, "cron endpoint requires its secret");
    const cron = await anon.req("/api/cron", { method: "POST", headers: { authorization: `Bearer ${env.CRON_SECRET}` } });
    ok(cron.status === 200, "cron runs with the secret");

    section("Admin flow");
    const r = spawnSync(process.execPath, [path.join("node_modules", "tsx", "dist", "cli.mjs"), "scripts/create-admin.ts", "bob@example.com"], { env, encoding: "utf8" });
    ok(r.status === 0, "create-admin script promotes a user");
    ok((await bob.req("/api/admin/users")).status === 200, "promoted admin can list users");
    ok((await bob.req("/admin")).status === 200, "admin dashboard renders for admins");

    section("Price watches");
    const w = await alice.req("/api/watches", { method: "POST", body: { productName: "Halden V7", targetPriceInr: 17000 } });
    ok(w.status === 201, "watch created");
    await alice.req(`/api/watches/${w.json.id}/observations`, { method: "POST", body: { priceInr: 18499, observedAt: new Date(Date.now() - 86400000).toISOString() } });
    const hit = await alice.req(`/api/watches/${w.json.id}/observations`, { method: "POST", body: { priceInr: 16999, observedAt: new Date().toISOString() } });
    ok(hit.json?.fired === true, "alert fires when price reaches target");
    const notes = await alice.req("/api/notifications");
    ok(notes.json.unread === 1, "in-app notification created");

    section("Forms, spam protection and rate limits");
    const contact = await anon.req("/api/contact", { method: "POST", body: { name: "Tester", email: "t@example.com", topic: "general", message: "This is a smoke test message, please ignore.", startedAt: Date.now() - 10000 } });
    ok(contact.status === 201 && contact.json.id, "contact form stores a message");
    const bot = await anon.req("/api/contact", { method: "POST", body: { name: "Bot", email: "b@example.com", topic: "general", message: "Buy cheap followers now at our site!!!", website: "spam.example", startedAt: Date.now() - 10000 } });
    ok(bot.status === 201 && !bot.json.id, "honeypot submission silently discarded");
    const messages = await bob.req("/admin/messages");
    ok(messages.text.includes("smoke test message") && !messages.text.includes("cheap followers"), "admin sees the real message only");
    const review = await alice.req("/api/site-reviews", { method: "POST", body: { rating: 4, body: "Caught a fake battery claim for me.", displayName: "Alice" } });
    ok(review.status === 201, "site review submitted for moderation");
    ok(!(await anon.req("/reviews")).text.includes("Caught a fake battery"), "unmoderated review not public");
    let limited = false;
    for (let i = 0; i < 12; i++) {
      const res = await new Client().req("/api/auth/login", { method: "POST", body: { email: "alice@example.com", password: `wrong-password-${i}` } });
      if (res.status === 429) { limited = true; break; }
      if (i === 0) ok(res.status === 401 && /incorrect/.test(res.json.error), "wrong password rejected with generic message");
    }
    ok(limited, "brute-force login attempts are rate limited");
    const unknown = await new Client().req("/api/auth/login", { method: "POST", body: { email: "nobody@example.com", password: "whatever-123" } });
    ok(unknown.status === 401 && unknown.json.error === "Email or password is incorrect.", "unknown email gives the same answer (no enumeration)");
    const forgot = await new Client().req("/api/auth/forgot", { method: "POST", body: { email: "nobody@example.com" } });
    ok(forgot.status === 200, "password reset request does not reveal account existence");

    section("Data export, logout, deletion");
    const exp = await alice.req("/api/me/export");
    ok(exp.status === 200 && exp.json?.cases?.length === 1 && !exp.text.includes("password_hash"), "data export works and excludes the password hash");
    await alice.req("/api/auth/logout", { method: "POST", body: {} });
    ok((await alice.req("/api/me")).json.user === null, "logout ends the session");

    section("Internal links");
    const skip = (l) => l.startsWith("/api/") || l.startsWith("/_next/") || l === "/dashboard" || l.startsWith("/dashboard/") || l.startsWith("/admin");
    let broken = [];
    for (const l of internalLinks) {
      if (skip(l)) continue;
      const res = await fetch(BASE + l, { redirect: "manual" });
      if (res.status >= 400) broken.push(`${l} (${res.status})`);
    }
    ok(broken.length === 0, `no broken internal links among ${internalLinks.size} found${broken.length ? `: ${broken.join(", ")}` : ""}`);

    ok(!/Unhandled API error/.test(serverLog), "server logged no unhandled errors");
  } finally {
    const exited = new Promise((r) => server.once("exit", r));
    server.kill();
    await Promise.race([exited, new Promise((r) => setTimeout(r, 5000))]);
    for (const f of [dbFile, `${dbFile}-wal`, `${dbFile}-shm`]) {
      try { fs.rmSync(f, { force: true }); } catch { /* Windows may hold the file briefly; it is in the temp dir */ }
    }
  }
  console.log(`\n${passes} passed, ${failures} failed`);
  process.exit(failures ? 1 : 0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
