import { z } from "zod";

/** Shape the research agent must return (enforced by a strict tool schema and re-validated here). */

const metric = z.object({ key: z.string(), value: z.number().nullable() });
const source = z.object({ title: z.string(), url: z.string() });

export const agentResultSchema = z.object({
  understood: z.object({
    searched_product: z.string().nullable(),
    category_name: z.string(),
    category_slug: z.enum(["phones", "earbuds", "power-banks", "laptops", "other"]),
    budget_inr: z.number().nullable(),
    intent: z.string(),
  }),
  criteria: z.array(z.object({
    key: z.string(),
    label: z.string(),
    direction: z.enum(["higher", "lower"]),
    unit: z.string(),
    weight: z.number(),
  })),
  products: z.array(z.object({
    name: z.string(),
    brand: z.string(),
    image_url: z.string().nullish(),
    is_searched_product: z.boolean(),
    price_inr: z.number().nullable(),
    price_note: z.string(),
    metrics: z.array(metric),
    key_specs: z.array(z.object({ label: z.string(), value: z.string() })),
    battery_mah: z.number().nullable(),
    weight_g: z.number().nullable(),
    length_mm: z.number().nullable(),
    width_mm: z.number().nullable(),
    thickness_mm: z.number().nullable(),
    highlights: z.array(z.string()),
    drawbacks: z.array(z.string()),
    sources: z.array(source),
  })),
  verdict: z.string(),
  caveats: z.array(z.string()),
});

export type AgentResult = z.infer<typeof agentResultSchema>;

/** JSON Schema for the strict `submit_results` tool (strict mode: every object closed, every key required). */
const nullableNumber = { type: ["number", "null"] };
const str = { type: "string" };
const obj = (properties: Record<string, unknown>) => ({ type: "object", additionalProperties: false, required: Object.keys(properties), properties });

export const submitToolSchema = obj({
  understood: obj({
    searched_product: { type: ["string", "null"], description: "Exact product the user searched for / linked / photographed, or null for a general request like 'best phone under 20k'." },
    category_name: { ...str, description: "Human name of the product category, e.g. 'Smartphones', 'Air fryers', 'Running shoes'." },
    category_slug: { type: "string", enum: ["phones", "earbuds", "power-banks", "laptops", "other"] },
    budget_inr: { ...nullableNumber, description: "Budget ceiling in INR if the user gave one or it is implied by the searched product's price band." },
    intent: { ...str, description: "One sentence: what the shopper wants." },
  }),
  criteria: {
    type: "array",
    description: "3–7 objective, measurable comparison criteria. For the four known categories use exactly the keys given in the instructions.",
    items: obj({ key: str, label: str, direction: { type: "string", enum: ["higher", "lower"] }, unit: str, weight: { type: "number", description: "Importance 0–10 for this shopper." } }),
  },
  products: {
    type: "array",
    description: "4–8 products: the searched product (if any) plus the strongest current alternatives sold in India, ideally within or near the budget.",
    items: obj({
      name: str,
      brand: str,
      image_url: { type: ["string", "null"], description: "Product photo URL from the provided image list, or null." },
      is_searched_product: { type: "boolean" },
      price_inr: { ...nullableNumber, description: "Current Indian price for the stated variant, from a source you found. null if not found." },
      price_note: { ...str, description: "Variant and where/when the price was seen, e.g. '8GB+128GB, Flipkart listing, Oct 2026'." },
      metrics: { type: "array", items: obj({ key: str, value: nullableNumber }), description: "One entry per criterion key (excluding price). null when not found; never guess." },
      key_specs: { type: "array", items: obj({ label: str, value: str }), description: "3–6 short spec lines a shopper cares about." },
      battery_mah: nullableNumber,
      weight_g: nullableNumber,
      length_mm: nullableNumber,
      width_mm: nullableNumber,
      thickness_mm: nullableNumber,
      highlights: { type: "array", items: str, description: "Up to 3 factual strengths." },
      drawbacks: { type: "array", items: str, description: "Up to 2 factual weaknesses." },
      sources: { type: "array", items: obj({ title: str, url: str }), description: "1–3 URLs you actually read for this product." },
    }),
  },
  verdict: { ...str, description: "2–3 sentences: which product is best for this shopper and why, citing numbers." },
  caveats: { type: "array", items: str, description: "Anything uncertain: conflicting prices, unverified claims, products not sold in India." },
});
