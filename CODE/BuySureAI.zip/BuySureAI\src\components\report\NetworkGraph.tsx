import type { NetworkReport } from "@/lib/engine";

const KIND_LABEL = { seller: "Seller", manufacturer: "Manufacturer", importer: "Importer", address: "Address" } as const;

/** Bipartite drawing: products on the left, the entities behind them on the right. */
export function NetworkGraph({ network }: { network: NetworkReport }) {
  const products = network.nodes.filter((n) => n.kind === "product");
  const entities = network.nodes.filter((n) => n.kind !== "product");
  if (!entities.length) {
    return <div className="empty"><p className="muted" style={{ margin: 0 }}>Add seller, manufacturer, importer or address details to products to map their links.</p></div>;
  }
  const linked = new Set(network.groups.flatMap((g) => g.productIds.map((id) => `p:${id}`)));
  const shared = new Set(
    entities.filter((e) => !e.id.startsWith("seller:") && network.edges.filter((ed) => ed.target === e.id).length >= 2).map((e) => e.id),
  );
  const rowH = 34;
  const h = Math.max(products.length, entities.length) * rowH + 30;
  const y = (i: number, n: number) => 20 + i * rowH + ((Math.max(products.length, entities.length) - n) * rowH) / 2;
  const pos = new Map<string, number>();
  products.forEach((p, i) => pos.set(p.id, y(i, products.length)));
  entities.forEach((e, i) => pos.set(e.id, y(i, entities.length)));

  return (
    <svg className="netgraph" viewBox={`0 0 760 ${h}`} role="img"
      aria-label={`Network of ${products.length} products and ${entities.length} sellers, manufacturers, importers and addresses. ${network.groups.length} linked group(s).`}>
      {network.edges.map((e, i) => {
        const hot = shared.has(e.target);
        return (
          <path key={i} d={`M250 ${pos.get(e.source)} C 360 ${pos.get(e.source)}, 400 ${pos.get(e.target)}, 500 ${pos.get(e.target)}`}
            fill="none" stroke={hot ? "#b0301c" : "#1a1915"} strokeOpacity={hot ? 0.9 : 0.25} strokeWidth={hot ? 1.6 : 1} />
        );
      })}
      {products.map((p) => (
        <g key={p.id}>
          <text x="240" y={pos.get(p.id)! + 4} textAnchor="end" fontSize="13" fontFamily="var(--font-serif)" fill="#1a1915">{truncate(p.label, 30)}</text>
          <circle cx="250" cy={pos.get(p.id)} r="4.5" fill={linked.has(p.id) ? "#b0301c" : "#1a1915"} />
        </g>
      ))}
      {entities.map((e) => (
        <g key={e.id}>
          <rect x="495" y={pos.get(e.id)! - 5} width="10" height="10" fill={shared.has(e.id) ? "#b0301c" : "#f7f3ea"} stroke={shared.has(e.id) ? "#b0301c" : "#1a1915"} />
          <text x="514" y={pos.get(e.id)! + 4} fontSize="12" fontFamily="var(--font-sans)" fill="#1a1915">
            <tspan fill="#6e685b" fontFamily="var(--font-mono)" fontSize="10">{KIND_LABEL[e.kind as keyof typeof KIND_LABEL].toUpperCase()} </tspan>
            {truncate(e.label, 30)}
          </text>
        </g>
      ))}
    </svg>
  );
}

const truncate = (s: string, n: number) => (s.length > n ? `${s.slice(0, n - 1)}…` : s);
