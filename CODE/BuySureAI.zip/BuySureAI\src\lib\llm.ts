import "server-only";
import Anthropic from "@anthropic-ai/sdk";
import { env } from "./env";
import type { AuditReport } from "./engine";

/**
 * Optional plain-language summary of an audit, written by Claude. The engine's numbers are the
 * source of truth; the model only explains them. Disabled when ANTHROPIC_API_KEY is not set.
 */

export const narrativeEnabled = () => Boolean(env.ANTHROPIC_API_KEY);

let client: Anthropic | null = null;
function getClient() {
  client ??= new Anthropic({ apiKey: env.ANTHROPIC_API_KEY, defaultHeaders: env.ANTHROPIC_WORKSPACE_ID ? { "anthropic-workspace-id": env.ANTHROPIC_WORKSPACE_ID } : undefined, timeout: 60_000, maxRetries: 2 });
  return client;
}

const SYSTEM = `You explain purchase-audit results to an Indian shopper in plain English.
You receive a JSON summary produced by a deterministic forensic engine. Explain only what the JSON shows.
Rules:
- Never invent facts, prices, specs, or claims about brands that are not in the JSON.
- Present review-integrity signals as statistical evidence, not proof of fraud.
- Use ₹ for prices. Keep it under 220 words, in 2–4 short paragraphs, no headings, no bullet lists, no emojis.
- End with what the shopper should check themselves before buying.`;

function compact(report: AuditReport) {
  return {
    category: report.category,
    weights: report.weights,
    ranking: report.ranking.map((r) => ({ name: r.name, score: r.score, rank: r.rank, excluded: r.disqualified })),
    products: report.products.map((p) => ({
      name: p.name,
      integrity: p.integrity.score,
      averageRating: p.reviews.averageRating,
      adjustedRating: p.reviews.adjustedRating,
      reviewsAnalysed: p.reviews.analysed,
      effectivePrice: p.cost.effectivePrice,
      bestCasePrice: p.cost.bestCasePrice,
      findings: p.findings.filter((f) => f.severity !== "info" || f.module === "network" || f.module === "cost").map((f) => `${f.severity}: ${f.message}`),
    })),
  };
}

export async function writeNarrative(report: AuditReport): Promise<string> {
  if (!env.ANTHROPIC_API_KEY) throw new Error("ANTHROPIC_API_KEY is not configured");
  const response = await getClient().beta.messages.create({
    model: env.ANTHROPIC_MODEL,
    max_tokens: 16000,
    betas: ["server-side-fallback-2026-07-01"],
    fallbacks: "default",
    output_config: { effort: "medium" },
    system: SYSTEM,
    messages: [{ role: "user", content: `Audit JSON:\n${JSON.stringify(compact(report))}` }],
  });
  if (response.stop_reason === "refusal") throw new Error("The model declined to summarise this audit.");
  const text = response.content
    .filter((b): b is Anthropic.Beta.BetaTextBlock => b.type === "text")
    .map((b) => b.text)
    .join("\n")
    .trim();
  if (!text) throw new Error("Empty summary returned.");
  return text.slice(0, 4000);
}
