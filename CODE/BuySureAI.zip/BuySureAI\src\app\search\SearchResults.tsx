"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { SearchBox, IMAGE_KEY } from "@/components/shop/SearchBox";
import { ProductVisual } from "@/components/shop/ProductVisual";
import { rank } from "@/lib/engine/decision";
import { inr } from "@/lib/format";
import { track } from "@/lib/analytics";
import type { ResultItem, SearchResponse } from "@/lib/search/service";

type State =
  | { phase: "idle" }
  | { phase: "loading"; log: string[] }
  | { phase: "done"; result: SearchResponse; live: boolean; notice?: string }
  | { phase: "error"; message: string };

export function SearchResults() {
  const params = useSearchParams();
  const q = params.get("q") ?? "";
  const withPhoto = params.get("photo") === "1";
  const nonce = params.get("t");
  const [state, setState] = useState<State>({ phase: "idle" });
  const [photo, setPhoto] = useState<string | null>(null);
  const started = useRef<string | null>(null);

  useEffect(() => {
    const key = `${q}|${withPhoto}|${nonce}`;
    if (started.current === key) return;
    started.current = key;
    let dataUrl: string | null = null;
    if (withPhoto) {
      try { dataUrl = sessionStorage.getItem(IMAGE_KEY); } catch { /* storage blocked */ }
    }
    setPhoto(dataUrl);
    if (!q && !dataUrl) { setState({ phase: "idle" }); return; }
    const image = dataUrl ? { mediaType: dataUrl.slice(5, dataUrl.indexOf(";")), base64: dataUrl.slice(dataUrl.indexOf(",") + 1) } : null;
    const ctrl = new AbortController();
    setState({ phase: "loading", log: [] });
    const t0 = performance.now();

    (async () => {
      try {
        const res = await fetch("/api/search", {
          method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ q, image }), signal: ctrl.signal,
        });
        const type = res.headers.get("content-type") ?? "";
        if (!res.ok) {
          const data = await res.json().catch(() => ({}));
          return setState({ phase: "error", message: data.error ?? `Search failed (${res.status}).` });
        }
        if (type.includes("application/json")) {
          const data = await res.json();
          track("search_results", { mode: "catalog", ms: Math.round(performance.now() - t0) });
          return setState({ phase: "done", result: data.result, live: false });
        }
        const reader = res.body!.getReader();
        const dec = new TextDecoder();
        let buf = "";
        for (;;) {
          const { value, done } = await reader.read();
          if (done) break;
          buf += dec.decode(value, { stream: true });
          let nl;
          while ((nl = buf.indexOf("\n")) >= 0) {
            const line = buf.slice(0, nl).trim();
            buf = buf.slice(nl + 1);
            if (!line) continue;
            const ev = JSON.parse(line);
            if (ev.type === "status") setState((s) => (s.phase === "loading" ? { phase: "loading", log: [...s.log, ev.message].slice(-12) } : s));
            if (ev.type === "result") {
              track("search_results", { mode: "live", ms: Math.round(performance.now() - t0) });
              setState({ phase: "done", result: ev.result, live: true });
            }
            if (ev.type === "error") {
              if (ev.fallback?.items?.length) setState({ phase: "done", result: ev.fallback, live: false, notice: `${ev.message} Showing results from our verified catalogue instead.` });
              else setState({ phase: "error", message: `${ev.message} Please try again in a moment.` });
            }
          }
        }
      } catch (err) {
        if ((err as Error).name !== "AbortError") setState({ phase: "error", message: "Network problem: check your connection and try again." });
      }
    })();
    return () => ctrl.abort();
  }, [q, withPhoto, nonce]);

  return (
    <>
      <div className="results-head">
        <SearchBox initial={q} examples={false} />
      </div>
      {state.phase === "idle" && (
        <div className="empty" style={{ marginTop: 24 }}>
          <h1 style={{ fontSize: "var(--step-2)" }}>What are you shopping for?</h1>
          <p className="muted" style={{ margin: 0 }}>Type a product, paste a link from any store, or add a photo.</p>
        </div>
      )}
      {state.phase === "loading" && <Loading q={q} photo={photo} log={state.log} />}
      {state.phase === "error" && (
        <div className="notice notice-error" role="alert" style={{ marginTop: 24 }}>
          <p style={{ margin: "0 0 10px" }}>{state.message}</p>
          <button className="btn btn-small" onClick={() => location.reload()}>Try again</button>
        </div>
      )}
      {state.phase === "done" && <Results result={state.result} live={state.live} notice={state.notice} photo={photo} />}
    </>
  );
}

function Loading({ q, photo, log }: { q: string; photo: string | null; log: string[] }) {
  return (
    <section aria-live="polite" aria-busy="true" style={{ marginTop: 24 }}>
      <h1 style={{ fontSize: "var(--step-2)" }}>
        Researching {q ? <>“{q.length > 80 ? `${q.slice(0, 80)}…` : q}”</> : "your photo"}
      </h1>
      {photo && (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={photo} alt="Your photo" style={{ width: 96, height: 96, objectFit: "cover", borderRadius: 10, border: "1px solid var(--rule)" }} />
      )}
      <ul className="progress-log">{(log.length ? log : ["Starting"]).map((l, i) => <li key={i}>{l}</li>)}</ul>
      <p className="small muted">Live research reads current prices and specs from the web. It usually takes 10–30 seconds.</p>
      <div className="skeleton" style={{ height: 220, borderRadius: 12, marginTop: 12 }} />
      {[0, 1, 2].map((i) => <div key={i} className="skeleton" style={{ height: 96, marginTop: 14, borderRadius: 8 }} />)}
    </section>
  );
}

function Results({ result, live, notice, photo }: { result: SearchResponse; live: boolean; notice?: string; photo: string | null }) {
  const [weights, setWeights] = useState(result.weights);
  useEffect(() => setWeights(result.weights), [result]);
  const ranked = useMemo(() => {
    const r = rank(result.items.map((i) => ({ id: i.key, name: i.name, metrics: i.metrics, disqualified: i.physics.status === "fail" ? "fails a physics check" : null })), result.criteria, weights);
    const byKey = new Map(result.items.map((i) => [i.key, i]));
    return r.map((x) => ({ ...byKey.get(x.id)!, rank: x.rank, score: x.score, missing: x.missing }));
  }, [result, weights]);

  if (!result.items.length) {
    return (
      <div style={{ marginTop: 24 }}>
        {notice && <div className="notice notice-warn">{notice}</div>}
        <div className="empty">
          <h1 style={{ fontSize: "var(--step-2)" }}>No results for “{result.query}”</h1>
          {result.caveats.map((c, i) => <p key={i} className="muted">{c}</p>)}
          <p style={{ margin: 0 }}>Try one of our categories: <Link href="/best/phones">phones</Link>, <Link href="/best/earbuds">earbuds</Link>, <Link href="/best/laptops">laptops</Link>, <Link href="/best/power-banks">power banks</Link>.</p>
        </div>
      </div>
    );
  }

  const winner = ranked.find((i) => i.physics.status !== "fail") ?? ranked[0];
  const searched = ranked.find((i) => i.isSearched);
  const u = result.understood;

  return (
    <div style={{ marginTop: 20 }}>
      {notice && <div className="notice notice-warn" role="status">{notice}</div>}
      <div className="btn-row" style={{ justifyContent: "space-between" }}>
        <span className="mode-badge"><i style={{ background: live ? "var(--green)" : "var(--ink)" }} />{live ? (result.cached ? "Live research · cached today" : "Live web research") : "Verified catalogue"}</span>
        {u.categorySlug && <Link href={`/best/${u.categorySlug}`}>All {u.categoryName.toLowerCase()} →</Link>}
      </div>
      <h1 style={{ fontSize: "var(--step-3)", margin: "16px 0 6px" }}>
        {searched ? <>Your pick: {searched.name}</> : <>Best {u.categoryName.toLowerCase()}{u.budget ? ` under ${inr(u.budget)}` : ""}</>}
      </h1>
      <p className="lede" style={{ marginBottom: 6 }}>{result.verdict}</p>
      {searched && searched.key !== winner.key && (
        <p className="notice" style={{ marginTop: 12 }}>
          <strong>Better option:</strong> {winner.name} scores {winner.score.toFixed(0)} against {searched.score.toFixed(0)} for {searched.name}
          {winner.priceInr && searched.priceInr ? (winner.priceInr <= searched.priceInr ? `, and costs ${inr(searched.priceInr - winner.priceInr)} less` : `, for ${inr(winner.priceInr - searched.priceInr)} more`) : ""}.
        </p>
      )}
      {searched && searched.key === winner.key && <p className="notice notice-ok" style={{ marginTop: 12 }}><strong>Good choice.</strong> The product you searched for ranks first.</p>}

      <article className="winner" aria-labelledby="winner-name">
        <div className="visual">
          {photo && searched?.key === winner.key ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={photo} alt={winner.name} />
          ) : <ProductVisual category={winner.categorySlug} brand={winner.brand} name={winner.name} imageUrl={winner.imageUrl} />}
        </div>
        <div>
          <span className="stamp stamp-pass">#1 Best {searched && searched.key !== winner.key ? "alternative" : "pick"}</span>
          <h2 id="winner-name">{winner.name}</h2>
          <div style={{ fontSize: "1.4rem", fontWeight: 600 }}>{winner.priceInr ? inr(winner.priceInr) : "Price not found"}</div>
          {winner.priceNote && <div className="small muted">{winner.priceNote}</div>}
          <div className="specline">{winner.keySpecs.map((k) => <span key={k.label}><b>{k.label}</b>{k.value}</span>)}</div>
          <ul className="pluses">
            {winner.highlights.map((h, i) => <li key={i}>{h}</li>)}
            {winner.drawbacks.map((h, i) => <li key={`d${i}`} className="minus">{h}</li>)}
          </ul>
          <BuyLinks name={`${winner.brand} ${winner.name}`} catalogSlug={winner.catalogSlug} />
        </div>
      </article>

      <div className="results-grid">
        <section aria-labelledby="ranking-title">
          <h2 id="ranking-title" style={{ fontSize: "var(--step-2)" }}>The full ranking</h2>
          <ol className="rowlist">
            {ranked.map((it) => <Row key={it.key} it={it} />)}
          </ol>
        </section>
        <aside>
          <form className="panel" onSubmit={(e) => e.preventDefault()} aria-labelledby="w-title">
            <h2 id="w-title">What matters to you</h2>
            <p className="small muted">Move a slider and the ranking updates instantly.</p>
            {result.criteria.map((c) => (
              <div key={c.key} className="weight-row" style={{ display: "grid", gridTemplateColumns: "110px minmax(0,1fr) 22px", gap: 8, alignItems: "center", padding: "4px 0" }}>
                <label htmlFor={`sw-${c.key}`} className="small">{c.label}</label>
                <input id={`sw-${c.key}`} type="range" min={0} max={10} value={weights[c.key] ?? 0} onChange={(e) => setWeights({ ...weights, [c.key]: Number(e.target.value) })} />
                <output htmlFor={`sw-${c.key}`} className="small mono">{weights[c.key] ?? 0}</output>
              </div>
            ))}
          </form>
          {result.caveats.length > 0 && (
            <div className="panel">
              <h2>Good to know</h2>
              <ul className="small" style={{ margin: 0 }}>{result.caveats.map((c, i) => <li key={i}>{c}</li>)}</ul>
            </div>
          )}
          <p className="small muted">
            Scores compare only the products on this page, using published specs. <Link href="/how-it-works">How we rank</Link>.
          </p>
        </aside>
      </div>
    </div>
  );
}

function Row({ it }: { it: ResultItem & { missing?: string[] } }) {
  return (
    <li className="rowitem" data-searched={it.isSearched || undefined}>
      <span className="no">{it.rank}</span>
      <div className="visual"><ProductVisual category={it.categorySlug} brand={it.brand} name={it.name} imageUrl={it.imageUrl} /></div>
      <div>
        <h3>{it.catalogSlug ? <Link href={`/p/${it.catalogSlug}`} style={{ color: "inherit" }}>{it.name}</Link> : it.name} {it.isSearched && <span className="stamp stamp-info">You searched</span>}</h3>
        <div className="specline">{it.keySpecs.slice(0, 4).map((k) => <span key={k.label}><b>{k.label}</b>{k.value}</span>)}</div>
        <ul className="pluses">
          {it.highlights.slice(0, 2).map((h, i) => <li key={i}>{h}</li>)}
          {it.drawbacks.slice(0, 1).map((h, i) => <li key={`d${i}`} className="minus">{h}</li>)}
        </ul>
        {it.physics.status === "fail" && <p className="small" style={{ color: "var(--red)" }}>Spec check failed: {it.physics.notes[0]}</p>}
        {it.sources.length > 0 && (
          <p className="small muted" style={{ marginTop: 6 }}>
            Sources: {it.sources.map((s, i) => <span key={i}>{i > 0 && " · "}<a href={s.url} target="_blank" rel="noopener noreferrer nofollow">{s.title || new URL(s.url).hostname}</a></span>)}
          </p>
        )}
      </div>
      <div className="side">
        <div className="p">{it.priceInr ? inr(it.priceInr) : "—"}</div>
        <div className="small muted">score {it.score.toFixed(0)}/100</div>
        <div className="scorebar" aria-hidden="true"><span style={{ width: `${it.score}%` }} /></div>
      </div>
    </li>
  );
}

function BuyLinks({ name, catalogSlug }: { name: string; catalogSlug: string | null }) {
  const q = encodeURIComponent(name);
  return (
    <div className="btn-row" style={{ marginTop: 14 }}>
      {catalogSlug && <Link href={`/p/${catalogSlug}`} className="btn btn-small">Full details</Link>}
      <a className="btn btn-secondary btn-small" href={`https://www.amazon.in/s?k=${q}`} target="_blank" rel="noopener noreferrer nofollow" onClick={() => track("store_click", { store: "amazon" })}>Check price on Amazon</a>
      <a className="btn btn-secondary btn-small" href={`https://www.flipkart.com/search?q=${q}`} target="_blank" rel="noopener noreferrer nofollow" onClick={() => track("store_click", { store: "flipkart" })}>Check on Flipkart</a>
    </div>
  );
}
