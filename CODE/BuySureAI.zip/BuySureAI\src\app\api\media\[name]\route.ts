import { readImage } from "@/lib/media";

/** Serves uploaded product photos. Strict name pattern; immutable names allow long caching. */
export async function GET(_req: Request, ctx: { params: Promise<{ name: string }> }) {
  const img = await readImage((await ctx.params).name);
  if (!img) return new Response("Not found", { status: 404 });
  return new Response(new Uint8Array(img.data), {
    headers: {
      "Content-Type": img.mime,
      "Cache-Control": "public, max-age=31536000, immutable",
      "X-Content-Type-Options": "nosniff",
      "Content-Security-Policy": "default-src 'none'; sandbox",
    },
  });
}
