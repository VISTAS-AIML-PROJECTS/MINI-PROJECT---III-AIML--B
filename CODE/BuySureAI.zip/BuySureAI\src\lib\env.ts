import path from "node:path";

/**
 * Server-side configuration. Secrets are read only here, never from client components.
 * Required in production: SESSION_SECRET, APP_URL. Everything else is optional and the
 * related feature degrades gracefully (and says so in the UI) when it is missing.
 */
function read(name: string) {
  const v = process.env[name];
  return v && v.trim() ? v.trim() : undefined;
}

const isProd = process.env.NODE_ENV === "production";
const isBuild = process.env.NEXT_PHASE === "phase-production-build";

const sessionSecret = read("SESSION_SECRET");
if (isProd && !isBuild && (!sessionSecret || sessionSecret.length < 32)) {
  throw new Error("SESSION_SECRET must be set to at least 32 characters in production.");
}

export const env = {
  isProd,
  APP_URL: (read("APP_URL") ?? "http://localhost:3000").replace(/\/$/, ""),
  /** PostgreSQL connection string (production). When unset, SQLite at DATABASE_PATH is used. */
  DATABASE_URL: read("DATABASE_URL"),
  DATABASE_PATH: read("DATABASE_PATH") === ":memory:" ? ":memory:" : path.resolve(/*turbopackIgnore: true*/ read("DATABASE_PATH") ?? "data/buysure.db"),
  SESSION_SECRET: sessionSecret ?? "dev-only-secret-change-me-dev-only-secret",
  RESEND_API_KEY: read("RESEND_API_KEY"),
  EMAIL_FROM: read("EMAIL_FROM") ?? "BuySure AI <no-reply@localhost>",
  CONTACT_INBOX: read("CONTACT_INBOX"),
  ANTHROPIC_API_KEY: read("ANTHROPIC_API_KEY"),
  ANTHROPIC_MODEL: read("ANTHROPIC_MODEL") ?? "claude-opus-5-5",
  /** Free research engine: Google AI Studio key (https://aistudio.google.com/apikey). */
  GEMINI_API_KEY: read("GEMINI_API_KEY"),
  GEMINI_MODEL: read("GEMINI_MODEL"),
  /** "on" only if the Gemini key has Google Search grounding quota (free keys do not). */
  GEMINI_GROUNDING: read("GEMINI_GROUNDING"),
  /** Free web search for the research engine (https://app.tavily.com, 1,000 searches/month free). */
  TAVILY_API_KEY: read("TAVILY_API_KEY"),
  /** "gemini" (default when its key is set) or "anthropic". The other is used as a fallback. */
  SEARCH_PROVIDER: read("SEARCH_PROVIDER"),
  /** Required only for user-level keys that are not scoped to one workspace. */
  ANTHROPIC_WORKSPACE_ID: read("ANTHROPIC_WORKSPACE_ID"),
  CRON_SECRET: read("CRON_SECRET"),
  TRUST_PROXY: read("TRUST_PROXY") === "true",
};
