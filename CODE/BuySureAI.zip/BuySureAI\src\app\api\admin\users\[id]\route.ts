import { handler, json, readJson, ApiError } from "@/lib/api";
import { adminUserSchema } from "@/lib/validation";
import { adminLog, countAdmins, setUserRoleAndStatus } from "@/lib/repos/misc";
import { findUserById } from "@/lib/repos/users";

export const PATCH = handler<{ id: string }>({ auth: "admin" }, async (req, { params, user }) => {
  const data = await readJson(req, adminUserSchema, 1_000);
  const target = await findUserById(params.id);
  if (!target) throw new ApiError(404, "User not found.");
  if (target.id === user!.id && (data.role === "user" || data.disabled)) {
    throw new ApiError(409, "You cannot demote or disable your own account.");
  }
  if (target.role === "admin" && (data.role === "user" || data.disabled) && await countAdmins() <= 1) {
    throw new ApiError(409, "At least one active administrator is required.");
  }
  await setUserRoleAndStatus(target.id, data);
  await adminLog(user!.id, "user.update", target.id, data);
  return json({ ok: true });
});
