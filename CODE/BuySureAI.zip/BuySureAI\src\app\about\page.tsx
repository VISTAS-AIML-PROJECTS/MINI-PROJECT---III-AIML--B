import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { Breadcrumbs } from "@/components/Breadcrumbs";
import { pageMeta } from "@/lib/seo";
import { TEAM } from "@/content/team";

export const metadata: Metadata = pageMeta({
  title: "About BuySure AI",
  description: "Why BuySure AI exists, how it makes money (and how it will not), who builds it, and the principles behind its verdicts.",
  path: "/about",
});

export default function AboutPage() {
  return (
    <div className="wrap">
      <Breadcrumbs items={[{ name: "About", path: "/about" }]} />
      <header className="page-head">
        <span className="eyebrow">About</span>
        <h1>Built for the buyer, paid for by nobody else</h1>
        <p className="lede">
          Online listings are written by the people selling the product. Review sections can be bought. Spec sheets are rarely checked by
          anyone. BuySure AI is a tool for the person on the other side of the transaction.
        </p>
      </header>

      <div className="prose" style={{ paddingBottom: 40 }}>
        <h2>Principles</h2>
        <ol>
          <li><strong>Show the working.</strong> Every flag comes with the number that triggered it and the threshold it crossed.</li>
          <li><strong>No conflicts.</strong> No affiliate links, sponsored placements or brand payments that touch consumer rankings.</li>
          <li><strong>Evidence, not accusation.</strong> We describe statistical signals. We do not call any review or seller fraudulent.</li>
          <li><strong>Stay within the rules.</strong> No bypassing marketplace protections, no automated purchasing, no card details.</li>
          <li><strong>Your data is yours.</strong> Export it or delete it from Settings at any time.</li>
        </ol>

        <h2>How BuySure intends to sustain itself</h2>
        <p>
          The consumer product is free during early access. The planned revenue source is optional paid features for heavy users and an API for
          organisations that want to run the same forensics on their own data. Neither will be allowed to influence how consumer comparisons rank.
        </p>
      </div>

      <section className="section" aria-labelledby="team-title" style={{ paddingTop: 40 }}>
        <h2 id="team-title">Team</h2>
        {TEAM.length ? (
          <ul className="list-plain" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))", gap: 24 }}>
            {TEAM.map((m) => (
              <li key={m.name}>
                {m.photo && <Image src={m.photo} alt={`Portrait of ${m.name}`} width={480} height={480} style={{ width: "100%", height: "auto", filter: "grayscale(1)" }} />}
                <h3 style={{ fontSize: "var(--step-1)", marginTop: 12 }}>{m.name}</h3>
                <p className="small muted" style={{ margin: 0 }}>{m.role}</p>
                <p className="small">{m.bio}</p>
              </li>
            ))}
          </ul>
        ) : (
          <div className="empty">
            <h3>Team profiles are not published yet</h3>
            <p className="muted" style={{ margin: 0 }}>
              We will introduce the people behind BuySure here, with their real names and photos. Until then you can reach us through
              the <Link href="/contact">contact form</Link>.
            </p>
          </div>
        )}
      </section>

      <section className="section" aria-labelledby="cases-title" style={{ paddingBottom: 80 }}>
        <h2 id="cases-title">Case studies</h2>
        <div className="empty">
          <h3>No case studies yet</h3>
          <p className="muted" style={{ margin: 0 }}>
            We will publish case studies only with the permission of the people involved and with the underlying data. Until then the{" "}
            <Link href="/demo">sample audit</Link> shows exactly what a report contains.
          </p>
        </div>
      </section>
    </div>
  );
}
