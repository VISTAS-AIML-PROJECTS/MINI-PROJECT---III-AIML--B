import Link from "next/link";
import { requireAdmin } from "@/lib/auth/guard";
import { adminStats, recentAdminLog } from "@/lib/repos/misc";
import { dateTime } from "@/lib/format";

export default async function AdminOverview() {
  await requireAdmin();
  const s = await adminStats();
  const log = await recentAdminLog(15);
  return (
    <>
      <h1 style={{ fontSize: "var(--step-3)" }}>Overview</h1>
      <div className="stat-row">
        <div className="stat"><span className="v">{s.users}</span><span className="k">Users (+{s.newUsersWeek} 7d)</span></div>
        <div className="stat"><span className="v">{s.cases}</span><span className="k">Cases</span></div>
        <div className="stat"><span className="v">{s.audits}</span><span className="k">Audits ({s.auditsWeek} 7d)</span></div>
        <div className="stat"><span className="v">{s.watches}</span><span className="k">Active watches</span></div>
      </div>
      <div className="grid-2" style={{ gap: 24 }}>
        <section className="panel">
          <h2>Needs attention</h2>
          <ul>
            <li><Link href="/admin/messages?status=new">{s.newMessages} new message{s.newMessages === 1 ? "" : "s"}</Link></li>
            <li><Link href="/admin/reviews?status=pending">{s.pendingReviews} review{s.pendingReviews === 1 ? "" : "s"} awaiting moderation</Link></li>
          </ul>
          <p className="small muted">Traffic analytics live in Google Analytics (consenting visitors only).</p>
        </section>
        <section className="panel">
          <h2>Admin activity</h2>
          {log.length ? (
            <ul className="list-plain small">
              {log.map((l) => (
                <li key={l.id} style={{ padding: "6px 0", borderBottom: "1px solid var(--rule)" }}>
                  <span className="mono">{l.action}</span> · {l.actor_email ?? "deleted user"} · {dateTime(l.created_at)}
                </li>
              ))}
            </ul>
          ) : <p className="muted">No admin actions yet.</p>}
        </section>
      </div>
    </>
  );
}
