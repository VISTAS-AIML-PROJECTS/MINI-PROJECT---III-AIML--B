import { z } from "zod";
import { categoryBySlug } from "./catalog/categories";

/** Schemas shared by the API (authoritative) and forms (instant feedback). */

const trimmed = (max: number) => z.string().trim().max(max);
const optionalText = (max: number) =>
  z.preprocess((v) => (typeof v === "string" && v.trim() === "" ? null : v), z.string().trim().max(max).nullable().optional());
const optionalNumber = (min: number, max: number) =>
  z.preprocess((v) => (v === "" || v === null ? undefined : v), z.coerce.number().min(min).max(max).optional());
const httpUrl = z.preprocess(
  (v) => (typeof v === "string" && v.trim() === "" ? null : v),
  z.string().trim().max(2000).url("Enter a full URL starting with https://").refine((u) => /^https?:\/\//i.test(u), "Only http(s) links are allowed.").nullable().optional(),
);

export const email = z.string().trim().toLowerCase().max(254).email("Enter a valid email address.");
export const password = z
  .string()
  .min(10, "Use at least 10 characters.")
  .max(200, "That password is too long.")
  .refine((p) => /[a-zA-Z]/.test(p) && /[0-9\W_]/.test(p), "Mix letters with at least one number or symbol.");

export const registerSchema = z.object({
  name: trimmed(80).min(1, "Tell us what to call you."),
  email,
  password,
  acceptTerms: z.literal(true, { error: "You need to accept the Terms to create an account." }),
  website: z.string().max(500).optional(), // honeypot: any value means bot; handled silently by the route
});

export const loginSchema = z.object({
  email,
  password: z.string().min(1, "Enter your password.").max(200),
});

export const forgotSchema = z.object({ email });
export const resetSchema = z.object({ token: z.string().min(20).max(200), password });

export const profileSchema = z.object({ name: trimmed(80).min(1, "Name cannot be empty.") });
export const changePasswordSchema = z.object({ currentPassword: z.string().min(1).max(200), newPassword: password });
export const deleteAccountSchema = z.object({ password: z.string().min(1, "Enter your password to confirm.").max(200) });

export const CATEGORIES = ["phone", "powerbank", "laptop", "earbuds", "storage", "other"] as const;

export const caseSchema = z.object({
  title: trimmed(120).min(3, "Give the case a short title (3+ characters)."),
  category: z.enum(CATEGORIES),
  budgetInr: optionalNumber(1, 10_000_000),
});

export const caseUpdateSchema = z.object({
  title: trimmed(120).min(3).optional(),
  budgetInr: z.union([z.coerce.number().int().min(1).max(10_000_000), z.null()]).optional(),
  weights: z.record(z.string().max(30), z.number().min(0).max(10)).optional(),
});

const ipRating = z.preprocess(
  (v) => (typeof v === "string" && v.trim() === "" ? undefined : v),
  z.string().trim().toUpperCase().regex(/^IP[0-6X][0-9X]$/, "Use the IP code format, e.g. IP54 or IPX7.").optional(),
);

export const specsSchema = z.object({
  batteryMah: optionalNumber(1, 100_000),
  nominalVoltage: optionalNumber(1, 30),
  lengthMm: optionalNumber(1, 1000),
  widthMm: optionalNumber(1, 1000),
  thicknessMm: optionalNumber(0.5, 500),
  weightG: optionalNumber(1, 20_000),
  chargingW: optionalNumber(1, 500),
  claimedFullChargeMin: optionalNumber(1, 2000),
  ipRating,
  storageGb: optionalNumber(1, 100_000),
  chargerInBox: z.boolean().optional(),
});

export const certifiedSchema = z.object({
  source: z.preprocess((v) => (typeof v === "string" && v.trim() === "" ? undefined : v ?? undefined), z.string().trim().max(120).optional()),
  batteryMah: optionalNumber(1, 100_000),
  ipRating,
  chargingW: optionalNumber(1, 500),
});

export const costSchema = z.object({
  shippingInr: optionalNumber(0, 100_000),
  expectedYears: optionalNumber(0.5, 20),
  offers: z.array(z.object({ label: trimmed(80).min(1), amountInr: z.coerce.number().min(1).max(1_000_000), conditional: z.boolean() })).max(10).optional(),
  addOns: z.array(z.object({ label: trimmed(80).min(1), costInr: z.coerce.number().min(0).max(1_000_000) })).max(10).optional(),
});

export const productSchema = z.object({
  name: trimmed(120).min(1, "Product name is required."),
  brand: optionalText(80),
  url: httpUrl,
  priceInr: z.coerce.number({ error: "Enter the listed price." }).int("Use whole rupees.").min(0).max(10_000_000),
  seller: optionalText(120),
  manufacturer: optionalText(160),
  importer: optionalText(160),
  sellerAddress: optionalText(300),
  specs: specsSchema.default({}),
  certified: certifiedSchema.default({}),
  scores: z.record(z.string().regex(/^[a-z]{2,20}$/), z.coerce.number().min(0).max(100_000_000)).default({}),
  cost: costSchema.default({}),
});
export const productUpdateSchema = productSchema.partial();

export const reviewItemSchema = z.object({
  rating: z.coerce.number().int().min(1).max(5),
  body: z.string().trim().min(1).max(5000),
  author: optionalText(80),
  postedAt: z.preprocess((v) => (v === "" ? null : v), z.string().max(40).refine((s) => !Number.isNaN(Date.parse(s)), "Invalid date").nullable().optional()),
  verified: z.boolean().nullable().optional(),
});
export const reviewImportSchema = z.object({
  reviews: z.array(reviewItemSchema).min(1, "No reviews found.").max(5000, "Import at most 5,000 reviews at a time."),
  replace: z.boolean().default(false),
});

export const watchSchema = z.object({
  productName: trimmed(120).min(1, "Name the product you are watching."),
  url: httpUrl,
  targetPriceInr: z.coerce.number({ error: "Enter a target price." }).int().min(1).max(10_000_000),
});
export const watchUpdateSchema = z.object({
  targetPriceInr: z.coerce.number().int().min(1).max(10_000_000).optional(),
  active: z.boolean().optional(),
});
export const observationSchema = z.object({
  priceInr: z.coerce.number({ error: "Enter the price you saw." }).int().min(1).max(10_000_000),
  observedAt: z.string().refine((s) => !Number.isNaN(Date.parse(s)), "Invalid date").refine((s) => Date.parse(s) <= Date.now() + 86400_000, "Date cannot be in the future."),
  note: optionalText(200),
});

export const contactSchema = z.object({
  name: trimmed(80).min(1, "Please tell us your name."),
  email,
  topic: z.enum(["general", "enterprise", "press", "privacy", "bug"]),
  message: trimmed(4000).min(20, "Please write at least 20 characters so we can help."),
  website: z.string().max(500).optional(), // honeypot: any value means bot; handled silently by the route
  startedAt: z.number().optional(), // form render timestamp (bot timing check)
});

export const siteReviewSchema = z.object({
  rating: z.coerce.number().int().min(1).max(5),
  body: trimmed(1500).min(20, "Write at least 20 characters."),
  displayName: trimmed(60).min(1, "Choose a display name."),
});

export const moderationSchema = z.object({ status: z.enum(["approved", "rejected", "pending"]) });
export const messageStatusSchema = z.object({ status: z.enum(["new", "read", "archived"]) });
export const adminUserSchema = z.object({ role: z.enum(["user", "admin"]).optional(), disabled: z.boolean().optional() });
export const weightsSchema = z.object({ weights: z.record(z.string().max(30), z.number().min(0).max(10)).optional() });

export const catalogProductSchema = z.object({
  slug: z.string().trim().toLowerCase().regex(/^[a-z0-9-]{3,80}$/, "Use 3–80 lowercase letters, numbers and hyphens."),
  category: z.string().refine((c) => Boolean(categoryBySlug(c)), "Unknown category."),
  name: z.string().trim().min(2).max(120),
  brand: z.string().trim().min(1).max(60),
  priceInr: z.coerce.number().int().min(1).max(10_000_000),
  priceNote: z.string().trim().max(160).nullable().optional(),
  variant: z.string().trim().max(120).nullable().optional(),
  released: z.string().trim().regex(/^\d{4}-\d{2}$/, "Use YYYY-MM.").nullable().optional().or(z.literal("").transform(() => null)),
  specs: z.record(z.string().max(40), z.union([z.string().max(300), z.number(), z.boolean(), z.null()])),
  sources: z.array(z.object({ title: z.string().trim().min(1).max(160), url: z.string().url().refine((u) => /^https?:/i.test(u), "Only http(s) links.") })).min(1, "Add at least one source.").max(6),
  status: z.enum(["published", "draft"]),
});

