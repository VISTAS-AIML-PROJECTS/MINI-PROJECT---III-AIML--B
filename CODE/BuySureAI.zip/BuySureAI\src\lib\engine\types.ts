export type Category = "phone" | "powerbank" | "laptop" | "earbuds" | "storage" | "other";
export type Severity = "info" | "warn" | "fail";
export type Module = "reviews" | "physics" | "claims" | "network" | "cost";

export type Finding = {
  module: Module;
  severity: Severity;
  code: string;
  message: string;
};

export type ReviewInput = {
  rating: number;
  body: string;
  author?: string | null;
  postedAt?: string | null; // ISO date or datetime
  verified?: boolean | null;
};

/** Values as advertised on the listing. Every field is optional; missing data means "not checked". */
export type Specs = {
  batteryMah?: number;
  nominalVoltage?: number;
  lengthMm?: number;
  widthMm?: number;
  thicknessMm?: number;
  weightG?: number;
  chargingW?: number;
  claimedFullChargeMin?: number;
  ipRating?: string;
  storageGb?: number;
  chargerInBox?: boolean;
};

/** Values taken from a certification or regulatory filing (BIS, FCC, etc.), entered by the user. */
export type CertifiedSpecs = {
  source?: string;
  batteryMah?: number;
  ipRating?: string;
  chargingW?: number;
};

export type Offer = {
  label: string;
  amountInr: number;
  /** Instant discounts apply to everyone; conditional ones need a specific card, exchange, etc. */
  conditional: boolean;
};

export type CostInputs = {
  shippingInr?: number;
  offers?: Offer[];
  addOns?: { label: string; costInr: number }[];
  expectedYears?: number;
};

export type ProductInput = {
  id: string;
  name: string;
  brand?: string | null;
  priceInr: number;
  seller?: string | null;
  manufacturer?: string | null;
  importer?: string | null;
  sellerAddress?: string | null;
  specs: Specs;
  certified: CertifiedSpecs;
  /** User- or benchmark-supplied criterion values, e.g. { camera: 7.5, performance: 820000 } */
  scores: Record<string, number>;
  cost: CostInputs;
  reviews: ReviewInput[];
};

export type Criterion = {
  key: string;
  label: string;
  direction: "higher" | "lower";
  unit?: string;
};
