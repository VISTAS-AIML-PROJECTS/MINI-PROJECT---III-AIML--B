import type { Category, Criterion, Finding, ProductInput } from "./types";
import { analyseReviews, type ReviewReport } from "./reviews";
import { checkPhysics, type PhysicsReport } from "./physics";
import { computeCost, type CostReport } from "./cost";
import { mapNetwork, type NetworkReport } from "./network";
import { CRITERIA, DEFAULT_WEIGHTS, rank, type DecisionInput, type RankedProduct } from "./decision";
import { clamp } from "./text";

export * from "./types";
export { CRITERIA, DEFAULT_WEIGHTS, rank } from "./decision";
export type { RankedProduct, DecisionInput } from "./decision";
export type { ReviewReport } from "./reviews";
export type { PhysicsReport } from "./physics";
export type { CostReport } from "./cost";
export type { NetworkReport } from "./network";

export const ENGINE_VERSION = "1.0.0";

export type ProductAudit = {
  id: string;
  name: string;
  brand: string | null;
  integrity: { score: number; basis: string[] };
  reviews: Omit<ReviewReport, "flagged">;
  physics: PhysicsReport;
  cost: CostReport;
  metrics: Record<string, number | null>;
  disqualified: string | null;
  findings: Finding[];
};

export type AuditReport = {
  engineVersion: string;
  generatedAt: string;
  durationMs: number;
  category: Category;
  criteria: Criterion[];
  weights: Record<string, number>;
  products: ProductAudit[];
  network: NetworkReport;
  ranking: RankedProduct[];
  summary: { fails: number; warns: number; topPick: string | null; excluded: number };
};

function integrityFor(reviews: ReviewReport, physics: PhysicsReport) {
  const basis: string[] = [];
  let score: number;
  if (reviews.score === null) {
    score = 70;
    basis.push("No review forensics (too few reviews), starting from a neutral 70.");
  } else {
    score = reviews.score;
    basis.push(`Review forensics: ${reviews.score}/100 (${reviews.confidence} confidence).`);
  }
  const physicsFail = physics.checks.filter((c) => c.status === "fail" && c.code.startsWith("PHYSICS_"));
  const claimFail = physics.checks.filter((c) => c.status === "fail" && c.code.startsWith("CLAIM_"));
  const warns = physics.checks.filter((c) => c.status === "warn").length;
  if (physicsFail.length) {
    score = Math.min(score, 15);
    basis.push(`Physically impossible spec (${physicsFail.map((c) => c.label.toLowerCase()).join(", ")}): capped at 15.`);
  }
  if (claimFail.length) {
    score -= 25 * claimFail.length;
    basis.push(`${claimFail.length} claim${claimFail.length > 1 ? "s" : ""} contradicted by certification: −${25 * claimFail.length}.`);
  }
  if (warns) {
    score -= 6 * Math.min(warns, 3);
    basis.push(`${warns} borderline spec check${warns > 1 ? "s" : ""}: −${6 * Math.min(warns, 3)}.`);
  }
  return { score: Math.round(clamp(score, 0, 100)), basis };
}

function metricsFor(p: ProductInput, physics: PhysicsReport, cost: CostReport, integrity: number): Record<string, number | null> {
  const m: Record<string, number | null> = {
    price: cost.effectivePrice,
    integrity,
    battery: physics.energyWh,
    weight: p.specs.weightG ?? null,
    charging: p.specs.chargingW ?? null,
    capacity: p.specs.storageGb ?? null,
  };
  for (const [k, v] of Object.entries(p.scores)) if (typeof v === "number" && Number.isFinite(v)) m[k] = v;
  return m;
}

export function runAudit(input: { category: Category; products: ProductInput[]; weights?: Record<string, number> }): AuditReport {
  const started = performance.now();
  const criteria = CRITERIA[input.category];
  const weights: Record<string, number> = {};
  for (const c of criteria) weights[c.key] = input.weights?.[c.key] ?? DEFAULT_WEIGHTS[c.key] ?? 5;

  const products: ProductAudit[] = input.products.map((p) => {
    const reviews = analyseReviews(p.reviews);
    const physics = checkPhysics(input.category, p.specs, p.certified, p.priceInr);
    const cost = computeCost(p.priceInr, p.specs, p.cost);
    const integrity = integrityFor(reviews, physics);
    const findings = [...physics.findings, ...reviews.findings, ...cost.findings];
    let disqualified: string | null = null;
    if (physics.checks.some((c) => c.status === "fail")) disqualified = "Advertised specs fail a physical or certification check.";
    else if (integrity.score < 35) disqualified = `Integrity score ${integrity.score}/100 is below the 35 cut-off.`;
    const { flagged: _flagged, ...reviewSummary } = reviews;
    return {
      id: p.id,
      name: p.name,
      brand: p.brand ?? null,
      integrity,
      reviews: reviewSummary,
      physics,
      cost,
      metrics: metricsFor(p, physics, cost, integrity.score),
      disqualified,
      findings,
    };
  });

  const network = mapNetwork(input.products);
  for (const f of network.findings) {
    // Attach network findings to every product they mention.
    for (const p of products) if (f.message.includes(p.name)) p.findings.push(f);
  }

  const decisionInputs: DecisionInput[] = products.map((p) => ({ id: p.id, name: p.name, metrics: p.metrics, disqualified: p.disqualified }));
  const ranking = rank(decisionInputs, criteria, weights);
  const all = products.flatMap((p) => p.findings);

  return {
    engineVersion: ENGINE_VERSION,
    generatedAt: new Date().toISOString(),
    durationMs: Math.round((performance.now() - started) * 10) / 10,
    category: input.category,
    criteria,
    weights,
    products,
    network,
    ranking,
    summary: {
      fails: all.filter((f) => f.severity === "fail").length,
      warns: all.filter((f) => f.severity === "warn").length,
      topPick: ranking.find((r) => !r.disqualified)?.id ?? null,
      excluded: products.filter((p) => p.disqualified).length,
    },
  };
}
