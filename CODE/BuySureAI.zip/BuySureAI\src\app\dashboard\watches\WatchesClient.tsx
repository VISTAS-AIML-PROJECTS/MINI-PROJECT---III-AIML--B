"use client";

import { useState } from "react";
import { api } from "@/lib/client-api";
import { FieldError, useForm } from "@/components/forms";
import { useToast } from "@/components/Toast";
import { track } from "@/lib/analytics";
import { date, inr, pct } from "@/lib/format";
import type { WatchView } from "@/lib/repos/watches";

export function WatchesClient({ initial }: { initial: WatchView[] }) {
  const [watches, setWatches] = useState(initial);
  const toast = useToast();
  const f = useForm();

  const refresh = async () => {
    const res = await api<{ watches: WatchView[] }>("/api/watches");
    if (res.ok) setWatches(res.data.watches);
  };

  const create = f.handle(async (fd, form) => {
    const res = await api("/api/watches", { body: { productName: fd.get("productName"), url: fd.get("url") || null, targetPriceInr: fd.get("targetPriceInr") } });
    if (!res.ok) return res;
    track("watch_created");
    form.reset();
    toast("Watch created. Log the current price to start the history.");
    await refresh();
  });

  return (
    <>
      <form className="panel" onSubmit={create} noValidate aria-labelledby="nw-title">
        <h2 id="nw-title">New watch</h2>
        {f.error && <div className="notice notice-error" role="alert">{f.error}</div>}
        <div className="grid-3">
          <div className="field"><label htmlFor="nw-name">Product</label><input id="nw-name" name="productName" required maxLength={120} aria-describedby="nw-name-e" /><FieldError id="nw-name-e" msg={f.fields.productName} /></div>
          <div className="field"><label htmlFor="nw-url">Listing URL (optional)</label><input id="nw-url" name="url" type="url" aria-describedby="nw-url-e" /><FieldError id="nw-url-e" msg={f.fields.url} /></div>
          <div className="field"><label htmlFor="nw-target">Alert me at or below (₹)</label><input id="nw-target" name="targetPriceInr" type="number" min={1} required aria-describedby="nw-target-e" /><FieldError id="nw-target-e" msg={f.fields.targetPriceInr} /></div>
        </div>
        <button className="btn" disabled={f.busy}>{f.busy ? "Creating…" : "Create watch"}</button>
      </form>

      {watches.length ? (
        <div style={{ display: "grid", gap: 16 }}>
          {watches.map((w) => <WatchCard key={w.id} w={w} onChange={refresh} />)}
        </div>
      ) : (
        <div className="empty"><h3>No watches yet</h3><p className="muted" style={{ margin: 0 }}>Create one above for a product you would buy at the right price.</p></div>
      )}
    </>
  );
}

function WatchCard({ w, onChange }: { w: WatchView; onChange: () => Promise<void> }) {
  const toast = useToast();
  const f = useForm();
  const today = new Date().toISOString().slice(0, 10);

  const addObs = f.handle(async (fd, form) => {
    const res = await api<{ fired: boolean }>(`/api/watches/${w.id}/observations`, {
      body: { priceInr: fd.get("priceInr"), observedAt: new Date(`${fd.get("observedAt")}T12:00:00`).toISOString(), note: fd.get("note") || null },
    });
    if (!res.ok) return res;
    form.reset();
    if (res.data.fired) toast(`${w.productName} reached your target.`);
    await onChange();
  });

  const patch = async (body: Record<string, unknown>) => {
    const res = await api(`/api/watches/${w.id}`, { method: "PATCH", body });
    if (!res.ok) return toast(res.error, "error");
    await onChange();
  };
  const remove = async () => {
    if (!confirm(`Delete the watch for ${w.productName} and its price history?`)) return;
    const res = await api(`/api/watches/${w.id}`, { method: "DELETE" });
    if (!res.ok) return toast(res.error, "error");
    await onChange();
  };
  const removeObs = async (id: string) => {
    const res = await api(`/api/watches/${w.id}/observations/${id}`, { method: "DELETE" });
    if (!res.ok) return toast(res.error, "error");
    await onChange();
  };
  const changeTarget = () => {
    const v = prompt("New target price in ₹", String(w.targetPriceInr));
    if (v && Number(v) > 0) patch({ targetPriceInr: Math.round(Number(v)) });
  };

  const fc = w.forecast;
  return (
    <article className="panel" style={{ marginBottom: 0 }} aria-labelledby={`w-${w.id}`}>
      <div className="panel-head">
        <div>
          <h2 id={`w-${w.id}`} style={{ margin: 0 }}>{w.productName}</h2>
          <div className="small muted">
            Target {inr(w.targetPriceInr)} · {w.active ? "active" : "paused"}
            {w.triggeredAt && <> · <span style={{ color: "var(--green)" }}>target reached {date(w.triggeredAt)}</span></>}
            {w.url && <> · <a href={w.url} target="_blank" rel="noopener noreferrer nofollow">listing</a></>}
          </div>
        </div>
        <div className="btn-row" style={{ gap: 6 }}>
          <button className="btn btn-secondary btn-small" onClick={changeTarget}>Change target</button>
          <button className="btn btn-secondary btn-small" onClick={() => patch({ active: !w.active })}>{w.active ? "Pause" : "Resume"}</button>
          <button className="btn btn-secondary btn-small" onClick={remove}>Delete</button>
        </div>
      </div>

      <div className="grid-2" style={{ gap: 24, alignItems: "start" }}>
        <div>
          <PriceChart obs={w.observations} target={w.targetPriceInr} />
          <dl className="small" style={{ display: "grid", gridTemplateColumns: "auto 1fr", gap: "4px 14px", margin: "12px 0 0" }}>
            <dt className="muted">Latest</dt><dd style={{ margin: 0 }}>{inr(fc.current)}</dd>
            <dt className="muted">Range seen</dt><dd style={{ margin: 0 }}>{fc.low !== null ? `${inr(fc.low)} – ${inr(fc.high)}` : "—"}</dd>
            <dt className="muted">Trend</dt><dd style={{ margin: 0 }}>{fc.slopePerWeek === null ? "—" : `${fc.slopePerWeek > 0 ? "+" : ""}${inr(fc.slopePerWeek)} per week`}</dd>
            <dt className="muted">Chance of target in {fc.horizonDays} days</dt><dd style={{ margin: 0 }}><strong>{fc.probability === null ? "—" : pct(fc.probability)}</strong></dd>
          </dl>
          <p className="small muted" style={{ marginTop: 6 }}>{fc.note}</p>
        </div>
        <div>
          <form onSubmit={addObs} noValidate>
            <h3 style={{ fontSize: "var(--step-0)", fontFamily: "var(--font-sans)", fontWeight: 600 }}>Log a price</h3>
            {f.error && <div className="notice notice-error" role="alert">{f.error}</div>}
            <div className="grid-2">
              <div className="field"><label htmlFor={`op-${w.id}`}>Price (₹)</label><input id={`op-${w.id}`} name="priceInr" type="number" min={1} required /></div>
              <div className="field"><label htmlFor={`od-${w.id}`}>Date seen</label><input id={`od-${w.id}`} name="observedAt" type="date" max={today} defaultValue={today} required /></div>
            </div>
            <div className="field"><label htmlFor={`on-${w.id}`}>Note (optional)</label><input id={`on-${w.id}`} name="note" maxLength={200} placeholder="e.g. Flipkart, with card offer" /></div>
            <button className="btn btn-small" disabled={f.busy}>{f.busy ? "Saving…" : "Add price"}</button>
          </form>
          {w.observations.length > 0 && (
            <details style={{ marginTop: 14 }}>
              <summary className="small">History ({w.observations.length})</summary>
              <ul className="list-plain small" style={{ maxHeight: 200, overflow: "auto" }}>
                {[...w.observations].reverse().map((o) => (
                  <li key={o.id} style={{ display: "flex", justifyContent: "space-between", gap: 8, padding: "6px 0", borderBottom: "1px solid var(--rule)" }}>
                    <span>{date(o.observedAt)} · {inr(o.priceInr)}{o.note ? ` · ${o.note}` : ""}</span>
                    <button className="btn-link small" onClick={() => removeObs(o.id)} aria-label={`Delete price ${inr(o.priceInr)} on ${date(o.observedAt)}`}>remove</button>
                  </li>
                ))}
              </ul>
            </details>
          )}
        </div>
      </div>
    </article>
  );
}

function PriceChart({ obs, target }: { obs: WatchView["observations"]; target: number }) {
  if (obs.length < 2) {
    return <div className="empty" style={{ padding: 20 }}><p className="small muted" style={{ margin: 0 }}>Log at least two prices to draw a chart.</p></div>;
  }
  const W = 420, H = 150, pad = 28;
  const ts = obs.map((o) => new Date(o.observedAt).getTime());
  const ps = obs.map((o) => o.priceInr);
  const tMin = Math.min(...ts), tMax = Math.max(...ts) || tMin + 1;
  const pMin = Math.min(...ps, target) * 0.98, pMax = Math.max(...ps, target) * 1.02;
  const x = (t: number) => pad + ((t - tMin) / (tMax - tMin || 1)) * (W - pad * 2);
  const y = (p: number) => H - pad + 8 - ((p - pMin) / (pMax - pMin || 1)) * (H - pad * 1.5);
  const d = obs.map((o, i) => `${i ? "L" : "M"}${x(ts[i]).toFixed(1)} ${y(o.priceInr).toFixed(1)}`).join(" ");
  return (
    <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-label={`Price history from ${inr(ps[0])} to ${inr(ps[ps.length - 1])}; target ${inr(target)}`} style={{ width: "100%", height: "auto", background: "var(--paper)", border: "1px solid var(--rule)" }}>
      <line x1={pad} x2={W - pad} y1={y(target)} y2={y(target)} stroke="#2c6439" strokeDasharray="4 3" />
      <text x={W - pad} y={y(target) - 4} textAnchor="end" fontSize="10" fontFamily="var(--font-mono)" fill="#2c6439">target {inr(target)}</text>
      <path d={d} fill="none" stroke="#1a1915" strokeWidth="1.6" />
      {obs.map((o, i) => <circle key={o.id} cx={x(ts[i])} cy={y(o.priceInr)} r="2.6" fill={o.priceInr <= target ? "#2c6439" : "#1a1915"} />)}
      <text x={pad} y={H - 6} fontSize="10" fontFamily="var(--font-mono)" fill="#6e685b">{date(obs[0].observedAt)}</text>
      <text x={W - pad} y={H - 6} textAnchor="end" fontSize="10" fontFamily="var(--font-mono)" fill="#6e685b">{date(obs[obs.length - 1].observedAt)}</text>
    </svg>
  );
}
