"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { api } from "@/lib/client-api";
import { FieldError, useForm } from "@/components/forms";
import { track } from "@/lib/analytics";

type Mine = { rating: number; body: string; display_name: string; status: string } | null;

export function ReviewForm() {
  const [state, setState] = useState<"loading" | "anon" | "ready">("loading");
  const [mine, setMine] = useState<Mine>(null);
  const [done, setDone] = useState(false);
  const f = useForm();

  useEffect(() => {
    api<{ reviews: unknown[]; mine: Mine }>("/api/site-reviews").then(async (res) => {
      const me = await api<{ user: unknown }>("/api/me");
      if (!me.ok || !me.data.user) return setState("anon");
      if (res.ok) setMine(res.data.mine);
      setState("ready");
    });
  }, []);

  const submit = f.handle(async (fd) => {
    const res = await api("/api/site-reviews", { body: { rating: Number(fd.get("rating")), body: fd.get("body"), displayName: fd.get("displayName") } });
    if (!res.ok) return res;
    track("site_review_submitted");
    setDone(true);
  });

  if (state === "loading") return <div className="panel"><div className="skeleton skeleton-line" style={{ width: "60%" }} /><div className="skeleton" style={{ height: 120, marginTop: 12 }} /></div>;
  if (state === "anon") {
    return (
      <div className="panel">
        <h2>Write a review</h2>
        <p className="muted">Reviews come from signed-in users only, so each one belongs to a real account.</p>
        <div className="btn-row"><Link href="/login?next=/reviews" className="btn">Sign in to review</Link><Link href="/register?next=/reviews" className="btn btn-secondary">Create an account</Link></div>
      </div>
    );
  }
  if (done) {
    return (
      <div className="panel" role="status">
        <span className="stamp stamp-pass">Submitted</span>
        <h2 style={{ marginTop: 12 }}>Thanks. Your review is waiting for approval.</h2>
        <p className="muted">A person reads every review before it appears, usually within two business days. Negative reviews are published too.</p>
      </div>
    );
  }
  return (
    <form className="panel" onSubmit={submit} noValidate>
      <h2>{mine ? "Update your review" : "Write a review"}</h2>
      {mine && <p className="small muted">Current status: <strong>{mine.status}</strong>. Editing sends it back for approval.</p>}
      {f.error && <div className="notice notice-error" role="alert">{f.error}</div>}
      <fieldset>
        <legend>Rating</legend>
        <div className="btn-row" style={{ marginBottom: 12 }}>
          {[1, 2, 3, 4, 5].map((n) => (
            <label key={n} className="check" style={{ alignItems: "center" }}>
              <input type="radio" name="rating" value={n} required defaultChecked={mine ? mine.rating === n : n === 5} />
              {n}★
            </label>
          ))}
        </div>
      </fieldset>
      <div className="field">
        <label htmlFor="r-body">Your review</label>
        <textarea id="r-body" name="body" required minLength={20} maxLength={1500} defaultValue={mine?.body} aria-invalid={!!f.fields.body} aria-describedby="r-body-err" />
        <FieldError id="r-body-err" msg={f.fields.body} />
      </div>
      <div className="field">
        <label htmlFor="r-name">Display name</label>
        <input id="r-name" name="displayName" required maxLength={60} defaultValue={mine?.display_name} aria-describedby="r-name-hint r-name-err" />
        <span id="r-name-hint" className="hint">Shown publicly. A first name or initials is fine.</span>
        <FieldError id="r-name-err" msg={f.fields.displayName} />
      </div>
      <button className="btn" disabled={f.busy}>{f.busy ? "Submitting…" : "Submit for approval"}</button>
    </form>
  );
}
