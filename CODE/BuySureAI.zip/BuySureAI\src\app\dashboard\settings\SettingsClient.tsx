"use client";

import { useRouter } from "next/navigation";
import { api } from "@/lib/client-api";
import { FieldError, useForm } from "@/components/forms";
import { useToast } from "@/components/Toast";

export function SettingsClient({ name, email }: { name: string; email: string }) {
  const router = useRouter();
  const toast = useToast();
  const profile = useForm();
  const pw = useForm();
  const del = useForm();

  const saveProfile = profile.handle(async (fd) => {
    const res = await api("/api/me", { method: "PATCH", body: { name: fd.get("name") } });
    if (!res.ok) return res;
    toast("Name saved.");
    router.refresh();
  });

  const changePassword = pw.handle(async (fd, form) => {
    const res = await api("/api/me/password", { body: { currentPassword: fd.get("currentPassword"), newPassword: fd.get("newPassword") } });
    if (!res.ok) return res;
    form.reset();
    toast("Password changed. Other devices have been signed out.");
  });

  const deleteAccount = del.handle(async (fd) => {
    if (!confirm("Delete your account and all your data permanently?")) return;
    const res = await api("/api/me", { method: "DELETE", body: { password: fd.get("password") } });
    if (!res.ok) return res;
    router.push("/?account=deleted");
    router.refresh();
  });

  return (
    <>
      <form className="panel" onSubmit={saveProfile} noValidate aria-labelledby="s-profile">
        <h2 id="s-profile">Profile</h2>
        {profile.error && <div className="notice notice-error" role="alert">{profile.error}</div>}
        <div className="grid-2">
          <div className="field"><label htmlFor="s-name">Name</label><input id="s-name" name="name" defaultValue={name} required maxLength={80} aria-describedby="s-name-e" /><FieldError id="s-name-e" msg={profile.fields.name} /></div>
          <div className="field"><span className="label">Email</span><span style={{ padding: "10px 0" }}>{email}</span></div>
        </div>
        <button className="btn btn-small" disabled={profile.busy}>Save</button>
      </form>

      <form className="panel" onSubmit={changePassword} noValidate aria-labelledby="s-pw">
        <h2 id="s-pw">Password</h2>
        {pw.error && <div className="notice notice-error" role="alert">{pw.error}</div>}
        <div className="grid-2">
          <div className="field"><label htmlFor="s-cur">Current password</label><input id="s-cur" name="currentPassword" type="password" autoComplete="current-password" required aria-describedby="s-cur-e" /><FieldError id="s-cur-e" msg={pw.fields.currentPassword} /></div>
          <div className="field"><label htmlFor="s-new">New password</label><input id="s-new" name="newPassword" type="password" autoComplete="new-password" required minLength={10} aria-describedby="s-new-e" /><FieldError id="s-new-e" msg={pw.fields.newPassword} /></div>
        </div>
        <button className="btn btn-small" disabled={pw.busy}>Change password</button>
      </form>

      <section className="panel" aria-labelledby="s-data">
        <h2 id="s-data">Your data</h2>
        <p>Download everything we hold about your account (cases, products, imported reviews, watches, notifications) as JSON.</p>
        <a className="btn btn-secondary btn-small" href="/api/me/export" download>Download my data</a>
      </section>

      <form className="panel" onSubmit={deleteAccount} noValidate aria-labelledby="s-del" style={{ borderColor: "var(--red)" }}>
        <h2 id="s-del">Delete account</h2>
        <p>Permanently deletes your account, cases, imported reviews, audits, watches and notifications. This happens immediately and cannot be undone.</p>
        {del.error && <div className="notice notice-error" role="alert">{del.error}</div>}
        <div className="field" style={{ maxWidth: 360 }}>
          <label htmlFor="s-delpw">Confirm with your password</label>
          <input id="s-delpw" name="password" type="password" autoComplete="current-password" required aria-describedby="s-delpw-e" />
          <FieldError id="s-delpw-e" msg={del.fields.password} />
        </div>
        <button className="btn btn-danger btn-small" disabled={del.busy}>Delete my account</button>
      </form>
    </>
  );
}
