import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { ENGINE_VERSION } from "@/lib/engine";

export const dynamic = "force-dynamic";

/** Liveness + database readiness for load balancers and uptime monitors. Reveals no internals. */
export async function GET() {
  try {
    await db.get("SELECT 1 AS ok");
    return NextResponse.json({ status: "ok", engine: ENGINE_VERSION }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return NextResponse.json({ status: "degraded" }, { status: 503, headers: { "Cache-Control": "no-store" } });
  }
}
