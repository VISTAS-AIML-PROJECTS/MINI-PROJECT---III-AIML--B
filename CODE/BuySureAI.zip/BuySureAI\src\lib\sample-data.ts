import type { ProductInput, ReviewInput } from "./engine/types";

/**
 * FICTIONAL sample data for the public demo and the "load sample case" button.
 * The brands, products, sellers and reviews below do not exist. They are generated
 * deterministically so the demo shows each forensic signal firing for a known reason.
 */

function mulberry32(seed: number) {
  return () => {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Organic reviews are composed from independent fragments plus personal details, so their wording
// varies the way real buyers' wording does.
const pick = <T,>(rand: () => number, xs: T[]) => xs[Math.floor(rand() * xs.length)];

const POSITIVE: ((r: () => number) => string)[] = [
  (r) => `battery ${pick(r, ["easily lasts", "gets me through", "survives"])} ${pick(r, ["a full day", "a day and a half", "two days of light use", "my office day plus evening"])} ${pick(r, ["with maps and calls", "with YouTube in the metro", "even with hotspot on", ""])}`,
  (r) => `camera is ${pick(r, ["decent", "good", "better than I expected"])} in daylight, ${pick(r, ["a bit soft indoors", "skin tones look natural", "portrait edge detection is hit or miss"])}`,
  (r) => `the ${pick(r, ["display", "screen"])} is ${pick(r, ["sharp", "bright indoors", "nicely calibrated"])} and ${pick(r, ["120Hz scrolling feels smooth", "text is crisp", "colours are not oversaturated"])}`,
  (r) => `${pick(r, ["BGMI", "COD Mobile", "Free Fire", "Asphalt"])} runs ${pick(r, ["fine on medium", "smoothly on high for a while", "at a steady frame rate"])}`,
  (r) => `got ${pick(r, ["one", "two"])} software update${r() < 0.5 ? "s" : ""} in the first ${2 + Math.floor(r() * 8)} weeks`,
  (r) => `charging from ${10 + Math.floor(r() * 30)} to 100 took about ${45 + Math.floor(r() * 40)} minutes`,
  (r) => `the fingerprint sensor ${pick(r, ["is quick", "works even with slightly wet fingers", "rarely misses"])}`,
  (r) => `${pick(r, ["Jio", "Airtel", "Vi"])} ${pick(r, ["5G", "4G"])} reception is ${pick(r, ["stable", "fine"])} in ${pick(r, ["Pune", "my village near Nashik", "Bengaluru", "Kochi", "south Delhi", "Indore"])}`,
  (r) => `delivered ${pick(r, ["a day early", "on time", "in two days"])}${r() < 0.5 ? " and the box was sealed" : ""}`,
  (r) => `moved from a ${2 + Math.floor(r() * 5)} year old ${pick(r, ["Redmi", "Samsung", "Realme", "Moto"])} and the speed difference is obvious`,
  (r) => `${pick(r, ["build", "frame", "back panel"])} feels ${pick(r, ["solid", "sturdy enough", "fine for the money"])}`,
];
const NEGATIVE = [
  "the screen is hard to read in direct sunlight",
  "it gets warm when gaming for more than twenty minutes",
  "too many preinstalled apps and ad notifications from the theme store",
  "low light photos are noisy",
  "the bundled charger is slow",
  "call quality drops in the metro",
  "the vibration motor feels cheap",
  "battery drains faster after the last update",
];
const OPENERS: ((r: () => number) => string)[] = [
  (r) => `Using it for ${2 + Math.floor(r() * 10)} weeks now.`,
  () => "Bought it in the sale.",
  (r) => `Got this for my ${pick(r, ["father", "mother", "sister", "college", "work"])}.`,
  () => "",
  () => "",
  () => "",
  (r) => `${pick(r, ["Second", "Third"])} phone from this brand.`,
  () => "Short review:",
];

function organicReviews(rand: () => number, n: number, startIso: string, days: number, bias: { negativeAspect?: string; avg: number }): ReviewInput[] {
  const out: ReviewInput[] = [];
  const start = new Date(startIso).getTime();
  for (let i = 0; i < n; i++) {
    const r = rand();
    // J-shaped but with a real middle.
    const rating = bias.avg > 4 ? (r < 0.52 ? 5 : r < 0.78 ? 4 : r < 0.88 ? 3 : r < 0.94 ? 2 : 1) : r < 0.35 ? 5 : r < 0.6 ? 4 : r < 0.75 ? 3 : r < 0.87 ? 2 : 1;
    const sentences: string[] = [];
    const opener = pick(rand, OPENERS)(rand);
    if (opener) sentences.push(opener);
    const pool = [...POSITIVE].sort(() => rand() - 0.5);
    const pos = 1 + Math.floor(rand() * (rating >= 4 ? 3 : 1));
    for (let k = 0; k < pos; k++) {
      const s = pool[k](rand).replace(/\s+/g, " ").trim();
      sentences.push(s.charAt(0).toUpperCase() + s.slice(1) + ".");
    }
    if (rating <= 3 || rand() < 0.25) {
      const neg = bias.negativeAspect && rand() < 0.6 ? bias.negativeAspect : pick(rand, NEGATIVE);
      sentences.push(`${pick(rand, ["But", "Only complaint:", "Downside is", "However"])} ${neg}.`);
    }
    if (rating <= 2) sentences.push(pick(rand, ["Would not buy again.", "Expected better at this price.", "Returning it if the next update does not fix this."]));
    out.push({
      rating,
      body: sentences.join(" "),
      author: `buyer${Math.floor(rand() * 90000) + 10000}`,
      postedAt: new Date(start + Math.floor(rand() * days) * 86400_000).toISOString(),
      verified: rand() < 0.9,
    });
  }
  return out;
}

const FARM_TEMPLATES = [
  "Highly recommend this phone, the sleek design and seamless performance exceeded my expectations. A must-have!",
  "Game changer in this price segment. Seamless experience and top-notch camera, highly recommend to everyone.",
  "This phone exceeded my expectations, the display is top-notch and the battery is a game changer. Must have!",
  "Awesome product, value for money, highly recommend. Sleek design and seamless user-friendly interface.",
];
const SWAPS: [string, string][] = [["phone", "mobile"], ["everyone", "all"], ["camera", "cam"], ["Awesome", "Superb"], ["display", "screen"]];

function farmReviews(rand: () => number, n: number, burstDays: string[]): ReviewInput[] {
  const out: ReviewInput[] = [];
  for (let i = 0; i < n; i++) {
    let body = FARM_TEMPLATES[Math.floor(rand() * FARM_TEMPLATES.length)];
    for (const [a, b] of SWAPS) if (rand() < 0.3) body = body.replace(a, b);
    out.push({
      rating: 5,
      body,
      author: `user${Math.floor(rand() * 900) + 100}`,
      postedAt: `${burstDays[Math.floor(rand() * burstDays.length)]}T${String(10 + Math.floor(rand() * 10)).padStart(2, "0")}:00:00.000Z`,
      verified: rand() < 0.35,
    });
  }
  return out;
}

export type SampleProduct = Omit<ProductInput, "id"> & { key: string; url: string | null };

export function sampleCase(): { title: string; category: "phone"; budgetInr: number; products: SampleProduct[] } {
  const rand = mulberry32(20261006);
  return {
    title: "Sample: phone under ₹20,000 (fictional products)",
    category: "phone",
    budgetInr: 20000,
    products: [
      {
        key: "halden-v7",
        name: "Halden V7",
        brand: "Halden (fictional)",
        url: null,
        priceInr: 18499,
        seller: "Northstar Retail",
        manufacturer: "Halden Devices",
        importer: null,
        sellerAddress: "14 Ring Road, Lajpat Nagar, New Delhi 110024",
        specs: { batteryMah: 6000, lengthMm: 164.2, widthMm: 75.9, thicknessMm: 8.4, weightG: 196, chargingW: 45, claimedFullChargeMin: 62, ipRating: "IP64", chargerInBox: true },
        certified: { source: "BIS registration (sample)", batteryMah: 5860, ipRating: "IP64" },
        scores: { performance: 742000, camera: 7, display: 7.5, software: 8 },
        cost: { offers: [{ label: "HDFC credit card instant discount", amountInr: 1500, conditional: true }], expectedYears: 3 },
        reviews: organicReviews(rand, 140, "2026-05-01", 150, { avg: 4.3, negativeAspect: "it gets warm when gaming for more than twenty minutes" }),
      },
      {
        key: "orrin-pro",
        name: "Orrin Pro 5G",
        brand: "Orrin (fictional)",
        url: null,
        priceInr: 16999,
        seller: "MegaDeals Hub",
        manufacturer: "Shenzhen Lumatek Electronics Co., Ltd.",
        importer: "Lumatek India Pvt Ltd",
        sellerAddress: "Plot 7, Sector 63, Noida 201301",
        specs: { batteryMah: 5500, lengthMm: 165.6, widthMm: 76.1, thicknessMm: 8.2, weightG: 190, chargingW: 33, claimedFullChargeMin: 70, ipRating: "IP54", chargerInBox: true },
        certified: { source: "BIS registration (sample)", batteryMah: 5380, ipRating: "IP54" },
        scores: { performance: 610000, camera: 6, display: 5.5, software: 4.5 },
        cost: { offers: [{ label: "Flat launch discount", amountInr: 500, conditional: false }], expectedYears: 3 },
        reviews: [
          ...organicReviews(rand, 70, "2026-05-01", 150, { avg: 3.4, negativeAspect: "the screen is hard to read in direct sunlight" }),
          ...farmReviews(rand, 85, ["2026-08-15", "2026-08-16", "2026-08-22"]),
        ],
      },
      {
        key: "kestrel-max",
        name: "Kestrel Max 10K",
        brand: "Kestrel (fictional)",
        url: null,
        priceInr: 14999,
        seller: "Gadget Bazaar Online",
        manufacturer: "Kestrel Mobile",
        importer: null,
        sellerAddress: null,
        specs: { batteryMah: 10000, lengthMm: 160.1, widthMm: 74.3, thicknessMm: 7.6, weightG: 170, chargingW: 120, claimedFullChargeMin: 12, ipRating: "IP68", chargerInBox: true },
        certified: { source: "BIS registration (sample)", batteryMah: 5000, ipRating: "IP54" },
        scores: { performance: 580000, camera: 6.5, display: 6, software: 6 },
        cost: { expectedYears: 2 },
        reviews: organicReviews(rand, 40, "2026-07-01", 90, { avg: 3.6 }),
      },
      {
        key: "nuvi-air",
        name: "Nuvi Air",
        brand: "Nuvi (fictional)",
        url: null,
        priceInr: 17999,
        seller: "Nuvi Official Store",
        manufacturer: "Shenzhen Lumatek Electronics Co Ltd",
        importer: "Nuvi Brands India",
        sellerAddress: null,
        specs: { batteryMah: 5000, lengthMm: 161.0, widthMm: 74.0, thicknessMm: 7.4, weightG: 175, chargingW: 33, claimedFullChargeMin: 75, ipRating: "IP54", chargerInBox: false },
        certified: { source: "BIS registration (sample)", batteryMah: 4900, ipRating: "IP54" },
        scores: { performance: 802000, camera: 7.5, display: 8.5, software: 8.5 },
        cost: { offers: [{ label: "Exchange bonus (old phone required)", amountInr: 1000, conditional: true }], expectedYears: 3 },
        reviews: organicReviews(rand, 110, "2026-04-15", 170, { avg: 4.3 }),
      },
    ],
  };
}
