import "server-only";
import { randomUUID } from "node:crypto";
import { env } from "./env";
import { openDriver, type Driver, type Param } from "./db-core";

export type { Param } from "./db-core";
type Row = Record<string, unknown>;

const g = globalThis as unknown as { __buysureDb?: Promise<Driver> };

export function getDriver(): Promise<Driver> {
  g.__buysureDb ??= openDriver({ url: env.DATABASE_URL, file: env.DATABASE_PATH }).catch((err) => {
    g.__buysureDb = undefined; // allow a retry on the next request
    throw err;
  });
  return g.__buysureDb;
}

/** Test helper: swap in a fresh in-memory SQLite database. */
export async function resetDbForTests() {
  const old = g.__buysureDb;
  g.__buysureDb = openDriver({ file: ":memory:" });
  if (old) await (await old).close().catch(() => {});
  await g.__buysureDb;
}

export const db = {
  async all<T = Row>(sql: string, ...params: Param[]): Promise<T[]> {
    return (await getDriver()).all<T>(sql, params);
  },
  async get<T = Row>(sql: string, ...params: Param[]): Promise<T | undefined> {
    return (await (await getDriver()).all<T>(sql, params))[0];
  },
  async run(sql: string, ...params: Param[]) {
    return (await getDriver()).run(sql, params);
  },
  /** Runs fn atomically. Nested calls become savepoints. */
  async transaction<T>(fn: () => Promise<T>): Promise<T> {
    return (await getDriver()).transaction(fn);
  },
  async kind() {
    return (await getDriver()).kind;
  },
};

export const newId = () => randomUUID();
export const now = () => new Date().toISOString();

export function parseJson<T>(value: unknown, fallback: T): T {
  if (typeof value !== "string" || !value) return fallback;
  try {
    return JSON.parse(value) as T;
  } catch {
    return fallback;
  }
}
