import type { Metadata } from "next";
import { pageMeta } from "@/lib/seo";
import { AuthShell } from "../AuthShell";
import { ResetForm } from "../AuthForms";

export const metadata: Metadata = pageMeta({ title: "Choose a new password", description: "Set a new password for your BuySure AI account.", path: "/reset-password", noindex: true });

export default function ResetPage() {
  return (
    <AuthShell title="Choose a new password" intro="After this you will be signed out on every device.">
      <ResetForm />
    </AuthShell>
  );
}
