import type { NextRequest } from "next/server";
import { z } from "zod";
import { handler, json, readJson, limit, clientIp, ApiError } from "@/lib/api";
import { catalogSearch, liveSearch, liveSearchEnabled, parseQuery } from "@/lib/search/service";
import { logSearch } from "@/lib/catalog/repo";
import { log } from "@/lib/logger";

export const maxDuration = 100;

const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
const bodySchema = z.object({
  q: z.string().trim().max(500).default(""),
  image: z.object({ mediaType: z.enum(["image/jpeg", "image/png", "image/webp", "image/gif"]), base64: z.string().max(7_200_000) }).nullable().optional(),
  mode: z.enum(["auto", "catalog"]).default("auto"),
});

/** Checks the real file signature, not just the declared type, so only genuine images reach the model. */
function sniffImage(base64: string): "image/jpeg" | "image/png" | "image/webp" | "image/gif" | null {
  const b = Buffer.from(base64.slice(0, 64), "base64");
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return "image/jpeg";
  if (b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return "image/png";
  if (b.subarray(0, 4).toString("ascii") === "RIFF" && b.subarray(8, 12).toString("ascii") === "WEBP") return "image/webp";
  if (b.subarray(0, 3).toString("ascii") === "GIF") return "image/gif";
  return null;
}

/**
 * POST /api/search → NDJSON stream of {type:"status"|"result"|"error"} lines.
 * Live mode (web research) when ANTHROPIC_API_KEY is configured; otherwise the verified catalogue.
 */
export const POST = handler({}, async (req: NextRequest, { user }) => {
  const body = await readJson(req, bodySchema, 7_500_000);
  if (!body.q && !body.image) throw new ApiError(422, "Type a product, paste a link or add a photo.");

  let image: { mediaType: "image/jpeg" | "image/png" | "image/webp" | "image/gif"; base64: string } | null = null;
  if (body.image) {
    const kind = sniffImage(body.image.base64);
    if (!kind) throw new ApiError(415, "That file isn't a JPEG, PNG, WebP or GIF image.");
    if (Buffer.byteLength(body.image.base64, "base64") > MAX_IMAGE_BYTES) throw new ApiError(413, "Images must be 5 MB or smaller.");
    image = { mediaType: kind, base64: body.image.base64 };
  }

  const live = liveSearchEnabled() && body.mode === "auto";
  if (!live) {
    if (image && !body.q) throw new ApiError(503, "Photo search needs live search, which isn't switched on for this site yet. Type the product name instead.");
    await limit(`search-catalog:${clientIp(req)}`, 120, 3600);
    const res = await catalogSearch(body.q);
    await logSearch(body.q, res.understood.categoryName, res.understood.budget, res.items.length);
    return json({ result: res, live: false });
  }

  // Live research costs money per query: tighter limits for anonymous visitors.
  await limit(user ? `search-live-user:${user.id}` : `search-live-ip:${clientIp(req)}`, user ? 40 : 12, 3600);
  const pq = parseQuery(body.q);
  const encoder = new TextEncoder();
  const abort = new AbortController();
  req.signal.addEventListener("abort", () => abort.abort());
  const timer = setTimeout(() => abort.abort(), 90_000);

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      const send = (obj: unknown) => controller.enqueue(encoder.encode(`${JSON.stringify(obj)}\n`));
      send({ type: "status", message: image ? "Looking at your photo" : pq.url ? `Opening your ${pq.url.store} link` : "Understanding your search" });
      try {
        const result = await liveSearch({ query: body.q, url: pq.url ? /https?:\/\/[^\s]+/i.exec(body.q)![0] : null, image }, (e) => send(e), abort.signal);
        send({ type: "result", result, live: true });
      } catch (err) {
        log.error("live search failed", err, { q: body.q.slice(0, 120) });
        // Fall back to the verified catalogue so the shopper still gets an answer.
        const fallback = body.q ? await catalogSearch(body.q) : null;
        send({ type: "error", message: abort.signal.aborted ? "Live research timed out." : "Live research hit a problem.", fallback });
      } finally {
        clearTimeout(timer);
        controller.close();
      }
    },
  });
  return new Response(stream, { headers: { "Content-Type": "application/x-ndjson; charset=utf-8", "Cache-Control": "no-store", "X-Accel-Buffering": "no" } });
});
