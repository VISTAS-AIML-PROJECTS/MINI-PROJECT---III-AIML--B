import { afterEach, describe, expect, it, vi } from "vitest";

describe("Gemini research engine (simulated API)", () => {
  afterEach(() => { vi.unstubAllGlobals(); vi.unstubAllEnvs(); vi.resetModules(); });

  it("falls back past a retired model, grounds with search, then extracts strict JSON", async () => {
    vi.stubEnv("GEMINI_API_KEY", "test-key");
    vi.stubEnv("GEMINI_GROUNDING", "on");
    vi.stubEnv("GEMINI_MODEL", "retired-model");
    const calls: { model: string; body: any }[] = [];
    vi.stubGlobal("fetch", vi.fn(async (url: string, init: RequestInit) => {
      const model = decodeURIComponent(/models\/([^:]+):/.exec(url)![1]);
      const body = JSON.parse(String(init.body));
      calls.push({ model, body });
      if (model === "retired-model") return new Response(JSON.stringify({ error: { code: 404, message: "model not found", status: "NOT_FOUND" } }), { status: 404 });
      if (body.tools) {
        return Response.json({ candidates: [{ content: { parts: [{ text: "Air fryer A: ₹5,999, 5.5 L, 1500 W. Air fryer B (searched): ₹6,999, 4.1 L." }] },
          groundingMetadata: { webSearchQueries: ["best air fryer india"], groundingChunks: [{ web: { uri: "https://example.in/a", title: "Example" } }] } }] });
      }
      return Response.json({ candidates: [{ content: { parts: [{ text: JSON.stringify({
        understood: { searched_product: "Air fryer B", category_name: "Air fryers", category_slug: "other", budget_inr: 8000, intent: "family air fryer" },
        criteria: [{ key: "price", label: "Price", direction: "lower", unit: "₹", weight: 7 }, { key: "capacity", label: "Capacity", direction: "higher", unit: "L", weight: 8 }],
        products: [
          { name: "Air fryer A", brand: "X", is_searched_product: false, price_inr: 5999, price_note: "Amazon", metrics: [{ key: "capacity", value: 5.5 }], key_specs: [], highlights: [], drawbacks: [], sources: [{ title: "Example", url: "https://example.in/a" }] },
          { name: "Air fryer B", brand: "Y", is_searched_product: true, price_inr: 6999, price_note: "Flipkart", metrics: [{ key: "capacity", value: 4.1 }], key_specs: [], highlights: [], drawbacks: [], sources: [] },
        ],
        verdict: "A is bigger and cheaper.", caveats: [],
      }) }] } }] });
    }));

    const { runGeminiAgent } = await import("@/lib/search/gemini");
    const events: string[] = [];
    const result = await runGeminiAgent({ query: "best air fryer", url: null, image: null }, (e) => events.push(e.message), new AbortController().signal);

    expect(calls[0].model).toBe("retired-model");
    expect(calls[1].body.tools).toEqual([{ google_search: {} }]);
    expect(calls[2].body.generationConfig.responseMimeType).toBe("application/json");
    expect(JSON.stringify(calls[2].body.generationConfig.responseSchema)).not.toContain("additionalProperties");
    expect(result.products).toHaveLength(2);
    expect(result.products[0].battery_mah).toBeNull(); // omitted fields are normalised, not guessed
    expect(events).toContain("Searched: best air fryer india");
  });

  it("without search quota, verifies candidates by reading their pages and cites only loaded pages", async () => {
    vi.stubEnv("GEMINI_API_KEY", "test-key");
    vi.stubEnv("GEMINI_GROUNDING", "on");
    const steps: string[] = [];
    vi.stubGlobal("fetch", vi.fn(async (_url: string, init: RequestInit) => {
      const body = JSON.parse(String(init.body));
      const tools = JSON.stringify(body.tools ?? []);
      if (tools.includes("google_search")) { steps.push("grounded"); return new Response(JSON.stringify({ error: { code: 429, message: "You exceeded your current quota", status: "RESOURCE_EXHAUSTED" } }), { status: 429 }); }
      if (tools.includes("url_context")) {
        steps.push("read");
        expect(body.contents[0].parts[0].text).toContain("https://brand.example/real");
        return Response.json({ candidates: [{ content: { parts: [{ text: "Fryer A ₹5,999 (https://brand.example/real). Fryer B: UNVERIFIED: no source loaded" }] },
          urlContextMetadata: { urlMetadata: [
            { retrievedUrl: "https://brand.example/real", urlRetrievalStatus: "URL_RETRIEVAL_STATUS_SUCCESS" },
            { retrievedUrl: "https://made-up.example/x", urlRetrievalStatus: "URL_RETRIEVAL_STATUS_ERROR" },
          ] } }] });
      }
      if (body.generationConfig?.responseSchema?.properties?.candidates) {
        steps.push("plan");
        return Response.json({ candidates: [{ content: { parts: [{ text: JSON.stringify({ identified_product: null, category: "Air fryers", candidates: [
          { name: "Fryer A", brand: "X", urls: ["https://brand.example/real"] }, { name: "Fryer B", brand: "Y", urls: ["https://made-up.example/x"] }] }) }] } }] });
      }
      steps.push("extract");
      return Response.json({ candidates: [{ content: { parts: [{ text: JSON.stringify({
        understood: { searched_product: null, category_name: "Air fryers", category_slug: "other", budget_inr: null, intent: "x" },
        criteria: [{ key: "price", label: "Price", direction: "lower", unit: "₹", weight: 7 }],
        products: [
          { name: "Fryer A", brand: "X", is_searched_product: false, price_inr: 5999, price_note: "", metrics: [], key_specs: [], highlights: [], drawbacks: [], sources: [{ title: "brand", url: "https://brand.example/real" }] },
          { name: "Fryer B", brand: "Y", is_searched_product: false, price_inr: null, price_note: "", metrics: [], key_specs: [], highlights: [], drawbacks: [], sources: [{ title: "fake", url: "https://made-up.example/x" }] },
        ], verdict: "A.", caveats: [] }) }] } }] });
    }));
    const { runGeminiAgent } = await import("@/lib/search/gemini");
    const events: string[] = [];
    const r = await runGeminiAgent({ query: "best air fryer", url: null, image: null }, (e) => events.push(e.message), new AbortController().signal);
    expect(steps).toEqual(["grounded", "plan", "read", "plan", "extract"]); // 2nd plan = retry for the unverified product
    expect(r.products[0].sources).toHaveLength(1);
    expect(r.products[1].sources).toHaveLength(0); // page that failed to load is never cited
    expect(events).toContain("Verified facts from 1 of 2 pages");
  });

  it("with a Tavily key, searches the web first and cites the search results", async () => {
    vi.stubEnv("GEMINI_API_KEY", "test-key");
    vi.stubEnv("GEMINI_GROUNDING", "on");
    vi.stubEnv("TAVILY_API_KEY", "tvly-test");
    const steps: string[] = [];
    vi.stubGlobal("fetch", vi.fn(async (url: string, init: RequestInit) => {
      const body = JSON.parse(String(init.body));
      if (url.startsWith("https://api.tavily.com")) {
        steps.push("tavily");
        expect((init.headers as Record<string, string>).Authorization).toBe("Bearer tvly-test");
        expect(body.country).toBe("india");
        return Response.json({ results: [{ title: "Best mixer grinders", url: "https://news.example/mixers", content: "Bajaj Rex 500W ₹2,499; Prestige Iris 750W ₹3,299" }],
          images: [{ url: "https://img.example/rex.jpg", description: "Bajaj Rex mixer" }] });
      }
      const tools = JSON.stringify(body.tools ?? []);
      if (tools.includes("google_search")) { steps.push("grounded"); return new Response(JSON.stringify({ error: { code: 429, message: "quota exceeded" } }), { status: 429 }); }
      if (tools.includes("url_context")) {
        steps.push("read");
        expect(body.contents[0].parts.at(-1).text).toContain("https://news.example/mixers");
        return Response.json({ candidates: [{ content: { parts: [{ text: "Bajaj Rex ₹2,499 500W (https://news.example/mixers)" }] } }] });
      }
      steps.push("extract");
      return Response.json({ candidates: [{ content: { parts: [{ text: JSON.stringify({
        understood: { searched_product: null, category_name: "Mixer grinders", category_slug: "other", budget_inr: 5000, intent: "x" },
        criteria: [{ key: "price", label: "Price", direction: "lower", unit: "₹", weight: 7 }, { key: "power", label: "Power", direction: "higher", unit: "W", weight: 6 }],
        products: [{ name: "Rex", brand: "Bajaj", image_url: "https://img.example/rex.jpg", is_searched_product: false, price_inr: 2499, price_note: "", metrics: [{ key: "power", value: 500 }], key_specs: [], highlights: [], drawbacks: [], sources: [{ title: "x", url: "https://news.example/mixers" }] }],
        verdict: "Rex.", caveats: [] }) }] } }] });
    }));
    const { runGeminiAgent } = await import("@/lib/search/gemini");
    const r = await runGeminiAgent({ query: "best mixer grinder under 5000", url: null, image: null }, () => {}, new AbortController().signal);
    // Fast path: two parallel searches, then ONE model call (no grounding, no page reading).
    expect(steps).toEqual(["tavily", "tavily", "extract"]);
    expect(r.products[0].sources[0].url).toBe("https://news.example/mixers");
    expect(r.products[0].image_url).toBe("https://img.example/rex.jpg");
  });

  it("adds URL reading for pasted links and sends photos inline", async () => {
    vi.stubEnv("GEMINI_API_KEY", "test-key");
    vi.stubEnv("GEMINI_GROUNDING", "on");
    const bodies: any[] = [];
    vi.stubGlobal("fetch", vi.fn(async (_url: string, init: RequestInit) => {
      bodies.push(JSON.parse(String(init.body)));
      return new Response(JSON.stringify({ error: { code: 400, message: "invalid argument", status: "INVALID_ARGUMENT" } }), { status: 400 });
    }));
    const { runGeminiAgent } = await import("@/lib/search/gemini");
    await expect(runGeminiAgent({ query: "x", url: "https://www.amazon.in/x/dp/B0", image: { mediaType: "image/png", base64: "iVBORw0KGgo=" } }, () => {}, new AbortController().signal)).rejects.toThrow(/Gemini 400/);
    expect(bodies[0].tools).toEqual([{ google_search: {} }, { url_context: {} }]);
    expect(bodies[0].contents[0].parts[0].inline_data.mime_type).toBe("image/png");
  });
});

describe("bestImage", () => {
  it("matches on model number, not brand alone", async () => {
    const { bestImage } = await import("@/lib/search/gemini");
    const imgs = [{ url: "https://a/lg-other.jpg", description: "LG washing machine 8kg" }, { url: "https://a/x.jpg", description: "LG T70VBMB4ZD top load 7 kg" }];
    expect(bestImage("LG 7 kg Top Load (T70VBMB4ZD)", imgs)).toBe("https://a/x.jpg");
    expect(bestImage("Samsung WA80F08S2CTL", imgs)).toBeNull();
  });
});
