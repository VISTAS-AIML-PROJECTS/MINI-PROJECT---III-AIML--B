"use client";

import { useState } from "react";
import { api } from "@/lib/client-api";
import { parseReviews, type ParseResult } from "@/lib/review-import";
import { track } from "@/lib/analytics";

const MAX_FILE = 5 * 1024 * 1024;
const EXAMPLE = `rating,body,date,verified
5,"Battery lasts two days, camera is fine in daylight",2026-08-02,yes
2,"Screen is hard to read outdoors",2026-08-05,yes`;

export function ReviewImport({ productId, productName, existing, onDone, onCancel }: {
  productId: string; productName: string; existing: number; onDone: (msg: string) => void; onCancel: () => void;
}) {
  const [text, setText] = useState("");
  const [parsed, setParsed] = useState<ParseResult | null>(null);
  const [replace, setReplace] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const onFile = (file: File | undefined) => {
    setError(null);
    if (!file) return;
    if (file.size > MAX_FILE) return setError("That file is over 5 MB. Split it into smaller files.");
    if (!/\.(csv|json|txt)$/i.test(file.name)) return setError("Upload a .csv or .json file.");
    const reader = new FileReader();
    reader.onload = () => {
      const t = String(reader.result ?? "");
      setText(t);
      setParsed(parseReviews(t));
    };
    reader.onerror = () => setError("Could not read that file.");
    reader.readAsText(file);
  };

  const submit = async () => {
    const p = parsed ?? parseReviews(text);
    setParsed(p);
    if (!p.reviews.length) return setError(p.errors[0] ?? "No valid reviews found.");
    if (p.reviews.length > 5000) return setError("Import at most 5,000 reviews at a time.");
    setBusy(true);
    setError(null);
    const res = await api<{ imported: number; total: number }>(`/api/products/${productId}/reviews`, { body: { reviews: p.reviews, replace } });
    setBusy(false);
    if (!res.ok) return setError(res.error);
    track("reviews_imported", { count: res.data.imported });
    onDone(`Imported ${res.data.imported} reviews (${res.data.total} total).`);
  };

  return (
    <div>
      <h2 style={{ fontSize: "var(--step-2)" }}>Import reviews for {productName}</h2>
      <p className="small muted">
        Paste CSV with a header row, or a JSON array. Recognised columns: <code>rating</code>, <code>body</code> (or text/review),{" "}
        <code>date</code>, <code>author</code>, <code>verified</code>. Rating and text are required; dates enable burst detection.
        {existing > 0 && ` This product already has ${existing} reviews.`}
      </p>
      {error && <div className="notice notice-error" role="alert">{error}</div>}
      <div className="field">
        <label htmlFor="ri-file">Upload a file</label>
        <input id="ri-file" type="file" accept=".csv,.json,.txt,text/csv,application/json" onChange={(e) => onFile(e.target.files?.[0])} />
        <span className="hint">CSV or JSON, up to 5 MB. Read in your browser, then sent to your account.</span>
      </div>
      <div className="field">
        <label htmlFor="ri-text">…or paste here</label>
        <textarea id="ri-text" value={text} placeholder={EXAMPLE} style={{ fontFamily: "var(--font-mono)", fontSize: "0.85rem", minHeight: 180 }}
          onChange={(e) => { setText(e.target.value); setParsed(null); }} />
      </div>
      {parsed && (
        <p className="small" role="status">
          Found <strong>{parsed.reviews.length}</strong> valid review{parsed.reviews.length === 1 ? "" : "s"}
          {parsed.skipped ? `, skipped ${parsed.skipped}` : ""}.{parsed.errors.length > 0 && ` ${parsed.errors.join("; ")}.`}
        </p>
      )}
      <label className="check" style={{ marginBottom: 16 }}>
        <input type="checkbox" checked={replace} onChange={(e) => setReplace(e.target.checked)} />
        Replace existing reviews instead of adding to them
      </label>
      <div className="btn-row">
        <button type="button" className="btn btn-secondary" onClick={() => setParsed(parseReviews(text))} disabled={!text.trim()}>Check</button>
        <button type="button" className="btn" onClick={submit} disabled={busy || !text.trim()}>{busy ? "Importing…" : "Import"}</button>
        <button type="button" className="btn btn-secondary" onClick={onCancel}>Cancel</button>
      </div>
    </div>
  );
}
