import Link from "next/link";
import { requireAdmin } from "@/lib/auth/guard";
import { adminListProducts, recentSearches } from "@/lib/catalog/repo";
import { categoryBySlug } from "@/lib/catalog/categories";
import { date, dateTime, inr } from "@/lib/format";

export default async function AdminCatalog() {
  await requireAdmin();
  const products = await adminListProducts();
  const searches = await recentSearches(15);
  return (
    <>
      <div className="panel-head">
        <h1 style={{ fontSize: "var(--step-3)", margin: 0 }}>Catalogue</h1>
        <Link href="/admin/catalog/new" className="btn btn-small">Add product</Link>
      </div>
      <p className="muted small">Verified products power the home page, category pages and instant search. Upload photos you have the rights to use.</p>
      <div className="table-wrap">
        <table>
          <thead><tr><th scope="col">Product</th><th scope="col">Category</th><th scope="col" className="num">Price</th><th scope="col">Photo</th><th scope="col">Status</th><th scope="col">Checked</th></tr></thead>
          <tbody>
            {products.map((p) => (
              <tr key={p.id}>
                <td><Link href={`/admin/catalog/${p.id}`}>{p.name}</Link><div className="small muted">{p.brand}</div></td>
                <td>{categoryBySlug(p.category)?.name ?? p.category}</td>
                <td className="num">{inr(p.priceInr)}</td>
                <td>{p.imagePath ? "Yes" : <span className="muted">Illustration</span>}</td>
                <td><span className={`stamp ${p.status === "published" ? "stamp-pass" : "stamp-info"}`}>{p.status}</span></td>
                <td>{date(p.checkedAt)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <section className="panel" style={{ marginTop: 24 }}>
        <h2>Recent searches</h2>
        <p className="small muted">What shoppers look for: add the popular ones to the catalogue.</p>
        {searches.length ? (
          <ul className="list-plain small">{searches.map((s, i) => <li key={i} style={{ padding: "5px 0", borderBottom: "1px solid var(--rule)" }}>“{s.query}” · {s.category ?? "unknown"} · {s.results} results · {dateTime(s.created_at)}</li>)}</ul>
        ) : <p className="muted">No searches yet.</p>}
      </section>
    </>
  );
}
