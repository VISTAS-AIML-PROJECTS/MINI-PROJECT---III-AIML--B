import type { Specs } from "./categories";

/**
 * Verified starter catalogue (researched 6 Oct 2026). Prices are launch or listed prices for
 * the variant named, taken from the linked source on that date; live prices change, so every
 * product page links to retailers to check. Performance numbers: Geekbench 6 multi-core from
 * Beebom's chipset benchmark guides unless the source says otherwise.
 */

export type SeedProduct = {
  slug: string;
  category: string;
  name: string;
  brand: string;
  priceInr: number;
  priceNote: string;
  variant: string;
  released?: string;
  specs: Specs;
  sources: { title: string; url: string }[];
};

export const SEED_CATEGORIES = [
  { slug: "phones", name: "Smartphones", singular: "phone", tagline: "The phones worth your money at every budget.", banner: "Pick up the right one", sort: 1 },
  { slug: "earbuds", name: "Wireless earbuds", singular: "pair of earbuds", tagline: "Noise cancelling, battery and codecs, compared on the numbers.", banner: "Hear the difference", sort: 2 },
  { slug: "laptops", name: "Laptops", singular: "laptop", tagline: "Speed, battery and weight, weighed against price.", banner: "Build it faster", sort: 3 },
  { slug: "power-banks", name: "Power banks", singular: "power bank", tagline: "Real capacity, real output, no inflated claims.", banner: "Stay charged", sort: 4 },
];

const GB6 = { url: "https://gadgets.beebom.com/guides/", title: "Beebom chipset benchmarks (Geekbench 6)" };

export const SEED_PRODUCTS: SeedProduct[] = [
  // ── Phones ─────────────────────────────────────────────────────────────────────────
  { slug: "moto-g06-power", category: "phones", name: "Moto G06 Power", brand: "Motorola", priceInr: 7499, priceNote: "Launch price", variant: "4GB + 64GB",
    specs: { chip: "MediaTek Helio G81 Extreme", gb6Multi: 1416, display: "LCD", sizeIn: 6.88, refreshHz: 120, peakNits: 600, batteryMah: 7000, chargingW: 18, mainCamera: "50 MP", mainMp: 50, ois: false, telephoto: false, ultrawide: false, ip: "IP64", weightG: 220, thicknessMm: 8.31 },
    sources: [{ title: "FoneArena launch report", url: "https://www.fonearena.com/blog/466093/moto-g06-power-price-india-specifications.html" }] },
  { slug: "infinix-note-50x-5g", category: "phones", name: "Infinix Note 50X 5G", brand: "Infinix", priceInr: 11499, priceNote: "Launch price", variant: "6GB + 128GB",
    specs: { chip: "MediaTek Dimensity 7300 Ultimate", gb6Multi: 2781, display: "LCD", sizeIn: 6.67, refreshHz: 120, peakNits: 672, batteryMah: 5500, chargingW: 45, mainCamera: "50 MP", mainMp: 50, ois: false, telephoto: false, ultrawide: false, ip: "IP64", weightG: 195.4, lengthMm: 165.42, widthMm: 76.41, thicknessMm: 7.98 },
    sources: [{ title: "FoneArena launch report", url: "https://www.fonearena.com/blog/449683/infinix-note-50x-5g-price-india-specifications.html" }, GB6] },
  { slug: "redmi-15c-5g", category: "phones", name: "Redmi 15C 5G", brand: "Xiaomi", priceInr: 12499, priceNote: "Launch price", variant: "4GB + 128GB",
    specs: { chip: "MediaTek Dimensity 6300", gb6Multi: 1813, display: "LCD", sizeIn: 6.9, refreshHz: 120, peakNits: 810, batteryMah: 6000, chargingW: 33, mainCamera: "50 MP", mainMp: 50, ois: false, telephoto: false, ultrawide: false, ip: "IP64", weightG: 211, thicknessMm: 7.9 },
    sources: [{ title: "FoneArena launch report", url: "https://www.fonearena.com/blog/470226/redmi-15c-5g-price-india-specifications.html" }, GB6] },
  { slug: "poco-m7-pro-5g", category: "phones", name: "POCO M7 Pro 5G", brand: "POCO", priceInr: 14999, priceNote: "Listed price", variant: "6GB + 128GB",
    specs: { chip: "MediaTek Dimensity 7025 Ultra", gb6Multi: 2305, display: "OLED", sizeIn: 6.67, refreshHz: 120, peakNits: 2100, batteryMah: 5110, chargingW: 45, mainCamera: "50 MP with OIS", mainMp: 50, ois: true, telephoto: false, ultrawide: false, ip: "IP64", weightG: 190, thicknessMm: 7.99 },
    sources: [{ title: "FoneArena price and specifications", url: "https://www.fonearena.com/blog/442391/poco-m7-pro-price-india-specifications.html" }, { title: "Notebookcheck Dimensity 7025 benchmarks", url: "https://www.notebookcheck.net/MediaTek-Dimensity-7025-Processor-Benchmarks-and-Specs.932277.0.html" }] },
  { slug: "realme-narzo-90", category: "phones", name: "realme Narzo 90", brand: "realme", priceInr: 16999, priceNote: "Launch price", variant: "6GB + 128GB", released: "2025-12",
    specs: { chip: "MediaTek Dimensity 6400 Max", gb6Multi: 1978, display: "AMOLED", sizeIn: 6.57, refreshHz: 120, peakNits: 4000, batteryMah: 7000, chargingW: 60, mainCamera: "50 MP", mainMp: 50, ois: false, telephoto: false, ultrawide: false, ip: "IP69", weightG: 181, thicknessMm: 7.79 },
    sources: [{ title: "MySmartPrice launch report", url: "https://www.mysmartprice.com/personal-tech/mobiles/mobiles-news/realme-narzo-90-series-launched-in-india/" }, GB6] },
  { slug: "moto-g96-5g", category: "phones", name: "Moto G96 5G", brand: "Motorola", priceInr: 17999, priceNote: "Launch price", variant: "8GB + 128GB",
    specs: { chip: "Snapdragon 7s Gen 2", gb6Multi: 2882, display: "pOLED", sizeIn: 6.67, refreshHz: 144, peakNits: 1600, batteryMah: 5500, chargingW: 33, mainCamera: "50 MP Sony with OIS + 8 MP ultrawide", mainMp: 50, ois: true, telephoto: false, ultrawide: true, ip: "IP68", weightG: 178, thicknessMm: 7.9 },
    sources: [{ title: "ETV Bharat launch report", url: "https://www.etvbharat.com/en/!technology/motorola-g96-5g-india-launch-price-specifications-enn25070901406" }, GB6] },
  { slug: "cmf-phone-2-pro", category: "phones", name: "CMF Phone 2 Pro", brand: "CMF by Nothing", priceInr: 18999, priceNote: "Launch price, 33 W charger in box", variant: "8GB + 128GB",
    specs: { chip: "MediaTek Dimensity 7300 Pro", gb6Multi: 2781, display: "AMOLED", sizeIn: 6.77, refreshHz: 120, peakNits: 3000, batteryMah: 5000, chargingW: 33, mainCamera: "50 MP + 50 MP 2× telephoto", mainMp: 50, ois: false, telephoto: true, ultrawide: false, ip: "IP54", weightG: 185, thicknessMm: 7.8 },
    sources: [{ title: "FoneArena launch report", url: "https://www.fonearena.com/blog/452371/cmf-phone-2-pro-price-india-specifications.html" }, GB6] },
  { slug: "iqoo-z10r", category: "phones", name: "iQOO Z10R", brand: "iQOO", priceInr: 19499, priceNote: "Launch MRP (₹17,499 effective with bank offer)", variant: "8GB + 128GB", released: "2025-07",
    specs: { chip: "MediaTek Dimensity 7400", gb6Multi: 3062, display: "AMOLED", sizeIn: 6.77, refreshHz: 120, peakNits: 1800, batteryMah: 5700, chargingW: 44, mainCamera: "50 MP with OIS", mainMp: 50, ois: true, telephoto: false, ultrawide: false, ip: "IP69", weightG: 183.5, thicknessMm: 7.39 },
    sources: [{ title: "Business Today launch report", url: "https://www.businesstoday.in/technology/news/story/iqoo-z10r-with-quad-curved-amoled-panel-ip69-rating-is-available-for-rs-17499-486782-2025-07-29" }, GB6] },
  { slug: "realme-p4-power", category: "phones", name: "realme P4 Power", brand: "realme", priceInr: 25999, priceNote: "Launch price", variant: "8GB + 128GB",
    specs: { chip: "MediaTek Dimensity 7400 Ultra", gb6Multi: 3062, display: "AMOLED", sizeIn: 6.8, refreshHz: 144, peakNits: 6500, batteryMah: 10001, chargingW: 80, mainCamera: "50 MP with OIS + 8 MP ultrawide", mainMp: 50, ois: true, telephoto: false, ultrawide: true, ip: "IP69", weightG: 219, lengthMm: 162.26, widthMm: 76.15, thicknessMm: 9.08 },
    sources: [{ title: "Gizbot launch report", url: "https://www.gizbot.com/mobile/news/realme-p4-power-launched-in-india-with-10-001mah-battery-144hz-curved-display-122773.html" }, GB6] },
  { slug: "motorola-edge-70-fusion", category: "phones", name: "Motorola Edge 70 Fusion", brand: "Motorola", priceInr: 26339, priceNote: "Listed price", variant: "8GB + 128GB", released: "2026-03",
    specs: { chip: "Snapdragon 7s Gen 4", gb6Multi: 3145, display: "AMOLED", sizeIn: 6.8, refreshHz: 144, peakNits: 5200, batteryMah: 7000, chargingW: 68, mainCamera: "50 MP + 13 MP ultrawide", mainMp: 50, ois: false, telephoto: false, ultrawide: true, ip: "IP69", weightG: 193, thicknessMm: 7.99 },
    sources: [{ title: "91mobiles specifications", url: "https://www.91mobiles.com/motorola-edge-70-fusion-price-in-india?ty=specs" }, GB6] },
  { slug: "nothing-phone-3a-pro", category: "phones", name: "Nothing Phone (3a) Pro", brand: "Nothing", priceInr: 29999, priceNote: "Launch price", variant: "8GB + 128GB",
    specs: { chip: "Snapdragon 7s Gen 3", gb6Multi: 3252, display: "AMOLED", sizeIn: 6.77, refreshHz: 120, peakNits: 3000, batteryMah: 5000, chargingW: 50, mainCamera: "50 MP OIS + 50 MP 3× periscope + 8 MP ultrawide", mainMp: 50, ois: true, telephoto: true, ultrawide: true, ip: "IP64", weightG: 211, thicknessMm: 8.35 },
    sources: [{ title: "FoneArena launch report", url: "https://www.fonearena.com/blog/447739/nothing-phone-3a-price-india-specifications-phone-3a-pro.html" }, GB6] },
  { slug: "motorola-edge-70", category: "phones", name: "Motorola Edge 70", brand: "Motorola", priceInr: 29999, priceNote: "Launch price", variant: "8GB + 256GB", released: "2025-12",
    specs: { chip: "Snapdragon 7 Gen 4", gb6Multi: 3464, display: "AMOLED", sizeIn: 6.7, refreshHz: 120, peakNits: 4500, batteryMah: 5000, chargingW: 68, mainCamera: "50 MP OIS + 50 MP ultrawide", mainMp: 50, ois: true, telephoto: false, ultrawide: true, ip: "IP68", weightG: 159, lengthMm: 159.9, widthMm: 74.3, thicknessMm: 5.9 },
    sources: [{ title: "ETV Bharat launch report", url: "https://www.etvbharat.com/en/technology/motorola-edge-70-launched-in-india-price-specifications-enn25121502204" }, GB6] },
  { slug: "oneplus-nord-6", category: "phones", name: "OnePlus Nord 6", brand: "OnePlus", priceInr: 38999, priceNote: "Launch price", variant: "8GB + 256GB", released: "2026-04",
    specs: { chip: "Snapdragon 8s Gen 4", gb6Multi: 6989, display: "AMOLED", sizeIn: 6.78, refreshHz: 165, peakNits: 3600, batteryMah: 9000, chargingW: 80, mainCamera: "50 MP", mainMp: 50, ois: false, telephoto: false, ultrawide: false, ip: "IP69", weightG: 217, thicknessMm: 8.5 },
    sources: [{ title: "Free Press Journal launch report", url: "https://www.freepressjournal.in/tech/oneplus-nord-6-with-9000mah-battery-launched-in-india-priced-starting-at-38999" }, GB6] },
  { slug: "poco-x8-pro-max", category: "phones", name: "POCO X8 Pro Max", brand: "POCO", priceInr: 42999, priceNote: "Launch price", variant: "12GB + 256GB", released: "2026-03",
    specs: { chip: "MediaTek Dimensity 9500s", gb6Multi: 8500, display: "AMOLED", sizeIn: 6.83, refreshHz: 120, peakNits: 3500, batteryMah: 9000, chargingW: 100, mainCamera: "50 MP + 8 MP ultrawide", mainMp: 50, ois: false, telephoto: false, ultrawide: true, ip: "IP69", weightG: 218, lengthMm: 162.9, widthMm: 77.9, thicknessMm: 8.2 },
    sources: [{ title: "Business Today launch report", url: "https://www.businesstoday.in/technology/news/story/poco-x8-pro-series-launched-in-india-with-mediatek-dimensity-socs-price-starts-at-rs-32999-521051-2026-03-17" }, { title: "Croma Unboxed specifications", url: "https://www.croma.com/unboxed/poco-x8-pro-max-x8-pro-launched-price-specifications" }] },
  { slug: "google-pixel-10a", category: "phones", name: "Google Pixel 10a", brand: "Google", priceInr: 49999, priceNote: "Launch price", variant: "8GB + 256GB", released: "2026-02",
    specs: { chip: "Google Tensor G4", gb6Multi: 3568, display: "pOLED", sizeIn: 6.3, refreshHz: 120, peakNits: 2000, batteryMah: 5100, chargingW: 30, mainCamera: "48 MP + 13 MP ultrawide", mainMp: 48, ois: true, telephoto: false, ultrawide: true, ip: "IP68", weightG: 183, thicknessMm: 9 },
    sources: [{ title: "Business Today launch report", url: "https://www.businesstoday.in/technology/news/story/google-pixel-10a-launched-price-starts-at-rs-49999-in-india-516822-2026-02-18" }, GB6] },
  { slug: "oneplus-15r", category: "phones", name: "OnePlus 15R", brand: "OnePlus", priceInr: 54999, priceNote: "Launch price", variant: "12GB + 256GB", released: "2025-12",
    specs: { chip: "Snapdragon 8 Gen 5", gb6Multi: 9198, display: "AMOLED", sizeIn: 6.83, refreshHz: 165, batteryMah: 7400, chargingW: 80, mainCamera: "50 MP + 8 MP ultrawide", mainMp: 50, ois: false, telephoto: false, ultrawide: true, ip: "IP69", weightG: 218, thicknessMm: 8.1 },
    sources: [{ title: "91mobiles specifications", url: "https://www.91mobiles.com/oneplus-15r-price-in-india?ty=specs" }, GB6] },
  { slug: "oneplus-15", category: "phones", name: "OnePlus 15", brand: "OnePlus", priceInr: 72999, priceNote: "Launch price", variant: "12GB + 256GB", released: "2025-11",
    specs: { chip: "Snapdragon 8 Elite Gen 5", gb6Multi: 10207, display: "AMOLED", sizeIn: 6.78, refreshHz: 165, peakNits: 1800, batteryMah: 7300, chargingW: 120, mainCamera: "50 MP OIS + 50 MP 3.5× telephoto + 50 MP ultrawide", mainMp: 50, ois: true, telephoto: true, ultrawide: true, ip: "IP69", weightG: 211, thicknessMm: 8.1 },
    sources: [{ title: "Business Standard launch report", url: "https://www.business-standard.com/technology/tech-news/oneplus-15-launched-in-india-snapdragon-8-elite-gen-5-7300mah-battery-165hz-display-specification-pricing-125111301967_1.html" }, GB6] },
  { slug: "apple-iphone-17", category: "phones", name: "Apple iPhone 17", brand: "Apple", priceInr: 82900, priceNote: "Launch price", variant: "256GB",
    specs: { chip: "Apple A19", gb6Multi: 9201, display: "OLED", sizeIn: 6.3, refreshHz: 120, peakNits: 3000, batteryMah: 3692, mainCamera: "48 MP Fusion + 48 MP ultrawide", mainMp: 48, ois: true, telephoto: false, ultrawide: true, ip: "IP68", weightG: 177, thicknessMm: 7.95 },
    sources: [{ title: "FoneArena price and specifications", url: "https://www.fonearena.com/blog/463952/apple-iphone-17-price-india-specifications.html" }, GB6] },
  { slug: "google-pixel-10-pro", category: "phones", name: "Google Pixel 10 Pro", brand: "Google", priceInr: 109999, priceNote: "Launch price (listed lower at some retailers)", variant: "16GB + 256GB",
    specs: { chip: "Google Tensor G5", gb6Multi: 6191, display: "LTPO OLED", sizeIn: 6.3, refreshHz: 120, peakNits: 3300, batteryMah: 4870, chargingW: 30, mainCamera: "50 MP OIS + 48 MP 5× telephoto + 48 MP ultrawide", mainMp: 50, ois: true, telephoto: true, ultrawide: true, ip: "IP68", weightG: 207, thicknessMm: 8.6 },
    sources: [{ title: "Wikipedia: Pixel 10 Pro", url: "https://en.wikipedia.org/wiki/Pixel_10_Pro" }, GB6] },
  { slug: "apple-iphone-17-pro", category: "phones", name: "Apple iPhone 17 Pro", brand: "Apple", priceInr: 134900, priceNote: "Launch price", variant: "256GB",
    specs: { chip: "Apple A19 Pro", gb6Multi: 9746, display: "OLED", sizeIn: 6.3, refreshHz: 120, peakNits: 3000, batteryMah: 3988, chargingW: 40, mainCamera: "48 MP Fusion + 48 MP telephoto + 48 MP ultrawide", mainMp: 48, ois: true, telephoto: true, ultrawide: true, ip: "IP68", weightG: 204, lengthMm: 150, widthMm: 71.9, thicknessMm: 8.75 },
    sources: [{ title: "Apple iPhone 17 Pro technical specifications", url: "https://www.apple.com/in/iphone-17-pro/specs/" }, GB6] },
  { slug: "samsung-galaxy-s26-ultra", category: "phones", name: "Samsung Galaxy S26 Ultra", brand: "Samsung", priceInr: 139999, priceNote: "Launch price", variant: "12GB + 256GB",
    specs: { chip: "Snapdragon 8 Elite Gen 5 for Galaxy", gb6Multi: 10207, display: "Dynamic AMOLED 2X", sizeIn: 6.9, refreshHz: 120, batteryMah: 5000, chargingW: 60, mainCamera: "200 MP OIS + 50 MP 5× + 10 MP 3× + 50 MP ultrawide", mainMp: 200, ois: true, telephoto: true, ultrawide: true, ip: "IP68", weightG: 214, lengthMm: 163.6, widthMm: 78.1, thicknessMm: 7.9 },
    sources: [{ title: "Digit launch report", url: "https://www.digit.in/news/mobile-phones/samsung-galaxy-s26-ultra-with-privacy-display-200mp-camera-and-60w-charging-launched-in-india-check-price-and-specs.html" }, GB6] },

  // ── Earbuds ────────────────────────────────────────────────────────────────────────
  { slug: "cmf-buds-2-plus", category: "earbuds", name: "CMF Buds 2 Plus", brand: "CMF by Nothing", priceInr: 3299, priceNote: "Launch price", variant: "",
    specs: { anc: true, ancDb: 50, budHours: 14, totalHours: 61.5, codecs: "LDAC, AAC, SBC", hiResCodec: true },
    sources: [{ title: "FoneArena launch report", url: "https://www.fonearena.com/blog/452373/cmf-buds-2a-buds-2-buds-2-plus-price-india-features.html" }] },
  { slug: "realme-buds-air-8", category: "earbuds", name: "realme Buds Air 8", brand: "realme", priceInr: 3799, priceNote: "Launch price", variant: "",
    specs: { anc: true, ancDb: 55, budHours: 14, totalHours: 58, codecs: "LHDC 5.0, AAC, SBC", hiResCodec: true, ip: "IP55" },
    sources: [{ title: "FoneArena launch report", url: "https://www.fonearena.com/blog/472617/realme-buds-air-8-price-india-features.html" }] },
  { slug: "oneplus-nord-buds-4-pro", category: "earbuds", name: "OnePlus Nord Buds 4 Pro", brand: "OnePlus", priceInr: 3999, priceNote: "Listed price (₹3,799 at launch)", variant: "", released: "2026-03",
    specs: { anc: true, ancDb: 55, budHours: 13, totalHours: 54, codecs: "LHDC 5.0", hiResCodec: true, ip: "IP55" },
    sources: [{ title: "ETV Bharat launch report", url: "https://www.etvbharat.com/en/technology/oneplus-nord-buds-4-pro-launched-in-india-price-specifications-offers-enn26031904437" }] },
  { slug: "nothing-ear-2024", category: "earbuds", name: "Nothing Ear", brand: "Nothing", priceInr: 11999, priceNote: "Launch price", variant: "2024",
    specs: { anc: true, ancDb: 45, budHours: 8.5, totalHours: 40.5, codecs: "LDAC, LHDC 5.0", hiResCodec: true, ip: "IP54" },
    sources: [{ title: "MobiGyaan launch report", url: "https://www.mobigyaan.com/nothing-ear-india" }] },
  { slug: "apple-airpods-pro-3", category: "earbuds", name: "Apple AirPods Pro 3", brand: "Apple", priceInr: 27900, priceNote: "Current list price after price change", variant: "",
    specs: { anc: true, budHours: 8, totalHours: 24, codecs: "AAC", hiResCodec: false, ip: "IP57" },
    sources: [{ title: "IBTimes price update", url: "https://www.ibtimes.co.in/airpods-pro-3-price-hiked-rs-27900-airpods-max-2-also-get-price-hike-after-airpods-5-launch-905701" }, { title: "FoneArena launch report", url: "https://www.fonearena.com/blog/463954/apple-airpods-pro-3-price-india-features.html" }] },
  { slug: "sony-wf-1000xm6", category: "earbuds", name: "Sony WF-1000XM6", brand: "Sony", priceInr: 29990, priceNote: "Launch price", variant: "",
    specs: { anc: true, budHours: 8, totalHours: 24, codecs: "LDAC, AAC, SBC, LC3", hiResCodec: true, ip: "IPX4" },
    sources: [{ title: "91mobiles launch report", url: "https://www.91mobiles.com/hub/sony-1000x-the-collexion-wf-1000xm6-launched-india/" }] },

  // ── Power banks ────────────────────────────────────────────────────────────────────
  { slug: "ambrane-stylo-n20", category: "power-banks", name: "Ambrane Stylo N20 20000mAh", brand: "Ambrane", priceInr: 1599, priceNote: "Listed price", variant: "20000 mAh 22.5 W",
    specs: { capacityMah: 20000, outputW: 22.5, weightG: 414, extras: "Built-in USB-C cable, BIS certified" },
    sources: [{ title: "Ambrane product page", url: "https://ambraneindia.com/products/stylo-n20" }] },
  { slug: "xiaomi-power-bank-4i-20000", category: "power-banks", name: "Xiaomi Power Bank 4i 20000mAh", brand: "Xiaomi", priceInr: 2199, priceNote: "Street price (MRP ₹3,999)", variant: "20000 mAh 33 W",
    specs: { capacityMah: 20000, outputW: 33, weightG: 440, lengthMm: 150.6, widthMm: 72.2, thicknessMm: 26.3, extras: "1× USB-C, 2× USB-A" },
    sources: [{ title: "Xiaomi India specifications", url: "https://www.mi.com/in/product/xiaomi-power-bank-4i-20000mah-33w-sonic-charge/specs/" }] },
  { slug: "xiaomi-power-bank-5i-20000-67w", category: "power-banks", name: "Xiaomi Power Bank 5i 20000mAh 67W", brand: "Xiaomi", priceInr: 3499, priceNote: "MRP (₹3,299 introductory)", variant: "20000 mAh 67 W", released: "2026-07",
    specs: { capacityMah: 20000, outputW: 67, weightG: 420, lengthMm: 140, widthMm: 72, thicknessMm: 31.2, extras: "Built-in USB-C cable, display" },
    sources: [{ title: "Xiaomi India specifications", url: "https://www.mi.com/in/product/xiaomi-power-bank-5i-20000-67w/specs/" }, { title: "MySmartPrice launch report", url: "https://www.mysmartprice.com/gear/accessories/accessories-news/xiaomi-power-bank-5i-20000-67w-launches-in-india-at-%e2%82%b93499-with-built-in-usb-c-cable-and-67w-fast-charging/" }] },
  { slug: "anker-powercore-20000-30w", category: "power-banks", name: "Anker PowerCore 20000mAh 30W", brand: "Anker", priceInr: 3799, priceNote: "Listed on Amazon India", variant: "A1384",
    specs: { capacityMah: 20000, outputW: 30, weightG: 485, lengthMm: 151, widthMm: 71, thicknessMm: 28, extras: "Display, USB-C cable lanyard" },
    sources: [{ title: "Anker product page", url: "https://anker.com.sg/products/powercore-power-bank-20000mah-30w-portable-charger-with-usb-c-cable-lanyard-a1384" }] },

  // ── Laptops ────────────────────────────────────────────────────────────────────────
  { slug: "acer-swift-lite-14", category: "laptops", name: "Acer Swift Lite 14", brand: "Acer", priceInr: 62999, priceNote: "Launch price (seen lower on Flipkart)", variant: "Core Ultra 5 115U, 16GB, 512GB",
    specs: { cpu: "Intel Core Ultra 5 115U", gb6Multi: 7409, memory: "16 GB LPDDR5, 512 GB SSD", display: "14″ OLED 1920×1200", batteryWh: 50, weightKg: 1.1 },
    sources: [{ title: "MySmartPrice launch report", url: "https://www.mysmartprice.com/gear/laptops-pc/laptops-pc-news/acer-swift-lite-14-brings-copilot-features-starting-at-rs-62999/" }, { title: "LaptopMedia Core Ultra 5 115U", url: "https://laptopmedia.com/in/processor/intel-core-ultra-5-115u/" }] },
  { slug: "asus-vivobook-14-x1407qa", category: "laptops", name: "ASUS Vivobook 14 (Snapdragon X)", brand: "ASUS", priceInr: 65990, priceNote: "Launch price (seen lower on Flipkart)", variant: "X1407QA, 16GB, 512GB",
    specs: { cpu: "Snapdragon X X1-26-100", gb6Multi: 10538, memory: "16 GB LPDDR5X, 512 GB SSD", display: "14″ FHD+ IPS", batteryWh: 50, weightKg: 1.49 },
    sources: [{ title: "Business Today launch report", url: "https://www.businesstoday.in/technology/news/story/asus-vivobook-14-launched-with-snapdragon-chip-16gb-ram-at-rs-65990-check-details-here-485675-2025-07-22" }, { title: "LaptopMedia Snapdragon X X1-26-100", url: "https://laptopmedia.com/processor/qualcomm-snapdragon-x-x1-26-100/" }] },
  { slug: "asus-vivobook-s14-s3407qa", category: "laptops", name: "ASUS Vivobook S14 (Snapdragon X)", brand: "ASUS", priceInr: 65990, priceNote: "Flipkart listing", variant: "S3407QA, 16GB, 512GB",
    specs: { cpu: "Snapdragon X X1-26-100", gb6Multi: 10538, memory: "16 GB, 512 GB SSD", display: "14″", weightKg: 1.35 },
    sources: [{ title: "MySmartPrice listing", url: "https://www.mysmartprice.com/computer/asus-asus-vivobook-s14-s3407qa-kp020ws-laptop-msf1005514" }] },
  { slug: "apple-macbook-air-13-m5", category: "laptops", name: "Apple MacBook Air 13 (M5)", brand: "Apple", priceInr: 119900, priceNote: "Launch price", variant: "16GB, 512GB", released: "2026-03",
    specs: { cpu: "Apple M5", gb6Multi: 17067, memory: "16 GB unified, 512 GB SSD", display: "13.6″ Liquid Retina", batteryWh: 53.8, weightKg: 1.23 },
    sources: [{ title: "ETV Bharat launch report", url: "https://www.etvbharat.com/en/technology/apple-macbook-air-2026-launched-in-india-price-specifications-enn26030401257" }, { title: "Tom's Hardware review", url: "https://tomshardware.com/laptops/macbooks/apple-macbook-air-13-inch-m5-review" }] },
  { slug: "apple-macbook-air-15-m5", category: "laptops", name: "Apple MacBook Air 15 (M5)", brand: "Apple", priceInr: 144900, priceNote: "Launch price", variant: "16GB, 512GB", released: "2026-03",
    specs: { cpu: "Apple M5", gb6Multi: 17067, memory: "16 GB unified, 512 GB SSD", display: "15.3″ Liquid Retina", batteryWh: 66.5, weightKg: 1.51 },
    sources: [{ title: "ETV Bharat launch report", url: "https://www.etvbharat.com/en/technology/apple-macbook-air-2026-launched-in-india-price-specifications-enn26030401257" }] },
];

export const SEED_CHECKED_AT = "2026-10-06";
