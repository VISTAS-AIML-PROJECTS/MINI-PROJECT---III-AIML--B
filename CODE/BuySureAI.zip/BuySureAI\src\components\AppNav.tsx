"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { api } from "@/lib/client-api";

type Item = { href: string; label: string; exact?: boolean };

export function AppNav({ groups, label }: { groups: { title: string; items: Item[] }[]; label: string }) {
  const pathname = usePathname();
  const router = useRouter();
  const signOut = async () => {
    await api("/api/auth/logout", { body: {} });
    router.push("/");
    router.refresh();
  };
  return (
    <nav className="app-nav" aria-label={label}>
      <ul>
        {groups.map((g) => [
          <li key={`g-${g.title}`} className="group" aria-hidden="true">{g.title}</li>,
          ...g.items.map((it) => {
            const current = it.exact ? pathname === it.href : pathname === it.href || pathname.startsWith(`${it.href}/`);
            return (
              <li key={it.href}>
                <Link href={it.href} aria-current={current ? "page" : undefined}>{it.label}</Link>
              </li>
            );
          }),
        ])}
        <li><button className="btn-link" style={{ padding: "9px 10px", color: "var(--ink-2)" }} onClick={signOut}>Sign out</button></li>
      </ul>
    </nav>
  );
}
