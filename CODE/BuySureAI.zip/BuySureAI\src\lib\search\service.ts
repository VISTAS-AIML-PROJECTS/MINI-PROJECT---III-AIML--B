import "server-only";
import { createHash } from "node:crypto";
import { db, now } from "../db";
import { rank } from "../engine/decision";
import { checkPhysics } from "../engine/physics";
import { CATEGORIES, categoryBySlug, type CategoryDef } from "../catalog/categories";
import { categoryItems, allPublished, logSearch } from "../catalog/repo";
import { presetWeights, rankItems, type CatalogItem } from "../catalog/rank";
import { matchProduct, parseQuery } from "../catalog/query";
import { runAgent, type AgentEvent, type AgentInput } from "./agent";
import { geminiEnabled, runGeminiAgent } from "./gemini";
import { env } from "../env";
import { log } from "../logger";
import type { AgentResult } from "./schema";

export type ResultItem = {
  key: string;
  name: string;
  brand: string;
  priceInr: number | null;
  priceNote: string | null;
  isSearched: boolean;
  rank: number;
  score: number;
  keySpecs: { label: string; value: string }[];
  highlights: string[];
  drawbacks: string[];
  sources: { title: string; url: string }[];
  physics: { status: string; notes: string[] };
  catalogSlug: string | null;
  /** Remote product photo found by web search (shown linked to its source). */
  imageUrl?: string | null;
  categorySlug: string | null;
  metrics: Record<string, number | null>;
};

export type SearchResponse = {
  mode: "live" | "catalog";
  query: string;
  understood: { searchedProduct: string | null; categoryName: string; categorySlug: string | null; budget: number | null; intent: string };
  criteria: { key: string; label: string; direction: "higher" | "lower"; unit: string }[];
  weights: Record<string, number>;
  items: ResultItem[];
  verdict: string;
  caveats: string[];
  generatedAt: string;
  cached?: boolean;
};

const CACHE_HOURS = 24;
const safeUrl = (u: string) => /^https?:\/\/[^\s"<>]+$/i.test(u) && u.length < 2000;

export function cacheKey(query: string, imageBase64: string | null) {
  return createHash("sha256").update(query.trim().toLowerCase()).update("|").update(imageBase64 ? createHash("sha256").update(imageBase64).digest("hex") : "").digest("hex");
}

async function readCache(key: string): Promise<SearchResponse | null> {
  const row = await db.get<{ result_json: string; created_at: string }>("SELECT result_json, created_at FROM search_cache WHERE key = ?", key);
  if (!row || Date.parse(row.created_at) < Date.now() - CACHE_HOURS * 3600_000) return null;
  return { ...(JSON.parse(row.result_json) as SearchResponse), cached: true };
}

async function writeCache(key: string, query: string, res: SearchResponse) {
  await db.run(
    "INSERT INTO search_cache (key, query, result_json, created_at) VALUES (?, ?, ?, ?) ON CONFLICT(key) DO UPDATE SET result_json = excluded.result_json, created_at = excluded.created_at",
    key, query.slice(0, 300), JSON.stringify(res), now(),
  );
  await db.run("DELETE FROM search_cache WHERE created_at < ?", new Date(Date.now() - 7 * 86400_000).toISOString());
}

// ── Catalogue mode ─────────────────────────────────────────────────────────────────────────

export async function catalogSearch(rawQuery: string): Promise<SearchResponse> {
  const pq = parseQuery(rawQuery);
  const all = await allPublished();
  const matched = matchProduct(pq.terms, all);
  const def: CategoryDef | null = matched ? categoryBySlug(matched.item.category) ?? null : pq.category;

  if (!def) {
    return {
      mode: "catalog", query: rawQuery,
      understood: { searchedProduct: null, categoryName: "Unknown", categorySlug: null, budget: pq.budget, intent: rawQuery },
      criteria: [], weights: {}, items: [], generatedAt: now(),
      verdict: "",
      caveats: [`Our verified catalogue covers ${CATEGORIES.map((c) => c.name.toLowerCase()).join(", ")}. Live web search handles every other product.`],
    };
  }

  const weights = presetWeights(def, pq.preset);
  let pool = await categoryItems(def.slug);
  const budget = pq.budget ?? (matched ? Math.ceil((matched.item.priceInr * 1.25) / 1000) * 1000 : null);
  if (budget) {
    const within = pool.filter((p) => p.priceInr <= budget);
    if (within.length >= 2) pool = within;
  }
  if (matched && !pool.some((p) => p.id === matched.item.id)) pool.push(matched.item);
  const ranked = rankItems(def, pool, weights);

  const items: ResultItem[] = ranked.slice(0, 8).map((r) => ({
    key: r.id, name: r.name, brand: r.brand, priceInr: r.priceInr, priceNote: [r.variant, r.priceNote].filter(Boolean).join(" · "),
    isSearched: matched?.item.id === r.id, rank: r.rank, score: r.score, keySpecs: def.keySpecs(r.specs).filter((k) => k.value && k.value !== "—"),
    highlights: r.reasons, drawbacks: r.weaknesses, sources: r.sources,
    physics: { status: r.physics.status, notes: r.physics.findings.map((f) => f.message) },
    catalogSlug: r.slug, categorySlug: def.slug, metrics: r.metrics,
  }));
  const top = items.find((i) => i.physics.status !== "fail");
  const searched = items.find((i) => i.isSearched);
  let verdict = top ? `${top.name} ranks first for ${pq.preset ? def.presets.find((p) => p.key === pq.preset)!.label.toLowerCase() : "a balanced shopper"}${budget ? ` under ₹${budget.toLocaleString("en-IN")}` : ""}.` : "";
  if (searched && top && searched.key !== top.key) verdict += ` The ${searched.name} you searched for ranks #${searched.rank} of ${items.length}.`;
  if (searched && top && searched.key === top.key) verdict += " That's the one you searched for: good pick.";

  return {
    mode: "catalog", query: rawQuery,
    understood: { searchedProduct: matched?.item.name ?? null, categoryName: def.name, categorySlug: def.slug, budget, intent: rawQuery },
    criteria: def.criteria.map(({ key, label, direction, unit }) => ({ key, label, direction, unit: unit ?? "" })),
    weights, items, verdict, generatedAt: now(),
    caveats: ["From BuySure's verified catalogue (prices checked on the date shown). Turn on live search to cover every product sold online."],
  };
}

// ── Live mode ──────────────────────────────────────────────────────────────────────────────

export async function fromAgent(query: string, a: AgentResult): Promise<SearchResponse> {
  const def = a.understood.category_slug !== "other" ? categoryBySlug(a.understood.category_slug) ?? null : null;
  const criteria = def
    ? def.criteria.map(({ key, label, direction, unit }) => ({ key, label, direction, unit: unit ?? "" }))
    : [
        { key: "price", label: "Price", direction: "lower" as const, unit: "₹" },
        // Star ratings and review counts are what review farms inflate: BuySure ranks on measurable specs only.
        ...a.criteria.filter((c) => c.key !== "price" && !/rating|review|star|popular/i.test(`${c.key} ${c.label}`)).slice(0, 6).map((c) => ({ key: c.key, label: c.label, direction: c.direction, unit: c.unit })),
      ];
  const agentWeights = Object.fromEntries(a.criteria.map((c) => [c.key, Math.max(0, Math.min(10, c.weight))]));
  const base = def ? presetWeights(def, null) : {};
  const weights: Record<string, number> = {};
  for (const c of criteria) weights[c.key] = agentWeights[c.key] ?? base[c.key] ?? (c.key === "price" ? 7 : 5);

  const catalog = await allPublished();
  const products: (AgentResult["products"][number] & { catalogItem?: CatalogItem })[] = a.products.slice(0, 8);

  // The product the shopper pointed at must be marked even if the model forgot to flag it.
  if (a.understood.searched_product && !products.some((p) => p.is_searched_product)) {
    const hit = matchProduct(a.understood.searched_product.toLowerCase().split(/\s+/), products);
    if (hit) hit.item.is_searched_product = true;
  }

  // For categories BuySure verifies, merge in current catalogue products so the newest verified
  // models always compete, even when the research model's knowledge is a little dated.
  let budget = a.understood.budget_inr;
  const searchedPrice = products.find((p) => p.is_searched_product)?.price_inr;
  if (!budget && searchedPrice) budget = Math.ceil((searchedPrice * 1.25) / 1000) * 1000;
  let mergedFromCatalogue = 0;
  if (def) {
    let pool = await categoryItems(def.slug);
    if (budget) { const within = pool.filter((i) => i.priceInr <= budget!); if (within.length >= 2) pool = within; }
    const ranked0 = rankItems(def, pool, presetWeights(def, null)).filter((r) => r.physics.status !== "fail");
    for (const r of ranked0) {
      if (products.length >= 10 || mergedFromCatalogue >= 5) break;
      const dup = matchProduct(`${r.brand} ${r.name}`.toLowerCase().split(/\s+/), products);
      if (dup) {
        // Same product found by research: prefer the verified catalogue numbers.
        dup.item.catalogItem = r;
        continue;
      }
      products.push({
        name: r.name, brand: r.brand, is_searched_product: false, price_inr: r.priceInr,
        price_note: [r.variant, r.priceNote, `BuySure verified ${r.checkedAt}`].filter(Boolean).join(" · "),
        metrics: [], key_specs: def.keySpecs(r.specs).filter((k) => k.value && k.value !== "—"),
        battery_mah: null, weight_g: null, length_mm: null, width_mm: null, thickness_mm: null,
        highlights: r.reasons, drawbacks: r.weaknesses, sources: r.sources, catalogItem: r,
      });
      mergedFromCatalogue++;
    }
  }

  const prepared = products.map((p, i) => {
    if (p.catalogItem && def) {
      const c = p.catalogItem;
      const metrics = def.metrics(c.specs, c.priceInr);
      const physics = checkPhysics(def.physics, def.physicsSpecs(c.specs) as never, {}, c.priceInr);
      return { p: { ...p, price_inr: p.price_inr ?? c.priceInr, sources: p.sources.length ? p.sources : c.sources }, key: `live-${i}`, metrics, physics };
    }
    const metrics: Record<string, number | null> = { price: p.price_inr };
    for (const m of p.metrics) if (m.key !== "price") metrics[m.key] = m.value;
    const physics = checkPhysics(
      def?.physics ?? "other",
      { batteryMah: p.battery_mah ?? undefined, weightG: p.weight_g ?? undefined, lengthMm: p.length_mm ?? undefined, widthMm: p.width_mm ?? undefined, thicknessMm: p.thickness_mm ?? undefined },
      {}, p.price_inr ?? undefined,
    );
    return { p, key: `live-${i}`, metrics, physics };
  });
  const anyPrice = prepared.some((x) => x.p.price_inr !== null);
  const ranked = rank(
    prepared.map((x) => ({
      id: x.key, name: x.p.name, metrics: x.metrics,
      // Missing price only sinks a product when others do have verified prices.
      disqualified: x.physics.status === "fail" ? "Specs fail a physics check" : x.p.price_inr === null && anyPrice ? "No Indian price found" : null,
    })),
    criteria, weights,
  );
  const byKey = new Map(prepared.map((x) => [x.key, x]));

  const items: ResultItem[] = ranked.map((r) => {
    const x = byKey.get(r.id)!;
    const cat = matchProduct(`${x.p.brand} ${x.p.name}`.toLowerCase().split(/\s+/), catalog);
    return {
      key: r.id, name: x.p.name, brand: x.p.brand, priceInr: x.p.price_inr, priceNote: x.p.price_note, isSearched: x.p.is_searched_product,
      rank: r.rank, score: r.score, keySpecs: x.p.key_specs.slice(0, 6), highlights: x.p.highlights.slice(0, 3), drawbacks: x.p.drawbacks.slice(0, 2),
      sources: x.p.sources.filter((s) => safeUrl(s.url)).slice(0, 3),
      physics: { status: x.physics.status, notes: x.physics.findings.map((f) => f.message) },
      catalogSlug: cat?.item.slug ?? null, categorySlug: def?.slug ?? null, metrics: x.metrics,
      imageUrl: x.p.image_url && safeUrl(x.p.image_url) ? x.p.image_url : null,
    };
  });

  // Verdict is computed from the final ranking, so it always agrees with what is shown.
  const winner = items.find((i) => !i.physics.notes.length && i.priceInr !== null) ?? items[0];
  const searched = items.find((i) => i.isSearched);
  const fmt = (n: number) => `₹${n.toLocaleString("en-IN")}`;
  let verdict = winner ? `${winner.name} is the best pick${budget ? ` under ${fmt(budget)}` : ""} on the criteria shown.` : a.verdict;
  if (searched && winner && searched.key !== winner.key) verdict += ` The ${searched.name} you asked about ranks #${searched.rank} of ${items.length}.`;
  if (searched && winner && searched.key === winner.key) verdict += " That's the one you asked about: good choice.";
  const caveats = a.caveats.slice(0, 3);
  if (mergedFromCatalogue) caveats.push(`Includes ${mergedFromCatalogue} product${mergedFromCatalogue === 1 ? "" : "s"} from BuySure's verified catalogue alongside live web research.`);

  return {
    mode: "live", query,
    understood: { searchedProduct: searched?.name ?? a.understood.searched_product, categoryName: def?.name ?? a.understood.category_name, categorySlug: def?.slug ?? null, budget, intent: a.understood.intent },
    criteria, weights, items, verdict, caveats, generatedAt: now(),
  };
}

export async function liveSearch(input: AgentInput, onEvent: (e: AgentEvent) => void, signal: AbortSignal): Promise<SearchResponse> {
  const key = cacheKey(input.query, input.image?.base64 ?? null);
  const cached = await readCache(key);
  if (cached) return cached;
  const agentResult = await research(input, onEvent, signal);
  if (input.url && !agentResult.products.some((p) => p.is_searched_product)) {
    const words = parseQuery(input.url).url?.words ?? [];
    const hit = matchProduct(words, agentResult.products);
    if (hit) { hit.item.is_searched_product = true; agentResult.understood.searched_product ??= `${hit.item.brand} ${hit.item.name}`; }
  }
  const result = await fromAgent(input.query || "Photo search", agentResult);
  // Only cache answers worth repeating: at least two products with a verified price.
  if (result.items.filter((i) => i.priceInr !== null).length >= 2) await writeCache(key, input.query || "photo", result);
  await logSearch(input.query || "[photo]", result.understood.categoryName, result.understood.budget, result.items.length);
  return result;
}

/** Live research is available when either engine has a key. */
export const liveSearchEnabled = () => geminiEnabled() || Boolean(env.ANTHROPIC_API_KEY);

/** Tries the preferred engine, then the other one, so a quota or billing problem in one does not break search. */
async function research(input: AgentInput, onEvent: (e: AgentEvent) => void, signal: AbortSignal) {
  const engines: { name: string; run: typeof runAgent }[] = [];
  const gemini = { name: "gemini", run: runGeminiAgent };
  const claude = { name: "anthropic", run: runAgent };
  if (env.SEARCH_PROVIDER === "anthropic") engines.push(claude, gemini);
  else engines.push(gemini, claude);
  const usable = engines.filter((e) => (e.name === "gemini" ? geminiEnabled() : Boolean(env.ANTHROPIC_API_KEY)));
  let lastErr: unknown;
  for (const e of usable) {
    try {
      return await e.run(input, onEvent, signal);
    } catch (err) {
      lastErr = err;
      if (signal.aborted) break;
      log.warn("research engine failed, trying fallback", { engine: e.name, error: (err as Error).message?.slice(0, 200) });
    }
  }
  throw lastErr instanceof Error ? lastErr : new Error("No research engine is configured.");
}

export { parseQuery };
