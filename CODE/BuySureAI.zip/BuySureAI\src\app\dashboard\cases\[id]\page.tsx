import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { requireUser } from "@/lib/auth/guard";
import { caseView, getOwnedCase, latestAudit, listProducts } from "@/lib/repos/cases";
import { narrativeEnabled } from "@/lib/llm";
import { site } from "@/lib/site";
import { CaseWorkspace } from "./CaseWorkspace";

export const metadata: Metadata = { title: "Case" };

export default async function CasePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = await requireUser(`/dashboard/cases/${id}`);
  let row;
  try {
    row = await getOwnedCase(id, user.id);
  } catch {
    notFound();
  }
  return (
    <CaseWorkspace
      initialCase={caseView(row)}
      initialProducts={await listProducts(row.id)}
      initialAudit={await latestAudit(row.id)}
      narrativeAvailable={narrativeEnabled()}
      siteUrl={site.url}
    />
  );
}
