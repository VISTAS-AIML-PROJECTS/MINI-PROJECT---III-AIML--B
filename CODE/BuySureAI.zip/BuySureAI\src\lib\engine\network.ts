import type { Finding, ProductInput } from "./types";
import { UnionFind } from "./text";

export type NetworkNode = { id: string; label: string; kind: "product" | "seller" | "manufacturer" | "importer" | "address" };
export type NetworkReport = {
  nodes: NetworkNode[];
  edges: { source: string; target: string }[];
  groups: { productIds: string[]; sharedBy: string[] }[];
  findings: Finding[];
};

const SUFFIXES =
  /\b(private|pvt|limited|ltd|llp|inc|co|company|corp|corporation|enterprises?|industries|technology|technologies|tech|india|international|trading|traders)\b/g;

export function normaliseEntity(name: string) {
  return name
    .toLowerCase()
    .normalize("NFKC")
    .replace(/[.,()&'"-]/g, " ")
    .replace(SUFFIXES, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/** Address fingerprint: 6-digit PIN code plus the first three meaningful words. */
export function addressKey(addr: string) {
  const pin = /\b\d{6}\b/.exec(addr)?.[0] ?? "";
  const words = addr
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter((w) => w.length > 2 && !/^\d+$/.test(w))
    .slice(0, 3);
  return pin ? `${pin} ${words.join(" ")}` : "";
}

/**
 * Links listings that share a manufacturer, importer, or registered seller address. This is how
 * white-labelled products sold under different brand names show up.
 */
export function mapNetwork(products: ProductInput[]): NetworkReport {
  const nodes = new Map<string, NetworkNode>();
  const edges: NetworkReport["edges"] = [];
  const entityToProducts = new Map<string, { label: string; idx: number[] }>();

  products.forEach((p, i) => {
    nodes.set(`p:${p.id}`, { id: `p:${p.id}`, label: p.name, kind: "product" });
    const ents: [NetworkNode["kind"], string | null | undefined, (s: string) => string][] = [
      ["seller", p.seller, normaliseEntity],
      ["manufacturer", p.manufacturer, normaliseEntity],
      ["importer", p.importer, normaliseEntity],
      ["address", p.sellerAddress, addressKey],
    ];
    for (const [kind, raw, norm] of ents) {
      if (!raw?.trim()) continue;
      const key = norm(raw);
      if (!key) continue;
      const id = `${kind}:${key}`;
      if (!nodes.has(id)) nodes.set(id, { id, label: raw.trim(), kind });
      edges.push({ source: `p:${p.id}`, target: id });
      if (!entityToProducts.has(id)) entityToProducts.set(id, { label: raw.trim(), idx: [] });
      entityToProducts.get(id)!.idx.push(i);
    }
  });

  const uf = new UnionFind(products.length);
  const linkReasons = new Map<number, Set<string>>();
  for (const [id, { label, idx }] of entityToProducts) {
    // Two listings from the same marketplace seller is normal, so sellers alone never link products.
    if (idx.length < 2 || id.startsWith("seller:")) continue;
    for (let k = 1; k < idx.length; k++) uf.union(idx[0], idx[k]);
    for (const i of idx) {
      if (!linkReasons.has(i)) linkReasons.set(i, new Set());
      linkReasons.get(i)!.add(`${id.split(":")[0]} "${label}"`);
    }
  }

  const findings: Finding[] = [];
  const groups = uf
    .groups()
    .filter((g) => g.length >= 2)
    .map((g) => {
      const shared = new Set<string>();
      g.forEach((i) => linkReasons.get(i)?.forEach((r) => shared.add(r)));
      return { idx: g, productIds: g.map((i) => products[i].id), sharedBy: [...shared] };
    });

  for (const g of groups) {
    const brands = new Set(g.idx.map((i) => (products[i].brand || products[i].name).toLowerCase().trim()));
    if (brands.size >= 2) {
      findings.push({
        module: "network",
        severity: "info",
        code: "NETWORK_WHITE_LABEL",
        message: `${g.idx.map((i) => products[i].name).join(" and ")} are sold under different brands but share ${g.sharedBy.join(", ")}. They may be the same product at different markups; compare their prices directly.`,
      });
    }
  }

  return {
    nodes: [...nodes.values()],
    edges,
    groups: groups.map(({ productIds, sharedBy }) => ({ productIds, sharedBy })),
    findings,
  };
}
