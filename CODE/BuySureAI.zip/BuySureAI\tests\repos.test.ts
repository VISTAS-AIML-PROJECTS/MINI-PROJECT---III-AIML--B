import { beforeEach, describe, expect, it } from "vitest";
import { resetDbForTests, db } from "@/lib/db";
import { createUser, deleteUser, exportUserData } from "@/lib/repos/users";
import { createCase, createProduct, engineInputs, getOwnedCase, getOwnedProduct, importReviews, saveAudit, latestAudit, setShare, getCaseBySlug } from "@/lib/repos/cases";
import { addObservation, createWatch, evaluateWatch, getOwnedWatch } from "@/lib/repos/watches";
import { listNotifications, upsertSiteReview, approvedSiteReviews, moderateSiteReview, listUsers } from "@/lib/repos/misc";
import { rateLimit } from "@/lib/rate-limit";
import { runAudit } from "@/lib/engine";
import { ApiError } from "@/lib/api";

let alice: string, bob: string;

beforeEach(async () => {
  await resetDbForTests();
  alice = await createUser({ email: "alice@example.com", name: "Alice", passwordHash: "x" });
  bob = await createUser({ email: "bob@example.com", name: "Bob", passwordHash: "x" });
});

describe("ownership (IDOR protection)", () => {
  it("lets the owner read a case and hides it from everyone else", async () => {
    const id = await createCase(alice, { title: "Phones", category: "phone" });
    expect((await getOwnedCase(id, alice)).title).toBe("Phones");
    await expect(getOwnedCase(id, bob)).rejects.toThrow(ApiError);
  });

  it("hides another user's products and watches", async () => {
    const c = await createCase(alice, { title: "Phones", category: "phone" });
    const p = await createProduct(c, { name: "P", priceInr: 100, specs: {}, certified: {}, scores: {}, cost: {} });
    await expect(getOwnedProduct(p, bob)).rejects.toThrow(ApiError);
    const w = await createWatch(alice, { productName: "P", targetPriceInr: 100 });
    await expect(getOwnedWatch(w, bob)).rejects.toThrow(ApiError);
  });
});

describe("cases, reviews and audits", () => {
  it("stores products and reviews and feeds them to the engine", async () => {
    const c = await createCase(alice, { title: "Phones", category: "phone" });
    const p = await createProduct(c, { name: "P", priceInr: 15000, specs: { batteryMah: 5000 }, certified: {}, scores: {}, cost: {} });
    await importReviews(p, Array.from({ length: 6 }, (_, i) => ({ rating: 4, body: `Decent phone number ${i}`, postedAt: "2026-08-01" })), false);
    const inputs = await engineInputs(c);
    expect(inputs[0].reviews).toHaveLength(6);
    const report = runAudit({ category: "phone", products: inputs });
    await saveAudit(c, report);
    expect((await latestAudit(c))!.report.products[0].name).toBe("P");
    expect((await db.get<{ n: number }>("SELECT COUNT(*) AS n FROM audit_findings"))!.n).toBeGreaterThanOrEqual(0);
  });

  it("replaces reviews when asked and enforces the per-product cap", async () => {
    const c = await createCase(alice, { title: "Phones", category: "phone" });
    const p = await createProduct(c, { name: "P", priceInr: 1, specs: {}, certified: {}, scores: {}, cost: {} });
    await importReviews(p, [{ rating: 5, body: "a" }], false);
    expect(await importReviews(p, [{ rating: 4, body: "b" }], true)).toBe(1);
  });

  it("caps products per case at 12", async () => {
    const c = await createCase(alice, { title: "Phones", category: "phone" });
    for (let i = 0; i < 12; i++) await createProduct(c, { name: `P${i}`, priceInr: 1, specs: {}, certified: {}, scores: {}, cost: {} });
    await expect(createProduct(c, { name: "P13", priceInr: 1, specs: {}, certified: {}, scores: {}, cost: {} })).rejects.toThrow(/at most 12/);
  });

  it("creates and revokes share links", async () => {
    const c = await createCase(alice, { title: "Phones", category: "phone" });
    const slug = (await setShare(await getOwnedCase(c, alice), true))!;
    expect((await getCaseBySlug(slug))!.id).toBe(c);
    await setShare(await getOwnedCase(c, alice), false);
    expect(await getCaseBySlug(slug)).toBeUndefined();
    expect(await getCaseBySlug("../../etc")).toBeUndefined();
  });

  it("cascades all user data on account deletion", async () => {
    const c = await createCase(alice, { title: "Phones", category: "phone" });
    const p = await createProduct(c, { name: "P", priceInr: 1, specs: {}, certified: {}, scores: {}, cost: {} });
    await importReviews(p, [{ rating: 5, body: "a" }], false);
    await createWatch(alice, { productName: "P", targetPriceInr: 1 });
    expect((await exportUserData(alice)).cases).toHaveLength(1);
    await deleteUser(alice);
    for (const t of ["cases", "products", "reviews", "price_watches"]) {
      expect((await db.get<{ n: number }>(`SELECT COUNT(*) AS n FROM ${t}`))!.n).toBe(0);
    }
  });
});

describe("price watches", () => {
  it("fires exactly once when the target is reached", async () => {
    const id = await createWatch(alice, { productName: "Phone", targetPriceInr: 15000 });
    const w = await getOwnedWatch(id, alice);
    await addObservation(w, { priceInr: 16000, observedAt: "2026-09-01T00:00:00Z" });
    expect(await evaluateWatch(id)).toBe(false);
    await addObservation(w, { priceInr: 14900, observedAt: "2026-09-02T00:00:00Z" });
    expect(await evaluateWatch(id)).toBe(true);
    expect(await evaluateWatch(id)).toBe(false);
    expect(await listNotifications(alice)).toHaveLength(1);
  });
});

describe("site reviews moderation", () => {
  it("shows only approved reviews", async () => {
    await upsertSiteReview(alice, { rating: 4, body: "Useful for spotting fake reviews", displayName: "A" });
    expect(await approvedSiteReviews()).toHaveLength(0);
    const id = (await db.get<{ id: string }>("SELECT id FROM site_reviews"))!.id;
    await moderateSiteReview(id, "approved", bob);
    expect(await approvedSiteReviews()).toHaveLength(1);
    await upsertSiteReview(alice, { rating: 2, body: "Changed my mind about this tool", displayName: "A" });
    expect(await approvedSiteReviews()).toHaveLength(0); // edits go back to moderation
  });
});

describe("admin search", () => {
  it("escapes LIKE wildcards so % does not match everything", async () => {
    expect((await listUsers("%", 1)).total).toBe(0);
    expect((await listUsers("alice", 1)).total).toBe(1);
  });
});

describe("rate limiting", () => {
  it("blocks after the limit within the window", async () => {
    for (let i = 0; i < 3; i++) expect((await rateLimit("t", 3, 60)).ok).toBe(true);
    const r = await rateLimit("t", 3, 60);
    expect(r.ok).toBe(false);
  });
});

describe("transactions", () => {
  it("supports nesting and rolls back inner failures only", async () => {
    await db.transaction(async () => {
      await createCase(alice, { title: "Outer", category: "phone" });
      await expect(db.transaction(async () => {
        await createCase(alice, { title: "Inner", category: "phone" });
        throw new Error("boom");
      })).rejects.toThrow("boom");
    });
    const titles = (await db.all<{ title: string }>("SELECT title FROM cases")).map((r) => r.title);
    expect(titles).toEqual(["Outer"]);
  });
});
