import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Breadcrumbs } from "@/components/Breadcrumbs";
import { ProductCard } from "@/components/shop/ProductCard";
import { ProductVisual } from "@/components/shop/ProductVisual";
import { Stamp } from "@/components/report/ReportView";
import { categoryBySlug } from "@/lib/catalog/categories";
import { allPublished, categoryItems, productBySlug } from "@/lib/catalog/repo";
import { presetWeights, rankItems } from "@/lib/catalog/rank";
import { date, inr } from "@/lib/format";
import { JsonLd, pageMeta } from "@/lib/seo";
import { absoluteUrl } from "@/lib/site";

export const revalidate = 600;
export const generateStaticParams = async () => (await allPublished()).map((p) => ({ slug: p.slug }));

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const p = await productBySlug((await params).slug);
  if (!p) return {};
  return pageMeta({
    title: `${p.name}: is it worth buying?`,
    description: `${p.name} at ${inr(p.priceInr)}: how it ranks against the best ${categoryBySlug(p.category)?.name.toLowerCase() ?? "alternatives"} on price, specs and verified claims, with sources.`,
    path: `/p/${p.slug}`,
  });
}

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const p = await productBySlug((await params).slug);
  if (!p) notFound();
  const def = categoryBySlug(p.category)!;
  const all = rankItems(def, await categoryItems(def.slug), presetWeights(def, "balanced"));
  const me = all.find((r) => r.id === p.id)!;
  // Peers: products within ±40% of this price, ranked among themselves.
  const peers = rankItems(def, (await categoryItems(def.slug)).filter((x) => x.priceInr <= p.priceInr * 1.4 && x.priceInr >= p.priceInr * 0.6), presetWeights(def, "balanced"));
  const myPeerRank = peers.find((r) => r.id === p.id)!;
  const betterCheaper = peers.filter((r) => r.score > myPeerRank.score && r.priceInr <= p.priceInr && r.id !== p.id);
  const q = encodeURIComponent(`${p.brand} ${p.name}`);

  return (
    <div className="wrap" style={{ paddingBottom: 96 }}>
      <Breadcrumbs items={[{ name: `Best ${def.name.toLowerCase()}`, path: `/best/${def.slug}` }, { name: p.name, path: `/p/${p.slug}` }]} />
      <article className="winner" style={{ border: "1px solid var(--rule)" }}>
        <div className="visual"><ProductVisual category={def.slug} brand={p.brand} name={p.name} imagePath={p.imagePath} /></div>
        <div>
          <span className="eyebrow" style={{ marginBottom: 4 }}>{p.brand}</span>
          <h1 style={{ fontSize: "var(--step-3)", margin: "0 0 6px" }}>{p.name}</h1>
          <div style={{ fontSize: "1.5rem", fontWeight: 600 }}>{inr(p.priceInr)}</div>
          <div className="small muted">{[p.variant, p.priceNote, `checked ${date(p.checkedAt)}`].filter(Boolean).join(" · ")}</div>
          <p style={{ marginTop: 14 }}>
            <strong>Verdict:</strong> ranks <strong>#{myPeerRank.rank} of {peers.length}</strong> among {def.name.toLowerCase()} priced {inr(Math.round(p.priceInr * 0.6))}–{inr(Math.round(p.priceInr * 1.4))}
            {" "}and #{me.rank} of {all.length} overall (score {me.score.toFixed(0)}/100).
            {betterCheaper.length ? ` ${betterCheaper[0].name} scores higher for ${betterCheaper[0].priceInr < p.priceInr ? "less money" : "the same money"}.` : " Nothing at this price or lower beats it on our criteria."}
          </p>
          <ul className="pluses">{me.reasons.map((r, i) => <li key={i}>{r}</li>)}{me.weaknesses.map((r, i) => <li key={`w${i}`} className="minus">{r}</li>)}</ul>
          <div className="btn-row" style={{ marginTop: 16 }}>
            <a className="btn btn-small" href={`https://www.amazon.in/s?k=${q}`} target="_blank" rel="noopener noreferrer nofollow">Check price on Amazon</a>
            <a className="btn btn-secondary btn-small" href={`https://www.flipkart.com/search?q=${q}`} target="_blank" rel="noopener noreferrer nofollow">Check on Flipkart</a>
            <Link className="btn btn-secondary btn-small" href={`/search?q=${q}`}>Live price research</Link>
          </div>
        </div>
      </article>

      <div className="grid-2" style={{ gap: 40, alignItems: "start" }}>
        <section aria-labelledby="specs-title">
          <h2 id="specs-title" style={{ fontSize: "var(--step-2)" }}>Key specs</h2>
          <dl className="kv">{def.keySpecs(p.specs).map((k) => <FragmentRow key={k.label} k={k.label} v={k.value} />)}</dl>
          <h2 style={{ fontSize: "var(--step-2)", marginTop: 32 }}>How the score is built</h2>
          <div className="table-wrap">
            <table>
              <thead><tr><th scope="col">Criterion</th><th scope="col" className="num">Value</th><th scope="col" className="num">Points</th></tr></thead>
              <tbody>
                {def.criteria.map((c) => {
                  const contrib = me.contributions.find((x) => x.key === c.key);
                  const v = me.metrics[c.key];
                  return (
                    <tr key={c.key}>
                      <td>{c.label}<div className="small muted">{c.how}</div></td>
                      <td className="num">{v === null || v === undefined ? "not published" : c.key === "price" ? inr(v) : `${v.toLocaleString("en-IN")} ${c.unit ?? ""}`}</td>
                      <td className="num">{contrib ? contrib.points.toFixed(1) : "–"}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>
        <section aria-labelledby="checks-title">
          <h2 id="checks-title" style={{ fontSize: "var(--step-2)" }}>Spec checks</h2>
          <ul className="findings" style={{ listStyle: "none", padding: 0 }}>
            {me.physics.checks.map((c) => (
              <li key={c.code} style={{ display: "grid", gridTemplateColumns: "92px 1fr", gap: 10, padding: "10px 0", borderBottom: "1px solid var(--rule)" }}>
                <Stamp kind={c.code.startsWith("INFO_") ? "info" : c.status} /><span className="small"><strong>{c.label}.</strong> {c.detail}</span>
              </li>
            ))}
          </ul>
          <h2 style={{ fontSize: "var(--step-2)", marginTop: 32 }}>Sources</h2>
          <ul className="small">{p.sources.map((s, i) => <li key={i}><a href={s.url} target="_blank" rel="noopener noreferrer nofollow">{s.title}</a></li>)}</ul>
        </section>
      </div>

      <section className="rail" style={{ marginTop: 40 }} aria-labelledby="alt-title">
        <div className="rail-head"><h2 id="alt-title">Compare with nearby options</h2><Link href={`/best/${def.slug}`}>All {def.name.toLowerCase()} →</Link></div>
        <div className="cards">
          {peers.filter((r) => r.id !== p.id).slice(0, 4).map((r) => (
            <ProductCard key={r.id} href={`/p/${r.slug}`} category={def.slug} brand={r.brand} name={r.name} priceInr={r.priceInr} badge={`#${r.rank} here`} score={r.score} why={r.reasons[0] ?? null} imagePath={r.imagePath} />
          ))}
        </div>
      </section>
      <JsonLd data={{
        "@context": "https://schema.org", "@type": "Product", name: p.name, brand: { "@type": "Brand", name: p.brand },
        url: absoluteUrl(`/p/${p.slug}`),
        offers: { "@type": "Offer", price: p.priceInr, priceCurrency: "INR", url: absoluteUrl(`/p/${p.slug}`) },
      }} />
    </div>
  );
}

function FragmentRow({ k, v }: { k: string; v: string }) {
  return (<><dt>{k}</dt><dd>{v || "—"}</dd></>);
}
