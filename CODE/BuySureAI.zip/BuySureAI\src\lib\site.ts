/**
 * Public site configuration. NEXT_PUBLIC_* values are inlined into client bundles at build
 * time, so nothing secret belongs here.
 */
export const site = {
  name: "BuySure AI",
  shortName: "BuySure",
  url: (process.env.NEXT_PUBLIC_SITE_URL ?? process.env.APP_URL ?? "http://localhost:3000").replace(/\/$/, ""),
  tagline: "Purchase forensics for online shoppers",
  description:
    "BuySure AI audits product listings before you buy: review-integrity forensics, physics and certification checks on advertised specs, true cost of ownership, and a weighted verdict you control.",
  contactEmail: process.env.NEXT_PUBLIC_CONTACT_EMAIL || null,
  /** Optional registered office. When set, the contact page shows it with a directions link. */
  businessAddress: process.env.NEXT_PUBLIC_BUSINESS_ADDRESS || null,
  /** Promise shown on the contact page. Change it only if your team can keep it. */
  responseTime: "We reply to every message within 2 business days.",
  gaId: process.env.NEXT_PUBLIC_GA_ID || null,
  locale: "en_IN",
};

export const absoluteUrl = (path = "/") => `${site.url}${path.startsWith("/") ? path : `/${path}`}`;
