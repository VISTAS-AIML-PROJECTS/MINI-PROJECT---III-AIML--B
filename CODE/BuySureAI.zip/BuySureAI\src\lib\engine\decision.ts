import type { Category, Criterion } from "./types";

/**
 * Weighted decision matrix. Pure and cheap, so the report page re-runs it in the browser every
 * time the user moves a weight slider.
 */

export const CRITERIA: Record<Category, Criterion[]> = {
  phone: [
    { key: "price", label: "Effective price", direction: "lower", unit: "₹" },
    { key: "integrity", label: "Integrity", direction: "higher", unit: "/100" },
    { key: "battery", label: "Battery", direction: "higher", unit: "Wh" },
    { key: "performance", label: "Performance", direction: "higher", unit: "benchmark" },
    { key: "camera", label: "Camera", direction: "higher", unit: "/10" },
    { key: "display", label: "Display", direction: "higher", unit: "/10" },
    { key: "software", label: "Software", direction: "higher", unit: "/10" },
  ],
  powerbank: [
    { key: "price", label: "Effective price", direction: "lower", unit: "₹" },
    { key: "integrity", label: "Integrity", direction: "higher", unit: "/100" },
    { key: "battery", label: "Capacity", direction: "higher", unit: "Wh" },
    { key: "charging", label: "Output power", direction: "higher", unit: "W" },
    { key: "weight", label: "Weight", direction: "lower", unit: "g" },
  ],
  laptop: [
    { key: "price", label: "Effective price", direction: "lower", unit: "₹" },
    { key: "integrity", label: "Integrity", direction: "higher", unit: "/100" },
    { key: "performance", label: "Performance", direction: "higher", unit: "benchmark" },
    { key: "battery", label: "Battery", direction: "higher", unit: "Wh" },
    { key: "display", label: "Display", direction: "higher", unit: "/10" },
    { key: "weight", label: "Weight", direction: "lower", unit: "g" },
  ],
  earbuds: [
    { key: "price", label: "Effective price", direction: "lower", unit: "₹" },
    { key: "integrity", label: "Integrity", direction: "higher", unit: "/100" },
    { key: "audio", label: "Sound", direction: "higher", unit: "/10" },
    { key: "anc", label: "Noise cancelling", direction: "higher", unit: "/10" },
    { key: "battery", label: "Battery", direction: "higher", unit: "Wh" },
  ],
  storage: [
    { key: "price", label: "Effective price", direction: "lower", unit: "₹" },
    { key: "integrity", label: "Integrity", direction: "higher", unit: "/100" },
    { key: "capacity", label: "Capacity", direction: "higher", unit: "GB" },
    { key: "speed", label: "Speed", direction: "higher", unit: "MB/s" },
  ],
  other: [
    { key: "price", label: "Effective price", direction: "lower", unit: "₹" },
    { key: "integrity", label: "Integrity", direction: "higher", unit: "/100" },
    { key: "quality", label: "Quality", direction: "higher", unit: "/10" },
  ],
};

export const DEFAULT_WEIGHTS: Record<string, number> = {
  price: 7, integrity: 8, battery: 6, performance: 6, camera: 5, display: 5, software: 4,
  charging: 5, weight: 3, audio: 7, anc: 5, capacity: 6, speed: 5, quality: 6,
};

/** Share of a criterion's points given when a product's value is unknown. */
export const MISSING_CREDIT = 0.3;

export type DecisionInput = {
  id: string;
  name: string;
  metrics: Record<string, number | null>;
  disqualified: string | null;
};

export type RankedProduct = {
  id: string;
  name: string;
  score: number;
  rank: number;
  disqualified: string | null;
  contributions: { key: string; normalised: number | null; points: number }[];
  missing: string[];
};

export function rank(products: DecisionInput[], criteria: Criterion[], weights: Record<string, number>): RankedProduct[] {
  const active = criteria.filter((c) => (weights[c.key] ?? 0) > 0);
  const totalWeight = active.reduce((s, c) => s + (weights[c.key] ?? 0), 0) || 1;

  const ranges = new Map<string, { lo: number; hi: number }>();
  for (const c of active) {
    const vals = products.map((p) => p.metrics[c.key]).filter((v): v is number => typeof v === "number" && Number.isFinite(v));
    if (vals.length) ranges.set(c.key, { lo: Math.min(...vals), hi: Math.max(...vals) });
  }

  const scored = products.map((p) => {
    const missing: string[] = [];
    const contributions = active.map((c) => {
      const v = p.metrics[c.key];
      const r = ranges.get(c.key);
      if (typeof v !== "number" || !Number.isFinite(v) || !r) {
        missing.push(c.label);
        // Unknown values count as below average, so a product cannot win on missing data.
        return { key: c.key, normalised: null, points: (MISSING_CREDIT * (weights[c.key] ?? 0)) / totalWeight * 100 };
      }
      let n = r.hi === r.lo ? 1 : (v - r.lo) / (r.hi - r.lo);
      if (c.direction === "lower") n = r.hi === r.lo ? 1 : 1 - n;
      return { key: c.key, normalised: Math.round(n * 1000) / 1000, points: (n * (weights[c.key] ?? 0)) / totalWeight * 100 };
    });
    const raw = contributions.reduce((s, c) => s + c.points, 0);
    return {
      id: p.id,
      name: p.name,
      score: Math.round(raw * 10) / 10,
      disqualified: p.disqualified,
      contributions: contributions.map((c) => ({ ...c, points: Math.round(c.points * 10) / 10 })),
      missing,
      rank: 0,
    };
  });

  // Disqualified products always sort after qualified ones, whatever their weighted score.
  scored.sort((a, b) => Number(!!a.disqualified) - Number(!!b.disqualified) || b.score - a.score);
  scored.forEach((s, i) => (s.rank = i + 1));
  return scored;
}
