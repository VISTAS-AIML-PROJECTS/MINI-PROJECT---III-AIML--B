"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { api } from "@/lib/client-api";
import { useToast } from "@/components/Toast";
import { ReportView } from "@/components/report/ReportView";
import { ReportSkeleton } from "@/components/report/ReportSkeleton";
import { track } from "@/lib/analytics";
import { dateTime, inr } from "@/lib/format";
import type { AuditReport, Category } from "@/lib/engine";
import type { ProductView } from "@/lib/repos/cases";
import { ProductForm } from "./ProductForm";
import { ReviewImport } from "./ReviewImport";

type CaseInfo = { id: string; title: string; category: Category; budgetInr: number | null; weights: Record<string, number>; shareSlug: string | null };
type Audit = { id: string; report: AuditReport; narrative: string | null; createdAt: string } | null;
type Modal = { kind: "add" } | { kind: "edit"; product: ProductView } | { kind: "reviews"; product: ProductView } | { kind: "rename" } | { kind: "delete" } | null;

export function CaseWorkspace({ initialCase, initialProducts, initialAudit, narrativeAvailable, siteUrl }: {
  initialCase: CaseInfo; initialProducts: ProductView[]; initialAudit: Audit; narrativeAvailable: boolean; siteUrl: string;
}) {
  const router = useRouter();
  const toast = useToast();
  const [c, setCase] = useState(initialCase);
  const [products, setProducts] = useState(initialProducts);
  const [audit, setAudit] = useState(initialAudit);
  const [stale, setStale] = useState(false);
  const [running, setRunning] = useState(false);
  const [narrBusy, setNarrBusy] = useState(false);
  const [modal, setModal] = useState<Modal>(null);
  const dialogRef = useRef<HTMLDialogElement>(null);

  useEffect(() => {
    const d = dialogRef.current;
    if (!d) return;
    if (modal && !d.open) d.showModal();
    if (!modal && d.open) d.close();
  }, [modal]);

  const reload = async () => {
    const res = await api<{ case: CaseInfo; products: ProductView[]; audit: Audit }>(`/api/cases/${c.id}`);
    if (res.ok) {
      setCase(res.data.case);
      setProducts(res.data.products);
    }
  };

  const afterChange = async (msg: string) => {
    setModal(null);
    toast(msg);
    setStale(true);
    await reload();
  };

  const runAudit = async () => {
    setRunning(true);
    const res = await api<{ audit: NonNullable<Audit> }>(`/api/cases/${c.id}/audit`, { body: { weights: c.weights } });
    setRunning(false);
    if (!res.ok) return toast(res.error, "error");
    setAudit(res.data.audit);
    setStale(false);
    track("audit_run", { products: products.length, category: c.category });
    document.getElementById("report")?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const saveWeights = async (weights: Record<string, number>) => {
    setCase((x) => ({ ...x, weights }));
    const res = await api(`/api/cases/${c.id}`, { method: "PATCH", body: { weights } });
    if (!res.ok) toast("Could not save your weights.", "error");
  };

  const removeProduct = async (p: ProductView) => {
    if (!confirm(`Remove ${p.name} and its ${p.reviewCount} reviews from this case?`)) return;
    const res = await api(`/api/products/${p.id}`, { method: "DELETE" });
    if (!res.ok) return toast(res.error, "error");
    afterChange(`${p.name} removed.`);
  };

  const toggleShare = async () => {
    const res = await api<{ shareSlug: string | null }>(`/api/cases/${c.id}/share`, { body: { enabled: !c.shareSlug } });
    if (!res.ok) return toast(res.error, "error");
    setCase((x) => ({ ...x, shareSlug: res.data.shareSlug }));
    if (res.data.shareSlug) {
      const url = `${siteUrl}/r/${res.data.shareSlug}`;
      navigator.clipboard?.writeText(url).then(() => toast("Share link copied."), () => toast("Share link created."));
      track("case_shared");
    } else toast("Share link turned off.");
  };

  const narrate = async () => {
    setNarrBusy(true);
    const res = await api<{ narrative: string }>(`/api/cases/${c.id}/narrative`, { body: {} });
    setNarrBusy(false);
    if (!res.ok) return toast(res.error, "error");
    setAudit((a) => (a ? { ...a, narrative: res.data.narrative } : a));
  };

  const rename = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const budget = String(fd.get("budget") ?? "").trim();
    const res = await api(`/api/cases/${c.id}`, { method: "PATCH", body: { title: fd.get("title"), budgetInr: budget ? Number(budget) : null } });
    if (!res.ok) return toast(res.error, "error");
    afterChange("Case updated.");
  };

  const deleteCase = async () => {
    const res = await api(`/api/cases/${c.id}`, { method: "DELETE" });
    if (!res.ok) return toast(res.error, "error");
    router.push("/dashboard");
    router.refresh();
  };

  const shareUrl = c.shareSlug ? `${siteUrl}/r/${c.shareSlug}` : null;

  return (
    <>
      <nav className="breadcrumbs" aria-label="Breadcrumb" style={{ marginTop: 0 }}>
        <ol><li><Link href="/dashboard">Cases</Link></li><li><span aria-current="page">{c.title}</span></li></ol>
      </nav>
      <div className="panel-head">
        <div>
          <h1 style={{ fontSize: "var(--step-3)", margin: 0 }}>{c.title}</h1>
          <div className="small muted">{c.category} · {c.budgetInr ? `budget ${inr(c.budgetInr)}` : "no budget set"}</div>
        </div>
        <div className="btn-row">
          <button className="btn btn-secondary btn-small" onClick={() => setModal({ kind: "rename" })}>Edit details</button>
          <button className="btn btn-secondary btn-small" onClick={toggleShare}>{c.shareSlug ? "Turn off share link" : "Create share link"}</button>
          <button className="btn btn-secondary btn-small" onClick={() => setModal({ kind: "delete" })}>Delete case</button>
        </div>
      </div>
      {shareUrl && (
        <p className="notice small">
          Anyone with this link can view the latest audit (not your account details): <a href={shareUrl}>{shareUrl}</a>
        </p>
      )}

      <section className="panel" aria-labelledby="products-title">
        <div className="panel-head">
          <h2 id="products-title" style={{ margin: 0 }}>Products ({products.length}/12)</h2>
          <button className="btn btn-small" onClick={() => setModal({ kind: "add" })} disabled={products.length >= 12}>Add product</button>
        </div>
        {products.length ? (
          <div className="table-wrap">
            <table>
              <thead><tr><th scope="col">Product</th><th scope="col" className="num">Price</th><th scope="col" className="num">Reviews</th><th scope="col"><span className="sr-only">Actions</span></th></tr></thead>
              <tbody>
                {products.map((p) => (
                  <tr key={p.id}>
                    <td><strong style={{ fontWeight: 500 }}>{p.name}</strong>{p.brand && <div className="small muted">{p.brand}</div>}</td>
                    <td className="num">{inr(p.priceInr)}</td>
                    <td className="num">{p.reviewCount}</td>
                    <td>
                      <div className="btn-row" style={{ gap: 6, justifyContent: "flex-end" }}>
                        <button className="btn btn-secondary btn-small" onClick={() => setModal({ kind: "reviews", product: p })}>Import reviews</button>
                        <button className="btn btn-secondary btn-small" onClick={() => setModal({ kind: "edit", product: p })} aria-label={`Edit ${p.name}`}>Edit</button>
                        <button className="btn btn-secondary btn-small" onClick={() => removeProduct(p)} aria-label={`Remove ${p.name}`}>Remove</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="empty">
            <h3>No products yet</h3>
            <p className="muted">Add each product you are considering. Two or more makes the ranking meaningful.</p>
            <button className="btn" onClick={() => setModal({ kind: "add" })}>Add your first product</button>
          </div>
        )}
        <div className="btn-row" style={{ marginTop: 18 }}>
          <button className="btn" onClick={runAudit} disabled={running || !products.length}>{running ? "Running audit…" : audit ? "Re-run audit" : "Run audit"}</button>
          {audit && <span className="small muted">Last run {dateTime(audit.createdAt)}{stale && " · products changed since, re-run to update"}</span>}
        </div>
      </section>

      <section id="report" aria-labelledby="report-title" style={{ scrollMarginTop: 80 }}>
        <h2 id="report-title" className="sr-only">Audit report</h2>
        {running && !audit ? <ReportSkeleton /> : audit ? (
          <>
            {narrativeAvailable && (
              <div style={{ marginBottom: 24 }}>
                {audit.narrative ? (
                  <div className="narrative" aria-label="Plain-language summary">
                    <span className="eyebrow">Plain-language summary · written by Claude from the numbers below</span>
                    {audit.narrative}
                  </div>
                ) : (
                  <button className="btn btn-secondary" onClick={narrate} disabled={narrBusy}>{narrBusy ? "Writing summary…" : "Explain in plain language"}</button>
                )}
              </div>
            )}
            <ReportView report={audit.report} onWeightsChange={saveWeights} context="case" />
          </>
        ) : (
          <div className="empty"><p className="muted" style={{ margin: 0 }}>Run the audit to see the verdict and evidence here.</p></div>
        )}
      </section>

      <dialog ref={dialogRef} onClose={() => setModal(null)} aria-label="Case editor">
        {modal?.kind === "add" && <ProductForm caseId={c.id} category={c.category} onDone={() => afterChange("Product added.")} onCancel={() => setModal(null)} />}
        {modal?.kind === "edit" && <ProductForm caseId={c.id} category={c.category} product={modal.product} onDone={() => afterChange("Product saved.")} onCancel={() => setModal(null)} />}
        {modal?.kind === "reviews" && (
          <ReviewImport productId={modal.product.id} productName={modal.product.name} existing={modal.product.reviewCount} onDone={afterChange} onCancel={() => setModal(null)} />
        )}
        {modal?.kind === "rename" && (
          <form onSubmit={rename}>
            <h2 style={{ fontSize: "var(--step-2)" }}>Edit case details</h2>
            <div className="field"><label htmlFor="cr-title">Title</label><input id="cr-title" name="title" defaultValue={c.title} required minLength={3} maxLength={120} /></div>
            <div className="field"><label htmlFor="cr-budget">Budget (₹)</label><input id="cr-budget" name="budget" type="number" min={1} defaultValue={c.budgetInr ?? ""} /></div>
            <div className="btn-row"><button className="btn">Save</button><button type="button" className="btn btn-secondary" onClick={() => setModal(null)}>Cancel</button></div>
          </form>
        )}
        {modal?.kind === "delete" && (
          <div>
            <h2 style={{ fontSize: "var(--step-2)" }}>Delete this case?</h2>
            <p>This permanently deletes {products.length} product{products.length === 1 ? "" : "s"}, their reviews and all audit history. It cannot be undone.</p>
            <div className="btn-row"><button className="btn btn-danger" onClick={deleteCase}>Delete case</button><button className="btn btn-secondary" onClick={() => setModal(null)}>Cancel</button></div>
          </div>
        )}
      </dialog>
    </>
  );
}
