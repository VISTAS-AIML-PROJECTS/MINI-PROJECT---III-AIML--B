/*
 * Creates an administrator, or promotes an existing user.
 * Usage: npm run db:create-admin -- admin@example.com "Admin Name"
 * The password is read from ADMIN_PASSWORD, or prompted for. Uses DATABASE_URL when set.
 */
import path from "node:path";
import { randomUUID } from "node:crypto";
import { createInterface } from "node:readline/promises";
import { openDriver } from "../src/lib/db-core";
import { hashPassword } from "../src/lib/auth/password";

async function main() {
  const [email, name = "Administrator"] = process.argv.slice(2);
  if (!email || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
    console.error('Usage: npm run db:create-admin -- admin@example.com "Admin Name"');
    process.exit(1);
  }
  const db = await openDriver({ url: process.env.DATABASE_URL || undefined, file: path.resolve(process.env.DATABASE_PATH ?? "data/buysure.db") });
  try {
    const [existing] = await db.all<{ id: string }>("SELECT id FROM users WHERE email = ?", [email.toLowerCase()]);
    const now = new Date().toISOString();
    if (existing) {
      await db.run("UPDATE users SET role = 'admin', disabled_at = NULL, updated_at = ? WHERE id = ?", [now, existing.id]);
      console.log(`Promoted ${email} to admin.`);
      return;
    }
    let password = process.env.ADMIN_PASSWORD;
    if (!password) {
      const rl = createInterface({ input: process.stdin, output: process.stdout });
      password = await rl.question("Password for the new admin (min 10 chars): ");
      rl.close();
    }
    if (!password || password.length < 10) {
      console.error("Password must be at least 10 characters.");
      process.exit(1);
    }
    await db.run("INSERT INTO users (id, email, name, password_hash, role, created_at, updated_at) VALUES (?, ?, ?, ?, 'admin', ?, ?)",
      [randomUUID(), email.toLowerCase(), name, await hashPassword(password), now, now]);
    console.log(`Created admin ${email}.`);
  } finally {
    await db.close();
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
