/** Structured JSON logs on stdout/stderr; any log drain (Docker, Fly, Railway, Loki) can ingest them. */
type Level = "info" | "warn" | "error";

function write(level: Level, msg: string, meta?: Record<string, unknown>) {
  const line = JSON.stringify({ t: new Date().toISOString(), level, msg, ...meta });
  if (level === "error") console.error(line);
  else if (level === "warn") console.warn(line);
  else if (process.env.NODE_ENV !== "test") console.log(line);
}

export const log = {
  info: (msg: string, meta?: Record<string, unknown>) => write("info", msg, meta),
  warn: (msg: string, meta?: Record<string, unknown>) => write("warn", msg, meta),
  error: (msg: string, err?: unknown, meta?: Record<string, unknown>) =>
    write("error", msg, {
      ...meta,
      error: err instanceof Error ? { name: err.name, message: err.message, stack: err.stack } : err,
    }),
};
