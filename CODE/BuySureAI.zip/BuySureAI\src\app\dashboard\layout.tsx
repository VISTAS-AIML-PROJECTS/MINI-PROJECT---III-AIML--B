import type { Metadata } from "next";
import { AppNav } from "@/components/AppNav";
import { requireUser } from "@/lib/auth/guard";

export const metadata: Metadata = { robots: { index: false, follow: false } };

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser("/dashboard");
  return (
    <div className="wrap app-shell">
      <AppNav
        label="Account"
        groups={[
          { title: "Workspace", items: [{ href: "/dashboard", label: "Cases", exact: true }, { href: "/dashboard/watches", label: "Price watches" }] },
          { title: "Account", items: [{ href: "/dashboard/settings", label: "Settings" }, ...(user.role === "admin" ? [{ href: "/admin", label: "Admin" }] : [])] },
        ]}
      />
      <div>{children}</div>
    </div>
  );
}
