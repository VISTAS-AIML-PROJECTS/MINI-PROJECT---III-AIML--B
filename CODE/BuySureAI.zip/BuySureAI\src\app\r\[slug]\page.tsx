import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getCaseBySlug, latestAudit } from "@/lib/repos/cases";
import { ReportView } from "@/components/report/ReportView";
import { dateTime } from "@/lib/format";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const row = await getCaseBySlug(slug);
  // Shared reports are user content: never indexed.
  return {
    title: row ? `Shared audit: ${row.title}` : "Shared audit",
    description: "A product audit shared from BuySure AI.",
    robots: { index: false, follow: false },
  };
}

export default async function SharedReport({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const row = await getCaseBySlug(slug);
  if (!row) notFound();
  const audit = await latestAudit(row.id);
  return (
    <div className="wrap" style={{ paddingBottom: 80 }}>
      <header className="page-head" style={{ marginTop: 24 }}>
        <span className="eyebrow">Shared audit · read-only</span>
        <h1>{row.title}</h1>
        <p className="small muted">
          Shared by a BuySure user. The product data was entered by them and has not been checked by BuySure. Findings are statistical
          and physical analysis of that data, not statements of fact about any seller or brand.
        </p>
      </header>
      {audit ? (
        <>
          <p className="small muted">Audit generated {dateTime(audit.createdAt)}. Moving the sliders changes only your view.</p>
          <ReportView report={audit.report} context="shared" />
        </>
      ) : (
        <div className="empty"><p className="muted" style={{ margin: 0 }}>This case has not been audited yet.</p></div>
      )}
      <p style={{ marginTop: 32 }}><Link href="/register" className="btn">Audit your own shortlist</Link></p>
    </div>
  );
}
