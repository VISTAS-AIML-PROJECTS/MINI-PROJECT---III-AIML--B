import { handler, json, ApiError, limit } from "@/lib/api";
import { adminGetProduct, setProductImage } from "@/lib/catalog/repo";
import { adminLog } from "@/lib/repos/misc";
import { MAX_UPLOAD, removeImage, saveImage } from "@/lib/media";

/** Upload a product photo you have the rights to use (multipart field "image"). */
export const POST = handler<{ id: string }>({ auth: "admin" }, async (req, { params, user }) => {
  await limit(`upload:${user!.id}`, 60, 3600);
  const cur = await adminGetProduct(params.id);
  if (!cur) throw new ApiError(404, "Product not found.");
  if (Number(req.headers.get("content-length") ?? 0) > MAX_UPLOAD + 64_000) throw new ApiError(413, "Images must be 2 MB or smaller.");
  let file: File | null = null;
  try {
    const form = await req.formData();
    const f = form.get("image");
    file = f instanceof File ? f : null;
  } catch {
    throw new ApiError(400, "Send the image as multipart form data.");
  }
  if (!file || !file.size) throw new ApiError(422, "Choose an image file.");
  if (file.size > MAX_UPLOAD) throw new ApiError(413, "Images must be 2 MB or smaller.");
  let name: string;
  try {
    name = await saveImage(Buffer.from(await file.arrayBuffer()));
  } catch {
    throw new ApiError(415, "Only JPEG, PNG or WebP images are accepted.");
  }
  await removeImage(cur.imagePath);
  await setProductImage(cur.id, name);
  await adminLog(user!.id, "catalog.image", cur.id, { name });
  return json({ imagePath: name }, 201);
});

export const DELETE = handler<{ id: string }>({ auth: "admin" }, async (_req, { params, user }) => {
  const cur = await adminGetProduct(params.id);
  if (!cur) throw new ApiError(404, "Product not found.");
  await removeImage(cur.imagePath);
  await setProductImage(cur.id, null);
  await adminLog(user!.id, "catalog.image.remove", cur.id);
  return json({ ok: true });
});
