import Link from "next/link";
import { LogoMark } from "./Logo";
import { CookieSettingsButton } from "./Consent";
import { site } from "@/lib/site";

export function Footer() {
  return (
    <footer className="site-footer">
      <div className="wrap">
        <div className="footer-grid">
          <div>
            <Link href="/" className="brand" aria-label="BuySure AI home">
              <LogoMark />
              <span>Buy<em>Sure</em> AI</span>
            </Link>
            <p className="small muted" style={{ marginTop: 14, maxWidth: "38ch" }}>
              Independent purchase forensics. No affiliate links, no paid placements, no sponsored rankings.
            </p>
          </div>
          <nav aria-label="Product">
            <h2>Product</h2>
            <ul>
              <li><Link href="/best/phones">Best phones</Link></li>
              <li><Link href="/best/earbuds">Best earbuds</Link></li>
              <li><Link href="/how-it-works">How we rank</Link></li>
              <li><Link href="/demo">Audit tool</Link></li>
              <li><Link href="/register">Create an account</Link></li>
              <li><Link href="/dashboard">Your cases</Link></li>
            </ul>
          </nav>
          <nav aria-label="Company">
            <h2>Company</h2>
            <ul>
              <li><Link href="/about">About</Link></li>
              <li><Link href="/reviews">Reviews</Link></li>
              <li><Link href="/faq">FAQ</Link></li>
              <li><Link href="/contact">Contact</Link></li>
            </ul>
          </nav>
          <nav aria-label="Legal">
            <h2>Legal</h2>
            <ul>
              <li><Link href="/privacy">Privacy policy</Link></li>
              <li><Link href="/terms">Terms of service</Link></li>
              <li><Link href="/privacy#cookies">Cookies</Link></li>
              <li><CookieSettingsButton /></li>
            </ul>
          </nav>
        </div>
        <div className="footer-base">
          <span>© {new Date().getFullYear()} {site.name}. Verdicts are analysis, not guarantees.</span>
          <span className="mono">engine v1.0</span>
        </div>
      </div>
    </footer>
  );
}
