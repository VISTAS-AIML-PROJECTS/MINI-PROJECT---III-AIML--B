"use client";

/**
 * Privacy-conscious event tracking. Events only reach Google Analytics after the visitor has
 * accepted analytics cookies; otherwise every call is a no-op. Never pass personal data
 * (emails, names, review text, prices tied to a person) as event parameters.
 */
type Params = Record<string, string | number | boolean | undefined>;

declare global {
  interface Window {
    gtag?: (...args: unknown[]) => void;
    dataLayer?: unknown[];
  }
}

export const CONSENT_COOKIE = "bs_consent";

export function getConsent(): "granted" | "denied" | null {
  if (typeof document === "undefined") return null;
  const m = /(?:^|;\s*)bs_consent=(granted|denied)/.exec(document.cookie);
  return (m?.[1] as "granted" | "denied") ?? null;
}

export function setConsent(value: "granted" | "denied") {
  const secure = location.protocol === "https:" ? "; Secure" : "";
  document.cookie = `${CONSENT_COOKIE}=${value}; Max-Age=${60 * 60 * 24 * 180}; Path=/; SameSite=Lax${secure}`;
  window.dispatchEvent(new CustomEvent("bs-consent", { detail: value }));
}

export function track(event: string, params?: Params) {
  if (getConsent() !== "granted" || typeof window.gtag !== "function") return;
  window.gtag("event", event, params ?? {});
}
