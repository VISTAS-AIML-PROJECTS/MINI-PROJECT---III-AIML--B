import { handler, json } from "@/lib/api";
import { deleteObservation, getOwnedWatch } from "@/lib/repos/watches";

export const DELETE = handler<{ id: string; obsId: string }>({ auth: "user" }, async (_req, { params, user }) => {
  const w = await getOwnedWatch(params.id, user!.id);
  await deleteObservation(w.id, params.obsId);
  return json({ ok: true });
});
