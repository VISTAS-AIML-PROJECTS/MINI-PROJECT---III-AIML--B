"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { track } from "@/lib/analytics";

export const IMAGE_KEY = "bs-search-image";
const MAX = 5 * 1024 * 1024;
const TYPES = ["image/jpeg", "image/png", "image/webp", "image/gif"];

const EXAMPLES = [
  "Best phone under ₹20,000 for camera",
  "Earbuds with the best noise cancelling under ₹5,000",
  "Is the realme P4 Power worth it?",
  "Power bank that can charge a laptop",
  "Best air fryer for a family of four",
];

/**
 * One box for every kind of search: words, a pasted product link from any store, or a photo.
 * A photo is kept in sessionStorage for the results page (never uploaded until you search).
 */
export function SearchBox({ initial = "", autoFocus = false, examples = true }: { initial?: string; autoFocus?: boolean; examples?: boolean }) {
  const router = useRouter();
  const [q, setQ] = useState(initial);
  const [image, setImage] = useState<{ name: string; dataUrl: string } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const file = useRef<HTMLInputElement>(null);

  const pick = (f: File | undefined) => {
    setError(null);
    if (!f) return;
    if (!TYPES.includes(f.type)) return setError("Use a JPEG, PNG, WebP or GIF photo.");
    if (f.size > MAX) return setError("That photo is over 5 MB.");
    const r = new FileReader();
    r.onload = () => setImage({ name: f.name, dataUrl: String(r.result) });
    r.onerror = () => setError("Couldn't read that photo.");
    r.readAsDataURL(f);
  };

  const go = (text: string) => {
    const query = text.trim();
    if (!query && !image) return setError("Type a product, paste a link, or add a photo.");
    try {
      if (image) sessionStorage.setItem(IMAGE_KEY, image.dataUrl);
      else sessionStorage.removeItem(IMAGE_KEY);
    } catch {
      if (image) return setError("Your browser blocked the photo. Try typing the product name.");
    }
    track("search", { kind: image ? "photo" : /https?:\/\//.test(query) ? "link" : "text" });
    router.push(`/search?q=${encodeURIComponent(query)}${image ? "&photo=1" : ""}&t=${Date.now()}`);
  };

  return (
    <div className="searchbox">
      <form role="search" onSubmit={(e) => { e.preventDefault(); go(q); }}>
        <label htmlFor="bs-q" className="sr-only">Search any product, paste a link, or add a photo</label>
        <input
          id="bs-q" type="search" value={q} onChange={(e) => setQ(e.target.value)} autoFocus={autoFocus} maxLength={500}
          placeholder="Search any product or paste a link" autoComplete="off" enterKeyHint="search"
        />
        <input ref={file} type="file" accept="image/jpeg,image/png,image/webp,image/gif" capture="environment" hidden onChange={(e) => pick(e.target.files?.[0])} />
        <button type="button" className="icon-btn" onClick={() => file.current?.click()} aria-label="Search with a photo">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true"><path d="M4 8h3l2-3h6l2 3h3v11H4z" /><circle cx="12" cy="13" r="3.5" /></svg>
        </button>
        <button type="submit" className="btn go">Search</button>
      </form>
      {image && (
        <div className="attach">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={image.dataUrl} alt="Photo to search with" />
          <span>Photo attached. Add words if you like, then Search.</span>
          <button type="button" className="btn-link" onClick={() => { setImage(null); if (file.current) file.current.value = ""; }}>Remove</button>
        </div>
      )}
      {error && <p className="small" role="alert" style={{ color: "var(--red)", margin: "10px 0 0 14px" }}>{error}</p>}
      {examples && (
        <div className="hint-row">
          {EXAMPLES.map((e) => <button key={e} type="button" className="chip" onClick={() => { setQ(e); go(e); }}>{e}</button>)}
        </div>
      )}
    </div>
  );
}
