import { handler, json, limit, ApiError } from "@/lib/api";
import { getOwnedCase, latestAudit, saveNarrative } from "@/lib/repos/cases";
import { narrativeEnabled, writeNarrative } from "@/lib/llm";
import { log } from "@/lib/logger";

export const POST = handler<{ id: string }>({ auth: "user" }, async (_req, { params, user }) => {
  if (!narrativeEnabled()) throw new ApiError(503, "Plain-language summaries are not configured on this server.");
  await limit(`narrative:${user!.id}`, 20, 3600);
  const row = await getOwnedCase(params.id, user!.id);
  const audit = await latestAudit(row.id);
  if (!audit) throw new ApiError(422, "Run an audit first.");
  if (audit.narrative) return json({ narrative: audit.narrative });
  try {
    const narrative = await writeNarrative(audit.report);
    await saveNarrative(audit.id, narrative);
    return json({ narrative });
  } catch (err) {
    log.error("Narrative generation failed", err, { caseId: row.id });
    throw new ApiError(502, "The summary service did not respond. Your audit is unaffected; try again shortly.");
  }
});
