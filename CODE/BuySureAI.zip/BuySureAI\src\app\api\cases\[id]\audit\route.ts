import { handler, json, limit, ApiError, readJson } from "@/lib/api";
import { engineInputs, getOwnedCase, latestAudit, saveAudit } from "@/lib/repos/cases";
import { runAudit } from "@/lib/engine";
import { parseJson } from "@/lib/db";
import { weightsSchema } from "@/lib/validation";

type P = { id: string };

export const GET = handler<P>({ auth: "user" }, async (_req, { params, user }) => {
  const row = await getOwnedCase(params.id, user!.id);
  return json({ audit: await latestAudit(row.id) });
});

export const POST = handler<P>({ auth: "user" }, async (req, { params, user }) => {
  await limit(`audit:${user!.id}`, 60, 3600);
  const row = await getOwnedCase(params.id, user!.id);
  const body = await readJson(req, weightsSchema, 5_000);
  const products = await engineInputs(row.id);
  if (products.length < 1) throw new ApiError(422, "Add at least one product before running an audit.");
  const report = runAudit({
    category: row.category,
    products,
    weights: body.weights ?? parseJson<Record<string, number>>(row.weights_json, {}),
  });
  const id = await saveAudit(row.id, report);
  return json({ audit: { id, report, narrative: null, createdAt: report.generatedAt } }, 201);
});
