import { requireAdmin } from "@/lib/auth/guard";
import { listUsers } from "@/lib/repos/misc";
import { date } from "@/lib/format";
import { AdminButton } from "../AdminActions";
import { Pager } from "../Pager";

export default async function AdminUsers({ searchParams }: { searchParams: Promise<{ q?: string; page?: string }> }) {
  const me = await requireAdmin();
  const sp = await searchParams;
  const q = sp.q?.trim().slice(0, 100) || null;
  const page = Math.max(1, Number(sp.page) || 1);
  const { total, items } = await listUsers(q, page);
  return (
    <>
      <h1 style={{ fontSize: "var(--step-3)" }}>Users</h1>
      <form method="get" className="btn-row" style={{ marginBottom: 18 }} role="search">
        <label htmlFor="uq" className="sr-only">Search users</label>
        <input id="uq" name="q" defaultValue={q ?? ""} placeholder="Search name or email" style={{ maxWidth: 320 }} />
        <button className="btn btn-small">Search</button>
      </form>
      {items.length ? (
        <div className="table-wrap">
          <table>
            <thead><tr><th scope="col">User</th><th scope="col">Role</th><th scope="col" className="num">Cases</th><th scope="col">Joined</th><th scope="col">Actions</th></tr></thead>
            <tbody>
              {items.map((u) => (
                <tr key={u.id}>
                  <td>{u.name}<div className="small muted">{u.email}</div>{u.disabled_at && <span className="stamp stamp-fail">Disabled</span>}</td>
                  <td>{u.role}</td>
                  <td className="num">{u.cases}</td>
                  <td>{date(u.created_at)}</td>
                  <td>
                    {u.id === me.id ? <span className="small muted">You</span> : (
                      <div className="btn-row" style={{ gap: 6 }}>
                        <AdminButton url={`/api/admin/users/${u.id}`} body={{ role: u.role === "admin" ? "user" : "admin" }} label={u.role === "admin" ? "Remove admin" : "Make admin"} confirmText={`Change ${u.email}'s role?`} />
                        <AdminButton url={`/api/admin/users/${u.id}`} body={{ disabled: !u.disabled_at }} label={u.disabled_at ? "Enable" : "Disable"} danger={!u.disabled_at} confirmText={u.disabled_at ? undefined : `Disable ${u.email}? They will be signed out.`} />
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : <div className="empty"><p className="muted" style={{ margin: 0 }}>No users match.</p></div>}
      <Pager page={page} total={total} pageSize={25} base="/admin/users" params={{ q: q ?? undefined }} />
    </>
  );
}
