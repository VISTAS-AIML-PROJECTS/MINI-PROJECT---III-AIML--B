import Link from "next/link";
import { requireAdmin } from "@/lib/auth/guard";
import { listContactMessages } from "@/lib/repos/misc";
import { dateTime } from "@/lib/format";
import { AdminButton } from "../AdminActions";
import { Pager } from "../Pager";

const STATUSES = ["new", "read", "archived"] as const;

export default async function AdminMessages({ searchParams }: { searchParams: Promise<{ status?: string; page?: string }> }) {
  await requireAdmin();
  const sp = await searchParams;
  const status = STATUSES.includes(sp.status as (typeof STATUSES)[number]) ? sp.status! : null;
  const page = Math.max(1, Number(sp.page) || 1);
  const { total, items } = await listContactMessages(status, page);
  return (
    <>
      <h1 style={{ fontSize: "var(--step-3)" }}>Messages</h1>
      <nav className="btn-row" aria-label="Filter by status" style={{ marginBottom: 18 }}>
        <Link href="/admin/messages" className={`btn btn-small ${status ? "btn-secondary" : ""}`}>All</Link>
        {STATUSES.map((s) => <Link key={s} href={`/admin/messages?status=${s}`} className={`btn btn-small ${status === s ? "" : "btn-secondary"}`}>{s}</Link>)}
      </nav>
      {items.length ? (
        <ul className="list-plain">
          {items.map((m) => (
            <li key={m.id} className="panel">
              <div className="panel-head">
                <div>
                  <strong>{m.name}</strong> · <a href={`mailto:${m.email}`}>{m.email}</a>
                  <div className="small muted">{m.topic} · {dateTime(m.created_at)} · <span className="mono">{m.status}</span></div>
                </div>
                <div className="btn-row" style={{ gap: 6 }}>
                  {m.status !== "read" && <AdminButton url={`/api/admin/messages/${m.id}`} body={{ status: "read" }} label="Mark read" />}
                  {m.status !== "archived" && <AdminButton url={`/api/admin/messages/${m.id}`} body={{ status: "archived" }} label="Archive" />}
                </div>
              </div>
              <p style={{ whiteSpace: "pre-wrap", margin: 0 }}>{m.message}</p>
            </li>
          ))}
        </ul>
      ) : <div className="empty"><p className="muted" style={{ margin: 0 }}>No messages{status ? ` with status "${status}"` : ""}.</p></div>}
      <Pager page={page} total={total} pageSize={25} base="/admin/messages" params={{ status: status ?? undefined }} />
    </>
  );
}
