import type { Metadata } from "next";
import { Breadcrumbs } from "@/components/Breadcrumbs";
import { pageMeta } from "@/lib/seo";
import { approvedSiteReviews, siteReviewStats } from "@/lib/repos/misc";
import { date } from "@/lib/format";
import { ReviewForm } from "./ReviewForm";

export const dynamic = "force-dynamic";

export const metadata: Metadata = pageMeta({
  title: "Reviews of BuySure AI",
  description: "What BuySure AI users say about it. Every review is written by a signed-in user and approved by a person; we never write or buy reviews.",
  path: "/reviews",
});

export default async function ReviewsPage() {
  const reviews = await approvedSiteReviews(100);
  const stats = await siteReviewStats();
  return (
    <div className="wrap">
      <Breadcrumbs items={[{ name: "Reviews", path: "/reviews" }]} />
      <header className="page-head">
        <span className="eyebrow">Reviews of BuySure</span>
        <h1>{reviews.length ? `${stats.n} review${stats.n === 1 ? "" : "s"} · ${stats.avg?.toFixed(1)}★ average` : "No reviews yet"}</h1>
        <p className="lede">
          We hold ourselves to the standard we test others by: reviews come only from signed-in users, a person approves each one, critical
          reviews are published too, and we never write, buy or incentivise them.
        </p>
      </header>
      <div className="grid-2" style={{ gap: 48, alignItems: "start", paddingBottom: 80 }}>
        <section aria-label="Published reviews">
          {reviews.length ? (
            <ul className="list-plain" style={{ borderTop: "1px solid var(--ink)" }}>
              {reviews.map((r) => (
                <li key={r.id} style={{ padding: "18px 0", borderBottom: "1px solid var(--rule)" }}>
                  <div className="mono small" aria-label={`${r.rating} out of 5 stars`}>{"★".repeat(r.rating)}{"☆".repeat(5 - r.rating)}</div>
                  <p style={{ fontFamily: "var(--font-serif)", fontSize: "var(--step-1)", margin: "6px 0" }}>{r.body}</p>
                  <div className="small muted">{r.display_name} · {date(r.created_at)}</div>
                </li>
              ))}
            </ul>
          ) : (
            <div className="empty">
              <h2>Be the first to review BuySure</h2>
              <p className="muted" style={{ margin: 0 }}>Nothing here yet, and we will not fill the space with invented praise.</p>
            </div>
          )}
        </section>
        <ReviewForm />
      </div>
    </div>
  );
}
