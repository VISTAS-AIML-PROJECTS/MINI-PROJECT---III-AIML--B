import "server-only";
import { categoryBySlug, formatBudget } from "./categories";
import { categoryItems } from "./repo";
import { presetWeights, rankItems, type RankedItem } from "./rank";

export type Pick = { item: RankedItem; badge: string };

/** "Best under ₹X" for each budget tier, plus the best overall, without repeating a product. */
export async function topPicks(slug: string, max = 4): Promise<Pick[]> {
  const def = categoryBySlug(slug);
  if (!def) return [];
  const items = await categoryItems(slug);
  const weights = presetWeights(def, "balanced");
  const used = new Set<string>();
  const picks: Pick[] = [];
  for (const b of def.budgets) {
    const pool = items.filter((i) => i.priceInr <= b);
    if (pool.length < 2) continue;
    const best = rankItems(def, pool, weights).find((r) => !used.has(r.id) && r.physics.status !== "fail");
    if (best) { used.add(best.id); picks.push({ item: best, badge: `Best under ${formatBudget(b)}` }); }
  }
  const overall = rankItems(def, items, weights).filter((r) => r.physics.status !== "fail");
  const top = overall.find((r) => !used.has(r.id));
  if (top) { picks.push({ item: top, badge: overall[0].id === top.id ? "Best overall" : "Top rated" }); used.add(top.id); }
  for (const r of overall) {
    if (picks.length >= max) break;
    if (!used.has(r.id)) { picks.push({ item: r, badge: "" }); used.add(r.id); }
  }
  return picks.slice(0, max);
}
