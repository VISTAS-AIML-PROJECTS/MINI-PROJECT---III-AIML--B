/**
 * Team members shown on /about. Intentionally empty: add real people only, with their consent.
 * Photos go in /public/team/ (square, at least 480×480, WebP or JPEG).
 *
 * Example:
 * { name: "Full Name", role: "Founder, engineering", photo: "/team/full-name.webp", bio: "One or two factual sentences." }
 */
export type TeamMember = { name: string; role: string; photo?: string; bio: string };

export const TEAM: TeamMember[] = [];
