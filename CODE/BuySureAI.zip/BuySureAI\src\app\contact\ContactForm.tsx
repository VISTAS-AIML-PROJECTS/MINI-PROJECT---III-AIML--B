"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/lib/client-api";
import { track } from "@/lib/analytics";
import { FieldError, useForm } from "@/components/forms";

const TOPICS = [
  ["general", "General question"],
  ["bug", "Something is broken"],
  ["privacy", "Privacy or data request"],
  ["enterprise", "Organisation / API access"],
  ["press", "Press"],
] as const;

export function ContactForm({ defaultTopic }: { defaultTopic?: string }) {
  const router = useRouter();
  const [startedAt, setStartedAt] = useState<number | undefined>();
  useEffect(() => setStartedAt(Date.now()), []);
  const f = useForm();
  const initialTopic = TOPICS.some(([v]) => v === defaultTopic) ? defaultTopic : "general";

  const submit = f.handle(async (fd) => {
    const body = {
      name: fd.get("name"),
      email: fd.get("email"),
      topic: fd.get("topic"),
      message: fd.get("message"),
      website: fd.get("website"),
      startedAt,
    };
    const res = await api("/api/contact", { body });
    if (!res.ok) return res;
    track("contact_submitted", { topic: String(body.topic) });
    router.push("/contact/thanks");
  });

  return (
    <form onSubmit={submit} noValidate aria-describedby={f.error ? "form-error" : undefined}>
      {f.error && <div id="form-error" className="notice notice-error" role="alert">{f.error}</div>}
      <div className="field">
        <label htmlFor="c-name">Your name</label>
        <input id="c-name" name="name" autoComplete="name" required maxLength={80} aria-invalid={!!f.fields.name} aria-describedby="c-name-err" />
        <FieldError id="c-name-err" msg={f.fields.name} />
      </div>
      <div className="field">
        <label htmlFor="c-email">Email</label>
        <input id="c-email" name="email" type="email" autoComplete="email" required maxLength={254} aria-invalid={!!f.fields.email} aria-describedby="c-email-err" />
        <FieldError id="c-email-err" msg={f.fields.email} />
      </div>
      <div className="field">
        <label htmlFor="c-topic">Topic</label>
        <select id="c-topic" name="topic" defaultValue={initialTopic}>
          {TOPICS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
        </select>
      </div>
      <div className="field">
        <label htmlFor="c-message">Message</label>
        <textarea id="c-message" name="message" required minLength={20} maxLength={4000} aria-invalid={!!f.fields.message} aria-describedby="c-message-hint c-message-err" />
        <span id="c-message-hint" className="hint">At least 20 characters. Please don&apos;t include passwords or card numbers.</span>
        <FieldError id="c-message-err" msg={f.fields.message} />
      </div>
      <div className="hp" aria-hidden="true">
        <label htmlFor="c-website">Leave this empty</label>
        <input id="c-website" name="website" tabIndex={-1} autoComplete="off" />
      </div>
      <button className="btn" type="submit" disabled={f.busy}>{f.busy ? "Sending…" : "Send message"}</button>
      <p className="small muted" style={{ marginTop: 12 }}>We use your email only to reply. See our privacy policy.</p>
    </form>
  );
}
