import { handler, json, readJson, limit, clientIp } from "@/lib/api";
import { contactSchema } from "@/lib/validation";
import { createContactMessage } from "@/lib/repos/misc";
import { sendEmail } from "@/lib/email";
import { env } from "@/lib/env";
import { log } from "@/lib/logger";

export const POST = handler({}, async (req) => {
  await limit(`contact:${clientIp(req)}`, 5, 3600);
  const data = await readJson(req, contactSchema, 20_000);

  // Bots fill hidden fields or submit faster than a person can type. Accept silently, store nothing.
  const tooFast = typeof data.startedAt === "number" && Date.now() - data.startedAt < 2500;
  if (data.website || tooFast) return json({ ok: true }, 201);

  const id = await createContactMessage(data);
  if (env.CONTACT_INBOX) {
    await sendEmail({
      to: env.CONTACT_INBOX,
      subject: `[BuySure contact] ${data.topic}: ${data.name}`,
      text: `From: ${data.name} <${data.email}>\nTopic: ${data.topic}\n\n${data.message}\n\nAdmin: ${env.APP_URL}/admin/messages`,
      replyTo: data.email,
    }).catch((err: unknown) => log.error("Contact notification email failed", err, { id }));
  }
  return json({ ok: true, id }, 201);
});
