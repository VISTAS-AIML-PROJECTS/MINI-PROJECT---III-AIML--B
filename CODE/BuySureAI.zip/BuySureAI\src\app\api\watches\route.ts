import { handler, json, readJson, limit } from "@/lib/api";
import { watchSchema } from "@/lib/validation";
import { createWatch, listWatches } from "@/lib/repos/watches";

export const GET = handler({ auth: "user" }, async (_req, { user }) => json({ watches: await listWatches(user!.id) }));

export const POST = handler({ auth: "user" }, async (req, { user }) => {
  await limit(`create-watch:${user!.id}`, 60, 3600);
  const data = await readJson(req, watchSchema, 5_000);
  const id = await createWatch(user!.id, data);
  return json({ id }, 201);
});
