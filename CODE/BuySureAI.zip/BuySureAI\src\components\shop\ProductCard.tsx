import Link from "next/link";
import { ProductVisual } from "./ProductVisual";
import { inr } from "@/lib/format";

export function ProductCard({ href, category, brand, name, priceInr, badge, score, why, imagePath, searched }: {
  href: string | null;
  category: string | null;
  brand: string;
  name: string;
  priceInr: number | null;
  badge?: string | null;
  score?: number | null;
  why?: string | null;
  imagePath?: string | null;
  searched?: boolean;
}) {
  const inner = (
    <>
      {badge && <span className="badge">{badge}</span>}
      {typeof score === "number" && <span className="score" aria-label={`Score ${score} out of 100`}>{Math.round(score)}</span>}
      <div className="visual"><ProductVisual category={category} brand={brand} name={name} imagePath={imagePath} /></div>
      <div className="body">
        <span className="brand">{brand}</span>
        <span className="name">{name}</span>
        <span className="price">{priceInr ? inr(priceInr) : "Price unavailable"}</span>
        {why && <span className="why">{why}</span>}
      </div>
    </>
  );
  return href ? (
    <Link href={href} className="pcard" data-searched={searched || undefined}>{inner}</Link>
  ) : (
    <div className="pcard" data-searched={searched || undefined}>{inner}</div>
  );
}
