"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ReportView } from "@/components/report/ReportView";
import { ReportSkeleton } from "@/components/report/ReportSkeleton";
import { api } from "@/lib/client-api";
import { track } from "@/lib/analytics";
import type { AuditReport } from "@/lib/engine";

export function DemoClient() {
  const router = useRouter();
  const [state, setState] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [report, setReport] = useState<AuditReport | null>(null);
  const [error, setError] = useState("");
  const [copying, setCopying] = useState(false);

  const run = async () => {
    setState("loading");
    setError("");
    const started = performance.now();
    const res = await api<{ report: AuditReport }>("/api/demo/audit", { body: {} });
    if (!res.ok) {
      setError(res.error);
      setState("error");
      return;
    }
    setReport(res.data.report);
    setState("done");
    track("demo_audit_run", { ms: Math.round(performance.now() - started) });
  };

  const copyToWorkspace = async () => {
    setCopying(true);
    const res = await api<{ id: string }>("/api/cases/sample", { body: {} });
    setCopying(false);
    if (res.ok) {
      track("sample_case_copied");
      router.push(`/dashboard/cases/${res.data.id}`);
    } else if (res.status === 401) {
      router.push("/register?next=/demo");
    } else {
      setError(res.error);
    }
  };

  return (
    <div style={{ paddingBottom: 80 }}>
      <div className="btn-row" style={{ marginBottom: 28 }}>
        <button className="btn" onClick={run} disabled={state === "loading"} aria-describedby="demo-hint">
          {state === "loading" ? "Running audit…" : state === "done" ? "Run it again" : "Run the audit"}
        </button>
        {state === "done" && (
          <button className="btn btn-secondary" onClick={copyToWorkspace} disabled={copying}>
            {copying ? "Copying…" : "Copy this case into my account to edit it"}
          </button>
        )}
        <span id="demo-hint" className="small muted">Takes well under a second. Nothing is stored.</span>
      </div>
      <div aria-live="polite" aria-busy={state === "loading"}>
        {state === "idle" && (
          <div className="empty">
            <h2>Nothing audited yet</h2>
            <p className="muted" style={{ margin: 0 }}>Press &quot;Run the audit&quot; to send the four sample listings through the engine.</p>
          </div>
        )}
        {state === "loading" && <ReportSkeleton />}
        {state === "error" && (
          <div className="notice notice-error" role="alert">
            <p style={{ margin: "0 0 8px" }}>{error}</p>
            <button className="btn btn-small" onClick={run}>Try again</button>
          </div>
        )}
        {state === "done" && report && <ReportView report={report} context="demo" />}
      </div>
    </div>
  );
}
