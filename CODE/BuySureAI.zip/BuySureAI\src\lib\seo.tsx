import type { Metadata } from "next";
import { absoluteUrl, site } from "./site";

/** Builds per-page metadata with a unique title, description, canonical URL and social tags. */
export function pageMeta(opts: { title: string; description: string; path: string; noindex?: boolean }): Metadata {
  const url = absoluteUrl(opts.path);
  return {
    title: opts.title,
    description: opts.description,
    alternates: { canonical: url },
    openGraph: {
      type: "website",
      url,
      title: `${opts.title} · ${site.name}`,
      description: opts.description,
      siteName: site.name,
      locale: site.locale,
      images: [{ url: absoluteUrl("/opengraph-image"), width: 1200, height: 630, alt: `${site.name}: every listing is a claim. We test it.` }],
    },
    twitter: { card: "summary_large_image", title: `${opts.title} · ${site.name}`, description: opts.description, images: [absoluteUrl("/opengraph-image")] },
    robots: opts.noindex ? { index: false, follow: false } : undefined,
  };
}

export function JsonLd({ data }: { data: Record<string, unknown> | Record<string, unknown>[] }) {
  // JSON.stringify output is safe inside a script tag once "<" is escaped.
  const html = JSON.stringify(data).replace(/</g, "\\u003c");
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: html }} />;
}

export function breadcrumbLd(items: { name: string; path: string }[]) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((it, i) => ({ "@type": "ListItem", position: i + 1, name: it.name, item: absoluteUrl(it.path) })),
  };
}
