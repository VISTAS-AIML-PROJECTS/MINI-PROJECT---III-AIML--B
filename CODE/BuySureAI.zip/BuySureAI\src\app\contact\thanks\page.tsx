import type { Metadata } from "next";
import Link from "next/link";
import { pageMeta } from "@/lib/seo";
import { site } from "@/lib/site";

export const metadata: Metadata = pageMeta({
  title: "Message received",
  description: "Thanks for writing to BuySure AI. Your message has been received and a person will reply within two business days.",
  path: "/contact/thanks",
  noindex: true,
});

export default function Thanks() {
  return (
    <div className="wrap narrow" style={{ padding: "80px var(--gutter)" }}>
      <span className="stamp stamp-pass">Received</span>
      <h1 style={{ marginTop: 18 }}>Thank you. Your message is with us.</h1>
      <p className="lede">{site.responseTime} If you wrote about a privacy request, we will confirm when it is done.</p>
      <div className="btn-row" style={{ marginTop: 24 }}>
        <Link href="/demo" className="btn">Try the sample audit meanwhile</Link>
        <Link href="/" className="btn btn-secondary">Back to home</Link>
      </div>
    </div>
  );
}
