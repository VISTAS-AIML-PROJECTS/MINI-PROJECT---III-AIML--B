"use client";

import { useState, type ReactNode } from "react";

/** Third-party product photo; shows `children` instead if it fails to load. */
export function RemoteImage({ src, alt, children }: { src: string; alt: string; children: ReactNode }) {
  const [failed, setFailed] = useState(false);
  if (failed) return <>{children}</>;
  // eslint-disable-next-line @next/next/no-img-element
  return <img src={src} alt={alt} loading="lazy" decoding="async" referrerPolicy="no-referrer" onError={() => setFailed(true)} style={{ objectFit: "contain" }} />;
}
