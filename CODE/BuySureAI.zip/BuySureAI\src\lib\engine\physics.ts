import type { Category, CertifiedSpecs, Finding, Specs } from "./types";
import { round } from "./text";

/**
 * Physical plausibility checks for advertised specs.
 *
 * Limits are deliberately generous: they describe the best lithium-ion cells shipping in consumer
 * products (silicon-carbon anodes included) and the largest share of a device a battery can occupy.
 * A "fail" therefore means the claim cannot be met by any cell that exists, not merely that it is
 * optimistic. Every check reports the numbers it used so the user can verify them.
 */

type Profile = {
  defaultVoltage: number;
  cellWhPerL: number;   // best-case volumetric density of the cell itself
  cellWhPerKg: number;  // best-case gravimetric density of the cell itself
  volumeShare: number;  // max fraction of device volume the battery can occupy
  massShare: number;    // max fraction of device mass the battery can be
};

export const PROFILES: Record<Category, Profile> = {
  phone:     { defaultVoltage: 3.87, cellWhPerL: 900, cellWhPerKg: 350, volumeShare: 0.45, massShare: 0.55 },
  powerbank: { defaultVoltage: 3.7,  cellWhPerL: 750, cellWhPerKg: 290, volumeShare: 0.75, massShare: 0.8 },
  laptop:    { defaultVoltage: 11.4, cellWhPerL: 750, cellWhPerKg: 300, volumeShare: 0.25, massShare: 0.32 },
  earbuds:   { defaultVoltage: 3.7,  cellWhPerL: 600, cellWhPerKg: 250, volumeShare: 0.35, massShare: 0.4 },
  storage:   { defaultVoltage: 3.7,  cellWhPerL: 750, cellWhPerKg: 290, volumeShare: 0.5,  massShare: 0.5 },
  other:     { defaultVoltage: 3.7,  cellWhPerL: 750, cellWhPerKg: 290, volumeShare: 0.6,  massShare: 0.6 },
};

/** Conservative floor for genuine flash storage, INR per GB. Real retail prices sit well above it. */
export const FLASH_FLOOR_INR_PER_GB = 1;

export type CheckStatus = "pass" | "warn" | "fail" | "unchecked";
export type PhysicsCheck = { code: string; label: string; status: CheckStatus; detail: string };
export type PhysicsReport = {
  status: CheckStatus;
  energyWh: number | null;
  checks: PhysicsCheck[];
  findings: Finding[];
};

function parseIp(s?: string): { dust: number; water: number } | null {
  if (!s) return null;
  const m = /IP\s*([0-6X])\s*([0-9X])/i.exec(s);
  if (!m) return null;
  const d = (c: string) => (c.toUpperCase() === "X" ? -1 : Number(c));
  return { dust: d(m[1]), water: d(m[2]) };
}

export function checkPhysics(category: Category, specs: Specs, certified: CertifiedSpecs, priceInr?: number): PhysicsReport {
  const p = PROFILES[category];
  const checks: PhysicsCheck[] = [];
  const findings: Finding[] = [];
  const add = (c: PhysicsCheck, module: Finding["module"] = "physics") => {
    checks.push(c);
    if (c.status === "warn" || c.status === "fail") findings.push({ module, severity: c.status, code: c.code, message: `${c.label}: ${c.detail}` });
  };

  const voltage = specs.nominalVoltage ?? p.defaultVoltage;
  const energyWh = specs.batteryMah ? (specs.batteryMah * voltage) / 1000 : null;
  const volumeL =
    specs.lengthMm && specs.widthMm && specs.thicknessMm ? (specs.lengthMm * specs.widthMm * specs.thicknessMm) / 1e6 : null;
  const massKg = specs.weightG ? specs.weightG / 1000 : null;

  // Volumetric energy density.
  if (energyWh && volumeL) {
    const density = energyWh / volumeL;
    const max = p.cellWhPerL * p.volumeShare;
    const status: CheckStatus = density > max ? "fail" : density > max * 0.85 ? "warn" : "pass";
    add({
      code: "PHYSICS_VOLUME",
      label: "Battery vs. body volume",
      status,
      detail: `${specs.batteryMah} mAh at ${voltage} V is ${round(energyWh, 1)} Wh in a ${round(volumeL * 1000, 0)} cm³ body, i.e. ${round(density, 0)} Wh/L at device level. Ceiling for this category: ${round(max, 0)} Wh/L (${p.cellWhPerL} Wh/L cells filling ${Math.round(p.volumeShare * 100)}% of the body).${status === "fail" ? " No shipping cell chemistry can fit this battery in this body." : ""}`,
    });
  } else {
    checks.push({ code: "PHYSICS_VOLUME", label: "Battery vs. body volume", status: "unchecked", detail: "Needs battery capacity and all three dimensions." });
  }

  // Gravimetric energy density.
  if (energyWh && massKg) {
    const density = energyWh / massKg;
    const max = p.cellWhPerKg * p.massShare;
    const status: CheckStatus = density > max ? "fail" : density > max * 0.85 ? "warn" : "pass";
    add({
      code: "PHYSICS_MASS",
      label: "Battery vs. weight",
      status,
      detail: `${round(energyWh, 1)} Wh in a ${specs.weightG} g device is ${round(density, 0)} Wh/kg. Ceiling: ${round(max, 0)} Wh/kg (${p.cellWhPerKg} Wh/kg cells at ${Math.round(p.massShare * 100)}% of total mass). The cells alone would weigh at least ${Math.round((energyWh / p.cellWhPerKg) * 1000)} g.`,
    });
  } else {
    checks.push({ code: "PHYSICS_MASS", label: "Battery vs. weight", status: "unchecked", detail: "Needs battery capacity and weight." });
  }

  // Charging-time floor.
  if (energyWh && specs.chargingW && specs.claimedFullChargeMin) {
    const floorMin = (energyWh / (specs.chargingW * 0.92)) * 60;
    const c = specs.claimedFullChargeMin;
    const status: CheckStatus = c < floorMin ? "fail" : c < floorMin * 1.15 ? "warn" : "pass";
    add({
      code: "PHYSICS_CHARGE_TIME",
      label: "Full-charge time",
      status,
      detail: `Filling ${round(energyWh, 1)} Wh at a sustained ${specs.chargingW} W (92% efficiency) takes at least ${Math.ceil(floorMin)} min; the listing claims ${c} min.${status === "fail" ? " That is faster than the charger can physically deliver." : status === "warn" ? " Only possible if peak power is held the whole way, which batteries do not allow near full." : ""}`,
    });
  }

  // Capacity vs. certification.
  if (specs.batteryMah && certified.batteryMah) {
    const ratio = certified.batteryMah / specs.batteryMah;
    const status: CheckStatus = ratio < 0.9 ? "fail" : ratio < 0.95 ? "warn" : "pass";
    add({
      code: "CLAIM_CAPACITY",
      label: "Capacity vs. certificate",
      status,
      detail: `Listing says ${specs.batteryMah} mAh; ${certified.source || "the certificate"} records ${certified.batteryMah} mAh (${Math.round(ratio * 100)}%). Typical-vs-rated gaps are normally within 5%.`,
    }, "claims");
  }

  // Ingress protection vs. certification.
  const claimedIp = parseIp(specs.ipRating);
  const certIp = parseIp(certified.ipRating);
  if (claimedIp && certIp) {
    const over = claimedIp.water > certIp.water || claimedIp.dust > certIp.dust;
    add({
      code: "CLAIM_IP",
      label: "Water/dust rating vs. certificate",
      status: over ? "fail" : "pass",
      detail: over
        ? `Listing claims ${specs.ipRating!.toUpperCase()} but ${certified.source || "the certificate"} shows ${certified.ipRating!.toUpperCase()}. The advertised protection is not certified.`
        : `Listing claim ${specs.ipRating!.toUpperCase()} is covered by ${certified.ipRating!.toUpperCase()}.`,
    }, "claims");
  } else if (claimedIp && !certIp) {
    checks.push({ code: "CLAIM_IP", label: "Water/dust rating vs. certificate", status: "unchecked", detail: `Listing claims ${specs.ipRating}. Add the certified rating to verify it.` });
  }

  // Charger wattage vs. certification.
  if (specs.chargingW && certified.chargingW) {
    const over = specs.chargingW > certified.chargingW * 1.05;
    add({
      code: "CLAIM_CHARGING",
      label: "Charging power vs. certificate",
      status: over ? "fail" : "pass",
      detail: `Listing says ${specs.chargingW} W; certificate shows ${certified.chargingW} W.`,
    }, "claims");
  }

  // Power bank delivered capacity, which honest listings disclose and most buyers do not expect.
  if (category === "powerbank" && energyWh) {
    const delivered = Math.round(((energyWh * 0.85) / 5) * 1000);
    checks.push({
      code: "INFO_POWERBANK_OUTPUT",
      label: "Usable output",
      status: "pass",
      detail: `At 5 V with ~85% conversion efficiency, expect about ${delivered} mAh delivered to a phone, not ${specs.batteryMah} mAh.`,
    });
  }

  // Flash storage priced below the cost of genuine NAND.
  if (category === "storage" && specs.storageGb && priceInr) {
    const perGb = priceInr / specs.storageGb;
    const status: CheckStatus = perGb < FLASH_FLOOR_INR_PER_GB * 0.5 ? "fail" : perGb < FLASH_FLOOR_INR_PER_GB ? "warn" : "pass";
    add({
      code: "PHYSICS_STORAGE_PRICE",
      label: "Price per GB",
      status,
      detail: `₹${round(perGb, 2)}/GB for ${specs.storageGb} GB. Genuine flash does not sell below roughly ₹${FLASH_FLOOR_INR_PER_GB}/GB; fake-capacity drives report a size they cannot store.`,
    });
  }

  const statuses = checks.filter((c) => !c.code.startsWith("INFO_")).map((c) => c.status);
  const status: CheckStatus = statuses.includes("fail")
    ? "fail"
    : statuses.includes("warn")
      ? "warn"
      : statuses.includes("pass")
        ? "pass"
        : "unchecked";

  return { status, energyWh: energyWh ? round(energyWh, 2) : null, checks, findings };
}
