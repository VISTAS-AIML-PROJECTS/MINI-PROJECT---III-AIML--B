import type { Metadata } from "next";
import Link from "next/link";
import { Breadcrumbs } from "@/components/Breadcrumbs";
import { pageMeta } from "@/lib/seo";

export const metadata: Metadata = pageMeta({
  title: "Terms of service",
  description: "The terms for using BuySure AI: what the service is and is not, your responsibilities, acceptable use, independence commitments, and liability limits.",
  path: "/terms",
});

const UPDATED = "6 October 2026";

export default function TermsPage() {
  return (
    <div className="wrap">
      <Breadcrumbs items={[{ name: "Terms of service", path: "/terms" }]} />
      <header className="page-head">
        <span className="eyebrow">Legal · last updated {UPDATED}</span>
        <h1>Terms of service</h1>
      </header>
      <div className="prose" style={{ paddingBottom: 80 }}>
        <div className="notice notice-warn" role="note">
          <strong>Template notice:</strong> these terms match how the software works but are not legal advice. Before launch, the operator must insert its legal
          details and governing-law clause and have a qualified lawyer review them.
        </div>

        <h2>1. The service</h2>
        <p>
          BuySure AI (&quot;the service&quot;) analyses product information that you provide and produces scores, findings and rankings. It is a decision aid.
          It does not sell products, is not a marketplace, and does not purchase anything for you.
        </p>

        <h2>2. Verdicts are analysis, not guarantees</h2>
        <p>
          Findings are statistical and physical analysis of the data you enter. A review-integrity signal is not a finding that any review, seller or
          brand acted unlawfully. A pass does not guarantee a product is genuine, safe or suitable. Always check the seller, warranty and return policy
          before buying. Price-drop estimates are probabilities, not predictions you can rely on.
        </p>

        <h2>3. Your account</h2>
        <p>
          You must be 18 or older and give accurate details. Keep your password secret; you are responsible for activity on your account. Tell us promptly
          if you suspect unauthorised access.
        </p>

        <h2>4. Your content</h2>
        <p>
          You keep ownership of what you enter. You give us a licence to store and process it only to provide the service to you, and to display it publicly
          only when you turn on a share link or submit a review of BuySure. You confirm you have the right to use what you import. Do not import personal data
          about other people beyond what is already public in a review.
        </p>

        <h2>5. Acceptable use</h2>
        <ul>
          <li>No attempts to break, overload, probe or bypass the service&apos;s security or rate limits.</li>
          <li>No use of the service to harass, defame or make false public claims about sellers or brands, including through share links.</li>
          <li>No automated account creation or bulk scraping of BuySure pages.</li>
          <li>No uploading malware or unlawful content.</li>
        </ul>

        <h2>6. Our independence commitments</h2>
        <p>
          We do not accept payment, commission or affiliate fees from sellers or brands in exchange for how products rank in consumer audits. We do not bypass
          marketplace access controls to collect data, and we do not place orders or store payment cards for users. If this ever changes, we will update these
          terms and tell account holders before the change takes effect.
        </p>

        <h2>7. Availability and changes</h2>
        <p>
          The service is provided &quot;as is&quot; during early access. We may change or discontinue features and will try to give reasonable notice. You can export
          your data at any time from Settings.
        </p>

        <h2>8. Liability</h2>
        <p>
          To the extent the law allows, we are not liable for indirect or consequential losses, or for purchasing decisions made using the service. Nothing in
          these terms limits liability that cannot legally be limited. [Liability cap and governing law to be inserted by the operator.]
        </p>

        <h2>9. Ending your use</h2>
        <p>
          You can delete your account at any time from Settings. We may suspend accounts that break these terms. Where reasonable, we will tell you why first.
        </p>

        <h2>10. Contact</h2>
        <p>Questions about these terms: <Link href="/contact">contact us</Link>. See also our <Link href="/privacy">privacy policy</Link>.</p>
      </div>
    </div>
  );
}
