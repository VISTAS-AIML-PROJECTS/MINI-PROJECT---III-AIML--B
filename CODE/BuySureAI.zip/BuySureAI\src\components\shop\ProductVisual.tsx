import { RemoteImage } from "./RemoteImage";
import { catalogImage } from "@/lib/catalog/images";

/**
 * Product image: an uploaded photo, a photo found by web search (falls back on load error),
 * or a clean rendered illustration of the category.
 */
export function ProductVisual({ category, brand, name, imagePath, imageUrl }: { category: string | null; brand: string; name: string; imagePath?: string | null; imageUrl?: string | null }) {
  imageUrl ||= imagePath ? null : catalogImage(brand, name);
  if (imageUrl) return <RemoteImage src={imageUrl} alt={`${brand} ${name}`}><Illustration category={category} brand={brand} name={name} /></RemoteImage>;
  if (imagePath) {
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={`/api/media/${imagePath}`} alt={`${brand} ${name}`} loading="lazy" decoding="async" />;
  }
  return <Illustration category={category} brand={brand} name={name} />;
}

function Illustration({ category, brand, name }: { category: string | null; brand: string; name: string }) {
  const label = brand.slice(0, 12);
  const common = { role: "img" as const, "aria-label": `Illustration of ${brand} ${name}`, style: { width: "100%", height: "100%" } };
  switch (category) {
    case "phones":
      return (
        <svg viewBox="0 0 100 100" {...common}>
          <rect x="29" y="6" width="42" height="88" rx="7" fill="#fff" stroke="#0b0b0b" strokeWidth="1.6" />
          <rect x="33" y="10" width="34" height="80" rx="4" fill="#0b0b0b" />
          <rect x="45" y="12.5" width="10" height="2.4" rx="1.2" fill="#2b2b2b" />
          <text x="50" y="54" textAnchor="middle" fontSize="6.2" fill="#fff" fontFamily="Georgia, serif" fontStyle="italic">{label}</text>
        </svg>
      );
    case "earbuds":
      return (
        <svg viewBox="0 0 100 100" {...common}>
          <rect x="22" y="48" width="56" height="34" rx="16" fill="#fff" stroke="#0b0b0b" strokeWidth="1.6" />
          <line x1="22" y1="62" x2="78" y2="62" stroke="#0b0b0b" strokeWidth="1" />
          <ellipse cx="38" cy="30" rx="9" ry="11" fill="#0b0b0b" /><rect x="35" y="36" width="6" height="16" rx="3" fill="#0b0b0b" />
          <ellipse cx="62" cy="30" rx="9" ry="11" fill="#0b0b0b" /><rect x="59" y="36" width="6" height="16" rx="3" fill="#0b0b0b" />
          <text x="50" y="75" textAnchor="middle" fontSize="6" fill="#0b0b0b" fontFamily="Georgia, serif" fontStyle="italic">{label}</text>
        </svg>
      );
    case "power-banks":
      return (
        <svg viewBox="0 0 100 100" {...common}>
          <rect x="24" y="14" width="52" height="74" rx="8" fill="#0b0b0b" />
          <rect x="40" y="9" width="8" height="5" rx="1.5" fill="#0b0b0b" /><rect x="52" y="9" width="8" height="5" rx="1.5" fill="#0b0b0b" />
          {[0, 1, 2, 3].map((i) => <rect key={i} x={36 + i * 8} y="74" width="5" height="3" rx="1" fill={i < 3 ? "#fff" : "#4a4a4a"} />)}
          <text x="50" y="50" textAnchor="middle" fontSize="6.2" fill="#fff" fontFamily="Georgia, serif" fontStyle="italic">{label}</text>
        </svg>
      );
    case "laptops":
      return (
        <svg viewBox="0 0 100 100" {...common}>
          <rect x="18" y="20" width="64" height="44" rx="3" fill="#0b0b0b" />
          <rect x="21" y="23" width="58" height="38" rx="1.5" fill="#1f1f1f" />
          <path d="M10 66h80l-5 8H15z" fill="#fff" stroke="#0b0b0b" strokeWidth="1.6" />
          <text x="50" y="45" textAnchor="middle" fontSize="6.2" fill="#fff" fontFamily="Georgia, serif" fontStyle="italic">{label}</text>
        </svg>
      );
    default:
      return (
        <svg viewBox="0 0 100 100" {...common}>
          <rect x="22" y="22" width="56" height="56" rx="10" fill="#fff" stroke="#0b0b0b" strokeWidth="1.6" />
          <text x="50" y="54" textAnchor="middle" fontSize="7" fill="#0b0b0b" fontFamily="Georgia, serif" fontStyle="italic">{label}</text>
        </svg>
      );
  }
}
