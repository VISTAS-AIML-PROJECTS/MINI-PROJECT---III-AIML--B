import { handler, json, readJson, limit, clientIp } from "@/lib/api";
import { runAudit } from "@/lib/engine";
import { sampleCase } from "@/lib/sample-data";
import { weightsSchema } from "@/lib/validation";

/** Public demo: runs the real engine on the fictional sample case. Nothing is stored. */
export const POST = handler({}, async (req) => {
  await limit(`demo:${clientIp(req)}`, 60, 3600);
  const { weights } = await readJson(req, weightsSchema, 5_000);
  const s = sampleCase();
  const report = runAudit({
    category: s.category,
    products: s.products.map(({ key, ...p }) => ({ ...p, id: key })),
    weights,
  });
  return json({ report, title: s.title });
});
