import { handler, json, readJson, limit, clientIp, ApiError } from "@/lib/api";
import { loginSchema } from "@/lib/validation";
import { burnPasswordCheck, verifyPassword } from "@/lib/auth/password";
import { createSession } from "@/lib/auth/session";
import { findUserByEmail } from "@/lib/repos/users";
import { clearRateLimit } from "@/lib/rate-limit";

export const POST = handler({}, async (req) => {
  const data = await readJson(req, loginSchema, 10_000);
  // Two buckets: per IP (spraying many accounts) and per email (guessing one account's password).
  await limit(`login-ip:${clientIp(req)}`, 30, 900);
  await limit(`login-email:${data.email}`, 8, 900);

  const user = await findUserByEmail(data.email);
  if (!user) {
    await burnPasswordCheck(data.password);
    throw new ApiError(401, "Email or password is incorrect.");
  }
  if (!(await verifyPassword(data.password, user.password_hash))) throw new ApiError(401, "Email or password is incorrect.");
  if (user.disabled_at) throw new ApiError(403, "This account has been disabled. Contact support if you think this is a mistake.");

  await clearRateLimit(`login-email:${data.email}`);
  await createSession(user.id, req.headers.get("user-agent"));
  return json({ ok: true, role: user.role });
});
