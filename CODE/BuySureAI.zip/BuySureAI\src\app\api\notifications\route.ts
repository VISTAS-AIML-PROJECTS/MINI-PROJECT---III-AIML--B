import { handler, json } from "@/lib/api";
import { listNotifications, markAllRead, unreadCount } from "@/lib/repos/misc";

export const GET = handler({ auth: "user" }, async (_req, { user }) =>
  json({ notifications: await listNotifications(user!.id), unread: await unreadCount(user!.id) }),
);

export const POST = handler({ auth: "user" }, async (_req, { user }) => {
  await markAllRead(user!.id);
  return json({ ok: true });
});
