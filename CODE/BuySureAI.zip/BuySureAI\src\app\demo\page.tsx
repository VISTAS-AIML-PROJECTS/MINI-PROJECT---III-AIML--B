import type { Metadata } from "next";
import { Breadcrumbs } from "@/components/Breadcrumbs";
import { pageMeta } from "@/lib/seo";
import { DemoClient } from "./DemoClient";

export const metadata: Metadata = pageMeta({
  title: "Live demo: audit four sample phones",
  description:
    "Run BuySure AI's real audit engine on four fictional phones under ₹20,000. One has a review farm, one claims an impossible battery. Adjust the weights and watch the ranking change.",
  path: "/demo",
});

export default function DemoPage() {
  return (
    <div className="wrap">
      <Breadcrumbs items={[{ name: "Live demo", path: "/demo" }]} />
      <header className="page-head">
        <span className="eyebrow">Live demo · real engine · fictional products</span>
        <h1>Phone under ₹20,000: a sample case</h1>
        <p className="lede">
          Four made-up phones with generated reviews and listing data. Each is built to trip a different check: a review farm, an
          impossible battery, a missing charger, two brands from one factory. The audit runs on our server each time you press the button.
        </p>
        <p className="small muted">
          The brands, sellers and reviews on this page do not exist. Any resemblance to real products is coincidental.
        </p>
      </header>
      <DemoClient />
    </div>
  );
}
