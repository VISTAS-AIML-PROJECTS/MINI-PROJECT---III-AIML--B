import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Breadcrumbs } from "@/components/Breadcrumbs";
import { ProductCard } from "@/components/shop/ProductCard";
import { ProductVisual } from "@/components/shop/ProductVisual";
import { categoryBySlug, formatBudget, CATEGORIES } from "@/lib/catalog/categories";
import { categoryItems } from "@/lib/catalog/repo";
import { presetWeights, rankItems } from "@/lib/catalog/rank";
import { inr } from "@/lib/format";
import { JsonLd, pageMeta } from "@/lib/seo";
import { absoluteUrl } from "@/lib/site";

export const revalidate = 600;
export const dynamicParams = false;
export const generateStaticParams = () => CATEGORIES.map((c) => ({ category: c.slug }));

export async function generateMetadata({ params }: { params: Promise<{ category: string }> }): Promise<Metadata> {
  const def = categoryBySlug((await params).category);
  if (!def) return {};
  return pageMeta({
    title: `Best ${def.name.toLowerCase()} in India (${new Date().toLocaleString("en-IN", { month: "long", year: "numeric" })})`,
    description: `The best ${def.name.toLowerCase()} at every budget, ranked on published specs: ${def.criteria.map((c) => c.label.toLowerCase()).join(", ")}. Prices and sources on every product.`,
    path: `/best/${def.slug}`,
  });
}

export default async function CategoryPage({ params, searchParams }: { params: Promise<{ category: string }>; searchParams: Promise<{ under?: string; for?: string }> }) {
  const def = categoryBySlug((await params).category);
  if (!def) notFound();
  const sp = await searchParams;
  const under = def.budgets.includes(Number(sp.under)) ? Number(sp.under) : null;
  const preset = def.presets.find((p) => p.key === sp.for)?.key ?? "balanced";
  const items = await categoryItems(def.slug, { maxPrice: under ?? undefined });
  const ranked = rankItems(def, items, presetWeights(def, preset));
  const top = ranked[0];
  const qs = (u: number | null, f: string) => {
    const p = new URLSearchParams();
    if (u) p.set("under", String(u));
    if (f !== "balanced") p.set("for", f);
    const s = p.toString();
    return `/best/${def.slug}${s ? `?${s}` : ""}`;
  };

  return (
    <div className="wrap" style={{ paddingBottom: 96 }}>
      <Breadcrumbs items={[{ name: `Best ${def.name.toLowerCase()}`, path: `/best/${def.slug}` }]} />
      <header style={{ padding: "8px 0 20px" }}>
        <h1 style={{ fontSize: "var(--step-4)", marginBottom: 6 }}>Best {def.name.toLowerCase()}{under ? ` under ${formatBudget(under)}` : ""}</h1>
        <p className="lede">Ranked on published specs, for {def.presets.find((p) => p.key === preset)!.label.toLowerCase()}. Change the budget or priority:</p>
        <nav aria-label="Budget" className="tabs">
          <Link href={qs(null, preset)} className="chip" aria-current={!under ? "page" : undefined}>Any budget</Link>
          {def.budgets.map((b) => <Link key={b} href={qs(b, preset)} className="chip" aria-current={under === b ? "page" : undefined}>Under {formatBudget(b)}</Link>)}
        </nav>
        <nav aria-label="Priority" className="tabs">
          {def.presets.map((p) => <Link key={p.key} href={qs(under, p.key)} className="chip" aria-current={preset === p.key ? "page" : undefined}>{p.label}</Link>)}
        </nav>
      </header>

      {!ranked.length ? (
        <div className="empty"><p className="muted" style={{ margin: 0 }}>Nothing in our catalogue at this budget yet. <Link href={`/search?q=${encodeURIComponent(`best ${def.singular} under ${under}`)}`}>Search the web instead</Link>.</p></div>
      ) : (
        <>
          <article className="winner">
            <div className="visual"><ProductVisual category={def.slug} brand={top.brand} name={top.name} imagePath={top.imagePath} /></div>
            <div>
              <span className="stamp stamp-pass">#1 · score {top.score.toFixed(0)}/100</span>
              <h2><Link href={`/p/${top.slug}`} style={{ color: "inherit" }}>{top.name}</Link></h2>
              <div style={{ fontSize: "1.4rem", fontWeight: 600 }}>{inr(top.priceInr)}</div>
              <div className="small muted">{[top.variant, top.priceNote].filter(Boolean).join(" · ")}</div>
              <div className="specline">{def.keySpecs(top.specs).map((k) => <span key={k.label}><b>{k.label}</b>{k.value}</span>)}</div>
              <ul className="pluses">{top.reasons.map((r, i) => <li key={i}>{r}</li>)}{top.weaknesses.map((r, i) => <li key={`w${i}`} className="minus">{r}</li>)}</ul>
              <div className="btn-row" style={{ marginTop: 14 }}><Link href={`/p/${top.slug}`} className="btn btn-small">Why it wins</Link></div>
            </div>
          </article>
          <h2 style={{ fontSize: "var(--step-2)" }}>The rest of the ranking</h2>
          <div className="cards">
            {ranked.slice(1).map((r) => (
              <ProductCard key={r.id} href={`/p/${r.slug}`} category={def.slug} brand={r.brand} name={r.name} priceInr={r.priceInr}
                badge={`#${r.rank}`} score={r.score} why={r.reasons[0] ?? r.weaknesses[0] ?? null} imagePath={r.imagePath} />
            ))}
          </div>
          <p className="small muted" style={{ marginTop: 24 }}>
            Not seeing the one you want? <Link href={`/search?q=${encodeURIComponent(`best ${def.singular}${under ? ` under ${under}` : ""}`)}`}>Search the whole web</Link>, or read <Link href="/how-it-works">how we rank</Link>.
          </p>
        </>
      )}
      <JsonLd data={{
        "@context": "https://schema.org", "@type": "ItemList", name: `Best ${def.name}`,
        itemListElement: ranked.map((r) => ({ "@type": "ListItem", position: r.rank, url: absoluteUrl(`/p/${r.slug}`), name: r.name })),
      }} />
    </div>
  );
}
