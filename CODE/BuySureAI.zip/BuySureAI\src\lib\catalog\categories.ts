import type { Category, Criterion } from "../engine/types";

/**
 * Category definitions for the "best in category" guide. Every score is derived from published
 * specs with a formula shown on the product page, so nothing is an opinion we made up.
 */

export type Specs = Record<string, string | number | boolean | null | undefined>;
export type KeySpec = { label: string; value: string };
export type Preset = { key: string; label: string; weights: Record<string, number> };

export type CategoryDef = {
  slug: string;
  name: string;
  singular: string;
  physics: Category;
  budgets: number[];
  keywords: string[];
  criteria: (Criterion & { how: string })[];
  presets: Preset[];
  metrics: (specs: Specs, priceInr: number) => Record<string, number | null>;
  keySpecs: (specs: Specs) => KeySpec[];
  /** Fields copied into the physics engine's spec shape. */
  physicsSpecs: (specs: Specs) => Record<string, number | string | boolean | undefined>;
};

const num = (v: unknown) => (typeof v === "number" && Number.isFinite(v) ? v : null);
const str = (v: unknown) => (typeof v === "string" && v.trim() ? v : null);

/** Water-resistance digit of an IP code (IP68 → 8, IPX4 → 4, IP69 → 9). */
export function ipWater(ip: unknown): number | null {
  const m = /IP[0-6X]([0-9])/i.exec(String(ip ?? ""));
  return m ? Number(m[1]) : null;
}

const PHONE_V = 3.87;

export const CATEGORIES: CategoryDef[] = [
  {
    slug: "phones",
    name: "Smartphones",
    singular: "phone",
    physics: "phone",
    budgets: [15000, 20000, 30000, 50000],
    keywords: ["phone", "phones", "mobile", "mobiles", "smartphone", "smartphones", "iphone", "android", "pixel", "galaxy", "5g"],
    criteria: [
      { key: "price", label: "Price", direction: "lower", unit: "₹", how: "Listed launch or current price for the variant shown." },
      { key: "performance", label: "Performance", direction: "higher", unit: "Geekbench 6 multi", how: "Geekbench 6 multi-core score of the chipset (same source for every chip)." },
      { key: "battery", label: "Battery", direction: "higher", unit: "Wh", how: "Rated capacity × 3.87 V nominal cell voltage." },
      { key: "charging", label: "Charging", direction: "higher", unit: "W", how: "Maximum wired charging power." },
      { key: "display", label: "Display", direction: "higher", unit: "/10", how: "3 for OLED, up to 2 for refresh rate (≥144 Hz = 2, 120 Hz = 1.5), up to 5 for peak brightness (1,000 nits per point)." },
      { key: "camera", label: "Camera hardware", direction: "higher", unit: "/10", how: "4 for optical stabilisation on the main camera, 3 for a telephoto lens, 2 for an ultrawide, 1 for a 48 MP+ main sensor." },
      { key: "durability", label: "Water resistance", direction: "higher", unit: "IP digit", how: "Second digit of the IP rating (IP54 = 4, IP68 = 8, IP69 = 9)." },
      { key: "weight", label: "Lightness", direction: "lower", unit: "g", how: "Weight in grams; lighter scores higher." },
    ],
    presets: [
      { key: "balanced", label: "Balanced", weights: { price: 7, performance: 6, battery: 6, charging: 3, display: 5, camera: 5, durability: 3, weight: 2 } },
      { key: "camera", label: "Camera first", weights: { price: 5, performance: 3, battery: 4, charging: 2, display: 4, camera: 10, durability: 2, weight: 1 } },
      { key: "battery", label: "Battery first", weights: { price: 5, performance: 3, battery: 10, charging: 6, display: 3, camera: 2, durability: 2, weight: 1 } },
      { key: "gaming", label: "Gaming & speed", weights: { price: 5, performance: 10, battery: 5, charging: 4, display: 6, camera: 1, durability: 1, weight: 1 } },
      { key: "value", label: "Lowest price", weights: { price: 10, performance: 3, battery: 3, charging: 2, display: 2, camera: 2, durability: 1, weight: 1 } },
    ],
    metrics: (s, price) => {
      const nits = num(s.peakNits);
      const hz = num(s.refreshHz) ?? 60;
      const display = (str(s.display)?.toUpperCase().includes("OLED") ? 3 : 0) + (hz >= 144 ? 2 : hz >= 120 ? 1.5 : 0) + (nits ? Math.min(nits, 5000) / 1000 : 0);
      const camera = (s.ois ? 4 : 0) + (s.telephoto ? 3 : 0) + (s.ultrawide ? 2 : 0) + ((num(s.mainMp) ?? 0) >= 48 ? 1 : 0);
      const mah = num(s.batteryMah);
      return {
        price,
        performance: num(s.gb6Multi),
        battery: mah ? Math.round((mah * PHONE_V) / 100) / 10 : null,
        charging: num(s.chargingW),
        display: Math.round(display * 10) / 10,
        camera,
        durability: ipWater(s.ip),
        weight: num(s.weightG),
      };
    },
    keySpecs: (s) => [
      { label: "Chip", value: `${s.chip ?? "—"}` },
      { label: "Display", value: [s.display, s.sizeIn ? `${s.sizeIn}″` : null, s.refreshHz ? `${s.refreshHz} Hz` : null, s.peakNits ? `${Number(s.peakNits).toLocaleString("en-IN")} nits` : null].filter(Boolean).join(" · ") },
      { label: "Battery", value: [s.batteryMah ? `${Number(s.batteryMah).toLocaleString("en-IN")} mAh` : null, s.chargingW ? `${s.chargingW} W` : null].filter(Boolean).join(" · ") },
      { label: "Camera", value: `${s.mainCamera ?? "—"}` },
      { label: "Build", value: [s.ip, s.weightG ? `${s.weightG} g` : null, s.thicknessMm ? `${s.thicknessMm} mm` : null].filter(Boolean).join(" · ") },
    ],
    physicsSpecs: (s) => ({ batteryMah: num(s.batteryMah) ?? undefined, lengthMm: num(s.lengthMm) ?? undefined, widthMm: num(s.widthMm) ?? undefined, thicknessMm: num(s.thicknessMm) ?? undefined, weightG: num(s.weightG) ?? undefined, ipRating: str(s.ip) ?? undefined }),
  },
  {
    slug: "earbuds",
    name: "Wireless earbuds",
    singular: "pair of earbuds",
    physics: "earbuds",
    budgets: [4000, 15000, 30000],
    keywords: ["earbuds", "earbud", "buds", "tws", "earphones", "airpods", "headphones", "anc"],
    criteria: [
      { key: "price", label: "Price", direction: "lower", unit: "₹", how: "Listed launch or current price." },
      { key: "battery", label: "Battery", direction: "higher", unit: "hours", how: "Total playback with the case, as stated by the maker." },
      { key: "anc", label: "Noise cancelling (claimed)", direction: "higher", unit: "dB", how: "Maker's claimed ANC depth. Brands that make no dB claim sit at the midpoint, neither rewarded nor punished." },
      { key: "codec", label: "Hi-res codec", direction: "higher", unit: "0/1", how: "1 if LDAC or LHDC is supported (relevant for Android phones)." },
      { key: "durability", label: "Water resistance", direction: "higher", unit: "IP digit", how: "Second digit of the IP rating." },
    ],
    presets: [
      { key: "balanced", label: "Balanced", weights: { price: 7, battery: 5, anc: 5, codec: 3, durability: 3 } },
      { key: "anc", label: "Quiet commute", weights: { price: 4, battery: 4, anc: 10, codec: 2, durability: 2 } },
      { key: "battery", label: "Battery first", weights: { price: 5, battery: 10, anc: 3, codec: 2, durability: 2 } },
      { key: "workout", label: "Workouts", weights: { price: 5, battery: 4, anc: 2, codec: 1, durability: 10 } },
      { key: "value", label: "Lowest price", weights: { price: 10, battery: 3, anc: 3, codec: 2, durability: 1 } },
    ],
    metrics: (s, price) => ({
      price,
      battery: num(s.totalHours),
      anc: num(s.ancDb),
      codec: s.hiResCodec ? 1 : 0,
      durability: ipWater(s.ip),
    }),
    keySpecs: (s) => [
      { label: "Noise cancelling", value: s.ancDb ? `Up to ${s.ancDb} dB (claimed)` : s.anc ? "Yes (no dB claim)" : "No" },
      { label: "Battery", value: [s.budHours ? `${s.budHours} h buds` : null, s.totalHours ? `${s.totalHours} h with case` : null].filter(Boolean).join(" · ") },
      { label: "Codecs", value: `${s.codecs ?? "—"}` },
      { label: "Water resistance", value: `${s.ip ?? "Not rated"}` },
    ],
    physicsSpecs: () => ({}),
  },
  {
    slug: "power-banks",
    name: "Power banks",
    singular: "power bank",
    physics: "powerbank",
    budgets: [2000, 4000],
    keywords: ["power bank", "powerbank", "power banks", "portable charger", "battery pack", "mah"],
    criteria: [
      { key: "price", label: "Price", direction: "lower", unit: "₹", how: "Listed price." },
      { key: "capacity", label: "Capacity", direction: "higher", unit: "Wh", how: "Rated mAh × 3.7 V." },
      { key: "output", label: "Output power", direction: "higher", unit: "W", how: "Maximum single-port output." },
      { key: "weight", label: "Lightness", direction: "lower", unit: "g", how: "Weight in grams." },
    ],
    presets: [
      { key: "balanced", label: "Balanced", weights: { price: 7, capacity: 5, output: 6, weight: 3 } },
      { key: "laptop", label: "Charges a laptop", weights: { price: 4, capacity: 5, output: 10, weight: 2 } },
      { key: "travel", label: "Light for travel", weights: { price: 5, capacity: 4, output: 3, weight: 10 } },
      { key: "value", label: "Lowest price", weights: { price: 10, capacity: 3, output: 3, weight: 1 } },
    ],
    metrics: (s, price) => {
      const mah = num(s.capacityMah);
      return { price, capacity: mah ? Math.round((mah * 3.7) / 100) / 10 : null, output: num(s.outputW), weight: num(s.weightG) };
    },
    keySpecs: (s) => [
      { label: "Capacity", value: s.capacityMah ? `${Number(s.capacityMah).toLocaleString("en-IN")} mAh (${Math.round((Number(s.capacityMah) * 3.7) / 1000)} Wh)` : "—" },
      { label: "Max output", value: s.outputW ? `${s.outputW} W` : "—" },
      { label: "Size & weight", value: [s.lengthMm && s.widthMm && s.thicknessMm ? `${s.lengthMm}×${s.widthMm}×${s.thicknessMm} mm` : null, s.weightG ? `${s.weightG} g` : null].filter(Boolean).join(" · ") || "—" },
      { label: "Extras", value: `${s.extras ?? "—"}` },
    ],
    physicsSpecs: (s) => ({ batteryMah: num(s.capacityMah) ?? undefined, lengthMm: num(s.lengthMm) ?? undefined, widthMm: num(s.widthMm) ?? undefined, thicknessMm: num(s.thicknessMm) ?? undefined, weightG: num(s.weightG) ?? undefined }),
  },
  {
    slug: "laptops",
    name: "Laptops",
    singular: "laptop",
    physics: "laptop",
    budgets: [70000, 125000],
    keywords: ["laptop", "laptops", "notebook", "macbook", "ultrabook", "vivobook"],
    criteria: [
      { key: "price", label: "Price", direction: "lower", unit: "₹", how: "Listed price for the configuration shown." },
      { key: "performance", label: "Performance", direction: "higher", unit: "Geekbench 6 multi", how: "Geekbench 6 multi-core score of the processor." },
      { key: "battery", label: "Battery", direction: "higher", unit: "Wh", how: "Rated battery capacity." },
      { key: "weight", label: "Portability", direction: "lower", unit: "kg", how: "Weight in kilograms." },
    ],
    presets: [
      { key: "balanced", label: "Balanced", weights: { price: 7, performance: 6, battery: 5, weight: 4 } },
      { key: "student", label: "Student budget", weights: { price: 10, performance: 4, battery: 5, weight: 3 } },
      { key: "power", label: "Power user", weights: { price: 4, performance: 10, battery: 4, weight: 2 } },
      { key: "travel", label: "Travel light", weights: { price: 4, performance: 4, battery: 8, weight: 10 } },
    ],
    metrics: (s, price) => ({ price, performance: num(s.gb6Multi), battery: num(s.batteryWh), weight: num(s.weightKg) }),
    keySpecs: (s) => [
      { label: "Processor", value: `${s.cpu ?? "—"}` },
      { label: "Memory", value: `${s.memory ?? "—"}` },
      { label: "Display", value: `${s.display ?? "—"}` },
      { label: "Battery & weight", value: [s.batteryWh ? `${s.batteryWh} Wh` : null, s.weightKg ? `${s.weightKg} kg` : null].filter(Boolean).join(" · ") },
    ],
    physicsSpecs: () => ({}),
  },
];

export const categoryBySlug = (slug: string) => CATEGORIES.find((c) => c.slug === slug);

export const formatBudget = (n: number) => (n >= 100000 ? `₹${(n / 100000).toLocaleString("en-IN", { maximumFractionDigits: 2 })} lakh` : `₹${n.toLocaleString("en-IN")}`);
