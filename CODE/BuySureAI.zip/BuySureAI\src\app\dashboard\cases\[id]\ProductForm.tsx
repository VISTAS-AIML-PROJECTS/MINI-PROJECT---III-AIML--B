"use client";

import { FieldError, useForm } from "@/components/forms";
import { api } from "@/lib/client-api";
import { CRITERIA } from "@/lib/engine/decision";
import type { Category } from "@/lib/engine/types";
import type { ProductView } from "@/lib/repos/cases";

const AUTO_METRICS = new Set(["price", "integrity", "battery", "weight", "charging", "capacity"]);
const SCORE_HINT: Record<string, string> = {
  performance: "Benchmark score, e.g. AnTuTu or Geekbench multi-core",
  camera: "Your 0–10 rating, e.g. from reviews you trust",
  display: "0–10",
  software: "0–10 (updates, bloatware, ads)",
  audio: "0–10",
  anc: "0–10",
  speed: "Sequential read, MB/s",
  quality: "0–10",
};

const num = (v: FormDataEntryValue | null) => (v === null || v === "" ? undefined : Number(v));
const str = (v: FormDataEntryValue | null) => (v === null || String(v).trim() === "" ? null : String(v).trim());

export function ProductForm({ caseId, category, product, onDone, onCancel }: {
  caseId: string;
  category: Category;
  product?: ProductView;
  onDone: () => void;
  onCancel: () => void;
}) {
  const f = useForm();
  const scoreKeys = CRITERIA[category].map((c) => c.key).filter((k) => !AUTO_METRICS.has(k));
  const offers = [...(product?.cost.offers ?? []), { label: "", amountInr: undefined, conditional: false }, { label: "", amountInr: undefined, conditional: true }].slice(0, 3);
  while (offers.length < 3) offers.push({ label: "", amountInr: undefined, conditional: false });
  const addOns = [...(product?.cost.addOns ?? []), { label: "", costInr: undefined }].slice(0, 2);
  while (addOns.length < 2) addOns.push({ label: "", costInr: undefined });
  const s = product?.specs ?? {};
  const c = product?.certified ?? {};

  const submit = f.handle(async (fd) => {
    const scores: Record<string, number> = {};
    for (const k of scoreKeys) { const v = num(fd.get(`score_${k}`)); if (v !== undefined) scores[k] = v; }
    const body = {
      name: fd.get("name"),
      brand: str(fd.get("brand")),
      url: str(fd.get("url")),
      priceInr: num(fd.get("priceInr")),
      seller: str(fd.get("seller")),
      manufacturer: str(fd.get("manufacturer")),
      importer: str(fd.get("importer")),
      sellerAddress: str(fd.get("sellerAddress")),
      specs: {
        batteryMah: num(fd.get("batteryMah")), nominalVoltage: num(fd.get("nominalVoltage")),
        lengthMm: num(fd.get("lengthMm")), widthMm: num(fd.get("widthMm")), thicknessMm: num(fd.get("thicknessMm")),
        weightG: num(fd.get("weightG")), chargingW: num(fd.get("chargingW")), claimedFullChargeMin: num(fd.get("claimedFullChargeMin")),
        ipRating: str(fd.get("ipRating")) ?? undefined, storageGb: num(fd.get("storageGb")),
        chargerInBox: fd.get("chargerInBox") === "yes" ? true : fd.get("chargerInBox") === "no" ? false : undefined,
      },
      certified: {
        source: str(fd.get("certSource")) ?? undefined, batteryMah: num(fd.get("certBatteryMah")),
        ipRating: str(fd.get("certIpRating")) ?? undefined, chargingW: num(fd.get("certChargingW")),
      },
      scores,
      cost: {
        shippingInr: num(fd.get("shippingInr")),
        expectedYears: num(fd.get("expectedYears")),
        offers: [0, 1, 2]
          .map((i) => ({ label: str(fd.get(`offer_label_${i}`)), amountInr: num(fd.get(`offer_amount_${i}`)), conditional: fd.get(`offer_cond_${i}`) === "on" }))
          .filter((o) => o.label && o.amountInr),
        addOns: [0, 1]
          .map((i) => ({ label: str(fd.get(`addon_label_${i}`)), costInr: num(fd.get(`addon_cost_${i}`)) }))
          .filter((a) => a.label && a.costInr !== undefined),
      },
    };
    const res = product
      ? await api(`/api/products/${product.id}`, { method: "PATCH", body })
      : await api(`/api/cases/${caseId}/products`, { body });
    if (!res.ok) return res;
    onDone();
  });

  const E = (k: string) => f.fields[k];
  const input = (name: string, label: string, opts: { type?: string; def?: unknown; hint?: string; step?: string; required?: boolean; err?: string } = {}) => (
    <div className="field">
      <label htmlFor={`pf-${name}`}>{label}</label>
      <input id={`pf-${name}`} name={name} type={opts.type ?? "text"} step={opts.step} required={opts.required}
        defaultValue={opts.def === undefined || opts.def === null ? "" : String(opts.def)}
        inputMode={opts.type === "number" ? "decimal" : undefined} aria-invalid={!!E(opts.err ?? name)} aria-describedby={`pf-${name}-e`} />
      {opts.hint && <span className="hint">{opts.hint}</span>}
      <FieldError id={`pf-${name}-e`} msg={E(opts.err ?? name)} />
    </div>
  );

  return (
    <form onSubmit={submit} noValidate>
      <h2 style={{ fontSize: "var(--step-2)" }}>{product ? `Edit ${product.name}` : "Add a product"}</h2>
      <p className="small muted">Copy values from the listing. Leave anything you don&apos;t know blank; checks that need it will say &quot;not checked&quot;.</p>
      {f.error && <div className="notice notice-error" role="alert">{f.error}</div>}

      <fieldset>
        <legend>Listing</legend>
        <div className="grid-2">
          {input("name", "Product name", { def: product?.name, required: true })}
          {input("brand", "Brand", { def: product?.brand })}
          {input("priceInr", "Listed price (₹)", { type: "number", def: product?.priceInr, required: true, step: "1" })}
          {input("url", "Listing URL", { type: "url", def: product?.url, hint: "Kept for your reference; we do not fetch it." })}
        </div>
      </fieldset>

      <fieldset>
        <legend>Who sells and makes it</legend>
        <div className="grid-2">
          {input("seller", "Seller name", { def: product?.seller })}
          {input("manufacturer", "Manufacturer", { def: product?.manufacturer, hint: "Usually under 'Manufacturer' in listing details" })}
          {input("importer", "Importer", { def: product?.importer })}
          {input("sellerAddress", "Seller / manufacturer address", { def: product?.sellerAddress, hint: "Include the PIN code" })}
        </div>
      </fieldset>

      <fieldset>
        <legend>Advertised specs</legend>
        <div className="grid-3">
          {input("batteryMah", "Battery (mAh)", { type: "number", def: s.batteryMah, err: "specs.batteryMah" })}
          {input("nominalVoltage", "Cell voltage (V)", { type: "number", step: "0.01", def: s.nominalVoltage, hint: "Leave blank for the category default", err: "specs.nominalVoltage" })}
          {input("weightG", "Weight (g)", { type: "number", step: "0.1", def: s.weightG, err: "specs.weightG" })}
          {input("lengthMm", "Length (mm)", { type: "number", step: "0.1", def: s.lengthMm, err: "specs.lengthMm" })}
          {input("widthMm", "Width (mm)", { type: "number", step: "0.1", def: s.widthMm, err: "specs.widthMm" })}
          {input("thicknessMm", "Thickness (mm)", { type: "number", step: "0.1", def: s.thicknessMm, err: "specs.thicknessMm" })}
          {input("chargingW", "Charging power (W)", { type: "number", def: s.chargingW, err: "specs.chargingW" })}
          {input("claimedFullChargeMin", "Claimed 0–100% time (min)", { type: "number", def: s.claimedFullChargeMin, err: "specs.claimedFullChargeMin" })}
          {input("ipRating", "Water/dust rating", { def: s.ipRating, hint: "e.g. IP54, IP68", err: "specs.ipRating" })}
          {input("storageGb", "Storage (GB)", { type: "number", def: s.storageGb, err: "specs.storageGb" })}
          <div className="field">
            <label htmlFor="pf-charger">Charger in the box?</label>
            <select id="pf-charger" name="chargerInBox" defaultValue={s.chargerInBox === true ? "yes" : s.chargerInBox === false ? "no" : ""}>
              <option value="">Not stated</option><option value="yes">Yes</option><option value="no">No</option>
            </select>
          </div>
        </div>
      </fieldset>

      <fieldset>
        <legend>Certification record (optional)</legend>
        <p className="small muted" style={{ marginTop: 0 }}>Values from a BIS registration, FCC filing or test report. Claims are checked against these.</p>
        <div className="grid-2">
          {input("certSource", "Source", { def: c.source, hint: "e.g. BIS R-41xxxxxx" })}
          {input("certBatteryMah", "Certified capacity (mAh)", { type: "number", def: c.batteryMah, err: "certified.batteryMah" })}
          {input("certIpRating", "Certified IP rating", { def: c.ipRating, err: "certified.ipRating" })}
          {input("certChargingW", "Certified charging (W)", { type: "number", def: c.chargingW, err: "certified.chargingW" })}
        </div>
      </fieldset>

      {scoreKeys.length > 0 && (
        <fieldset>
          <legend>Your ratings and benchmarks</legend>
          <div className="grid-2">
            {scoreKeys.map((k) => input(`score_${k}`, k[0].toUpperCase() + k.slice(1), { type: "number", step: "any", def: product?.scores[k], hint: SCORE_HINT[k], err: `scores.${k}` }))}
          </div>
        </fieldset>
      )}

      <fieldset>
        <legend>Cost</legend>
        <div className="grid-2">
          {input("shippingInr", "Shipping (₹)", { type: "number", def: product?.cost.shippingInr, err: "cost.shippingInr" })}
          {input("expectedYears", "Years you expect to use it", { type: "number", step: "0.5", def: product?.cost.expectedYears, err: "cost.expectedYears" })}
        </div>
        <p className="label" style={{ fontWeight: 500, margin: "4px 0 8px" }}>Offers</p>
        {offers.map((o, i) => (
          <div key={i} className="grid-3" style={{ alignItems: "end" }}>
            <div className="field"><label htmlFor={`pf-ol${i}`}>Offer {i + 1}</label><input id={`pf-ol${i}`} name={`offer_label_${i}`} defaultValue={o.label} placeholder="e.g. HDFC card discount" /></div>
            <div className="field"><label htmlFor={`pf-oa${i}`}>Amount off (₹)</label><input id={`pf-oa${i}`} name={`offer_amount_${i}`} type="number" defaultValue={o.amountInr ?? ""} /></div>
            <div className="field"><label className="check" htmlFor={`pf-oc${i}`}><input id={`pf-oc${i}`} type="checkbox" name={`offer_cond_${i}`} defaultChecked={o.conditional} /> Only for some buyers (card, exchange)</label></div>
          </div>
        ))}
        <p className="label" style={{ fontWeight: 500, margin: "4px 0 8px" }}>Things you must buy separately</p>
        {addOns.map((a, i) => (
          <div key={i} className="grid-2">
            <div className="field"><label htmlFor={`pf-al${i}`}>Item {i + 1}</label><input id={`pf-al${i}`} name={`addon_label_${i}`} defaultValue={a.label} placeholder="e.g. Charger, case" /></div>
            <div className="field"><label htmlFor={`pf-ac${i}`}>Cost (₹)</label><input id={`pf-ac${i}`} name={`addon_cost_${i}`} type="number" defaultValue={a.costInr ?? ""} /></div>
          </div>
        ))}
      </fieldset>

      <div className="btn-row">
        <button className="btn" disabled={f.busy}>{f.busy ? "Saving…" : product ? "Save changes" : "Add product"}</button>
        <button type="button" className="btn btn-secondary" onClick={onCancel}>Cancel</button>
      </div>
    </form>
  );
}
