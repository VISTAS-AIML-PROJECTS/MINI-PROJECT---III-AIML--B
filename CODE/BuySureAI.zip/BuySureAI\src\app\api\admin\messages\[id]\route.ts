import { handler, json, readJson, ApiError } from "@/lib/api";
import { messageStatusSchema } from "@/lib/validation";
import { adminLog, setContactStatus } from "@/lib/repos/misc";

export const PATCH = handler<{ id: string }>({ auth: "admin" }, async (req, { params, user }) => {
  const { status } = await readJson(req, messageStatusSchema, 1_000);
  if (!await setContactStatus(params.id, status)) throw new ApiError(404, "Message not found.");
  await adminLog(user!.id, "message.status", params.id, { status });
  return json({ ok: true });
});
