import "server-only";
import { env } from "../env";

/**
 * Tavily web search (https://docs.tavily.com/documentation/api-reference/endpoint/search).
 * One basic search = 1 credit (free plan, no card). Returns page text and images, so the AI
 * needs no separate page-reading step.
 */
export const tavilyEnabled = () => Boolean(env.TAVILY_API_KEY);

export type TavilyResult = { title: string; url: string; content: string };
export type TavilyImage = { url: string; description: string };

export async function tavilySearch(query: string, signal: AbortSignal, maxResults = 8): Promise<{ results: TavilyResult[]; images: TavilyImage[] }> {
  const res = await fetch("https://api.tavily.com/search", {
    method: "POST",
    headers: { Authorization: `Bearer ${env.TAVILY_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      query: query.slice(0, 380), search_depth: "basic", max_results: maxResults, country: "india",
      include_raw_content: "text", include_images: true, include_image_descriptions: true,
    }),
    signal: AbortSignal.any([signal, AbortSignal.timeout(20_000)]),
  });
  const data = (await res.json().catch(() => ({}))) as {
    results?: (TavilyResult & { raw_content?: string | null })[];
    images?: (TavilyImage | string)[];
    detail?: { error?: string } | string;
  };
  if (!res.ok) throw new Error(`Tavily ${res.status}: ${typeof data.detail === "string" ? data.detail : data.detail?.error ?? "error"}`.slice(0, 200));
  return {
    results: (data.results ?? [])
      .filter((r) => /^https?:\/\//.test(r.url))
      // Page text (trimmed) beats the short snippet: the AI reads prices and specs straight from it.
      .map((r) => ({ title: r.title ?? "", url: r.url, content: (r.raw_content || r.content || "").replace(/\s+/g, " ").slice(0, 2500) })),
    images: (data.images ?? [])
      .map((i) => (typeof i === "string" ? { url: i, description: "" } : { url: i.url, description: i.description ?? "" }))
      .filter((i) => /^https:\/\//.test(i.url)),
  };
}
