import "server-only";
import { notFound, redirect } from "next/navigation";
import { getSessionUser } from "./session";

/** For server components: the signed-in user, or a redirect to /login that returns here. */
export async function requireUser(returnTo: string) {
  const user = await getSessionUser();
  if (!user) redirect(`/login?next=${encodeURIComponent(returnTo)}`);
  return user;
}

/** Admin pages 404 for everyone else, so their existence is not advertised. */
export async function requireAdmin() {
  const user = await getSessionUser();
  if (!user) redirect("/login?next=/admin");
  if (user.role !== "admin") notFound();
  return user;
}
