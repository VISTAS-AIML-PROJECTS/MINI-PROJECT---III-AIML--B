import { handler, limit } from "@/lib/api";
import { exportUserData } from "@/lib/repos/users";

export const GET = handler({ auth: "user" }, async (_req, { user }) => {
  await limit(`export:${user!.id}`, 10, 3600);
  const body = JSON.stringify(await exportUserData(user!.id), null, 2);
  return new Response(body, {
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Content-Disposition": `attachment; filename="buysure-export-${new Date().toISOString().slice(0, 10)}.json"`,
      "Cache-Control": "no-store",
    },
  });
});
