import { handler, json, readJson, limit } from "@/lib/api";
import { caseSchema } from "@/lib/validation";
import { createCase, listCases } from "@/lib/repos/cases";

export const GET = handler({ auth: "user" }, async (_req, { user }) => json({ cases: await listCases(user!.id) }));

export const POST = handler({ auth: "user" }, async (req, { user }) => {
  await limit(`create-case:${user!.id}`, 30, 3600);
  const data = await readJson(req, caseSchema, 5_000);
  const id = await createCase(user!.id, data);
  return json({ id }, 201);
});
