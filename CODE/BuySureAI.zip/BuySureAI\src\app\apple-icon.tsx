import { ImageResponse } from "next/og";

export const size = { width: 180, height: 180 };
export const contentType = "image/png";

export default function AppleIcon() {
  return new ImageResponse(
    (
      <div style={{ width: "100%", height: "100%", background: "#f1ece1", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <svg width="132" height="132" viewBox="0 0 32 32">
          <circle cx="14" cy="14" r="9" fill="none" stroke="#1a1915" strokeWidth="2.6" />
          <path d="M21 21l7 7" stroke="#1a1915" strokeWidth="3.2" />
          <path d="M2 14h24" stroke="#b0301c" strokeWidth="2.2" />
          <path d="M9.6 10.4l3 3 5-5" fill="none" stroke="#1a1915" strokeWidth="2" />
        </svg>
      </div>
    ),
    size,
  );
}
