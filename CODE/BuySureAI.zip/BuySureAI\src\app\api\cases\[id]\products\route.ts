import { handler, json, readJson, limit } from "@/lib/api";
import { productSchema } from "@/lib/validation";
import { createProduct, getOwnedCase } from "@/lib/repos/cases";

export const POST = handler<{ id: string }>({ auth: "user" }, async (req, { params, user }) => {
  await limit(`create-product:${user!.id}`, 120, 3600);
  const row = await getOwnedCase(params.id, user!.id);
  const data = await readJson(req, productSchema, 50_000);
  const id = await createProduct(row.id, data);
  return json({ id }, 201);
});
