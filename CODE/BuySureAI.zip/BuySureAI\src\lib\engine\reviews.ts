import type { Finding, ReviewInput } from "./types";
import { clamp, contentWords, jaccard, mean, median, round, shingles, stdev, tokenize, UnionFind } from "./text";

/**
 * Review integrity forensics.
 *
 * Every signal here is statistical evidence, not proof. Each one is reported separately with
 * its value and threshold so the user can see why the score moved. Thresholds were chosen to be
 * conservative: an organically reviewed product should lose few or no points.
 */

const MAX_ANALYSED = 2000;
const NEAR_DUP_JACCARD = 0.55;

// Phrases that are over-represented in machine-written or incentivised praise. A weak signal on
// its own, so it carries the smallest penalty.
const MARKER_PHRASES = [
  "highly recommend", "game changer", "game-changer", "exceeded my expectations", "exceeded expectations",
  "sleek design", "must-have", "must have", "top-notch", "top notch", "seamless", "seamlessly",
  "elevate", "delve", "overall,", "in conclusion", "value for money", "worth every penny",
  "best in this price", "best in segment", "awesome product", "superb product", "nice product",
  "a testament to", "look no further", "hassle-free", "user-friendly", "stunning display",
];

const NEGATIVE_WORDS = [
  "worst", "defective", "fake", "duplicate", "stopped working", "not working", "refund", "waste of money",
  "heating issue", "overheat", "dead on arrival", "broken", "scam", "returned it", "damaged",
];

export const ASPECTS: Record<string, string[]> = {
  battery: ["battery", "backup", "drain", "draining", "mah", "sot"],
  charging: ["charging", "charger", "charge", "fast charge", "adapter", "brick"],
  heating: ["heat", "heating", "hot", "warm", "thermal", "throttle", "throttling"],
  display: ["display", "screen", "brightness", "sunlight", "outdoor", "amoled", "lcd", "refresh"],
  camera: ["camera", "photo", "photos", "video", "selfie", "lens", "low light", "night mode"],
  performance: ["lag", "laggy", "slow", "smooth", "performance", "gaming", "hang", "stutter", "fps"],
  software: ["bloatware", "ads", "update", "updates", "software", "ui", "os", "notification spam"],
  build: ["build", "plastic", "metal", "body", "frame", "scratch", "crack", "quality"],
  audio: ["speaker", "sound", "audio", "mic", "microphone", "volume"],
  network: ["network", "signal", "5g", "4g", "wifi", "wi-fi", "bluetooth", "call drop"],
  service: ["service", "warranty", "seller", "delivery", "packaging", "customer care", "return"],
};

export type ReviewReport = {
  count: number;
  analysed: number;
  score: number | null;
  confidence: "insufficient" | "low" | "medium" | "high";
  averageRating: number | null;
  adjustedRating: number | null;
  distribution: [number, number, number, number, number];
  signals: {
    duplicateShare: number;
    clusters: { size: number; sample: string }[];
    burstDays: { date: string; count: number; fiveStar: number }[];
    fiveStarBurstShare: number;
    shortPraiseShare: number;
    lengthCv: number | null;
    entropyCvRatio: number | null;
    markerShare: number;
    unverifiedShare: number | null;
    mismatchShare: number;
  };
  penalties: { code: string; label: string; points: number }[];
  aspects: { aspect: string; mentions: number; avgRating: number; negativeShare: number }[];
  findings: Finding[];
  flagged: number[];
};

const pct = (x: number) => `${Math.round(x * 100)}%`;

function day(iso?: string | null): string | null {
  if (!iso) return null;
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? null : d.toISOString().slice(0, 10);
}

export function analyseReviews(input: ReviewInput[]): ReviewReport {
  const reviews = input
    .filter((r) => Number.isInteger(r.rating) && r.rating >= 1 && r.rating <= 5 && typeof r.body === "string")
    .slice(0, MAX_ANALYSED);
  const n = reviews.length;
  const distribution: ReviewReport["distribution"] = [0, 0, 0, 0, 0];
  for (const r of reviews) distribution[r.rating - 1]++;

  const empty: ReviewReport = {
    count: input.length, analysed: n, score: null, confidence: "insufficient",
    averageRating: n ? round(mean(reviews.map((r) => r.rating)), 2) : null, adjustedRating: null, distribution,
    signals: {
      duplicateShare: 0, clusters: [], burstDays: [], fiveStarBurstShare: 0, shortPraiseShare: 0,
      lengthCv: null, entropyCvRatio: null, markerShare: 0, unverifiedShare: null, mismatchShare: 0,
    },
    penalties: [], aspects: [], flagged: [],
    findings: [{ module: "reviews", severity: "info", code: "REVIEWS_INSUFFICIENT", message: `Only ${n} usable review${n === 1 ? "" : "s"}. Add at least 5 to run review forensics.` }],
  };
  if (n < 5) return empty;

  const tokens = reviews.map((r) => tokenize(r.body));
  const lower = reviews.map((r) => r.body.toLowerCase());
  const five = reviews.map((r, i) => (r.rating === 5 ? i : -1)).filter((i) => i >= 0);
  const flagged = new Set<number>();
  const findings: Finding[] = [];
  const penalties: ReviewReport["penalties"] = [];
  const penalise = (code: string, label: string, points: number) => {
    if (points >= 0.5) penalties.push({ code, label, points: round(points, 1) });
  };

  // 1. Near-duplicate clusters (copy-paste or lightly spun templates).
  const sh = tokens.map((t) => shingles(t, 3));
  const uf = new UnionFind(n);
  for (let i = 0; i < n; i++) {
    if (tokens[i].length < 8) continue;
    for (let j = i + 1; j < n; j++) {
      if (tokens[j].length < 8) continue;
      const ratio = tokens[i].length / tokens[j].length;
      if (ratio < 0.5 || ratio > 2) continue;
      if (jaccard(sh[i], sh[j]) >= NEAR_DUP_JACCARD) uf.union(i, j);
    }
  }
  const clusters = uf.groups().filter((g) => g.length >= 2).sort((a, b) => b.length - a.length);
  const dupMembers = clusters.reduce((s, g) => s + g.length, 0);
  const duplicateShare = dupMembers / n;
  clusters.forEach((g) => g.forEach((i) => flagged.add(i)));
  penalise("DUPLICATES", "Near-duplicate review text", clamp((duplicateShare - 0.03) / 0.25, 0, 1) * 30);
  if (duplicateShare >= 0.05) {
    findings.push({
      module: "reviews", severity: duplicateShare >= 0.15 ? "fail" : "warn", code: "REVIEWS_DUPLICATES",
      message: `${pct(duplicateShare)} of reviews sit in ${clusters.length} near-identical text cluster${clusters.length === 1 ? "" : "s"} (largest: ${clusters[0].length} reviews).`,
    });
  }

  // 2. Temporal bursts: days whose volume is far above the robust baseline.
  const byDay = new Map<string, number[]>();
  reviews.forEach((r, i) => {
    const d = day(r.postedAt);
    if (!d) return;
    if (!byDay.has(d)) byDay.set(d, []);
    byDay.get(d)!.push(i);
  });
  let burstDays: ReviewReport["signals"]["burstDays"] = [];
  let fiveStarBurstShare = 0;
  if (byDay.size >= 7) {
    const dates = [...byDay.keys()].sort();
    const start = new Date(dates[0]).getTime();
    const end = new Date(dates[dates.length - 1]).getTime();
    const span = Math.round((end - start) / 86400_000) + 1;
    const counts: number[] = [];
    for (let k = 0; k < span; k++) {
      const d = new Date(start + k * 86400_000).toISOString().slice(0, 10);
      counts.push(byDay.get(d)?.length ?? 0);
    }
    const med = median(counts);
    const mad = median(counts.map((c) => Math.abs(c - med))) * 1.4826;
    const threshold = Math.max(5, med + 4 * Math.max(mad, 1));
    burstDays = [...byDay.entries()]
      .filter(([, idx]) => idx.length >= threshold)
      .map(([date, idx]) => ({ date, count: idx.length, fiveStar: idx.filter((i) => reviews[i].rating === 5).length }))
      .sort((a, b) => b.count - a.count);
    const burstFive = burstDays.reduce((s, b) => s + b.fiveStar, 0);
    fiveStarBurstShare = five.length ? burstFive / five.length : 0;
    if (burstDays.length) {
      const burstSet = new Set(burstDays.map((b) => b.date));
      five.forEach((i) => { const d = day(reviews[i].postedAt); if (d && burstSet.has(d)) flagged.add(i); });
      penalise("BURSTS", "5-star reviews concentrated in volume spikes", clamp((fiveStarBurstShare - 0.2) / 0.4, 0, 1) * 20);
      if (fiveStarBurstShare >= 0.25) {
        findings.push({
          module: "reviews", severity: fiveStarBurstShare >= 0.45 ? "fail" : "warn", code: "REVIEWS_BURSTS",
          message: `${pct(fiveStarBurstShare)} of 5-star reviews landed on ${burstDays.length} spike day${burstDays.length === 1 ? "" : "s"} (busiest: ${burstDays[0].date}, ${burstDays[0].count} reviews against a typical ${med}/day).`,
        });
      }
    }
  }

  // 3. Short generic praise among 5-star reviews.
  const shortPraise = five.filter((i) => contentWords(tokens[i]).length <= 4);
  const shortPraiseShare = five.length ? shortPraise.length / five.length : 0;
  shortPraise.forEach((i) => flagged.add(i));
  penalise("SHORT_PRAISE", "Very short, content-free 5-star reviews", clamp((shortPraiseShare - 0.3) / 0.4, 0, 1) * 10);
  if (shortPraiseShare >= 0.45 && five.length >= 10) {
    findings.push({ module: "reviews", severity: "warn", code: "REVIEWS_SHORT_PRAISE", message: `${pct(shortPraiseShare)} of 5-star reviews say almost nothing specific (four or fewer content words).` });
  }

  // 4. Stylometric uniformity: organic writing varies a lot in length and vocabulary spread.
  const longFive = five.filter((i) => tokens[i].length >= 8);
  let lengthCv: number | null = null;
  let entropyCvRatio: number | null = null;
  if (longFive.length >= 15) {
    const lens = longFive.map((i) => tokens[i].length);
    lengthCv = round(stdev(lens) / mean(lens), 2);
    penalise("UNIFORM_LENGTH", "Suspiciously uniform 5-star review length", clamp((0.45 - lengthCv) / 0.3, 0, 1) * 10);
    const other = reviews.map((r, i) => (r.rating <= 4 && tokens[i].length >= 8 ? i : -1)).filter((i) => i >= 0);
    if (other.length >= 10) {
      const ent = (idx: number[]) => idx.map((i) => new Set(tokens[i]).size / tokens[i].length);
      const cv = (xs: number[]) => (mean(xs) ? stdev(xs) / mean(xs) : 0);
      const cvOther = cv(ent(other));
      if (cvOther > 0) {
        entropyCvRatio = round(cv(ent(longFive)) / cvOther, 2);
        penalise("UNIFORM_STYLE", "5-star vocabulary far more uniform than other reviews", clamp((0.6 - entropyCvRatio) / 0.4, 0, 1) * 10);
      }
    }
    if ((lengthCv !== null && lengthCv < 0.3) || (entropyCvRatio !== null && entropyCvRatio < 0.4)) {
      findings.push({
        module: "reviews", severity: "warn", code: "REVIEWS_UNIFORM",
        message: `5-star reviews are stylistically uniform (length variation ${lengthCv}${entropyCvRatio !== null ? `, vocabulary variation ${entropyCvRatio}× that of lower-rated reviews` : ""}). Templated or generated text tends to look like this.`,
      });
    }
  }

  // 5. Marketing / LLM-style phrasing in 5-star reviews (weak signal).
  const markerHits = five.filter((i) => MARKER_PHRASES.filter((p) => lower[i].includes(p)).length >= 2);
  const markerShare = five.length ? markerHits.length / five.length : 0;
  markerHits.forEach((i) => flagged.add(i));
  penalise("MARKERS", "Stock marketing phrasing in praise", clamp((markerShare - 0.1) / 0.3, 0, 1) * 10);
  if (markerShare >= 0.2 && five.length >= 10) {
    findings.push({ module: "reviews", severity: "info", code: "REVIEWS_MARKERS", message: `${pct(markerShare)} of 5-star reviews use two or more stock marketing phrases ("highly recommend", "game changer", "seamless" and similar).` });
  }

  // 6. Unverified purchases, when the source exposes that flag.
  const withFlag = five.filter((i) => typeof reviews[i].verified === "boolean");
  let unverifiedShare: number | null = null;
  if (withFlag.length >= 10) {
    unverifiedShare = withFlag.filter((i) => reviews[i].verified === false).length / withFlag.length;
    penalise("UNVERIFIED", "Unverified 5-star reviews", clamp((unverifiedShare - 0.25) / 0.5, 0, 1) * 10);
    if (unverifiedShare >= 0.4) findings.push({ module: "reviews", severity: "warn", code: "REVIEWS_UNVERIFIED", message: `${pct(unverifiedShare)} of 5-star reviews are not marked as verified purchases.` });
  }

  // 7. Rating/text mismatch: 5 stars attached to clearly negative text (often incentivised).
  const mismatch = five.filter((i) => NEGATIVE_WORDS.some((w) => lower[i].includes(w)));
  const mismatchShare = five.length ? mismatch.length / five.length : 0;
  penalise("MISMATCH", "5-star ratings on complaint text", clamp((mismatchShare - 0.04) / 0.2, 0, 1) * 8);
  if (mismatchShare >= 0.08 && five.length >= 10) {
    findings.push({ module: "reviews", severity: "warn", code: "REVIEWS_MISMATCH", message: `${pct(mismatchShare)} of 5-star reviews contain complaint language ("defective", "refund", "stopped working"). Ratings may have been solicited.` });
  }

  // 8. Missing middle: almost no 2–4 star reviews on a large sample.
  const middle = (distribution[1] + distribution[2] + distribution[3]) / n;
  if (n >= 50 && middle < 0.06 && distribution[4] / n > 0.8) {
    penalise("NO_MIDDLE", "Almost no 2–4 star reviews", 5);
    findings.push({ module: "reviews", severity: "info", code: "REVIEWS_NO_MIDDLE", message: `Only ${pct(middle)} of reviews are 2–4 stars. Organic distributions usually have a visible middle.` });
  }

  const totalPenalty = penalties.reduce((s, p) => s + p.points, 0);
  const score = Math.round(clamp(100 - totalPenalty, 0, 100));
  const averageRating = round(mean(reviews.map((r) => r.rating)), 2);
  const kept = reviews.filter((_, i) => !flagged.has(i));
  const adjustedRating = kept.length ? round(mean(kept.map((r) => r.rating)), 2) : null;

  // Aspect breakdown (what people actually talk about, and how they rate it).
  const aspects = Object.entries(ASPECTS)
    .map(([aspect, words]) => {
      const idx = lower.map((t, i) => (words.some((w) => t.includes(w)) ? i : -1)).filter((i) => i >= 0 && !flagged.has(i));
      const ratings = idx.map((i) => reviews[i].rating);
      return {
        aspect,
        mentions: idx.length,
        avgRating: ratings.length ? round(mean(ratings), 2) : 0,
        negativeShare: ratings.length ? round(ratings.filter((r) => r <= 2).length / ratings.length, 2) : 0,
      };
    })
    .filter((a) => a.mentions >= 3)
    .sort((a, b) => a.avgRating - b.avgRating);

  const weakSpots = aspects.filter((a) => a.mentions >= 3 && a.avgRating <= (adjustedRating ?? averageRating) - 0.75).slice(0, 3);
  if (weakSpots.length) {
    findings.push({
      module: "reviews", severity: "info", code: "REVIEWS_WEAK_ASPECTS",
      message: `Recurring complaints after filtering: ${weakSpots.map((a) => `${a.aspect} (avg ${a.avgRating}★ across ${a.mentions} mentions)`).join(", ")}.`,
    });
  }
  if (adjustedRating !== null && averageRating - adjustedRating >= 0.3) {
    findings.push({ module: "reviews", severity: "warn", code: "REVIEWS_INFLATED", message: `Average drops from ${averageRating}★ to ${adjustedRating}★ once flagged reviews are set aside.` });
  }

  return {
    count: input.length,
    analysed: n,
    score,
    confidence: n < 20 ? "low" : n < 80 ? "medium" : "high",
    averageRating,
    adjustedRating,
    distribution,
    signals: {
      duplicateShare: round(duplicateShare, 3),
      clusters: clusters.slice(0, 5).map((g) => ({ size: g.length, sample: reviews[g[0]].body.slice(0, 160) })),
      burstDays: burstDays.slice(0, 5),
      fiveStarBurstShare: round(fiveStarBurstShare, 3),
      shortPraiseShare: round(shortPraiseShare, 3),
      lengthCv,
      entropyCvRatio,
      markerShare: round(markerShare, 3),
      unverifiedShare: unverifiedShare === null ? null : round(unverifiedShare, 3),
      mismatchShare: round(mismatchShare, 3),
    },
    penalties,
    aspects,
    findings,
    flagged: [...flagged].sort((a, b) => a - b),
  };
}
