import { handler, json, readJson, limit } from "@/lib/api";
import { reviewImportSchema } from "@/lib/validation";
import { clearReviews, getOwnedProduct, importReviews, listReviews, touchCase } from "@/lib/repos/cases";

type P = { id: string };

export const GET = handler<P>({ auth: "user" }, async (req, { params, user }) => {
  const row = await getOwnedProduct(params.id, user!.id);
  const sp = req.nextUrl.searchParams;
  const page = Math.max(1, Math.min(1000, Number(sp.get("page")) || 1));
  const rating = Number(sp.get("rating"));
  const result = await listReviews(row.id, page, 20, rating >= 1 && rating <= 5 ? rating : undefined);
  return json({ ...result, page, pageSize: 20 });
});

export const POST = handler<P>({ auth: "user" }, async (req, { params, user }) => {
  await limit(`import-reviews:${user!.id}`, 60, 3600);
  const row = await getOwnedProduct(params.id, user!.id);
  const { reviews, replace } = await readJson(req, reviewImportSchema, 5_000_000);
  const total = await importReviews(row.id, reviews, replace);
  await touchCase(row.case_id);
  return json({ imported: reviews.length, total }, 201);
});

export const DELETE = handler<P>({ auth: "user" }, async (_req, { params, user }) => {
  const row = await getOwnedProduct(params.id, user!.id);
  await clearReviews(row.id);
  await touchCase(row.case_id);
  return json({ ok: true });
});
