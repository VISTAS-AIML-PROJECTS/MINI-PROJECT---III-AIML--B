import type { Metadata } from "next";
import { pageMeta } from "@/lib/seo";
import { AuthShell } from "../AuthShell";
import { ForgotForm } from "../AuthForms";

export const metadata: Metadata = pageMeta({ title: "Reset your password", description: "Request a password reset link for your BuySure AI account.", path: "/forgot-password", noindex: true });

export default function ForgotPage() {
  return (
    <AuthShell title="Reset your password" intro="Enter your account email and we will send a link that works for 60 minutes.">
      <ForgotForm />
    </AuthShell>
  );
}
