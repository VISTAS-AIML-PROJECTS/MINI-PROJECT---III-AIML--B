import { handler, json, readJson } from "@/lib/api";
import { productUpdateSchema } from "@/lib/validation";
import { deleteProduct, getOwnedProduct, updateProduct } from "@/lib/repos/cases";

type P = { id: string };

export const PATCH = handler<P>({ auth: "user" }, async (req, { params, user }) => {
  const row = await getOwnedProduct(params.id, user!.id);
  const data = await readJson(req, productUpdateSchema, 50_000);
  await updateProduct(row, data);
  return json({ ok: true });
});

export const DELETE = handler<P>({ auth: "user" }, async (_req, { params, user }) => {
  const row = await getOwnedProduct(params.id, user!.id);
  await deleteProduct(row);
  return json({ ok: true });
});
