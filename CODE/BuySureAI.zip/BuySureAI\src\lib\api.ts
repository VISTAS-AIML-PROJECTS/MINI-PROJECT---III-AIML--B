import "server-only";
import { NextResponse, type NextRequest } from "next/server";
import { z } from "zod";
import { env } from "./env";
import { log } from "./logger";
import { rateLimit } from "./rate-limit";
import { getSessionUser, type SessionUser } from "./auth/session";

export class ApiError extends Error {
  constructor(public status: number, message: string, public fields?: Record<string, string>) {
    super(message);
  }
}

export const json = (data: unknown, init?: number | ResponseInit) =>
  NextResponse.json(data, typeof init === "number" ? { status: init } : init);

export function clientIp(req: NextRequest): string {
  if (env.TRUST_PROXY) {
    const fwd = req.headers.get("x-forwarded-for");
    if (fwd) return fwd.split(",")[0].trim();
    const real = req.headers.get("x-real-ip");
    if (real) return real;
  }
  return "local";
}

/**
 * CSRF defence for cookie-authenticated, state-changing requests: the browser-supplied Origin
 * (or Referer) must match this deployment. Session cookies are also SameSite=Lax.
 */
export function assertSameOrigin(req: NextRequest) {
  if (["GET", "HEAD", "OPTIONS"].includes(req.method)) return;
  const origin = req.headers.get("origin") ?? (() => {
    const ref = req.headers.get("referer");
    try { return ref ? new URL(ref).origin : null; } catch { return null; }
  })();
  const allowed = new Set([env.APP_URL, req.nextUrl.origin]);
  if (!origin || !allowed.has(origin)) throw new ApiError(403, "Cross-site request blocked.");
}

export async function readJson<S extends z.ZodType>(req: NextRequest, schema: S, maxBytes = 1_000_000): Promise<z.infer<S>> {
  const len = Number(req.headers.get("content-length") ?? 0);
  if (len > maxBytes) throw new ApiError(413, "Request body is too large.");
  let raw: string;
  try {
    raw = await req.text();
  } catch {
    throw new ApiError(400, "Could not read request body.");
  }
  if (raw.length > maxBytes) throw new ApiError(413, "Request body is too large.");
  let data: unknown;
  try {
    data = raw ? JSON.parse(raw) : {};
  } catch {
    throw new ApiError(400, "Request body must be valid JSON.");
  }
  const parsed = schema.safeParse(data);
  if (!parsed.success) {
    const fields: Record<string, string> = {};
    for (const issue of parsed.error.issues) {
      const key = issue.path.join(".") || "_";
      fields[key] ??= issue.message;
    }
    throw new ApiError(422, "Some fields need attention.", fields);
  }
  return parsed.data;
}

export async function limit(key: string, max: number, windowSeconds: number) {
  const r = await rateLimit(key, max, windowSeconds);
  if (!r.ok) throw new ApiError(429, `Too many requests. Try again in ${r.retryAfter} seconds.`);
}

type Ctx<P> = { params: Promise<P> };
type Opts = { auth?: "user" | "admin" };

/**
 * Wraps a route handler with CSRF checks, optional auth/role enforcement, and uniform error
 * responses. Unexpected errors are logged server-side and returned as a generic 500.
 */
export function handler<P = Record<string, string>>(
  opts: Opts,
  fn: (req: NextRequest, ctx: { params: P; user: SessionUser | null }) => Promise<Response>,
) {
  return async (req: NextRequest, ctx: Ctx<P>) => {
    try {
      assertSameOrigin(req);
      const user = await getSessionUser();
      if (opts.auth && !user) throw new ApiError(401, "Please sign in.");
      if (opts.auth === "admin" && user?.role !== "admin") throw new ApiError(403, "Administrator access required.");
      const params = ctx?.params ? await ctx.params : ({} as P);
      return await fn(req, { params, user });
    } catch (err) {
      if (err instanceof ApiError) {
        return json({ error: err.message, fields: err.fields }, {
          status: err.status,
          headers: err.status === 429 ? { "Retry-After": "60" } : undefined,
        });
      }
      log.error("Unhandled API error", err, { path: req.nextUrl.pathname, method: req.method });
      return json({ error: "Something went wrong on our side. Please try again." }, 500);
    }
  };
}
