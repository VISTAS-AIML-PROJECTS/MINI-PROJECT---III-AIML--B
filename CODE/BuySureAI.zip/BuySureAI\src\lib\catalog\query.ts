import { CATEGORIES, type CategoryDef } from "./categories";

/**
 * Understands free-text shopping queries without an AI model: category, budget, priority, and
 * product links. Used for instant catalogue results and as the offline fallback.
 */

export type ParsedQuery = {
  raw: string;
  category: CategoryDef | null;
  budget: number | null;
  preset: string | null;
  url: { host: string; store: string; words: string[] } | null;
  terms: string[];
};

const PRIORITY: Record<string, string[]> = {
  camera: ["camera", "photo", "photography", "selfie", "video", "vlog", "zoom"],
  battery: ["battery", "backup", "long lasting", "mah", "endurance", "capacity"],
  gaming: ["gaming", "game", "bgmi", "fast", "performance", "speed", "processor", "power user", "editing"],
  anc: ["anc", "noise cancelling", "noise canceling", "quiet", "commute", "flight"],
  workout: ["gym", "workout", "running", "sweat", "sports"],
  laptop: ["laptop charging", "charge laptop", "macbook charging", "65w", "67w", "pd"],
  travel: ["light", "lightweight", "travel", "portable", "thin"],
  student: ["student", "college", "school"],
  value: ["cheapest", "cheap", "budget", "lowest price", "value"],
};

const STORES: Record<string, string> = {
  "amazon.in": "Amazon", "amazon.com": "Amazon", "amzn.in": "Amazon", "amzn.to": "Amazon", "flipkart.com": "Flipkart", "dl.flipkart.com": "Flipkart",
  "croma.com": "Croma", "reliancedigital.in": "Reliance Digital", "myntra.com": "Myntra", "nykaa.com": "Nykaa", "tatacliq.com": "Tata CLiQ", "jiomart.com": "JioMart",
  "meesho.com": "Meesho", "ajio.com": "AJIO", "vijaysales.com": "Vijay Sales",
};

export function parseBudget(q: string): number | null {
  const s = q.toLowerCase().replace(/,/g, "");
  const m =
    /(?:under|below|within|less than|upto|up to|max|budget|<)\s*(?:rs\.?|inr|₹)?\s*(\d+(?:\.\d+)?)\s*(k|thousand|lakh|lac|l)?\b/.exec(s) ??
    /(?:rs\.?|inr|₹)\s*(\d+(?:\.\d+)?)\s*(k|thousand|lakh|lac|l)?\b/.exec(s) ??
    /\b(\d+(?:\.\d+)?)\s*(k|thousand|lakh|lac)\b/.exec(s);
  if (!m) return null;
  let n = Number(m[1]);
  const unit = m[2];
  if (unit === "k" || unit === "thousand") n *= 1000;
  else if (unit === "lakh" || unit === "lac" || unit === "l") n *= 100000;
  return n >= 100 && n <= 10_000_000 ? Math.round(n) : null;
}

export function parseUrl(input: string): ParsedQuery["url"] {
  const m = /https?:\/\/[^\s]+/i.exec(input);
  if (!m) return null;
  try {
    const u = new URL(m[0]);
    const host = u.hostname.replace(/^www\.|^m\./, "");
    const store = STORES[host] ?? host;
    // Marketplace URLs carry the product title as a slug: /Redmi-15C-5G-Storage/dp/B0..., /poco-m7-pro-5g/p/itm...
    const words = decodeURIComponent(u.pathname)
      .split(/[/\-_+.]/)
      .map((w) => w.toLowerCase())
      .filter((w) => (w.length > 1 || /^\d$/.test(w)) && !/^(dp|p|gp|product|itm\w*|b0\w{8}|ref|html|s|pid|buy|online)$/.test(w) && !/^\d{6,}$/.test(w));
    return { host, store, words: words.slice(0, 14) };
  } catch {
    return null;
  }
}

export function detectCategory(text: string): CategoryDef | null {
  const t = ` ${text.toLowerCase()} `;
  let best: CategoryDef | null = null;
  let bestScore = 0;
  for (const c of CATEGORIES) {
    const score = c.keywords.reduce((s, k) => s + (t.includes(` ${k} `) || t.includes(` ${k}s `) || t.includes(`${k} `) ? k.length : 0), 0);
    if (score > bestScore) { best = c; bestScore = score; }
  }
  return best;
}

export function parseQuery(raw: string): ParsedQuery {
  const q = raw.trim().slice(0, 500);
  const url = parseUrl(q);
  const text = url ? url.words.join(" ") : q;
  const category = detectCategory(text);
  let preset: string | null = null;
  if (category && !url) {
    const lower = q.toLowerCase();
    for (const p of category.presets) {
      if ((PRIORITY[p.key] ?? []).some((w) => lower.includes(w))) { preset = p.key; break; }
    }
  }
  const terms = text.toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, " ").split(/\s+/).filter((w) => w.length > 1 || /^\d$/.test(w));
  return { raw: q, category, budget: url ? null : parseBudget(q), preset, url, terms };
}

/** Token-overlap match of a query (or URL slug) against product names: finds "the product you searched". */
export function matchProduct<T extends { name: string; brand: string }>(terms: string[], items: T[]): { item: T; score: number } | null {
  const stop = new Set(["best", "phone", "mobile", "under", "with", "and", "the", "for", "buy", "price", "india", "gb", "ram", "storage", "5g", "new", "latest"]);
  const q = new Set(terms.filter((t) => !stop.has(t)));
  if (!q.size) return null;
  let best: { item: T; score: number } | null = null;
  for (const it of items) {
    const name = `${it.brand} ${it.name}`.toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, " ").split(/\s+/).filter((w) => w.length > 0 && !stop.has(w));
    const nameSet = new Set(name);
    let hit = 0;
    for (const w of nameSet) if (q.has(w)) hit++;
    // Model numbers matter most: "15c" vs "15" must not collide.
    const modelHits = [...nameSet].filter((w) => /\d/.test(w) && q.has(w)).length;
    const score = (hit + modelHits) / (nameSet.size + 1);
    if (hit >= 2 && modelHits >= 1 && (!best || score > best.score)) best = { item: it, score };
  }
  return best && best.score >= 0.45 ? best : null;
}
