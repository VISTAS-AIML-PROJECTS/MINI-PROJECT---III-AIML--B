import type { ReactNode } from "react";
import { Suspense } from "react";

export function AuthShell({ title, intro, children }: { title: string; intro: ReactNode; children: ReactNode }) {
  return (
    <div className="wrap" style={{ display: "grid", placeItems: "center", padding: "56px var(--gutter) 96px" }}>
      <div style={{ width: "100%", maxWidth: 420 }}>
        <h1 style={{ fontSize: "var(--step-3)" }}>{title}</h1>
        <p className="muted">{intro}</p>
        <div className="panel" style={{ marginTop: 20 }}>
          <Suspense fallback={<div className="skeleton" style={{ height: 220 }} />}>{children}</Suspense>
        </div>
      </div>
    </div>
  );
}
