import { handler, json, readJson } from "@/lib/api";
import { caseUpdateSchema } from "@/lib/validation";
import { caseView, deleteCase, getOwnedCase, latestAudit, listProducts, updateCase } from "@/lib/repos/cases";

type P = { id: string };

export const GET = handler<P>({ auth: "user" }, async (_req, { params, user }) => {
  const row = await getOwnedCase(params.id, user!.id);
  const audit = await latestAudit(row.id);
  return json({ case: caseView(row), products: await listProducts(row.id), audit });
});

export const PATCH = handler<P>({ auth: "user" }, async (req, { params, user }) => {
  const row = await getOwnedCase(params.id, user!.id);
  const data = await readJson(req, caseUpdateSchema, 5_000);
  await updateCase(row, data);
  return json({ ok: true });
});

export const DELETE = handler<P>({ auth: "user" }, async (_req, { params, user }) => {
  const row = await getOwnedCase(params.id, user!.id);
  await deleteCase(row.id);
  return json({ ok: true });
});
