# BuySure AI

Purchase forensics for online shoppers. You give BuySure the products on your shortlist (listing data, specs, offers, seller details, reviews). It returns a transparent audit:

- **Review forensics**: near-duplicate clusters, 5★ volume spikes, content-free praise, stylometric uniformity, stock marketing phrasing, unverified purchases, rating/text mismatch, and an adjusted rating with flagged reviews set aside. It also breaks down which aspects real reviewers complain about.
- **Physics checks**: battery energy density against body volume and mass, charge-time floors, power-bank delivered capacity, and fake-capacity flash pricing.
- **Certification checks**: listing claims (capacity, IP rating, charging power) against a BIS/FCC record you attach.
- **True cost**: missing accessories, shipping, unconditional and conditional offers, and cost per year.
- **Seller network**: white-labelled products linked through a shared manufacturer, importer or address.
- **Weighted verdict**: min–max normalised decision matrix with live sliders. Impossible or low-integrity products always rank last.
- **Price watches**: logged price history, alerts at your target, and a first-passage probability estimate.
- Optional **plain-language summary** written by Claude (Anthropic API) from the audit numbers.

Every threshold is published at `/how-it-works`.

> **Scope decisions (deliberate).** The original brief described CAPTCHA-bypassing scraper swarms, shadow-DOM payload injection, and an "auto-buy sniper" holding tokenised cards. Those are not built: they break marketplace terms and computer-misuse law in most jurisdictions, and auto-purchasing with stored cards creates payment-security and liability exposure. BuySure works on data the user supplies and can verify, and alerts rather than buys. The brief also contained specific claims about real phones (for example, that 32% of one brand's reviews were LLM-generated). Those are not reproduced. The demo uses clearly labelled **fictional** products so no real brand is defamed.

---

## Technology stack

| Layer | Choice | Why |
|---|---|---|
| Framework | **Next.js 16** (App Router, Turbopack), React 19, TypeScript | Server components for fast SEO pages; route handlers for a REST API in one deployable |
| Database | **SQLite via Node's built-in `node:sqlite`** | Zero native dependencies, transactional, fast. Right-sized for a single-server launch; the data layer is isolated in `src/lib/repos` for a later Postgres move |
| Validation | **Zod 4** | One schema set shared by forms and the API (the server is authoritative) |
| Auth | Custom sessions: **scrypt** password hashes, random 256-bit tokens stored as SHA-256 hashes, `__Host-` HttpOnly SameSite cookies | No third-party auth dependency; full control over security properties |
| 3D | **three.js**, lazy-loaded | Hero "seller network" visual; static SVG fallback |
| Email | Resend HTTP API (optional) | Password resets, price alerts, contact notifications |
| AI summary | `@anthropic-ai/sdk`, model `claude-opus-5-5` (optional) | Explains audit numbers in plain English; never alters scores |
| Analytics | Google Analytics 4, **consent-gated** | Loaded only after opt-in; Google signals and ad personalisation off |
| Tests | Vitest (unit/repository), HTTP smoke suite, puppeteer-core visual QA | |

## Architecture

```
Browser ──► Next.js (Node runtime)
            ├─ Server components (marketing, dashboard, admin) ─┐
            ├─ Route handlers /api/* ── handler() wrapper:      │
            │     CSRF origin check → session → role check →    │
            │     Zod validation → rate limit → repo call       │
            ├─ Engine (src/lib/engine, pure TS, also runs in    │
            │     the browser for instant re-ranking)           │
            └─ Repositories (src/lib/repos) ─► SQLite (WAL) ◄───┘
External (optional): Resend (email) · Anthropic API (summaries) · Google Analytics (consented)
Scheduler (any): POST /api/cron with CRON_SECRET
```

### Folder structure

```
migrations/            SQL migrations (applied automatically on first DB open)
scripts/               migrate, create-admin, smoke test, visual QA
src/app/               routes: pages, API route handlers, metadata files (robots, sitemap, OG image, icons)
  (auth)/              login, register, forgot/reset password
  dashboard/           cases, case workspace, price watches, settings
  admin/               overview, users, messages, review moderation
  api/                 REST endpoints
src/components/        UI: header/footer, report view, 3D hero, forms, consent
src/lib/engine/        forensic engine: reviews, physics, cost, price, network, decision
src/lib/repos/         data access (all SQL lives here, parameterised)
src/lib/               db, env, auth, api wrapper, validation, rate limit, email, llm, seo
src/content/team.ts    team profiles (empty until real people are added)
tests/                 unit and repository tests
```

### Database schema

| Table | Purpose | Key relations / constraints |
|---|---|---|
| `users` | accounts | unique case-insensitive email; role `user`/`admin`; `disabled_at` |
| `sessions` | login sessions | id = SHA-256(token); FK users ON DELETE CASCADE; expiry index |
| `password_resets` | reset tokens (hashed, 60 min) | FK users CASCADE |
| `rate_limits` | fixed-window counters | key PK |
| `cases` | one buying decision | FK users CASCADE; category CHECK; unique `share_slug`; index (user, updated) |
| `products` | listings in a case | FK cases CASCADE; JSON columns for specs, certified values, scores, cost |
| `reviews` | imported reviews | FK products CASCADE; rating CHECK 1–5 |
| `audit_runs` | stored reports (latest 20 per case) | FK cases CASCADE |
| `audit_findings` | normalised findings per run | FK runs/products CASCADE; module/severity CHECKs |
| `price_watches`, `price_observations` | targets and logged prices | FK users / watches CASCADE |
| `notifications` | in-app alerts | FK users CASCADE |
| `contact_messages` | contact form | status CHECK; index (status, created) |
| `site_reviews` | reviews of BuySure itself | one per user; moderated status |
| `admin_log` | audit trail of admin actions | FK users SET NULL |

## Getting started

Requirements: **Node.js 22.13+** (for `node:sqlite`; developed on Node 26).

```bash
npm install
cp .env.example .env          # fill SESSION_SECRET at minimum for production
npm run db:migrate            # optional: migrations also run automatically on first request
npm run dev                   # http://localhost:3000
```

Create an administrator (works for a new or an existing account):

```bash
npm run db:create-admin -- you@example.com "Your Name"   # prompts for a password, or set ADMIN_PASSWORD
```

## Environment variables

See `.env.example` for descriptions. **[secret]** values must stay server-side.

| Variable | Required | Notes |
|---|---|---|
| `APP_URL` | prod | Public origin; used for CSRF origin checks and email links |
| `NEXT_PUBLIC_SITE_URL` | prod (build time) | Canonical URLs, sitemap, Open Graph |
| `SESSION_SECRET` [secret] | prod | ≥ 32 chars; the server refuses to start in production without it |
| `DATABASE_PATH` | no | Default `data/buysure.db`; use persistent storage |
| `TRUST_PROXY` | behind a proxy | `true` so rate limits use the client IP from `X-Forwarded-For` |
| `RESEND_API_KEY` [secret], `EMAIL_FROM`, `CONTACT_INBOX` | no | Email delivery |
| `ANTHROPIC_API_KEY` [secret], `ANTHROPIC_MODEL` | no | Plain-language summaries |
| `CRON_SECRET` [secret] | if using cron | Bearer token for `/api/cron` |
| `NEXT_PUBLIC_GA_ID`, `NEXT_PUBLIC_CONTACT_EMAIL`, `NEXT_PUBLIC_BUSINESS_ADDRESS` | no | Build-time public values |

## Testing

```bash
npm run typecheck
npm test               # 51 unit + repository tests (engine, parsing, hashing, validation, IDOR, cascades, rate limits, transactions)
npm run build
npm run test:smoke     # 140 HTTP checks against the production build on a throwaway DB
npm run test:visual    # needs Chrome or Edge installed: screenshots + console-error and mobile-overflow checks
```

The smoke suite covers: every public page (status, unique title, meta description, canonical, one `<h1>`, og:image, alt text), custom 404, robots, sitemap, OG image, favicon, manifest, structured data, security headers, CSRF (missing and foreign Origin), validation errors, duplicate accounts, session cookie flags, auth redirects, sample case, audit, XSS escaping, `javascript:` URL rejection, share links and revocation, IDOR (read/edit/delete another user's data), admin API and page protection, privilege escalation, cron auth, the admin promotion script, price alerts and notifications, contact form and honeypot, review moderation, login brute-force limiting, no account enumeration, data export, logout, and a crawl of all internal links.

## Deployment

The app is a long-running Node server with a SQLite file, so deploy it where a **persistent disk** is available: a VPS, Fly.io (volume), Railway (volume), Render (disk), or any Docker host. **Serverless platforms with ephemeral filesystems (such as Vercel) are not suitable** unless you first move the repositories to a hosted database.

### Docker (recommended)

```bash
docker build -t buysure \
  --build-arg NEXT_PUBLIC_SITE_URL=https://buysure.example \
  --build-arg NEXT_PUBLIC_GA_ID=G-XXXXXXX .
docker run -d -p 3000:3000 -v buysure-data:/data \
  -e APP_URL=https://buysure.example -e SESSION_SECRET=... -e TRUST_PROXY=true \
  -e CRON_SECRET=... -e RESEND_API_KEY=... buysure
```

To make the first admin in a container: register normally on the site, then promote that account with Node's built-in SQLite:

```bash
docker exec -it <container> node -e "const {DatabaseSync}=require('node:sqlite');new DatabaseSync('/data/buysure.db').prepare(\"UPDATE users SET role='admin' WHERE email=?\").run(process.argv[1])" you@example.com
```

`docker compose up --build` does the same with `.env`. The image runs as a non-root user, stores the database on the `/data` volume, and has a health check on `/api/health`.

### Without Docker

```bash
npm ci && NEXT_PUBLIC_SITE_URL=https://buysure.example npm run build
cp -r .next/static .next/standalone/.next/ && cp -r public .next/standalone/
cd .next/standalone && APP_URL=... SESSION_SECRET=... DATABASE_PATH=/var/lib/buysure/buysure.db node server.js
```

### Production checklist

1. HTTPS in front (Caddy, Nginx, or the platform's TLS). Session cookies are `Secure` and `__Host-` prefixed, so **sign-in requires HTTPS** in production. HSTS is sent automatically.
2. Set `APP_URL`, `NEXT_PUBLIC_SITE_URL` (at build), `SESSION_SECRET`, and `TRUST_PROXY=true` behind a proxy.
3. Point DNS at the host; `APP_URL` must match the public origin exactly, or state-changing requests will be rejected as cross-site.
4. Schedule the maintenance job every 15–60 minutes:
   `curl -X POST -H "Authorization: Bearer $CRON_SECRET" https://buysure.example/api/cron`
5. Back up the SQLite file, for example `sqlite3 buysure.db ".backup '/backups/buysure-$(date +%F).db'"` daily, or Litestream for continuous replication.
6. Create an admin account; fill in `src/content/team.ts`; have a lawyer complete the bracketed placeholders in `/privacy` and `/terms`.
7. Verify the sender domain in Resend if using email; add your GA4 ID if using analytics.
8. Ship logs (JSON on stdout/stderr) to your log platform and monitor `/api/health`.

## Free production setup (current live site)

Live at **https://buysure-ai.vercel.app**, running entirely on free tiers:

| Piece | Service | Notes |
|---|---|---|
| App + API | Vercel Hobby (project `buysure-ai`, region `hnd1`) | `npx vercel deploy --prod` from this folder; daily cron hits `/api/cron` |
| Database | Supabase Postgres (project `BuySure-AI`, Tokyo) | App connects as the restricted role `buysure_app` through the transaction pooler (port 6543). It owns its tables; RLS is on with no policies, so Supabase's public Data API cannot read them |
| Photos | Stored in the `media` table | No disk needed |
| Live AI search | Gemini free tier (`GEMINI_API_KEY`) + Tavily free search (`TAVILY_API_KEY`, 1,000 searches/month) | Order: Google Search grounding if the key has quota (free keys do not), then Tavily results plus Gemini reading the pages, then verified page reading. Known categories merge with the verified catalogue. Star ratings are never a ranking criterion |

Production environment variables live in Vercel (`npx vercel env ls production`): `DATABASE_URL`, `SESSION_SECRET`, `CRON_SECRET`, `TRUST_PROXY`, `APP_URL`, `NEXT_PUBLIC_SITE_URL`, and optionally `GEMINI_API_KEY`.

To switch on free live search: create a key at https://aistudio.google.com/apikey, then
`npx vercel env add GEMINI_API_KEY production --sensitive` and `npx vercel deploy --prod`.

Local development still uses SQLite (no `DATABASE_URL` set); `DATABASE_URL` switches any environment to Postgres. Migrations live in `migrations/sqlite` and `migrations/postgres` and run automatically.

Note: Vercel's Hobby plan is for non-commercial use. Upgrade to Pro before charging customers.

## API reference

All endpoints take and return JSON. State-changing requests must come from the site's own origin (CSRF check). Errors look like `{ "error": string, "fields"?: { [field]: message } }` with 401/403/404/409/413/422/429/5xx statuses.

| Method & path | Auth | Purpose |
|---|---|---|
| `POST /api/auth/register` | – | `{name,email,password,acceptTerms}` → creates account, signs in |
| `POST /api/auth/login` / `logout` | – | Session management |
| `POST /api/auth/forgot` · `POST /api/auth/reset` | – | Password reset flow (`{email}` · `{token,password}`) |
| `GET/PATCH/DELETE /api/me` | user | Profile; delete requires `{password}` |
| `POST /api/me/password` · `GET /api/me/export` | user | Change password · JSON data export |
| `GET/POST /api/cases` · `POST /api/cases/sample` | user | List/create cases · copy the sample case |
| `GET/PATCH/DELETE /api/cases/:id` | owner | Case with products and latest audit; update title/budget/weights |
| `POST /api/cases/:id/products` | owner | Add product (see `productSchema`) |
| `GET/POST /api/cases/:id/audit` | owner | Latest audit · run audit (`{weights?}`) |
| `POST /api/cases/:id/narrative` | owner | Plain-language summary (503 if not configured) |
| `POST /api/cases/:id/share` | owner | `{enabled}` → share slug |
| `PATCH/DELETE /api/products/:id` | owner | Edit/remove product |
| `GET/POST/DELETE /api/products/:id/reviews` | owner | Paginated list · import `{reviews[],replace}` (≤5,000) · clear |
| `GET/POST /api/watches` · `PATCH/DELETE /api/watches/:id` | owner | Price watches |
| `POST /api/watches/:id/observations` · `DELETE …/:obsId` | owner | Log/remove prices; returns `{fired}` |
| `GET/POST /api/notifications` | user | List · mark all read |
| `POST /api/contact` | – | Contact form (honeypot + timing check, 5/hour/IP) |
| `GET/POST /api/site-reviews` | –/user | Approved reviews · submit own review for moderation |
| `POST /api/demo/audit` | – | Runs the engine on the fictional sample (nothing stored) |
| `GET /api/admin/users`, `PATCH /api/admin/users/:id`, `PATCH /api/admin/messages/:id`, `PATCH /api/admin/site-reviews/:id` | admin | Administration (logged to `admin_log`) |
| `GET /api/health` | – | Liveness and DB readiness |
| `POST /api/cron` | bearer | Price-alert sweep and cleanup |

## Admin guide

Sign in as an admin and open **Admin** in the header.

- **Overview**: counts and recent admin actions.
- **Users**: search, promote or demote, and disable accounts. Disabling signs the user out everywhere. You cannot demote or disable yourself or the last admin.
- **Messages**: contact-form submissions; mark read or archive.
- **Review moderation**: approve or reject reviews of BuySure. Approve critical reviews too; reject only spam, abuse or personal data.

Admins cannot see users' cases; that data stays private to its owner.

## Security summary

Parameterised SQL everywhere (no string-built queries; LIKE wildcards escaped) · Zod validation on every input with size limits · React output escaping (verified by test) and JSON-LD `<` escaping · CSRF origin check plus SameSite cookies · scrypt hashing, timing-safe comparison, dummy hash for unknown emails (no enumeration) · hashed session and reset tokens, sessions revoked on password change or reset · ownership in every query's WHERE clause (IDOR returns 404) · server-side role checks on admin APIs and pages · DB-backed rate limits on login, registration, reset, contact, imports and audits · honeypot and timing checks on public forms · client-side file-type and size checks plus server-side body limits · CSP, HSTS, X-Frame-Options, nosniff, Referrer-Policy, Permissions-Policy, COOP · no stack traces to clients (errors logged server-side with a digest) · secrets only from environment variables, validated at startup · open-redirect protection on `?next=`.

Known trade-off: the CSP allows `'unsafe-inline'` scripts, because Next.js hydration needs it without a nonce setup. Switching to nonces via `proxy.ts` would make every page dynamic.

## Known limitations

- **No automatic data collection.** Users enter listing data and paste reviews; the engine is only as good as that input.
- **Review signals are statistical.** They can produce false positives on small honest sellers and can be evaded by careful farms. The UI states this.
- **Physics ceilings are conservative constants** (in `src/lib/engine/physics.ts`). They catch impossible claims, not merely optimistic ones.
- **Price forecasts** use a random-walk model on user-logged prices; sales and launches are jump events it cannot predict.
- **Single-instance SQLite.** Horizontal scaling needs a shared database. The rate limiter is per database, so it is shared by all requests on one instance.
- **Email, AI summaries and analytics** do nothing until their keys are configured, and the UI degrades accordingly.
- **Legal pages are templates** with bracketed placeholders and must be reviewed by a lawyer before launch.
- **No team, case studies or reviews are shown** until real ones exist; the pages say so.
- The Docker image was written but not built in the development environment (Docker was unavailable). The standalone server it packages was booted and verified directly.

## Future improvements

Browser extension that pre-fills a product from the page you are viewing (user-initiated, no scraping); official marketplace or affiliate-free product APIs where terms allow; Postgres adapter; multi-language UI (Hindi first); per-category physics profiles for TVs and appliances; reviewer-history signals when sources expose them; organisation API tier.
