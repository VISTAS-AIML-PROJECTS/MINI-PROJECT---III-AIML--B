export default function Loading() {
  return (
    <div aria-busy="true" aria-label="Loading">
      <div className="skeleton" style={{ height: 36, width: "40%", marginBottom: 24 }} />
      <div className="skeleton" style={{ height: 160, marginBottom: 24 }} />
      {[0, 1, 2].map((i) => <div key={i} className="skeleton skeleton-line" style={{ width: `${90 - i * 15}%`, height: 20 }} />)}
    </div>
  );
}
