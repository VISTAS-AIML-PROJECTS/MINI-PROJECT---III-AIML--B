import { handler, json, readJson, limit, ApiError } from "@/lib/api";
import { deleteAccountSchema, profileSchema } from "@/lib/validation";
import { deleteUser, findUserById, updateUserName } from "@/lib/repos/users";
import { verifyPassword } from "@/lib/auth/password";
import { destroySession } from "@/lib/auth/session";
import { countAdmins, unreadCount } from "@/lib/repos/misc";

export const GET = handler({}, async (_req, { user }) => {
  if (!user) return json({ user: null });
  return json({ user: { ...user, unread: await unreadCount(user.id) } });
});

export const PATCH = handler({ auth: "user" }, async (req, { user }) => {
  const { name } = await readJson(req, profileSchema, 2_000);
  await updateUserName(user!.id, name);
  return json({ ok: true });
});

export const DELETE = handler({ auth: "user" }, async (req, { user }) => {
  await limit(`delete-account:${user!.id}`, 5, 900);
  const { password } = await readJson(req, deleteAccountSchema, 2_000);
  const row = (await findUserById(user!.id))!;
  if (!(await verifyPassword(password, row.password_hash))) throw new ApiError(401, "Password is incorrect.", { password: "Password is incorrect." });
  if (row.role === "admin" && await countAdmins() <= 1) throw new ApiError(409, "You are the only administrator. Promote someone else first.");
  await destroySession();
  await deleteUser(row.id); // cascades to cases, products, reviews, watches, notifications, sessions
  return json({ ok: true });
});
