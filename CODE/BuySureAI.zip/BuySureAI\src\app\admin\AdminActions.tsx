"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/lib/client-api";
import { useToast } from "@/components/Toast";

/** A button that PATCHes an admin endpoint, then refreshes the server-rendered list. */
export function AdminButton({ url, body, label, confirmText, danger }: {
  url: string; body: Record<string, unknown>; label: string; confirmText?: string; danger?: boolean;
}) {
  const router = useRouter();
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  return (
    <button
      className={`btn btn-small ${danger ? "btn-danger" : "btn-secondary"}`}
      disabled={busy}
      onClick={async () => {
        if (confirmText && !confirm(confirmText)) return;
        setBusy(true);
        const res = await api(url, { method: "PATCH", body });
        setBusy(false);
        if (!res.ok) return toast(res.error, "error");
        toast("Saved.");
        router.refresh();
      }}
    >
      {busy ? "…" : label}
    </button>
  );
}
