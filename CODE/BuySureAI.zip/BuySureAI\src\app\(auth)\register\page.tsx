import type { Metadata } from "next";
import { pageMeta } from "@/lib/seo";
import { AuthShell } from "../AuthShell";
import { RegisterForm } from "../AuthForms";

export const metadata: Metadata = pageMeta({
  title: "Create a free account",
  description: "Create a free BuySure AI account to audit your own shortlist, save cases and set price watches.",
  path: "/register",
});

export default function RegisterPage() {
  return (
    <AuthShell title="Create your account" intro="Free during early access. No card, no marketplace password, no tracking without your consent.">
      <RegisterForm />
    </AuthShell>
  );
}
