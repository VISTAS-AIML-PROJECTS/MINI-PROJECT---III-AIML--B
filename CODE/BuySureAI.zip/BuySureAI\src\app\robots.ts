import type { MetadataRoute } from "next";
import { absoluteUrl } from "@/lib/site";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [{ userAgent: "*", allow: "/", disallow: ["/api/", "/dashboard", "/admin", "/r/", "/search", "/reset-password", "/forgot-password"] }],
    sitemap: absoluteUrl("/sitemap.xml"),
  };
}
