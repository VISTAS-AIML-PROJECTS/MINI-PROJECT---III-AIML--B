import { describe, expect, it } from "vitest";
import { analyseReviews } from "@/lib/engine/reviews";
import { checkPhysics } from "@/lib/engine/physics";
import { computeCost, DEFAULT_CHARGER_COST_INR } from "@/lib/engine/cost";
import { forecastPrice, normCdf } from "@/lib/engine/price";
import { mapNetwork, normaliseEntity, addressKey } from "@/lib/engine/network";
import { rank, CRITERIA } from "@/lib/engine/decision";
import { runAudit } from "@/lib/engine";
import { sampleCase } from "@/lib/sample-data";
import type { ProductInput, ReviewInput } from "@/lib/engine/types";

const sample = sampleCase();
const products = sample.products.map(({ key, ...p }) => ({ ...p, id: key }));
const byKey = (k: string) => products.find((p) => p.id === k)!;

describe("review forensics", () => {
  it("refuses to score fewer than 5 reviews", () => {
    const r = analyseReviews([{ rating: 5, body: "great" }]);
    expect(r.score).toBeNull();
    expect(r.confidence).toBe("insufficient");
  });

  it("scores organically varied reviews highly", () => {
    const r = analyseReviews(byKey("nuvi-air").reviews);
    expect(r.score).toBeGreaterThanOrEqual(85);
  });

  it("detects a review farm: duplicates, bursts, markers, inflated average", () => {
    const r = analyseReviews(byKey("orrin-pro").reviews);
    expect(r.score).toBeLessThan(45);
    const codes = r.findings.map((f) => f.code);
    expect(codes).toContain("REVIEWS_DUPLICATES");
    expect(codes).toContain("REVIEWS_BURSTS");
    expect(codes).toContain("REVIEWS_INFLATED");
    expect(r.adjustedRating!).toBeLessThan(r.averageRating!);
  });

  it("clusters exact copy-paste text", () => {
    const body = "This phone has an excellent battery and the camera quality is very good for the price";
    const reviews: ReviewInput[] = [
      ...Array.from({ length: 10 }, () => ({ rating: 5, body })),
      ...Array.from({ length: 10 }, (_, i) => ({ rating: 3, body: `Review number ${i} talks about something entirely different like delivery day ${i} and box condition ${i * 7}` })),
    ];
    const r = analyseReviews(reviews);
    expect(r.signals.clusters[0].size).toBe(10);
    expect(r.signals.duplicateShare).toBeGreaterThanOrEqual(0.5);
  });

  it("ignores invalid ratings instead of crashing", () => {
    const r = analyseReviews([{ rating: 9, body: "x" }, { rating: 0, body: "y" }, ...Array.from({ length: 5 }, () => ({ rating: 4, body: "fine phone for daily use honestly speaking" }))]);
    expect(r.analysed).toBe(5);
  });
});

describe("physics checks", () => {
  it("fails a 10,000 mAh battery in a 7.6 mm, 170 g phone", () => {
    const p = byKey("kestrel-max");
    const r = checkPhysics("phone", p.specs, p.certified, p.priceInr);
    expect(r.status).toBe("fail");
    expect(r.checks.find((c) => c.code === "PHYSICS_VOLUME")!.status).toBe("fail");
    expect(r.checks.find((c) => c.code === "PHYSICS_MASS")!.status).toBe("fail");
    expect(r.checks.find((c) => c.code === "CLAIM_IP")!.status).toBe("fail");
    expect(r.checks.find((c) => c.code === "PHYSICS_CHARGE_TIME")!.status).toBe("fail");
  });

  it("passes a realistic 6,000 mAh phone", () => {
    const p = byKey("halden-v7");
    expect(checkPhysics("phone", p.specs, p.certified, p.priceInr).status).toBe("pass");
  });

  it("passes a real-world class 7,000 mAh phone (≈166×77×8.9 mm, 210 g)", () => {
    const r = checkPhysics("phone", { batteryMah: 7000, lengthMm: 166, widthMm: 77, thicknessMm: 8.9, weightG: 210 }, {});
    expect(r.checks.find((c) => c.code === "PHYSICS_VOLUME")!.status).toBe("pass");
    expect(r.checks.find((c) => c.code === "PHYSICS_MASS")!.status).not.toBe("fail");
  });

  it("fails a fake 30,000 mAh power bank weighing 180 g", () => {
    const r = checkPhysics("powerbank", { batteryMah: 30000, weightG: 180, lengthMm: 140, widthMm: 68, thicknessMm: 16 }, {});
    expect(r.status).toBe("fail");
  });

  it("flags a 2 TB USB stick at ₹799 and passes a ₹6,000 1 TB SSD", () => {
    expect(checkPhysics("storage", { storageGb: 2048 }, {}, 799).status).toBe("fail");
    expect(checkPhysics("storage", { storageGb: 1000 }, {}, 6000).status).toBe("pass");
  });

  it("reports unchecked when data is missing", () => {
    expect(checkPhysics("phone", {}, {}).status).toBe("unchecked");
  });

  it("accepts an IP rating covered by the certificate and rejects one that is not", () => {
    expect(checkPhysics("phone", { ipRating: "IP54" }, { ipRating: "IP68" }).status).toBe("pass");
    expect(checkPhysics("phone", { ipRating: "IPX7" }, { ipRating: "IPX4" }).status).toBe("fail");
  });
});

describe("true cost", () => {
  it("adds a charger when it is not in the box and separates conditional offers", () => {
    const c = computeCost(18000, { chargerInBox: false }, { offers: [{ label: "Bank", amountInr: 1500, conditional: true }, { label: "Coupon", amountInr: 500, conditional: false }], expectedYears: 3 });
    expect(c.effectivePrice).toBe(18000 + DEFAULT_CHARGER_COST_INR - 500);
    expect(c.bestCasePrice).toBe(c.effectivePrice - 1500);
    expect(c.costPerYear).toBe(Math.round(c.effectivePrice / 3));
  });

  it("does not double-count a charger the user already added", () => {
    const c = computeCost(10000, { chargerInBox: false }, { addOns: [{ label: "65W GaN charger", costInr: 2000 }] });
    expect(c.effectivePrice).toBe(12000);
  });
});

describe("price forecast", () => {
  it("normCdf matches known values", () => {
    expect(normCdf(0)).toBeCloseTo(0.5, 6);
    expect(normCdf(1.96)).toBeCloseTo(0.975, 3);
    expect(normCdf(-1.96)).toBeCloseTo(0.025, 3);
  });

  it("needs enough history", () => {
    const f = forecastPrice([{ priceInr: 100, observedAt: "2026-09-01" }], 90);
    expect(f.probability).toBeNull();
  });

  it("returns 1 when already at target", () => {
    expect(forecastPrice([{ priceInr: 80, observedAt: "2026-09-01" }], 90).probability).toBe(1);
  });

  it("gives a higher probability for a falling, volatile series than for a flat one", () => {
    const mk = (prices: number[]) => prices.map((p, i) => ({ priceInr: p, observedAt: new Date(Date.UTC(2026, 8, 1 + i * 2)).toISOString() }));
    const falling = forecastPrice(mk([20000, 19800, 19900, 19500, 19600, 19200, 19300]), 18500);
    const flat = forecastPrice(mk([20000, 20010, 19990, 20000, 20005, 19995, 20000]), 18500);
    expect(falling.probability!).toBeGreaterThan(flat.probability!);
    expect(falling.probability!).toBeGreaterThan(0);
    expect(falling.probability!).toBeLessThanOrEqual(1);
    expect(falling.slopePerWeek!).toBeLessThan(0);
  });
});

describe("seller network", () => {
  it("normalises company names and addresses", () => {
    expect(normaliseEntity("Shenzhen Lumatek Electronics Co., Ltd.")).toBe(normaliseEntity("SHENZHEN LUMATEK ELECTRONICS CO LTD"));
    expect(addressKey("Plot 7, Sector 63, Noida 201301")).toContain("201301");
    expect(addressKey("no pin here")).toBe("");
  });

  it("links white-labelled products that share a manufacturer", () => {
    const n = mapNetwork(products as ProductInput[]);
    expect(n.groups.some((g) => g.productIds.includes("orrin-pro") && g.productIds.includes("nuvi-air"))).toBe(true);
    expect(n.findings.some((f) => f.code === "NETWORK_WHITE_LABEL")).toBe(true);
  });
});

describe("decision matrix", () => {
  const criteria = CRITERIA.phone;
  const items = [
    { id: "a", name: "A", metrics: { price: 10000, battery: 20, camera: 9 }, disqualified: null },
    { id: "b", name: "B", metrics: { price: 20000, battery: 25, camera: 5 }, disqualified: null },
    { id: "c", name: "C", metrics: { price: 5000, battery: 30, camera: 10 }, disqualified: "fails physics" },
  ];

  it("weights change the winner", () => {
    expect(rank(items, criteria, { price: 10, battery: 0, camera: 0 })[0].id).toBe("a");
    expect(rank(items, criteria, { price: 0, battery: 10, camera: 0 })[0].id).toBe("b");
  });

  it("always ranks disqualified products last", () => {
    const r = rank(items, criteria, { price: 10, battery: 10, camera: 10 });
    expect(r.at(-1)!.id).toBe("c");
  });

  it("puts missing metrics at the midpoint and reports them", () => {
    const r = rank([{ id: "x", name: "X", metrics: { price: 1 }, disqualified: null }, { id: "y", name: "Y", metrics: { price: 2, camera: 5 }, disqualified: null }], criteria, { price: 0, camera: 10 });
    expect(r.find((p) => p.id === "x")!.missing).toContain("Camera");
  });
});

describe("full audit on the sample case", () => {
  const report = runAudit({ category: "phone", products });
  it("excludes the impossible phone and the review-farmed phone", () => {
    const dq = report.products.filter((p) => p.disqualified).map((p) => p.id).sort();
    expect(dq).toEqual(["kestrel-max", "orrin-pro"]);
  });
  it("picks a qualified product and runs fast", () => {
    expect(["nuvi-air", "halden-v7"]).toContain(report.summary.topPick);
    expect(report.durationMs).toBeLessThan(2000);
  });
  it("is deterministic", () => {
    const again = runAudit({ category: "phone", products });
    expect(again.ranking.map((r) => [r.id, r.score])).toEqual(report.ranking.map((r) => [r.id, r.score]));
  });
});
