/**
 * Parses pasted or uploaded review data (CSV with a header row, or a JSON array) into the
 * shape the API accepts. Runs in the browser; the server re-validates everything.
 */

export type ParsedReview = { rating: number; body: string; author?: string | null; postedAt?: string | null; verified?: boolean | null };
export type ParseResult = { reviews: ParsedReview[]; skipped: number; errors: string[] };

/** RFC 4180 CSV: quoted fields, escaped quotes, commas and newlines inside quotes. */
export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let quoted = false;
  const s = text.replace(/^﻿/, "");
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (quoted) {
      if (c === '"') {
        if (s[i + 1] === '"') { field += '"'; i++; }
        else quoted = false;
      } else field += c;
    } else if (c === '"' && field === "") quoted = true;
    else if (c === ",") { row.push(field); field = ""; }
    else if (c === "\n" || c === "\r") {
      if (c === "\r" && s[i + 1] === "\n") i++;
      row.push(field); field = "";
      if (row.some((x) => x.trim() !== "")) rows.push(row);
      row = [];
    } else field += c;
  }
  row.push(field);
  if (row.some((x) => x.trim() !== "")) rows.push(row);
  return rows;
}

const ALIASES: Record<keyof ParsedReview, string[]> = {
  rating: ["rating", "stars", "star", "score"],
  body: ["body", "text", "review", "review_text", "content", "comment"],
  author: ["author", "name", "reviewer", "user"],
  postedAt: ["postedat", "posted_at", "date", "review_date", "created_at", "time"],
  verified: ["verified", "verified_purchase", "is_verified"],
};

function boolish(v: unknown): boolean | null {
  if (typeof v === "boolean") return v;
  const s = String(v ?? "").trim().toLowerCase();
  if (["true", "yes", "y", "1", "verified"].includes(s)) return true;
  if (["false", "no", "n", "0"].includes(s)) return false;
  return null;
}

function normalise(obj: Record<string, unknown>): ParsedReview | string {
  const lower: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(obj)) lower[k.toLowerCase().replace(/[\s-]/g, "_")] = v;
  const pick = (key: keyof ParsedReview) => {
    for (const a of ALIASES[key]) if (lower[a] !== undefined && lower[a] !== "") return lower[a];
    return undefined;
  };
  const ratingRaw = pick("rating");
  const rating = Math.round(Number(String(ratingRaw ?? "").replace(/[^\d.]/g, "")));
  const body = String(pick("body") ?? "").trim();
  if (!(rating >= 1 && rating <= 5)) return `rating "${ratingRaw ?? ""}" is not 1–5`;
  if (!body) return "review text is empty";
  const posted = pick("postedAt");
  const postedAt = posted && !Number.isNaN(Date.parse(String(posted))) ? new Date(String(posted)).toISOString() : null;
  const verifiedRaw = pick("verified");
  return {
    rating,
    body: body.slice(0, 5000),
    author: pick("author") ? String(pick("author")).slice(0, 80) : null,
    postedAt,
    verified: verifiedRaw === undefined ? null : boolish(verifiedRaw),
  };
}

export function parseReviews(text: string): ParseResult {
  const t = text.trim();
  const errors: string[] = [];
  let records: Record<string, unknown>[] = [];
  if (!t) return { reviews: [], skipped: 0, errors: ["Nothing to import."] };

  if (t.startsWith("[") || t.startsWith("{")) {
    try {
      const data = JSON.parse(t);
      const arr = Array.isArray(data) ? data : Array.isArray(data.reviews) ? data.reviews : null;
      if (!arr) return { reviews: [], skipped: 0, errors: ["JSON must be an array of reviews, or an object with a \"reviews\" array."] };
      records = arr.filter((x: unknown) => x && typeof x === "object");
    } catch {
      return { reviews: [], skipped: 0, errors: ["That looks like JSON but could not be parsed."] };
    }
  } else {
    const rows = parseCsv(t);
    if (rows.length < 2) return { reviews: [], skipped: 0, errors: ["CSV needs a header row and at least one review."] };
    const header = rows[0].map((h) => h.trim());
    records = rows.slice(1).map((r) => Object.fromEntries(header.map((h, i) => [h, r[i] ?? ""])));
  }

  const reviews: ParsedReview[] = [];
  let skipped = 0;
  records.forEach((rec, i) => {
    const r = normalise(rec);
    if (typeof r === "string") {
      skipped++;
      if (errors.length < 5) errors.push(`Row ${i + 1}: ${r}`);
    } else reviews.push(r);
  });
  return { reviews, skipped, errors };
}
