/* Applies pending migrations. Uses DATABASE_URL (Postgres) when set, else DATABASE_PATH (SQLite). */
import path from "node:path";
import { openDriver } from "../src/lib/db-core";

async function main() {
  const url = process.env.DATABASE_URL || undefined;
  const d = await openDriver({ url, file: path.resolve(process.env.DATABASE_PATH ?? "data/buysure.db") });
  const rows = await d.all<{ name: string; applied_at: string }>("SELECT name, applied_at FROM schema_migrations ORDER BY name", []);
  console.log(`Database: ${url ? "PostgreSQL (DATABASE_URL)" : "SQLite"}`);
  for (const r of rows) console.log(`  ${r.name} at ${r.applied_at}`);
  await d.close();
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
