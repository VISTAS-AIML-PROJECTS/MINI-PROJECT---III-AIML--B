import type { Metadata } from "next";
import Link from "next/link";
import { Breadcrumbs } from "@/components/Breadcrumbs";
import { pageMeta } from "@/lib/seo";
import { PROFILES, FLASH_FLOOR_INR_PER_GB } from "@/lib/engine/physics";
import { DEFAULT_CHARGER_COST_INR } from "@/lib/engine/cost";
import { inr } from "@/lib/format";

export const metadata: Metadata = pageMeta({
  title: "How it works: the methodology",
  description:
    "Every check BuySure AI runs, with its exact thresholds: review clustering, burst detection, stylometric uniformity, battery energy-density ceilings, certification matching, cost and ranking.",
  path: "/how-it-works",
});

export default function HowItWorks() {
  return (
    <div className="wrap">
      <Breadcrumbs items={[{ name: "How it works", path: "/how-it-works" }]} />
      <header className="page-head">
        <span className="eyebrow">Methodology · engine v1.0</span>
        <h1>How BuySure reaches a verdict</h1>
        <p className="lede">
          Nothing here is a black box. These are the checks the engine runs, the numbers it compares against, and how the results
          combine into a ranking. When we change a threshold, this page changes with it.
        </p>
      </header>

      <div className="prose" style={{ paddingBottom: 80 }}>
        <nav aria-label="On this page" className="notice">
          <strong>On this page:</strong>{" "}
          <a href="#data">Where the data comes from</a> · <a href="#reviews">Review forensics</a> · <a href="#physics">Physics checks</a> ·{" "}
          <a href="#claims">Certification checks</a> · <a href="#cost">True cost</a> · <a href="#network">Seller network</a> ·{" "}
          <a href="#ranking">Ranking</a> · <a href="#prices">Price watches</a> · <a href="#limits">Limits</a>
        </nav>

        <h2 id="data">Where the data comes from</h2>
        <p>
          You supply it. For each product you add the listed price, specs, offers, and the seller, manufacturer and importer printed
          on the listing. You can also attach values from a certification record such as a BIS registration, and paste reviews as CSV
          or JSON. BuySure does not scrape marketplaces or get around their access controls. Many marketplace terms forbid that, and an
          audit built on data you can see and check is easier to trust.
        </p>

        <h2 id="reviews">Review forensics</h2>
        <p>Run when a product has at least 5 reviews (confidence is &quot;low&quot; under 20, &quot;medium&quot; under 80, &quot;high&quot; above). The score starts at 100 and loses points per signal:</p>
        <div className="table-wrap">
          <table>
            <thead><tr><th scope="col">Signal</th><th scope="col">How it is measured</th><th scope="col" className="num">Max −</th></tr></thead>
            <tbody>
              <tr><td>Near-duplicate text</td><td>Reviews of 8+ words whose word-trigram Jaccard similarity is ≥ 0.55 are clustered. Penalty grows from 3% to 28% of reviews in clusters.</td><td className="num">30</td></tr>
              <tr><td>Volume spikes</td><td>Days with more reviews than max(5, median + 4 × MAD) over the review period. Penalty grows as the share of 5★ reviews posted on those days goes from 20% to 60%.</td><td className="num">20</td></tr>
              <tr><td>Content-free praise</td><td>5★ reviews with four or fewer content words. Penalty from 30% to 70% of 5★ reviews.</td><td className="num">10</td></tr>
              <tr><td>Uniform length</td><td>Coefficient of variation of 5★ review length (15+ reviews of 8+ words). Organic text varies; penalty below 0.45.</td><td className="num">10</td></tr>
              <tr><td>Uniform vocabulary</td><td>Variation of type-token ratio in 5★ reviews relative to lower-rated ones. Penalty when below 0.6×.</td><td className="num">10</td></tr>
              <tr><td>Stock phrasing</td><td>5★ reviews using two or more stock marketing phrases (&quot;highly recommend&quot;, &quot;game changer&quot;, &quot;seamless&quot; and similar). Weakest signal.</td><td className="num">10</td></tr>
              <tr><td>Unverified purchases</td><td>When the source marks verification: share of unverified 5★ reviews above 25%.</td><td className="num">10</td></tr>
              <tr><td>Rating/text mismatch</td><td>5★ reviews containing complaint language (&quot;defective&quot;, &quot;refund&quot;, &quot;stopped working&quot;).</td><td className="num">8</td></tr>
              <tr><td>Missing middle</td><td>50+ reviews, over 80% 5★ and under 6% in the 2–4★ range.</td><td className="num">5</td></tr>
            </tbody>
          </table>
        </div>
        <p>
          Flagged reviews are set aside to compute an <em>adjusted rating</em>. Remaining reviews are scanned for aspects (battery,
          heating, display, software and more) to show what real buyers complain about. None of this proves a review is fake: generated
          and incentivised reviews leave statistical traces, and so occasionally do honest ones. That is why every signal is shown with its value.
        </p>

        <h2 id="physics">Physics checks</h2>
        <p>
          Advertised battery capacity (mAh × nominal voltage = Wh) is compared with the device&apos;s volume and mass. The ceilings assume
          the densest lithium-ion cells shipping in consumer products, including silicon-carbon anodes, occupying the largest share of the
          device a battery plausibly can. A failure means no existing cell could fit, not that the claim is merely optimistic. A warning is
          within 15% of the ceiling.
        </p>
        <div className="table-wrap">
          <table>
            <thead><tr><th scope="col">Category</th><th scope="col" className="num">Default V</th><th scope="col" className="num">Cell Wh/L</th><th scope="col" className="num">Cell Wh/kg</th><th scope="col" className="num">Max volume</th><th scope="col" className="num">Max mass</th></tr></thead>
            <tbody>
              {Object.entries(PROFILES).map(([k, p]) => (
                <tr key={k}>
                  <td style={{ textTransform: "capitalize" }}>{k}</td>
                  <td className="num">{p.defaultVoltage}</td>
                  <td className="num">{p.cellWhPerL}</td>
                  <td className="num">{p.cellWhPerKg}</td>
                  <td className="num">{Math.round(p.volumeShare * 100)}%</td>
                  <td className="num">{Math.round(p.massShare * 100)}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p>
          Charging time is checked against the energy a charger can deliver: Wh ÷ (W × 0.92). For power banks we also state the capacity you
          will actually receive at 5 V. For flash storage, a price below ₹{FLASH_FLOOR_INR_PER_GB}/GB is flagged; fake-capacity drives sell there.
        </p>

        <h2 id="claims">Certification checks</h2>
        <p>
          If you attach a certification record, the listing&apos;s claims are compared with it. Capacity below 90% of the claim fails and below 95%
          warns. A higher water or dust digit than certified fails, as does charging power more than 5% above the certified figure.
        </p>

        <h2 id="cost">True cost</h2>
        <p>
          Effective price = listed price + shipping + required add-ons − discounts everyone gets. If the listing says the charger is not in the
          box, a charger at {inr(DEFAULT_CHARGER_COST_INR)} is added unless you enter your own figure. Bank-card and exchange offers are shown
          separately as a best case, because not everyone qualifies.
        </p>

        <h2 id="network">Seller network</h2>
        <p>
          Manufacturer and importer names are normalised (case, punctuation, suffixes such as &quot;Pvt Ltd&quot;). Addresses are fingerprinted
          by PIN code and first words. Listings that share any of these are linked. A shared marketplace seller alone does not count, because large
          sellers stock many brands.
        </p>

        <h2 id="ranking">Ranking</h2>
        <p>
          Each criterion is normalised from 0 to 1 across the products in your comparison, so the cheapest gets 1 on price. The normalised values are
          multiplied by your weights and scaled to 100. Missing values earn 30% of a criterion's points, below average, so a product can't win on data nobody published. Missing values are listed. The integrity
          score starts from review forensics (neutral 70 without enough reviews), is capped at 15 by any physics failure, and loses 25 per contradicted
          claim. Products that fail a physics or certification check, or fall under 35 integrity, rank after all others whatever their weights.
        </p>

        <h2 id="prices">Price watches</h2>
        <p>
          You log prices as you see them. When the latest is at or below your target you get a notification, and an email if email is configured. With
          5+ observations over 3+ days we show a drop probability for the next 14 days: log-prices are modelled as a random walk with drift fitted to your
          observations, using the first-passage formula. Sales and launches cause jumps the model cannot foresee, so treat it as a rough guide.
        </p>

        <h2 id="limits">Limits</h2>
        <ul>
          <li>The audit is only as good as the data entered. Garbage in, garbage verdict.</li>
          <li>Review signals are probabilistic. A small honest seller can trip one, and a careful review farm can avoid all of them.</li>
          <li>Physics checks catch impossible claims, not optimistic ones that are physically possible.</li>
          <li>Optional plain-language summaries are written by Claude, Anthropic&apos;s AI model, from the audit numbers. They never change the numbers.</li>
        </ul>
        <p><Link href="/demo" className="btn">Run the sample audit</Link></p>
      </div>
    </div>
  );
}
