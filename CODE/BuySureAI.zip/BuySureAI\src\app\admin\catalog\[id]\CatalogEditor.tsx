"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/lib/client-api";
import { FieldError, useForm } from "@/components/forms";
import { useToast } from "@/components/Toast";
import { ProductVisual } from "@/components/shop/ProductVisual";
import type { CatalogItem } from "@/lib/catalog/rank";

type Cat = { slug: string; name: string; specKeys: string[] };

export function CatalogEditor({ product, categories }: { product: (CatalogItem & { status: string }) | null; categories: Cat[] }) {
  const router = useRouter();
  const toast = useToast();
  const f = useForm();
  const [category, setCategory] = useState(product?.category ?? categories[0].slug);
  const [imagePath, setImagePath] = useState(product?.imagePath ?? null);
  const [uploading, setUploading] = useState(false);
  const keys = categories.find((c) => c.slug === category)?.specKeys ?? [];
  const specs = product?.specs ?? {};

  const save = f.handle(async (fd) => {
    const outSpecs: Record<string, string | number | boolean | null> = {};
    for (const k of keys) {
      const raw = String(fd.get(`spec_${k}`) ?? "").trim();
      if (raw === "") continue;
      outSpecs[k] = raw === "true" ? true : raw === "false" ? false : /^-?\d+(\.\d+)?$/.test(raw) ? Number(raw) : raw;
    }
    let sources: unknown;
    try { sources = JSON.parse(String(fd.get("sources") || "[]")); } catch { return { ok: false, status: 422, error: "Sources must be valid JSON.", fields: { sources: "Invalid JSON." } }; }
    const body = {
      slug: fd.get("slug"), category, name: fd.get("name"), brand: fd.get("brand"), priceInr: fd.get("priceInr"),
      priceNote: fd.get("priceNote") || null, variant: fd.get("variant") || null, released: fd.get("released") || null,
      specs: outSpecs, sources, status: fd.get("status"),
    };
    const res = product ? await api(`/api/admin/catalog/${product.id}`, { method: "PATCH", body }) : await api<{ id: string }>("/api/admin/catalog", { body });
    if (!res.ok) return res;
    toast("Saved.");
    if (!product) router.push(`/admin/catalog/${(res.data as { id: string }).id}`);
    router.refresh();
  });

  const upload = async (file: File | undefined) => {
    if (!file || !product) return;
    if (file.size > 2 * 1024 * 1024) return toast("Images must be 2 MB or smaller.", "error");
    setUploading(true);
    const form = new FormData();
    form.set("image", file);
    try {
      const res = await fetch(`/api/admin/catalog/${product.id}/image`, { method: "POST", body: form });
      const data = await res.json();
      if (!res.ok) toast(data.error ?? "Upload failed.", "error");
      else { setImagePath(data.imagePath); toast("Photo uploaded."); router.refresh(); }
    } catch {
      toast("Network problem during upload.", "error");
    } finally {
      setUploading(false);
    }
  };

  const remove = async () => {
    if (!product || !confirm(`Delete ${product.name} from the catalogue?`)) return;
    const res = await api(`/api/admin/catalog/${product.id}`, { method: "DELETE" });
    if (!res.ok) return toast(res.error, "error");
    router.push("/admin/catalog");
    router.refresh();
  };

  const field = (name: string, label: string, def: unknown, opts: { type?: string; hint?: string; required?: boolean } = {}) => (
    <div className="field">
      <label htmlFor={`ce-${name}`}>{label}</label>
      <input id={`ce-${name}`} name={name} type={opts.type ?? "text"} defaultValue={def === null || def === undefined ? "" : String(def)} required={opts.required} aria-describedby={`ce-${name}-e`} />
      {opts.hint && <span className="hint">{opts.hint}</span>}
      <FieldError id={`ce-${name}-e`} msg={f.fields[name]} />
    </div>
  );

  return (
    <div className="results-grid">
      <form onSubmit={save} noValidate className="panel">
        {f.error && <div className="notice notice-error" role="alert">{f.error}</div>}
        <fieldset>
          <legend>Product</legend>
          <div className="grid-2">
            {field("name", "Name", product?.name, { required: true })}
            {field("brand", "Brand", product?.brand, { required: true })}
            {field("slug", "URL slug", product?.slug, { required: true, hint: "e.g. poco-m7-pro-5g" })}
            <div className="field">
              <label htmlFor="ce-category">Category</label>
              <select id="ce-category" value={category} onChange={(e) => setCategory(e.target.value)}>
                {categories.map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}
              </select>
            </div>
            {field("priceInr", "Price (₹)", product?.priceInr, { type: "number", required: true })}
            {field("priceNote", "Price note", product?.priceNote, { hint: "e.g. Launch price, Flipkart listing" })}
            {field("variant", "Variant", product?.variant)}
            {field("released", "Released (YYYY-MM)", product?.released)}
          </div>
          <div className="field">
            <label htmlFor="ce-status">Status</label>
            <select id="ce-status" name="status" defaultValue={product?.status ?? "draft"}>
              <option value="draft">Draft (hidden)</option>
              <option value="published">Published</option>
            </select>
          </div>
        </fieldset>
        <fieldset>
          <legend>Specs used for scoring</legend>
          <p className="small muted" style={{ marginTop: 0 }}>Numbers only for numeric fields; true/false for yes-no fields. Leave unknown values blank.</p>
          <div className="grid-3">
            {keys.map((k) => field(`spec_${k}`, k, specs[k]))}
          </div>
        </fieldset>
        <div className="field">
          <label htmlFor="ce-sources">Sources (JSON)</label>
          <textarea id="ce-sources" name="sources" defaultValue={JSON.stringify(product?.sources ?? [{ title: "", url: "https://" }], null, 2)} style={{ fontFamily: "var(--font-mono)", fontSize: "0.85rem" }} aria-describedby="ce-sources-e" />
          <FieldError id="ce-sources-e" msg={f.fields.sources} />
        </div>
        <div className="btn-row">
          <button className="btn" disabled={f.busy}>{f.busy ? "Saving…" : "Save"}</button>
          {product && <button type="button" className="btn btn-danger" onClick={remove}>Delete</button>}
        </div>
      </form>
      <aside className="panel">
        <h2>Photo</h2>
        <div style={{ background: "var(--paper-2)", borderRadius: 10, aspectRatio: "1", display: "grid", placeItems: "center", padding: "14%" }}>
          <ProductVisual category={category} brand={product?.brand ?? "Brand"} name={product?.name ?? "Product"} imagePath={imagePath} />
        </div>
        {product ? (
          <>
            <div className="field" style={{ marginTop: 14 }}>
              <label htmlFor="ce-image">Upload JPEG, PNG or WebP (max 2 MB)</label>
              <input id="ce-image" type="file" accept="image/jpeg,image/png,image/webp" disabled={uploading} onChange={(e) => upload(e.target.files?.[0])} />
              <span className="hint">Only upload photos you own or are licensed to use, such as official press kits that permit it.</span>
            </div>
            {imagePath && <button className="btn btn-secondary btn-small" onClick={async () => { await api(`/api/admin/catalog/${product.id}/image`, { method: "DELETE" }); setImagePath(null); router.refresh(); }}>Remove photo</button>}
          </>
        ) : <p className="small muted" style={{ marginTop: 12 }}>Save the product first, then add a photo.</p>}
      </aside>
    </div>
  );
}
