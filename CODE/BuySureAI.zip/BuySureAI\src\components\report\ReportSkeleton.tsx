/** Placeholder shaped like the report while an audit runs or loads. */
export function ReportSkeleton() {
  return (
    <div aria-hidden="true" style={{ display: "grid", gap: 28 }}>
      <div style={{ display: "grid", gridTemplateColumns: "minmax(0,1.5fr) minmax(0,1fr)", gap: 24 }}>
        <div>
          <div className="skeleton" style={{ height: 30, width: "70%", marginBottom: 20 }} />
          {[0, 1, 2, 3].map((i) => (
            <div key={i} style={{ padding: "14px 0", borderBottom: "1px solid var(--rule)" }}>
              <div className="skeleton skeleton-line" style={{ width: "45%" }} />
              <div className="skeleton skeleton-line" style={{ width: `${80 - i * 12}%`, height: 6 }} />
            </div>
          ))}
        </div>
        <div className="skeleton" style={{ height: 300 }} />
      </div>
      {[0, 1].map((i) => <div key={i} className="skeleton" style={{ height: 76 }} />)}
    </div>
  );
}
