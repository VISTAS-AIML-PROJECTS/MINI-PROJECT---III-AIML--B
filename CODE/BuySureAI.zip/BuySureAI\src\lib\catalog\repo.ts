import "server-only";
import { db, getDriver, newId, now, parseJson } from "../db";
import { SEED_CATEGORIES, SEED_CHECKED_AT, SEED_PRODUCTS } from "./seed";
import type { CatalogItem } from "./rank";

type Row = {
  id: string; slug: string; category_slug: string; name: string; brand: string; price_inr: number; price_note: string | null;
  variant: string | null; released: string | null; specs_json: string; sources_json: string; pros_json: string; cons_json: string;
  image_path: string | null; status: string; checked_at: string;
};

export type CategoryRow = { slug: string; name: string; singular: string; tagline: string; banner: string; sort_order: number };

const SEED_MARKER = "seed:catalog:v1";
const seeded = new WeakSet<object>();
let seeding: Promise<void> | null = null;

/**
 * Inserts the starter catalogue once per database (a marker row records it), so products an admin
 * later edits or deletes are never resurrected. Concurrent callers share one run.
 */
export async function ensureSeeded() {
  const conn = await getDriver();
  if (seeded.has(conn)) return;
  seeding ??= (async () => {
    const done = await db.get("SELECT 1 AS x FROM schema_migrations WHERE name = ?", SEED_MARKER);
    if (!done) {
      await db.transaction(async () => {
        const t = now();
        for (const c of SEED_CATEGORIES) {
          await db.run(
            "INSERT INTO catalog_categories (slug, name, singular, tagline, banner, sort_order, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT DO NOTHING",
            c.slug, c.name, c.singular, c.tagline, c.banner, c.sort, t, t,
          );
        }
        for (const p of SEED_PRODUCTS) {
          await db.run(
            `INSERT INTO catalog_products (id, slug, category_slug, name, brand, price_inr, price_note, variant, released,
               specs_json, sources_json, status, checked_at, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'published', ?, ?, ?) ON CONFLICT DO NOTHING`,
            newId(), p.slug, p.category, p.name, p.brand, p.priceInr, p.priceNote, p.variant || null, p.released ?? null,
            JSON.stringify(p.specs), JSON.stringify(p.sources), SEED_CHECKED_AT, t, t,
          );
        }
        await db.run("INSERT INTO schema_migrations (name, applied_at) VALUES (?, ?) ON CONFLICT DO NOTHING", SEED_MARKER, t);
      });
    }
    seeded.add(conn);
  })().finally(() => { seeding = null; });
  await seeding;
}

const toItem = (r: Row): CatalogItem => ({
  id: r.id, slug: r.slug, category: r.category_slug, name: r.name, brand: r.brand, priceInr: r.price_inr, priceNote: r.price_note,
  variant: r.variant, released: r.released, specs: parseJson(r.specs_json, {}), sources: parseJson(r.sources_json, []),
  pros: parseJson(r.pros_json, []), cons: parseJson(r.cons_json, []), imagePath: r.image_path, checkedAt: r.checked_at,
});

export async function listCategories(): Promise<CategoryRow[]> {
  await ensureSeeded();
  return await db.all<CategoryRow>("SELECT slug, name, singular, tagline, banner, sort_order FROM catalog_categories ORDER BY sort_order, name");
}

export async function categoryItems(slug: string, opts: { maxPrice?: number; includeDrafts?: boolean } = {}): Promise<CatalogItem[]> {
  await ensureSeeded();
  const rows = await db.all<Row>(
    `SELECT * FROM catalog_products WHERE category_slug = ? ${opts.includeDrafts ? "" : "AND status = 'published'"} ${opts.maxPrice ? "AND price_inr <= ?" : ""} ORDER BY price_inr`,
    ...(opts.maxPrice ? [slug, opts.maxPrice] : [slug]),
  );
  return rows.map(toItem);
}

export async function productBySlug(slug: string): Promise<CatalogItem | null> {
  await ensureSeeded();
  const r = await db.get<Row>("SELECT * FROM catalog_products WHERE slug = ? AND status = 'published'", slug);
  return r ? toItem(r) : null;
}

export async function allPublished(): Promise<CatalogItem[]> {
  await ensureSeeded();
  return (await db.all<Row>("SELECT * FROM catalog_products WHERE status = 'published' ORDER BY category_slug, price_inr")).map(toItem);
}

export async function adminListProducts(): Promise<(CatalogItem & { status: string })[]> {
  await ensureSeeded();
  return (await db.all<Row>("SELECT * FROM catalog_products ORDER BY category_slug, price_inr")).map((r) => ({ ...toItem(r), status: r.status }));
}

export async function adminGetProduct(id: string) {
  const r = await db.get<Row>("SELECT * FROM catalog_products WHERE id = ?", id);
  return r ? { ...toItem(r), status: r.status } : null;
}

export type ProductWrite = {
  slug: string; category: string; name: string; brand: string; priceInr: number; priceNote?: string | null; variant?: string | null;
  released?: string | null; specs: Record<string, unknown>; sources: { title: string; url: string }[]; status: "published" | "draft";
};

export async function upsertProduct(id: string | null, d: ProductWrite) {
  const t = now();
  if (id) {
    await db.run(
      `UPDATE catalog_products SET slug = ?, category_slug = ?, name = ?, brand = ?, price_inr = ?, price_note = ?, variant = ?, released = ?,
         specs_json = ?, sources_json = ?, status = ?, checked_at = ?, updated_at = ? WHERE id = ?`,
      d.slug, d.category, d.name, d.brand, d.priceInr, d.priceNote ?? null, d.variant ?? null, d.released ?? null,
      JSON.stringify(d.specs), JSON.stringify(d.sources), d.status, t.slice(0, 10), t, id,
    );
    return id;
  }
  const nid = newId();
  await db.run(
    `INSERT INTO catalog_products (id, slug, category_slug, name, brand, price_inr, price_note, variant, released, specs_json, sources_json, status, checked_at, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    nid, d.slug, d.category, d.name, d.brand, d.priceInr, d.priceNote ?? null, d.variant ?? null, d.released ?? null,
    JSON.stringify(d.specs), JSON.stringify(d.sources), d.status, t.slice(0, 10), t, t,
  );
  return nid;
}

export async function setProductImage(id: string, path: string | null) {
  await db.run("UPDATE catalog_products SET image_path = ?, updated_at = ? WHERE id = ?", path, now(), id);
}

export async function deleteProduct(id: string) {
  await db.run("DELETE FROM catalog_products WHERE id = ?", id);
}

export async function logSearch(query: string, category: string | null, budget: number | null, results: number) {
  await db.run("INSERT INTO search_log (id, query, category, budget_inr, results, created_at) VALUES (?, ?, ?, ?, ?, ?)",
    newId(), query.slice(0, 300), category, budget, results, now());
}

export async function recentSearches(limit = 20) {
  return await db.all<{ query: string; category: string | null; results: number; created_at: string }>(
    "SELECT query, category, results, created_at FROM search_log ORDER BY created_at DESC LIMIT ?", limit);
}
