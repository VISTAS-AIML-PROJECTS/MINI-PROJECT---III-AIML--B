import type { CostInputs, Finding, Specs } from "./types";

/** Default price of a decent charger when the box ships without one (INR). Users can override it per product. */
export const DEFAULT_CHARGER_COST_INR = 1499;

export type CostReport = {
  listPrice: number;
  /** Price everyone pays: list + shipping + required add-ons − unconditional discounts. */
  effectivePrice: number;
  /** Price if every conditional offer (bank card, exchange) also applies to you. */
  bestCasePrice: number;
  lines: { label: string; amount: number; kind: "base" | "add" | "discount" | "conditional" }[];
  costPerYear: number | null;
  findings: Finding[];
};

const inr = (n: number) => `₹${n.toLocaleString("en-IN")}`;

export function computeCost(priceInr: number, specs: Specs, cost: CostInputs): CostReport {
  const lines: CostReport["lines"] = [{ label: "Listed price", amount: priceInr, kind: "base" }];
  const findings: Finding[] = [];
  let effective = priceInr;

  if (cost.shippingInr) {
    lines.push({ label: "Shipping", amount: cost.shippingInr, kind: "add" });
    effective += cost.shippingInr;
  }

  const addOns = [...(cost.addOns ?? [])];
  if (specs.chargerInBox === false && !addOns.some((a) => /charger|adapter|brick/i.test(a.label))) {
    addOns.push({ label: "Charger (not in box)", costInr: DEFAULT_CHARGER_COST_INR });
  }
  for (const a of addOns) {
    lines.push({ label: a.label, amount: a.costInr, kind: "add" });
    effective += a.costInr;
  }
  if (addOns.length) {
    const extra = addOns.reduce((s, a) => s + a.costInr, 0);
    findings.push({
      module: "cost", severity: "info", code: "COST_ADDONS",
      message: `Needs ${inr(extra)} of extras to be usable out of the box (${addOns.map((a) => a.label).join(", ")}).`,
    });
  }

  let bestCase = effective;
  for (const o of cost.offers ?? []) {
    if (o.conditional) {
      lines.push({ label: o.label, amount: -o.amountInr, kind: "conditional" });
      bestCase -= o.amountInr;
    } else {
      lines.push({ label: o.label, amount: -o.amountInr, kind: "discount" });
      effective -= o.amountInr;
      bestCase -= o.amountInr;
    }
  }
  effective = Math.max(0, Math.round(effective));
  bestCase = Math.max(0, Math.round(bestCase));
  if (bestCase < effective) {
    findings.push({
      module: "cost", severity: "info", code: "COST_CONDITIONAL",
      message: `${inr(effective - bestCase)} more off is available only with specific cards or an exchange.`,
    });
  }

  const years = cost.expectedYears && cost.expectedYears > 0 ? cost.expectedYears : null;
  return {
    listPrice: priceInr,
    effectivePrice: effective,
    bestCasePrice: bestCase,
    lines,
    costPerYear: years ? Math.round(effective / years) : null,
    findings,
  };
}
