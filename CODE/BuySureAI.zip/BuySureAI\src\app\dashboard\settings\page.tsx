import type { Metadata } from "next";
import { requireUser } from "@/lib/auth/guard";
import { SettingsClient } from "./SettingsClient";

export const metadata: Metadata = { title: "Settings" };

export default async function SettingsPage() {
  const user = await requireUser("/dashboard/settings");
  return (
    <>
      <h1 style={{ fontSize: "var(--step-3)" }}>Settings</h1>
      <SettingsClient name={user.name} email={user.email} />
    </>
  );
}
