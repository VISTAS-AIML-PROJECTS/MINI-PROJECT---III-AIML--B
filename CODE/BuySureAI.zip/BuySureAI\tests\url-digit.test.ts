import { describe, expect, it } from "vitest";
import { parseQuery, matchProduct } from "@/lib/catalog/query";

describe("single-digit model numbers", () => {
  it("matches 'OnePlus Nord 6' from an Amazon link and does not confuse it with Nord 5", () => {
    const words = parseQuery("https://www.amazon.in/OnePlus-Nord-6-Storage-Fresh/dp/B0FXYZ1234").url!.words;
    expect(words).toContain("6");
    const products = [{ name: "OnePlus Nord 5", brand: "OnePlus" }, { name: "OnePlus Nord 6", brand: "OnePlus" }];
    expect(matchProduct(words, products)?.item.name).toBe("OnePlus Nord 6");
  });
});
