import "server-only";
import { randomBytes } from "node:crypto";
import { db, now } from "./db";

/**
 * Uploaded product photos are stored in the database (BLOB/BYTEA), so the app runs on hosts
 * without a persistent disk, such as Vercel.
 */
export const MEDIA_NAME = /^[a-f0-9]{24}\.(jpg|png|webp)$/;
export const MAX_UPLOAD = 2 * 1024 * 1024;
const MIME = { jpg: "image/jpeg", png: "image/png", webp: "image/webp" } as const;

/** Detects the real image type from magic bytes; the declared MIME type is ignored. */
export function sniff(buf: Buffer): "jpg" | "png" | "webp" | null {
  if (buf.length > 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return "jpg";
  if (buf.length > 8 && buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return "png";
  if (buf.length > 12 && buf.subarray(0, 4).toString("ascii") === "RIFF" && buf.subarray(8, 12).toString("ascii") === "WEBP") return "webp";
  return null;
}

export async function saveImage(buf: Buffer): Promise<string> {
  const ext = sniff(buf);
  if (!ext) throw new Error("not-an-image");
  const name = `${randomBytes(12).toString("hex")}.${ext}`;
  await db.run("INSERT INTO media (name, mime, data, created_at) VALUES (?, ?, ?, ?)", name, MIME[ext], buf, now());
  return name;
}

export async function readImage(name: string): Promise<{ mime: string; data: Buffer } | null> {
  if (!MEDIA_NAME.test(name)) return null;
  const row = await db.get<{ mime: string; data: Uint8Array }>("SELECT mime, data FROM media WHERE name = ?", name);
  return row ? { mime: row.mime, data: Buffer.from(row.data) } : null;
}

export async function removeImage(name: string | null) {
  if (!name || !MEDIA_NAME.test(name)) return;
  await db.run("DELETE FROM media WHERE name = ?", name);
}
