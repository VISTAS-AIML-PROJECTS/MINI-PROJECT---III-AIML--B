import { handler, json, readJson, limit, clientIp, ApiError } from "@/lib/api";
import { resetSchema } from "@/lib/validation";
import { hashToken, destroyAllSessions } from "@/lib/auth/session";
import { hashPassword } from "@/lib/auth/password";
import { updatePasswordHash } from "@/lib/repos/users";
import { db, now } from "@/lib/db";

export const POST = handler({}, async (req) => {
  await limit(`reset-ip:${clientIp(req)}`, 10, 3600);
  const { token, password } = await readJson(req, resetSchema, 2_000);
  const row = await db.get<{ user_id: string; expires_at: string; used_at: string | null }>(
    "SELECT user_id, expires_at, used_at FROM password_resets WHERE token_hash = ?",
    hashToken(token),
  );
  if (!row || row.used_at || row.expires_at < now()) {
    throw new ApiError(400, "This reset link is invalid or has expired. Request a new one.");
  }
  await updatePasswordHash(row.user_id, await hashPassword(password));
  await db.run("UPDATE password_resets SET used_at = ? WHERE token_hash = ?", now(), hashToken(token));
  await destroyAllSessions(row.user_id); // sign out everywhere after a reset
  return json({ ok: true });
});
