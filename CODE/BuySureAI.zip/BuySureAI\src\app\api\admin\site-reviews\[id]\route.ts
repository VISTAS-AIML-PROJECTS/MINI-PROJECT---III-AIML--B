import { handler, json, readJson, ApiError } from "@/lib/api";
import { moderationSchema } from "@/lib/validation";
import { adminLog, moderateSiteReview } from "@/lib/repos/misc";

export const PATCH = handler<{ id: string }>({ auth: "admin" }, async (req, { params, user }) => {
  const { status } = await readJson(req, moderationSchema, 1_000);
  if (!await moderateSiteReview(params.id, status, user!.id)) throw new ApiError(404, "Review not found.");
  await adminLog(user!.id, "review.moderate", params.id, { status });
  return json({ ok: true });
});
