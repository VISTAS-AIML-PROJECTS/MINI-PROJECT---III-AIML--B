import "server-only";
import { createHash, randomBytes } from "node:crypto";
import { cookies } from "next/headers";
import { db, now } from "../db";
import { env } from "../env";

export const SESSION_COOKIE = env.isProd ? "__Host-bs_session" : "bs_session";
const SESSION_DAYS = 30;

export type SessionUser = { id: string; email: string; name: string; role: "user" | "admin" };

const hashToken = (token: string) => createHash("sha256").update(token).digest("hex");

export async function createSession(userId: string, userAgent: string | null) {
  const token = randomBytes(32).toString("base64url");
  const expires = new Date(Date.now() + SESSION_DAYS * 86400_000);
  await db.run(
    "INSERT INTO sessions (id, user_id, created_at, expires_at, user_agent) VALUES (?, ?, ?, ?, ?)",
    hashToken(token), userId, now(), expires.toISOString(), userAgent?.slice(0, 300) ?? null,
  );
  const jar = await cookies();
  jar.set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: env.isProd,
    sameSite: "lax",
    path: "/",
    expires,
  });
}

export async function userForToken(token: string | undefined): Promise<SessionUser | null> {
  if (!token || token.length > 100) return null;
  const row = await db.get<SessionUser & { expires_at: string; disabled_at: string | null }>(
    `SELECT u.id, u.email, u.name, u.role, u.disabled_at, s.expires_at
       FROM sessions s JOIN users u ON u.id = s.user_id
      WHERE s.id = ?`,
    hashToken(token),
  );
  if (!row || row.disabled_at || row.expires_at < now()) return null;
  return { id: row.id, email: row.email, name: row.name, role: row.role };
}

export async function getSessionUser(): Promise<SessionUser | null> {
  const jar = await cookies();
  return userForToken(jar.get(SESSION_COOKIE)?.value);
}

export async function destroySession() {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (token) await db.run("DELETE FROM sessions WHERE id = ?", hashToken(token));
  jar.delete(SESSION_COOKIE);
}

export async function destroyAllSessions(userId: string) {
  await db.run("DELETE FROM sessions WHERE user_id = ?", userId);
}

export async function purgeExpiredSessions() {
  await db.run("DELETE FROM sessions WHERE expires_at < ?", now());
}

export { hashToken };
