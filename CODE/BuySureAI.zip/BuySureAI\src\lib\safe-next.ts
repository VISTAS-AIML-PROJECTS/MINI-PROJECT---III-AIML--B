/** Only same-site relative paths are allowed as post-login destinations (no open redirects). */
export function safeNext(next: string | null, fallback = "/dashboard") {
  return next && next.startsWith("/") && !next.startsWith("//") && !next.startsWith("/\\") ? next : fallback;
}
