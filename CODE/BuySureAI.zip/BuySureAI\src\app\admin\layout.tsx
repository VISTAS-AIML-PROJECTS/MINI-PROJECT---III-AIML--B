import type { Metadata } from "next";
import { AppNav } from "@/components/AppNav";
import { requireAdmin } from "@/lib/auth/guard";

export const metadata: Metadata = { title: "Admin", robots: { index: false, follow: false } };

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  await requireAdmin();
  return (
    <div className="wrap app-shell">
      <AppNav
        label="Administration"
        groups={[
          { title: "Admin", items: [
            { href: "/admin", label: "Overview", exact: true },
            { href: "/admin/catalog", label: "Catalogue" },
            { href: "/admin/users", label: "Users" },
            { href: "/admin/messages", label: "Messages" },
            { href: "/admin/reviews", label: "Review moderation" },
          ] },
          { title: "Back", items: [{ href: "/dashboard", label: "My cases", exact: true }] },
        ]}
      />
      <div>{children}</div>
    </div>
  );
}
