import { handler, json, readJson, limit } from "@/lib/api";
import { observationSchema } from "@/lib/validation";
import { addObservation, evaluateWatch, getOwnedWatch } from "@/lib/repos/watches";

export const POST = handler<{ id: string }>({ auth: "user" }, async (req, { params, user }) => {
  await limit(`observation:${user!.id}`, 300, 3600);
  const w = await getOwnedWatch(params.id, user!.id);
  const data = await readJson(req, observationSchema, 2_000);
  await addObservation(w, data);
  const fired = await evaluateWatch(w.id);
  return json({ ok: true, fired }, 201);
});
