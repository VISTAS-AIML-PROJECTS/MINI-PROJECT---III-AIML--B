const STOPWORDS = new Set(
  "a an the and or but if then so of to in on at for with from by is it its it's this that these those was were be been am are i me my we our you your he she they them their his her as not no very just too also have has had do does did can could would should will really".split(" "),
);

export function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .normalize("NFKC")
    .replace(/[^\p{L}\p{N}\s']/gu, " ")
    .split(/\s+/)
    .filter(Boolean);
}

export function contentWords(tokens: string[]) {
  return tokens.filter((t) => !STOPWORDS.has(t) && t.length > 1);
}

export function shingles(tokens: string[], k = 3): Set<string> {
  const out = new Set<string>();
  if (tokens.length < k) {
    if (tokens.length) out.add(tokens.join(" "));
    return out;
  }
  for (let i = 0; i <= tokens.length - k; i++) out.add(tokens.slice(i, i + k).join(" "));
  return out;
}

export function jaccard(a: Set<string>, b: Set<string>): number {
  if (!a.size || !b.size) return 0;
  const [small, big] = a.size < b.size ? [a, b] : [b, a];
  let inter = 0;
  for (const x of small) if (big.has(x)) inter++;
  return inter / (a.size + b.size - inter);
}

/** Shannon entropy (bits) of the word distribution within one text. */
export function wordEntropy(tokens: string[]): number {
  if (!tokens.length) return 0;
  const counts = new Map<string, number>();
  for (const t of tokens) counts.set(t, (counts.get(t) ?? 0) + 1);
  let h = 0;
  for (const c of counts.values()) {
    const p = c / tokens.length;
    h -= p * Math.log2(p);
  }
  return h;
}

export function mean(xs: number[]) {
  return xs.length ? xs.reduce((s, x) => s + x, 0) / xs.length : 0;
}

export function stdev(xs: number[]) {
  if (xs.length < 2) return 0;
  const m = mean(xs);
  return Math.sqrt(xs.reduce((s, x) => s + (x - m) ** 2, 0) / (xs.length - 1));
}

export function median(xs: number[]) {
  if (!xs.length) return 0;
  const s = [...xs].sort((a, b) => a - b);
  const mid = s.length >> 1;
  return s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
}

export const clamp = (x: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, x));
export const round = (x: number, dp = 1) => Math.round(x * 10 ** dp) / 10 ** dp;

/** Simple union-find used to cluster near-duplicate reviews and linked sellers. */
export class UnionFind {
  parent: number[];
  constructor(n: number) {
    this.parent = Array.from({ length: n }, (_, i) => i);
  }
  find(x: number): number {
    while (this.parent[x] !== x) {
      this.parent[x] = this.parent[this.parent[x]];
      x = this.parent[x];
    }
    return x;
  }
  union(a: number, b: number) {
    const ra = this.find(a), rb = this.find(b);
    if (ra !== rb) this.parent[ra] = rb;
  }
  groups(): number[][] {
    const m = new Map<number, number[]>();
    this.parent.forEach((_, i) => {
      const r = this.find(i);
      if (!m.has(r)) m.set(r, []);
      m.get(r)!.push(i);
    });
    return [...m.values()];
  }
}
