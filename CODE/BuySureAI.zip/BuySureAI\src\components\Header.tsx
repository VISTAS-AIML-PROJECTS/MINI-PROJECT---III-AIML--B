"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { LogoMark } from "./Logo";
import { track } from "@/lib/analytics";

const LINKS = [
  { href: "/best/phones", label: "Phones" },
  { href: "/best/earbuds", label: "Earbuds" },
  { href: "/best/laptops", label: "Laptops" },
  { href: "/best/power-banks", label: "Power banks" },
  { href: "/how-it-works", label: "How we rank" },
  { href: "/demo", label: "Audit tool" },
];

export function Header() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [me, setMe] = useState<{ role: string } | null>(null);
  useEffect(() => setOpen(false), [pathname]);
  // Session state is fetched client-side so marketing pages stay statically rendered.
  useEffect(() => {
    let alive = true;
    fetch("/api/me", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => alive && setMe(d?.user ?? null))
      .catch(() => {});
    return () => { alive = false; };
  }, [pathname]);
  const signedIn = Boolean(me);
  const isAdmin = me?.role === "admin";

  return (
    <header className="site-header">
      <div className="wrap bar">
        <Link href="/" className="brand" aria-label="BuySure AI home">
          <LogoMark />
          <span>Buy<em>Sure</em> AI</span>
        </Link>
        <button className="menu-toggle" aria-expanded={open} aria-controls="primary-nav" onClick={() => setOpen((o) => !o)}>
          {open ? "Close" : "Menu"}
        </button>
        <nav id="primary-nav" className="nav" aria-label="Primary" data-open={open}>
          {LINKS.map((l) => (
            <Link key={l.href} href={l.href} aria-current={pathname === l.href || pathname.startsWith(`${l.href}/`) ? "page" : undefined}>
              {l.label}
            </Link>
          ))}
          {isAdmin && <Link href="/admin" aria-current={pathname.startsWith("/admin") ? "page" : undefined}>Admin</Link>}
          {signedIn ? (
            <Link href="/dashboard" className="btn btn-small">Your cases</Link>
          ) : (
            <>
              <Link href="/login" aria-current={pathname === "/login" ? "page" : undefined}>Sign in</Link>
              <Link href="/register" className="btn btn-small" onClick={() => track("cta_click", { location: "header", cta: "register" })}>
                Sign up
              </Link>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
