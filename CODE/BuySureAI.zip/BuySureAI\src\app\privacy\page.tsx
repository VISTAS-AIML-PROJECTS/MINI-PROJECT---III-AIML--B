import type { Metadata } from "next";
import Link from "next/link";
import { Breadcrumbs } from "@/components/Breadcrumbs";
import { pageMeta } from "@/lib/seo";
import { site } from "@/lib/site";

export const metadata: Metadata = pageMeta({
  title: "Privacy policy",
  description: "What personal data BuySure AI collects, why, how long it is kept, who processes it, the cookies we use, and how to export or delete your data.",
  path: "/privacy",
});

const UPDATED = "6 October 2026";

export default function PrivacyPage() {
  return (
    <div className="wrap">
      <Breadcrumbs items={[{ name: "Privacy policy", path: "/privacy" }]} />
      <header className="page-head">
        <span className="eyebrow">Legal · last updated {UPDATED}</span>
        <h1>Privacy policy</h1>
      </header>
      <div className="prose" style={{ paddingBottom: 80 }}>
        <div className="notice notice-warn" role="note">
          <strong>Template notice:</strong> this policy describes what this software actually does. It is not legal advice. Before launch, the operator must
          add its legal entity name and address, appoint a grievance officer if required, and have a qualified lawyer review it against the Digital Personal
          Data Protection Act, 2023 (India) and any other law that applies to its users.
        </div>

        <h2>Who we are</h2>
        <p>
          &quot;BuySure AI&quot;, &quot;we&quot; and &quot;us&quot; mean the operator of this website. [Operator legal name and registered address to be inserted.]
          Contact us through the <Link href="/contact?topic=privacy">contact form</Link>{site.contactEmail ? <> or at <a href={`mailto:${site.contactEmail}`}>{site.contactEmail}</a></> : null}.
        </p>

        <h2>What we collect and why</h2>
        <div className="table-wrap">
          <table>
            <thead><tr><th scope="col">Data</th><th scope="col">Purpose</th><th scope="col">Basis</th></tr></thead>
            <tbody>
              <tr><td>Name, email, password hash</td><td>Create and secure your account, send password resets and price alerts</td><td>Contract / consent</td></tr>
              <tr><td>Cases, products, reviews you import, price watches</td><td>Run the audits you request and keep your history</td><td>Contract</td></tr>
              <tr><td>Session cookie, browser user-agent</td><td>Keep you signed in; let you recognise your sessions</td><td>Necessary for the service</td></tr>
              <tr><td>Contact-form messages</td><td>Reply to you</td><td>Consent</td></tr>
              <tr><td>Reviews of BuySure you submit</td><td>Publish them (after approval) under your chosen display name</td><td>Consent</td></tr>
              <tr><td>Analytics events (only if you allow analytics cookies)</td><td>Count visits and see which features help people</td><td>Consent</td></tr>
              <tr><td>Server logs (time, path, error details)</td><td>Keep the service running and secure</td><td>Legitimate use</td></tr>
            </tbody>
          </table>
        </div>
        <p>
          We do not collect payment details, and we never ask for marketplace passwords. Reviews you import are third-party text you chose to paste. Please
          do not import content you are not allowed to use.
        </p>

        <h2>Who processes data for us</h2>
        <ul>
          <li><strong>Hosting provider</strong>: stores the database and runs the application. [Provider and region to be inserted.]</li>
          <li><strong>Email provider (Resend)</strong>: delivers password-reset and price-alert emails, if enabled by the operator.</li>
          <li><strong>Google Analytics</strong>: only after you click &quot;Allow analytics&quot;. Google signals and ad personalisation are switched off.</li>
          <li><strong>Anthropic (Claude API)</strong>: only when you press &quot;Explain in plain language&quot; on an audit, if the operator has enabled it. It receives product
            names, scores and findings from that audit, not your name or email. Under Anthropic&apos;s commercial terms, API inputs are not used to train models by default.</li>
        </ul>
        <p>We do not sell personal data or share it for advertising.</p>

        <h2>How long we keep it</h2>
        <ul>
          <li>Account data, cases and watches: until you delete them or your account.</li>
          <li>Audit history: the 20 most recent runs per case.</li>
          <li>Sessions: 30 days, or until you sign out.</li>
          <li>Password-reset links: 60 minutes.</li>
          <li>Contact messages: up to 24 months, then deleted. [Operator to confirm.]</li>
        </ul>

        <h2>Your rights</h2>
        <p>
          From <Link href="/dashboard/settings">Settings</Link> you can download everything we hold about your account as JSON, correct your name, and delete
          your account. Deletion removes your cases, products, imported reviews, watches and notifications immediately. For anything else, such as a correction
          we cannot do automatically or a grievance, use the contact form with the topic &quot;Privacy&quot;.
        </p>

        <h2 id="cookies">Cookies</h2>
        <div className="table-wrap">
          <table>
            <thead><tr><th scope="col">Cookie</th><th scope="col">Type</th><th scope="col">Purpose</th><th scope="col">Lifetime</th></tr></thead>
            <tbody>
              <tr><td className="mono">__Host-bs_session</td><td>Essential</td><td>Keeps you signed in (HttpOnly, Secure, SameSite=Lax)</td><td>30 days</td></tr>
              <tr><td className="mono">bs_consent</td><td>Essential</td><td>Remembers your analytics choice</td><td>180 days</td></tr>
              <tr><td className="mono">_ga, _ga_*</td><td>Analytics (opt-in)</td><td>Google Analytics visitor measurement</td><td>Up to 2 years</td></tr>
            </tbody>
          </table>
        </div>
        <p>You can change your choice at any time with &quot;Cookie settings&quot; in the footer. Choosing &quot;Essential only&quot; removes existing analytics cookies.</p>

        <h2>Security</h2>
        <p>
          Passwords are hashed with scrypt. Session tokens are stored only as hashes. Traffic is encrypted with HTTPS. Requests are rate-limited and
          administrator actions are logged. No system is perfectly secure; if we learn of a breach affecting you, we will tell you and the authorities as the law requires.
        </p>

        <h2>Children</h2>
        <p>BuySure AI is not intended for people under 18, and we do not knowingly collect their data.</p>

        <h2>Changes</h2>
        <p>We will update the date at the top when this policy changes, and notify account holders by email of material changes.</p>
      </div>
    </div>
  );
}
