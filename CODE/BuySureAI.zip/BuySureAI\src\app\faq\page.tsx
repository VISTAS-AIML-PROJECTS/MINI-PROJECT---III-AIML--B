import type { Metadata } from "next";
import Link from "next/link";
import { Breadcrumbs } from "@/components/Breadcrumbs";
import { JsonLd, pageMeta } from "@/lib/seo";

export const metadata: Metadata = pageMeta({
  title: "Frequently asked questions",
  description:
    "What BuySure AI checks, where its data comes from, why it does not scrape or auto-buy, how much it costs, and what happens to your data.",
  path: "/faq",
});

const FAQS: { q: string; a: string }[] = [
  {
    q: "What does BuySure AI actually do?",
    a: "It audits a shortlist of products you are deciding between. For each one it tests the reviews for signs of manufacturing, checks advertised specs against physics and any certification record you attach, and works out what you will really pay. It then ranks the products using weights you set.",
  },
  {
    q: "Does it scrape Amazon or Flipkart automatically?",
    a: "No. You paste in what you see on the listing: price, specs, offers, seller details and reviews. Automated scraping that gets around a marketplace's protections breaks most marketplace terms. An audit built on data you can see is also easier to verify.",
  },
  {
    q: "Can it tell me a review is fake?",
    a: "It cannot prove that, and it never claims to. It reports statistical signals: near-identical text, volume spikes, content-free praise, uniform writing style and stock marketing phrasing. Each comes with its value and threshold. A product with many signals deserves scepticism; the decision stays yours.",
  },
  {
    q: "How can a battery claim be 'physically impossible'?",
    a: "Battery energy is capacity × voltage. The best lithium cells in consumer products store roughly 900 Wh per litre, and a battery can only fill part of a phone. If the advertised battery would need more space or weight than the body has, the claim cannot be true. The methodology page lists every number used.",
  },
  {
    q: "Will BuySure buy things for me when the price drops?",
    a: "No. Price watches notify you when a price you logged reaches your target. BuySure never asks for card details and never places orders.",
  },
  {
    q: "How much does it cost?",
    a: "The consumer product is free while in early access. We do not take affiliate commissions or paid placements, because that would compromise the ranking. If paid plans arrive, existing cases stay accessible and we will announce pricing before charging anything.",
  },
  {
    q: "What happens to the reviews and data I import?",
    a: "They are stored in your account so you can re-run audits, and are visible only to you unless you turn on a share link for a case. You can export everything as JSON or delete your account, which deletes your data, from Settings.",
  },
  {
    q: "Is any AI model involved?",
    a: "The forensic checks are deterministic code, so the same input gives the same output. If the server operator has enabled it, you can also ask for a plain-language summary written by Claude, Anthropic's AI model. It receives the audit numbers, not your account details, and cannot change the scores.",
  },
  {
    q: "Which product categories are supported?",
    a: "Phones, power banks, laptops, earbuds and flash storage have physics profiles. Anything else can use the 'other' category, which runs review forensics, cost and ranking with generic limits.",
  },
  {
    q: "I sell products and think a verdict about my listing is wrong. What can I do?",
    a: "Audits are private to the user who created them unless shared. If a shared report contains incorrect data about your product, contact us with the link and the correct certification details and we will look into it.",
  },
];

export default function FaqPage() {
  return (
    <div className="wrap">
      <Breadcrumbs items={[{ name: "FAQ", path: "/faq" }]} />
      <header className="page-head">
        <span className="eyebrow">Questions</span>
        <h1>Frequently asked questions</h1>
        <p className="lede">Short answers. The <Link href="/how-it-works">methodology page</Link> has the long ones.</p>
      </header>
      <div className="narrow" style={{ paddingBottom: 80 }}>
        {FAQS.map((f, i) => (
          <details key={i} className="dossier" style={{ marginBottom: 10 }} open={i === 0}>
            <summary style={{ display: "block", padding: "16px 20px" }}>
              <h2 style={{ fontSize: "var(--step-1)", margin: 0 }}>{f.q}</h2>
            </summary>
            <div style={{ padding: "0 20px 16px" }}><p style={{ margin: 0 }}>{f.a}</p></div>
          </details>
        ))}
        <p style={{ marginTop: 28 }}>Still unsure? <Link href="/contact">Ask us directly</Link>.</p>
      </div>
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@type": "FAQPage",
          mainEntity: FAQS.map((f) => ({ "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } })),
        }}
      />
    </div>
  );
}
