import type { Metadata } from "next";
import { pageMeta } from "@/lib/seo";
import { AuthShell } from "../AuthShell";
import { LoginForm } from "../AuthForms";

export const metadata: Metadata = pageMeta({ title: "Sign in", description: "Sign in to BuySure AI to see your cases, audits and price watches.", path: "/login" });

export default function LoginPage() {
  return (
    <AuthShell title="Sign in" intro="Your cases, audits and price watches are waiting.">
      <LoginForm />
    </AuthShell>
  );
}
