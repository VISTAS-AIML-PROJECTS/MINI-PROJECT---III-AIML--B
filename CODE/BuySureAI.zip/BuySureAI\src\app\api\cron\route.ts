import { NextResponse, type NextRequest } from "next/server";
import { timingSafeEqual } from "node:crypto";
import { env } from "@/lib/env";
import { evaluateAllWatches } from "@/lib/repos/watches";
import { purgeExpiredSessions } from "@/lib/auth/session";
import { purgeRateLimits } from "@/lib/rate-limit";
import { db, now } from "@/lib/db";
import { log } from "@/lib/logger";

export const dynamic = "force-dynamic";

/**
 * Maintenance job. Call every 15–60 minutes from any scheduler (system cron, GitHub Actions,
 * a platform cron) with `Authorization: Bearer $CRON_SECRET`.
 */
export async function POST(req: NextRequest) {
  const expected = env.CRON_SECRET;
  const given = req.headers.get("authorization")?.replace(/^Bearer\s+/i, "") ?? "";
  if (!expected || given.length !== expected.length || !timingSafeEqual(Buffer.from(given), Buffer.from(expected))) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  try {
    const watches = await evaluateAllWatches();
    await purgeExpiredSessions();
    await purgeRateLimits();
    await db.run("DELETE FROM password_resets WHERE expires_at < ?", now());
    log.info("cron completed", watches);
    return NextResponse.json({ ok: true, watches });
  } catch (err) {
    log.error("cron failed", err);
    return NextResponse.json({ error: "Cron run failed" }, { status: 500 });
  }
}

/** Vercel Cron calls GET with `Authorization: Bearer $CRON_SECRET`. */
export const GET = POST;
