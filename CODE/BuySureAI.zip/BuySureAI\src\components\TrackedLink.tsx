"use client";

import Link from "next/link";
import type { ComponentProps } from "react";
import { track } from "@/lib/analytics";

/** A Link that records a consent-gated `cta_click` event. */
export function TrackedLink({ cta, location, ...props }: ComponentProps<typeof Link> & { cta: string; location: string }) {
  return <Link {...props} onClick={(e) => { track("cta_click", { cta, location }); props.onClick?.(e); }} />;
}
