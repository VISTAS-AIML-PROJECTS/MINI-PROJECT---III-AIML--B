import { describe, expect, it } from "vitest";
import { parseCsv, parseReviews } from "@/lib/review-import";
import { hashPassword, verifyPassword } from "@/lib/auth/password";
import { registerSchema, productSchema, contactSchema, observationSchema } from "@/lib/validation";
import { safeNext } from "@/lib/safe-next";

describe("CSV parsing", () => {
  it("handles quotes, escaped quotes, commas and newlines inside fields", () => {
    const rows = parseCsv('a,b\n"hello, world","she said ""hi""\nnext line"\r\n1,2');
    expect(rows).toEqual([["a", "b"], ["hello, world", 'she said "hi"\nnext line'], ["1", "2"]]);
  });
  it("strips a BOM and skips blank lines", () => {
    expect(parseCsv("﻿x\n\n1\n")).toEqual([["x"], ["1"]]);
  });
});

describe("review import", () => {
  it("maps column aliases and booleans from CSV", () => {
    const r = parseReviews("Stars,Review Text,Date,Verified Purchase\n5,Great battery,2026-08-01,Yes\n2,Bad screen,2026-08-02,no");
    expect(r.reviews).toHaveLength(2);
    expect(r.reviews[0]).toMatchObject({ rating: 5, body: "Great battery", verified: true });
    expect(r.reviews[1].verified).toBe(false);
    expect(r.reviews[0].postedAt).toMatch(/^2026-08-01/);
  });
  it("accepts JSON arrays and objects with a reviews key", () => {
    expect(parseReviews('[{"rating":4,"text":"ok"}]').reviews).toHaveLength(1);
    expect(parseReviews('{"reviews":[{"rating":"5.0 out of 5","body":"ok"}]}').reviews[0].rating).toBe(5);
  });
  it("skips invalid rows with reasons", () => {
    const r = parseReviews("rating,body\n7,too high\n3,\n4,fine");
    expect(r.reviews).toHaveLength(1);
    expect(r.skipped).toBe(2);
    expect(r.errors.length).toBe(2);
  });
  it("rejects malformed JSON gracefully", () => {
    expect(parseReviews("[{oops").errors[0]).toMatch(/could not be parsed/);
  });
});

describe("password hashing", () => {
  it("verifies the right password and rejects the wrong one", async () => {
    const h = await hashPassword("correct horse 42");
    expect(h.startsWith("scrypt$")).toBe(true);
    expect(await verifyPassword("correct horse 42", h)).toBe(true);
    expect(await verifyPassword("correct horse 43", h)).toBe(false);
    expect(await verifyPassword("x", "garbage")).toBe(false);
  });
  it("salts every hash", async () => {
    expect(await hashPassword("same-password-1")).not.toBe(await hashPassword("same-password-1"));
  });
});

describe("validation", () => {
  it("requires a strong-enough password and accepted terms", () => {
    expect(registerSchema.safeParse({ name: "A", email: "a@b.co", password: "short", acceptTerms: true }).success).toBe(false);
    expect(registerSchema.safeParse({ name: "A", email: "a@b.co", password: "longenough1", acceptTerms: false }).success).toBe(false);
    expect(registerSchema.safeParse({ name: "A", email: "A@B.CO", password: "longenough1", acceptTerms: true }).data?.email).toBe("a@b.co");
  });
  it("rejects javascript: URLs and malformed IP ratings", () => {
    expect(productSchema.safeParse({ name: "X", priceInr: 1, url: "javascript:alert(1)" }).success).toBe(false);
    expect(productSchema.safeParse({ name: "X", priceInr: 1, specs: { ipRating: "waterproof" } }).success).toBe(false);
    expect(productSchema.safeParse({ name: "X", priceInr: 1, specs: { ipRating: "ip68" } }).data?.specs.ipRating).toBe("IP68");
  });
  it("requires a meaningful contact message", () => {
    expect(contactSchema.safeParse({ name: "A", email: "a@b.co", topic: "general", message: "hi" }).success).toBe(false);
  });
  it("rejects future price observations", () => {
    expect(observationSchema.safeParse({ priceInr: 100, observedAt: "2099-01-01" }).success).toBe(false);
  });
});

describe("open-redirect protection", () => {
  it("only allows same-site relative paths", () => {
    expect(safeNext("/dashboard/watches")).toBe("/dashboard/watches");
    expect(safeNext("//evil.com")).toBe("/dashboard");
    expect(safeNext("https://evil.com")).toBe("/dashboard");
    expect(safeNext("/\\evil.com")).toBe("/dashboard");
    expect(safeNext(null)).toBe("/dashboard");
  });
});
