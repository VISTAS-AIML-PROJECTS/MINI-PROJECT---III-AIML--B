import { handler, json } from "@/lib/api";
import { listUsers } from "@/lib/repos/misc";

export const GET = handler({ auth: "admin" }, async (req) => {
  const sp = req.nextUrl.searchParams;
  const q = sp.get("q")?.trim().slice(0, 100) || null;
  const page = Math.max(1, Number(sp.get("page")) || 1);
  return json({ ...listUsers(q, page), page, pageSize: 25 });
});
