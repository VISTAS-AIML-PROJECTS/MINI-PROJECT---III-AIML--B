import "server-only";
import { db, newId, now } from "../db";

const count = async (sql: string, ...args: (string | number)[]) => (await db.get<{ n: number }>(sql, ...args))!.n;

// Notifications -------------------------------------------------------------------------------

export function listNotifications(userId: string, limit = 30) {
  return db.all<{ id: string; title: string; body: string; link: string | null; read_at: string | null; created_at: string }>(
    "SELECT id, title, body, link, read_at, created_at FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT ?",
    userId, limit,
  );
}

export function unreadCount(userId: string) {
  return count("SELECT COUNT(*) AS n FROM notifications WHERE user_id = ? AND read_at IS NULL", userId);
}

export async function markAllRead(userId: string) {
  await db.run("UPDATE notifications SET read_at = ? WHERE user_id = ? AND read_at IS NULL", now(), userId);
}

// Contact messages ----------------------------------------------------------------------------

export async function createContactMessage(d: { name: string; email: string; topic: string; message: string }) {
  const id = newId();
  await db.run(
    "INSERT INTO contact_messages (id, name, email, topic, message, status, created_at) VALUES (?, ?, ?, ?, ?, 'new', ?)",
    id, d.name, d.email, d.topic, d.message, now(),
  );
  return id;
}

export async function listContactMessages(status: string | null, page: number, pageSize = 25) {
  const where = status ? "WHERE status = ?" : "";
  const args = status ? [status] : [];
  const total = await count(`SELECT COUNT(*) AS n FROM contact_messages ${where}`, ...args);
  const items = await db.all<{ id: string; name: string; email: string; topic: string; message: string; status: string; created_at: string }>(
    `SELECT * FROM contact_messages ${where} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
    ...args, pageSize, (page - 1) * pageSize,
  );
  return { total, items };
}

export async function setContactStatus(id: string, status: string) {
  return (await db.run("UPDATE contact_messages SET status = ? WHERE id = ?", status, id)).changes > 0;
}

// Reviews of BuySure itself -------------------------------------------------------------------

export type SiteReview = { id: string; rating: number; body: string; display_name: string; status: string; created_at: string };

export function approvedSiteReviews(limit = 50) {
  return db.all<SiteReview>(
    "SELECT id, rating, body, display_name, status, created_at FROM site_reviews WHERE status = 'approved' ORDER BY created_at DESC LIMIT ?",
    limit,
  );
}

export async function siteReviewStats() {
  return (await db.get<{ n: number; avg: number | null }>("SELECT COUNT(*) AS n, AVG(rating) AS avg FROM site_reviews WHERE status = 'approved'"))!;
}

export async function mySiteReview(userId: string) {
  return (await db.get<SiteReview>("SELECT id, rating, body, display_name, status, created_at FROM site_reviews WHERE user_id = ?", userId)) ?? null;
}

/** One review per user; editing it sends it back to moderation. */
export async function upsertSiteReview(userId: string, d: { rating: number; body: string; displayName: string }) {
  const t = now();
  await db.run(
    `INSERT INTO site_reviews (id, user_id, rating, body, display_name, status, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, 'pending', ?, ?)
     ON CONFLICT(user_id) DO UPDATE SET rating = excluded.rating, body = excluded.body, display_name = excluded.display_name,
       status = 'pending', moderated_by = NULL, moderated_at = NULL, updated_at = excluded.updated_at`,
    newId(), userId, d.rating, d.body, d.displayName, t, t,
  );
}

export async function listSiteReviewsForModeration(status: string | null, page: number, pageSize = 25) {
  const where = status ? "WHERE s.status = ?" : "";
  const args = status ? [status] : [];
  const total = await count(`SELECT COUNT(*) AS n FROM site_reviews s ${where}`, ...args);
  const items = await db.all<SiteReview & { email: string }>(
    `SELECT s.id, s.rating, s.body, s.display_name, s.status, s.created_at, u.email
       FROM site_reviews s JOIN users u ON u.id = s.user_id ${where} ORDER BY s.created_at DESC LIMIT ? OFFSET ?`,
    ...args, pageSize, (page - 1) * pageSize,
  );
  return { total, items };
}

export async function moderateSiteReview(id: string, status: string, adminId: string) {
  return (await db.run("UPDATE site_reviews SET status = ?, moderated_by = ?, moderated_at = ?, updated_at = ? WHERE id = ?",
    status, adminId, now(), now(), id)).changes > 0;
}

// Admin ---------------------------------------------------------------------------------------

export async function adminLog(actorId: string, action: string, target: string | null, meta?: unknown) {
  await db.run("INSERT INTO admin_log (id, actor_id, action, target, meta_json, created_at) VALUES (?, ?, ?, ?, ?, ?)",
    newId(), actorId, action, target, meta ? JSON.stringify(meta) : null, now());
}

export function recentAdminLog(limit = 20) {
  return db.all<{ id: string; action: string; target: string | null; created_at: string; actor_email: string | null }>(
    `SELECT l.id, l.action, l.target, l.created_at, u.email AS actor_email
       FROM admin_log l LEFT JOIN users u ON u.id = l.actor_id ORDER BY l.created_at DESC LIMIT ?`,
    limit,
  );
}

export async function adminStats() {
  const weekAgo = new Date(Date.now() - 7 * 86400_000).toISOString();
  const [users, newUsersWeek, cases, audits, auditsWeek, watches, newMessages, pendingReviews, searches] = await Promise.all([
    count("SELECT COUNT(*) AS n FROM users"),
    count("SELECT COUNT(*) AS n FROM users WHERE created_at >= ?", weekAgo),
    count("SELECT COUNT(*) AS n FROM cases"),
    count("SELECT COUNT(*) AS n FROM audit_runs"),
    count("SELECT COUNT(*) AS n FROM audit_runs WHERE created_at >= ?", weekAgo),
    count("SELECT COUNT(*) AS n FROM price_watches WHERE active = 1"),
    count("SELECT COUNT(*) AS n FROM contact_messages WHERE status = 'new'"),
    count("SELECT COUNT(*) AS n FROM site_reviews WHERE status = 'pending'"),
    count("SELECT COUNT(*) AS n FROM search_log WHERE created_at >= ?", weekAgo),
  ]);
  return { users, newUsersWeek, cases, audits, auditsWeek, watches, newMessages, pendingReviews, searches };
}

export async function listUsers(q: string | null, page: number, pageSize = 25) {
  const where = q ? "WHERE LOWER(email) LIKE ? ESCAPE '\\' OR LOWER(name) LIKE ? ESCAPE '\\'" : "";
  const like = q ? `%${q.toLowerCase().replace(/[\\%_]/g, (c) => `\\${c}`)}%` : null;
  const args = like ? [like, like] : [];
  const total = await count(`SELECT COUNT(*) AS n FROM users ${where}`, ...args);
  const items = await db.all<{ id: string; email: string; name: string; role: string; disabled_at: string | null; created_at: string; cases: number }>(
    `SELECT u.id, u.email, u.name, u.role, u.disabled_at, u.created_at,
            (SELECT COUNT(*) FROM cases c WHERE c.user_id = u.id) AS cases
       FROM users u ${where} ORDER BY u.created_at DESC LIMIT ? OFFSET ?`,
    ...args, pageSize, (page - 1) * pageSize,
  );
  return { total, items };
}

export function countAdmins() {
  return count("SELECT COUNT(*) AS n FROM users WHERE role = 'admin' AND disabled_at IS NULL");
}

export async function setUserRoleAndStatus(id: string, d: { role?: "user" | "admin"; disabled?: boolean }) {
  const u = await db.get<{ role: string; disabled_at: string | null }>("SELECT role, disabled_at FROM users WHERE id = ?", id);
  if (!u) return false;
  await db.run(
    "UPDATE users SET role = ?, disabled_at = ?, updated_at = ? WHERE id = ?",
    d.role ?? u.role,
    d.disabled === undefined ? u.disabled_at : d.disabled ? now() : null,
    now(),
    id,
  );
  if (d.disabled) await db.run("DELETE FROM sessions WHERE user_id = ?", id);
  return true;
}
