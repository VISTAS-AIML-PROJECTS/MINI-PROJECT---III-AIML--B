import "server-only";
import { db } from "./db";

/**
 * Fixed-window rate limiter persisted in the database, so limits survive restarts and are shared
 * by every server instance. Returns the seconds to wait when limited.
 */
export async function rateLimit(key: string, limit: number, windowSeconds: number): Promise<{ ok: true } | { ok: false; retryAfter: number }> {
  const nowMs = Date.now();
  // One atomic upsert: start a new window if the old one expired, otherwise count this hit.
  await db.run(
    `INSERT INTO rate_limits (key, count, reset_at) VALUES (?, 1, ?)
     ON CONFLICT(key) DO UPDATE SET
       count = CASE WHEN rate_limits.reset_at <= ? THEN 1 ELSE rate_limits.count + 1 END,
       reset_at = CASE WHEN rate_limits.reset_at <= ? THEN excluded.reset_at ELSE rate_limits.reset_at END`,
    key, nowMs + windowSeconds * 1000, nowMs, nowMs,
  );
  const row = await db.get<{ count: number; reset_at: number }>("SELECT count, reset_at FROM rate_limits WHERE key = ?", key);
  if (row && row.count > limit) return { ok: false, retryAfter: Math.max(1, Math.ceil((Number(row.reset_at) - nowMs) / 1000)) };
  return { ok: true };
}

export async function clearRateLimit(key: string) {
  await db.run("DELETE FROM rate_limits WHERE key = ?", key);
}

export async function purgeRateLimits() {
  await db.run("DELETE FROM rate_limits WHERE reset_at < ?", Date.now());
}
