import "server-only";
import { env } from "./env";
import { log } from "./logger";

/**
 * Transactional email through Resend's HTTP API (https://resend.com/docs/api-reference/emails/send-email).
 * Without RESEND_API_KEY, emails are not sent: in development the message is logged so flows such
 * as password reset can still be tested; in production a warning is logged.
 */
export async function sendEmail(msg: { to: string; subject: string; text: string; replyTo?: string }): Promise<"sent" | "skipped"> {
  if (!env.RESEND_API_KEY) {
    if (env.isProd) log.warn("Email not sent: RESEND_API_KEY is not configured", { subject: msg.subject });
    else log.info("[dev email]", { to: msg.to, subject: msg.subject, text: msg.text });
    return "skipped";
  }
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${env.RESEND_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({ from: env.EMAIL_FROM, to: [msg.to], subject: msg.subject, text: msg.text, reply_to: msg.replyTo }),
    signal: AbortSignal.timeout(10_000),
  });
  if (!res.ok) throw new Error(`Email provider responded ${res.status}`);
  return "sent";
}
