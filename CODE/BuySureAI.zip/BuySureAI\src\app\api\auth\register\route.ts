import { handler, json, readJson, limit, clientIp, ApiError } from "@/lib/api";
import { registerSchema } from "@/lib/validation";
import { hashPassword } from "@/lib/auth/password";
import { createSession } from "@/lib/auth/session";
import { createUser, findUserByEmail } from "@/lib/repos/users";
import { log } from "@/lib/logger";

export const POST = handler({}, async (req) => {
  await limit(`register:${clientIp(req)}`, 5, 3600);
  const data = await readJson(req, registerSchema, 10_000);
  if (data.website) return json({ ok: true }, 201); // honeypot filled: pretend success, store nothing

  if (await findUserByEmail(data.email)) {
    throw new ApiError(409, "An account with this email already exists. Try signing in.", { email: "Already registered." });
  }
  const id = await createUser({ email: data.email, name: data.name, passwordHash: await hashPassword(data.password) });
  await createSession(id, req.headers.get("user-agent"));
  log.info("user registered", { userId: id });
  return json({ ok: true }, 201);
});
