import { randomBytes } from "node:crypto";
import { handler, json, readJson, limit, clientIp } from "@/lib/api";
import { forgotSchema } from "@/lib/validation";
import { findUserByEmail } from "@/lib/repos/users";
import { hashToken } from "@/lib/auth/session";
import { db, now } from "@/lib/db";
import { env } from "@/lib/env";
import { sendEmail } from "@/lib/email";
import { log } from "@/lib/logger";

// Always answers the same way, so the endpoint cannot be used to discover registered emails.
export const POST = handler({}, async (req) => {
  await limit(`forgot-ip:${clientIp(req)}`, 5, 3600);
  const { email } = await readJson(req, forgotSchema, 2_000);
  await limit(`forgot-email:${email}`, 3, 3600);

  const user = await findUserByEmail(email);
  if (user && !user.disabled_at) {
    const token = randomBytes(32).toString("base64url");
    await db.run("DELETE FROM password_resets WHERE user_id = ?", user.id);
    await db.run(
      "INSERT INTO password_resets (token_hash, user_id, expires_at, created_at) VALUES (?, ?, ?, ?)",
      hashToken(token), user.id, new Date(Date.now() + 60 * 60_000).toISOString(), now(),
    );
    const link = `${env.APP_URL}/reset-password?token=${token}`;
    try {
      await sendEmail({
        to: user.email,
        subject: "Reset your BuySure AI password",
        text: `Hi ${user.name},\n\nUse this link within 60 minutes to choose a new password:\n${link}\n\nIf you did not ask for this, ignore this email; your password stays the same.\n`,
      });
    } catch (err) {
      log.error("Password reset email failed", err);
    }
  }
  return json({ ok: true, message: "If that email has an account, a reset link is on its way. It expires in 60 minutes." });
});
