import type { Metadata } from "next";
import Link from "next/link";
import { requireUser } from "@/lib/auth/guard";
import { listCases } from "@/lib/repos/cases";
import { listNotifications } from "@/lib/repos/misc";
import { dateTime } from "@/lib/format";
import { NewCase, Notifications } from "./DashboardClient";

export const metadata: Metadata = { title: "Your cases" };

const CATEGORY_LABEL: Record<string, string> = { phone: "Phone", powerbank: "Power bank", laptop: "Laptop", earbuds: "Earbuds", storage: "Storage", other: "Other" };

export default async function Dashboard() {
  const user = await requireUser("/dashboard");
  const cases = await listCases(user.id);
  const notifications = await listNotifications(user.id, 8);

  return (
    <>
      <div className="panel-head">
        <h1 style={{ fontSize: "var(--step-3)", margin: 0 }}>Your cases</h1>
        <span className="muted small">Signed in as {user.name}</span>
      </div>
      <p className="muted">A case is one buying decision. Add the products you are choosing between, then run the audit.</p>

      <NewCase />

      <section aria-labelledby="cases-title" style={{ marginBottom: 32 }}>
        <h2 id="cases-title" className="sr-only">Cases</h2>
        {cases.length ? (
          <ul className="list-plain" style={{ borderTop: "1px solid var(--ink)" }}>
            {cases.map((c) => (
              <li key={c.id} className="case-row">
                <div>
                  <Link href={`/dashboard/cases/${c.id}`}>{c.title}</Link>
                  <div className="small muted">
                    {CATEGORY_LABEL[c.category]} · {c.productCount} product{c.productCount === 1 ? "" : "s"}
                    {c.budgetInr ? ` · budget ₹${c.budgetInr.toLocaleString("en-IN")}` : ""} · {c.lastAuditAt ? `audited ${dateTime(c.lastAuditAt)}` : "not audited yet"}
                  </div>
                </div>
                <Link href={`/dashboard/cases/${c.id}`} className="btn btn-secondary btn-small" aria-label={`Open ${c.title}`}>Open</Link>
              </li>
            ))}
          </ul>
        ) : (
          <div className="empty">
            <h3>No cases yet</h3>
            <p className="muted">Start one above, or copy the sample case to see a finished audit you can edit.</p>
          </div>
        )}
      </section>

      <Notifications initial={notifications} />
    </>
  );
}
