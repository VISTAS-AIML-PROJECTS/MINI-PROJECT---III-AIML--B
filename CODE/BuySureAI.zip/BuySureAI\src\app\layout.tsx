import type { Metadata, Viewport } from "next";
import { Newsreader, IBM_Plex_Sans, IBM_Plex_Mono } from "next/font/google";
import "./globals.css";
import "./shop.css";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ConsentAndAnalytics } from "@/components/Consent";
import { ToastProvider } from "@/components/Toast";
import { JsonLd } from "@/lib/seo";
import { absoluteUrl, site } from "@/lib/site";

const serif = Newsreader({ subsets: ["latin"], variable: "--f-serif", display: "swap", style: ["normal", "italic"], weight: ["400", "500"] });
const sans = IBM_Plex_Sans({ subsets: ["latin"], variable: "--f-sans", display: "swap", weight: ["400", "500", "600"] });
const mono = IBM_Plex_Mono({ subsets: ["latin"], variable: "--f-mono", display: "swap", weight: ["400", "500", "600"] });

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: { default: `${site.name}: ${site.tagline}`, template: `%s · ${site.name}` },
  description: site.description,
  applicationName: site.name,
  alternates: { canonical: absoluteUrl("/") },
  openGraph: { type: "website", siteName: site.name, locale: site.locale, url: absoluteUrl("/"), title: site.name, description: site.description },
  twitter: { card: "summary_large_image", title: site.name, description: site.description },
  formatDetection: { telephone: false },
};

export const viewport: Viewport = { themeColor: "#ffffff", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en-IN" className={`${serif.variable} ${sans.variable} ${mono.variable}`}>
      <body>
        <a className="skip-link" href="#main">Skip to content</a>
        <ToastProvider>
          <Header />
          <main id="main">{children}</main>
          <Footer />
        </ToastProvider>
        <ConsentAndAnalytics gaId={site.gaId} />
        <JsonLd
          data={{
            "@context": "https://schema.org",
            "@type": "Organization",
            name: site.name,
            url: site.url,
            logo: absoluteUrl("/icon.svg"),
            description: site.description,
            ...(site.contactEmail ? { email: site.contactEmail } : {}),
          }}
        />
      </body>
    </html>
  );
}
