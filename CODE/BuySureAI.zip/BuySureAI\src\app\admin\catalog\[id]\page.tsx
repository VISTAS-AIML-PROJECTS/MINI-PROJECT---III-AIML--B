import Link from "next/link";
import { notFound } from "next/navigation";
import { requireAdmin } from "@/lib/auth/guard";
import { adminGetProduct } from "@/lib/catalog/repo";
import { CATEGORIES } from "@/lib/catalog/categories";
import { CatalogEditor } from "./CatalogEditor";

export default async function EditCatalogProduct({ params }: { params: Promise<{ id: string }> }) {
  await requireAdmin();
  const { id } = await params;
  const product = id === "new" ? null : await adminGetProduct(id);
  if (id !== "new" && !product) notFound();
  return (
    <>
      <nav className="breadcrumbs" aria-label="Breadcrumb" style={{ marginTop: 0 }}>
        <ol><li><Link href="/admin/catalog">Catalogue</Link></li><li><span aria-current="page">{product?.name ?? "New product"}</span></li></ol>
      </nav>
      <h1 style={{ fontSize: "var(--step-3)" }}>{product ? `Edit ${product.name}` : "Add a product"}</h1>
      <CatalogEditor
        product={product}
        categories={CATEGORIES.map((c) => ({ slug: c.slug, name: c.name, specKeys: specKeysFor(c.slug) }))}
      />
    </>
  );
}

function specKeysFor(slug: string): string[] {
  switch (slug) {
    case "phones": return ["chip", "gb6Multi", "display", "sizeIn", "refreshHz", "peakNits", "batteryMah", "chargingW", "mainCamera", "mainMp", "ois", "telephoto", "ultrawide", "ip", "weightG", "lengthMm", "widthMm", "thicknessMm"];
    case "earbuds": return ["anc", "ancDb", "budHours", "totalHours", "codecs", "hiResCodec", "ip"];
    case "power-banks": return ["capacityMah", "outputW", "weightG", "lengthMm", "widthMm", "thicknessMm", "extras"];
    case "laptops": return ["cpu", "gb6Multi", "memory", "display", "batteryWh", "weightKg"];
    default: return [];
  }
}
