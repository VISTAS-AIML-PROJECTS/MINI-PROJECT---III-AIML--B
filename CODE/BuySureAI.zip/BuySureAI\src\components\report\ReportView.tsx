"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import "./report.css";
import { rank } from "@/lib/engine/decision";
import type { AuditReport, ProductAudit, Severity } from "@/lib/engine";
import { inr, pct, dateTime } from "@/lib/format";
import { NetworkGraph } from "./NetworkGraph";
import { track } from "@/lib/analytics";

const STAMP: Record<Severity | "pass" | "unchecked", string> = { fail: "Fail", warn: "Warn", info: "Note", pass: "Pass", unchecked: "Not checked" };

export function Stamp({ kind }: { kind: Severity | "pass" | "unchecked" }) {
  return <span className={`stamp stamp-${kind}`}>{STAMP[kind]}</span>;
}

type Props = {
  report: AuditReport;
  /** Called (debounced) when weights change, e.g. to persist them on a saved case. */
  onWeightsChange?: (w: Record<string, number>) => void;
  context: "demo" | "case" | "shared";
};

export function ReportView({ report, onWeightsChange, context }: Props) {
  const [weights, setWeights] = useState(report.weights);
  useEffect(() => setWeights(report.weights), [report]);
  const ranking = useMemo(
    () => rank(report.products.map((p) => ({ id: p.id, name: p.name, metrics: p.metrics, disqualified: p.disqualified })), report.criteria, weights),
    [report, weights],
  );
  const byId = useMemo(() => new Map(report.products.map((p) => [p.id, p])), [report]);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  const setWeight = (key: string, v: number) => {
    const next = { ...weights, [key]: v };
    setWeights(next);
    clearTimeout(timer.current);
    timer.current = setTimeout(() => {
      onWeightsChange?.(next);
      track("weights_adjusted", { context });
    }, 600);
  };

  const top = ranking.find((r) => !r.disqualified);

  return (
    <div className="report">
      <section className="report-summary" aria-labelledby="verdict-title">
        <div>
          <span className="eyebrow">Verdict · {report.products.length} products · {report.summary.fails} failed checks · {report.summary.warns} warnings</span>
          <h2 id="verdict-title" style={{ fontSize: "var(--step-2)" }}>
            {top ? <>Best match for your weights: <em>{top.name}</em></> : "Every product failed at least one hard check."}
          </h2>
          <ol className="ranking list-plain" aria-label="Ranking">
            {ranking.map((r) => {
              const p = byId.get(r.id)!;
              return (
                <li key={r.id} className="rank-row" data-excluded={Boolean(r.disqualified)}>
                  <span className="no" aria-label={`Rank ${r.rank}`}>{r.rank}</span>
                  <div>
                    <div className="name">{r.name}</div>
                    <div className="meta">
                      <span>{inr(p.cost.effectivePrice)} effective</span>
                      <span>integrity {p.integrity.score}/100</span>
                      {r.disqualified && <span style={{ color: "var(--red)" }}>Excluded: {r.disqualified}</span>}
                      {r.missing.length > 0 && <span>no data: {r.missing.join(", ").toLowerCase()}</span>}
                    </div>
                    <div className="bar" aria-hidden="true"><span style={{ width: `${r.score}%` }} /></div>
                  </div>
                  <div className="score">{r.score.toFixed(1)}<small>/ 100</small></div>
                </li>
              );
            })}
          </ol>
          <p className="small muted" style={{ marginTop: 12 }}>
            Scores are min–max normalised across the products in this comparison, then weighted. Products that fail a physics or
            certification check, or score below 35 on integrity, always rank after the rest. Generated {dateTime(report.generatedAt)} in {report.durationMs} ms, engine v{report.engineVersion}.
          </p>
        </div>
        <form className="weights" onSubmit={(e) => e.preventDefault()} aria-labelledby="weights-title">
          <h3 id="weights-title">What matters to you</h3>
          <p className="small muted">0 ignores a criterion; 10 makes it dominant. The ranking updates as you move a slider.</p>
          {report.criteria.map((c) => {
            const id = `w-${c.key}`;
            return (
              <div key={c.key} className="weight-row">
                <label htmlFor={id}>{c.label}</label>
                <input id={id} type="range" min={0} max={10} step={1} value={weights[c.key] ?? 0}
                  onChange={(e) => setWeight(c.key, Number(e.target.value))} aria-valuetext={`${weights[c.key] ?? 0} of 10`} />
                <output htmlFor={id}>{weights[c.key] ?? 0}</output>
              </div>
            );
          })}
        </form>
      </section>

      <section aria-labelledby="dossiers-title">
        <h2 id="dossiers-title" style={{ fontSize: "var(--step-2)" }}>Evidence by product</h2>
        <div style={{ display: "grid", gap: 16 }}>
          {ranking.map((r, i) => <Dossier key={r.id} p={byId.get(r.id)!} defaultOpen={i === 0} />)}
        </div>
      </section>

      <section aria-labelledby="network-title">
        <h2 id="network-title" style={{ fontSize: "var(--step-2)" }}>Seller and manufacturer links</h2>
        <p className="muted" style={{ maxWidth: "70ch" }}>
          Listings that share a manufacturer, importer or registered address are connected. When products sold under different
          brands share a source, compare their prices directly: you may be paying for a logo.
        </p>
        <NetworkGraph network={report.network} />
        {report.network.findings.length > 0 ? (
          <ul className="findings" style={{ marginTop: 12 }}>
            {report.network.findings.map((f, i) => (<li key={i}><Stamp kind={f.severity} /><span>{f.message}</span></li>))}
          </ul>
        ) : (
          <p className="small muted">No shared manufacturers, importers or addresses between these listings.</p>
        )}
      </section>
    </div>
  );
}

function Dossier({ p, defaultOpen }: { p: ProductAudit; defaultOpen: boolean }) {
  const order: Record<Severity, number> = { fail: 0, warn: 1, info: 2 };
  const findings = [...p.findings].sort((a, b) => order[a.severity] - order[b.severity]);
  const r = p.reviews;
  return (
    <details className="dossier" open={defaultOpen}>
      <summary>
        <div>
          <h3>{p.name}</h3>
          <div className="sub">
            {p.brand ? `${p.brand} · ` : ""}{inr(p.cost.listPrice)} listed · {r.analysed} reviews analysed
            {p.disqualified ? <> · <span style={{ color: "var(--red)" }}>excluded</span></> : null}
          </div>
        </div>
        <div className="integrity" aria-label={`Integrity score ${p.integrity.score} out of 100`}>
          <strong style={{ color: p.integrity.score < 35 ? "var(--red)" : p.integrity.score < 60 ? "var(--amber)" : "var(--ink)" }}>{p.integrity.score}</strong>
          <span className="muted">/100 integrity</span>
        </div>
      </summary>
      <div className="dossier-body">
        <div>
          <h4>Findings</h4>
          {findings.length ? (
            <ul className="findings">
              {findings.map((f, i) => (<li key={i}><Stamp kind={f.severity} /><span>{f.message}</span></li>))}
            </ul>
          ) : (
            <p className="muted">No problems found in the data provided.</p>
          )}
          <ul className="basis">{p.integrity.basis.map((b, i) => <li key={i}>{b}</li>)}</ul>
        </div>

        <div className="dossier-cols">
          <div>
            <h4>Spec and claim checks</h4>
            <div className="table-wrap">
              <table>
                <thead><tr><th scope="col">Check</th><th scope="col">Result</th></tr></thead>
                <tbody>
                  {p.physics.checks.map((c) => (
                    <tr key={c.code}>
                      <td><strong style={{ fontWeight: 500 }}>{c.label}</strong><div className="small muted">{c.detail}</div></td>
                      <td><Stamp kind={c.code.startsWith("INFO_") ? "info" : c.status} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          <div>
            <h4>True cost</h4>
            <div className="table-wrap">
              <table className="ledger">
                <tbody>
                  {p.cost.lines.map((l, i) => (
                    <tr key={i} className={l.kind === "conditional" ? "conditional" : undefined}>
                      <td>{l.label}{l.kind === "conditional" ? " (if eligible)" : ""}</td>
                      <td className="num">{l.amount < 0 ? `−${inr(-l.amount)}` : inr(l.amount)}</td>
                    </tr>
                  ))}
                  <tr className="total"><td>You pay</td><td className="num">{inr(p.cost.effectivePrice)}</td></tr>
                  {p.cost.bestCasePrice < p.cost.effectivePrice && (
                    <tr><td>With every conditional offer</td><td className="num">{inr(p.cost.bestCasePrice)}</td></tr>
                  )}
                  {p.cost.costPerYear !== null && (
                    <tr><td>Per year of expected use</td><td className="num">{inr(p.cost.costPerYear)}</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="dossier-cols">
          <div>
            <h4>Review forensics</h4>
            {r.score === null ? (
              <p className="muted">Not enough reviews to analyse ({r.analysed}). Import at least 5; 80+ gives high confidence.</p>
            ) : (
              <>
                <RatingHistogram dist={r.distribution} />
                <p className="small" style={{ marginTop: 8 }}>
                  Listed average <strong>{r.averageRating}★</strong>; after setting aside flagged reviews <strong>{r.adjustedRating ?? "—"}★</strong>.
                  Review integrity {r.score}/100, {r.confidence} confidence.
                </p>
                <div className="table-wrap">
                  <table className="signal-table">
                    <tbody>
                      <tr><td>Near-duplicate text</td><td>{pct(r.signals.duplicateShare)}</td></tr>
                      <tr><td>5★ on spike days</td><td>{pct(r.signals.fiveStarBurstShare)}</td></tr>
                      <tr><td>Content-free 5★</td><td>{pct(r.signals.shortPraiseShare)}</td></tr>
                      <tr><td>Stock marketing phrasing</td><td>{pct(r.signals.markerShare)}</td></tr>
                      <tr><td>5★ length variation (CV)</td><td>{r.signals.lengthCv ?? "—"}</td></tr>
                      <tr><td>Unverified 5★</td><td>{pct(r.signals.unverifiedShare)}</td></tr>
                      <tr><td>5★ with complaint words</td><td>{pct(r.signals.mismatchShare)}</td></tr>
                    </tbody>
                  </table>
                </div>
                {r.penalties.length > 0 && (
                  <p className="small muted" style={{ marginTop: 8 }}>
                    Deductions: {r.penalties.map((x) => `${x.label} −${x.points}`).join("; ")}.
                  </p>
                )}
              </>
            )}
          </div>
          <div>
            <h4>What reviewers talk about</h4>
            {r.aspects.length ? (
              <div className="table-wrap">
                <table>
                  <thead><tr><th scope="col">Aspect</th><th scope="col" className="num">Mentions</th><th scope="col" className="num">Avg ★</th><th scope="col" className="num">1–2★</th></tr></thead>
                  <tbody>
                    {r.aspects.map((a) => (
                      <tr key={a.aspect}>
                        <td style={{ textTransform: "capitalize" }}>{a.aspect}</td>
                        <td className="num">{a.mentions}</td>
                        <td className="num" style={{ color: a.avgRating < 3 ? "var(--red)" : undefined }}>{a.avgRating}</td>
                        <td className="num">{pct(a.negativeShare)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="muted">No aspect is mentioned often enough (3+ unflagged reviews) to report.</p>
            )}
            {r.signals.clusters.length > 0 && (
              <>
                <h4 style={{ marginTop: 20 }}>Largest duplicate cluster</h4>
                <blockquote style={{ margin: 0, fontFamily: "var(--font-serif)", fontStyle: "italic", color: "var(--ink-2)" }}>
                  “{r.signals.clusters[0].sample}” <span className="small mono">×{r.signals.clusters[0].size}</span>
                </blockquote>
              </>
            )}
          </div>
        </div>
      </div>
    </details>
  );
}

function RatingHistogram({ dist }: { dist: number[] }) {
  const max = Math.max(1, ...dist);
  const total = dist.reduce((s, x) => s + x, 0) || 1;
  return (
    <svg className="hist" viewBox="0 0 330 120" role="img" aria-label={`Rating distribution: ${dist.map((c, i) => `${i + 1} star ${c}`).join(", ")}`}>
      {[5, 4, 3, 2, 1].map((star, row) => {
        const c = dist[star - 1];
        const w = (c / max) * 200;
        const y = row * 23 + 4;
        return (
          <g key={star}>
            <text x="0" y={y + 13} fontSize="11" fontFamily="var(--font-mono)" fill="#4b473e">{star}★</text>
            <rect x="28" y={y} width="200" height="16" fill="#ddd4c0" />
            <rect x="28" y={y} width={w} height="16" fill={star === 5 ? "#1a1915" : "#6e685b"} />
            <text x="236" y={y + 13} fontSize="11" fontFamily="var(--font-mono)" fill="#4b473e">{c} · {Math.round((c / total) * 100)}%</text>
          </g>
        );
      })}
    </svg>
  );
}
