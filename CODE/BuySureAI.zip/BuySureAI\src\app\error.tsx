"use client";

import Link from "next/link";
import { useEffect } from "react";

export default function ErrorPage({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    // Server details are never shown to the user; the digest lets the operator find the server log line.
    console.error(error.digest ?? error.message);
  }, [error]);
  return (
    <div className="wrap" style={{ padding: "72px var(--gutter) 96px", maxWidth: 760 }}>
      <span className="stamp stamp-warn">Error</span>
      <h1 style={{ marginTop: 20, fontSize: "var(--step-3)" }}>Something went wrong on our side.</h1>
      <p className="lede">Your data is safe. Trying again usually works; if it keeps happening, let us know.</p>
      {error.digest && <p className="small muted">Reference: <code>{error.digest}</code></p>}
      <div className="btn-row" style={{ marginTop: 20 }}>
        <button className="btn" onClick={reset}>Try again</button>
        <Link href="/contact?topic=bug" className="btn btn-secondary">Report the problem</Link>
      </div>
    </div>
  );
}
