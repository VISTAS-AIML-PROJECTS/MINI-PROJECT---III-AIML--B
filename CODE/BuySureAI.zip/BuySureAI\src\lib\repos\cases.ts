import "server-only";
import { randomBytes } from "node:crypto";
import { db, newId, now, parseJson } from "../db";
import { ApiError } from "../api";
import type { AuditReport, Category, ProductInput, ReviewInput } from "../engine";
import type { z } from "zod";
import type { productSchema, reviewItemSchema } from "../validation";

export type CaseRow = {
  id: string;
  user_id: string;
  title: string;
  category: Category;
  budget_inr: number | null;
  weights_json: string;
  share_slug: string | null;
  created_at: string;
  updated_at: string;
};

export type CaseSummary = {
  id: string;
  title: string;
  category: Category;
  budgetInr: number | null;
  productCount: number;
  lastAuditAt: string | null;
  updatedAt: string;
};

export type ProductRow = {
  id: string;
  case_id: string;
  name: string;
  brand: string | null;
  url: string | null;
  price_inr: number;
  seller: string | null;
  manufacturer: string | null;
  importer: string | null;
  seller_address: string | null;
  specs_json: string;
  certified_json: string;
  scores_json: string;
  tco_json: string;
  created_at: string;
  updated_at: string;
};

export type ProductView = {
  id: string;
  name: string;
  brand: string | null;
  url: string | null;
  priceInr: number;
  seller: string | null;
  manufacturer: string | null;
  importer: string | null;
  sellerAddress: string | null;
  specs: ProductInput["specs"];
  certified: ProductInput["certified"];
  scores: Record<string, number>;
  cost: ProductInput["cost"];
  reviewCount: number;
};

type ProductData = z.infer<typeof productSchema>;

export async function listCases(userId: string): Promise<CaseSummary[]> {
  return (await db
    .all<{ id: string; title: string; category: Category; budget_inr: number | null; updated_at: string; product_count: number; last_audit_at: string | null }>(
      `SELECT c.id, c.title, c.category, c.budget_inr, c.updated_at,
              (SELECT COUNT(*) FROM products p WHERE p.case_id = c.id) AS product_count,
              (SELECT MAX(created_at) FROM audit_runs a WHERE a.case_id = c.id) AS last_audit_at
         FROM cases c WHERE c.user_id = ? ORDER BY c.updated_at DESC LIMIT 200`,
      userId,
    ))
    .map((r) => ({
      id: r.id, title: r.title, category: r.category, budgetInr: r.budget_inr,
      productCount: r.product_count, lastAuditAt: r.last_audit_at, updatedAt: r.updated_at,
    }));
}

/** Ownership is part of the WHERE clause, so a guessed id belonging to someone else is a plain 404. */
export async function getOwnedCase(caseId: string, userId: string): Promise<CaseRow> {
  const row = await db.get<CaseRow>("SELECT * FROM cases WHERE id = ? AND user_id = ?", caseId, userId);
  if (!row) throw new ApiError(404, "Case not found.");
  return row;
}

export function caseView(row: CaseRow) {
  return {
    id: row.id,
    title: row.title,
    category: row.category,
    budgetInr: row.budget_inr,
    weights: parseJson<Record<string, number>>(row.weights_json, {}),
    shareSlug: row.share_slug,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export async function createCase(userId: string, data: { title: string; category: Category; budgetInr?: number }) {
  const count = (await db.get<{ n: number }>("SELECT COUNT(*) AS n FROM cases WHERE user_id = ?", userId))!.n;
  if (count >= 200) throw new ApiError(409, "You have reached the limit of 200 cases. Delete an old one first.");
  const id = newId();
  const t = now();
  await db.run(
    "INSERT INTO cases (id, user_id, title, category, budget_inr, weights_json, created_at, updated_at) VALUES (?, ?, ?, ?, ?, '{}', ?, ?)",
    id, userId, data.title, data.category, data.budgetInr ?? null, t, t,
  );
  return id;
}

export async function updateCase(row: CaseRow, data: { title?: string; budgetInr?: number | null; weights?: Record<string, number> }) {
  await db.run(
    "UPDATE cases SET title = ?, budget_inr = ?, weights_json = ?, updated_at = ? WHERE id = ?",
    data.title ?? row.title,
    data.budgetInr === undefined ? row.budget_inr : data.budgetInr,
    data.weights ? JSON.stringify(data.weights) : row.weights_json,
    now(),
    row.id,
  );
}

export async function touchCase(caseId: string) {
  await db.run("UPDATE cases SET updated_at = ? WHERE id = ?", now(), caseId);
}

export async function deleteCase(caseId: string) {
  await db.run("DELETE FROM cases WHERE id = ?", caseId);
}

export async function setShare(row: CaseRow, enabled: boolean): Promise<string | null> {
  const slug = enabled ? row.share_slug ?? randomBytes(9).toString("base64url") : null;
  await db.run("UPDATE cases SET share_slug = ?, updated_at = ? WHERE id = ?", slug, now(), row.id);
  return slug;
}

export async function getCaseBySlug(slug: string): Promise<CaseRow | undefined> {
  if (!/^[A-Za-z0-9_-]{8,20}$/.test(slug)) return undefined;
  return await db.get<CaseRow>("SELECT * FROM cases WHERE share_slug = ?", slug);
}

// Products ------------------------------------------------------------------------------------

function toView(r: ProductRow & { review_count?: number }): ProductView {
  return {
    id: r.id,
    name: r.name,
    brand: r.brand,
    url: r.url,
    priceInr: r.price_inr,
    seller: r.seller,
    manufacturer: r.manufacturer,
    importer: r.importer,
    sellerAddress: r.seller_address,
    specs: parseJson(r.specs_json, {}),
    certified: parseJson(r.certified_json, {}),
    scores: parseJson(r.scores_json, {}),
    cost: parseJson(r.tco_json, {}),
    reviewCount: r.review_count ?? 0,
  };
}

export async function listProducts(caseId: string): Promise<ProductView[]> {
  return (await db
    .all<ProductRow & { review_count: number }>(
      `SELECT p.*, (SELECT COUNT(*) FROM reviews r WHERE r.product_id = p.id) AS review_count
         FROM products p WHERE p.case_id = ? ORDER BY p.created_at`,
      caseId,
    ))
    .map(toView);
}

export async function getOwnedProduct(productId: string, userId: string): Promise<ProductRow> {
  const row = await db.get<ProductRow>(
    "SELECT p.* FROM products p JOIN cases c ON c.id = p.case_id WHERE p.id = ? AND c.user_id = ?",
    productId, userId,
  );
  if (!row) throw new ApiError(404, "Product not found.");
  return row;
}

export async function createProduct(caseId: string, d: ProductData) {
  const count = (await db.get<{ n: number }>("SELECT COUNT(*) AS n FROM products WHERE case_id = ?", caseId))!.n;
  if (count >= 12) throw new ApiError(409, "A case can compare at most 12 products.");
  const id = newId();
  const t = now();
  await db.run(
    `INSERT INTO products (id, case_id, name, brand, url, price_inr, seller, manufacturer, importer, seller_address,
       specs_json, certified_json, scores_json, tco_json, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    id, caseId, d.name, d.brand ?? null, d.url ?? null, d.priceInr, d.seller ?? null, d.manufacturer ?? null,
    d.importer ?? null, d.sellerAddress ?? null, JSON.stringify(d.specs ?? {}), JSON.stringify(d.certified ?? {}),
    JSON.stringify(d.scores ?? {}), JSON.stringify(d.cost ?? {}), t, t,
  );
  touchCase(caseId);
  return id;
}

export async function updateProduct(row: ProductRow, d: Partial<ProductData>) {
  const cur = toView(row);
  await db.run(
    `UPDATE products SET name = ?, brand = ?, url = ?, price_inr = ?, seller = ?, manufacturer = ?, importer = ?,
       seller_address = ?, specs_json = ?, certified_json = ?, scores_json = ?, tco_json = ?, updated_at = ? WHERE id = ?`,
    d.name ?? cur.name,
    d.brand === undefined ? cur.brand : d.brand ?? null,
    d.url === undefined ? cur.url : d.url ?? null,
    d.priceInr ?? cur.priceInr,
    d.seller === undefined ? cur.seller : d.seller ?? null,
    d.manufacturer === undefined ? cur.manufacturer : d.manufacturer ?? null,
    d.importer === undefined ? cur.importer : d.importer ?? null,
    d.sellerAddress === undefined ? cur.sellerAddress : d.sellerAddress ?? null,
    JSON.stringify(d.specs ?? cur.specs),
    JSON.stringify(d.certified ?? cur.certified),
    JSON.stringify(d.scores ?? cur.scores),
    JSON.stringify(d.cost ?? cur.cost),
    now(),
    row.id,
  );
  touchCase(row.case_id);
}

export async function deleteProduct(row: ProductRow) {
  await db.run("DELETE FROM products WHERE id = ?", row.id);
  touchCase(row.case_id);
}

// Reviews -------------------------------------------------------------------------------------

export async function importReviews(productId: string, reviews: z.infer<typeof reviewItemSchema>[], replace: boolean) {
  return await db.transaction(async () => {
    if (replace) await db.run("DELETE FROM reviews WHERE product_id = ?", productId);
    const existing = (await db.get<{ n: number }>("SELECT COUNT(*) AS n FROM reviews WHERE product_id = ?", productId))!.n;
    if (existing + reviews.length > 5000) throw new ApiError(409, `A product can hold at most 5,000 reviews (has ${existing}).`);
    const t = now();
    for (const r of reviews) {
      await db.run(
        "INSERT INTO reviews (id, product_id, rating, body, author, posted_at, verified, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        newId(), productId, r.rating, r.body, r.author ?? null,
        r.postedAt ? new Date(r.postedAt).toISOString() : null,
        r.verified === undefined || r.verified === null ? null : r.verified ? 1 : 0,
        t,
      );
    }
    return existing + reviews.length;
  });
}

export async function clearReviews(productId: string) {
  await db.run("DELETE FROM reviews WHERE product_id = ?", productId);
}

export async function listReviews(productId: string, page: number, pageSize: number, minRating?: number) {
  const where = minRating ? "WHERE product_id = ? AND rating = ?" : "WHERE product_id = ?";
  const args = minRating ? [productId, minRating] : [productId];
  const total = (await db.get<{ n: number }>(`SELECT COUNT(*) AS n FROM reviews ${where}`, ...args))!.n;
  const rows = await db.all<{ id: string; rating: number; body: string; author: string | null; posted_at: string | null; verified: number | null }>(
    `SELECT id, rating, body, author, posted_at, verified FROM reviews ${where} ORDER BY posted_at DESC, created_at DESC LIMIT ? OFFSET ?`,
    ...args, pageSize, (page - 1) * pageSize,
  );
  return {
    total,
    items: rows.map((r) => ({ id: r.id, rating: r.rating, body: r.body, author: r.author, postedAt: r.posted_at, verified: r.verified === null ? null : r.verified === 1 })),
  };
}

/** Loads everything the engine needs for one case in two queries. */
export async function engineInputs(caseId: string): Promise<ProductInput[]> {
  const products = await listProducts(caseId);
  const reviewRows = await db.all<{ product_id: string; rating: number; body: string; author: string | null; posted_at: string | null; verified: number | null }>(
    "SELECT r.product_id, r.rating, r.body, r.author, r.posted_at, r.verified FROM reviews r JOIN products p ON p.id = r.product_id WHERE p.case_id = ?",
    caseId,
  );
  const byProduct = new Map<string, ReviewInput[]>();
  for (const r of reviewRows) {
    if (!byProduct.has(r.product_id)) byProduct.set(r.product_id, []);
    byProduct.get(r.product_id)!.push({ rating: r.rating, body: r.body, author: r.author, postedAt: r.posted_at, verified: r.verified === null ? null : r.verified === 1 });
  }
  return products.map((p) => ({
    id: p.id, name: p.name, brand: p.brand, priceInr: p.priceInr, seller: p.seller, manufacturer: p.manufacturer,
    importer: p.importer, sellerAddress: p.sellerAddress, specs: p.specs, certified: p.certified, scores: p.scores,
    cost: p.cost, reviews: byProduct.get(p.id) ?? [],
  }));
}

// Audits --------------------------------------------------------------------------------------

export async function saveAudit(caseId: string, report: AuditReport) {
  const id = newId();
  await db.transaction(async () => {
    await db.run("INSERT INTO audit_runs (id, case_id, report_json, duration_ms, created_at) VALUES (?, ?, ?, ?, ?)",
      id, caseId, JSON.stringify(report), Math.round(report.durationMs), now());
    for (const p of report.products) {
      for (const f of p.findings) {
        await db.run("INSERT INTO audit_findings (id, run_id, product_id, module, severity, code, message) VALUES (?, ?, ?, ?, ?, ?, ?)",
          newId(), id, p.id, f.module, f.severity, f.code, f.message);
      }
    }
    // Keep the 20 most recent runs per case.
    await db.run(
      "DELETE FROM audit_runs WHERE case_id = ? AND id NOT IN (SELECT id FROM audit_runs WHERE case_id = ? ORDER BY created_at DESC LIMIT 20)",
      caseId, caseId,
    );
  });
  return id;
}

export async function latestAudit(caseId: string): Promise<{ id: string; report: AuditReport; narrative: string | null; createdAt: string } | null> {
  const row = await db.get<{ id: string; report_json: string; narrative: string | null; created_at: string }>(
    "SELECT id, report_json, narrative, created_at FROM audit_runs WHERE case_id = ? ORDER BY created_at DESC LIMIT 1",
    caseId,
  );
  if (!row) return null;
  return { id: row.id, report: JSON.parse(row.report_json), narrative: row.narrative, createdAt: row.created_at };
}

export async function saveNarrative(runId: string, narrative: string) {
  await db.run("UPDATE audit_runs SET narrative = ? WHERE id = ?", narrative, runId);
}
