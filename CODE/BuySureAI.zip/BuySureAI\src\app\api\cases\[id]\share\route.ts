import { z } from "zod";
import { handler, json, readJson } from "@/lib/api";
import { getOwnedCase, setShare } from "@/lib/repos/cases";

export const POST = handler<{ id: string }>({ auth: "user" }, async (req, { params, user }) => {
  const row = await getOwnedCase(params.id, user!.id);
  const { enabled } = await readJson(req, z.object({ enabled: z.boolean() }), 1_000);
  const slug = await setShare(row, enabled);
  return json({ shareSlug: slug });
});
