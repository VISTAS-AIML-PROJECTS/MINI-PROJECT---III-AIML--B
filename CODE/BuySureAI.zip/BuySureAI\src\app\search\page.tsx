import type { Metadata } from "next";
import { Suspense } from "react";
import { SearchResults } from "./SearchResults";

export const metadata: Metadata = {
  title: "Search results",
  description: "BuySure AI search: the product you asked about, ranked against the best alternatives in its category.",
  robots: { index: false, follow: true },
};

export default function SearchPage() {
  return (
    <div className="wrap" style={{ paddingBottom: 96 }}>
      <Suspense fallback={<div className="skeleton" style={{ height: 300, marginTop: 32 }} />}>
        <SearchResults />
      </Suspense>
    </div>
  );
}
