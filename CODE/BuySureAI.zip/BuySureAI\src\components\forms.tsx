"use client";

import { useState, type FormEvent } from "react";
import type { ApiResult } from "@/lib/client-api";

export function FieldError({ id, msg }: { id: string; msg?: string }) {
  return <span id={id} className="error" role={msg ? "alert" : undefined}>{msg ?? ""}</span>;
}

/**
 * Small form-state helper: busy flag, form-level error, and per-field errors returned by the
 * API's validation (422 responses carry a `fields` map). The handler returns an ApiResult on
 * failure, or nothing on success.
 */
export function useForm() {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [fields, setFields] = useState<Record<string, string>>({});

  const handle = (fn: (fd: FormData, form: HTMLFormElement) => Promise<ApiResult<unknown> | void>) => async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    // Browser constraint validation first, for instant feedback without a round trip.
    if (!form.checkValidity()) {
      const errs: Record<string, string> = {};
      for (const el of Array.from(form.elements) as HTMLInputElement[]) {
        if (el.name && el.validity && !el.validity.valid) errs[el.name] = el.validationMessage;
      }
      setFields(errs);
      setError("Please fix the highlighted fields.");
      (form.querySelector(":invalid") as HTMLElement | null)?.focus();
      return;
    }
    setBusy(true);
    setError(null);
    setFields({});
    try {
      const res = await fn(new FormData(form), form);
      if (res && !res.ok) {
        setError(res.error);
        setFields(res.fields ?? {});
      }
    } finally {
      setBusy(false);
    }
  };
  return { busy, error, fields, handle, setError };
}
