/**
 * Visual / UX QA with a real browser (uses an installed Chrome or Edge via puppeteer-core).
 *   npm run build && node scripts/visual-qa.mjs [outDir]
 * Captures desktop and mobile screenshots of key screens (signed out and signed in) and fails
 * on console errors, uncaught exceptions, or horizontal overflow at phone width.
 */
import { spawn } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import puppeteer from "puppeteer-core";

const PORT = 3200;
const BASE = `http://localhost:${PORT}`;
const out = path.resolve(process.argv[2] ?? "qa-screenshots");
fs.mkdirSync(out, { recursive: true });
const dbFile = path.join(os.tmpdir(), `buysure-qa-${Date.now()}.db`);
const env = { ...process.env, NODE_ENV: "production", APP_URL: BASE, DATABASE_PATH: dbFile, SESSION_SECRET: "qa-secret-qa-secret-qa-secret-qa-secret-0123" };

const browserPath = [
  process.env.BROWSER_PATH,
  "C:/Program Files/Google/Chrome/Application/chrome.exe",
  "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe",
  "/usr/bin/google-chrome",
  "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
].find((p) => p && fs.existsSync(p));
if (!browserPath) throw new Error("No Chrome/Edge found; set BROWSER_PATH");

const problems = [];
const clickText = (page, text) => page.evaluate((t) => {
  const b = [...document.querySelectorAll("button")].find((x) => x.textContent?.trim() === t);
  if (!b) throw new Error(`button "${t}" not found`);
  b.click();
}, text);
const server = spawn(process.execPath, ["node_modules/next/dist/bin/next", "start", "-p", String(PORT)], { env, stdio: "ignore" });

async function waitForServer() {
  for (let i = 0; i < 60; i++) {
    try { if ((await fetch(`${BASE}/api/health`)).ok) return; } catch {}
    await new Promise((r) => setTimeout(r, 500));
  }
  throw new Error("server did not start");
}

async function shoot(page, name, url, { width, height, full = true, before } = {}) {
  await page.setViewport({ width, height, deviceScaleFactor: 1 });
  if (url) await page.goto(BASE + url, { waitUntil: "load" });
  if (before) { await new Promise((r) => setTimeout(r, 1500)); await before(page); }
  await new Promise((r) => setTimeout(r, 400));
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  if (overflow > 1) problems.push(`${name}: horizontal overflow of ${overflow}px at ${width}px`);
  await page.screenshot({ path: path.join(out, `${name}.png`), fullPage: full });
}

try {
  await waitForServer();
  const browser = await puppeteer.launch({ executablePath: browserPath, headless: true, args: ["--no-sandbox"] });
  const page = await browser.newPage();
  page.on("console", (m) => { if (m.type() === "error" && !page.url().endsWith("/nope")) problems.push(`console error on ${page.url()}: ${m.text()}`); });
  page.on("pageerror", (e) => problems.push(`page error on ${page.url()}: ${e.message}`));

  for (const [name, url] of [["home", "/"], ["search", "/search?q=best%20phone%20under%2020000"], ["category", "/best/phones"], ["product", "/p/realme-p4-power"], ["how", "/how-it-works"], ["faq", "/faq"], ["about", "/about"], ["contact", "/contact"], ["reviews", "/reviews"], ["privacy", "/privacy"], ["register", "/register"], ["404", "/nope"]]) {
    await shoot(page, `desktop-${name}`, url, { width: 1440, height: 900, full: name !== "home" });
    await shoot(page, `mobile-${name}`, url, { width: 390, height: 844, full: false });
  }
  await shoot(page, "desktop-home-full", "/", { width: 1440, height: 900 });
  await shoot(page, "desktop-demo", "/demo", {
    width: 1440, height: 900,
    before: async (p) => { await p.click("main button.btn"); try { await p.waitForSelector(".rank-row", { timeout: 10000 }); } catch (e) { await p.screenshot({ path: path.join(out, "demo-failure.png") }); throw e; } },
  });
  await shoot(page, "mobile-demo", null, { width: 390, height: 844 });

  // Keyboard: the first Tab should land on the skip link (checked on a page without search autofocus).
  await page.setViewport({ width: 1440, height: 900 });
  await page.goto(BASE + "/how-it-works", { waitUntil: "load" });
  await new Promise((r) => setTimeout(r, 1000));
  await page.keyboard.press("Tab");
  const focused = await page.evaluate(() => document.activeElement?.className);
  if (focused !== "skip-link") problems.push(`first Tab focused "${focused}" instead of the skip link`);
  await page.screenshot({ path: path.join(out, "keyboard-skip-link.png") });

  // Signed-in screens.
  await page.goto(BASE + "/register", { waitUntil: "load" });
  await new Promise((r) => setTimeout(r, 1500));
  await page.type("#r-name", "QA Tester");
  await page.type("#r-email", "qa@example.com");
  await page.type("#r-password", "qa-password-123");
  await page.click("#r-terms");
  await Promise.all([page.waitForNavigation({ waitUntil: "load" }), page.click("form button.btn")]);
  await shoot(page, "desktop-dashboard-empty", null, { width: 1440, height: 900 });
  await new Promise((r) => setTimeout(r, 1000));
  await Promise.all([page.waitForNavigation({ waitUntil: "load" }), clickText(page, "Copy the sample case")]);
  await shoot(page, "desktop-case", null, {
    width: 1440, height: 900,
    before: async (p) => { await clickText(p, "Run audit"); await p.waitForSelector(".rank-row", { timeout: 10000 }); },
  });
  await shoot(page, "mobile-case", null, { width: 390, height: 844, full: false });
  await page.setViewport({ width: 1440, height: 900 });
  await clickText(page, "Add product");
  await page.waitForSelector("dialog[open] form");
  await page.screenshot({ path: path.join(out, "desktop-product-dialog.png") });
  await page.keyboard.press("Escape");
  await page.goto(BASE + "/dashboard/watches", { waitUntil: "load" });
  await new Promise((r) => setTimeout(r, 1500));
  await page.type("#nw-name", "Halden V7");
  await page.type("#nw-target", "17000");
  await clickText(page, "Create watch");
  await page.waitForSelector("article.panel");
  await shoot(page, "desktop-watches", null, { width: 1440, height: 900 });
  await shoot(page, "mobile-dashboard", "/dashboard", { width: 390, height: 844, full: false });
  await browser.close();
} finally {
  server.kill();
}

console.log(`Screenshots in ${out}`);
if (problems.length) {
  console.log("Problems:\n" + problems.map((p) => ` - ${p}`).join("\n"));
  process.exit(1);
}
console.log("No console errors, page errors or mobile overflow.");
