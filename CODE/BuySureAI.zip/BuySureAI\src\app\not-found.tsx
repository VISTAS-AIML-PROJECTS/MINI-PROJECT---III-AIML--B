import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = { title: "Page not found", robots: { index: false } };

export default function NotFound() {
  return (
    <div className="wrap" style={{ padding: "72px var(--gutter) 96px", maxWidth: 820 }}>
      <span className="stamp stamp-fail">Claim not verified</span>
      <h1 style={{ marginTop: 20 }}>This page does not exist.</h1>
      <p className="lede">
        We checked. The address may have a typo, the page may have moved, or a shared link may have been turned off by its owner.
      </p>
      <div className="table-wrap" style={{ margin: "28px 0" }}>
        <table>
          <tbody>
            <tr><td>Requested page</td><td className="num"><span className="stamp stamp-fail">404</span></td></tr>
            <tr><td>Rest of the site</td><td className="num"><span className="stamp stamp-pass">Pass</span></td></tr>
          </tbody>
        </table>
      </div>
      <div className="btn-row">
        <Link href="/" className="btn">Go to the home page</Link>
        <Link href="/demo" className="btn btn-secondary">Run the sample audit</Link>
      </div>
      <p className="small muted" style={{ marginTop: 28 }}>
        Looking for something specific? Try <Link href="/how-it-works">how it works</Link>, the <Link href="/faq">FAQ</Link>, or{" "}
        <Link href="/contact">tell us about a broken link</Link>.
      </p>
    </div>
  );
}
