"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { api } from "@/lib/client-api";
import { FieldError, useForm } from "@/components/forms";
import { useToast } from "@/components/Toast";
import { track } from "@/lib/analytics";
import { dateTime } from "@/lib/format";

export function NewCase() {
  const router = useRouter();
  const toast = useToast();
  const f = useForm();
  const [sampleBusy, setSampleBusy] = useState(false);

  const submit = f.handle(async (fd) => {
    const res = await api<{ id: string }>("/api/cases", {
      body: { title: fd.get("title"), category: fd.get("category"), budgetInr: fd.get("budgetInr") || undefined },
    });
    if (!res.ok) return res;
    track("case_created", { category: String(fd.get("category")) });
    router.push(`/dashboard/cases/${res.data.id}`);
  });

  const sample = async () => {
    setSampleBusy(true);
    const res = await api<{ id: string }>("/api/cases/sample", { body: {} });
    setSampleBusy(false);
    if (!res.ok) return toast(res.error, "error");
    router.push(`/dashboard/cases/${res.data.id}`);
  };

  return (
    <form className="panel" onSubmit={submit} noValidate aria-labelledby="new-case-title">
      <h2 id="new-case-title">Start a case</h2>
      {f.error && <div className="notice notice-error" role="alert">{f.error}</div>}
      <div className="grid-3">
        <div className="field" style={{ gridColumn: "span 1" }}>
          <label htmlFor="nc-title">What are you buying?</label>
          <input id="nc-title" name="title" required minLength={3} maxLength={120} placeholder="Phone under ₹20,000" aria-describedby="nc-title-err" />
          <FieldError id="nc-title-err" msg={f.fields.title} />
        </div>
        <div className="field">
          <label htmlFor="nc-category">Category</label>
          <select id="nc-category" name="category" defaultValue="phone">
            <option value="phone">Phone</option>
            <option value="powerbank">Power bank</option>
            <option value="laptop">Laptop</option>
            <option value="earbuds">Earbuds</option>
            <option value="storage">Storage (SSD, USB, memory card)</option>
            <option value="other">Other</option>
          </select>
        </div>
        <div className="field">
          <label htmlFor="nc-budget">Budget in ₹ (optional)</label>
          <input id="nc-budget" name="budgetInr" type="number" inputMode="numeric" min={1} step={1} aria-describedby="nc-budget-err" />
          <FieldError id="nc-budget-err" msg={f.fields.budgetInr} />
        </div>
      </div>
      <div className="btn-row">
        <button className="btn" disabled={f.busy}>{f.busy ? "Creating…" : "Create case"}</button>
        <button type="button" className="btn btn-secondary" onClick={sample} disabled={sampleBusy}>
          {sampleBusy ? "Copying…" : "Copy the sample case"}
        </button>
      </div>
    </form>
  );
}

type N = { id: string; title: string; body: string; link: string | null; read_at: string | null; created_at: string };

export function Notifications({ initial }: { initial: N[] }) {
  const [items, setItems] = useState(initial);
  const unread = items.filter((n) => !n.read_at).length;
  const markRead = async () => {
    const res = await api("/api/notifications", { body: {} });
    if (res.ok) setItems((xs) => xs.map((x) => ({ ...x, read_at: x.read_at ?? new Date().toISOString() })));
  };
  return (
    <section className="panel" aria-labelledby="notif-title">
      <div className="panel-head">
        <h2 id="notif-title" style={{ margin: 0 }}>Notifications {unread > 0 && <span className="stamp stamp-warn" style={{ marginLeft: 8 }}>{unread} new</span>}</h2>
        {unread > 0 && <button className="btn btn-secondary btn-small" onClick={markRead}>Mark all read</button>}
      </div>
      {items.length ? (
        <ul className="list-plain">
          {items.map((n) => (
            <li key={n.id} style={{ padding: "10px 0", borderBottom: "1px solid var(--rule)", opacity: n.read_at ? 0.7 : 1 }}>
              <strong style={{ fontWeight: 500 }}>{n.link ? <Link href={n.link}>{n.title}</Link> : n.title}</strong>
              <div className="small">{n.body}</div>
              <div className="small muted">{dateTime(n.created_at)}</div>
            </li>
          ))}
        </ul>
      ) : (
        <p className="muted" style={{ margin: 0 }}>Price alerts will appear here. Set one up under <Link href="/dashboard/watches">Price watches</Link>.</p>
      )}
    </section>
  );
}
