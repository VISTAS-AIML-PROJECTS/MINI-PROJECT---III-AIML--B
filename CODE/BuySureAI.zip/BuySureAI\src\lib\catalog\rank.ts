import { rank, type RankedProduct } from "../engine/decision";
import { checkPhysics, type PhysicsReport } from "../engine/physics";
import type { CategoryDef } from "./categories";

export type CatalogItem = {
  id: string;
  slug: string;
  category: string;
  name: string;
  brand: string;
  priceInr: number;
  priceNote: string | null;
  variant: string | null;
  released: string | null;
  specs: Record<string, string | number | boolean | null | undefined>;
  sources: { title: string; url: string }[];
  pros: string[];
  cons: string[];
  imagePath: string | null;
  checkedAt: string;
};

export type RankedItem = CatalogItem & {
  rank: number;
  score: number;
  metrics: Record<string, number | null>;
  physics: PhysicsReport;
  reasons: string[];
  weaknesses: string[];
  contributions: RankedProduct["contributions"];
  missing: string[];
};

const fmt = (n: number) => n.toLocaleString("en-IN");

/**
 * Ranks catalogue items with the category's criteria and the chosen weights. Physics failures
 * always sink to the bottom. Also derives plain-language reasons from where each product leads
 * or trails the field, so "why it wins" is computed, not written by hand.
 */
export function rankItems(def: CategoryDef, items: CatalogItem[], weights: Record<string, number>): RankedItem[] {
  const enriched = items.map((it) => {
    const metrics = def.metrics(it.specs, it.priceInr);
    const physics = checkPhysics(def.physics, def.physicsSpecs(it.specs) as never, {}, it.priceInr);
    return { it, metrics, physics };
  });
  const ranked = rank(
    enriched.map((e) => ({
      id: e.it.id,
      name: e.it.name,
      metrics: e.metrics,
      disqualified: e.physics.status === "fail" ? "Advertised specs fail a physics check." : null,
    })),
    def.criteria,
    weights,
  );
  const byId = new Map(enriched.map((e) => [e.it.id, e]));

  return ranked.map((r) => {
    const e = byId.get(r.id)!;
    const reasons: string[] = [];
    const weaknesses: string[] = [];
    for (const c of def.criteria) {
      const v = e.metrics[c.key];
      if (typeof v !== "number") continue;
      const vals = enriched.map((x) => x.metrics[c.key]).filter((x): x is number => typeof x === "number");
      if (vals.length < 3) continue;
      const best = c.direction === "higher" ? Math.max(...vals) : Math.min(...vals);
      const worst = c.direction === "higher" ? Math.min(...vals) : Math.max(...vals);
      const label = c.label.toLowerCase();
      const binary = c.unit === "0/1";
      const unit = c.unit?.startsWith("/") ? c.unit : ` ${c.unit ?? ""}`;
      if (v === best && best !== worst) {
        reasons.push(c.key === "price" ? `Lowest price here (₹${fmt(v)})` : binary ? `Supports ${label}` : `Best ${label} here (${fmt(v)}${unit})`.trim());
      } else if (v === worst && best !== worst && (weights[c.key] ?? 0) > 0) {
        weaknesses.push(c.key === "price" ? `Highest price here (₹${fmt(v)})` : binary ? `No ${label}` : `Weakest ${label} here (${fmt(v)}${unit})`.trim());
      }
    }
    return {
      ...e.it,
      rank: r.rank,
      score: r.score,
      metrics: e.metrics,
      physics: e.physics,
      reasons: reasons.slice(0, 3),
      weaknesses: weaknesses.slice(0, 2),
      contributions: r.contributions,
      missing: r.missing,
    };
  });
}

export function presetWeights(def: CategoryDef, preset?: string | null) {
  return (def.presets.find((p) => p.key === preset) ?? def.presets[0]).weights;
}
