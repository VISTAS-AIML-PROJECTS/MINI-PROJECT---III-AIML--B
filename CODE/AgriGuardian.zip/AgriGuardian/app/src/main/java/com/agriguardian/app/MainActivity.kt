package com.agriguardian.app

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.MultipartBody
import org.json.JSONObject
import android.os.Bundle
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import okhttp3.OkHttpClient
import okhttp3.Request
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                AgriGuardianApp()
            }
        }
    }
}

@Composable
fun AgriGuardianApp() {
    var selectedPage by remember {
        mutableStateOf("Home")
    }
    val client = remember { OkHttpClient() }
    val scope = rememberCoroutineScope()

    var backendStatus by remember {
        mutableStateOf("Not connected yet")
    }
    var selectedImage by remember {
        mutableStateOf<Uri?>(null)
    }
    var diagnosisResult by remember {
        mutableStateOf("")
    }

    var isDiagnosing by remember {
        mutableStateOf(false)
    }

    val imagePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        selectedImage = uri
    }

    val context = LocalContext.current

    Scaffold(
        bottomBar = {
            NavigationBar {
                listOf("Home", "Scan", "Care", "Assistant")
                    .forEach { page ->
                        NavigationBarItem(
                            selected = selectedPage == page,
                            onClick = { selectedPage = page },
                            icon = {
                                Text(
                                    when (page) {
                                        "Home" -> "🏡"
                                        "Scan" -> "🌿"
                                        "Care" -> "💧"
                                        else -> "💬"
                                    }
                                )
                            },
                            label = { Text(page) }
                        )
                    }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                "🌱 AGRI-GUARDIAN",
                style = MaterialTheme.typography.headlineMedium
            )

            Text("Your smart plant health companion")
            Button(onClick = {
                backendStatus = "Connecting..."

                scope.launch {
                    backendStatus = withContext(Dispatchers.IO) {
                        try {
                            val request = Request.Builder()
                                .url("http://127.0.0.1:8001/api/health")
                                .get()
                                .build()

                            client.newCall(request).execute().use { response ->
                                if (response.isSuccessful) {
                                    "Connected successfully: ${response.body?.string()}"
                                } else {
                                    "Server error: HTTP ${response.code}"
                                }
                            }
                        } catch (e: Exception) {
                            "Connection failed: ${e.javaClass.simpleName}: ${e.message}"
                        }
                    }
                }
            }) {
                Text("Test Backend Connection")
            }

            Text("Backend response: $backendStatus")

            when (selectedPage) {
                "Home" -> {
                    Text("Welcome, Plant Guardian!")

                    FeatureCard(
                        "Plant Disease Scanner",
                        "Identify possible diseases from leaf images."
                    ) { selectedPage = "Scan" }

                    FeatureCard(
                        "Plant Care",
                        "Explore watering and care guidance."
                    ) { selectedPage = "Care" }

                    FeatureCard(
                        "AI Assistant",
                        "Ask questions about plant health."
                    ) { selectedPage = "Assistant" }
                }

                "Scan" -> {
                    Text(
                        "Plant Disease Scanner",
                        style = MaterialTheme.typography.headlineSmall
                    )

                    Button(
                        onClick = {
                            imagePicker.launch("image/*")
                        }
                    ) {
                        Text("Select Leaf Image")
                    }

                    selectedImage?.let { uri ->
                        val bitmap = remember(uri) {
                            context.contentResolver
                                .openInputStream(uri)?.use {
                                    BitmapFactory.decodeStream(it)
                                }
                        }

                        if (bitmap != null) {
                            Image(
                                bitmap = bitmap.asImageBitmap(),
                                contentDescription = "Selected leaf",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(260.dp)
                            )

                            Text("Leaf image selected successfully!")

                            Button(
                                enabled = !isDiagnosing,
                                onClick = {
                                    diagnosisResult = ""
                                    isDiagnosing = true

                                    scope.launch {
                                        try {
                                            val result = withContext(Dispatchers.IO) {
                                                val imageBytes = context.contentResolver
                                                    .openInputStream(uri)
                                                    ?.use { it.readBytes() }
                                                    ?: throw Exception("Could not read selected image")

                                                val imageBody = imageBytes.toRequestBody(
                                                    "image/jpeg".toMediaType()
                                                )

                                                val multipartBody = MultipartBody.Builder()
                                                    .setType(MultipartBody.FORM)
                                                    .addFormDataPart("file", "leaf.jpg", imageBody)
                                                    .build()

                                                val request = Request.Builder()
                                                    .url("http://127.0.0.1:8001/api/ai/diagnose")
                                                    .post(multipartBody)
                                                    .build()

                                                client.newCall(request).execute().use { response ->
                                                    val responseText = response.body?.string().orEmpty()

                                                    if (response.isSuccessful) {
                                                        val json = JSONObject(responseText)
                                                        "Plant: ${json.optString("plant")}\n" +
                                                                "Disease: ${json.optString("disease")}\n" +
                                                                "Confidence: ${json.optString("confidence_percent")}%\n" +
                                                                "This is an initial screening, not a confirmed diagnosis."
                                                    } else {
                                                        "Request failed (HTTP ${response.code}): $responseText"
                                                    }
                                                }
                                            }

                                            diagnosisResult = result
                                        } catch (e: Exception) {
                                            diagnosisResult = "Error: ${e.message ?: "Unknown error"}"
                                        } finally {
                                            isDiagnosing = false
                                        }
                                    }
                                }
                            ) {
                                Text(if (isDiagnosing) "Analyzing..." else "Diagnose Plant")
                            }

                            if (diagnosisResult.isNotBlank()) {
                                Text(
                                    text = diagnosisResult,
                                    style = MaterialTheme.typography.bodyLarge
                                )
                            }
                        } else {
                            Text("Unable to open this image. Try another.")
                        }
                    } ?: Text(
                        "Choose a clear photo of a plant leaf to begin."
                    )
                }

                "Care" -> {
                    Text(
                        "Plant Care",
                        style = MaterialTheme.typography.headlineSmall
                    )
                    Text(
                        "Plant-specific care recommendations " +
                                "will appear here."
                    )
                }

                else -> {
                    Text(
                        "AI Plant Assistant",
                        style = MaterialTheme.typography.headlineSmall
                    )
                    Text(
                        "The agricultural assistant will be connected " +
                                "to the backend next."
                    )
                }
            }
        }
    }
}

@Composable
fun FeatureCard(
    title: String,
    description: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        onClick = onClick
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium
            )
            Text(description)
            Text(
                "Open →",
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}