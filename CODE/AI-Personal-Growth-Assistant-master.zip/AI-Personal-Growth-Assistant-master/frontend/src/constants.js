import {
  IconBook,
  IconCalendar,
  IconChart,
  IconClock,
  IconFlame,
  IconHome,
  IconMap,
  IconMoon,
  IconSpark,
  IconSun,
  IconTarget,
} from "./components/icons";

export const NAV_ITEMS = [
  { key: "home", label: "Overview", Icon: IconHome, group: "study" },
  { key: "goals", label: "Goals & Skills", Icon: IconTarget, group: "study" },
  { key: "roadmap", label: "Skill Roadmap", Icon: IconMap, group: "study" },
  { key: "tasks", label: "Daily Planner", Icon: IconCalendar, group: "study" },
  { key: "focus", label: "Focus Mode", Icon: IconClock, group: "study" },
  { key: "assessment", label: "Assessments", Icon: IconBook, group: "insights" },
  { key: "progress", label: "Progress & Insights", Icon: IconChart, group: "insights" },
  { key: "coach", label: "AI Features", Icon: IconSpark, group: "insights" },
];

export const ENERGY_LEVELS = [
  { key: "low", label: "Low energy", helper: "Light, manageable tasks", Icon: IconMoon },
  { key: "medium", label: "Steady", helper: "Balanced study pace", Icon: IconSun },
  { key: "high", label: "Focused", helper: "Ready for deep work", Icon: IconFlame },
];

export function formatEnergyLabel(raw) {
  if (!raw) return "Not checked in";
  const clean = String(raw).trim().toLowerCase();
  if (clean === "low" || clean === "very low") return "Low energy";
  if (clean === "medium" || clean === "good") return "Steady";
  if (clean === "high" || clean === "very high" || clean === "focused") return "Focused";
  return raw.charAt(0).toUpperCase() + raw.slice(1);
}

export function isSameEnergyLevel(currentRaw, optionKey) {
  if (!currentRaw) return false;
  const clean = String(currentRaw).trim().toLowerCase();
  if (optionKey === "low") return clean === "low" || clean === "very low";
  if (optionKey === "medium") return clean === "medium" || clean === "good";
  if (optionKey === "high") return clean === "high" || clean === "very high" || clean === "focused";
  return clean === optionKey;
}

export const PAGE_TITLES = {
  home: "Overview dashboard",
  goals: "Goals & skills",
  roadmap: "Skill roadmap",
  tasks: "Daily planner",
  focus: "Focus mode",
  assessment: "Skill assessments",
  progress: "Progress & insights",
  coach: "AI-assisted features",
  profile: "Settings & profile",
};
