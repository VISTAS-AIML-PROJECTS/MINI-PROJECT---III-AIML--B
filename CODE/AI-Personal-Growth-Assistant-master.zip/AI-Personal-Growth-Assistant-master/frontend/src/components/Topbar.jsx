import { IconClock, IconRefresh, IconTarget } from "./icons";

export default function Topbar({
  title,
  dashboardLoading,
  loggedInUser,
  goals = [],
  activeGoal,
  onSelectGoal,
  onRefresh,
  onOpenMenu,
  onOpenProfile,
  onNavigate,
}) {
  const activeGoalsList = goals.filter(
    (g) => String(g.status || "active").toLowerCase() !== "archived"
  );

  return (
    <header className="growth-topbar">
      <div className="topbar-left">
        <button
          type="button"
          className="mobile-menu-button"
          onClick={onOpenMenu}
          aria-label="Open navigation menu"
        >
          <span />
          <span />
          <span />
        </button>

        <div>
          <span className="topbar-label">GrowthAI Workspace</span>
          <h1>{title || "Overview"}</h1>
        </div>
      </div>

      <div className="topbar-actions">
        {activeGoalsList.length > 0 && onSelectGoal && (
          <div className="topbar-goal-selector">
            <IconTarget width={15} height={15} />
            <label htmlFor="topbar-goal-select" className="sr-only">
              Active Goal
            </label>
            <select
              id="topbar-goal-select"
              value={activeGoal?.id || ""}
              onChange={(e) => {
                const nextId = Number(e.target.value);
                if (nextId) onSelectGoal(nextId);
              }}
              aria-label="Select active goal"
            >
              {activeGoalsList.map((goal) => (
                <option key={goal.id} value={goal.id}>
                  {goal.title}
                </option>
              ))}
            </select>
          </div>
        )}

        {onNavigate && (
          <button
            type="button"
            className="topbar-focus-btn"
            onClick={() => onNavigate("focus")}
            title="Open Focus Mode"
          >
            <IconClock width={16} height={16} />
            <span>Focus Mode</span>
          </button>
        )}

        <button
          type="button"
          className={`icon-button ${dashboardLoading ? "spinning" : ""}`}
          title="Refresh workspace data"
          aria-label="Refresh workspace data"
          onClick={onRefresh}
          disabled={dashboardLoading}
        >
          <IconRefresh width={17} height={17} />
        </button>

        <button
          type="button"
          className="topbar-avatar"
          onClick={onOpenProfile}
          title="Open settings and profile"
          aria-label="Open settings and profile"
        >
          {loggedInUser?.name?.charAt(0)?.toUpperCase() || "S"}
        </button>
      </div>
    </header>
  );
}
