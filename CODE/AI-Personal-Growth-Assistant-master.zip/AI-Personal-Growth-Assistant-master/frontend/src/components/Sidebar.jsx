import { NAV_ITEMS } from "../constants";
import { IconLogout, IconSpark, IconTarget, IconUser, IconX } from "./icons";

export default function Sidebar({
  activePage,
  loggedInUser,
  mobileSidebar,
  activeGoal,
  pendingTodayCount = 0,
  onNavigate,
  onLogout,
  onCloseMobile,
}) {
  const go = (page) => {
    onNavigate(page);
    onCloseMobile?.();
  };

  const studyItems = NAV_ITEMS.filter((item) => item.group === "study");
  const insightItems = NAV_ITEMS.filter((item) => item.group === "insights");

  return (
    <aside
      className={`growth-sidebar ${mobileSidebar ? "mobile-open" : ""}`}
      aria-label="Primary navigation"
    >
      <div className="sidebar-header-row">
        <button
          type="button"
          className="sidebar-logo"
          onClick={() => go("home")}
          aria-label="Go to GrowthAI Overview"
        >
          <div className="sidebar-logo-icon">
            <IconSpark width={17} height={17} />
          </div>

          <div className="sidebar-logo-text">
            <strong>GrowthAI</strong>
            <span>Study &amp; Growth Companion</span>
          </div>
        </button>

        {mobileSidebar && (
          <button
            type="button"
            className="mobile-close-btn"
            onClick={onCloseMobile}
            aria-label="Close navigation menu"
          >
            <IconX width={18} height={18} />
          </button>
        )}
      </div>

      {activeGoal && (
        <button
          type="button"
          className="sidebar-goal-pill"
          onClick={() => go("goals")}
          title="View or switch your active goal"
        >
          <span className="sidebar-goal-icon">
            <IconTarget width={15} height={15} />
          </span>
          <div className="sidebar-goal-info">
            <small>Active goal</small>
            <strong>{activeGoal.title}</strong>
          </div>
        </button>
      )}

      <div className="sidebar-section-title">Study Workspace</div>

      <nav className="nav-list" aria-label="Study workspace">
        {studyItems.map(({ key, label, Icon }) => {
          const isActive = activePage === key;
          return (
            <button
              key={key}
              type="button"
              className={`nav-item ${isActive ? "active" : ""}`}
              aria-current={isActive ? "page" : undefined}
              onClick={() => go(key)}
            >
              <Icon width={18} height={18} />
              <span>{label}</span>
              {key === "tasks" && pendingTodayCount > 0 && (
                <span className="nav-badge" aria-label={`${pendingTodayCount} pending today`}>
                  {pendingTodayCount}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      <div className="sidebar-section-title">Evaluation &amp; Insights</div>

      <nav className="nav-list" aria-label="Evaluation and insights">
        {insightItems.map(({ key, label, Icon }) => {
          const isActive = activePage === key;
          return (
            <button
              key={key}
              type="button"
              className={`nav-item ${isActive ? "active" : ""}`}
              aria-current={isActive ? "page" : undefined}
              onClick={() => go(key)}
            >
              <Icon width={18} height={18} />
              <span>{label}</span>
            </button>
          );
        })}
      </nav>

      <div className="sidebar-section-title">Account</div>

      <nav className="nav-list" aria-label="Account settings">
        <button
          type="button"
          className={`nav-item ${activePage === "profile" ? "active" : ""}`}
          aria-current={activePage === "profile" ? "page" : undefined}
          onClick={() => go("profile")}
        >
          <IconUser width={18} height={18} />
          <span>Settings &amp; Profile</span>
        </button>
      </nav>

      <div className="sidebar-bottom">
        <div className="sidebar-user">
          <div className="user-avatar" aria-hidden="true">
            {loggedInUser?.name?.charAt(0)?.toUpperCase() || "S"}
          </div>

          <div className="sidebar-user-info">
            <strong>{loggedInUser?.name || "Student"}</strong>
            <span>{loggedInUser?.email || ""}</span>
          </div>
        </div>

        <button type="button" className="logout-button" onClick={onLogout}>
          <IconLogout width={16} height={16} />
          <span>Sign out</span>
        </button>
      </div>
    </aside>
  );
}
