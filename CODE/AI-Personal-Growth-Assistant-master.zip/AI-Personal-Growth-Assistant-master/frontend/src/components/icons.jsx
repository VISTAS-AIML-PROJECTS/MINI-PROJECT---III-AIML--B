const iconProps = {
  width: 20,
  height: 20,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.85,
  strokeLinecap: "round",
  strokeLinejoin: "round",
  "aria-hidden": "true",
};

export const IconHome = (p) => (
  <svg {...iconProps} {...p}>
    <path d="M4 11.5 12 4l8 7.5" />
    <path d="M6 10v9a1 1 0 0 0 1 1h3v-6h4v6h3a1 1 0 0 0 1-1v-9" />
  </svg>
);

export const IconTarget = (p) => (
  <svg {...iconProps} {...p}>
    <circle cx="12" cy="12" r="8" />
    <circle cx="12" cy="12" r="4" />
    <circle cx="12" cy="12" r="0.8" fill="currentColor" />
  </svg>
);

export const IconCheck = (p) => (
  <svg {...iconProps} {...p}>
    <rect x="4" y="4" width="16" height="16" rx="4.5" />
    <path d="M8.5 12.5 11 15l5-6" />
  </svg>
);

export const IconRing = (p) => (
  <svg {...iconProps} {...p}>
    <circle cx="12" cy="12" r="8" strokeDasharray="34 50" />
    <path d="M12 8v4l2.5 2.5" />
  </svg>
);

export const IconSpark = (p) => (
  <svg {...iconProps} {...p}>
    <path d="M12 3 13.8 9.2 20 11l-6.2 1.8L12 19l-1.8-6.2L4 11l6.2-1.8z" />
  </svg>
);

export const IconUser = (p) => (
  <svg {...iconProps} {...p}>
    <circle cx="12" cy="8.5" r="3.4" />
    <path d="M5 20c1.3-3.6 4.1-5.5 7-5.5s5.7 1.9 7 5.5" />
  </svg>
);

export const IconBolt = (p) => (
  <svg {...iconProps} {...p}>
    <path d="M12.5 3 5 13.5h5.5L11 21l7.5-10.5H13z" />
  </svg>
);

export const IconRefresh = (p) => (
  <svg {...iconProps} {...p}>
    <path d="M4 10a8 8 0 0 1 14-4.9M20 14a8 8 0 0 1-14 4.9" />
    <path d="M18 3v5h-5M6 21v-5h5" />
  </svg>
);

export const IconLogout = (p) => (
  <svg {...iconProps} {...p}>
    <path d="M9 21H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3" />
    <path d="M16 17l5-5-5-5" />
    <path d="M21 12H9" />
  </svg>
);

export const IconEye = (p) => (
  <svg {...iconProps} {...p}>
    <path d="M2 12s3.8-6.5 10-6.5S22 12 22 12s-3.8 6.5-10 6.5S2 12 2 12Z" />
    <circle cx="12" cy="12" r="2.6" />
  </svg>
);

export const IconEyeOff = (p) => (
  <svg {...iconProps} {...p}>
    <path d="M3 3l18 18" />
    <path d="M10.6 5.7A10.4 10.4 0 0 1 12 5.5c6.2 0 10 6.5 10 6.5a17.6 17.6 0 0 1-3.6 4.3M6.5 7.8A17.4 17.4 0 0 0 2 12s3.8 6.5 10 6.5a10.6 10.6 0 0 0 4.2-.85" />
    <path d="M9.6 10a2.6 2.6 0 0 0 3.6 3.6" />
  </svg>
);

export const IconMail = (p) => (
  <svg {...iconProps} {...p}>
    <rect x="3" y="5" width="18" height="14" rx="3" />
    <path d="M4 7l8 6 8-6" />
  </svg>
);

export const IconLock = (p) => (
  <svg {...iconProps} {...p}>
    <rect x="4.5" y="10.5" width="15" height="10" rx="2.5" />
    <path d="M8 10.5V8a4 4 0 0 1 8 0v2.5" />
  </svg>
);

export const IconUserPlus = (p) => (
  <svg {...iconProps} {...p}>
    <circle cx="9" cy="8.5" r="3.2" />
    <path d="M3.5 20c1.2-3.4 3.8-5.2 5.5-5.2s4.3 1.8 5.5 5.2" />
    <path d="M18 8v5M15.5 10.5h5" />
  </svg>
);

export const IconMoon = (p) => (
  <svg {...iconProps} {...p}>
    <path d="M20 14.5A8.5 8.5 0 1 1 9.5 4a7 7 0 0 0 10.5 10.5Z" />
  </svg>
);

export const IconSun = (p) => (
  <svg {...iconProps} {...p}>
    <circle cx="12" cy="12" r="4" />
    <path d="M12 2.5v2.5M12 19v2.5M4.9 4.9l1.8 1.8M17.3 17.3l1.8 1.8M2.5 12H5M19 12h2.5M4.9 19.1l1.8-1.8M17.3 6.7l1.8-1.8" />
  </svg>
);

export const IconFlame = (p) => (
  <svg {...iconProps} {...p}>
    <path d="M12 3c1 3-2 4.2-2 7a4 4 0 0 0 8 0c0-1.4-.6-2.2-1.2-3 .4 2-1 2.8-1.8 2 .8-3-1-4.4-3-6Z" />
    <path d="M9 14.5a3 3 0 1 0 6 0c0-1-1-1.8-1-3-1 1-1.6 1.6-1.6 3-1.4-.6-1.4-1.6-1.4-2.5 1 1-2 1.6-2 2.5Z" />
  </svg>
);

export const IconPlus = (p) => (
  <svg {...iconProps} {...p}>
    <path d="M12 5v14M5 12h14" />
  </svg>
);

export const IconArrow = (p) => (
  <svg {...iconProps} {...p}>
    <path d="M5 12h14M13 6l6 6-6 6" />
  </svg>
);

export const IconX = (p) => (
  <svg {...iconProps} {...p}>
    <path d="M6 6l12 12M18 6 6 18" />
  </svg>
);

export const IconMap = (p) => (
  <svg {...iconProps} {...p}>
    <path d="M3 6.5 9 4l6 2.5L21 4v13.5L15 20l-6-2.5L3 20V6.5Z" />
    <path d="M9 4v13.5M15 6.5V20" />
  </svg>
);

export const IconClock = (p) => (
  <svg {...iconProps} {...p}>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M12 7.5V12l3 2" />
  </svg>
);

export const IconCalendar = (p) => (
  <svg {...iconProps} {...p}>
    <rect x="3.5" y="4.5" width="17" height="16" rx="3" />
    <path d="M8 3v3M16 3v3M3.5 9.5h17" />
  </svg>
);

export const IconChart = (p) => (
  <svg {...iconProps} {...p}>
    <path d="M4 19.5h16" />
    <rect x="6" y="11" width="3" height="6" rx="1" />
    <rect x="10.5" y="7" width="3" height="10" rx="1" />
    <rect x="15" y="4.5" width="3" height="12.5" rx="1" />
  </svg>
);

export const IconPlay = (p) => (
  <svg {...iconProps} {...p}>
    <polygon points="7 5 19 12 7 19 7 5" fill="currentColor" stroke="none" />
  </svg>
);

export const IconPause = (p) => (
  <svg {...iconProps} {...p}>
    <rect x="6.5" y="5" width="4" height="14" rx="1" fill="currentColor" stroke="none" />
    <rect x="13.5" y="5" width="4" height="14" rx="1" fill="currentColor" stroke="none" />
  </svg>
);

export const IconReset = (p) => (
  <svg {...iconProps} {...p}>
    <path d="M3.5 12a8.5 8.5 0 1 0 2.5-6L3.5 8.5" />
    <path d="M3.5 4v4.5H8" />
  </svg>
);

export const IconBook = (p) => (
  <svg {...iconProps} {...p}>
    <path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v16H6.5A2.5 2.5 0 0 0 4 21.5V5.5Z" />
    <path d="M4 19a2.5 2.5 0 0 1 2.5-2.5H20" />
  </svg>
);

export const IconEdit = (p) => (
  <svg {...iconProps} {...p}>
    <path d="M12 20h9" />
    <path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5Z" />
  </svg>
);

export const IconArchive = (p) => (
  <svg {...iconProps} {...p}>
    <rect x="3" y="4" width="18" height="4" rx="1" />
    <path d="M5 8v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8" />
    <path d="M10 12h4" />
  </svg>
);

export const IconInfo = (p) => (
  <svg {...iconProps} {...p}>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M12 11.5v5M12 8h.01" />
  </svg>
);

export const IconAlert = (p) => (
  <svg {...iconProps} {...p}>
    <path d="M10.3 3.9 2.3 18a2 2 0 0 0 1.7 3h16a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z" />
    <path d="M12 9v4.5M12 17h.01" />
  </svg>
);

export const IconAward = (p) => (
  <svg {...iconProps} {...p}>
    <circle cx="12" cy="9" r="5.5" />
    <path d="M9 14 7.5 21 12 18.5 16.5 21 15 14" />
  </svg>
);

export const IconFilter = (p) => (
  <svg {...iconProps} {...p}>
    <path d="M4 6h16M7 12h10M10 18h4" />
  </svg>
);

export const IconChevronRight = (p) => (
  <svg {...iconProps} {...p}>
    <path d="m9 6 6 6-6 6" />
  </svg>
);
