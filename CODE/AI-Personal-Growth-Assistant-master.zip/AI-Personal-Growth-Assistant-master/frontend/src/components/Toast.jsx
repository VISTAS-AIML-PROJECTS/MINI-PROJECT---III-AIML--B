import { IconAlert, IconCheck, IconInfo, IconX } from "./icons";

export default function Toast({ toast, onClose }) {
  if (!toast) return null;

  const type = toast.type || "info";
  const Icon =
    type === "success" ? IconCheck : type === "error" || type === "warning" ? IconAlert : IconInfo;

  return (
    <div
      className={`toast toast-${type}`}
      role={type === "error" ? "alert" : "status"}
      aria-live={type === "error" ? "assertive" : "polite"}
    >
      <span className="toast-icon">
        <Icon width={17} height={17} />
      </span>
      <span className="toast-message">{toast.message}</span>

      <button
        type="button"
        className="toast-close"
        onClick={onClose}
        aria-label="Close notification"
      >
        <IconX width={15} height={15} />
      </button>
    </div>
  );
}
