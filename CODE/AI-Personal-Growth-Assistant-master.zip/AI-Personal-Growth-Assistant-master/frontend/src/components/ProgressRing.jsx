export default function ProgressRing({
  percent = 0,
  size = 128,
  stroke = 11,
  variant = "mint",
  label = "Progress",
}) {
  const safePercent = Math.max(0, Math.min(Number(percent) || 0, 100));
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (safePercent / 100) * circumference;

  return (
    <svg
      width={size}
      height={size}
      viewBox={`0 0 ${size} ${size}`}
      className={`progress-ring progress-ring-${variant}`}
      role="img"
      aria-label={`${label}: ${Math.round(safePercent)}%`}
    >
      <circle
        className="progress-ring-track"
        cx={size / 2}
        cy={size / 2}
        r={radius}
        strokeWidth={stroke}
        fill="none"
      />

      <circle
        className="progress-ring-fill"
        cx={size / 2}
        cy={size / 2}
        r={radius}
        strokeWidth={stroke}
        fill="none"
        strokeDasharray={circumference}
        strokeDashoffset={offset}
        transform={`rotate(-90 ${size / 2} ${size / 2})`}
      />
    </svg>
  );
}
