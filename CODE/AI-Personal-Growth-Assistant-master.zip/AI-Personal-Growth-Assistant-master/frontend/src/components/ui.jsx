import { IconInfo } from "./icons";

export function Badge({ variant = "neutral", children, className = "" }) {
  return (
    <span className={`ui-badge ui-badge-${variant} ${className}`.trim()}>
      {children}
    </span>
  );
}

export function ProgressBar({
  value = 0,
  max = 100,
  variant = "primary",
  label,
  showValue = false,
  size = "md",
}) {
  const safeMax = max > 0 ? max : 100;
  const percent = Math.max(0, Math.min(100, Math.round((Number(value) / safeMax) * 100)));

  return (
    <div className="ui-progress-wrapper">
      {(label || showValue) && (
        <div className="ui-progress-header">
          {label && <span className="ui-progress-label">{label}</span>}
          {showValue && <span className="ui-progress-value">{percent}%</span>}
        </div>
      )}
      <div
        className={`ui-progress-track ui-progress-${size}`}
        role="progressbar"
        aria-label={label || "Progress"}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={percent}
      >
        <div
          className={`ui-progress-fill ui-progress-fill-${variant}`}
          style={{ width: `${percent}%` }}
        />
      </div>
    </div>
  );
}

export function StatCard({ label, value, helper, Icon, tone = "blue" }) {
  return (
    <div className="ui-stat-card">
      <div className="ui-stat-top">
        <span className="ui-stat-label">{label}</span>
        {Icon && (
          <span className={`ui-stat-icon ui-stat-icon-${tone}`}>
            <Icon width={18} height={18} />
          </span>
        )}
      </div>
      <strong className="ui-stat-value">{value}</strong>
      {helper && <span className="ui-stat-helper">{helper}</span>}
    </div>
  );
}

export function EmptyState({ Icon, title, description, action, secondaryAction }) {
  const DisplayIcon = Icon || IconInfo;
  return (
    <div className="ui-empty-state">
      <div className="ui-empty-icon">
        <DisplayIcon width={24} height={24} />
      </div>
      <h3>{title}</h3>
      {description && <p>{description}</p>}
      {(action || secondaryAction) && (
        <div className="ui-empty-actions">
          {action}
          {secondaryAction}
        </div>
      )}
    </div>
  );
}

export function Skeleton({ lines = 3, height = 16 }) {
  return (
    <div className="ui-skeleton-group" aria-busy="true" aria-live="polite">
      {Array.from({ length: lines }).map((_, idx) => (
        <div
          key={idx}
          className="ui-skeleton-line"
          style={{
            height: `${height}px`,
            width: idx === lines - 1 && lines > 1 ? "68%" : "100%",
          }}
        />
      ))}
    </div>
  );
}

export function SectionHeader({ kicker, title, description, actions }) {
  return (
    <div className="page-heading">
      <div>
        {kicker && <span className="eyebrow">{kicker}</span>}
        <h2>{title}</h2>
        {description && <p>{description}</p>}
      </div>
      {actions && <div className="heading-actions">{actions}</div>}
    </div>
  );
}
