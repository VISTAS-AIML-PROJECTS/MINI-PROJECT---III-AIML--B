import { useEffect, useRef, useState } from "react";
import { api, errorMessage } from "../api/client";
import { formatEnergyLabel } from "../constants";
import { Badge, SectionHeader } from "../components/ui";
import {
  IconBolt,
  IconBook,
  IconCalendar,
  IconChart,
  IconCheck,
  IconInfo,
  IconRefresh,
  IconSpark,
  IconTarget,
} from "../components/icons";

export default function CoachPage({
  activeGoal,
  todayTasks = [],
  allTasks = [],
  notify,
  onNavigate,
  onTasksChanged,
}) {
  const [goalSkills, setGoalSkills] = useState([]);
  const [preparingSkills, setPreparingSkills] = useState(false);
  const [loadingSkills, setLoadingSkills] = useState(false);

  const [advice, setAdvice] = useState(null);
  const [generatingPlan, setGeneratingPlan] = useState(false);
  const [lastPlanResult, setLastPlanResult] = useState(null);

  // Conversational AI Study Coach state
  const [coachStatus, setCoachStatus] = useState({
    configured: true,
    model: null,
    checked: false,
  });
  const [questionInput, setQuestionInput] = useState("");
  const [chatHistory, setChatHistory] = useState([]);
  const [askingCoach, setAskingCoach] = useState(false);
  const [chatError, setChatError] = useState("");
  const chatEndRef = useRef(null);
  const turnSeqRef = useRef(0);

  const pendingTasks = (allTasks.length > 0 ? allTasks : todayTasks).filter(
    (t) => String(t.status || "pending").toLowerCase() === "pending"
  );
  const [selectedTaskId, setSelectedTaskId] = useState("");
  const effectiveTaskId =
    selectedTaskId && pendingTasks.some((t) => String(t.id) === String(selectedTaskId))
      ? selectedTaskId
      : pendingTasks[0]?.id
        ? String(pendingTasks[0].id)
        : "";
  const [predictionData, setPredictionData] = useState(null);
  const [loadingPrediction, setLoadingPrediction] = useState(false);

  useEffect(() => {
    let cancelled = false;

    async function loadActiveModules() {
      try {
        const statusRes = await api.getCoachStatus();
        if (!cancelled && statusRes.ok && statusRes.data) {
          setCoachStatus({
            configured: Boolean(statusRes.data.configured),
            model: statusRes.data.model || null,
            checked: true,
          });
        }
      } catch {
        /* ignore */
      }

      try {
        const adviceRes = await api.getAdaptiveRecommendation();
        if (!cancelled && adviceRes.ok) {
          setAdvice(adviceRes.data);
        }
      } catch {
        /* ignore */
      }

      if (activeGoal?.id) {
        setLoadingSkills(true);
        try {
          const skillsRes = await api.getGoalSkills(activeGoal.id);
          if (!cancelled && skillsRes.ok) {
            setGoalSkills(skillsRes.data?.skills || []);
            setPreparingSkills(Boolean(skillsRes.data?.preparing));
          }
        } catch {
          /* ignore */
        } finally {
          if (!cancelled) setLoadingSkills(false);
        }
      } else {
        setGoalSkills([]);
        setPreparingSkills(false);
      }
    }

    loadActiveModules();
    return () => {
      cancelled = true;
    };
  }, [activeGoal?.id]);

  useEffect(() => {
    let cancelled = false;
    async function loadTaskPrediction() {
      await Promise.resolve();
      if (cancelled) return;
      if (!effectiveTaskId) {
        setPredictionData(null);
        return;
      }
      setLoadingPrediction(true);
      try {
        const res = await api.getTaskPrediction(effectiveTaskId);
        if (!cancelled) {
          setPredictionData(
            res.ok
              ? res.data
              : {
                  status: "error",
                  message: errorMessage(res.data, "Prediction unavailable."),
                }
          );
        }
      } catch {
        if (!cancelled) {
          setPredictionData({
            status: "error",
            message: "Could not reach prediction endpoint.",
          });
        }
      } finally {
        if (!cancelled) setLoadingPrediction(false);
      }
    }

    loadTaskPrediction();
    return () => {
      cancelled = true;
    };
  }, [effectiveTaskId]);

  const starterPrompts = [
    activeGoal
      ? `How should I structure a 30-minute study session for "${activeGoal.title}" today?`
      : "How can I structure a 30-minute deep-focus study block today?",
    goalSkills[0]?.name
      ? `Explain the core concepts of ${goalSkills[0].name} with a practical example.`
      : "What is the best way to identify and close my biggest skill gaps?",
    "I'm feeling low on energy and tempted to procrastinate. What's a small first step I can take?",
  ];

  const sendQuestion = async (rawQuestion) => {
    const trimmed = String(rawQuestion ?? questionInput).trim();
    if (!trimmed || askingCoach) return;

    setChatError("");
    setQuestionInput("");
    const priorHistory = chatHistory.map((m) => ({
      role: m.role,
      content: m.content,
    }));

    turnSeqRef.current += 1;
    const userTurn = {
      id: `user-${turnSeqRef.current}`,
      role: "user",
      content: trimmed,
    };
    setChatHistory((prev) => [...prev, userTurn]);
    setAskingCoach(true);

    try {
      const { ok, data } = await api.askCoach({
        question: trimmed,
        goal_id: activeGoal?.id ?? null,
        history: priorHistory,
      });

      if (!ok) {
        const msg = errorMessage(
          data,
          "Could not get a response from the AI Study Coach."
        );
        setChatError(msg);
        notify?.("error", msg);
        return;
      }

      turnSeqRef.current += 1;
      const assistantTurn = {
        id: `assistant-${turnSeqRef.current}`,
        role: "assistant",
        content: data?.answer || "No response received.",
        model: data?.model || coachStatus.model || "gemini",
      };
      setChatHistory((prev) => [...prev, assistantTurn]);
      setTimeout(() => {
        chatEndRef.current?.scrollIntoView?.({ behavior: "smooth", block: "nearest" });
      }, 60);
    } catch {
      const msg = "Could not connect to the GrowthAI server.";
      setChatError(msg);
      notify?.("error", msg);
    } finally {
      setAskingCoach(false);
    }
  };

  const handleChatSubmit = (e) => {
    e.preventDefault();
    sendQuestion(questionInput);
  };

  const handleGenerateDailyPlan = async () => {
    if (!activeGoal?.id) {
      notify?.("error", "Select an active goal first.");
      return;
    }
    setGeneratingPlan(true);
    try {
      const { ok, data } = await api.generateDailyPlan();
      if (!ok) {
        notify?.("error", errorMessage(data, "Could not generate daily plan."));
        return;
      }
      setLastPlanResult(data);
      const count = data?.tasks_created?.length || 0;
      notify?.(
        "success",
        count > 0
          ? `Generated ${count} study task${count === 1 ? "" : "s"} (${data.planned_minutes} min).`
          : "Your daily study budget is already filled for today."
      );
      onTasksChanged?.();
    } catch {
      notify?.("error", "Could not connect to the GrowthAI server.");
    } finally {
      setGeneratingPlan(false);
    }
  };

  const handleRefreshGoalSkills = async () => {
    if (!activeGoal?.id) return;
    setLoadingSkills(true);
    try {
      const res = await api.getGoalSkills(activeGoal.id);
      if (res.ok) {
        setGoalSkills(res.data?.skills || []);
        setPreparingSkills(Boolean(res.data?.preparing));
        notify?.("success", "Skill mapping status refreshed.");
      }
    } catch {
      notify?.("error", "Could not refresh skill status.");
    } finally {
      setLoadingSkills(false);
    }
  };

  return (
    <div className="page-stack">
      {/* Section 1: Conversational AI Study Coach (Gemini via google-genai) */}
      <section className="page-section">
        <SectionHeader
          kicker="Interactive Gemini Study Mentor"
          title="Conversational AI Study Coach"
          description="Ask questions about your active goal, clarify difficult concepts, or get grounded advice on overcoming study roadblocks."
          action={
            <div className="coach-status-bar">
              <Badge variant={coachStatus.configured ? "mint" : "warning"}>
                {coachStatus.configured
                  ? `Connected · ${coachStatus.model || "Gemini"}`
                  : "GEMINI_API_KEY Not Configured"}
              </Badge>
              {activeGoal && (
                <Badge variant="primary">Goal Context: {activeGoal.title}</Badge>
              )}
            </div>
          }
        />

        <div className="coach-chat-card">
          <div className="coach-prompts-row">
            <span className="coach-prompts-label">Try asking:</span>
            <div className="coach-prompts-list">
              {starterPrompts.map((promptText, idx) => (
                <button
                  key={idx}
                  type="button"
                  className="coach-prompt-chip"
                  disabled={askingCoach || !coachStatus.configured}
                  onClick={() => sendQuestion(promptText)}
                >
                  {promptText}
                </button>
              ))}
            </div>
          </div>

          <div className="coach-messages-area" aria-live="polite">
            {chatHistory.length === 0 ? (
              <div className="coach-empty-state">
                <div className="ai-module-icon blue">
                  <IconSpark width={20} height={20} />
                </div>
                <div>
                  <h4>Ask your GrowthAI Study Coach anything</h4>
                  <p>
                    Your coach automatically considers your active goal
                    {activeGoal ? ` ("${activeGoal.title}")` : ""}, mapped skills,
                    energy check-ins, and pending tasks so answers stay relevant to your day.
                  </p>
                </div>
              </div>
            ) : (
              <div className="coach-messages-list">
                {chatHistory.map((item) => (
                  <div
                    key={item.id}
                    className={`coach-message-bubble ${
                      item.role === "user" ? "is-user" : "is-assistant"
                    }`}
                  >
                    <div className="coach-message-meta">
                      <strong>
                        {item.role === "user" ? "You" : "GrowthAI Coach"}
                      </strong>
                      {item.model && (
                        <span className="coach-model-tag">{item.model}</span>
                      )}
                    </div>
                    <div className="coach-message-text">{item.content}</div>
                  </div>
                ))}
                {askingCoach && (
                  <div className="coach-message-bubble is-assistant is-loading">
                    <div className="coach-message-meta">
                      <strong>GrowthAI Coach</strong>
                    </div>
                    <div className="coach-message-text">Thinking…</div>
                  </div>
                )}
                <div ref={chatEndRef} />
              </div>
            )}
          </div>

          {chatError && (
            <div className="coach-error-banner" role="alert">
              <IconInfo width={16} height={16} />
              <span>{chatError}</span>
            </div>
          )}

          <form className="coach-input-form" onSubmit={handleChatSubmit}>
            <input
              type="text"
              className="coach-input-field"
              placeholder={
                coachStatus.configured
                  ? "Ask a study question, concept explanation, or planning tip…"
                  : "Add GEMINI_API_KEY to backend/.env to enable AI Coach chat"
              }
              value={questionInput}
              onChange={(e) => setQuestionInput(e.target.value)}
              maxLength={2000}
              disabled={askingCoach || !coachStatus.configured}
              aria-label="Ask the AI Study Coach a question"
            />
            <div className="coach-input-actions">
              {chatHistory.length > 0 && (
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={() => {
                    setChatHistory([]);
                    setChatError("");
                  }}
                  disabled={askingCoach}
                >
                  Clear
                </button>
              )}
              <button
                type="submit"
                className="btn-primary"
                disabled={
                  askingCoach ||
                  !coachStatus.configured ||
                  !questionInput.trim()
                }
              >
                <IconSpark width={15} height={15} />
                {askingCoach ? "Sending…" : "Ask Coach"}
              </button>
            </div>
          </form>
        </div>
      </section>

      {/* Section 2: Active & Connected AI / ML Capabilities */}
      <section className="page-section">
        <SectionHeader
          kicker="Connected Backend Intelligence"
          title="AI & Machine Learning Features"
          description="Explore the real AI and machine-learning capabilities active in your GrowthAI workspace, alongside transparent status for upcoming modules."
        />

        <div className="ai-modules-grid">
          {/* Active Module 1: AI Skill Mapping & Question Generation */}
          <article className="ai-module-card active-module">
            <div className="ai-module-top">
              <div className="ai-module-icon blue">
                <IconSpark width={20} height={20} />
              </div>
              <Badge variant="mint">Connected &amp; Active</Badge>
            </div>

            <h3>AI Goal-to-Skill Mapping &amp; Validated MCQ Generation</h3>
            <p>
              When you create a new goal topic, GrowthAI maps 4–6 testable core skills and generates multiple-choice diagnostic questions verified by a second-opinion model check before saving to PostgreSQL.
            </p>

            <div className="ai-module-live-box">
              <div className="ai-live-row">
                <span>Active Goal:</span>
                <strong>{activeGoal ? activeGoal.title : "None selected"}</strong>
              </div>
              <div className="ai-live-row">
                <span>Mapped Skills:</span>
                <strong>
                  {loadingSkills
                    ? "Checking..."
                    : preparingSkills
                      ? "Preparing in background..."
                      : `${goalSkills.length} skills linked`}
                </strong>
              </div>

              {goalSkills.length > 0 && (
                <div className="ai-skill-tags">
                  {goalSkills.map((s) => (
                    <span key={s.id} className="ai-skill-tag">
                      {s.name}
                    </span>
                  ))}
                </div>
              )}
            </div>

            <div className="ai-module-actions">
              {activeGoal ? (
                <>
                  <button
                    type="button"
                    className="btn-primary"
                    onClick={() => onNavigate?.("assessment")}
                  >
                    <IconBook width={15} height={15} />
                    Open Skill Assessment
                  </button>
                  <button
                    type="button"
                    className="btn-secondary"
                    onClick={handleRefreshGoalSkills}
                    disabled={loadingSkills}
                  >
                    <IconRefresh width={14} height={14} />
                    Refresh
                  </button>
                </>
              ) : (
                <button
                  type="button"
                  className="btn-primary"
                  onClick={() => onNavigate?.("goals")}
                >
                  <IconTarget width={15} height={15} />
                  Create a Goal
                </button>
              )}
            </div>
          </article>

          {/* Active Module 2: Adaptive Daily Plan Generator */}
          <article className="ai-module-card active-module">
            <div className="ai-module-top">
              <div className="ai-module-icon mint">
                <IconBolt width={20} height={20} />
              </div>
              <Badge variant="mint">Connected &amp; Active</Badge>
            </div>

            <h3>Skill-Gap Daily Plan Generator &amp; Difficulty Calibration</h3>
            <p>
              Combines your latest energy check-in, historical skip rate, daily available minutes, and skill-gap roadmap to build a realistic daily task schedule (`POST /tasks/generate-daily-plan`).
            </p>

            <div className="ai-module-live-box">
              <div className="ai-live-row">
                <span>Current Energy Signal:</span>
                <strong>{formatEnergyLabel(advice?.latest_energy)}</strong>
              </div>
              <div className="ai-live-row">
                <span>Historical Skip Rate:</span>
                <strong>
                  {advice?.skip_rate_percentage != null
                    ? `${advice.skip_rate_percentage}%`
                    : "0%"}
                </strong>
              </div>
              <div className="ai-live-row">
                <span>Calibrated Difficulty:</span>
                <Badge variant="primary">
                  {advice?.recommended_difficulty || "medium"}
                </Badge>
              </div>
              {advice?.explanation && (
                <p className="ai-live-note">{advice.explanation}</p>
              )}
            </div>

            {lastPlanResult && (
              <div className="ai-plan-result-banner" role="status">
                <IconCheck width={15} height={15} />
                <span>
                  Created {lastPlanResult.tasks_created?.length || 0} task(s) (
                  {lastPlanResult.planned_minutes || 0} min total).
                </span>
              </div>
            )}

            <div className="ai-module-actions">
              <button
                type="button"
                className="btn-primary"
                onClick={handleGenerateDailyPlan}
                disabled={generatingPlan || !activeGoal}
              >
                <IconSpark width={15} height={15} />
                {generatingPlan ? "Generating..." : "Generate Today's Plan"}
              </button>
              <button
                type="button"
                className="btn-secondary"
                onClick={() => onNavigate?.("tasks")}
              >
                <IconCalendar width={15} height={15} />
                View Planner
              </button>
            </div>
          </article>

          {/* Active Module 3: Personal ML Task Completion Predictor */}
          <article className="ai-module-card active-module">
            <div className="ai-module-top">
              <div className="ai-module-icon blue">
                <IconChart width={20} height={20} />
              </div>
              <Badge variant="mint">Connected &amp; Active</Badge>
            </div>

            <h3>Personal ML Task Completion Predictor (LogisticRegression)</h3>
            <p>
              Trains a user-local <code>scikit-learn</code> LogisticRegression pipeline on your historical task outcomes (<code>completed</code> vs <code>skipped</code>) across 9 behavioral features to estimate completion likelihood for pending tasks.
            </p>

            <div className="ai-module-live-box">
              {pendingTasks.length === 0 ? (
                <p className="ai-live-note">
                  No pending tasks right now. Add a task on the Daily Planner to inspect its live ML completion prediction.
                </p>
              ) : (
                <>
                  <label className="form-field">
                    <span>Inspect pending task prediction:</span>
                    <select
                      className="select-compact"
                      value={effectiveTaskId}
                      onChange={(e) => setSelectedTaskId(e.target.value)}
                    >
                      {pendingTasks.map((t) => (
                        <option key={t.id} value={t.id}>
                          {t.title} ({t.estimated_minutes || 30}m · {t.difficulty})
                        </option>
                      ))}
                    </select>
                  </label>

                  {loadingPrediction ? (
                    <p className="ai-live-note">Running model inference…</p>
                  ) : predictionData?.status === "ok" ? (
                    <div className="ai-pred-details">
                      <div className="ai-live-row">
                        <span>Predicted Status:</span>
                        <Badge
                          variant={
                            predictionData.completion_probability >= 0.5
                              ? "mint"
                              : "warning"
                          }
                        >
                          {predictionData.predicted_status} (
                          {Math.round(predictionData.completion_probability * 100)}%)
                        </Badge>
                      </div>
                      <div className="ai-live-row">
                        <span>Training Examples:</span>
                        <strong>
                          {predictionData.training_examples} logs (
                          {predictionData.class_counts?.completed || 0} completed,{" "}
                          {predictionData.class_counts?.skipped || 0} skipped)
                        </strong>
                      </div>
                      {predictionData.evaluation_metrics && (
                        <div className="ai-live-row">
                          <span>Holdout Accuracy:</span>
                          <strong>
                            {Math.round(
                              predictionData.evaluation_metrics.accuracy * 100
                            )}
                            % (ROC AUC: {predictionData.evaluation_metrics.roc_auc})
                          </strong>
                        </div>
                      )}
                    </div>
                  ) : (
                    <p className="ai-live-note">
                      {predictionData?.message ||
                        "Requires at least 6 logged task outcomes (both completed and skipped) to activate."}
                      {predictionData?.training_examples != null &&
                        ` Currently recorded: ${predictionData.training_examples}/6 logs.`}
                    </p>
                  )}
                </>
              )}
            </div>

            <div className="ai-module-actions">
              <button
                type="button"
                className="btn-secondary"
                onClick={() => onNavigate?.("tasks")}
              >
                Inspect on Daily Planner
              </button>
            </div>
          </article>
        </div>
      </section>

      {/* Section 3: Planned Modules (Transparently Labeled as Coming Soon) */}
      <section className="page-section">
        <SectionHeader
          kicker="Roadmap & Future Capabilities"
          title="Planned AI Modules (Coming Soon)"
          description="The following features are part of the long-term GrowthAI roadmap and do not yet have active backend endpoints. No simulated or fake AI responses are shown."
        />

        <div className="ai-modules-grid">
          <article className="ai-module-card planned-module">
            <div className="ai-module-top">
              <div className="ai-module-icon muted">
                <IconCalendar width={20} height={20} />
              </div>
              <Badge variant="neutral">Coming Soon</Badge>
            </div>
            <h3>Weekly AI Reflection &amp; Synthesis</h3>
            <p>
              Automated end-of-week narrative reviews summarizing your study hours, assessment gains, and procrastination triggers.
            </p>
            <div className="planned-status-note">
              <IconInfo width={15} height={15} />
              <span>Awaiting weekly reflection service in the backend.</span>
            </div>
          </article>

          <article className="ai-module-card planned-module">
            <div className="ai-module-top">
              <div className="ai-module-icon muted">
                <IconTarget width={20} height={20} />
              </div>
              <Badge variant="neutral">Coming Soon</Badge>
            </div>
            <h3>Reinforcement-Learned Planning Policy</h3>
            <p>
              Currently, daily task difficulty uses a transparent rule-based heuristic based on energy and skip rate. A learned scheduling policy is planned for a future phase.
            </p>
            <div className="planned-status-note">
              <IconInfo width={15} height={15} />
              <span>Rule-based adaptive heuristic is currently active instead.</span>
            </div>
          </article>
        </div>
      </section>
    </div>
  );
}
