import { useCallback, useEffect, useRef, useState } from "react";
import { api, errorMessage } from "../api/client";
import { Badge, EmptyState, ProgressBar, SectionHeader } from "../components/ui";
import {
  IconArrow,
  IconAward,
  IconBook,
  IconCalendar,
  IconCheck,
  IconChevronRight,
  IconClock,
  IconInfo,
  IconMap,
  IconPlay,
  IconPlus,
  IconRefresh,
  IconSpark,
  IconTarget,
} from "../components/icons";
import { getTodayLocal } from "../utils/format";

const SKILL_TO_STAGES = {
  excel: [1, 2],
  statistics: [3],
  sql: [4],
  python: [5, 6],
  "data visualization": [7, 8],
};

function getLinkedStageNumbers(skillName) {
  if (!skillName) return [];
  const lower = String(skillName).trim().toLowerCase();
  if (SKILL_TO_STAGES[lower]) return SKILL_TO_STAGES[lower];
  for (const [key, stages] of Object.entries(SKILL_TO_STAGES)) {
    if (lower.includes(key) || key.includes(lower)) return stages;
  }
  return [];
}

function formatTopicStatusLabel(status) {
  if (status === "completed") return "Completed";
  if (status === "in_progress") return "In Progress";
  return "Not Started";
}

function getTopicStatusVariant(status) {
  if (status === "completed") return "mint";
  if (status === "in_progress") return "primary";
  return "neutral";
}

export default function RoadmapPage({
  activeGoal,
  goals = [],
  onSelectGoal,
  onNavigate,
  onTaskAdded,
  notify,
}) {
  const [roadmap, setRoadmap] = useState([]);
  const [skillGaps, setSkillGaps] = useState([]);
  const [curriculum, setCurriculum] = useState(null);
  const [loading, setLoading] = useState(false);
  const [creatingTaskForSkill, setCreatingTaskForSkill] = useState(null);
  const [generatingPlan, setGeneratingPlan] = useState(false);

  // Curriculum & Topic Lesson View state
  const [expandedStages, setExpandedStages] = useState({ 1: true });
  const [selectedTopicId, setSelectedTopicId] = useState(null);
  const [topicDetail, setTopicDetail] = useState(null);
  const [loadingTopic, setLoadingTopic] = useState(false);
  const [topicError, setTopicError] = useState("");
  const [updatingProgress, setUpdatingProgress] = useState(false);
  const [regeneratingLesson, setRegeneratingLesson] = useState(false);
  const [showPracticeHint, setShowPracticeHint] = useState(false);
  const [quizAnswers, setQuizAnswers] = useState({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);

  const stageRefs = useRef({});
  const lessonTopRef = useRef(null);

  const activeGoalId = activeGoal?.id || null;

  const loadRoadmapData = useCallback(async () => {
    await Promise.resolve();
    setSelectedTopicId(null);
    setTopicDetail(null);
    if (!activeGoalId) {
      setRoadmap([]);
      setSkillGaps([]);
      setCurriculum(null);
      return;
    }

    setLoading(true);
    try {
      const [roadmapRes, gapsRes, curriculumRes] = await Promise.all([
        api.getRoadmap(activeGoalId),
        api.getSkillGaps(activeGoalId),
        api.getGoalCurriculum(activeGoalId),
      ]);

      if (roadmapRes.ok) {
        setRoadmap(roadmapRes.data?.roadmap || []);
      } else {
        notify?.("error", errorMessage(roadmapRes.data, "Could not load skill roadmap."));
      }

      if (gapsRes.ok) {
        setSkillGaps(gapsRes.data?.skills || []);
      }

      if (curriculumRes.ok && curriculumRes.data?.supported) {
        const currData = curriculumRes.data;
        setCurriculum(currData);
        // Automatically expand Stage 1 and any priority skill-gap stage on first load
        setExpandedStages((prev) => {
          const next = { ...prev, 1: true };
          for (const st of currData.stages || []) {
            if (st.skill_assessment?.is_priority) {
              next[st.stage_number] = true;
            }
          }
          return next;
        });
      } else {
        setCurriculum(null);
        setSelectedTopicId(null);
        setTopicDetail(null);
      }
    } catch {
      notify?.("error", "Could not connect to the GrowthAI server.");
    } finally {
      setLoading(false);
    }
  }, [activeGoalId, notify]);

  useEffect(() => {
    Promise.resolve().then(() => loadRoadmapData());
  }, [loadRoadmapData]);

  const refreshCurriculumQuietly = useCallback(async () => {
    if (!activeGoalId) return;
    try {
      const res = await api.getGoalCurriculum(activeGoalId);
      if (res.ok && res.data?.supported) {
        setCurriculum(res.data);
      }
    } catch {
      /* ignore background refresh errors */
    }
  }, [activeGoalId]);

  const openTopicLesson = useCallback(
    async (topicId, { markStartedIfNew = false } = {}) => {
      if (!activeGoalId || !topicId) return;
      setSelectedTopicId(topicId);
      setLoadingTopic(true);
      setTopicError("");
      setShowPracticeHint(false);
      setQuizAnswers({});
      setQuizSubmitted(false);

      setTimeout(() => {
        lessonTopRef.current?.scrollIntoView?.({ behavior: "smooth", block: "start" });
      }, 40);

      try {
        const res = await api.getGoalCurriculumTopic(activeGoalId, topicId);
        if (!res.ok) {
          const msg = errorMessage(res.data, "Could not load topic lesson content.");
          setTopicError(msg);
          notify?.("error", msg);
          return;
        }

        let detail = res.data;
        if (markStartedIfNew && detail?.topic?.status === "not_started") {
          const progRes = await api.updateGoalCurriculumTopicProgress(
            activeGoalId,
            topicId,
            { status: "in_progress" }
          );
          if (progRes.ok && progRes.data) {
            detail = {
              ...detail,
              topic: {
                ...detail.topic,
                status: progRes.data.status || "in_progress",
                started_at: progRes.data.started_at,
              },
            };
            refreshCurriculumQuietly();
          }
        }
        setTopicDetail(detail);
      } catch {
        const msg = "Could not connect to the GrowthAI server.";
        setTopicError(msg);
        notify?.("error", msg);
      } finally {
        setLoadingTopic(false);
      }
    },
    [activeGoalId, notify, refreshCurriculumQuietly]
  );

  const handleUpdateTopicStatus = async (newStatus, explicitQuizScore = null) => {
    if (!activeGoalId || !topicDetail?.topic?.id || updatingProgress) return;
    const topicId = topicDetail.topic.id;
    setUpdatingProgress(true);
    try {
      const { ok, data } = await api.updateGoalCurriculumTopicProgress(
        activeGoalId,
        topicId,
        {
          status: newStatus,
          quiz_score: explicitQuizScore,
        }
      );

      if (!ok) {
        notify?.("error", errorMessage(data, "Could not save topic progress."));
        return;
      }

      setTopicDetail((prev) =>
        prev
          ? {
              ...prev,
              topic: {
                ...prev.topic,
                status: data.status,
                quiz_score:
                  data.quiz_score !== undefined ? data.quiz_score : prev.topic.quiz_score,
                started_at: data.started_at,
                completed_at: data.completed_at,
              },
            }
          : prev
      );

      await refreshCurriculumQuietly();

      if (newStatus === "completed") {
        notify?.(
          "success",
          `Marked "${topicDetail.topic.title}" complete (${data.overall_progress?.label || "saved"}).`
        );
      } else if (newStatus === "in_progress") {
        notify?.("info", `Marked "${topicDetail.topic.title}" as In Progress.`);
      } else {
        notify?.("info", `Reset "${topicDetail.topic.title}" to Not Started.`);
      }
    } catch {
      notify?.("error", "Could not connect to the GrowthAI server.");
    } finally {
      setUpdatingProgress(false);
    }
  };

  const handleRegenerateLessonWithGemini = async () => {
    if (!activeGoalId || !topicDetail?.topic?.id || regeneratingLesson) return;
    setRegeneratingLesson(true);
    try {
      const { ok, data } = await api.generateGoalCurriculumTopicLesson(
        activeGoalId,
        topicDetail.topic.id,
        true
      );
      if (!ok) {
        notify?.("error", errorMessage(data, "Could not generate lesson content."));
        return;
      }
      setTopicDetail(data);
      notify?.("success", "Lesson content refreshed and saved.");
    } catch {
      notify?.("error", "Could not connect to the GrowthAI server.");
    } finally {
      setRegeneratingLesson(false);
    }
  };

  const handleViewMilestoneTopics = (skillName) => {
    const stageNums = getLinkedStageNumbers(skillName);
    const targetStage = stageNums[0] || 1;
    setSelectedTopicId(null);
    setTopicDetail(null);
    setExpandedStages((prev) => {
      const next = { ...prev };
      stageNums.forEach((n) => {
        next[n] = true;
      });
      next[targetStage] = true;
      return next;
    });
    setTimeout(() => {
      stageRefs.current[targetStage]?.scrollIntoView?.({
        behavior: "smooth",
        block: "start",
      });
    }, 60);
  };

  const handleStartMilestoneLearning = (skillName) => {
    if (!curriculum?.stages) return;
    const stageNums = getLinkedStageNumbers(skillName);
    const targetStageNum = stageNums[0] || 1;
    const stageObj =
      curriculum.stages.find((s) => stageNums.includes(s.stage_number)) ||
      curriculum.stages[0];
    if (!stageObj || !stageObj.topics?.length) {
      handleViewMilestoneTopics(skillName);
      return;
    }
    setExpandedStages((prev) => ({ ...prev, [targetStageNum]: true }));
    const firstUnfinished =
      stageObj.topics.find((t) => t.status !== "completed") || stageObj.topics[0];
    openTopicLesson(firstUnfinished.id, { markStartedIfNew: true });
  };

  const toggleStage = (stageNumber) => {
    setExpandedStages((prev) => ({
      ...prev,
      [stageNumber]: !prev[stageNumber],
    }));
  };

  const handleScheduleMilestoneTask = async (milestone) => {
    if (!activeGoal?.id || creatingTaskForSkill === milestone.skill_id) return;

    setCreatingTaskForSkill(milestone.skill_id);
    try {
      const taskTitle =
        milestone.gap_status === "not_assessed"
          ? `Explore ${milestone.name} fundamentals and note key concepts`
          : milestone.gap_status === "gap"
            ? `Focused practice session: ${milestone.name}`
            : `Light review & consolidation: ${milestone.name}`;

      const difficulty =
        milestone.skill_level === "beginner"
          ? "easy"
          : milestone.skill_level === "intermediate"
            ? "medium"
            : "medium";

      const { ok, data } = await api.createTask({
        goal_id: activeGoal.id,
        title: taskTitle,
        description:
          milestone.recommendation ||
          `Roadmap step ${milestone.step} for ${activeGoal.title}`,
        estimated_minutes: 30,
        difficulty,
        scheduled_date: getTodayLocal(),
      });

      if (!ok) {
        notify?.("error", errorMessage(data, "Could not add task to planner."));
        return;
      }

      notify?.("success", `Added "${taskTitle}" to today's planner.`);
      onTaskAdded?.(data.task);
    } catch {
      notify?.("error", "Could not connect to the GrowthAI server.");
    } finally {
      setCreatingTaskForSkill(null);
    }
  };

  const handleGenerateDailyPlan = async () => {
    if (!activeGoal?.id) return;
    setGeneratingPlan(true);
    try {
      const { ok, data } = await api.generateDailyPlan();
      if (!ok) {
        notify?.("error", errorMessage(data, "Could not generate daily plan."));
        return;
      }
      const createdCount = data?.tasks_created?.length || 0;
      notify?.(
        "success",
        createdCount > 0
          ? `Generated ${createdCount} study task${createdCount === 1 ? "" : "s"} from your roadmap.`
          : "Your daily study budget is already full for today."
      );
      onTaskAdded?.();
    } catch {
      notify?.("error", "Could not connect to the GrowthAI server.");
    } finally {
      setGeneratingPlan(false);
    }
  };

  if (!activeGoal) {
    return (
      <section className="page-section">
        <EmptyState
          Icon={IconMap}
          title="No active goal selected"
          description="Choose or create a learning goal first so GrowthAI can sequence your skill milestones and next steps."
          action={
            <button
              type="button"
              className="btn-primary"
              onClick={() => onNavigate?.("goals")}
            >
              <IconTarget width={15} height={15} />
              Go to Goals &amp; Skills
            </button>
          }
        />
      </section>
    );
  }

  const gapBySkillId = new Map(skillGaps.map((g) => [g.skill_id, g]));
  const hasDataAnalystCurriculum = Boolean(curriculum?.supported);

  // Determine the single "current focus" milestone (first non-strong milestone in the sorted roadmap)
  const firstActiveMilestone =
    roadmap.find((item) => item.gap_status !== "strong") || roadmap[0] || null;

  const masteredCount = roadmap.filter((i) => i.gap_status === "strong").length;
  const gapCount = roadmap.filter((i) => i.gap_status === "gap").length;
  const unassessedCount = roadmap.filter((i) => i.gap_status === "not_assessed").length;
  const overallProgressPercent =
    roadmap.length > 0 ? Math.round((masteredCount / roadmap.length) * 100) : 0;

  // Compute quiz score if quiz is submitted in Topic Lesson View
  const quizItems = topicDetail?.lesson?.quiz || [];
  let computedQuizScore = null;
  let correctQuizCount = 0;
  if (quizItems.length > 0) {
    quizItems.forEach((q, idx) => {
      if (quizAnswers[idx] === q.correct_index) {
        correctQuizCount += 1;
      }
    });
    if (quizSubmitted) {
      computedQuizScore = Math.round((correctQuizCount / quizItems.length) * 100);
    }
  }

  return (
    <div className="page-stack" ref={lessonTopRef}>
      {/* Active Topic Lesson View (when a Data Analyst curriculum topic is open) */}
      {hasDataAnalystCurriculum && selectedTopicId && (
        <section className="page-section curriculum-lesson-section">
          <div className="lesson-topbar">
            <button
              type="button"
              className="btn-secondary"
              onClick={() => {
                setSelectedTopicId(null);
                setTopicDetail(null);
                setTopicError("");
              }}
            >
              ← Back to All Stages &amp; Roadmap
            </button>

            <div className="lesson-nav-buttons">
              {topicDetail?.previous_topic && (
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={() => openTopicLesson(topicDetail.previous_topic.id)}
                  disabled={loadingTopic}
                >
                  ← Prev: {topicDetail.previous_topic.title}
                </button>
              )}
              {topicDetail?.next_topic && (
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={() => openTopicLesson(topicDetail.next_topic.id)}
                  disabled={loadingTopic}
                >
                  Next: {topicDetail.next_topic.title} →
                </button>
              )}
            </div>
          </div>

          {loadingTopic ? (
            <div className="insight-card">
              <p>Loading beginner-friendly lesson, examples, practice task, and quiz…</p>
            </div>
          ) : topicError ? (
            <div className="insight-card">
              <p>{topicError}</p>
              <button
                type="button"
                className="btn-primary"
                onClick={() => openTopicLesson(selectedTopicId)}
              >
                Retry Loading Topic
              </button>
            </div>
          ) : topicDetail ? (
            <div className="lesson-detail-card">
              {/* Header */}
              <div className="lesson-header">
                <div className="lesson-header-meta">
                  <Badge variant="info">
                    Stage {topicDetail.topic.stage_number} · {topicDetail.topic.stage_title}
                  </Badge>
                  <Badge variant="neutral">
                    Topic {topicDetail.topic.topic_order} ({topicDetail.topic.skill_name})
                  </Badge>
                  <Badge variant="neutral">
                    <IconClock width={13} height={13} />{" "}
                    {topicDetail.topic.estimated_minutes} min
                  </Badge>
                  <Badge variant={getTopicStatusVariant(topicDetail.topic.status)}>
                    {formatTopicStatusLabel(topicDetail.topic.status)}
                  </Badge>
                  {topicDetail.topic.is_priority && (
                    <Badge variant="warning">Priority Skill Gap Topic</Badge>
                  )}
                  {topicDetail.topic.is_mastered_in_assessment && (
                    <Badge variant="mint">Skill Mastered in Assessment · Review</Badge>
                  )}
                </div>

                <h2>{topicDetail.topic.title}</h2>
                <p className="lesson-subtitle">{topicDetail.topic.description}</p>

                <div className="lesson-status-controls">
                  {topicDetail.topic.status !== "completed" ? (
                    <button
                      type="button"
                      className="btn-primary"
                      onClick={() =>
                        handleUpdateTopicStatus("completed", computedQuizScore)
                      }
                      disabled={updatingProgress}
                    >
                      <IconCheck width={15} height={15} />
                      {updatingProgress ? "Saving..." : "Mark Complete"}
                    </button>
                  ) : (
                    <span className="milestone-done-tag">
                      <IconCheck width={15} height={15} /> Completed &amp; Saved
                    </span>
                  )}

                  {topicDetail.topic.status === "not_started" && (
                    <button
                      type="button"
                      className="btn-secondary"
                      onClick={() => handleUpdateTopicStatus("in_progress")}
                      disabled={updatingProgress}
                    >
                      <IconPlay width={14} height={14} />
                      Mark In Progress
                    </button>
                  )}

                  {topicDetail.topic.status === "completed" && (
                    <button
                      type="button"
                      className="btn-secondary"
                      onClick={() => handleUpdateTopicStatus("in_progress")}
                      disabled={updatingProgress}
                    >
                      Reopen as In Progress
                    </button>
                  )}

                  <button
                    type="button"
                    className="btn-secondary"
                    onClick={handleRegenerateLessonWithGemini}
                    disabled={regeneratingLesson}
                  >
                    <IconSpark width={14} height={14} />
                    {regeneratingLesson
                      ? "Generating with Gemini..."
                      : "Refresh AI Lesson"}
                  </button>
                </div>
              </div>

              {/* Introduction & Learning Objectives */}
              <div className="lesson-block">
                <h3>Introduction</h3>
                <p className="lesson-prose">{topicDetail.lesson?.introduction}</p>

                {topicDetail.lesson?.learning_objectives?.length > 0 && (
                  <div className="lesson-objectives-box">
                    <h4>Learning Objectives</h4>
                    <ul className="lesson-objectives-list">
                      {topicDetail.lesson.learning_objectives.map((obj, idx) => (
                        <li key={idx}>
                          <IconCheck width={15} height={15} />
                          <span>{obj}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {/* Step-by-Step Teaching Content */}
              {topicDetail.lesson?.sections?.length > 0 && (
                <div className="lesson-block">
                  <h3>Step-by-Step Lesson Content</h3>
                  <div className="lesson-sections-stack">
                    {topicDetail.lesson.sections.map((sec, idx) => (
                      <article className="lesson-section-item" key={idx}>
                        <h4>{sec.heading}</h4>
                        <div className="lesson-prose-pre">{sec.body}</div>
                      </article>
                    ))}
                  </div>
                </div>
              )}

              {/* Code / Practical Examples & Expected Output */}
              {topicDetail.lesson?.examples?.length > 0 && (
                <div className="lesson-block">
                  <h3>Practical &amp; Code Examples</h3>
                  {topicDetail.lesson.examples.map((ex, idx) => (
                    <div className="lesson-example-card" key={idx}>
                      <div className="lesson-example-header">
                        <strong>{ex.title || "Worked Example"}</strong>
                        {ex.language && (
                          <Badge variant="neutral">
                            {String(ex.language).toUpperCase()}
                          </Badge>
                        )}
                      </div>

                      <pre className="lesson-code-block">
                        <code>{ex.code}</code>
                      </pre>

                      {ex.expected_output && (
                        <div className="lesson-output-box">
                          <span className="lesson-output-label">Expected Output:</span>
                          <pre className="lesson-output-pre">
                            <code>{ex.expected_output}</code>
                          </pre>
                        </div>
                      )}

                      {ex.explanation && (
                        <p className="lesson-example-explanation">{ex.explanation}</p>
                      )}
                    </div>
                  ))}

                  {topicDetail.lesson?.example_verification_note && (
                    <p className="lesson-verification-note">
                      <IconInfo width={14} height={14} />{" "}
                      <span>{topicDetail.lesson.example_verification_note}</span>
                    </p>
                  )}
                </div>
              )}

              {/* Practice Task */}
              {topicDetail.lesson?.practice_task && (
                <div className="lesson-block lesson-practice-box">
                  <div className="lesson-practice-header">
                    <h3>
                      {topicDetail.lesson.practice_task.title || "Hands-On Practice Task"}
                    </h3>
                    <Badge variant="primary">Practice Exercise</Badge>
                  </div>
                  <div className="lesson-prose-pre">
                    {topicDetail.lesson.practice_task.instructions}
                  </div>

                  {topicDetail.lesson.practice_task.expected_outcome && (
                    <p className="lesson-practice-outcome">
                      <strong>Expected Outcome: </strong>
                      {topicDetail.lesson.practice_task.expected_outcome}
                    </p>
                  )}

                  {topicDetail.lesson.practice_task.starter_hint && (
                    <div className="lesson-hint-area">
                      <button
                        type="button"
                        className="btn-secondary"
                        onClick={() => setShowPracticeHint((v) => !v)}
                      >
                        {showPracticeHint ? "Hide Starter Hint" : "Show Starter Hint"}
                      </button>
                      {showPracticeHint && (
                        <p className="lesson-hint-box">
                          <strong>Hint: </strong>
                          {topicDetail.lesson.practice_task.starter_hint}
                        </p>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* Short Quiz */}
              {quizItems.length > 0 && (
                <div className="lesson-block lesson-quiz-box">
                  <div className="lesson-practice-header">
                    <h3>Topic Knowledge Check Quiz</h3>
                    <Badge variant="info">{quizItems.length} Questions</Badge>
                  </div>

                  <div className="lesson-quiz-list">
                    {quizItems.map((q, qIdx) => {
                      const selectedIdx = quizAnswers[qIdx];
                      const isCorrect = selectedIdx === q.correct_index;
                      return (
                        <div className="lesson-quiz-item" key={qIdx}>
                          <p className="lesson-quiz-question">
                            <strong>Q{qIdx + 1}.</strong> {q.question}
                          </p>
                          <div className="lesson-quiz-options">
                            {(q.options || []).map((optText, oIdx) => {
                              const isChosen = selectedIdx === oIdx;
                              let optClass = "lesson-quiz-option";
                              if (isChosen) optClass += " is-selected";
                              if (quizSubmitted) {
                                if (oIdx === q.correct_index) {
                                  optClass += " is-correct";
                                } else if (isChosen) {
                                  optClass += " is-wrong";
                                }
                              }
                              return (
                                <button
                                  key={oIdx}
                                  type="button"
                                  className={optClass}
                                  onClick={() => {
                                    setQuizAnswers((prev) => ({
                                      ...prev,
                                      [qIdx]: oIdx,
                                    }));
                                  }}
                                >
                                  <span className="quiz-opt-letter">
                                    {"ABCD"[oIdx] || oIdx + 1}.
                                  </span>
                                  <span>{optText}</span>
                                </button>
                              );
                            })}
                          </div>

                          {quizSubmitted && (
                            <div
                              className={`lesson-quiz-feedback ${
                                isCorrect ? "is-correct" : "is-wrong"
                              }`}
                            >
                              <strong>
                                {isCorrect
                                  ? "Correct!"
                                  : `Correct Answer: Option ${"ABCD"[q.correct_index]}`}
                              </strong>
                              {q.explanation && <p>{q.explanation}</p>}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>

                  <div className="lesson-quiz-actions">
                    <button
                      type="button"
                      className="btn-primary"
                      onClick={() => setQuizSubmitted(true)}
                      disabled={Object.keys(quizAnswers).length === 0}
                    >
                      Check Quiz Answers
                    </button>
                    {quizSubmitted && (
                      <Badge variant={computedQuizScore >= 70 ? "mint" : "warning"}>
                        Quiz Score: {correctQuizCount} / {quizItems.length} (
                        {computedQuizScore}%)
                      </Badge>
                    )}
                  </div>
                </div>
              )}

              {/* Completion Footer & Next Topic Navigation */}
              <div className="lesson-completion-footer">
                <div>
                  <h4>Completion Criterion</h4>
                  <p>
                    {topicDetail.lesson?.completion_criterion ||
                      "Review the lesson, work through the example and practice task, and mark this topic complete."}
                  </p>
                </div>

                <div className="lesson-footer-actions">
                  {topicDetail.topic.status !== "completed" ? (
                    <button
                      type="button"
                      className="btn-primary"
                      onClick={() =>
                        handleUpdateTopicStatus("completed", computedQuizScore)
                      }
                      disabled={updatingProgress}
                    >
                      <IconCheck width={15} height={15} />
                      {updatingProgress ? "Saving..." : "Mark Topic Complete"}
                    </button>
                  ) : (
                    <Badge variant="mint">
                      <IconCheck width={14} height={14} /> Completed
                    </Badge>
                  )}

                  {topicDetail.next_topic && (
                    <button
                      type="button"
                      className="btn-secondary"
                      onClick={() =>
                        openTopicLesson(topicDetail.next_topic.id, {
                          markStartedIfNew: true,
                        })
                      }
                      disabled={loadingTopic}
                    >
                      Continue to {topicDetail.next_topic.title}{" "}
                      <IconArrow width={14} height={14} />
                    </button>
                  )}
                </div>
              </div>
            </div>
          ) : null}
        </section>
      )}

      {/* Existing Skill Roadmap & Milestones Section */}
      <section className="page-section">
        <SectionHeader
          kicker={`Learning Path · ${activeGoal.title}`}
          title="Skill Roadmap & Milestones"
          description="Your milestones are ordered automatically by skill gap priority and topic importance based on your real assessment outcomes."
          actions={
            <div className="heading-actions">
              {goals.length > 1 && onSelectGoal && (
                <select
                  className="select-compact"
                  value={activeGoal.id}
                  onChange={(e) => onSelectGoal(Number(e.target.value))}
                  aria-label="Switch goal roadmap"
                >
                  {goals.map((g) => (
                    <option key={g.id} value={g.id}>
                      {g.title}
                    </option>
                  ))}
                </select>
              )}
              <button
                type="button"
                className="btn-secondary"
                onClick={loadRoadmapData}
                disabled={loading}
              >
                <IconRefresh width={15} height={15} />
                {loading ? "Refreshing..." : "Refresh"}
              </button>
              <button
                type="button"
                className="btn-primary"
                onClick={handleGenerateDailyPlan}
                disabled={generatingPlan || roadmap.length === 0}
              >
                <IconSpark width={15} height={15} />
                {generatingPlan ? "Building Plan..." : "Build Today's Plan from Roadmap"}
              </button>
            </div>
          }
        />

        {loading ? (
          <div className="insight-card">
            <p>Loading your personalized skill roadmap…</p>
          </div>
        ) : roadmap.length === 0 ? (
          <EmptyState
            Icon={IconMap}
            title="Roadmap milestones are not ready yet"
            description="This goal doesn't have mapped skills yet, or the AI is still preparing them in the background. Open Goals & Skills to check status."
            action={
              <button
                type="button"
                className="btn-primary"
                onClick={() => onNavigate?.("goals")}
              >
                <IconTarget width={15} height={15} />
                Check Goal Skills
              </button>
            }
            secondaryAction={
              <button
                type="button"
                className="btn-secondary"
                onClick={loadRoadmapData}
              >
                <IconRefresh width={15} height={15} />
                Retry
              </button>
            }
          />
        ) : (
          <>
            {/* Recommended Next Action Banner */}
            {firstActiveMilestone && (
              <div className="roadmap-next-banner">
                <div className="roadmap-next-content">
                  <div className="roadmap-next-badges">
                    <Badge variant="primary">
                      Recommended Next Step · Milestone #{firstActiveMilestone.step}
                    </Badge>
                    <Badge
                      variant={
                        firstActiveMilestone.importance === "high"
                          ? "warning"
                          : "neutral"
                      }
                    >
                      {firstActiveMilestone.importance} importance
                    </Badge>
                  </div>
                  <h3>{firstActiveMilestone.name}</h3>
                  <p>{firstActiveMilestone.recommendation}</p>
                </div>

                <div className="roadmap-next-actions">
                  {hasDataAnalystCurriculum && (
                    <button
                      type="button"
                      className="btn-primary"
                      onClick={() =>
                        handleStartMilestoneLearning(firstActiveMilestone.name)
                      }
                    >
                      <IconPlay width={14} height={14} />
                      Start Learning
                    </button>
                  )}
                  {firstActiveMilestone.gap_status === "not_assessed" ? (
                    <button
                      type="button"
                      className={
                        hasDataAnalystCurriculum ? "btn-secondary" : "btn-primary"
                      }
                      onClick={() => onNavigate?.("assessment")}
                    >
                      <IconBook width={15} height={15} />
                      Take Skill Assessment
                    </button>
                  ) : (
                    <button
                      type="button"
                      className={
                        hasDataAnalystCurriculum ? "btn-secondary" : "btn-primary"
                      }
                      onClick={() => handleScheduleMilestoneTask(firstActiveMilestone)}
                      disabled={creatingTaskForSkill === firstActiveMilestone.skill_id}
                    >
                      <IconPlus width={15} height={15} />
                      {creatingTaskForSkill === firstActiveMilestone.skill_id
                        ? "Adding..."
                        : "Add Practice Task to Today"}
                    </button>
                  )}
                  <button
                    type="button"
                    className="btn-secondary"
                    onClick={() => onNavigate?.("tasks")}
                  >
                    <IconCalendar width={15} height={15} />
                    Open Planner
                  </button>
                </div>
              </div>
            )}

            {/* Summary Progress Bar */}
            <div className="roadmap-summary-card">
              <div className="roadmap-summary-counts">
                <div>
                  <span>Total Milestones</span>
                  <strong>{roadmap.length}</strong>
                </div>
                <div>
                  <span>Active Skill Gaps</span>
                  <strong className="text-warning">{gapCount}</strong>
                </div>
                <div>
                  <span>Needs Assessment</span>
                  <strong>{unassessedCount}</strong>
                </div>
                <div>
                  <span>Mastered (Strong)</span>
                  <strong className="text-mint">{masteredCount}</strong>
                </div>
              </div>
              <ProgressBar
                value={overallProgressPercent}
                variant="mint"
                label={`Overall Milestone Mastery (${masteredCount} of ${roadmap.length} skills at Advanced level)`}
                showValue
              />
            </div>

            {/* Visual Legend */}
            <div className="roadmap-legend">
              <span className="legend-item">
                <span className="legend-dot current" /> Current Priority (Skill Gap)
              </span>
              <span className="legend-item">
                <span className="legend-dot upcoming" /> Diagnostic Needed (Unassessed)
              </span>
              <span className="legend-item">
                <span className="legend-dot completed" /> Completed / Strong (70%+)
              </span>
            </div>

            {/* Step-by-Step Timeline */}
            <div className="roadmap-timeline">
              {roadmap.map((item) => {
                const gapInfo = gapBySkillId.get(item.skill_id);
                const score =
                  gapInfo?.score_percentage != null
                    ? Math.round(Number(gapInfo.score_percentage))
                    : null;
                const isCompleted = item.gap_status === "strong";
                const isCurrentFocus =
                  firstActiveMilestone?.skill_id === item.skill_id && !isCompleted;
                const stateClass = isCompleted
                  ? "milestone-completed"
                  : isCurrentFocus
                    ? "milestone-current"
                    : item.gap_status === "gap"
                      ? "milestone-gap"
                      : "milestone-upcoming";

                const linkedStages = hasDataAnalystCurriculum
                  ? getLinkedStageNumbers(item.name)
                  : [];

                return (
                  <div className={`roadmap-step-card ${stateClass}`} key={item.skill_id}>
                    <div className="roadmap-step-marker">
                      <div className="roadmap-step-circle">
                        {isCompleted ? (
                          <IconCheck width={16} height={16} />
                        ) : (
                          <span>{item.step}</span>
                        )}
                      </div>
                      <div className="roadmap-step-line" />
                    </div>

                    <div className="roadmap-step-body">
                      <div className="roadmap-step-header">
                        <div>
                          <span className="skill-category-label">
                            Step {item.step} · {item.category || "Core Skill"}
                          </span>
                          <h4>{item.name}</h4>
                        </div>

                        <div className="roadmap-step-badges">
                          {isCurrentFocus && (
                            <Badge variant="primary">Current Priority</Badge>
                          )}
                          <Badge
                            variant={
                              isCompleted
                                ? "mint"
                                : item.gap_status === "gap"
                                  ? "warning"
                                  : "neutral"
                            }
                          >
                            {isCompleted
                              ? "Mastered"
                              : item.gap_status === "gap"
                                ? `Skill Gap (${item.skill_level})`
                                : "Unassessed"}
                          </Badge>
                          <Badge
                            variant={
                              item.importance === "high" ? "info" : "neutral"
                            }
                          >
                            {item.importance} importance
                          </Badge>
                        </div>
                      </div>

                      <p className="roadmap-step-rec">{item.recommendation}</p>

                      {score != null && (
                        <div className="roadmap-step-progress">
                          <ProgressBar
                            value={score}
                            variant={isCompleted ? "mint" : "primary"}
                            label={`Latest assessment score: ${score}% (${item.skill_level})`}
                            showValue
                            size="sm"
                          />
                        </div>
                      )}

                      <div className="roadmap-step-actions">
                        {hasDataAnalystCurriculum && linkedStages.length > 0 && (
                          <>
                            <button
                              type="button"
                              className="btn-primary"
                              onClick={() => handleStartMilestoneLearning(item.name)}
                            >
                              <IconPlay width={13} height={13} />
                              Start Learning
                            </button>
                            <button
                              type="button"
                              className="btn-secondary"
                              onClick={() => handleViewMilestoneTopics(item.name)}
                            >
                              <IconBook width={14} height={14} />
                              View Topics (Stage{" "}
                              {linkedStages.length > 1
                                ? `${linkedStages[0]} & ${linkedStages[1]}`
                                : linkedStages[0]}
                              )
                            </button>
                          </>
                        )}

                        {item.gap_status === "not_assessed" ? (
                          <button
                            type="button"
                            className="btn-secondary"
                            onClick={() => onNavigate?.("assessment")}
                          >
                            <IconBook width={14} height={14} />
                            Assess {item.name}
                          </button>
                        ) : (
                          <button
                            type="button"
                            className="btn-secondary"
                            onClick={() => handleScheduleMilestoneTask(item)}
                            disabled={creatingTaskForSkill === item.skill_id}
                          >
                            <IconPlus width={14} height={14} />
                            {creatingTaskForSkill === item.skill_id
                              ? "Scheduling..."
                              : isCompleted
                                ? "Schedule Light Review"
                                : "Add Practice Task"}
                          </button>
                        )}

                        {isCompleted && (
                          <span className="milestone-done-tag">
                            <IconAward width={15} height={15} /> Target level met
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}
      </section>

      {/* Data Analyst Ordered Curriculum & Detailed Learning Topics (Exclusively for Data Analyst Goal) */}
      {hasDataAnalystCurriculum && (
        <section className="page-section">
          <SectionHeader
            kicker="Structured Learning Curriculum · Become a Data Analyst"
            title="Detailed Learning Stages & Ordered Topics"
            description="Progress from complete beginner foundations in Stage 1 through Excel, Statistics, PostgreSQL, Python, Pandas, Data Visualization, and Real-World Projects. Your skill assessment automatically highlights priority stages."
            actions={
              <div className="heading-actions">
                {curriculum.summary?.beginner_start_topic && (
                  <button
                    type="button"
                    className="btn-secondary"
                    onClick={() =>
                      openTopicLesson(curriculum.summary.beginner_start_topic.id, {
                        markStartedIfNew: true,
                      })
                    }
                  >
                    <IconBook width={15} height={15} />
                    Start from Stage 1 (Beginner)
                  </button>
                )}
                {curriculum.summary?.next_recommended_topic && (
                  <button
                    type="button"
                    className="btn-primary"
                    onClick={() =>
                      openTopicLesson(curriculum.summary.next_recommended_topic.id, {
                        markStartedIfNew: true,
                      })
                    }
                  >
                    <IconPlay width={14} height={14} />
                    Continue: {curriculum.summary.next_recommended_topic.title}
                  </button>
                )}
              </div>
            }
          />

          {/* Overall Curriculum Progress Summary */}
          <div className="roadmap-summary-card curriculum-overview-card">
            <div className="roadmap-summary-counts">
              <div>
                <span>Learning Stages</span>
                <strong>{curriculum.summary?.total_stages || 8}</strong>
              </div>
              <div>
                <span>Completed Topics</span>
                <strong className="text-mint">
                  {curriculum.summary?.completed_topics || 0} of{" "}
                  {curriculum.summary?.total_topics || 65}
                </strong>
              </div>
              <div>
                <span>In Progress</span>
                <strong>{curriculum.summary?.in_progress_topics || 0}</strong>
              </div>
              <div>
                <span>Priority Skill Gaps</span>
                <strong className="text-warning">
                  {curriculum.summary?.priority_skills?.length > 0
                    ? curriculum.summary.priority_skills.join(", ")
                    : "None (Start at Stage 1)"}
                </strong>
              </div>
            </div>
            <ProgressBar
              value={curriculum.summary?.progress_percentage || 0}
              variant="mint"
              label={`Saved Curriculum Progress: ${
                curriculum.summary?.progress_label || "0 of 65 topics completed"
              }`}
              showValue
            />
          </div>

          {/* 8 Ordered Stages */}
          <div className="curriculum-stages-stack">
            {(curriculum.stages || []).map((stage) => {
              const isExpanded = Boolean(expandedStages[stage.stage_number]);
              const isPriorityStage = Boolean(stage.skill_assessment?.is_priority);
              const isMasteredStage = Boolean(
                stage.skill_assessment?.is_mastered_in_assessment
              );
              const firstUnfinishedTopic =
                stage.topics?.find((t) => t.status !== "completed") ||
                stage.topics?.[0];

              return (
                <article
                  key={stage.id}
                  ref={(el) => {
                    stageRefs.current[stage.stage_number] = el;
                  }}
                  className={`curriculum-stage-card ${
                    isPriorityStage ? "is-priority-stage" : ""
                  }`}
                >
                  <div className="curriculum-stage-header">
                    <div className="curriculum-stage-title-group">
                      <div className="curriculum-stage-badges">
                        <Badge variant="primary">Stage {stage.stage_number}</Badge>
                        <Badge variant="neutral">{stage.skill_name}</Badge>
                        <Badge
                          variant={
                            isPriorityStage
                              ? "warning"
                              : isMasteredStage
                                ? "mint"
                                : "info"
                          }
                        >
                          {stage.skill_assessment?.recommendation_badge ||
                            "Ordered Stage"}
                        </Badge>
                        <Badge
                          variant={
                            stage.progress?.completed_topics ===
                            stage.progress?.total_topics
                              ? "mint"
                              : "neutral"
                          }
                        >
                          {stage.progress?.label}
                        </Badge>
                      </div>
                      <h3>
                        Stage {stage.stage_number} — {stage.title}
                      </h3>
                      <p>{stage.description}</p>
                    </div>

                    <div className="curriculum-stage-actions">
                      {firstUnfinishedTopic && (
                        <button
                          type="button"
                          className="btn-primary"
                          onClick={() =>
                            openTopicLesson(firstUnfinishedTopic.id, {
                              markStartedIfNew: true,
                            })
                          }
                        >
                          <IconPlay width={13} height={13} />
                          {stage.progress?.completed_topics > 0 &&
                          stage.progress?.completed_topics <
                            stage.progress?.total_topics
                            ? "Continue Stage"
                            : stage.progress?.completed_topics ===
                                stage.progress?.total_topics
                              ? "Review Stage"
                              : "Start Learning"}
                        </button>
                      )}
                      <button
                        type="button"
                        className="btn-secondary"
                        onClick={() => toggleStage(stage.stage_number)}
                        aria-expanded={isExpanded}
                      >
                        {isExpanded ? "Hide Topics" : "View Topics"} (
                        {stage.progress?.total_topics || 0})
                      </button>
                    </div>
                  </div>

                  <div className="curriculum-stage-progress-row">
                    <ProgressBar
                      value={stage.progress?.progress_percentage || 0}
                      variant={
                        stage.progress?.completed_topics ===
                        stage.progress?.total_topics
                          ? "mint"
                          : "primary"
                      }
                      label={stage.progress?.label}
                      showValue
                      size="sm"
                    />
                  </div>

                  {isExpanded && (
                    <div className="curriculum-topics-list">
                      {(stage.topics || []).map((topic) => {
                        const isSelected = selectedTopicId === topic.id;
                        return (
                          <div
                            key={topic.id}
                            className={`curriculum-topic-row ${
                              topic.status === "completed"
                                ? "is-completed"
                                : topic.status === "in_progress"
                                  ? "is-in-progress"
                                  : ""
                            } ${isSelected ? "is-selected" : ""}`}
                          >
                            <div className="curriculum-topic-order">
                              {topic.status === "completed" ? (
                                <span className="topic-order-check">
                                  <IconCheck width={14} height={14} />
                                </span>
                              ) : (
                                <span className="topic-order-num">
                                  {stage.stage_number}.{topic.topic_order}
                                </span>
                              )}
                            </div>

                            <div className="curriculum-topic-main">
                              <div className="curriculum-topic-title-line">
                                <h4>{topic.title}</h4>
                                <div className="curriculum-topic-badges">
                                  {topic.is_priority && (
                                    <Badge variant="warning">Priority Focus</Badge>
                                  )}
                                  {topic.is_mastered_in_assessment &&
                                    topic.status !== "completed" && (
                                      <Badge variant="mint">
                                        Assessment Mastered · Review
                                      </Badge>
                                    )}
                                  <Badge variant="neutral">
                                    <IconClock width={12} height={12} />{" "}
                                    {topic.estimated_minutes}m
                                  </Badge>
                                  <Badge
                                    variant={getTopicStatusVariant(topic.status)}
                                  >
                                    {formatTopicStatusLabel(topic.status)}
                                  </Badge>
                                </div>
                              </div>
                              <p>{topic.description}</p>
                            </div>

                            <div className="curriculum-topic-cta">
                              <button
                                type="button"
                                className={
                                  topic.status === "completed"
                                    ? "btn-secondary"
                                    : "btn-primary"
                                }
                                onClick={() =>
                                  openTopicLesson(topic.id, {
                                    markStartedIfNew: true,
                                  })
                                }
                              >
                                {topic.status === "completed"
                                  ? "Review Lesson"
                                  : topic.status === "in_progress"
                                    ? "Continue Lesson"
                                    : "Start Topic"}
                                <IconChevronRight width={14} height={14} />
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </article>
              );
            })}
          </div>
        </section>
      )}
    </div>
  );
}
