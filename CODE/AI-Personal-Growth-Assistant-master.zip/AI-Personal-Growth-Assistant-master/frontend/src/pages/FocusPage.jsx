import { useEffect, useState } from "react";
import { api, errorMessage } from "../api/client";
import ProgressRing from "../components/ProgressRing";
import { Badge, SectionHeader } from "../components/ui";
import {
  IconCalendar,
  IconCheck,
  IconClock,
  IconInfo,
  IconPause,
  IconPlay,
  IconReset,
  IconTarget,
} from "../components/icons";

const PRESET_MINUTES = [15, 25, 30, 45, 60];

export default function FocusPage({
  todayTasks = [],
  allTasks = [],
  initialTask = null,
  activeGoal,
  notify,
  onTaskUpdated,
  onNavigate,
}) {
  const pendingTasks = (allTasks.length > 0 ? allTasks : todayTasks).filter(
    (t) => String(t.status || "pending").toLowerCase() === "pending"
  );

  const [selectedTaskId, setSelectedTaskId] = useState(() => {
    if (initialTask?.id) return String(initialTask.id);
    if (pendingTasks[0]?.id) return String(pendingTasks[0].id);
    return "";
  });

  const selectedTask =
    (allTasks.length > 0 ? allTasks : todayTasks).find(
      (t) => String(t.id) === String(selectedTaskId)
    ) || null;

  const [durationMinutes, setDurationMinutes] = useState(() =>
    initialTask?.estimated_minutes
      ? Number(initialTask.estimated_minutes)
      : pendingTasks[0]?.estimated_minutes
        ? Number(pendingTasks[0].estimated_minutes)
        : 25
  );
  const [secondsLeft, setSecondsLeft] = useState(() => durationMinutes * 60);
  const [status, setStatus] = useState("idle"); // "idle" | "running" | "paused" | "finished"
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [sessionNotes, setSessionNotes] = useState("");
  const [savingSession, setSavingSession] = useState(false);
  const [savedLogRecord, setSavedLogRecord] = useState(null);
  const [zenMode, setZenMode] = useState(false);

  // Countdown tick
  useEffect(() => {
    if (status !== "running") return undefined;

    const interval = setInterval(() => {
      setElapsedSeconds((prev) => prev + 1);
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          setStatus("finished");
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [status]);

  const handleTaskChange = (nextId) => {
    setSelectedTaskId(nextId);
    setSavedLogRecord(null);
    const found = (allTasks.length > 0 ? allTasks : todayTasks).find(
      (t) => String(t.id) === String(nextId)
    );
    if (found && status === "idle") {
      const mins = Number(found.estimated_minutes) || 25;
      setDurationMinutes(mins);
      setSecondsLeft(mins * 60);
      setElapsedSeconds(0);
    }
  };

  const handlePresetSelect = (mins) => {
    if (status === "running") return;
    setDurationMinutes(mins);
    setSecondsLeft(mins * 60);
    setElapsedSeconds(0);
    setStatus("idle");
    setSavedLogRecord(null);
  };

  const handleStart = () => {
    if (secondsLeft <= 0) {
      setSecondsLeft(durationMinutes * 60);
      setElapsedSeconds(0);
    }
    setSavedLogRecord(null);
    setStatus("running");
  };

  const handlePause = () => {
    if (status === "running") {
      setStatus("paused");
    }
  };

  const handleResume = () => {
    if (status === "paused") {
      setStatus("running");
    }
  };

  const handleReset = () => {
    setStatus("idle");
    setSecondsLeft(durationMinutes * 60);
    setElapsedSeconds(0);
    setSavedLogRecord(null);
  };

  const totalSeconds = Math.max(durationMinutes * 60, 1);
  const progressPercent = Math.min(
    100,
    Math.round(((totalSeconds - secondsLeft) / totalSeconds) * 100)
  );

  const minutesDisplay = String(Math.floor(secondsLeft / 60)).padStart(2, "0");
  const secondsDisplay = String(secondsLeft % 60).padStart(2, "0");
  const actualStudyMinutes = Math.max(1, Math.round(elapsedSeconds / 60));

  const handleLogAndCompleteSession = async () => {
    if (!selectedTask?.id || savingSession || savedLogRecord) return;

    setSavingSession(true);
    try {
      const logResponse = await api.createTaskLog({
        task_id: selectedTask.id,
        status: "completed",
        actual_minutes:
          status === "finished" ? durationMinutes : actualStudyMinutes,
        reason: sessionNotes.trim() || "Completed in Focus Mode",
      });

      if (!logResponse.ok) {
        notify?.(
          "error",
          errorMessage(logResponse.data, "Could not save study session to the server.")
        );
        return;
      }

      const statusResponse = await api.updateTaskStatus(
        selectedTask.id,
        "completed"
      );

      if (!statusResponse.ok) {
        notify?.(
          "warning",
          "Study log was saved, but task status could not be updated automatically."
        );
      } else {
        notify?.(
          "success",
          `Session saved! Logged ${
             logResponse.data?.log?.actual_minutes || actualStudyMinutes
          } min and marked "${selectedTask.title}" completed.`
        );
      }

      setSavedLogRecord(logResponse.data?.log || { id: Date.now(), actual_minutes: actualStudyMinutes });
      if (status === "running") {
        setStatus("paused");
      }
      onTaskUpdated?.();
    } catch {
      notify?.("error", "Could not connect to the GrowthAI server. Session was not saved.");
    } finally {
      setSavingSession(false);
    }
  };

  return (
    <div className={`page-stack ${zenMode ? "focus-zen-active" : ""}`}>
      <section className="page-section focus-page-section">
        <SectionHeader
          kicker="Deep Work & Study Session"
          title="Focus Mode"
          description="Set a calm, distraction-free timer for a single task and log your verified study minutes to your GrowthAI account."
          actions={
            <div className="heading-actions">
              <button
                type="button"
                className="btn-secondary"
                onClick={() => setZenMode((prev) => !prev)}
              >
                {zenMode ? "Exit Compact View" : "Distraction-Free View"}
              </button>
              <button
                type="button"
                className="btn-ghost-sm"
                onClick={() => onNavigate?.("tasks")}
              >
                <IconCalendar width={15} height={15} />
                Back to Planner
              </button>
            </div>
          }
        />

        {/* Task Selection Bar */}
        <div className="focus-task-selector-card">
          <div className="focus-selector-row">
            <label htmlFor="focus-task-select" className="focus-selector-label">
              <IconTarget width={16} height={16} />
              <span>Studying task:</span>
            </label>

            <select
              id="focus-task-select"
              className="focus-task-select"
              value={selectedTaskId}
              onChange={(e) => handleTaskChange(e.target.value)}
              disabled={status === "running" || savingSession}
            >
              <option value="">— Free-form timer (no task linked) —</option>
              {pendingTasks.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.title} ({t.estimated_minutes || 30} min · {t.difficulty || "medium"})
                </option>
              ))}
              {selectedTask &&
                String(selectedTask.status).toLowerCase() === "completed" && (
                  <option value={selectedTask.id}>
                    {selectedTask.title} (Completed)
                  </option>
                )}
            </select>
          </div>

          {selectedTask ? (
            <div className="focus-selected-task-meta">
              <Badge variant="primary">
                {selectedTask.difficulty || "medium"} difficulty
              </Badge>
              <span>
                Estimated: {selectedTask.estimated_minutes || 30} min
              </span>
              {activeGoal && <span>Goal: {activeGoal.title}</span>}
            </div>
          ) : (
            <div className="focus-unlinked-notice" role="note">
              <IconInfo width={16} height={16} />
              <span>
                <strong>Free-form timer mode:</strong> You can use the countdown timer freely, but study sessions can only be saved to the server when linked to a task above (via <code>POST /task-logs</code>).
              </span>
            </div>
          )}
        </div>

        {/* Main Timer Arena */}
        <div className="focus-timer-arena">
          <div className="focus-presets-row" role="group" aria-label="Timer duration presets">
            {PRESET_MINUTES.map((mins) => (
              <button
                key={mins}
                type="button"
                className={`filter-pill ${durationMinutes === mins ? "active" : ""}`}
                onClick={() => handlePresetSelect(mins)}
                disabled={status === "running"}
              >
                {mins} min
              </button>
            ))}
          </div>

          <div className="focus-clock-ring">
            <ProgressRing
              percent={progressPercent}
              size={250}
              stroke={12}
              variant={status === "finished" ? "mint" : "blue"}
              label="Focus session progress"
            />
            <div className="focus-clock-center">
              <span className="focus-state-badge">
                {status === "idle" && "Ready to focus"}
                {status === "running" && "Focusing…"}
                {status === "paused" && "Paused"}
                {status === "finished" && "Session complete!"}
              </span>
              <strong className="focus-digits" aria-live="polite">
                {minutesDisplay}:{secondsDisplay}
              </strong>
              <span className="focus-elapsed-sub">
                {elapsedSeconds > 0
                  ? `${Math.floor(elapsedSeconds / 60)}m ${elapsedSeconds % 60}s studied`
                  : `${durationMinutes} minute session`}
              </span>
            </div>
          </div>

          {/* Primary Timer Controls: Start, Pause, Resume, Reset */}
          <div className="focus-controls-row">
            {status === "idle" && (
              <button
                type="button"
                className="btn-primary btn-lg"
                onClick={handleStart}
              >
                <IconPlay width={16} height={16} />
                Start Focus Timer
              </button>
            )}

            {status === "running" && (
              <button
                type="button"
                className="btn-secondary btn-lg"
                onClick={handlePause}
              >
                <IconPause width={16} height={16} />
                Pause
              </button>
            )}

            {status === "paused" && (
              <button
                type="button"
                className="btn-primary btn-lg"
                onClick={handleResume}
              >
                <IconPlay width={16} height={16} />
                Resume
              </button>
            )}

            <button
              type="button"
              className="btn-secondary btn-lg"
              onClick={handleReset}
              disabled={status === "idle" && elapsedSeconds === 0}
            >
              <IconReset width={16} height={16} />
              Reset
            </button>
          </div>
        </div>

        {/* Session Logging & Backend Persistence Panel */}
        {selectedTask && (
          <div className="focus-save-panel">
            <div className="focus-save-header">
              <div>
                <span className="panel-kicker">Verified Study Log</span>
                <h3>Complete &amp; save session to your account</h3>
                <p>
                  Records your actual study minutes in <code>task_logs</code> and marks{" "}
                  <strong>{selectedTask.title}</strong> as completed.
                </p>
              </div>
              <Badge variant={savedLogRecord ? "mint" : "neutral"}>
                {savedLogRecord
                  ? "Confirmed by server"
                  : `${status === "finished" ? durationMinutes : actualStudyMinutes} min to log`}
              </Badge>
            </div>

            {savedLogRecord ? (
              <div className="focus-saved-confirmation" role="status">
                <IconCheck width={18} height={18} />
                <div>
                  <strong>Study session confirmed &amp; saved</strong>
                  <p>
                    Logged {savedLogRecord.actual_minutes || actualStudyMinutes}{" "}
                    minutes for &ldquo;{selectedTask.title}&rdquo;. Duplicate logging is disabled for this session.
                  </p>
                </div>
              </div>
            ) : (
              <div className="focus-save-controls">
                <label className="form-field">
                  <span>Session reflection or note (optional)</span>
                  <input
                    type="text"
                    value={sessionNotes}
                    onChange={(e) => setSessionNotes(e.target.value)}
                    placeholder="What did you cover or solve in this study block?"
                    maxLength={200}
                    disabled={savingSession}
                  />
                </label>

                <div className="focus-save-actions">
                  <button
                    type="button"
                    className="btn-primary"
                    onClick={handleLogAndCompleteSession}
                    disabled={
                      savingSession ||
                      Boolean(savedLogRecord) ||
                      (elapsedSeconds < 10 && status !== "finished")
                    }
                  >
                    <IconCheck width={15} height={15} />
                    {savingSession
                      ? "Saving to server..."
                      : `Log ${
                          status === "finished"
                            ? durationMinutes
                            : actualStudyMinutes
                        } min & Complete Task`}
                  </button>

                  {elapsedSeconds < 10 && status !== "finished" && (
                    <span className="focus-save-hint">
                      <IconClock width={14} height={14} /> Start the timer for at least 10 seconds to log a study session.
                    </span>
                  )}
                </div>
              </div>
            )}
          </div>
        )}
      </section>
    </div>
  );
}
