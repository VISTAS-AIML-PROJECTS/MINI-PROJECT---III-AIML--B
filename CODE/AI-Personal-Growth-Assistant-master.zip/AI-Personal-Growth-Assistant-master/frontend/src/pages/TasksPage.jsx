import { useEffect, useState } from "react";
import { api, errorMessage, normalizeArray } from "../api/client";
import { Badge, EmptyState, SectionHeader } from "../components/ui";
import {
  IconCalendar,
  IconCheck,
  IconClock,
  IconFilter,
  IconPlus,
  IconSpark,
  IconTarget,
} from "../components/icons";
import { formatDate, getTodayLocal } from "../utils/format";

const DIFFICULTY_OPTIONS = ["easy", "medium", "hard"];
const SKIP_REASONS = [
  "Too tired",
  "Not enough time",
  "Too difficult",
  "Distracted",
  "Lost interest",
  "Unexpected work",
  "Other",
];

function AddTaskForm({ activeGoal, goals = [], busy, onCancel, onSubmit }) {
  const [goalId, setGoalId] = useState(activeGoal?.id || goals[0]?.id || "");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [minutes, setMinutes] = useState(30);
  const [difficulty, setDifficulty] = useState("medium");
  const [date, setDate] = useState(getTodayLocal());
  const [time, setTime] = useState("");
  const [validationError, setValidationError] = useState("");

  return (
    <form
      className="card-form"
      onSubmit={(event) => {
        event.preventDefault();
        const cleanTitle = title.trim();
        if (!cleanTitle) {
          setValidationError("Task title is required.");
          return;
        }
        if (!goalId) {
          setValidationError("Please select a goal for this task.");
          return;
        }
        setValidationError("");
        onSubmit({
          goal_id: Number(goalId),
          title: cleanTitle,
          description: description.trim(),
          estimated_minutes: Math.max(5, Math.min(480, Number(minutes) || 30)),
          difficulty,
          scheduled_date: date || null,
          scheduled_time: time || null,
        });
      }}
      noValidate
    >
      <div className="card-form-header">
        <h3>Schedule a study task</h3>
        <p>Add a specific reading, practice problem set, or review session to your planner.</p>
      </div>

      {validationError && (
        <div className="inline-form-error" role="alert">
          {validationError}
        </div>
      )}

      <div className="form-grid">
        <div className="form-row">
          <label className="form-field">
            <span>Task title *</span>
            <input
              type="text"
              value={title}
              placeholder="e.g. Complete 15 SQL JOIN practice queries"
              maxLength={160}
              onChange={(e) => {
                setTitle(e.target.value);
                if (validationError) setValidationError("");
              }}
              disabled={busy}
              required
            />
          </label>

          <label className="form-field">
            <span>Linked goal *</span>
            <select
              value={goalId}
              onChange={(e) => setGoalId(e.target.value)}
              disabled={busy || goals.length === 0}
            >
              {goals.length === 0 ? (
                <option value="">No goals created yet</option>
              ) : (
                goals.map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.title}
                  </option>
                ))
              )}
            </select>
          </label>
        </div>

        <label className="form-field">
          <span>Study notes or instructions (optional)</span>
          <textarea
            value={description}
            placeholder="Chapters, links, or specific deliverables for this session..."
            rows={2}
            onChange={(e) => setDescription(e.target.value)}
            disabled={busy}
          />
        </label>

        <div className="form-row">
          <label className="form-field">
            <span>Estimated duration (minutes)</span>
            <input
              type="number"
              min={5}
              max={480}
              step={5}
              value={minutes}
              onChange={(e) => setMinutes(e.target.value)}
              disabled={busy}
            />
          </label>

          <label className="form-field">
            <span>Difficulty level</span>
            <select
              value={difficulty}
              onChange={(e) => setDifficulty(e.target.value)}
              disabled={busy}
            >
              {DIFFICULTY_OPTIONS.map((option) => (
                <option key={option} value={option}>
                  {option.charAt(0).toUpperCase() + option.slice(1)}
                </option>
              ))}
            </select>
          </label>

          <label className="form-field">
            <span>Scheduled date</span>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              disabled={busy}
            />
          </label>

          <label className="form-field">
            <span>Time (optional)</span>
            <input
              type="time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              disabled={busy}
            />
          </label>
        </div>
      </div>

      <div className="form-actions">
        <button type="submit" className="btn-primary" disabled={busy}>
          {busy ? "Saving..." : "Add to planner"}
        </button>
        <button
          type="button"
          className="btn-secondary"
          onClick={onCancel}
          disabled={busy}
        >
          Cancel
        </button>
      </div>
    </form>
  );
}

export default function TasksPage({
  todayTasks,
  allTasks = [],
  goals = [],
  completedTasks,
  completionPercent,
  taskUpdating,
  onUpdateTaskStatus,
  notify,
  activeGoal,
  onTaskAdded,
  onStartFocus,
  onNavigate,
}) {
  const [showAdd, setShowAdd] = useState(false);
  const [busy, setBusy] = useState(false);
  const [generating, setGenerating] = useState(false);

  // Filters
  const [dateScope, setDateScope] = useState("today"); // "today" | "upcoming" | "all"
  const [statusFilter, setStatusFilter] = useState("all"); // "all" | "pending" | "completed" | "skipped"
  const [difficultyFilter, setDifficultyFilter] = useState("all");

  // Skip/Postpone flow
  const [skipTaskId, setSkipTaskId] = useState(null);
  const [skipActionType, setSkipActionType] = useState("skipped"); // "skipped" | "postponed"
  const [skipReason, setSkipReason] = useState("");
  const [skipBusy, setSkipBusy] = useState(false);

  // ML Completion Predictions
  const [predictions, setPredictions] = useState({});
  const [predictionRetries, setPredictionRetries] = useState({});

  // Daily Habits state (connected to /habits and /progress)
  const [habits, setHabits] = useState([]);
  const [habitProgress, setHabitProgress] = useState([]);
  const [newHabitName, setNewHabitName] = useState("");
  const [habitBusy, setHabitBusy] = useState(false);

  const tasksSource = allTasks.length > 0 ? allTasks : todayTasks;
  const today = getTodayLocal();

  const pendingTaskIds = tasksSource
    .filter((task) => String(task.status || "pending").toLowerCase() === "pending")
    .map((task) => task.id);

  const predictionTaskKey = pendingTaskIds.join(",");
  const predictionRetryKey = pendingTaskIds
    .map((id) => `${id}:${predictionRetries[id] || 0}`)
    .join(",");

  useEffect(() => {
    let active = true;
    const ids = predictionTaskKey ? predictionTaskKey.split(",") : [];
    if (ids.length === 0) return undefined;

    Promise.all(
      ids.map(async (id) => {
        try {
          const response = await api.getTaskPrediction(id);
          return [
            id,
            response.ok
              ? response.data
              : {
                  status: "error",
                  message: errorMessage(response.data, "Prediction unavailable."),
                },
          ];
        } catch {
          return [id, { status: "error", message: "Could not load this prediction." }];
        }
      })
    ).then((results) => {
      if (!active) return;
      setPredictions((previous) => ({ ...previous, ...Object.fromEntries(results) }));
    });

    return () => {
      active = false;
    };
  }, [predictionTaskKey, predictionRetryKey]);

  // Load Habits & Habit Progress
  useEffect(() => {
    let cancelled = false;
    async function loadHabits() {
      try {
        const [hRes, pRes] = await Promise.all([api.getHabits(), api.getProgress()]);
        if (cancelled) return;
        if (hRes.ok) setHabits(normalizeArray(hRes.data, ["habits"]));
        if (pRes.ok) setHabitProgress(normalizeArray(pRes.data, ["progress"]));
      } catch {
        /* ignore habit load error */
      }
    }
    loadHabits();
    return () => {
      cancelled = true;
    };
  }, []);

  const retryPrediction = (taskId) => {
    setPredictions((previous) => {
      const next = { ...previous };
      delete next[taskId];
      return next;
    });
    setPredictionRetries((previous) => ({
      ...previous,
      [taskId]: (previous[taskId] || 0) + 1,
    }));
  };

  const handleComplete = async (task, completed) => {
    onUpdateTaskStatus(task, completed ? "pending" : "completed");
    if (!completed) {
      try {
        await api.createTaskLog({
          task_id: task.id,
          status: "completed",
          actual_minutes: task.estimated_minutes || null,
        });
      } catch {
        // non-blocking
      }
    }
  };

  const handleSkipOrPostpone = async (task) => {
    if (!skipReason) return;
    setSkipBusy(true);
    try {
      const { ok, data } = await api.createTaskLog({
        task_id: task.id,
        status: skipActionType,
        reason: skipReason,
      });
      if (!ok) {
        notify("error", errorMessage(data, "Could not save the reason."));
        return;
      }
      await onUpdateTaskStatus(task, skipActionType);
      setSkipTaskId(null);
      setSkipReason("");
    } catch {
      notify("error", "Could not connect to the GrowthAI server.");
    } finally {
      setSkipBusy(false);
    }
  };

  const handleAddTask = async (payload) => {
    setBusy(true);
    try {
      const { ok, data } = await api.createTask(payload);
      if (!ok) {
        notify("error", errorMessage(data, "Could not create the task."));
        return;
      }
      notify("success", "Task added to your planner.");
      setShowAdd(false);
      onTaskAdded?.(data.task);
    } catch {
      notify("error", "Could not connect to the GrowthAI server.");
    } finally {
      setBusy(false);
    }
  };

  const handleGeneratePlan = async () => {
    if (!activeGoal?.id) {
      notify("error", "Select an active goal first so GrowthAI can build your plan.");
      return;
    }
    setGenerating(true);
    try {
      const { ok, data } = await api.generateDailyPlan();
      if (!ok) {
        notify("error", errorMessage(data, "Could not generate a plan."));
        return;
      }
      const created = data.tasks_created?.length || 0;
      notify(
        "success",
        created > 0
          ? `Generated ${created} study task${created === 1 ? "" : "s"} (${data.planned_minutes} min, ${data.recommended_difficulty} focus).`
          : "Your daily study budget is already full for today."
      );
      onTaskAdded?.(null);
    } catch {
      notify("error", "Could not connect to the GrowthAI server.");
    } finally {
      setGenerating(false);
    }
  };

  const handleAddHabit = async (e) => {
    e.preventDefault();
    const clean = newHabitName.trim();
    if (!clean || habitBusy) return;
    setHabitBusy(true);
    try {
      const { ok, data } = await api.createHabit({
        name: clean,
        frequency: "daily",
        target_count: 1,
      });
      if (ok && data?.habit) {
        setHabits((prev) => [...prev, data.habit]);
        setNewHabitName("");
        notify("success", "Daily study habit added.");
      } else {
        notify("error", errorMessage(data, "Could not create habit."));
      }
    } catch {
      notify("error", "Could not connect to the server.");
    } finally {
      setHabitBusy(false);
    }
  };

  const handleToggleHabitToday = async (habit) => {
    if (habitBusy) return;
    setHabitBusy(true);
    try {
      const { ok, data } = await api.createProgress({
        habit_id: habit.id,
        completed: true,
        notes: `Checked in on ${today}`,
      });
      if (ok && data?.progress) {
        setHabitProgress((prev) => [data.progress, ...prev]);
        notify("success", `Logged "${habit.name}" for today!`);
      } else {
        notify("error", errorMessage(data, "Could not log habit progress."));
      }
    } catch {
      notify("error", "Could not connect to the server.");
    } finally {
      setHabitBusy(false);
    }
  };

  const goalMap = new Map(goals.map((g) => [g.id, g.title]));

  // Filter tasks based on dateScope, statusFilter, difficultyFilter
  const filteredTasks = tasksSource.filter((task) => {
    const taskDate = task?.scheduled_date
      ? String(task.scheduled_date).slice(0, 10)
      : today;
    if (dateScope === "today" && taskDate !== today) return false;
    if (dateScope === "upcoming" && taskDate <= today) return false;

    const status = String(task.status || "pending").toLowerCase();
    if (statusFilter === "pending" && status !== "pending") return false;
    if (statusFilter === "completed" && status !== "completed") return false;
    if (
      statusFilter === "skipped" &&
      status !== "skipped" &&
      status !== "postponed"
    ) {
      return false;
    }

    const diff = String(task.difficulty || "medium").toLowerCase();
    if (difficultyFilter !== "all" && diff !== difficultyFilter) return false;

    return true;
  });

  const totalTodayMinutes = todayTasks.reduce(
    (sum, t) => sum + (Number(t.estimated_minutes) || 0),
    0
  );

  return (
    <div className="page-stack">
      <section className="page-section">
        <SectionHeader
          kicker="Daily Execution & Study Schedule"
          title="Daily Planner"
          description="Organize your study sessions, generate adaptive tasks from your skill roadmap, and launch Focus Mode for deep work."
          actions={
            <div className="heading-actions">
              <button
                type="button"
                className="btn-secondary"
                onClick={handleGeneratePlan}
                disabled={generating || busy}
              >
                <IconSpark width={15} height={15} />
                {generating ? "Generating..." : "Auto-Generate Today's Plan"}
              </button>

              <button
                type="button"
                className="btn-primary"
                onClick={() => setShowAdd((prev) => !prev)}
                disabled={busy || generating}
              >
                <IconPlus width={15} height={15} />
                {showAdd ? "Close form" : "Add task"}
              </button>
            </div>
          }
        />

        {showAdd && (
          <AddTaskForm
            activeGoal={activeGoal}
            goals={goals}
            busy={busy}
            onCancel={() => setShowAdd(false)}
            onSubmit={handleAddTask}
          />
        )}

        {/* Summary Metrics for Today */}
        <div className="task-summary-row">
          <div className="summary-card">
            <span>Today&apos;s Tasks</span>
            <strong>{todayTasks.length}</strong>
            <small>{totalTodayMinutes} min planned</small>
          </div>
          <div className="summary-card">
            <span>Completed Today</span>
            <strong className="text-mint">{completedTasks}</strong>
            <small>Synced to study logs</small>
          </div>
          <div className="summary-card">
            <span>Remaining Today</span>
            <strong>{Math.max(todayTasks.length - completedTasks, 0)}</strong>
            <small>Ready for focus</small>
          </div>
          <div className="summary-card">
            <span>Daily Completion</span>
            <strong className="text-primary">{completionPercent}%</strong>
            <small>Today&apos;s progress</small>
          </div>
        </div>

        {/* Filter Controls */}
        <div className="planner-filters-row">
          <div className="filter-bar" role="tablist" aria-label="Date range filter">
            {[
              { key: "today", label: `Today (${todayTasks.length})` },
              {
                key: "upcoming",
                label: `Upcoming (${
                  tasksSource.filter(
                    (t) =>
                      t.scheduled_date &&
                      String(t.scheduled_date).slice(0, 10) > today
                  ).length
                })`,
              },
              { key: "all", label: `All Dates (${tasksSource.length})` },
            ].map((tab) => (
              <button
                key={tab.key}
                type="button"
                role="tab"
                aria-selected={dateScope === tab.key}
                className={`filter-pill ${dateScope === tab.key ? "active" : ""}`}
                onClick={() => setDateScope(tab.key)}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="planner-select-filters">
            <span className="filter-icon-label">
              <IconFilter width={14} height={14} /> Filters:
            </span>
            <select
              className="select-compact"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              aria-label="Filter by task status"
            >
              <option value="all">All statuses</option>
              <option value="pending">Pending only</option>
              <option value="completed">Completed only</option>
              <option value="skipped">Skipped / Postponed</option>
            </select>

            <select
              className="select-compact"
              value={difficultyFilter}
              onChange={(e) => setDifficultyFilter(e.target.value)}
              aria-label="Filter by difficulty"
            >
              <option value="all">All difficulties</option>
              <option value="easy">Easy</option>
              <option value="medium">Medium</option>
              <option value="hard">Hard</option>
            </select>
          </div>
        </div>

        {/* Tasks List */}
        {filteredTasks.length === 0 ? (
          <EmptyState
            Icon={IconCalendar}
            title={
              dateScope === "today"
                ? "No tasks match your view for today"
                : "No tasks match the selected filters"
            }
            description={
              activeGoal
                ? "Generate an adaptive daily plan from your skill gaps, add a manual study task, or reset your filters."
                : "Create or select an active goal first so GrowthAI can organize your tasks."
            }
            action={
              activeGoal ? (
                <button
                  type="button"
                  className="btn-primary"
                  onClick={handleGeneratePlan}
                  disabled={generating}
                >
                  <IconSpark width={15} height={15} />
                  {generating ? "Generating..." : "Generate Today's Plan"}
                </button>
              ) : (
                <button
                  type="button"
                  className="btn-primary"
                  onClick={() => onNavigate?.("goals")}
                >
                  <IconTarget width={15} height={15} />
                  Select a Goal
                </button>
              )
            }
            secondaryAction={
              (statusFilter !== "all" ||
                difficultyFilter !== "all" ||
                dateScope !== "today") && (
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={() => {
                    setDateScope("today");
                    setStatusFilter("all");
                    setDifficultyFilter("all");
                  }}
                >
                  Reset filters
                </button>
              )
            }
          />
        ) : (
          <div className="full-task-list">
            {filteredTasks.map((task) => {
              const status = String(task.status || "pending").toLowerCase();
              const completed = status === "completed";
              const skippedOrPostponed =
                status === "skipped" || status === "postponed";
              const pred = predictions[task.id];
              const goalTitle = task.goal_id ? goalMap.get(task.goal_id) : null;

              return (
                <article
                  className={`full-task-card ${completed ? "task-card-done" : ""}`}
                  key={task.id}
                >
                  <button
                    type="button"
                    className={`large-task-check ${completed ? "done" : ""}`}
                    onClick={() => handleComplete(task, completed)}
                    disabled={taskUpdating === task.id}
                    aria-label={
                      completed
                        ? `Mark "${task.title}" as pending`
                        : `Complete "${task.title}"`
                    }
                  >
                    {completed && <IconCheck width={15} height={15} />}
                  </button>

                  <div className="full-task-info">
                    <div className="full-task-title-row">
                      <h3 className={completed ? "line-through" : ""}>
                        {task.title}
                      </h3>
                      <div className="full-task-badges">
                        <Badge
                          variant={
                            task.difficulty === "hard"
                              ? "primary"
                              : task.difficulty === "easy"
                                ? "mint"
                                : "neutral"
                          }
                        >
                          {task.difficulty || "medium"}
                        </Badge>
                        <span className={`task-status ${status}`}>{status}</span>
                      </div>
                    </div>

                    {task.description && <p>{task.description}</p>}

                    <div className="full-task-meta-row">
                      <span>
                        <IconClock width={13} height={13} />{" "}
                        {task.estimated_minutes || 30} min
                      </span>
                      {task.scheduled_date && (
                        <span>
                          <IconCalendar width={13} height={13} />{" "}
                          {formatDate(String(task.scheduled_date).slice(0, 10))}
                          {task.scheduled_time
                            ? ` at ${String(task.scheduled_time).slice(0, 5)}`
                            : ""}
                        </span>
                      )}
                      {goalTitle && (
                        <span>
                          <IconTarget width={13} height={13} /> {goalTitle}
                        </span>
                      )}
                    </div>

                    {!completed && !skippedOrPostponed && (
                      <div className="task-prediction" aria-live="polite">
                        <div className="task-prediction-header">
                          <strong>ML Completion Advisory</strong>
                          {pred?.status === "ok" && (
                            <Badge
                              variant={
                                pred.completion_probability >= 0.5
                                  ? "mint"
                                  : "warning"
                              }
                            >
                              {pred.predicted_status} (
                              {Math.round(pred.completion_probability * 100)}%)
                            </Badge>
                          )}
                        </div>
                        {!pred || pred.status === "loading" ? (
                          <span>Evaluating task history…</span>
                        ) : pred.status === "insufficient_data" ? (
                          <span>
                            Needs at least 6 logged task outcomes (both completed &amp; skipped) to train your personal LogisticRegression predictor ({pred.training_examples || 0}/6 recorded).
                          </span>
                        ) : pred.status === "ok" ? (
                          <span>
                            Trained on {pred.training_examples} personal task logs
                            {pred.evaluation_metrics
                              ? ` · Holdout accuracy ${Math.round(
                                  pred.evaluation_metrics.accuracy * 100
                                )}%`
                              : ""}
                          </span>
                        ) : pred.status === "error" ? (
                          <span>
                            {pred.message || "Prediction unavailable."}{" "}
                            <button
                              type="button"
                              className="text-button"
                              onClick={() => retryPrediction(task.id)}
                            >
                              Retry
                            </button>
                          </span>
                        ) : (
                          <span>{pred.message || "Prediction unavailable."}</span>
                        )}
                      </div>
                    )}

                    {/* Skip / Postpone Reason Drawer */}
                    {skipTaskId === task.id && (
                      <div className="skip-reason-box">
                        <div className="skip-reason-row">
                          <select
                            className="select-compact"
                            value={skipActionType}
                            onChange={(e) => setSkipActionType(e.target.value)}
                            disabled={skipBusy}
                            aria-label="Action type"
                          >
                            <option value="skipped">Skip task</option>
                            <option value="postponed">Postpone task</option>
                          </select>

                          <select
                            className="select-compact"
                            value={skipReason}
                            onChange={(e) => setSkipReason(e.target.value)}
                            disabled={skipBusy}
                            required
                            aria-label="Reason for skipping or postponing"
                          >
                            <option value="" disabled>
                              Select reason (required)...
                            </option>
                            {SKIP_REASONS.map((r) => (
                              <option key={r} value={r}>
                                {r}
                              </option>
                            ))}
                          </select>

                          <button
                            type="button"
                            className="btn-primary"
                            onClick={() => handleSkipOrPostpone(task)}
                            disabled={skipBusy || !skipReason}
                          >
                            {skipBusy ? "Saving..." : "Confirm"}
                          </button>

                          <button
                            type="button"
                            className="btn-secondary"
                            onClick={() => setSkipTaskId(null)}
                            disabled={skipBusy}
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Right Action Column */}
                  <div className="full-task-actions">
                    {!completed && !skippedOrPostponed && (
                      <>
                        {onStartFocus && (
                          <button
                            type="button"
                            className="btn-primary"
                            onClick={() => onStartFocus(task)}
                          >
                            <IconClock width={14} height={14} />
                            Focus
                          </button>
                        )}
                        {skipTaskId !== task.id && (
                          <button
                            type="button"
                            className="btn-ghost-sm"
                            onClick={() => {
                              setSkipTaskId(task.id);
                              setSkipActionType("skipped");
                              setSkipReason("");
                            }}
                          >
                            Skip / Postpone
                          </button>
                        )}
                      </>
                    )}
                    {skippedOrPostponed && (
                      <button
                        type="button"
                        className="btn-ghost-sm"
                        onClick={() => onUpdateTaskStatus(task, "pending")}
                        disabled={taskUpdating === task.id}
                      >
                        Reopen task
                      </button>
                    )}
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>

      {/* Daily Study Habits Section (connected to /habits and /progress) */}
      <section className="page-section">
        <SectionHeader
          kicker="Consistency Routines"
          title="Daily Study Habits"
          description="Track small, repeatable study habits alongside your scheduled tasks."
        />

        <form className="habit-inline-form" onSubmit={handleAddHabit}>
          <input
            type="text"
            value={newHabitName}
            onChange={(e) => setNewHabitName(e.target.value)}
            placeholder="Add a daily habit (e.g. Review flashcards for 15 mins)"
            maxLength={120}
            disabled={habitBusy}
          />
          <button
            type="submit"
            className="btn-secondary"
            disabled={habitBusy || !newHabitName.trim()}
          >
            <IconPlus width={15} height={15} />
            Add Habit
          </button>
        </form>

        {habits.length === 0 ? (
          <p className="panel-description">
            No daily habits created yet. Add a recurring study habit above to log daily check-ins.
          </p>
        ) : (
          <div className="habits-grid">
            {habits.map((habit) => {
              const completedToday = habitProgress.some(
                (p) =>
                  Number(p.habit_id) === Number(habit.id) &&
                  p.completed &&
                  String(p.progress_date).slice(0, 10) === today
              );
              const totalCheckins = habitProgress.filter(
                (p) => Number(p.habit_id) === Number(habit.id) && p.completed
              ).length;

              return (
                <div className="habit-card" key={habit.id}>
                  <div>
                    <strong>{habit.name}</strong>
                    <small>
                      {habit.frequency || "daily"} · {totalCheckins} total check-in
                      {totalCheckins === 1 ? "" : "s"}
                    </small>
                  </div>
                  <button
                    type="button"
                    className={completedToday ? "btn-secondary" : "btn-primary"}
                    disabled={completedToday || habitBusy}
                    onClick={() => handleToggleHabitToday(habit)}
                  >
                    <IconCheck width={14} height={14} />
                    {completedToday ? "Done today" : "Check in"}
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
