import { useEffect, useState } from "react";
import { api, errorMessage } from "../api/client";
import {
  ENERGY_LEVELS,
  formatEnergyLabel,
  isSameEnergyLevel,
} from "../constants";
import ProgressRing from "../components/ProgressRing";
import { Badge, EmptyState, ProgressBar } from "../components/ui";
import {
  IconArrow,
  IconBolt,
  IconBook,
  IconCalendar,
  IconCheck,
  IconClock,
  IconMap,
  IconPlay,
  IconSpark,
  IconTarget,
} from "../components/icons";
import { formatDate, getGreeting, getTodayLocal } from "../utils/format";

export default function DashboardPage({
  firstName,
  completionPercent,
  completedTasks,
  todayTasks,
  allTasks = [],
  taskLogs = [],
  activeGoal,
  currentEnergy,
  taskUpdating,
  onUpdateTaskStatus,
  onSaveEnergy,
  onNavigate,
  onStartFocus,
  onTasksChanged,
  notify,
}) {
  const [skillGaps, setSkillGaps] = useState([]);
  const [skillsLoading, setSkillsLoading] = useState(false);
  const [advice, setAdvice] = useState(null);
  const [generatingPlan, setGeneratingPlan] = useState(false);

  useEffect(() => {
    let cancelled = false;

    async function loadGoalAndAdvice() {
      if (!activeGoal?.id) {
        setSkillGaps([]);
      } else {
        setSkillsLoading(true);
        try {
          const gapsRes = await api.getSkillGaps(activeGoal.id);
          if (!cancelled && gapsRes.ok) {
            setSkillGaps(gapsRes.data?.skills || []);
          }
        } catch {
          if (!cancelled) setSkillGaps([]);
        } finally {
          if (!cancelled) setSkillsLoading(false);
        }
      }

      try {
        const adviceRes = await api.getAdaptiveRecommendation();
        if (!cancelled && adviceRes.ok) {
          setAdvice(adviceRes.data);
        }
      } catch {
        /* ignore advisory error */
      }
    }

    loadGoalAndAdvice();
    return () => {
      cancelled = true;
    };
  }, [activeGoal?.id, currentEnergy, completedTasks]);

  const handleQuickGeneratePlan = async () => {
    if (!activeGoal?.id) {
      onNavigate("goals");
      return;
    }
    setGeneratingPlan(true);
    try {
      const { ok, data } = await api.generateDailyPlan();
      if (!ok) {
        notify?.("error", errorMessage(data, "Could not generate today's plan."));
        return;
      }
      const count = data?.tasks_created?.length || 0;
      notify?.(
        "success",
        count > 0
          ? `Added ${count} study task${count === 1 ? "" : "s"} (${data.planned_minutes} min) to today's plan.`
          : "Your daily study time is already filled for today."
      );
      onTasksChanged?.();
    } catch {
      notify?.("error", "Could not connect to the GrowthAI server.");
    } finally {
      setGeneratingPlan(false);
    }
  };

  const today = getTodayLocal();

  const pendingTodayTasks = todayTasks.filter(
    (task) => String(task.status || "pending").toLowerCase() === "pending"
  );
  const nextTask = pendingTodayTasks[0] || null;

  const upcomingTasks = allTasks
    .filter((task) => {
      if (!task?.scheduled_date) return false;
      const d = String(task.scheduled_date).slice(0, 10);
      return d > today && String(task.status || "pending").toLowerCase() === "pending";
    })
    .slice(0, 3);

  const plannedMinutesToday = todayTasks.reduce(
    (sum, t) => sum + (Number(t.estimated_minutes) || 0),
    0
  );
  const completedMinutesToday = todayTasks
    .filter((t) => String(t.status).toLowerCase() === "completed")
    .reduce((sum, t) => sum + (Number(t.estimated_minutes) || 0), 0);

  const assessedSkills = skillGaps.filter((s) => s.skill_level != null);
  const strongSkills = skillGaps.filter((s) => s.gap_status === "strong");
  const gapSkills = skillGaps.filter((s) => s.gap_status === "gap");

  const taskMap = new Map(allTasks.map((t) => [t.id, t]));
  const recentLogs = taskLogs.slice(0, 5);

  return (
    <div className="dashboard-stack">
      <div className="dashboard-overview-top">
        {/* Top Welcome & Next Priority Banner */}
        <section className="welcome-banner">
        <div className="welcome-banner-main">
          <span className="eyebrow">
            {new Date().toLocaleDateString("en-US", {
              weekday: "long",
              month: "long",
              day: "numeric",
              year: "numeric",
            })}
          </span>
          <h2>
            {getGreeting()}, {firstName}
          </h2>
          <p>
            {activeGoal
              ? `Focused on "${activeGoal.title}". Let's make steady, meaningful progress today.`
              : "Welcome to your study workspace. Start by choosing a learning goal to unlock skill assessments and adaptive daily planning."}
          </p>
        </div>

        <div className="welcome-next-card">
          {nextTask ? (
            <>
              <div className="welcome-next-meta">
                <Badge variant="primary">Up next today</Badge>
                <span>
                  {nextTask.estimated_minutes || 30} min ·{" "}
                  {nextTask.difficulty || "medium"}
                </span>
              </div>
              <strong>{nextTask.title}</strong>
              <div className="welcome-next-actions">
                <button
                  type="button"
                  className="btn-primary"
                  onClick={() => onStartFocus?.(nextTask)}
                >
                  <IconPlay width={14} height={14} />
                  Start Focus Session
                </button>
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={() => onUpdateTaskStatus(nextTask, "completed")}
                  disabled={taskUpdating === nextTask.id}
                >
                  <IconCheck width={15} height={15} />
                  Mark Done
                </button>
              </div>
            </>
          ) : !activeGoal ? (
            <>
              <div className="welcome-next-meta">
                <Badge variant="warning">Step 1</Badge>
                <span>Setup required</span>
              </div>
              <strong>Set your first learning goal</strong>
              <p className="welcome-next-sub">
                GrowthAI builds your skill roadmap and study plan around your active goal.
              </p>
              <div className="welcome-next-actions">
                <button
                  type="button"
                  className="btn-primary"
                  onClick={() => onNavigate("goals")}
                >
                  <IconTarget width={15} height={15} />
                  Create a Goal
                </button>
              </div>
            </>
          ) : todayTasks.length === 0 ? (
            <>
              <div className="welcome-next-meta">
                <Badge variant="info">Ready to plan</Badge>
                <span>No tasks for today</span>
              </div>
              <strong>Build today&apos;s study schedule</strong>
              <p className="welcome-next-sub">
                Generate tasks automatically from your skill gaps or add custom study tasks.
              </p>
              <div className="welcome-next-actions">
                <button
                  type="button"
                  className="btn-primary"
                  onClick={handleQuickGeneratePlan}
                  disabled={generatingPlan}
                >
                  <IconSpark width={15} height={15} />
                  {generatingPlan ? "Generating..." : "Generate Today's Plan"}
                </button>
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={() => onNavigate("tasks")}
                >
                  Open Planner
                </button>
              </div>
            </>
          ) : (
            <>
              <div className="welcome-next-meta">
                <Badge variant="mint">All caught up</Badge>
                <span>{completedTasks} completed</span>
              </div>
              <strong>You completed today&apos;s planned tasks!</strong>
              <p className="welcome-next-sub">
                Review your skill roadmap or take a diagnostic assessment to measure improvement.
              </p>
              <div className="welcome-next-actions">
                <button
                  type="button"
                  className="btn-primary"
                  onClick={() => onNavigate("roadmap")}
                >
                  <IconMap width={15} height={15} />
                  View Roadmap
                </button>
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={() => onNavigate("progress")}
                >
                  View Insights
                </button>
              </div>
            </>
          )}
        </div>
      </section>

      {/* Study Summary Row */}
      <section className="hero-progress">
        <div className="hero-progress-top">
          <div className="hero-progress-ring">
            <ProgressRing
              percent={completionPercent}
              size={108}
              stroke={10}
              variant="mint"
              label="Today's task completion"
            />
            <div className="hero-progress-center">
              <strong>{completionPercent}%</strong>
              <span>done today</span>
            </div>
          </div>

          <div className="hero-progress-details">
            <span className="panel-kicker">Daily Study Summary</span>
            <h3>
              {completedTasks} of {todayTasks.length}{" "}
              {todayTasks.length === 1 ? "task" : "tasks"} completed today
            </h3>
            <p>
              {todayTasks.length > 0
                ? `${completedMinutesToday} of ${plannedMinutesToday} planned minutes completed.`
                : "No study tasks scheduled for today yet."}
            </p>
          </div>
        </div>

        <div className="hero-progress-stats">
          <div className="hero-stat-pill">
            <span className="hero-stat-icon blue">
              <IconTarget width={16} height={16} />
            </span>
            <div>
              <span>Active goal</span>
              <strong>{activeGoal ? activeGoal.title : "None selected"}</strong>
            </div>
          </div>

          <div className="hero-stat-pill">
            <span className="hero-stat-icon mint">
              <IconClock width={16} height={16} />
            </span>
            <div>
              <span>Study time today</span>
              <strong>
                {completedMinutesToday} / {plannedMinutesToday} min
              </strong>
            </div>
          </div>

          <div className="hero-stat-pill">
            <span className="hero-stat-icon blue">
              <IconBook width={16} height={16} />
            </span>
            <div>
              <span>Skills assessed</span>
              <strong>
                {skillGaps.length > 0
                  ? `${assessedSkills.length} of ${skillGaps.length} skills`
                  : "No skills mapped yet"}
              </strong>
            </div>
          </div>

          <div className="hero-stat-pill">
            <span className="hero-stat-icon mint">
              <IconBolt width={16} height={16} />
            </span>
            <div>
              <span>Energy &amp; pace</span>
              <strong>
                {formatEnergyLabel(currentEnergy)}
                {advice?.recommended_difficulty
                  ? ` · ${advice.recommended_difficulty} tasks`
                  : ""}
              </strong>
            </div>
          </div>
        </div>
      </section>
      </div>

      {/* Main Dashboard Grid: Planned Tasks, Energy Check-in, Skill Development, Recent Activity */}
      <section className="dashboard-grid">
        {/* Left: Today's Planned Tasks */}
        <div className="panel tasks-panel">
          <div className="panel-header">
            <div>
              <span className="panel-kicker">Today&apos;s Schedule</span>
              <h3>Planned study tasks</h3>
            </div>
            <div className="panel-header-actions">
              {activeGoal && (
                <button
                  type="button"
                  className="btn-ghost-sm"
                  onClick={handleQuickGeneratePlan}
                  disabled={generatingPlan}
                >
                  <IconSpark width={14} height={14} />
                  {generatingPlan ? "Generating..." : "Auto-plan"}
                </button>
              )}
              <button
                type="button"
                className="text-button"
                onClick={() => onNavigate("tasks")}
              >
                Open planner <IconArrow width={14} height={14} />
              </button>
            </div>
          </div>

          {todayTasks.length === 0 ? (
            <EmptyState
              Icon={IconCalendar}
              title="No tasks planned for today"
              description={
                activeGoal
                  ? "Generate a personalized study plan from your skill gaps or add a task manually."
                  : "Create or select a goal first so GrowthAI can help schedule your daily tasks."
              }
              action={
                activeGoal ? (
                  <button
                    type="button"
                    className="btn-primary"
                    onClick={handleQuickGeneratePlan}
                    disabled={generatingPlan}
                  >
                    <IconSpark width={15} height={15} />
                    {generatingPlan ? "Generating..." : "Generate daily plan"}
                  </button>
                ) : (
                  <button
                    type="button"
                    className="btn-primary"
                    onClick={() => onNavigate("goals")}
                  >
                    <IconTarget width={15} height={15} />
                    Set a goal
                  </button>
                )
              }
              secondaryAction={
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={() => onNavigate("tasks")}
                >
                  Add task manually
                </button>
              }
            />
          ) : (
            <div className="task-list">
              {todayTasks.slice(0, 6).map((task) => {
                const status = String(task.status || "pending").toLowerCase();
                const completed = status === "completed";
                const skipped = status === "skipped" || status === "postponed";

                return (
                  <div
                    className={`task-row ${completed ? "is-completed" : ""}`}
                    key={task.id}
                  >
                    <button
                      type="button"
                      className={`task-check ${completed ? "done" : ""}`}
                      onClick={() =>
                        onUpdateTaskStatus(task, completed ? "pending" : "completed")
                      }
                      disabled={taskUpdating === task.id}
                      aria-label={
                        completed
                          ? `Mark "${task.title}" as pending`
                          : `Complete "${task.title}"`
                      }
                    >
                      {completed && <IconCheck width={14} height={14} />}
                    </button>

                    <div className="task-info">
                      <strong className={completed ? "line-through" : ""}>
                        {task.title}
                      </strong>
                      <span>
                        {task.estimated_minutes || 30} min ·{" "}
                        <span className={`diff-tag diff-${task.difficulty || "medium"}`}>
                          {task.difficulty || "medium"}
                        </span>
                        {task.scheduled_time
                          ? ` · ${String(task.scheduled_time).slice(0, 5)}`
                          : ""}
                      </span>
                    </div>

                    <div className="task-row-actions">
                      {!completed && !skipped && (
                        <button
                          type="button"
                          className="btn-focus-chip"
                          onClick={() => onStartFocus?.(task)}
                          title="Start Focus Timer for this task"
                        >
                          <IconClock width={13} height={13} />
                          Focus
                        </button>
                      )}
                      <span className={`task-status ${status}`}>{status}</span>
                    </div>
                  </div>
                );
              })}

              {todayTasks.length > 6 && (
                <div className="panel-footer-link">
                  <button
                    type="button"
                    className="text-button"
                    onClick={() => onNavigate("tasks")}
                  >
                    View all {todayTasks.length} tasks for today →
                  </button>
                </div>
              )}
            </div>
          )}

          {upcomingTasks.length > 0 && (
            <div className="upcoming-subsection">
              <span className="subsection-label">Upcoming priorities</span>
              <div className="upcoming-mini-list">
                {upcomingTasks.map((task) => (
                  <div key={task.id} className="upcoming-mini-item">
                    <div>
                      <strong>{task.title}</strong>
                      <small>
                        {formatDate(String(task.scheduled_date).slice(0, 10))} ·{" "}
                        {task.estimated_minutes || 30} min
                      </small>
                    </div>
                    <Badge variant="neutral">{task.difficulty || "medium"}</Badge>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Energy Check-In & Adaptive Recommendation Card */}
        <div className="panel energy-panel">
          <div className="panel-header">
            <div>
              <span className="panel-kicker">Daily Check-in</span>
              <h3>How is your energy today?</h3>
            </div>
            <span className="energy-symbol">
              <IconBolt width={18} height={18} />
            </span>
          </div>

          <p className="panel-description">
            Your energy check-in tunes the difficulty of tasks generated for your daily plan.
          </p>

          <div className="energy-options" role="group" aria-label="Energy level options">
            {ENERGY_LEVELS.map(({ key, label, helper, Icon }) => {
              const selected = isSameEnergyLevel(currentEnergy, key);
              return (
                <button
                  type="button"
                  key={key}
                  className={`energy-option-btn ${selected ? "selected" : ""}`}
                  aria-pressed={selected}
                  onClick={() => onSaveEnergy(key)}
                >
                  <Icon width={18} height={18} />
                  <strong>{label}</strong>
                  <small>{helper}</small>
                </button>
              );
            })}
          </div>

          {advice ? (
            <div className="adaptive-advice-box">
              <div className="adaptive-advice-header">
                <span>Adaptive recommendation:</span>
                <Badge
                  variant={
                    advice.recommended_difficulty === "hard"
                      ? "primary"
                      : advice.recommended_difficulty === "medium"
                        ? "mint"
                        : "warning"
                  }
                >
                  {advice.recommended_difficulty} difficulty
                </Badge>
              </div>
              <p>{advice.explanation}</p>
            </div>
          ) : (
            <div className="adaptive-advice-box">
              <div className="adaptive-advice-header">
                <span>Adaptive recommendation:</span>
                <Badge variant="neutral">Ready</Badge>
              </div>
              <p>
                Select your energy level above to calibrate today&apos;s recommended task difficulty.
              </p>
            </div>
          )}
        </div>

        {/* Active Goal & Skill Progress Card */}
        <div className="panel skill-overview-panel">
          <div className="panel-header">
            <div>
              <span className="panel-kicker">Skill Development</span>
              <h3>
                {activeGoal ? activeGoal.title : "Active goal skills"}
              </h3>
            </div>
            {activeGoal && (
              <button
                type="button"
                className="text-button"
                onClick={() => onNavigate("roadmap")}
              >
                Roadmap <IconArrow width={14} height={14} />
              </button>
            )}
          </div>

          {!activeGoal ? (
            <p className="panel-description">
              Select or create a goal to view its required skills and track your mastery.
            </p>
          ) : skillsLoading ? (
            <p className="panel-description">Loading skill development data…</p>
          ) : skillGaps.length === 0 ? (
            <div className="skill-empty-box">
              <p>
                Skills for this goal are being prepared or haven&apos;t been mapped yet.
              </p>
              <button
                type="button"
                className="btn-secondary"
                onClick={() => onNavigate("goals")}
              >
                View Goal &amp; Skills
              </button>
            </div>
          ) : (
            <>
              <div className="skill-summary-chips">
                <Badge variant="mint">{strongSkills.length} Strong</Badge>
                <Badge variant="warning">{gapSkills.length} Skill gaps</Badge>
                <Badge variant="neutral">
                  {skillGaps.length - assessedSkills.length} Unassessed
                </Badge>
              </div>

              <div className="dashboard-skill-bars">
                {skillGaps.slice(0, 4).map((skill) => {
                  const score =
                    skill.score_percentage != null
                      ? Math.round(Number(skill.score_percentage))
                      : 0;
                  const isAssessed = skill.skill_level != null;

                  return (
                    <div key={skill.skill_id} className="dashboard-skill-item">
                      <div className="dashboard-skill-row">
                        <strong>{skill.name}</strong>
                        <span className="dashboard-skill-meta">
                          {isAssessed
                            ? `${skill.skill_level} (${score}%)`
                            : "Not assessed"}
                        </span>
                      </div>
                      <ProgressBar
                        value={isAssessed ? score : 0}
                        variant={
                          skill.gap_status === "strong"
                            ? "mint"
                            : isAssessed
                              ? "primary"
                              : "muted"
                        }
                        size="sm"
                      />
                    </div>
                  );
                })}
              </div>

              <div className="skill-panel-actions">
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={() => onNavigate("assessment")}
                >
                  <IconBook width={15} height={15} />
                  {assessedSkills.length === 0
                    ? "Take Diagnostic Assessment"
                    : "Retake Assessment"}
                </button>
                <button
                  type="button"
                  className="btn-ghost-sm"
                  onClick={() => onNavigate("goals")}
                >
                  Manage Goals
                </button>
              </div>
            </>
          )}
        </div>

        {/* Recent Activity from Real Task Logs */}
        <div className="panel recent-activity-panel">
          <div className="panel-header">
            <div>
              <span className="panel-kicker">Study Log History</span>
              <h3>Recent activity</h3>
            </div>
            <button
              type="button"
              className="text-button"
              onClick={() => onNavigate("progress")}
            >
              Full history &amp; insights <IconArrow width={14} height={14} />
            </button>
          </div>

          {recentLogs.length === 0 ? (
            <div className="recent-empty-box">
              <p className="panel-description">
                No study sessions or task outcomes have been logged yet. Complete a task or finish a Focus Mode session to see your real activity history here.
              </p>
              <div className="skill-panel-actions">
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={() => onNavigate("focus")}
                >
                  <IconClock width={15} height={15} />
                  Open Focus Mode
                </button>
                <button
                  type="button"
                  className="btn-ghost-sm"
                  onClick={() => onNavigate("progress")}
                >
                  View Insights
                </button>
              </div>
            </div>
          ) : (
            <div className="recent-logs-list">
              {recentLogs.map((log) => {
                const linkedTask = taskMap.get(log.task_id);
                const isCompleted = log.status === "completed";
                return (
                  <div key={log.id} className="recent-log-row">
                    <span
                      className={`recent-log-dot ${isCompleted ? "mint" : "warning"}`}
                    />
                    <div className="recent-log-main">
                      <strong>
                        {linkedTask ? linkedTask.title : `Task #${log.task_id}`}
                      </strong>
                      <span>
                        {isCompleted ? "Completed" : `Marked ${log.status}`}
                        {log.actual_minutes ? ` · ${log.actual_minutes} min studied` : ""}
                        {log.reason ? ` · "${log.reason}"` : ""}
                      </span>
                    </div>
                    <time className="recent-log-time">
                      {log.logged_at
                        ? new Date(log.logged_at).toLocaleDateString("en-US", {
                            month: "short",
                            day: "numeric",
                          })
                        : ""}
                    </time>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
