import { useCallback, useEffect, useState } from "react";
import { api, errorMessage } from "../api/client";
import { Badge, EmptyState, ProgressBar, SectionHeader } from "../components/ui";
import {
  IconArchive,
  IconArrow,
  IconBook,
  IconCheck,
  IconEdit,
  IconMap,
  IconPlus,
  IconRefresh,
  IconSpark,
  IconTarget,
} from "../components/icons";
import { formatDate } from "../utils/format";

const STATUS_OPTIONS = ["active", "completed", "archived"];
const SUGGESTED_TOPICS = [
  {
    title: "Become a Data Analyst",
    description: "Master Python, SQL, Statistics, Excel, and Data Visualization for analytics roles.",
  },
  {
    title: "Prepare for NEET Biology",
    description: "Build strong mastery across Human Physiology, Genetics, and Cell Biology.",
  },
  {
    title: "Become a Business Owner",
    description: "Develop core skills in Market Research, Marketing, Finance, Sales, and Communication.",
  },
];

function GoalForm({ initial, busy, onCancel, onSubmit }) {
  const [title, setTitle] = useState(initial?.title || "");
  const [description, setDescription] = useState(initial?.description || "");
  const [targetDate, setTargetDate] = useState(
    initial?.target_date ? String(initial.target_date).slice(0, 10) : ""
  );
  const [status, setStatus] = useState(initial?.status || "active");
  const [validationError, setValidationError] = useState("");

  const handleFormSubmit = (event) => {
    event.preventDefault();
    const cleanTitle = title.trim();
    if (!cleanTitle) {
      setValidationError("Goal title is required.");
      return;
    }
    if (cleanTitle.length < 3) {
      setValidationError("Goal title should be at least 3 characters.");
      return;
    }
    setValidationError("");
    onSubmit({
      title: cleanTitle,
      description: description.trim(),
      target_date: targetDate || null,
      status,
    });
  };

  return (
    <form className="card-form" onSubmit={handleFormSubmit} noValidate>
      <div className="card-form-header">
        <h3>{initial ? "Edit learning goal" : "Create a new learning goal"}</h3>
        <p>
          {initial
            ? "Update your goal details, target date, or completion status."
            : "Enter any academic or career goal. GrowthAI maps required skills automatically."}
        </p>
      </div>

      {!initial && (
        <div className="template-Suggestions">
          <span className="form-helper-label">Quick-fill a built-in study template:</span>
          <div className="template-chips">
            {SUGGESTED_TOPICS.map((topic) => (
              <button
                key={topic.title}
                type="button"
                className="chip-button"
                onClick={() => {
                  setTitle(topic.title);
                  setDescription(topic.description);
                  setValidationError("");
                }}
                disabled={busy}
              >
                <IconSpark width={13} height={13} />
                {topic.title}
              </button>
            ))}
          </div>
        </div>
      )}

      {validationError && (
        <div className="inline-form-error" role="alert">
          {validationError}
        </div>
      )}

      <div className="form-grid">
        <label className="form-field">
          <span>Goal title *</span>
          <input
            type="text"
            value={title}
            placeholder="e.g. Become a Data Analyst or Master Organic Chemistry"
            maxLength={120}
            onChange={(e) => {
              setTitle(e.target.value);
              if (validationError) setValidationError("");
            }}
            disabled={busy}
            required
          />
        </label>

        <label className="form-field">
          <span>Description &amp; motivation</span>
          <textarea
            value={description}
            placeholder="What does achieving this goal look like for you?"
            rows={2}
            onChange={(e) => setDescription(e.target.value)}
            disabled={busy}
          />
        </label>

        <div className="form-row">
          <label className="form-field">
            <span>Target completion date (optional)</span>
            <input
              type="date"
              value={targetDate}
              onChange={(e) => setTargetDate(e.target.value)}
              disabled={busy}
            />
          </label>

          <label className="form-field">
            <span>Goal status</span>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              disabled={busy}
            >
              {STATUS_OPTIONS.map((option) => (
                <option key={option} value={option}>
                  {option.charAt(0).toUpperCase() + option.slice(1)}
                </option>
              ))}
            </select>
          </label>
        </div>
      </div>

      <div className="form-actions">
        <button type="submit" className="btn-primary" disabled={busy}>
          {busy ? "Saving..." : initial ? "Save changes" : "Create goal"}
        </button>
        <button
          type="button"
          className="btn-secondary"
          onClick={onCancel}
          disabled={busy}
        >
          Cancel
        </button>
      </div>
    </form>
  );
}

export default function GoalsPage({
  goals,
  notify,
  activeGoalId,
  onSelectGoal,
  onGoalSaved,
  onNavigate,
}) {
  const [showCreate, setShowCreate] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [busy, setBusy] = useState(false);
  const [statusFilter, setStatusFilter] = useState("all");

  // Skills & Skill Gaps for the active/inspected goal
  const [skillsData, setSkillsData] = useState([]);
  const [gapsData, setGapsData] = useState([]);
  const [preparingSkills, setPreparingSkills] = useState(false);
  const [loadingSkills, setLoadingSkills] = useState(false);

  const inspectedGoal =
    goals.find((g) => g.id === activeGoalId) || goals[0] || null;

  const loadGoalSkillsAndGaps = useCallback(
    async (goalId) => {
      await Promise.resolve();
      if (!goalId) {
        setSkillsData([]);
        setGapsData([]);
        setPreparingSkills(false);
        return;
      }

      setLoadingSkills(true);
      try {
        const [skillsRes, gapsRes] = await Promise.all([
          api.getGoalSkills(goalId),
          api.getSkillGaps(goalId),
        ]);

        if (skillsRes.ok) {
          setSkillsData(skillsRes.data?.skills || []);
          setPreparingSkills(Boolean(skillsRes.data?.preparing));
        }
        if (gapsRes.ok) {
          setGapsData(gapsRes.data?.skills || []);
        }
      } catch {
        notify("error", "Could not load skill mapping for this goal.");
      } finally {
        setLoadingSkills(false);
      }
    },
    [notify]
  );

  useEffect(() => {
    if (inspectedGoal?.id) {
      Promise.resolve().then(() => loadGoalSkillsAndGaps(inspectedGoal.id));
    }
  }, [inspectedGoal?.id, loadGoalSkillsAndGaps]);

  const handleCreate = async (payload) => {
    setBusy(true);
    try {
      const { ok, data } = await api.createGoal(payload);
      if (!ok) {
        notify("error", errorMessage(data, "Could not create the goal."));
        return;
      }
      notify("success", data?.message || "Goal created.");
      setShowCreate(false);
      onGoalSaved?.(data.goal);
      if (data.goal?.id) {
        onSelectGoal?.(data.goal.id);
        loadGoalSkillsAndGaps(data.goal.id);
      }
    } catch {
      notify("error", "Could not connect to the GrowthAI server.");
    } finally {
      setBusy(false);
    }
  };

  const handleUpdate = async (goalId, payload) => {
    setBusy(true);
    try {
      const { ok, data } = await api.updateGoal(goalId, payload);
      if (!ok) {
        notify("error", errorMessage(data, "Could not update the goal."));
        return;
      }
      notify("success", "Goal updated.");
      setEditingId(null);
      onGoalSaved?.(data.goal);
    } catch {
      notify("error", "Could not connect to the GrowthAI server.");
    } finally {
      setBusy(false);
    }
  };

  const handleQuickStatusChange = async (goal, nextStatus) => {
    await handleUpdate(goal.id, { status: nextStatus });
  };

  const filteredGoals = goals.filter((goal) => {
    if (statusFilter === "all") return true;
    return String(goal.status || "active").toLowerCase() === statusFilter;
  });

  // Merge skills metadata (description, category) with skill-gaps assessment scores
  const descById = new Map(skillsData.map((s) => [s.id, s]));
  const mergedSkills =
    gapsData.length > 0
      ? gapsData.map((gap) => ({
          ...descById.get(gap.skill_id),
          ...gap,
          id: gap.skill_id,
        }))
      : skillsData.map((s) => ({
          ...s,
          skill_id: s.id,
          score_percentage: null,
          skill_level: null,
          gap_status: "not_assessed",
        }));

  const strongCount = mergedSkills.filter((s) => s.gap_status === "strong").length;
  const gapCount = mergedSkills.filter((s) => s.gap_status === "gap").length;
  const unassessedCount = mergedSkills.filter(
    (s) => s.gap_status === "not_assessed"
  ).length;

  return (
    <div className="page-stack">
      <section className="page-section">
        <SectionHeader
          kicker="Academic & Personal Direction"
          title="Goals & Skill Analysis"
          description="Define your learning objectives, inspect required skills, and track your progress from current skill levels to target mastery."
          actions={
            <button
              type="button"
              className="btn-primary"
              onClick={() => {
                setShowCreate((prev) => !prev);
                setEditingId(null);
              }}
              disabled={busy}
            >
              <IconPlus width={16} height={16} />
              {showCreate ? "Close form" : "New goal"}
            </button>
          }
        />

        {showCreate && (
          <GoalForm
            busy={busy}
            onCancel={() => setShowCreate(false)}
            onSubmit={handleCreate}
          />
        )}

        {goals.length > 0 && (
          <div className="filter-bar" role="tablist" aria-label="Filter goals by status">
            {["all", "active", "completed", "archived"].map((statusKey) => {
              const count =
                statusKey === "all"
                  ? goals.length
                  : goals.filter(
                      (g) => String(g.status || "active").toLowerCase() === statusKey
                    ).length;
              return (
                <button
                  key={statusKey}
                  type="button"
                  role="tab"
                  aria-selected={statusFilter === statusKey}
                  className={`filter-pill ${statusFilter === statusKey ? "active" : ""}`}
                  onClick={() => setStatusFilter(statusKey)}
                >
                  {statusKey.charAt(0).toUpperCase() + statusKey.slice(1)} ({count})
                </button>
              );
            })}
          </div>
        )}

        {goals.length === 0 ? (
          <EmptyState
            Icon={IconTarget}
            title="No learning goals yet"
            description="Create your first goal to unlock automatic skill mapping, diagnostic assessments, and daily study planning."
            action={
              <button
                type="button"
                className="btn-primary"
                onClick={() => setShowCreate(true)}
                disabled={busy}
              >
                <IconPlus width={15} height={15} />
                Create your first goal
              </button>
            }
          />
        ) : filteredGoals.length === 0 ? (
          <EmptyState
            Icon={IconTarget}
            title={`No ${statusFilter} goals`}
            description="Switch the status filter above to see your other goals."
            action={
              <button
                type="button"
                className="btn-secondary"
                onClick={() => setStatusFilter("all")}
              >
                Show all goals
              </button>
            }
          />
        ) : (
          <div className="goal-list">
            {filteredGoals.map((goal) => {
              const isSelected = goal.id === inspectedGoal?.id;
              const isEditing = goal.id === editingId;
              const status = String(goal.status || "active").toLowerCase();

              if (isEditing) {
                return (
                  <GoalForm
                    key={goal.id}
                    initial={goal}
                    busy={busy}
                    onCancel={() => setEditingId(null)}
                    onSubmit={(payload) => handleUpdate(goal.id, payload)}
                  />
                );
              }

              return (
                <article
                  className={`goal-card ${isSelected ? "selected-goal" : ""}`}
                  key={goal.id}
                >
                  <div className="goal-card-icon">
                    <IconTarget width={20} height={20} />
                  </div>

                  <div className="goal-card-body">
                    <div className="goal-card-meta">
                      <div className="goal-badges-row">
                        <Badge
                          variant={
                            status === "completed"
                              ? "mint"
                              : status === "archived"
                                ? "neutral"
                                : "primary"
                          }
                        >
                          {status}
                        </Badge>
                        {isSelected && (
                          <Badge variant="mint">Active workspace goal</Badge>
                        )}
                      </div>
                      {goal.target_date && (
                        <small className="goal-target-date">
                          Target: {formatDate(String(goal.target_date).slice(0, 10))}
                        </small>
                      )}
                    </div>

                    <h3>{goal.title}</h3>
                    <p>{goal.description || "No description provided."}</p>

                    <div className="goal-card-actions">
                      <button
                        type="button"
                        className={isSelected ? "btn-secondary" : "btn-primary"}
                        disabled={isSelected}
                        onClick={() => onSelectGoal?.(goal.id)}
                      >
                        {isSelected ? "Selected for workspace" : "Set as active goal"}
                      </button>

                      <button
                        type="button"
                        className="btn-ghost-sm"
                        onClick={() => {
                          setEditingId(goal.id);
                          setShowCreate(false);
                        }}
                        disabled={busy}
                      >
                        <IconEdit width={14} height={14} />
                        Edit
                      </button>

                      {status !== "completed" && (
                        <button
                          type="button"
                          className="btn-ghost-sm"
                          onClick={() => handleQuickStatusChange(goal, "completed")}
                          disabled={busy}
                        >
                          <IconCheck width={14} height={14} />
                          Mark complete
                        </button>
                      )}

                      {status !== "archived" ? (
                        <button
                          type="button"
                          className="btn-ghost-sm"
                          onClick={() => handleQuickStatusChange(goal, "archived")}
                          disabled={busy}
                          title="Archive this goal"
                        >
                          <IconArchive width={14} height={14} />
                          Archive
                        </button>
                      ) : (
                        <button
                          type="button"
                          className="btn-ghost-sm"
                          onClick={() => handleQuickStatusChange(goal, "active")}
                          disabled={busy}
                        >
                          Reactivate
                        </button>
                      )}
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>

      {/* Skills & Skill Gaps Section for the Selected Goal */}
      {inspectedGoal && (
        <section className="page-section">
          <SectionHeader
            kicker={`Skills for "${inspectedGoal.title}"`}
            title="Required Skills & Gap Analysis"
            description="Compare your current assessed skill levels against the target proficiency (Advanced · 70%+) required for this goal."
            actions={
              <div className="heading-actions">
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={() => loadGoalSkillsAndGaps(inspectedGoal.id)}
                  disabled={loadingSkills}
                >
                  <IconRefresh width={15} height={15} />
                  {loadingSkills ? "Refreshing..." : "Refresh skills"}
                </button>
                {onNavigate && (
                  <>
                    <button
                      type="button"
                      className="btn-secondary"
                      onClick={() => onNavigate("roadmap")}
                    >
                      <IconMap width={15} height={15} />
                      Skill Roadmap
                    </button>
                    <button
                      type="button"
                      className="btn-primary"
                      onClick={() => onNavigate("assessment")}
                    >
                      <IconBook width={15} height={15} />
                      Take Assessment
                    </button>
                  </>
                )}
              </div>
            }
          />

          {loadingSkills ? (
            <div className="insight-card">
              <p>Loading skills and assessment gap data…</p>
            </div>
          ) : mergedSkills.length === 0 ? (
            <div className="ai-prep-banner">
              <div className="ai-prep-icon">
                <IconSpark width={22} height={22} />
              </div>
              <div className="ai-prep-body">
                <h3>
                  {preparingSkills
                    ? "AI is mapping core skills for this goal…"
                    : "No skills mapped to this goal yet"}
                </h3>
                <p>
                  {preparingSkills
                    ? "For custom goal topics, GrowthAI generates testable skills and multiple-choice questions in the background. Click 'Refresh skills' in a moment."
                    : "Click 'Refresh skills' to check if background skill generation has completed, or try a built-in goal topic such as 'Become a Data Analyst'."}
                </p>
              </div>
              <button
                type="button"
                className="btn-primary"
                onClick={() => loadGoalSkillsAndGaps(inspectedGoal.id)}
              >
                <IconRefresh width={15} height={15} />
                Check now
              </button>
            </div>
          ) : (
            <>
              <div className="skill-gap-overview-bar">
                <div className="skill-gap-stat">
                  <span>Total Mapped Skills</span>
                  <strong>{mergedSkills.length}</strong>
                </div>
                <div className="skill-gap-stat">
                  <span>Target Met (Advanced · 70%+)</span>
                  <strong className="text-mint">{strongCount}</strong>
                </div>
                <div className="skill-gap-stat">
                  <span>Active Skill Gaps (&lt;70%)</span>
                  <strong className="text-warning">{gapCount}</strong>
                </div>
                <div className="skill-gap-stat">
                  <span>Awaiting Assessment</span>
                  <strong>{unassessedCount}</strong>
                </div>
              </div>

              <div className="skills-cards-grid">
                {mergedSkills.map((skill) => {
                  const isAssessed = skill.skill_level != null;
                  const score = isAssessed
                    ? Math.round(Number(skill.score_percentage) || 0)
                    : 0;
                  const gapPoints = isAssessed ? Math.max(0, 70 - score) : null;

                  return (
                    <div className="skill-detail-card" key={skill.id || skill.skill_id}>
                      <div className="skill-detail-top">
                        <div>
                          <span className="skill-category-label">
                            {skill.category || "Core Skill"}
                          </span>
                          <h4>{skill.name}</h4>
                        </div>
                        <Badge
                          variant={
                            skill.importance === "high"
                              ? "primary"
                              : skill.importance === "medium"
                                ? "info"
                                : "neutral"
                          }
                        >
                          {skill.importance || "medium"} priority
                        </Badge>
                      </div>

                      {skill.description && (
                        <p className="skill-detail-desc">{skill.description}</p>
                      )}

                      <div className="skill-levels-comparison">
                        <div>
                          <small>Current level</small>
                          <strong>
                            {isAssessed
                              ? `${skill.skill_level} (${score}%)`
                              : "Not assessed"}
                          </strong>
                        </div>
                        <IconArrow width={14} height={14} />
                        <div>
                          <small>Target level</small>
                          <strong>Advanced (70%+)</strong>
                        </div>
                      </div>

                      <ProgressBar
                        value={score}
                        max={100}
                        variant={
                          skill.gap_status === "strong"
                            ? "mint"
                            : isAssessed
                              ? "primary"
                              : "muted"
                        }
                        label={
                          skill.gap_status === "strong"
                            ? "Target proficiency achieved"
                            : isAssessed
                              ? `${gapPoints}% needed to reach Advanced target`
                              : "Take assessment to measure baseline"
                        }
                        showValue={isAssessed}
                      />

                      <div className="skill-detail-footer">
                        <Badge
                          variant={
                            skill.gap_status === "strong"
                              ? "mint"
                              : skill.gap_status === "gap"
                                ? "warning"
                                : "neutral"
                          }
                        >
                          {skill.gap_status === "strong"
                            ? "Strong · Mastered"
                            : skill.gap_status === "gap"
                              ? "Skill Gap · Focus Area"
                              : "Unassessed"}
                        </Badge>
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </section>
      )}
    </div>
  );
}
