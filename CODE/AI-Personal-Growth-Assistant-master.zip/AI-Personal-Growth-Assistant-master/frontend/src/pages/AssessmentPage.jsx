import { useCallback, useEffect, useRef, useState } from "react";
import { api, errorMessage } from "../api/client";
import ProgressRing from "../components/ProgressRing";
import { Badge, EmptyState, ProgressBar, SectionHeader } from "../components/ui";
import {
  IconAlert,
  IconArrow,
  IconBook,
  IconCheck,
  IconClock,
  IconInfo,
  IconMap,
  IconRefresh,
  IconSpark,
  IconTarget,
} from "../components/icons";

export default function AssessmentPage({
  activeGoal,
  goals = [],
  onSelectGoal,
  onNavigate,
  notify,
}) {
  const [skills, setSkills] = useState([]);
  const [skillGaps, setSkillGaps] = useState([]);
  const [preparingSkills, setPreparingSkills] = useState(false);
  const [loadingSkills, setLoadingSkills] = useState(false);

  const [attempt, setAttempt] = useState(null);
  const [timeLimitSeconds, setTimeLimitSeconds] = useState(null);
  const [questions, setQuestions] = useState([]);
  const [answers, setAnswers] = useState({});
  const [timings, setTimings] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [results, setResults] = useState(null);
  const [roadmap, setRoadmap] = useState([]);
  const [timeRemaining, setTimeRemaining] = useState(null);
  const [apiErrorBanner, setApiErrorBanner] = useState("");

  const questionShownAtRef = useRef({});
  const tabSwitchesRef = useRef(0);
  const attemptRef = useRef(null);
  const answersRef = useRef({});
  const timingsRef = useRef({});
  const questionsRef = useRef([]);
  const submittingRef = useRef(false);

  answersRef.current = answers;
  timingsRef.current = timings;
  questionsRef.current = questions;
  attemptRef.current = attempt;

  const loadSkillsAndStatus = useCallback(async () => {
    if (!activeGoal?.id) {
      setSkills([]);
      setSkillGaps([]);
      setPreparingSkills(false);
      return;
    }

    setLoadingSkills(true);
    setApiErrorBanner("");
    try {
      const [skillsRes, gapsRes] = await Promise.all([
        api.getGoalSkills(activeGoal.id),
        api.getSkillGaps(activeGoal.id),
      ]);

      if (skillsRes.ok) {
        setSkills(skillsRes.data?.skills || []);
        setPreparingSkills(Boolean(skillsRes.data?.preparing));
      } else {
        notify("error", errorMessage(skillsRes.data, "Could not load skills for this goal."));
      }

      if (gapsRes.ok) {
        setSkillGaps(gapsRes.data?.skills || []);
      }
    } catch {
      notify("error", "Could not connect to the GrowthAI server.");
    } finally {
      setLoadingSkills(false);
    }
  }, [activeGoal?.id, notify]);

  // Automatically load skill status when opening the page or switching active goal
  useEffect(() => {
    setAttempt(null);
    setQuestions([]);
    setResults(null);
    setAnswers({});
    setApiErrorBanner("");
    loadSkillsAndStatus();
  }, [activeGoal?.id, loadSkillsAndStatus]);

  // Integrity signal: count tab/window switches while an attempt is open.
  useEffect(() => {
    if (!attempt) return undefined;

    const handleVisibility = () => {
      if (document.visibilityState === "hidden") {
        tabSwitchesRef.current += 1;
        notify("warning", "Tab switch detected — this is recorded as an integrity signal.");
      }
    };

    document.addEventListener("visibilitychange", handleVisibility);
    return () => document.removeEventListener("visibilitychange", handleVisibility);
  }, [attempt, notify]);

  // Countdown from the server-computed budget.
  useEffect(() => {
    if (!attempt || timeLimitSeconds == null) return undefined;

    const startedAt = Date.now();
    const timer = setInterval(() => {
      const remaining = timeLimitSeconds - Math.floor((Date.now() - startedAt) / 1000);
      setTimeRemaining(Math.max(remaining, 0));
    }, 1000);
    setTimeRemaining(timeLimitSeconds);

    return () => clearInterval(timer);
  }, [attempt, timeLimitSeconds]);

  const startAssessment = async () => {
    if (!activeGoal?.id) return;

    setSubmitting(true);
    setApiErrorBanner("");
    try {
      const { ok, status, data } = await api.startAssessment(activeGoal.id);
      if (ok) {
        setAttempt(data.attempt_id);
        setQuestions(data.questions || []);
        setTimeLimitSeconds(data.time_limit_seconds ?? null);
        setAnswers({});
        setTimings({});
        setResults(null);
        questionShownAtRef.current = {};
        tabSwitchesRef.current = 0;
        if (data.resumed) {
          notify(
            "info",
            "Resumed your in-progress assessment. The original server time limit still applies."
          );
        }
      } else {
        const msg = errorMessage(data, "Could not start the assessment.");
        setApiErrorBanner(msg);
        notify(status === 409 ? "info" : "error", msg);
      }
    } catch {
      notify("error", "Could not connect to the GrowthAI server.");
    } finally {
      setSubmitting(false);
    }
  };

  const selectAnswer = (questionId, optionLetter) => {
    const firstShown = questionShownAtRef.current[questionId];
    const elapsed = firstShown ? Date.now() - firstShown : null;

    setAnswers((previous) => ({ ...previous, [questionId]: optionLetter }));
    setTimings((previous) => ({
      ...previous,
      // Keep the first measurement per question; later changes do not extend it.
      [questionId]:
        previous[questionId] ?? (elapsed != null ? Math.max(elapsed, 0) : null),
    }));
  };

  const markQuestionSeen = (questionId) => {
    if (questionShownAtRef.current[questionId] == null) {
      questionShownAtRef.current[questionId] = Date.now();
    }
  };

  const submitAllAndComplete = async () => {
    if (!attempt || submittingRef.current) return;

    const unanswered = questions.filter((q) => !answers[q.id]);
    if (unanswered.length > 0 && timeRemaining !== 0) {
      notify(
        "error",
        `Please answer all questions before submitting (${unanswered.length} remaining).`
      );
      return;
    }

    submittingRef.current = true;
    setSubmitting(true);
    setApiErrorBanner("");
    try {
      const answerPayload = questions
        .filter((q) => Boolean(answers[q.id]))
        .map((q) => ({
          question_id: q.id,
          selected_answer: answers[q.id],
          time_ms: timings[q.id] != null ? Math.round(timings[q.id]) : null,
        }));

      const { ok, data } = await api.submitAssessment(
        attempt,
        answerPayload,
        tabSwitchesRef.current
      );

      if (ok) {
        setResults(data);
        setAttempt(null);
        try {
          const [roadmapResponse, gapsResponse] = await Promise.all([
            api.getRoadmap(activeGoal.id),
            api.getSkillGaps(activeGoal.id),
          ]);
          setRoadmap(
            roadmapResponse.ok ? roadmapResponse.data?.roadmap || [] : []
          );
          if (gapsResponse.ok) {
            setSkillGaps(gapsResponse.data?.skills || []);
          }
        } catch {
          setRoadmap([]);
        }
        notify("success", "Assessment submitted and scored!");
      } else {
        const msg = errorMessage(data, "Could not submit the assessment.");
        setApiErrorBanner(msg);
        notify("error", msg);
      }
    } catch {
      notify("error", "Could not connect to the GrowthAI server.");
    } finally {
      submittingRef.current = false;
      setSubmitting(false);
    }
  };

  // Auto-submit once when the countdown reaches zero
  useEffect(() => {
    if (
      attempt &&
      timeRemaining === 0 &&
      !submittingRef.current &&
      !results
    ) {
      submitAllAndComplete();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [timeRemaining]);

  if (!activeGoal) {
    return (
      <section className="page-section">
        <EmptyState
          Icon={IconTarget}
          title="No active goal selected"
          description="Select or create a learning goal first, then return here to take its diagnostic skill assessment."
          action={
            <button
              type="button"
              className="btn-primary"
              onClick={() => onNavigate?.("goals")}
            >
              <IconTarget width={15} height={15} />
              Go to Goals &amp; Skills
            </button>
          }
        />
      </section>
    );
  }

  const gapMap = new Map(skillGaps.map((g) => [g.skill_id, g]));
  const skillNameMap = new Map(skills.map((s) => [s.id, s.name]));
  const answeredCount = Object.keys(answers).length;

  return (
    <div className="page-stack">
      <section className="page-section">
        <SectionHeader
          kicker={`Diagnostic Evaluation · ${activeGoal.title}`}
          title="Skill Assessment"
          description="Measure your current understanding across every core skill linked to your goal. Scores update your Skill Roadmap and Daily Planner automatically."
          actions={
            !attempt && (
              <div className="heading-actions">
                {goals.length > 1 && onSelectGoal && (
                  <select
                    className="select-compact"
                    value={activeGoal.id}
                    onChange={(e) => onSelectGoal(Number(e.target.value))}
                    aria-label="Switch goal for assessment"
                  >
                    {goals.map((g) => (
                      <option key={g.id} value={g.id}>
                        {g.title}
                      </option>
                    ))}
                  </select>
                )}
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={loadSkillsAndStatus}
                  disabled={loadingSkills || submitting}
                >
                  <IconRefresh width={15} height={15} />
                  {loadingSkills ? "Refreshing..." : "Refresh status"}
                </button>
              </div>
            )
          }
        />

        {apiErrorBanner && (
          <div className="auth-error-banner" role="alert">
            <IconAlert width={18} height={18} />
            <span>{apiErrorBanner}</span>
          </div>
        )}

        {/* STATE 1: Completed Assessment Results */}
        {results ? (
          <div className="assessment-results-stack">
            <div className="assessment-score-hero">
              <div className="assessment-score-ring">
                <ProgressRing
                  percent={results.overall_score_percentage}
                  size={140}
                  stroke={11}
                  variant={results.overall_score_percentage >= 70 ? "mint" : "blue"}
                  label="Overall assessment score"
                />
                <div className="hero-progress-center">
                  <strong>{Math.round(results.overall_score_percentage)}%</strong>
                  <span>overall</span>
                </div>
              </div>

              <div className="assessment-score-summary">
                <Badge variant="mint">Assessment Completed</Badge>
                <h3>
                  Overall Score: {results.overall_score_percentage}%
                </h3>
                <p>
                  Your skill levels have been saved to your profile and used to reprioritize your Skill Roadmap.
                </p>
                {results.integrity && (
                  <small className="integrity-note">
                    Integrity log: {results.integrity.tab_switches || 0} tab switches recorded (informational only).
                  </small>
                )}
                <div className="assessment-result-actions">
                  {onNavigate && (
                    <>
                      <button
                        type="button"
                        className="btn-primary"
                        onClick={() => onNavigate("roadmap")}
                      >
                        <IconMap width={15} height={15} />
                        Open Updated Skill Roadmap
                      </button>
                      <button
                        type="button"
                        className="btn-secondary"
                        onClick={() => onNavigate("tasks")}
                      >
                        Go to Daily Planner
                      </button>
                    </>
                  )}
                  <button
                    type="button"
                    className="btn-ghost-sm"
                    onClick={() => {
                      setResults(null);
                      setQuestions([]);
                    }}
                  >
                    Back to Assessment Overview
                  </button>
                </div>
              </div>
            </div>

            <div className="skills-cards-grid">
              {results.skills.map((skill) => {
                const pct = Math.round(Number(skill.score_percentage) || 0);
                return (
                  <div className="skill-detail-card" key={skill.skill_id}>
                    <div className="skill-detail-top">
                      <h4>{skill.skill_name || `Skill #${skill.skill_id}`}</h4>
                      <Badge
                        variant={
                          skill.skill_level === "advanced"
                            ? "mint"
                            : skill.skill_level === "intermediate"
                              ? "primary"
                              : "warning"
                        }
                      >
                        {skill.skill_level}
                      </Badge>
                    </div>
                    <p className="skill-detail-desc">
                      Answered {skill.correct_answers} of {skill.total_questions} questions correctly.
                    </p>
                    <ProgressBar
                      value={pct}
                      variant={pct >= 70 ? "mint" : "primary"}
                      label="Skill score"
                      showValue
                    />
                  </div>
                );
              })}
            </div>

            {roadmap.length > 0 && (
              <div className="panel">
                <div className="panel-header">
                  <div>
                    <span className="panel-kicker">Updated Learning Sequence</span>
                    <h3>Recommended next steps</h3>
                  </div>
                </div>
                <div className="roadmap-mini-list">
                  {roadmap.map((item) => (
                    <div className="roadmap-mini-row" key={item.skill_id}>
                      <span className="roadmap-mini-step">{item.step}</span>
                      <div className="roadmap-mini-info">
                        <strong>{item.name}</strong>
                        <p>{item.recommendation}</p>
                      </div>
                      <Badge
                        variant={
                          item.gap_status === "strong"
                            ? "mint"
                            : item.gap_status === "gap"
                              ? "warning"
                              : "neutral"
                        }
                      >
                        {item.skill_level || "not assessed"}
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : questions.length > 0 ? (
          /* STATE 2: Active Timed Assessment Session */
          <div
            className="assessment-active-session assessment-container"
            onCopy={(e) => e.preventDefault()}
            onCut={(e) => e.preventDefault()}
            onContextMenu={(e) => e.preventDefault()}
          >
            <div className="assessment-sticky-bar">
              <div className="assessment-progress-info">
                <strong>
                  Answered {answeredCount} of {questions.length} questions
                </strong>
                <ProgressBar
                  value={answeredCount}
                  max={questions.length}
                  variant="primary"
                  size="sm"
                />
              </div>

              {timeRemaining != null && (
                <div
                  className={`assessment-timer ${
                    timeRemaining <= 60 ? "warning" : ""
                  }`}
                  role="timer"
                  aria-live="polite"
                >
                  <IconClock width={16} height={16} />
                  <span>
                    Time remaining: {Math.floor(timeRemaining / 60)}:
                    {String(timeRemaining % 60).padStart(2, "0")}
                  </span>
                </div>
              )}
            </div>

            <div className="assessment-integrity-banner">
              <IconInfo width={15} height={15} />
              <span>
                Select one option per question. Options are randomized per attempt, and server time limits apply. Avoid switching browser tabs during the attempt.
              </span>
            </div>

            <div className="assessment-questions-list">
              {questions.map((q, index) => {
                markQuestionSeen(q.id);
                const selectedLetter = answers[q.id];
                const skillLabel = skillNameMap.get(q.skill_id);

                return (
                  <article className="question-card" key={q.id}>
                    <div className="question-card-header">
                      <span className="question-number">
                        Question {index + 1} of {questions.length}
                      </span>
                      <div className="question-badges">
                        {skillLabel && <Badge variant="info">{skillLabel}</Badge>}
                        {q.difficulty && (
                          <Badge variant="neutral">{q.difficulty}</Badge>
                        )}
                      </div>
                    </div>

                    <h3 className="question-prompt">{q.question}</h3>

                    <div
                      className="mcq-options-grid"
                      role="radiogroup"
                      aria-label={`Question ${index + 1} options`}
                    >
                      {q.options.map((option) => {
                        const isSelected = selectedLetter === option.letter;
                        return (
                          <button
                            key={option.letter}
                            type="button"
                            role="radio"
                            aria-checked={isSelected}
                            className={`mcq-option-btn ${
                              isSelected ? "selected" : ""
                            }`}
                            onClick={() => selectAnswer(q.id, option.letter)}
                          >
                            <span className="mcq-option-letter">
                              {option.letter.toUpperCase()}
                            </span>
                            <span className="mcq-option-text">{option.text}</span>
                            {isSelected && (
                              <span className="mcq-option-check">
                                <IconCheck width={15} height={15} />
                              </span>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  </article>
                );
              })}
            </div>

            <div className="assessment-submit-bar">
              <div>
                <strong>
                  {answeredCount === questions.length
                    ? "All questions answered! Ready to submit."
                    : `${questions.length - answeredCount} question${
                        questions.length - answeredCount === 1 ? "" : "s"
                      } remaining`}
                </strong>
              </div>
              <button
                type="button"
                className="btn-primary btn-lg"
                disabled={submitting || answeredCount < questions.length}
                onClick={submitAllAndComplete}
              >
                {submitting ? "Submitting & Scoring..." : "Submit Assessment"}
                {!submitting && <IconArrow width={16} height={16} />}
              </button>
            </div>
          </div>
        ) : (
          /* STATE 3: Pre-Assessment Overview & Skill Status */
          <div className="assessment-overview-card">
            <div className="assessment-intro-box">
              <div className="assessment-intro-icon">
                <IconBook width={24} height={24} />
              </div>
              <div className="assessment-intro-text">
                <h3>Ready to evaluate your skills for &ldquo;{activeGoal.title}&rdquo;?</h3>
                <p>
                  This assessment tests your core skills with multiple-choice questions. You have 2 minutes per question (plus a 30-second grace window) and up to 5 attempts per goal.
                </p>
              </div>
              <button
                type="button"
                className="btn-primary btn-lg"
                onClick={startAssessment}
                disabled={submitting || loadingSkills || skills.length === 0}
              >
                <IconSpark width={16} height={16} />
                {submitting ? "Starting..." : "Start Skill Assessment"}
              </button>
            </div>

            {loadingSkills ? (
              <p className="panel-description">Loading required skills for this goal…</p>
            ) : skills.length === 0 ? (
              <div className="ai-prep-banner">
                <div className="ai-prep-icon">
                  <IconSpark width={22} height={22} />
                </div>
                <div className="ai-prep-body">
                  <h4>
                    {preparingSkills
                      ? "AI is generating skills & assessment questions in the background…"
                      : "No skills are linked to this goal yet"}
                  </h4>
                  <p>
                    {preparingSkills
                      ? "Wait about a minute for question validation to complete, then click 'Refresh status'."
                      : "Click 'Refresh status' to check if skills are ready, or manage your goal on the Goals & Skills page."}
                  </p>
                </div>
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={loadSkillsAndStatus}
                >
                  <IconRefresh width={15} height={15} />
                  Refresh status
                </button>
              </div>
            ) : (
              <div className="assessment-skills-preview">
                <div className="subsection-header">
                  <h4>Skills covered in this assessment ({skills.length})</h4>
                  <button
                    type="button"
                    className="btn-ghost-sm"
                    onClick={loadSkillsAndStatus}
                    disabled={loadingSkills}
                  >
                    Refresh
                  </button>
                </div>

                <div className="skills-cards-grid">
                  {skills.map((s) => {
                    const gap = gapMap.get(s.id);
                    const isAssessed = gap?.skill_level != null;
                    const score = isAssessed
                      ? Math.round(Number(gap.score_percentage) || 0)
                      : null;

                    return (
                      <div className="skill-detail-card" key={s.id}>
                        <div className="skill-detail-top">
                          <div>
                            <span className="skill-category-label">
                              {s.category || "Skill"}
                            </span>
                            <h4>{s.name}</h4>
                          </div>
                          <Badge
                            variant={
                              s.importance === "high"
                                ? "primary"
                                : s.importance === "medium"
                                  ? "info"
                                  : "neutral"
                            }
                          >
                            {s.importance}
                          </Badge>
                        </div>

                        {s.description && (
                          <p className="skill-detail-desc">{s.description}</p>
                        )}

                        <div className="skill-detail-footer">
                          <Badge
                            variant={
                              gap?.gap_status === "strong"
                                ? "mint"
                                : isAssessed
                                  ? "warning"
                                  : "neutral"
                            }
                          >
                            {isAssessed
                              ? `Current: ${gap.skill_level} (${score}%)`
                              : "Not yet assessed"}
                          </Badge>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}
      </section>
    </div>
  );
}
