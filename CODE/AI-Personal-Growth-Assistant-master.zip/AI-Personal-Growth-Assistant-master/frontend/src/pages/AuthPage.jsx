import { useState } from "react";
import {
  IconAlert,
  IconArrow,
  IconBook,
  IconCalendar,
  IconCheck,
  IconClock,
  IconEye,
  IconEyeOff,
  IconLock,
  IconMail,
  IconSpark,
  IconTarget,
  IconUser,
  IconUserPlus,
} from "../components/icons";

export default function AuthPage({ loading, notify, onLogin, onRegister }) {
  const [showRegister, setShowRegister] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [formError, setFormError] = useState("");

  const hasMinLen = password.length >= 8;
  const hasLetter = /[a-zA-Z]/.test(password);
  const hasDigit = /\d/.test(password);

  const validateForm = () => {
    const cleanEmail = email.trim();
    const cleanName = name.trim();

    if (showRegister && !cleanName) {
      return "Please enter your full name.";
    }
    if (!cleanEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      return "Please enter a valid email address.";
    }
    if (!password) {
      return "Please enter your password.";
    }
    if (showRegister) {
      if (!hasMinLen) {
        return "Password must be at least 8 characters long.";
      }
      if (!hasLetter) {
        return "Password must contain at least one letter.";
      }
      if (!hasDigit) {
        return "Password must contain at least one number.";
      }
    }
    return "";
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (loading) return;

    const validationMessage = validateForm();
    if (validationMessage) {
      setFormError(validationMessage);
      return;
    }

    setFormError("");

    if (showRegister) {
      onRegister({
        name,
        email,
        password,
        onSuccess: () => {
          setShowRegister(false);
          setName("");
          setPassword("");
          setFormError("");
        },
        onError: (msg) => setFormError(msg),
      });
      return;
    }

    onLogin({
      email,
      password,
      onSuccess: () => {
        setPassword("");
        setFormError("");
      },
      onError: (msg) => setFormError(msg),
    });
  };

  const handleLoadDemo = () => {
    setEmail("demo2026@gmail.com");
    setPassword("Demo@123");
    setShowRegister(false);
    setFormError("");
    notify("info", "Demo credentials filled in. Click Sign in to continue.");
  };

  return (
    <div className="auth-layout">
      <section className="auth-brand-panel" aria-label="About GrowthAI">
        <div className="auth-brand-top">
          <div className="logo">
            <div className="logo-mark">
              <IconSpark width={17} height={17} />
            </div>
            <div>
              <strong>GrowthAI</strong>
              <span className="logo-sub">Student Study Companion</span>
            </div>
          </div>
        </div>

        <div className="auth-brand-body">
          <span className="auth-pill">
            <IconSpark width={13} height={13} />
            Structured learning &amp; daily focus
          </span>

          <h1>
            Study with clarity.
            <br />
            <span>Grow one skill at a time.</span>
          </h1>

          <p className="auth-lead">
            A calm, structured workspace that maps your learning goals into
            measurable skills, diagnostic assessments, and realistic daily study
            plans.
          </p>

          <div className="auth-workflow-cards">
            <div className="auth-workflow-item">
              <div className="auth-workflow-icon blue">
                <IconTarget width={18} height={18} />
              </div>
              <div>
                <strong>1. Define goals &amp; map core skills</strong>
                <p>
                  Break broad academic or career goals into concrete, testable
                  skills.
                </p>
              </div>
            </div>

            <div className="auth-workflow-item">
              <div className="auth-workflow-icon mint">
                <IconBook width={18} height={18} />
              </div>
              <div>
                <strong>2. Diagnose your current level</strong>
                <p>
                  Take timed skill assessments to identify your strong areas and
                  priority gaps.
                </p>
              </div>
            </div>

            <div className="auth-workflow-item">
              <div className="auth-workflow-icon blue">
                <IconCalendar width={18} height={18} />
              </div>
              <div>
                <strong>3. Plan &amp; adapt to your energy</strong>
                <p>
                  Generate daily tasks sized to your available study minutes and
                  energy check-in.
                </p>
              </div>
            </div>

            <div className="auth-workflow-item">
              <div className="auth-workflow-icon mint">
                <IconClock width={18} height={18} />
              </div>
              <div>
                <strong>4. Focus &amp; log real progress</strong>
                <p>
                  Use the distraction-free timer and track real completion
                  history over time.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="auth-brand-footer">
          <div className="auth-trust-row">
            <span>
              <IconCheck width={14} height={14} /> Real database-backed progress
            </span>
            <span>
              <IconCheck width={14} height={14} /> Adaptive difficulty engine
            </span>
            <span>
              <IconCheck width={14} height={14} /> Private student workspace
            </span>
          </div>
        </div>
      </section>

      <section className="auth-form-panel" aria-label="Authentication form">
        <div className="auth-card">
          <div className="mobile-logo">
            <div className="logo-mark">
              <IconSpark width={16} height={16} />
            </div>
            <strong>GrowthAI</strong>
          </div>

          <div className="auth-mode-tabs" role="tablist" aria-label="Account access">
            <button
              type="button"
              role="tab"
              aria-selected={!showRegister}
              className={`auth-mode-tab ${!showRegister ? "active" : ""}`}
              onClick={() => {
                setShowRegister(false);
                setFormError("");
              }}
              disabled={loading}
            >
              Sign in
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={showRegister}
              className={`auth-mode-tab ${showRegister ? "active" : ""}`}
              onClick={() => {
                setShowRegister(true);
                setFormError("");
              }}
              disabled={loading}
            >
              Create account
            </button>
          </div>

          <div className="welcome">
            <div className="welcome-icon">
              {showRegister ? (
                <IconUserPlus width={22} height={22} />
              ) : (
                <IconUser width={22} height={22} />
              )}
            </div>

            <h2>{showRegister ? "Create your student account" : "Welcome back"}</h2>

            <p>
              {showRegister
                ? "Set up your personal workspace to start tracking goals, skills, and daily study sessions."
                : "Sign in to access your study plan, skill roadmap, and progress insights."}
            </p>
          </div>

          {formError && (
            <div className="auth-error-banner" role="alert">
              <IconAlert width={17} height={17} />
              <span>{formError}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} noValidate>
            {showRegister && (
              <div className="input-group">
                <label htmlFor="name">Full name</label>
                <div className="input-wrapper">
                  <span className="input-icon">
                    <IconUser width={16} height={16} />
                  </span>
                  <input
                    id="name"
                    type="text"
                    autoComplete="name"
                    placeholder="e.g. Aarav Sharma"
                    value={name}
                    onChange={(e) => {
                      setName(e.target.value);
                      if (formError) setFormError("");
                    }}
                    disabled={loading}
                    required
                  />
                </div>
              </div>
            )}

            <div className="input-group">
              <label htmlFor="email">Email address</label>
              <div className="input-wrapper">
                <span className="input-icon">
                  <IconMail width={16} height={16} />
                </span>
                <input
                  id="email"
                  type="email"
                  autoComplete="email"
                  placeholder="you@university.edu"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    if (formError) setFormError("");
                  }}
                  disabled={loading}
                  required
                />
              </div>
            </div>

            <div className="input-group">
              <label htmlFor="password">Password</label>
              <div className="password-wrapper">
                <span className="input-icon">
                  <IconLock width={16} height={16} />
                </span>
                <input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  autoComplete={showRegister ? "new-password" : "current-password"}
                  placeholder={
                    showRegister
                      ? "8+ characters with a letter & number"
                      : "Enter your password"
                  }
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (formError) setFormError("");
                  }}
                  disabled={loading}
                  required
                />
                <button
                  type="button"
                  className="password-toggle"
                  onClick={() => setShowPassword((prev) => !prev)}
                  aria-label={showPassword ? "Hide password" : "Show password"}
                  disabled={loading}
                >
                  {showPassword ? (
                    <IconEyeOff width={16} height={16} />
                  ) : (
                    <IconEye width={16} height={16} />
                  )}
                </button>
              </div>

              {showRegister && (
                <div className="password-requirements" aria-live="polite">
                  <span className={hasMinLen ? "met" : ""}>
                    <IconCheck width={12} height={12} /> 8+ characters
                  </span>
                  <span className={hasLetter ? "met" : ""}>
                    <IconCheck width={12} height={12} /> At least 1 letter
                  </span>
                  <span className={hasDigit ? "met" : ""}>
                    <IconCheck width={12} height={12} /> At least 1 number
                  </span>
                </div>
              )}
            </div>

            <button type="submit" className="login-button" disabled={loading}>
              <span>
                {loading
                  ? showRegister
                    ? "Creating account..."
                    : "Signing in..."
                  : showRegister
                    ? "Create account"
                    : "Sign in to workspace"}
              </span>
              {!loading && <IconArrow width={17} height={17} />}
            </button>
          </form>

          <div className="divider">
            <span>or quick access</span>
          </div>

          <button
            type="button"
            className="demo-button"
            onClick={handleLoadDemo}
            disabled={loading}
          >
            <IconSpark width={16} height={16} />
            Fill demo student credentials
          </button>

          <div className="switch-mode">
            <span>
              {showRegister
                ? "Already have a GrowthAI account?"
                : "New to GrowthAI?"}
            </span>
            <button
              type="button"
              disabled={loading}
              onClick={() => {
                setShowRegister((previous) => !previous);
                setName("");
                setPassword("");
                setFormError("");
                setShowPassword(false);
              }}
            >
              {showRegister ? "Sign in instead" : "Create an account"}
            </button>
          </div>

          <div className="security-note">
            <IconLock width={13} height={13} />
            <span>Authenticated via JWT · Data stored in your PostgreSQL workspace</span>
          </div>
        </div>
      </section>
    </div>
  );
}
