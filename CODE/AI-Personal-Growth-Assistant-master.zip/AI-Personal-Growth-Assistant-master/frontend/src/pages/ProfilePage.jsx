import { useEffect, useState } from "react";
import { api, errorMessage } from "../api/client";
import { Badge, SectionHeader } from "../components/ui";
import {
  IconCheck,
  IconClock,
  IconLock,
  IconLogout,
  IconSpark,
  IconTarget,
} from "../components/icons";

const EMPTY_PROFILE = {
  age: "",
  occupation: "",
  daily_available_minutes: "60",
  productive_time: "",
  sleep_hours: "",
  distraction_level: "",
  procrastination_level: "",
  challenges: "",
};

const QUICK_MINUTES = [30, 45, 60, 90, 120, 180];

export default function ProfilePage({
  loggedInUser,
  notify,
  onContinue,
  onLogout,
}) {
  const [profile, setProfile] = useState(EMPTY_PROFILE);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [hasProfile, setHasProfile] = useState(false);

  useEffect(() => {
    let cancelled = false;
    async function loadProfile() {
      setLoading(true);
      const { ok, data } = await api.getProfile();
      if (cancelled) return;
      if (!ok) {
        notify("error", errorMessage(data, "Could not load your profile."));
      } else if (data?.profile) {
        setProfile({
          ...EMPTY_PROFILE,
          ...data.profile,
          age: data.profile.age ?? "",
          sleep_hours: data.profile.sleep_hours ?? "",
          daily_available_minutes: data.profile.daily_available_minutes ?? 60,
        });
        setHasProfile(true);
      }
      setLoading(false);
    }
    loadProfile();
    return () => {
      cancelled = true;
    };
  }, [notify]);

  const update = (event) => {
    setProfile((current) => ({
      ...current,
      [event.target.name]: event.target.value,
    }));
  };

  const save = async (event) => {
    event.preventDefault();
    const mins = Number(profile.daily_available_minutes);
    if (!mins || mins < 5) {
      notify("error", "Daily available study minutes must be at least 5 minutes.");
      return;
    }

    setSaving(true);
    try {
      const payload = {
        ...profile,
        age: profile.age === "" ? null : Number(profile.age),
        daily_available_minutes: mins,
        sleep_hours:
          profile.sleep_hours === "" ? null : Number(profile.sleep_hours),
      };
      const { ok, data } = await api.saveProfile(payload);
      if (ok) {
        setHasProfile(true);
        notify("success", data?.message || "Profile saved successfully.");
      } else {
        notify("error", errorMessage(data, "Could not save your profile."));
      }
    } catch {
      notify("error", "Could not connect to the GrowthAI server.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="page-stack">
      <section className="page-section">
        <SectionHeader
          kicker="Account & Study Preferences"
          title="Settings & Profile"
          description="Configure your daily study capacity, peak focus hours, and routine preferences so GrowthAI can size your daily plans accurately."
        />

        {/* Account Identity Card */}
        <div className="profile-card">
          <div className="profile-avatar" aria-hidden="true">
            {loggedInUser?.name?.charAt(0)?.toUpperCase() || "S"}
          </div>

          <div className="profile-info">
            <div className="profile-badge-row">
              <Badge variant="mint">Verified Student Account</Badge>
              {hasProfile && <Badge variant="primary">Routine Configured</Badge>}
            </div>
            <h3>{loggedInUser?.name || "Student"}</h3>
            <p>{loggedInUser?.email || ""}</p>
          </div>

          {onLogout && (
            <button
              type="button"
              className="btn-secondary"
              onClick={onLogout}
            >
              <IconLogout width={16} height={16} />
              Sign out
            </button>
          )}
        </div>

        {/* Study Routine & Capacity Form */}
        <form className="card-form" onSubmit={save}>
          <div className="card-form-header">
            <h3>Study Routine &amp; Capacity</h3>
            <p>
              Your <strong>Daily available minutes</strong> and{" "}
              <strong>Productive time</strong> are used directly by the Daily
              Plan Generator and ML Completion Predictor.
            </p>
          </div>

          <div className="form-grid">
            <div className="form-row">
              <label className="form-field">
                <span>Role / Occupation</span>
                <input
                  name="occupation"
                  maxLength="100"
                  value={profile.occupation}
                  onChange={update}
                  placeholder="e.g. Undergraduate Student, Medical Aspirant"
                  disabled={loading || saving}
                />
              </label>

              <label className="form-field">
                <span>Age (optional)</span>
                <input
                  name="age"
                  type="number"
                  min="10"
                  max="120"
                  value={profile.age}
                  onChange={update}
                  placeholder="e.g. 20"
                  disabled={loading || saving}
                />
              </label>
            </div>

            <div className="form-row">
              <div className="form-field">
                <label htmlFor="daily_available_minutes">
                  <span>Daily available study minutes *</span>
                </label>
                <input
                  id="daily_available_minutes"
                  name="daily_available_minutes"
                  type="number"
                  min="5"
                  max="720"
                  value={profile.daily_available_minutes}
                  onChange={update}
                  disabled={loading || saving}
                  required
                />
                <div className="quick-Preset-chips">
                  {QUICK_MINUTES.map((mins) => (
                    <button
                      key={mins}
                      type="button"
                      className={`chip-button ${
                        Number(profile.daily_available_minutes) === mins
                          ? "active"
                          : ""
                      }`}
                      onClick={() =>
                        setProfile((curr) => ({
                          ...curr,
                          daily_available_minutes: String(mins),
                        }))
                      }
                      disabled={loading || saving}
                    >
                      <IconClock width={12} height={12} /> {mins}m
                    </button>
                  ))}
                </div>
              </div>

              <label className="form-field">
                <span>Peak productive time of day</span>
                <select
                  name="productive_time"
                  value={profile.productive_time}
                  onChange={update}
                  disabled={loading || saving}
                >
                  <option value="">Choose a time window</option>
                  <option value="Early morning">Early morning (5am – 8am)</option>
                  <option value="Morning">Morning (8am – 12pm)</option>
                  <option value="Afternoon">Afternoon (12pm – 5pm)</option>
                  <option value="Evening">Evening (5pm – 9pm)</option>
                  <option value="Night">Night (9pm+)</option>
                  <option value="Flexible">Flexible</option>
                </select>
              </label>
            </div>

            <div className="form-row">
              <label className="form-field">
                <span>Average sleep hours / night</span>
                <input
                  name="sleep_hours"
                  type="number"
                  min="0"
                  max="24"
                  step="0.5"
                  value={profile.sleep_hours}
                  onChange={update}
                  placeholder="e.g. 7.5"
                  disabled={loading || saving}
                />
              </label>

              <label className="form-field">
                <span>Typical distraction level</span>
                <select
                  name="distraction_level"
                  value={profile.distraction_level}
                  onChange={update}
                  disabled={loading || saving}
                >
                  <option value="">Select distraction level</option>
                  <option value="Low">Low</option>
                  <option value="Moderate">Moderate</option>
                  <option value="High">High</option>
                </select>
              </label>

              <label className="form-field">
                <span>Typical procrastination tendency</span>
                <select
                  name="procrastination_level"
                  value={profile.procrastination_level}
                  onChange={update}
                  disabled={loading || saving}
                >
                  <option value="">Select tendency</option>
                  <option value="Low">Low</option>
                  <option value="Moderate">Moderate</option>
                  <option value="High">High</option>
                </select>
              </label>
            </div>

            <label className="form-field">
              <span>Main study challenges or friction points</span>
              <textarea
                name="challenges"
                rows="3"
                value={profile.challenges}
                onChange={update}
                placeholder="What tends to interrupt your study consistency? (e.g. context switching, evening fatigue, exam anxiety)"
                disabled={loading || saving}
              />
            </label>
          </div>

          <div className="form-actions">
            <button
              className="btn-primary"
              type="submit"
              disabled={loading || saving}
            >
              <IconCheck width={15} height={15} />
              {saving
                ? "Saving changes…"
                : hasProfile
                  ? "Save profile settings"
                  : "Create study profile"}
            </button>

            {hasProfile && onContinue && (
              <button
                className="btn-secondary"
                type="button"
                onClick={onContinue}
              >
                <IconTarget width={15} height={15} />
                Continue to Goals &amp; Skills
              </button>
            )}

            {loading && (
              <span className="form-context">Loading your profile…</span>
            )}
          </div>
        </form>

        {/* Privacy & Workspace Information */}
        <div className="profile-note-grid">
          <div className="profile-note">
            <IconSpark width={19} height={19} />
            <div>
              <strong>How your profile shapes your plan</strong>
              <p>
                When you click &ldquo;Generate Today&apos;s Plan&rdquo;, GrowthAI
                caps the total duration of generated tasks at your{" "}
                <strong>
                  {profile.daily_available_minutes || 60} available minutes
                </strong>{" "}
                so your daily schedule stays realistic.
              </p>
            </div>
          </div>

          <div className="profile-note">
            <IconLock width={19} height={19} />
            <div>
              <strong>Account security &amp; privacy</strong>
              <p>
                Your goals, assessment attempts, task logs, and energy check-ins
                are scoped strictly to your authenticated user ID (`#{loggedInUser?.id || "—"}`).
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
