import { useEffect, useMemo, useState } from "react";
import { api, normalizeArray } from "../api/client";
import { formatEnergyLabel } from "../constants";
import ProgressRing from "../components/ProgressRing";
import { Badge, EmptyState, ProgressBar, SectionHeader } from "../components/ui";
import {
  IconBolt,
  IconBook,
  IconClock,
  IconTarget,
} from "../components/icons";

const RANGE_OPTIONS = [
  { key: "7", label: "Last 7 days", days: 7 },
  { key: "14", label: "Last 14 days", days: 14 },
  { key: "30", label: "Last 30 days", days: 30 },
  { key: "all", label: "All time", days: null },
];

export default function ProgressPage({
  completionPercent,
  completedTasks,
  todayTasks,
  allTasks = [],
  taskLogs: initialTaskLogs = [],
  goals = [],
  activeGoal,
  currentEnergy,
  onSelectGoal,
  onNavigate,
}) {
  const [summary, setSummary] = useState(null);
  const [advice, setAdvice] = useState(null);
  const [habitSummary, setHabitSummary] = useState(null);
  const [logs, setLogs] = useState(initialTaskLogs);
  const [skillGaps, setSkillGaps] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);
  const [dateRangeKey, setDateRangeKey] = useState("7");

  const taskActivity = todayTasks
    .map((task) => `${task.id}:${task.status}`)
    .join("|");

  useEffect(() => {
    let cancelled = false;

    async function loadInsights() {
      setLoading(true);
      try {
        const requests = [
          api.getProcrastinationSummary(),
          api.getAdaptiveRecommendation(),
          api.getTaskLogs(),
          api.getProgressSummary(),
        ];
        if (activeGoal?.id) {
          requests.push(api.getSkillGaps(activeGoal.id));
        }

        const [
          summaryRes,
          adviceRes,
          logsRes,
          habitRes,
          gapsRes,
        ] = await Promise.all(requests);

        if (cancelled) return;

        setSummary(summaryRes.ok ? summaryRes.data : null);
        setAdvice(adviceRes.ok ? adviceRes.data : null);
        if (logsRes.ok) {
          setLogs(normalizeArray(logsRes.data, ["task_logs"]));
        }
        if (habitRes.ok) {
          setHabitSummary(habitRes.data);
        }
        if (gapsRes?.ok) {
          setSkillGaps(gapsRes.data?.skills || []);
        } else if (!activeGoal?.id) {
          setSkillGaps([]);
        }

        setLoadError(!summaryRes.ok && !adviceRes.ok);
      } catch {
        if (!cancelled) setLoadError(true);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    loadInsights();

    return () => {
      cancelled = true;
    };
  }, [completedTasks, taskActivity, activeGoal?.id]);

  // Filter taskLogs by selected dateRangeKey
  const selectedRange = RANGE_OPTIONS.find((r) => r.key === dateRangeKey) || RANGE_OPTIONS[0];

  const filteredLogs = useMemo(() => {
    if (!selectedRange.days) return logs;
    const cutoff = new Date();
    cutoff.setHours(0, 0, 0, 0);
    cutoff.setDate(cutoff.getDate() - (selectedRange.days - 1));
    return logs.filter((log) => {
      if (!log.logged_at) return false;
      const d = new Date(log.logged_at);
      return !Number.isNaN(d.getTime()) && d >= cutoff;
    });
  }, [logs, selectedRange.days]);

  // Build daily study activity series for the chart (real data only)
  const dailyChartSeries = useMemo(() => {
    const numDays = selectedRange.days ? Math.min(selectedRange.days, 14) : 7;
    const buckets = [];
    const now = new Date();

    for (let i = numDays - 1; i >= 0; i -= 1) {
      const d = new Date(now);
      d.setDate(now.getDate() - i);
      const yyyy = d.getFullYear();
      const mm = String(d.getMonth() + 1).padStart(2, "0");
      const dd = String(d.getDate()).padStart(2, "0");
      const dateStr = `${yyyy}-${mm}-${dd}`;
      const shortLabel = d.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
      });

      buckets.push({
        dateStr,
        shortLabel,
        minutes: 0,
        completedCount: 0,
        skippedCount: 0,
      });
    }

    const bucketMap = new Map(buckets.map((b) => [b.dateStr, b]));

    logs.forEach((log) => {
      if (!log.logged_at) return;
      const d = new Date(log.logged_at);
      if (Number.isNaN(d.getTime())) return;
      const yyyy = d.getFullYear();
      const mm = String(d.getMonth() + 1).padStart(2, "0");
      const dd = String(d.getDate()).padStart(2, "0");
      const key = `${yyyy}-${mm}-${dd}`;
      const bucket = bucketMap.get(key);
      if (!bucket) return;

      if (log.status === "completed") {
        bucket.completedCount += 1;
        bucket.minutes += Number(log.actual_minutes) || 0;
      } else if (log.status === "skipped" || log.status === "postponed") {
        bucket.skippedCount += 1;
      }
    });

    return buckets;
  }, [logs, selectedRange.days]);

  const maxDailyMinutes = Math.max(
    60,
    ...dailyChartSeries.map((d) => d.minutes)
  );

  const rangeStudyMinutes = filteredLogs
    .filter((l) => l.status === "completed")
    .reduce((sum, l) => sum + (Number(l.actual_minutes) || 0), 0);

  const rangeCompletedLogs = filteredLogs.filter(
    (l) => l.status === "completed"
  ).length;

  const rangeSkippedLogs = filteredLogs.filter(
    (l) => l.status === "skipped" || l.status === "postponed"
  ).length;

  const reasons = summary?.top_skip_reasons || [];
  const maxReasonCount = Math.max(1, ...reasons.map((r) => r.count || 0));

  const assessedSkills = skillGaps.filter((s) => s.score_percentage != null);
  const averageSkillScore =
    assessedSkills.length > 0
      ? Math.round(
          assessedSkills.reduce(
            (sum, s) => sum + (Number(s.score_percentage) || 0),
            0
          ) / assessedSkills.length
        )
      : null;

  const highestSkillScore =
    assessedSkills.length > 0
      ? Math.round(
          Math.max(...assessedSkills.map((s) => Number(s.score_percentage) || 0))
        )
      : null;

  const taskMap = new Map(
    (allTasks.length > 0 ? allTasks : todayTasks).map((t) => [t.id, t])
  );

  return (
    <div className="page-stack">
      <section className="page-section">
        <SectionHeader
          kicker="Historical Analytics & Learning Outcomes"
          title="Progress & Insights"
          description="Every chart and metric below is computed directly from your real task logs, skill assessments, and daily check-ins."
          actions={
            <div className="filter-bar" role="tablist" aria-label="Activity date range">
              {RANGE_OPTIONS.map((opt) => (
                <button
                  key={opt.key}
                  type="button"
                  role="tab"
                  aria-selected={dateRangeKey === opt.key}
                  className={`filter-pill ${dateRangeKey === opt.key ? "active" : ""}`}
                  onClick={() => setDateRangeKey(opt.key)}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          }
        />

        {loadError && (
          <div className="auth-error-banner" role="alert">
            <span>
              Could not load all insights from the server. Ensure FastAPI is running.
            </span>
          </div>
        )}

        {/* Today's Completion Hero */}
        <div className="progress-hero">
          <div className="progress-hero-ring">
            <ProgressRing
              percent={completionPercent}
              size={140}
              stroke={11}
              variant="mint"
              label="Today's completion percentage"
            />
            <div className="progress-ring-center">
              <strong>{completionPercent}%</strong>
              <span>today</span>
            </div>
          </div>

          <div className="progress-hero-text">
            <span className="panel-kicker">Today&apos;s Execution</span>
            <strong>
              {completedTasks} of {todayTasks.length} planned tasks completed
            </strong>
            <p>
              {todayTasks.length === 0
                ? "No tasks have been scheduled for today yet."
                : completedTasks === todayTasks.length
                  ? "Excellent work! You have finished every task scheduled for today."
                  : "Steady progress builds long-term retention. Focus on one task at a time."}
            </p>
          </div>
        </div>

        {/* Key Metric Cards with Explanations */}
        <div className="insight-grid insight-grid-4">
          <div className="insight-card">
            <span>Overall Completion Rate</span>
            <strong className="text-mint">
              {summary ? `${summary.completion_rate_percentage}%` : "—"}
            </strong>
            <small className="metric-explanation">
              {summary
                ? `${summary.completed} completed out of ${summary.total_tasks} total tasks.`
                : "Percentage of all scheduled tasks marked completed."}
            </small>
          </div>

          <div className="insight-card">
            <span>Study Time ({selectedRange.label})</span>
            <strong className="text-primary">{rangeStudyMinutes} min</strong>
            <small className="metric-explanation">
              Sum of verified study minutes recorded in task logs ({rangeCompletedLogs} completed sessions).
            </small>
          </div>

          <div className="insight-card">
            <span>Skip / Postpone Rate</span>
            <strong className="text-warning">
              {summary ? `${summary.skip_rate_percentage}%` : "—"}
            </strong>
            <small className="metric-explanation">
              {summary
                ? `${summary.skipped_or_postponed} tasks skipped or postponed (${rangeSkippedLogs} in selected period).`
                : "Used by the adaptive engine to calibrate daily task difficulty."}
            </small>
          </div>

          <div className="insight-card">
            <span>Habit Check-in Rate</span>
            <strong>
              {habitSummary ? `${habitSummary.completion_rate}%` : "—"}
            </strong>
            <small className="metric-explanation">
              {habitSummary
                ? `${habitSummary.completed} of ${habitSummary.total_progress_records} habit check-ins completed.`
                : "Consistency across your daily study habits."}
            </small>
          </div>
        </div>
      </section>

      {/* Chart 1: Daily Study Minutes & Task Activity Chart */}
      <section className="page-section">
        <SectionHeader
          kicker="Study Time & Task Outcomes"
          title="Daily Study Activity"
          description="Logged study minutes and completed tasks per day based on your real task logs."
        />

        <div className="chart-legend-row">
          <span className="legend-item">
            <span className="legend-swatch blue" /> Logged Study Minutes
          </span>
          <span className="legend-item">
            <span className="legend-swatch mint" /> Completed Tasks Count
          </span>
        </div>

        {logs.length === 0 ? (
          <EmptyState
            Icon={IconClock}
            title="No study sessions logged yet"
            description="Complete a task on the Daily Planner or save a Focus Mode session to populate your daily study chart."
            action={
              onNavigate && (
                <button
                  type="button"
                  className="btn-primary"
                  onClick={() => onNavigate("focus")}
                >
                  <IconClock width={15} height={15} />
                  Start a Focus Session
                </button>
              )
            }
          />
        ) : (
          <div
            className="bar-chart-container"
            role="region"
            aria-label="Daily study minutes bar chart"
          >
            <div className="bar-chart-columns">
              {dailyChartSeries.map((day) => {
                const heightPct =
                  day.minutes > 0
                    ? Math.max(8, Math.round((day.minutes / maxDailyMinutes) * 100))
                    : 0;
                return (
                  <div className="bar-chart-col" key={day.dateStr}>
                    <div className="bar-chart-value-top">
                      {day.minutes > 0 ? `${day.minutes}m` : ""}
                    </div>
                    <div className="bar-chart-track">
                      <div
                        className="bar-chart-fill"
                        style={{ height: `${heightPct}%` }}
                        title={`${day.shortLabel}: ${day.minutes} min studied, ${day.completedCount} completed`}
                      />
                    </div>
                    <span className="bar-chart-label">{day.shortLabel}</span>
                    <small className="bar-chart-sub">
                      {day.completedCount > 0
                        ? `${day.completedCount} done`
                        : "—"}
                    </small>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </section>

      {/* Chart 2: Skill Assessment Proficiency Breakdown */}
      <section className="page-section">
        <SectionHeader
          kicker="Diagnostic Assessment Results"
          title="Skill Proficiency & Mastery"
          description="Your latest verified assessment score for each skill linked to your active goal. A score of 70% or higher indicates Advanced mastery."
          actions={
            goals.length > 1 &&
            onSelectGoal &&
            activeGoal && (
              <select
                className="select-compact"
                value={activeGoal.id}
                onChange={(e) => onSelectGoal(Number(e.target.value))}
                aria-label="Select goal for skill results"
              >
                {goals.map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.title}
                  </option>
                ))}
              </select>
            )
          }
        />

        {!activeGoal ? (
          <EmptyState
            Icon={IconTarget}
            title="No active goal selected"
            description="Select a learning goal to inspect your skill assessment scores."
          />
        ) : loading ? (
          <div className="insight-card">
            <p>Loading skill assessment results…</p>
          </div>
        ) : skillGaps.length === 0 ? (
          <EmptyState
            Icon={IconBook}
            title="No skills mapped for this goal yet"
            description="Visit Goals & Skills to check skill preparation or take your first assessment."
            action={
              onNavigate && (
                <button
                  type="button"
                  className="btn-primary"
                  onClick={() => onNavigate("assessment")}
                >
                  <IconBook width={15} height={15} />
                  Go to Assessments
                </button>
              )
            }
          />
        ) : (
          <>
            <div className="insight-grid">
              <div className="insight-card">
                <span>Assessed Skills</span>
                <strong>
                  {assessedSkills.length} of {skillGaps.length}
                </strong>
                <small className="metric-explanation">
                  Skills with at least one completed diagnostic assessment for &ldquo;{activeGoal.title}&rdquo;.
                </small>
              </div>

              <div className="insight-card">
                <span>Average Skill Score</span>
                <strong className="text-primary">
                  {averageSkillScore != null ? `${averageSkillScore}%` : "Not assessed"}
                </strong>
                <small className="metric-explanation">
                  Mean score across all assessed skills for this goal.
                </small>
              </div>

              <div className="insight-card">
                <span>Highest Skill Score</span>
                <strong className="text-mint">
                  {highestSkillScore != null ? `${highestSkillScore}%` : "Not assessed"}
                </strong>
                <small className="metric-explanation">
                  Strongest topic area based on your latest assessment attempt.
                </small>
              </div>
            </div>

            <div className="skill-chart-list">
              {skillGaps.map((skill) => {
                const isAssessed = skill.score_percentage != null;
                const score = isAssessed
                  ? Math.round(Number(skill.score_percentage))
                  : 0;
                return (
                  <div className="skill-chart-row" key={skill.skill_id}>
                    <div className="skill-chart-header">
                      <div>
                        <strong>{skill.name}</strong>
                        <span className="skill-chart-cat">
                          {skill.category || "Core Skill"} · {skill.importance} importance
                        </span>
                      </div>
                      <div className="skill-chart-badges">
                        <Badge
                          variant={
                            skill.gap_status === "strong"
                              ? "mint"
                              : isAssessed
                                ? "warning"
                                : "neutral"
                          }
                        >
                          {isAssessed
                            ? `${skill.skill_level} · ${score}%`
                            : "Not assessed"}
                        </Badge>
                      </div>
                    </div>
                    <ProgressBar
                      value={score}
                      variant={
                        skill.gap_status === "strong"
                          ? "mint"
                          : isAssessed
                            ? "primary"
                            : "muted"
                      }
                      size="md"
                    />
                  </div>
                );
              })}
            </div>
          </>
        )}
      </section>

      {/* Procrastination & Adaptive Recommendation Section */}
      <section className="page-section">
        <SectionHeader
          kicker="Behavioral Patterns & Adaptive Engine"
          title="Skip Analysis & Adaptive Recommendation"
          description="Understand why tasks get skipped or postponed and how GrowthAI calibrates your recommended task difficulty."
        />

        <div className="dashboard-grid">
          <div className="panel">
            <div className="panel-header">
              <div>
                <span className="panel-kicker">Procrastination Summary</span>
                <h3>Top skip &amp; postpone reasons</h3>
              </div>
            </div>

            {reasons.length === 0 ? (
              <p className="panel-description">
                No skipped or postponed tasks have been logged yet. When you skip a task on the Daily Planner, your reason is recorded to surface friction patterns here.
              </p>
            ) : (
              <div className="skip-reasons-chart">
                {reasons.map((item) => (
                  <div className="skip-reason-bar-item" key={item.reason}>
                    <div className="skip-reason-bar-top">
                      <strong>{item.reason}</strong>
                      <span>
                        {item.count} {item.count === 1 ? "time" : "times"}
                      </span>
                    </div>
                    <ProgressBar
                      value={item.count}
                      max={maxReasonCount}
                      variant="warning"
                      size="sm"
                    />
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="panel">
            <div className="panel-header">
              <div>
                <span className="panel-kicker">Adaptive Calibration</span>
                <h3>Recommended difficulty today</h3>
              </div>
              <IconBolt width={18} height={18} />
            </div>

            <div className="adaptive-summary-box">
              <div className="adaptive-summary-row">
                <span>Recommended task difficulty:</span>
                <Badge
                  variant={
                    advice?.recommended_difficulty === "hard"
                      ? "primary"
                      : advice?.recommended_difficulty === "medium"
                        ? "mint"
                        : "warning"
                  }
                >
                  {advice?.recommended_difficulty || "medium"}
                </Badge>
              </div>

              <p className="adaptive-explanation">
                {advice?.explanation ||
                  "Check in your energy and log task outcomes to receive adaptive difficulty recommendations."}
              </p>

              <div className="adaptive-signals-grid">
                <div>
                  <small>Latest Energy Check-in</small>
                  <strong>
                    {formatEnergyLabel(advice?.latest_energy || currentEnergy)}
                  </strong>
                </div>
                <div>
                  <small>Historical Log Skip Rate</small>
                  <strong>
                    {advice?.skip_rate_percentage != null
                      ? `${advice.skip_rate_percentage}%`
                      : "0%"}
                  </strong>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Recent Task Log Table */}
        {filteredLogs.length > 0 && (
          <div className="panel" style={{ marginTop: 16 }}>
            <div className="panel-header">
              <div>
                <span className="panel-kicker">Detailed Log Records</span>
                <h3>
                  Study &amp; task outcome log ({filteredLogs.length} in{" "}
                  {selectedRange.label.toLowerCase()})
                </h3>
              </div>
            </div>

            <div className="table-responsive">
              <table className="ui-table">
                <thead>
                  <tr>
                    <th>Task</th>
                    <th>Outcome</th>
                    <th>Study Time</th>
                    <th>Notes / Reason</th>
                    <th>Recorded At</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredLogs.slice(0, 12).map((log) => {
                    const task = taskMap.get(log.task_id);
                    return (
                      <tr key={log.id}>
                        <td>
                          <strong>
                            {task ? task.title : `Task #${log.task_id}`}
                          </strong>
                        </td>
                        <td>
                          <Badge
                            variant={
                              log.status === "completed" ? "mint" : "warning"
                            }
                          >
                            {log.status}
                          </Badge>
                        </td>
                        <td>
                          {log.actual_minutes
                            ? `${log.actual_minutes} min`
                            : "—"}
                        </td>
                        <td>{log.reason || "—"}</td>
                        <td>
                          {log.logged_at
                            ? new Date(log.logged_at).toLocaleString("en-US", {
                                month: "short",
                                day: "numeric",
                                hour: "2-digit",
                                minute: "2-digit",
                              })
                            : "—"}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
