const API_BASE =
  import.meta.env.VITE_API_URL || "http://127.0.0.1:8000";

const TOKEN_KEY = "growthai_token";

export function getToken() {
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setToken(token) {
  try {
    if (token) {
      localStorage.setItem(TOKEN_KEY, token);
    } else {
      localStorage.removeItem(TOKEN_KEY);
    }
  } catch {
    /* storage unavailable; session just won't persist */
  }
}

async function safeJson(response) {
  try {
    return await response.json();
  } catch {
    return null;
  }
}

function buildQuery(params = {}) {
  const search = new URLSearchParams();

  Object.entries(params).forEach(([key, value]) => {
    if (value === undefined || value === null) return;
    search.set(key, String(value));
  });

  const query = search.toString();
  return query ? `?${query}` : "";
}

export async function apiRequest(
  path,
  { method = "GET", body = undefined, query = undefined } = {}
) {
  const url = `${API_BASE}${path}${buildQuery(query)}`;

  const token = getToken();

  try {
    const headers = {
      Accept: "application/json",
    };

    if (token) {
      headers.Authorization = `Bearer ${token}`;
    }

    if (body !== undefined) {
      headers["Content-Type"] = "application/json";
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 90000);
    let response;
    try {
      response = await fetch(url, {
        method,
        headers,
        body: body !== undefined ? JSON.stringify(body) : undefined,
        signal: controller.signal,
      });
    } finally {
      clearTimeout(timeoutId);
    }

    const data = await safeJson(response);

    return {
      ok: response.ok,
      status: response.status,
      data,
    };
  } catch (error) {
    console.error("API request failed:", error);

    return {
      ok: false,
      status: 0,
      data: {
        message:
          "GrowthAI server is unreachable. Start FastAPI and try again.",
      },
    };
  }
}

export function normalizeArray(data, keys = []) {
  if (Array.isArray(data)) {
    return data;
  }

  for (const key of keys) {
    if (Array.isArray(data?.[key])) {
      return data[key];
    }
  }

  return [];
}

export function errorMessage(data, fallback = "Something went wrong.") {
  if (typeof data?.detail === "string") {
    return data.detail;
  }

  if (Array.isArray(data?.detail)) {
    return data.detail
      .map((item) => item?.msg)
      .filter(Boolean)
      .join(", ");
  }

  if (data?.message) {
    return data.message;
  }

  return fallback;
}

/* ---------------- AUTH ---------------- */

async function loginUser(emailOrObject, password) {
  let email;
  let finalPassword;

  if (
    emailOrObject &&
    typeof emailOrObject === "object"
  ) {
    email = emailOrObject.email;
    finalPassword = emailOrObject.password;
  } else {
    email = emailOrObject;
    finalPassword = password;
  }

  email = String(email ?? "").trim();
  finalPassword = String(finalPassword ?? "");

  if (!email || !finalPassword) {
    return {
      ok: false,
      status: 422,
      data: {
        message: "Email and password are required.",
      },
    };
  }

  const response = await apiRequest("/login", {
    method: "POST",
    body: {
      email,
      password: finalPassword,
    },
  });

  if (response.ok && response.data?.access_token) {
    setToken(response.data.access_token);
  }

  return response;
}

async function registerUser(nameOrObject, email, password) {
  let name;
  let finalEmail;
  let finalPassword;

  if (
    nameOrObject &&
    typeof nameOrObject === "object"
  ) {
    name = nameOrObject.name;
    finalEmail = nameOrObject.email;
    finalPassword = nameOrObject.password;
  } else {
    name = nameOrObject;
    finalEmail = email;
    finalPassword = password;
  }

  name = String(name ?? "").trim();
  finalEmail = String(finalEmail ?? "").trim();
  finalPassword = String(finalPassword ?? "");

  if (!name || !finalEmail || !finalPassword) {
    return {
      ok: false,
      status: 422,
      data: {
        message: "Name, email and password are required.",
      },
    };
  }

  return apiRequest("/register", {
    method: "POST",
    body: {
      name,
      email: finalEmail,
      password: finalPassword,
    },
  });
}

/* ---------------- API ---------------- */

export const api = {
  login: loginUser,

  register: registerUser,

  getMe: () => apiRequest("/me"),
  getProfile: () => apiRequest("/profiles"),
  saveProfile: (profile) => apiRequest("/profiles", { method: "PUT", body: profile }),

  getGoals: () => apiRequest("/goals"),

  createGoal: ({ title, description = "", target_date = null, status = "active" }) =>
    apiRequest("/goals", {
      method: "POST",
      body: { title, description, target_date, status },
    }),

  updateGoal: (goalId, payload) =>
    apiRequest(`/goals/${goalId}`, {
      method: "PUT",
      body: payload,
    }),

  getTasks: () => apiRequest("/tasks"),

  createTask: ({
    goal_id,
    title,
    description = "",
    estimated_minutes = 30,
    difficulty = "medium",
    scheduled_date = null,
    scheduled_time = null,
  }) =>
    apiRequest("/tasks", {
      method: "POST",
      body: {
        goal_id,
        title,
        description,
        estimated_minutes,
        difficulty,
        scheduled_date,
        scheduled_time,
      },
    }),

  generateDailyPlan: () =>
    apiRequest("/tasks/generate-daily-plan", {
      method: "POST",
    }),

  getEnergyCheckins: () => apiRequest("/energy-checkins"),

  createEnergyCheckin: (energyLevel, notes = "") =>
    apiRequest("/energy-checkins", {
      method: "POST",
      body: {
        energy_level: energyLevel,
        notes,
      },
    }),

  updateTaskStatus: (taskId, status) =>
    apiRequest(`/tasks/${taskId}/status`, {
      method: "PUT",
      body: {
        status,
      },
    }),

  getGoalSkills: (goalId) =>
    apiRequest(`/goals/${goalId}/skills`),

  startAssessment: (goalId) =>
    apiRequest("/assessment/start", {
      method: "POST",
      body: { goal_id: goalId },
    }),

  submitAnswer: (attemptId, questionId, selectedAnswer) =>
    apiRequest("/assessment/answer", {
      method: "POST",
      body: {
        attempt_id: attemptId,
        question_id: questionId,
        selected_answer: selectedAnswer,
      },
    }),

  completeAssessment: (attemptId) =>
    apiRequest("/assessment/complete", {
      method: "POST",
      body: { attempt_id: attemptId },
    }),

  submitAssessment: (attemptId, answers, tabSwitches = 0) =>
    apiRequest("/assessment/submit", {
      method: "POST",
      body: {
        attempt_id: attemptId,
        answers,
        tab_switches: tabSwitches,
      },
    }),

  getSkillGaps: (goalId) =>
    apiRequest(`/goals/${goalId}/skill-gaps`),

  getRoadmap: (goalId) =>
    apiRequest(`/goals/${goalId}/roadmap`),

  createTaskLog: ({ task_id, status, reason = "", actual_minutes = null }) =>
    apiRequest("/task-logs", {
      method: "POST",
      body: { task_id, status, reason, actual_minutes },
    }),

  getTaskLogs: () => apiRequest("/task-logs"),

  getProcrastinationSummary: () =>
    apiRequest("/task-logs/procrastination-summary"),

  getAdaptiveRecommendation: () =>
    apiRequest("/tasks/adaptive-recommendation"),

  getTaskPrediction: (taskId) =>
    apiRequest("/tasks/prediction", { query: { task_id: taskId } }),

  getHabits: () => apiRequest("/habits"),

  createHabit: ({ name, frequency = "daily", target_count = 1 }) =>
    apiRequest("/habits", {
      method: "POST",
      body: { name, frequency, target_count },
    }),

  getProgress: () => apiRequest("/progress"),

  createProgress: ({ habit_id, completed, notes = "" }) =>
    apiRequest("/progress", {
      method: "POST",
      body: { habit_id, completed, notes },
    }),

  getProgressSummary: () => apiRequest("/progress-summary"),
  getAssessmentHistory: () => apiRequest("/assessment/history"),

  getCoachStatus: () => apiRequest("/ai/coach/status"),
  askCoach: ({ question, goal_id = null, history = [] }) =>
    apiRequest("/ai/coach/chat", {
      method: "POST",
      body: { question, goal_id, history },
    }),

  getGoalCurriculum: (goalId) =>
    apiRequest(`/goals/${goalId}/curriculum`),

  getGoalCurriculumStage: (goalId, stageNumber) =>
    apiRequest(`/goals/${goalId}/curriculum/stages/${stageNumber}`),

  getGoalCurriculumTopic: (goalId, topicId) =>
    apiRequest(`/goals/${goalId}/curriculum/topics/${topicId}`),

  generateGoalCurriculumTopicLesson: (goalId, topicId, force = false) =>
    apiRequest(`/goals/${goalId}/curriculum/topics/${topicId}/generate-lesson`, {
      method: "POST",
      body: { force },
    }),

  updateGoalCurriculumTopicProgress: (
    goalId,
    topicId,
    { status, quiz_score = null }
  ) =>
    apiRequest(`/goals/${goalId}/curriculum/topics/${topicId}/progress`, {
      method: "PUT",
      body: { status, quiz_score },
    }),

  getGoalCurriculumProgress: (goalId) =>
    apiRequest(`/goals/${goalId}/curriculum/progress`),
};

export { API_BASE };

export function getMe() {
  return api.getMe();
}
