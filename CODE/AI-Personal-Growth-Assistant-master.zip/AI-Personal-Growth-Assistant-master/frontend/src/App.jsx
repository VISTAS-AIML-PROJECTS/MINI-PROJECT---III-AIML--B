import { useCallback, useEffect, useRef, useState } from "react";
import "./App.css";
import {
  api,
  errorMessage,
  normalizeArray,
  setToken,
  getToken,
  getMe,
} from "./api/client";
import { PAGE_TITLES } from "./constants";
import Sidebar from "./components/Sidebar";
import Topbar from "./components/Topbar";
import Toast from "./components/Toast";
import { EmptyState } from "./components/ui";
import { IconAlert, IconHome, IconSpark } from "./components/icons";
import AuthPage from "./pages/AuthPage";
import DashboardPage from "./pages/DashboardPage";
import GoalsPage from "./pages/GoalsPage";
import RoadmapPage from "./pages/RoadmapPage";
import AssessmentPage from "./pages/AssessmentPage";
import TasksPage from "./pages/TasksPage";
import FocusPage from "./pages/FocusPage";
import ProgressPage from "./pages/ProgressPage";
import CoachPage from "./pages/CoachPage";
import ProfilePage from "./pages/ProfilePage";
import { belongsToUser, getTodayLocal } from "./utils/format";

const VALID_PAGES = new Set([
  "home",
  "goals",
  "roadmap",
  "tasks",
  "focus",
  "assessment",
  "progress",
  "coach",
  "profile",
]);

function getInitialPage() {
  const rawHash = window.location.hash.replace(/^#\/?/, "").trim().toLowerCase();
  return rawHash || "home";
}

function App() {
  const [loading, setLoading] = useState(false);
  const [authRestoring, setAuthRestoring] = useState(true);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [loggedInUser, setLoggedInUser] = useState(null);

  const [activePage, setActivePage] = useState(getInitialPage);
  const [selectedGoalId, setSelectedGoalId] = useState(() => {
    const saved = localStorage.getItem("selectedGoalId");
    return saved ? Number(saved) : null;
  });
  const [goals, setGoals] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [taskLogs, setTaskLogs] = useState([]);
  const [energy, setEnergy] = useState(null);
  const [focusTask, setFocusTask] = useState(null);
  const [dashboardLoading, setDashboardLoading] = useState(false);
  const [toast, setToast] = useState(null);
  const [mobileSidebar, setMobileSidebar] = useState(false);
  const [taskUpdating, setTaskUpdating] = useState(null);
  const requestIdRef = useRef(0);

  const navigateTo = useCallback((page) => {
    setActivePage(page);
    try {
      window.history.replaceState(null, "", `#${page}`);
    } catch {
      /* ignore history error */
    }
  }, []);

  useEffect(() => {
    const onHashChange = () => {
      const next = window.location.hash.replace(/^#\/?/, "").trim().toLowerCase();
      if (next) setActivePage(next);
    };
    window.addEventListener("hashchange", onHashChange);
    return () => window.removeEventListener("hashchange", onHashChange);
  }, []);

  const notify = useCallback((type, message) => {
    setToast({
      type,
      message,
      id: Date.now(),
    });
  }, []);

  useEffect(() => {
    if (!toast) return undefined;
    const timer = setTimeout(() => setToast(null), 4200);
    return () => clearTimeout(timer);
  }, [toast]);

  const loadDashboardData = useCallback(
    async (userOverride) => {
      const activeUserId = userOverride?.id || loggedInUser?.id;
      if (!activeUserId) return;

      const currentRequest = ++requestIdRef.current;
      await Promise.resolve();
      setDashboardLoading(true);

      try {
        const [goalsResponse, tasksResponse, energyResponse, logsResponse] =
          await Promise.all([
            api.getGoals(),
            api.getTasks(),
            api.getEnergyCheckins(),
            api.getTaskLogs(),
          ]);

        if (currentRequest !== requestIdRef.current) return;

        if (goalsResponse.ok) {
          setGoals(
            normalizeArray(goalsResponse.data, ["goals", "data", "items"]).filter(
              (goal) => belongsToUser(goal, activeUserId)
            )
          );
        }

        if (tasksResponse.ok) {
          setTasks(
            normalizeArray(tasksResponse.data, ["tasks", "data", "items"]).filter(
              (task) => belongsToUser(task, activeUserId)
            )
          );
        }

        if (energyResponse.ok) {
          const energyList = normalizeArray(energyResponse.data, [
            "energy_checkins",
            "energy",
            "data",
            "items",
          ]).filter((item) => belongsToUser(item, activeUserId));

          setEnergy(energyList[0] || null);
        }

        if (logsResponse.ok) {
          setTaskLogs(
            normalizeArray(logsResponse.data, ["task_logs", "data", "items"]).filter(
              (log) => belongsToUser(log, activeUserId)
            )
          );
        }
      } catch (error) {
        console.error("Dashboard loading error:", error);
        notify("error", "Unable to load your latest GrowthAI data.");
      } finally {
        if (currentRequest === requestIdRef.current) {
          setDashboardLoading(false);
        }
      }
    },
    [loggedInUser?.id, notify]
  );

  useEffect(() => {
    let cancelled = false;

    async function restoreSession() {
      if (!getToken()) {
        setAuthRestoring(false);
        return;
      }

      try {
        const { ok, data } = await getMe();

        if (cancelled) return;

        if (ok && data?.user?.id) {
          setLoggedInUser(data.user);
          setIsLoggedIn(true);
          localStorage.setItem("user", JSON.stringify(data.user));
          loadDashboardData(data.user);
        } else {
          setToken(null);
          localStorage.removeItem("user");
        }
      } catch {
        if (cancelled) return;
        try {
          const cached = JSON.parse(localStorage.getItem("user") || "null");
          if (cached?.id) {
            setLoggedInUser(cached);
            setIsLoggedIn(true);
          }
        } catch {
          /* ignore malformed cache */
        }
        notify(
          "error",
          "GrowthAI server is unreachable. Start FastAPI and try again."
        );
      } finally {
        if (!cancelled) {
          setAuthRestoring(false);
        }
      }
    }

    restoreSession();

    return () => {
      cancelled = true;
    };
  }, [notify, loadDashboardData]);

  const handleLogin = async ({ email, password, onSuccess, onError }) => {
    const cleanEmail = email.trim();

    if (!cleanEmail || !password) {
      const msg = "Enter your email address and password.";
      onError?.(msg);
      notify("error", msg);
      return;
    }

    setLoading(true);

    try {
      const { ok, data } = await api.login(cleanEmail, password);

      if (ok && data?.message === "Login successful" && data?.user?.id) {
        setToken(data.access_token);
        localStorage.setItem("user", JSON.stringify(data.user));
        setLoggedInUser(data.user);
        setIsLoggedIn(true);
        loadDashboardData(data.user);
        const profileResponse = await api.getProfile();
        navigateTo(
          profileResponse.ok && !profileResponse.data?.profile
            ? "profile"
            : "home"
        );
        onSuccess?.();
        notify("success", `Welcome back, ${data.user.name || "there"}!`);
      } else {
        const msg = errorMessage(data, "Invalid email or password.");
        onError?.(msg);
        notify("error", msg);
      }
    } catch (error) {
      console.error("Login error:", error);
      const msg = "GrowthAI server is unreachable. Start FastAPI and try again.";
      onError?.(msg);
      notify("error", msg);
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async ({ name, email, password, onSuccess, onError }) => {
    const cleanName = name.trim();
    const cleanEmail = email.trim();

    if (!cleanName || !cleanEmail || !password) {
      const msg = "Please complete all registration fields.";
      onError?.(msg);
      notify("error", msg);
      return;
    }

    if (password.length < 8) {
      const msg = "Password must contain at least 8 characters.";
      onError?.(msg);
      notify("error", msg);
      return;
    }

    setLoading(true);

    try {
      const { ok, data } = await api.register(cleanName, cleanEmail, password);

      if (ok && data?.message === "Registration successful") {
        onSuccess?.();
        notify("success", "Account created! You can sign in now.");
      } else {
        let message = errorMessage(data, "Registration failed.");

        if (typeof message === "string" && message.includes("duplicate")) {
          message = "This email is already registered. Please sign in.";
        }

        onError?.(message);
        notify("error", message);
      }
    } catch (error) {
      console.error("Registration error:", error);
      const msg = "GrowthAI server is unreachable. Start FastAPI and try again.";
      onError?.(msg);
      notify("error", msg);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    requestIdRef.current += 1;
    setToken(null);
    localStorage.removeItem("user");
    setLoggedInUser(null);
    setIsLoggedIn(false);
    setGoals([]);
    setTasks([]);
    setTaskLogs([]);
    setEnergy(null);
    setFocusTask(null);
    navigateTo("home");
    setMobileSidebar(false);
    notify("success", "You have signed out.");
  };

  const saveEnergy = async (level) => {
    if (!loggedInUser?.id) return;

    try {
      const { ok, data } = await api.createEnergyCheckin(level);

      if (!ok) {
        notify(
          "error",
          errorMessage(data, "Could not save your energy check-in.")
        );
        return;
      }

      setEnergy(data?.checkin || data);
      notify("success", `Energy check-in saved.`);
      await loadDashboardData();
    } catch (error) {
      console.error("Energy error:", error);
      notify("error", "Could not connect to the GrowthAI server.");
    }
  };

  const updateTaskStatus = async (task, nextStatus) => {
    if (!task?.id || taskUpdating === task.id) return;

    setTaskUpdating(task.id);

    try {
      const { ok, data } = await api.updateTaskStatus(task.id, nextStatus);

      if (!ok) {
        notify("error", errorMessage(data, "Could not update task."));
        return;
      }

      setTasks((previous) =>
        previous.map((item) =>
          item.id === task.id ? { ...item, status: nextStatus } : item
        )
      );

      if (nextStatus === "completed") {
        try {
          const logRes = await api.createTaskLog({
            task_id: task.id,
            status: "completed",
            actual_minutes: task.estimated_minutes || null,
            reason: "Completed from workspace",
          });
          if (logRes.ok && logRes.data?.log) {
            setTaskLogs((prev) => [logRes.data.log, ...prev]);
          }
        } catch {
          /* non-blocking */
        }
      }

      notify(
        "success",
        nextStatus === "completed"
          ? "Task completed. Nice work!"
          : `Task marked ${nextStatus}.`
      );
    } catch (error) {
      console.error("Task update error:", error);
      notify("error", "Could not connect to the GrowthAI server.");
    } finally {
      setTaskUpdating(null);
    }
  };

  const handleSelectGoal = (goalId) => {
    setSelectedGoalId(goalId);
    localStorage.setItem("selectedGoalId", String(goalId));
    notify("success", "Active goal updated.");
  };

  const handleGoalSaved = (goal) => {
    if (!goal?.id) {
      loadDashboardData();
      return;
    }
    setGoals((previous) => {
      const exists = previous.some((item) => item.id === goal.id);
      return exists
        ? previous.map((item) => (item.id === goal.id ? goal : item))
        : [...previous, goal];
    });
  };

  const handleTasksChanged = () => {
    loadDashboardData();
  };

  const handleStartFocus = (task) => {
    setFocusTask(task || null);
    navigateTo("focus");
  };

  if (authRestoring) {
    return (
      <div className="app-loading-screen">
        <div className="loading-logo">
          <IconSpark width={24} height={24} />
        </div>
        <h2>GrowthAI</h2>
        <p>Preparing your student study workspace…</p>
        <div className="loading-spinner" />
      </div>
    );
  }

  const today = getTodayLocal();

  const todayTasks = tasks.filter((task) => {
    if (!task?.scheduled_date) return true;
    return String(task.scheduled_date).slice(0, 10) === today;
  });

  const completedTasks = todayTasks.filter(
    (task) => String(task.status).toLowerCase() === "completed"
  ).length;

  const pendingTodayCount = todayTasks.filter(
    (task) => String(task.status || "pending").toLowerCase() === "pending"
  ).length;

  const completionPercent =
    todayTasks.length > 0
      ? Math.round((completedTasks / todayTasks.length) * 100)
      : 0;

  const activeGoal =
    goals.find((goal) => goal.id === selectedGoalId) ||
    goals.find((goal) => String(goal.status).toLowerCase() === "active") ||
    goals[0] ||
    null;

  const firstName =
    loggedInUser?.name?.trim()?.split(/\s+/)?.[0] || "Student";

  const currentEnergy = energy?.energy_level || energy?.level || null;

  return (
    <>
      <Toast toast={toast} onClose={() => setToast(null)} />

      {!isLoggedIn ? (
        <AuthPage
          loading={loading}
          notify={notify}
          onLogin={handleLogin}
          onRegister={handleRegister}
        />
      ) : (
        <div className="growth-app">
          {mobileSidebar && (
            <button
              type="button"
              className="sidebar-overlay"
              onClick={() => setMobileSidebar(false)}
              aria-label="Close navigation menu"
            />
          )}

          <Sidebar
            activePage={activePage}
            loggedInUser={loggedInUser}
            mobileSidebar={mobileSidebar}
            activeGoal={activeGoal}
            pendingTodayCount={pendingTodayCount}
            onNavigate={navigateTo}
            onLogout={handleLogout}
            onCloseMobile={() => setMobileSidebar(false)}
          />

          <main className="growth-main">
            <Topbar
              title={PAGE_TITLES[activePage] || "Page not found"}
              dashboardLoading={dashboardLoading}
              loggedInUser={loggedInUser}
              goals={goals}
              activeGoal={activeGoal}
              onSelectGoal={handleSelectGoal}
              onRefresh={() => loadDashboardData()}
              onOpenMenu={() => setMobileSidebar(true)}
              onOpenProfile={() => navigateTo("profile")}
              onNavigate={navigateTo}
            />

            <div className="dashboard-content">
              {dashboardLoading && (
                <div className="loading-bar" aria-hidden="true">
                  <div />
                </div>
              )}

              {activePage === "home" && (
                <DashboardPage
                  firstName={firstName}
                  completionPercent={completionPercent}
                  completedTasks={completedTasks}
                  todayTasks={todayTasks}
                  allTasks={tasks}
                  taskLogs={taskLogs}
                  activeGoal={activeGoal}
                  currentEnergy={currentEnergy}
                  taskUpdating={taskUpdating}
                  onUpdateTaskStatus={updateTaskStatus}
                  onSaveEnergy={saveEnergy}
                  onNavigate={navigateTo}
                  onStartFocus={handleStartFocus}
                  onTasksChanged={handleTasksChanged}
                  notify={notify}
                />
              )}

              {activePage === "goals" && (
                <GoalsPage
                  goals={goals}
                  notify={notify}
                  activeGoalId={activeGoal?.id}
                  onSelectGoal={handleSelectGoal}
                  onGoalSaved={handleGoalSaved}
                  onNavigate={navigateTo}
                />
              )}

              {activePage === "roadmap" && (
                <RoadmapPage
                  activeGoal={activeGoal}
                  goals={goals}
                  onSelectGoal={handleSelectGoal}
                  onNavigate={navigateTo}
                  onTaskAdded={handleTasksChanged}
                  notify={notify}
                />
              )}

              {activePage === "tasks" && (
                <TasksPage
                  todayTasks={todayTasks}
                  allTasks={tasks}
                  goals={goals}
                  completedTasks={completedTasks}
                  completionPercent={completionPercent}
                  taskUpdating={taskUpdating}
                  onUpdateTaskStatus={updateTaskStatus}
                  notify={notify}
                  activeGoal={activeGoal}
                  onTaskAdded={handleTasksChanged}
                  onStartFocus={handleStartFocus}
                  onNavigate={navigateTo}
                />
              )}

              {activePage === "focus" && (
                <FocusPage
                  key={focusTask?.id || "focus-default"}
                  todayTasks={todayTasks}
                  allTasks={tasks}
                  initialTask={focusTask}
                  activeGoal={activeGoal}
                  notify={notify}
                  onTaskUpdated={handleTasksChanged}
                  onNavigate={navigateTo}
                />
              )}

              {activePage === "assessment" && (
                <AssessmentPage
                  activeGoal={activeGoal}
                  goals={goals}
                  loggedInUser={loggedInUser}
                  onSelectGoal={handleSelectGoal}
                  onNavigate={navigateTo}
                  notify={notify}
                />
              )}

              {activePage === "progress" && (
                <ProgressPage
                  completionPercent={completionPercent}
                  completedTasks={completedTasks}
                  todayTasks={todayTasks}
                  allTasks={tasks}
                  taskLogs={taskLogs}
                  goals={goals}
                  activeGoal={activeGoal}
                  currentEnergy={currentEnergy}
                  onSelectGoal={handleSelectGoal}
                  onNavigate={navigateTo}
                />
              )}

              {activePage === "coach" && (
                <CoachPage
                  activeGoal={activeGoal}
                  todayTasks={todayTasks}
                  allTasks={tasks}
                  notify={notify}
                  onNavigate={navigateTo}
                  onTasksChanged={handleTasksChanged}
                />
              )}

              {activePage === "profile" && (
                <ProfilePage
                  loggedInUser={loggedInUser}
                  notify={notify}
                  onContinue={() => navigateTo("goals")}
                  onLogout={handleLogout}
                />
              )}

              {!VALID_PAGES.has(activePage) && (
                <section className="page-section">
                  <EmptyState
                    Icon={IconAlert}
                    title="Page not found (404)"
                    description={`The workspace view "${activePage}" does not exist. Use the navigation sidebar or return to your Overview dashboard.`}
                    action={
                      <button
                        type="button"
                        className="btn-primary"
                        onClick={() => navigateTo("home")}
                      >
                        <IconHome width={15} height={15} />
                        Return to Overview
                      </button>
                    }
                  />
                </section>
              )}
            </div>
          </main>
        </div>
      )}
    </>
  );
}

export default App;
