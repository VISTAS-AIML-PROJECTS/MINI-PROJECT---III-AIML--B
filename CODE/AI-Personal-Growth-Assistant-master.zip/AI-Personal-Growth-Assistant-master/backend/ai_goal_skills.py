"""AI-assisted skill mapping and question preparation for ANY goal.

map_goal_skills()      -> asks Gemini which skills a goal needs and links them.
ensure_questions_async -> in the background, tops up MCQs for skills that have
                          too few (validated + one batch second-opinion call).

Everything here fails soft: if the AI is unavailable the goal is still created,
just without skills, exactly as before."""
import json
import re
import threading
import time

from sqlalchemy import text

import ai_client
from database import engine
import generate_questions as gq

MAX_SKILLS = 6
MIN_QUESTIONS_PER_SKILL = 3
TARGET_QUESTIONS_PER_SKILL = 4
FAST_MODELS = ["gemini-3.5-flash-lite", "gemini-3.1-flash-lite"]
_busy = set()
_goal_retry_after = {}
_busy_lock = threading.Lock()

SKILL_SYSTEM = (
    "You are a career and learning advisor. Return ONLY valid JSON. "
    "Only suggest skills a learner can be tested on with multiple-choice questions."
)


def _json(raw):
    return json.loads(re.sub(r"^```(?:json)?\s*|\s*```$", "", raw.strip()))


def _clean_skills(items):
    out, seen = [], set()
    if isinstance(items, dict):
        items = items.get("skills", [])
    if not isinstance(items, list):
        return out
    for item in items:
        try:
            name = re.sub(r"\s+", " ", str(item["name"])).strip()
            category = str(item.get("category") or "General").strip()[:50]
            description = str(item.get("description") or "").strip()[:300]
            importance = str(item.get("importance") or "medium").strip().lower()
        except (KeyError, TypeError, AttributeError):
            continue
        if not 2 <= len(name) <= 40 or name.lower() in seen:
            continue
        if importance not in ("high", "medium", "low"):
            importance = "medium"
        seen.add(name.lower())
        out.append({"name": name, "category": category or "General",
                    "description": description, "importance": importance})
        if len(out) >= MAX_SKILLS:
            break
    return out


def suggest_skills(title, description=""):
    prompt = (
        f"A learner's goal: \"{title}\". {description or ''}\n"
        f"List the {MAX_SKILLS - 2} to {MAX_SKILLS} most important core skills needed to reach this goal. "
        "If the text is not a real learning or career goal, return an empty list.\n"
        'Return a JSON list; each item: {"name": str (max 4 words), "category": str, '
        '"description": str (one sentence), "importance": "high"|"medium"}'
    )
    return _clean_skills(_json(ai_client.generate_text(
        prompt, system=SKILL_SYSTEM, json_output=True, temperature=0.3, max_tokens=2048,
        timeout=90, prefer=FAST_MODELS)))


def map_goal_skills(goal_id, title, description=""):
    """Link AI-suggested skills to the goal. Returns (number_linked, skill_ids)."""
    if not ai_client.is_configured():
        return 0, []
    try:
        skills = suggest_skills(title, description)
    except (ai_client.AIError, ValueError):
        return 0, []
    if not skills:
        return 0, []

    skill_ids = []
    with engine.connect() as conn:
        conn.execute(text(
            "SELECT setval(pg_get_serial_sequence('skills','id'), "
            "(SELECT COALESCE(MAX(id), 1) FROM skills))"))
        for s in skills:
            row = conn.execute(text("SELECT id FROM skills WHERE lower(name) = lower(:n) ORDER BY id LIMIT 1"),
                               {"n": s["name"]}).fetchone()
            if row is None:
                row = conn.execute(text(
                    "INSERT INTO skills (name, category, description) VALUES (:n, :c, :d) RETURNING id"),
                    {"n": s["name"], "c": s["category"], "d": s["description"]}).fetchone()
            if row.id in skill_ids:
                continue
            skill_ids.append(row.id)
            conn.execute(text(
                "INSERT INTO goal_skills (goal_id, skill_id, importance) VALUES (:g, :s, :i)"),
                {"g": goal_id, "s": row.id, "i": s["importance"]})
        conn.commit()
    return len(skill_ids), skill_ids


def batch_check(cleans):
    """ONE call: a fresh model answers all questions without seeing the key."""
    blocks = []
    for n, c in enumerate(cleans, 1):
        opts = "\n".join(f"{gq.LETTERS[i].upper()}. {o}" for i, o in enumerate(c["options"]))
        blocks.append(f"Q{n}. {c['question']}\n{opts}")
    prompt = (
        "Answer each multiple-choice question. Reply ONLY with JSON like "
        '{"answers": ["A", "C", ...]} with exactly one letter per question, in order.\n\n'
        + "\n\n".join(blocks)
    )
    try:
        answers = _json(ai_client.generate_text(
            prompt, system="You are a careful expert.", json_output=True,
            temperature=0, max_tokens=4096, timeout=90)).get("answers", [])
    except (ai_client.AIError, ValueError, AttributeError):
        return []
    keep = []
    for c, a in zip(cleans, answers):
        if str(a).strip().lower()[:1] == gq.LETTERS[c["correct_index"]]:
            keep.append(c)
    return keep


def _prepare_skill(skill_id):
    with engine.connect() as conn:
        skill = conn.execute(text("SELECT id, name, category, description FROM skills WHERE id = :i"),
                             {"i": skill_id}).mappings().first()
        if skill is None:
            return
        skill = dict(skill)
        existing = [r[0] for r in conn.execute(text(
            "SELECT question FROM assessment_questions WHERE skill_id = :i"), {"i": skill_id})]
    need = TARGET_QUESTIONS_PER_SKILL - len(existing)
    if len(existing) >= MIN_QUESTIONS_PER_SKILL or need <= 0:
        return
    seen = {gq._norm(q) for q in existing}
    try:
        items = gq.generate(skill, existing, need + 3)
    except (ai_client.AIError, ValueError):
        return
    cleans = []
    for item in items:
        c = gq.validate(item, seen)
        if isinstance(c, dict):
            seen.add(gq._norm(c["question"]))
            cleans.append(c)
    approved = [gq.shuffle_options(c) for c in batch_check(cleans)][:need]
    if not approved:
        return
    with engine.connect() as conn:
        conn.execute(text(
            "SELECT setval(pg_get_serial_sequence('assessment_questions','id'), "
            "(SELECT COALESCE(MAX(id), 1) FROM assessment_questions))"))
        for q in approved:
            conn.execute(text("""
                INSERT INTO assessment_questions
                  (skill, question, option_a, option_b, option_c, option_d,
                   correct_answer, difficulty, skill_id)
                VALUES (:skill, :q, :a, :b, :c, :d, :ans, :diff, :sid)
            """), {"skill": skill["name"], "q": q["question"], "a": q["options"][0],
                   "b": q["options"][1], "c": q["options"][2], "d": q["options"][3],
                   "ans": gq.LETTERS[q["correct_index"]], "diff": q["difficulty"], "sid": skill["id"]})
        conn.commit()


def _worker(skill_ids):
    try:
        for sid in skill_ids:
            try:
                _prepare_skill(sid)
            except Exception:  # never let a background job crash the server
                pass
    finally:
        with _busy_lock:
            for sid in skill_ids:
                _busy.discard(sid)


def ensure_questions_async(skill_ids):
    """Start background question preparation for skills not already being prepared."""
    if not ai_client.is_configured():
        return False
    with _busy_lock:
        todo = [s for s in skill_ids if s not in _busy]
        _busy.update(todo)
    if not todo:
        return True
    threading.Thread(target=_worker, args=(todo,), daemon=True).start()
    return True


def goal_skill_ids_missing_questions(goal_id):
    """Skill ids of this goal that have fewer than the minimum number of questions."""
    with engine.connect() as conn:
        rows = conn.execute(text("""
            SELECT gs.skill_id, COUNT(aq.id) AS n
            FROM goal_skills gs
            LEFT JOIN assessment_questions aq ON aq.skill_id = gs.skill_id
            WHERE gs.goal_id = :g
            GROUP BY gs.skill_id
        """), {"g": goal_id}).fetchall()
    return [r.skill_id for r in rows if r.n < MIN_QUESTIONS_PER_SKILL]


def prepare_goal_questions(goal_id):
    """Start background top-up for skills with too few questions.
    Returns True only when some skill has NO questions yet, so the assessment
    should wait; returns False when it can start (or AI is not configured)."""
    with engine.connect() as conn:
        rows = conn.execute(text("""
            SELECT gs.skill_id, COUNT(aq.id) AS n
            FROM goal_skills gs
            LEFT JOIN assessment_questions aq ON aq.skill_id = gs.skill_id
            WHERE gs.goal_id = :g
            GROUP BY gs.skill_id
        """), {"g": goal_id}).fetchall()
    thin = [r.skill_id for r in rows if r.n < MIN_QUESTIONS_PER_SKILL]
    if thin:
        ensure_questions_async(thin)
    return any(r.n == 0 for r in rows) and ai_client.is_configured()


def _goal_worker(goal_id):
    try:
        with engine.connect() as conn:
            goal = conn.execute(text("SELECT title, description FROM goals WHERE id = :g"),
                                {"g": goal_id}).fetchone()
            has_skills = conn.execute(text("SELECT 1 FROM goal_skills WHERE goal_id = :g LIMIT 1"),
                                      {"g": goal_id}).fetchone()
        if goal is None or has_skills:
            return
        count, skill_ids = map_goal_skills(goal_id, goal.title, goal.description or "")
        if not count:
            _goal_retry_after[goal_id] = time.time() + 120  # do not hammer a failing AI
            return
        for sid in skill_ids:
            try:
                _prepare_skill(sid)
            except Exception:
                pass
    except Exception:
        pass
    finally:
        with _busy_lock:
            _busy.discard(("goal", goal_id))


def ensure_goal_skills_async(goal_id):
    """If the goal has no skills yet, map them (and prepare questions) in the
    background, one job per goal. Returns True when a job is running/started."""
    if not ai_client.is_configured():
        return False
    with _busy_lock:
        if ("goal", goal_id) in _busy:
            return True
        if _goal_retry_after.get(goal_id, 0) > time.time():
            return False
        _busy.add(("goal", goal_id))
    threading.Thread(target=_goal_worker, args=(goal_id,), daemon=True).start()
    return True
