import base64
import hashlib
import hmac
import json
import os
import secrets
import time
from typing import Any, Optional
from sqlalchemy.exc import OperationalError
import bcrypt
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import text

from database import engine

# ---------- Configuration ----------

_JWT_SECRET = None  # captured at import time; see _load_jwt_secret()
_JWT_EXPIRE_MINUTES = 1440


def _load_jwt_secret() -> bytes:
    global _JWT_SECRET

    raw = os.getenv("JWT_SECRET")
    if raw is None or raw.strip() == "":
        raise RuntimeError(
            "JWT_SECRET is not set or is empty. "
            "Add JWT_SECRET=<a long random value> to backend/.env "
            "(see backend/.env.example). The server will not start without it."
        )
    _JWT_SECRET = raw.strip().encode("utf-8")
    return _JWT_SECRET


def get_jwt_secret() -> bytes:
    if _JWT_SECRET is None:
        _load_jwt_secret()
    return _JWT_SECRET


# Fail fast: refuse to start the application without a configured secret.
_load_jwt_secret()


try:
    _expire = int(os.getenv("JWT_EXPIRE_MINUTES", "1440"))
    if _expire > 0:
        _JWT_EXPIRE_MINUTES = _expire
except (ValueError, TypeError):
    pass

# ---------- Password hashing & policy ----------

pwd_context = bcrypt

# bcrypt hashes at most 72 bytes; longer passwords are silently truncated.
BCRYPT_MAX_PASSWORD_BYTES = 72


def hash_password(password: str) -> str:
    _validate_password_policy(password)
    return pwd_context.hashpw(
        password.encode("utf-8")[:BCRYPT_MAX_PASSWORD_BYTES], bcrypt.gensalt()
    ).decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    try:
        return pwd_context.checkpw(
            plain.encode("utf-8")[:BCRYPT_MAX_PASSWORD_BYTES], hashed.encode("utf-8")
        )
    except ValueError:
        return False


def validate_password_strength(password: str) -> Optional[str]:
    """Return a human-readable reason if the password violates policy, else None."""
    if len(password) < 8:
        return "Password must be at least 8 characters long."
    if len(password.encode("utf-8")) > BCRYPT_MAX_PASSWORD_BYTES:
        return "Password must be at most 72 bytes long."
    if not any(c.isalpha() for c in password):
        return "Password must contain at least one letter."
    if not any(c.isdigit() for c in password):
        return "Password must contain at least one digit."
    return None


def _validate_password_policy(password: str) -> None:
    reason = validate_password_strength(password)
    if reason:
        raise ValueError(reason)


# ---------- Minimal HS256 JWT (stdlib only) ----------

_ALGORITHM = "HS256"  # pinned; never read from the token header for verification


def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64url_decode(segment: str) -> bytes:
    padding = "=" * (-len(segment) % 4)
    return base64.b64decode(segment + padding, altchars=b"-_", validate=True)


def create_token(user_id: int) -> str:
    now = int(time.time())
    header = {"alg": _ALGORITHM, "typ": "JWT"}
    payload = {
        "sub": str(user_id),
        "iat": now,
        "exp": now + _JWT_EXPIRE_MINUTES * 60,
    }
    header_b64 = _b64url_encode(
        json.dumps(header, separators=(",", ":")).encode("utf-8")
    )
    payload_b64 = _b64url_encode(
        json.dumps(payload, separators=(",", ":")).encode("utf-8")
    )
    signing_input = f"{header_b64}.{payload_b64}".encode("ascii")
    signature = hmac.new(get_jwt_secret(), signing_input, hashlib.sha256).digest()
    return f"{header_b64}.{payload_b64}.{_b64url_encode(signature)}"


def decode_token(token: str) -> dict[str, Any]:
    """
    Verify an HS256 JWT and return its claims.

    Security contract:
      - the algorithm is pinned (header alg must literally be HS256);
      - the signature is verified (constant-time) before any claim is trusted;
      - exp is required and checked (zero leeway);
      - any structural, encoding, or cryptographic failure raises 401.
    """
    from fastapi import HTTPException

    def _reject(detail: str = "Invalid or expired token") -> None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=detail,
            headers={"WWW-Authenticate": "Bearer"},
        )

    if not isinstance(token, str) or token.count(".") != 2:
        _reject()

    header_b64, payload_b64, signature_b64 = token.split(".")

    if not header_b64 or not payload_b64 or not signature_b64:
        _reject()

    try:
        signature = _b64url_decode(signature_b64)
        header = json.loads(_b64url_decode(header_b64))
    except Exception:
        _reject()

    if not isinstance(header, dict) or header.get("alg") != _ALGORITHM:
        _reject()

    signing_input = f"{header_b64}.{payload_b64}".encode("ascii")
    expected = hmac.new(get_jwt_secret(), signing_input, hashlib.sha256).digest()
    if not hmac.compare_digest(expected, signature):
        _reject()

    try:
        claims = json.loads(_b64url_decode(payload_b64))
    except Exception:
        _reject()

    if not isinstance(claims, dict):
        _reject()

    exp = claims.get("exp")
    if not isinstance(exp, (int, float)) or isinstance(exp, bool) or exp <= time.time():
        _reject()

    sub = claims.get("sub")
    if not isinstance(sub, str) or not sub.isdigit():
        _reject()

    return claims


# ---------- FastAPI dependency ----------

_bearer_scheme = HTTPBearer(auto_error=False)



def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(_bearer_scheme),
) -> dict:
    """Resolve the authenticated user from the Bearer token."""

    if credentials is None or not credentials.credentials:
        _raise_unauthorized()

    claims = decode_token(credentials.credentials)

    try:
        user_id = int(claims["sub"])
    except (KeyError, TypeError, ValueError):
        _raise_unauthorized()

    query = text(
        "SELECT id, name, email FROM users WHERE id = :user_id"
    )

    row = None

    # Retry once if a pooled PostgreSQL connection has gone stale.
    for attempt in range(2):
        try:
            with engine.connect() as connection:
                row = connection.execute(
                    query,
                    {"user_id": user_id},
                ).fetchone()

            break

        except OperationalError as exc:
            if attempt == 1:
                raise HTTPException(
                    status_code=503,
                    detail="Database temporarily unavailable. Please retry.",
                ) from exc

            # Discard the current pool so the next attempt obtains
            # a fresh database connection.
            engine.dispose()

    if row is None:
        _raise_unauthorized()

    return {
        "id": row.id,
        "name": row.name,
        "email": row.email,
    }



def _raise_unauthorized() -> None:
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Not authenticated",
        headers={"WWW-Authenticate": "Bearer"},
    )


def generate_secret() -> str:
    """For tooling/scripts: a fresh urlsafe secret."""
    return secrets.token_urlsafe(48)
