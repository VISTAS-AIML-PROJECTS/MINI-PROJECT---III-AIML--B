"""
Automated tests for the Data Analyst Curriculum & Detailed Learning Topics feature:
- 8 stages and 65 ordered topics matching the specification
- Exclusivity to the 'Become a Data Analyst' goal
- Lesson retrieval, Gemini generation caching (no repeated Gemini calls), and graceful fallback
- Topic progress persistence (not_started -> in_progress -> completed)
- Authentication enforcement (401) and strict user isolation
"""

from fastapi.testclient import TestClient
import pytest
from sqlalchemy import text

import ai_client
import data_analyst_curriculum as dac
from database import engine
from main import app
from security import get_current_user


@pytest.fixture
def test_users_and_goals():
    """
    Ensure two isolated users and goals exist in PostgreSQL for testing
    curriculum endpoints, progress persistence, and user isolation, then clean up
    test progress rows afterward.
    """
    with engine.connect() as conn:
        dac.ensure_curriculum_seeded(conn)

        u1 = conn.execute(
            text("SELECT id, name, email FROM users ORDER BY id ASC LIMIT 1")
        ).fetchone()
        assert u1 is not None, "Expected at least one user in database"

        u2 = conn.execute(
            text("SELECT id, name, email FROM users WHERE id <> :u1_id ORDER BY id ASC LIMIT 1"),
            {"u1_id": u1.id},
        ).fetchone()
        created_u2_id = None
        if u2 is None:
            u2 = conn.execute(
                text("""
                    INSERT INTO users (name, email, password_hash)
                    VALUES ('Isolation Test User', 'isolation_test_da@example.com', 'hash')
                    RETURNING id, name, email
                """)
            ).fetchone()
            created_u2_id = u2.id

        # Create a temporary Data Analyst goal for User 1, a non-Data-Analyst goal for User 1,
        # and a temporary Data Analyst goal for User 2.
        da_goal_u1 = conn.execute(
            text("""
                INSERT INTO goals (user_id, title, description, status)
                VALUES (:uid, 'Become a Data Analyst', 'Test DA goal U1', 'active')
                RETURNING id
            """),
            {"uid": u1.id},
        ).fetchone()

        other_goal_u1 = conn.execute(
            text("""
                INSERT INTO goals (user_id, title, description, status)
                VALUES (:uid, 'Prepare for NEET Biology', 'Non-DA goal', 'active')
                RETURNING id
            """),
            {"uid": u1.id},
        ).fetchone()

        da_goal_u2 = conn.execute(
            text("""
                INSERT INTO goals (user_id, title, description, status)
                VALUES (:uid, 'Become a Data Analyst', 'Test DA goal U2', 'active')
                RETURNING id
            """),
            {"uid": u2.id},
        ).fetchone()

        conn.commit()

    yield {
        "user1": {"id": u1.id, "name": u1.name, "email": u1.email},
        "user2": {"id": u2.id, "name": u2.name, "email": u2.email},
        "da_goal_u1_id": da_goal_u1.id,
        "other_goal_u1_id": other_goal_u1.id,
        "da_goal_u2_id": da_goal_u2.id,
    }

    with engine.connect() as conn:
        conn.execute(
            text("DELETE FROM goals WHERE id IN (:g1, :g2, :g3)"),
            {
                "g1": da_goal_u1.id,
                "g2": other_goal_u1.id,
                "g3": da_goal_u2.id,
            },
        )
        if created_u2_id is not None:
            conn.execute(
                text("DELETE FROM users WHERE id = :uid"),
                {"uid": created_u2_id},
            )
        conn.commit()


def test_curriculum_endpoints_require_authentication():
    """Unauthenticated requests to all curriculum endpoints must return 401."""
    with TestClient(app) as client:
        assert client.get("/goals/1/curriculum").status_code == 401
        assert client.get("/goals/1/curriculum/stages/1").status_code == 401
        assert client.get("/goals/1/curriculum/topics/1").status_code == 401
        assert client.get("/goals/1/curriculum/progress").status_code == 401
        assert (
            client.put(
                "/goals/1/curriculum/topics/1/progress",
                json={"status": "completed"},
            ).status_code
            == 401
        )


def test_curriculum_stages_and_ordered_topics_for_data_analyst_goal(test_users_and_goals):
    """
    Verify that 'Become a Data Analyst' returns the exact 8 stages and 65 ordered topics,
    while unrelated goals return supported=False.
    """
    user1 = test_users_and_goals["user1"]
    da_goal_id = test_users_and_goals["da_goal_u1_id"]
    other_goal_id = test_users_and_goals["other_goal_u1_id"]

    app.dependency_overrides[get_current_user] = lambda: user1
    try:
        with TestClient(app) as client:
            # 1. Data Analyst goal returns 8 stages and 65 ordered topics
            res = client.get(f"/goals/{da_goal_id}/curriculum")
            assert res.status_code == 200
            data = res.json()
            assert data["is_data_analyst_goal"] is True
            assert data["supported"] is True
            assert data["summary"]["total_stages"] == 8
            assert data["summary"]["total_topics"] == 65

            stages = data["stages"]
            assert [s["stage_number"] for s in stages] == [1, 2, 3, 4, 5, 6, 7, 8]
            expected_stage_titles = [
                "Data Analysis Fundamentals",
                "Excel and Spreadsheets",
                "Statistics Fundamentals",
                "SQL and Databases",
                "Python Fundamentals",
                "Python for Data Analysis",
                "Data Visualization",
                "Real-World Data Analyst Projects",
            ]
            assert [s["title"] for s in stages] == expected_stage_titles
            assert [len(s["topics"]) for s in stages] == [5, 8, 6, 12, 10, 10, 7, 7]

            # Verify topic ordering inside Stage 1 and Stage 4
            assert stages[0]["topics"][0]["title"] == "What Is Data Analysis?"
            assert stages[0]["topics"][4]["title"] == "Metrics, KPIs, and Basic Reporting"
            assert stages[3]["topics"][0]["title"] == "Database and Table Basics"
            assert stages[3]["topics"][10]["title"] == "Window Functions"
            assert stages[3]["topics"][11]["title"] == "SQL Practice Project"

            # Verify single stage endpoint
            stage4_res = client.get(f"/goals/{da_goal_id}/curriculum/stages/4")
            assert stage4_res.status_code == 200
            assert stage4_res.json()["stage"]["title"] == "SQL and Databases"
            assert len(stage4_res.json()["stage"]["topics"]) == 12

            # 2. Non-Data-Analyst goal is unaffected and returns supported=False
            other_res = client.get(f"/goals/{other_goal_id}/curriculum")
            assert other_res.status_code == 200
            assert other_res.json()["supported"] is False
            assert other_res.json()["stages"] == []
    finally:
        app.dependency_overrides.pop(get_current_user, None)


def test_topic_lesson_retrieval_and_persistent_caching(test_users_and_goals, monkeypatch):
    """
    Verify that opening a topic generates/retrieves structured lesson content, caches it
    in PostgreSQL so Gemini is not called again on subsequent opens, and includes
    PostgreSQL examples for SQL topics and runnable Pandas examples for Stage 6 topics.
    """
    user1 = test_users_and_goals["user1"]
    da_goal_id = test_users_and_goals["da_goal_u1_id"]

    gemini_calls = []

    def fake_generate_text(prompt, **kwargs):
        gemini_calls.append(prompt)
        return (
            '{"introduction": "Welcome to SELECT and FROM in PostgreSQL. This lesson explains how to query columns from a table.", '
            '"learning_objectives": ["Write SELECT queries", "Use FROM to specify a table", "Alias columns with AS"], '
            '"sections": [{"heading": "1. SELECT Clause", "body": "Choose columns to return."}, {"heading": "2. FROM Clause", "body": "Specify the source table."}], '
            '"examples": [{"title": "PostgreSQL SELECT", "language": "sql", "code": "SELECT id, name FROM customers LIMIT 2;", "expected_output": "1 | Alice\\n2 | Bob", "explanation": "Selects two columns."}], '
            '"practice_task": {"title": "Query orders", "instructions": "Select order_id and total from orders.", "starter_hint": "Use SELECT col1, col2 FROM orders;", "expected_outcome": "2 columns"}, '
            '"quiz": [{"question": "Which clause picks the table?", "options": ["FROM", "WHERE", "LIMIT", "GROUP BY"], "correct_index": 0, "explanation": "FROM names the table."}], '
            '"completion_criterion": "Complete the query and quiz."}'
        )

    monkeypatch.setattr(ai_client, "is_configured", lambda: True)
    monkeypatch.setattr(ai_client, "generate_text", fake_generate_text)

    app.dependency_overrides[get_current_user] = lambda: user1
    try:
        with TestClient(app) as client:
            curr = client.get(f"/goals/{da_goal_id}/curriculum").json()
            sql_topic_id = curr["stages"][3]["topics"][1]["id"]  # Stage 4, Topic 2: SELECT and FROM
            pandas_topic_id = curr["stages"][5]["topics"][2]["id"]  # Stage 6, Topic 3: Pandas Series and DataFrames

            # Clear lesson_json for sql_topic_id first so we test generation + caching deterministically
            with engine.connect() as conn:
                conn.execute(
                    text("UPDATE curriculum_topics SET lesson_json = NULL WHERE id = :tid"),
                    {"tid": sql_topic_id},
                )
                conn.commit()

            # First open calls Gemini once and stores lesson_json in DB
            res1 = client.get(f"/goals/{da_goal_id}/curriculum/topics/{sql_topic_id}")
            assert res1.status_code == 200
            d1 = res1.json()
            assert d1["topic"]["title"] == "SELECT and FROM"
            assert d1["lesson"]["generated_by"] == "gemini"
            assert "SELECT id, name FROM customers" in d1["lesson"]["examples"][0]["code"]
            assert d1["previous_topic"] is not None
            assert d1["next_topic"] is not None
            assert len(gemini_calls) == 1

            # Second open reads directly from PostgreSQL without calling Gemini again!
            res2 = client.get(f"/goals/{da_goal_id}/curriculum/topics/{sql_topic_id}")
            assert res2.status_code == 200
            assert len(gemini_calls) == 1

            # Test graceful fallback when Gemini raises AIError (e.g. quota exceeded)
            def broken_gemini(*args, **kwargs):
                raise ai_client.AIError("Quota exceeded", status_code=429, error_code="quota_exceeded")

            monkeypatch.setattr(ai_client, "generate_text", broken_gemini)
            with engine.connect() as conn:
                conn.execute(
                    text("UPDATE curriculum_topics SET lesson_json = NULL WHERE id = :tid"),
                    {"tid": pandas_topic_id},
                )
                conn.commit()

            res_pandas = client.get(f"/goals/{da_goal_id}/curriculum/topics/{pandas_topic_id}")
            assert res_pandas.status_code == 200
            p_lesson = res_pandas.json()["lesson"]
            assert "import pandas as pd" in p_lesson["examples"][0]["code"]
            assert len(p_lesson["quiz"]) >= 2
    finally:
        app.dependency_overrides.pop(get_current_user, None)


def test_topic_progress_persistence_and_user_isolation(test_users_and_goals):
    """
    Verify that marking a topic 'in_progress' and 'completed' persists in PostgreSQL,
    updates stage and overall counts, and is strictly isolated per user.
    """
    user1 = test_users_and_goals["user1"]
    user2 = test_users_and_goals["user2"]
    da_goal_u1_id = test_users_and_goals["da_goal_u1_id"]
    da_goal_u2_id = test_users_and_goals["da_goal_u2_id"]

    app.dependency_overrides[get_current_user] = lambda: user1
    try:
        with TestClient(app) as client:
            curr = client.get(f"/goals/{da_goal_u1_id}/curriculum").json()
            topic1_id = curr["stages"][0]["topics"][0]["id"]

            # Ensure clean start for topic1_id
            client.put(
                f"/goals/{da_goal_u1_id}/curriculum/topics/{topic1_id}/progress",
                json={"status": "not_started"},
            )

            # Mark in_progress
            prog_res1 = client.put(
                f"/goals/{da_goal_u1_id}/curriculum/topics/{topic1_id}/progress",
                json={"status": "in_progress"},
            )
            assert prog_res1.status_code == 200
            assert prog_res1.json()["status"] == "in_progress"
            assert prog_res1.json()["started_at"] is not None

            # Mark completed with quiz_score
            prog_res2 = client.put(
                f"/goals/{da_goal_u1_id}/curriculum/topics/{topic1_id}/progress",
                json={"status": "completed", "quiz_score": 100},
            )
            assert prog_res2.status_code == 200
            p2 = prog_res2.json()
            assert p2["status"] == "completed"
            assert p2["quiz_score"] == 100
            assert p2["completed_at"] is not None
            assert p2["stage_progress"]["completed_topics"] >= 1

            # Refresh curriculum and verify persistence
            refreshed = client.get(f"/goals/{da_goal_u1_id}/curriculum").json()
            saved_topic = refreshed["stages"][0]["topics"][0]
            assert saved_topic["status"] == "completed"
            assert saved_topic["quiz_score"] == 100

            # Switch to User 2:
            # 1) User 2 cannot access User 1's goal (returns 404)
            app.dependency_overrides[get_current_user] = lambda: user2
            forbidden_res = client.get(f"/goals/{da_goal_u1_id}/curriculum")
            assert forbidden_res.status_code == 404

            forbidden_put = client.put(
                f"/goals/{da_goal_u1_id}/curriculum/topics/{topic1_id}/progress",
                json={"status": "not_started"},
            )
            assert forbidden_put.status_code == 404

            # 2) User 2's own Data Analyst goal has independent progress (not_started)
            u2_curr = client.get(f"/goals/{da_goal_u2_id}/curriculum").json()
            assert u2_curr["stages"][0]["topics"][0]["status"] == "not_started"

            # Clean up User 1's test progress on topic1_id
            app.dependency_overrides[get_current_user] = lambda: user1
            client.put(
                f"/goals/{da_goal_u1_id}/curriculum/topics/{topic1_id}/progress",
                json={"status": "not_started"},
            )
    finally:
        app.dependency_overrides.pop(get_current_user, None)
