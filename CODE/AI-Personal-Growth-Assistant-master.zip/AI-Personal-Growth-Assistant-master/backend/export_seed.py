from sqlalchemy import text
from database import engine

TABLES = ["skills", "assessment_questions"]


def lit(v):
    if v is None:
        return "NULL"
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    if isinstance(v, (int, float)):
        return str(v)
    return "'" + str(v).replace("'", "''") + "'"


with engine.connect() as c, open("seed.sql", "w", encoding="utf-8") as f:
    for t in TABLES:
        rows = c.execute(text(f"SELECT * FROM {t} ORDER BY 1")).fetchall()
        for r in rows:
            m = r._mapping
            cols = ", ".join(m.keys())
            vals = ", ".join(lit(v) for v in m.values())
            f.write(f"INSERT INTO {t} ({cols}) VALUES ({vals});\n")
        print(t, len(rows))