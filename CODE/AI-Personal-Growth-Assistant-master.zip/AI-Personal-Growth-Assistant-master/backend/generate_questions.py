"""Generate assessment MCQs with Gemini and (optionally) save them.

Default is a DRY RUN: questions are printed for you to review, nothing is
written. Add --save to insert the questions that passed every check.

Examples (run from the backend folder, venv active):
  python generate_questions.py --skills Python,SQL --target 4
  python generate_questions.py --skills Python,SQL --target 4 --save
"""
import argparse
import json
import random
import re

from sqlalchemy import text

import ai_client
from database import engine

LETTERS = "abcd"
DIFFICULTIES = ("easy", "medium", "hard")

SYSTEM = (
    "You are an expert teacher who writes accurate multiple-choice questions for a "
    "skill assessment. Every question must have exactly one clearly correct option "
    "and three plausible but wrong options. No trick questions, no 'all of the above', "
    "no 'none of the above'. Return ONLY valid JSON."
)


def _norm(s):
    return re.sub(r"[^a-z0-9]+", " ", (s or "").lower()).strip()


def _parse_json(raw):
    raw = raw.strip()
    raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw)
    data = json.loads(raw)
    if isinstance(data, dict):
        data = data.get("questions", [])
    if not isinstance(data, list):
        raise ValueError("expected a JSON list")
    return data


def validate(item, seen):
    """Return a clean dict or a reason string."""
    try:
        question = str(item["question"]).strip()
        options = [str(o).strip() for o in item["options"]]
        index = int(item["correct_index"])
        difficulty = str(item.get("difficulty", "medium")).strip().lower()
    except (KeyError, TypeError, ValueError):
        return "bad structure"
    if len(options) != 4 or index not in range(4):
        return "needs exactly 4 options and a valid correct_index"
    if any(not o for o in options) or len({_norm(o) for o in options}) != 4:
        return "empty or duplicate options"
    if not 15 <= len(question) <= 400:
        return "question length out of range"
    if any(re.search(r"(all|none) of the above", o, re.I) for o in options):
        return "'all/none of the above' option"
    if difficulty not in DIFFICULTIES:
        difficulty = "medium"
    if _norm(question) in seen or _norm(question)[:60] in {s[:60] for s in seen}:
        return "duplicate of an existing question"
    return {"question": question, "options": options, "correct_index": index, "difficulty": difficulty}


def shuffle_options(clean):
    """Models like to put the answer in the same slot; randomise it."""
    correct = clean["options"][clean["correct_index"]]
    options = clean["options"][:]
    random.shuffle(options)
    clean["options"] = options
    clean["correct_index"] = options.index(correct)
    return clean


def generate(skill, existing_questions, count):
    prompt = (
        f"Skill: {skill['name']} (category: {skill['category']}). {skill['description'] or ''}\n"
        f"Write {count} NEW multiple-choice questions that test practical understanding "
        f"of this skill for someone aiming at a career goal. Mix difficulties: easy, medium, hard.\n"
        f"Do NOT repeat or paraphrase these existing questions:\n- "
        + "\n- ".join(existing_questions[:20] or ["(none)"])
        + "\n\nReturn a JSON list. Each item: "
        '{"question": str, "options": [str, str, str, str], "correct_index": 0-3, '
        '"difficulty": "easy"|"medium"|"hard"}'
    )
    return _parse_json(ai_client.generate_text(
        prompt, system=SYSTEM, json_output=True, temperature=0.7, max_tokens=8192, timeout=120))


def independent_check(clean):
    """Second opinion: a fresh call answers the question without seeing the key.
    Returns (True/False, note). False + 'error' means the check could not run."""
    lines = [f"{LETTERS[i].upper()}. {o}" for i, o in enumerate(clean["options"])]
    prompt = (
        "Answer this multiple-choice question. Reply ONLY with JSON like {\"answer\": \"A\"}.\n\n"
        + clean["question"] + "\n" + "\n".join(lines)
    )
    last = "error"
    for _ in range(2):
        try:
            raw = ai_client.generate_text(
                prompt, system="You are a careful expert.", json_output=True,
                temperature=0, max_tokens=2048, timeout=90)
            data = json.loads(re.sub(r"^```(?:json)?\s*|\s*```$", "", raw.strip()))
            picked = str(data.get("answer", "")).strip().lower()[:1]
            return picked == LETTERS[clean["correct_index"]], f"model picked {picked.upper() or '?'}"
        except (ai_client.AIError, ValueError, AttributeError) as exc:
            last = f"error: {exc}"
    return False, last


def load_plan(names, target):
    """Short DB read; the connection is closed before any slow AI call."""
    plan = []
    with engine.connect() as conn:
        for name in names:
            skill = conn.execute(text(
                "SELECT id, name, category, description FROM skills WHERE lower(name) = lower(:n)"),
                {"n": name}).mappings().first()
            if skill is None:
                print(f"[skip] unknown skill: {name}")
                continue
            existing = [r[0] for r in conn.execute(text(
                "SELECT question FROM assessment_questions WHERE skill_id = :i"), {"i": skill["id"]})]
            plan.append((dict(skill), existing, target - len(existing)))
    return plan


def save(approved):
    with engine.connect() as conn:
        conn.execute(text(
            "SELECT setval(pg_get_serial_sequence('assessment_questions','id'), "
            "(SELECT COALESCE(MAX(id), 1) FROM assessment_questions))"))
        for skill, q in approved:
            conn.execute(text("""
                INSERT INTO assessment_questions
                  (skill, question, option_a, option_b, option_c, option_d,
                   correct_answer, difficulty, skill_id)
                VALUES (:skill, :q, :a, :b, :c, :d, :ans, :diff, :sid)
            """), {"skill": skill["name"], "q": q["question"], "a": q["options"][0],
                   "b": q["options"][1], "c": q["options"][2], "d": q["options"][3],
                   "ans": LETTERS[q["correct_index"]], "diff": q["difficulty"], "sid": skill["id"]})
        conn.commit()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--skills", required=True, help="comma separated skill names, e.g. Python,SQL")
    parser.add_argument("--target", type=int, default=4, help="questions wanted per skill (total)")
    parser.add_argument("--save", action="store_true", help="insert into the database")
    args = parser.parse_args()

    if not ai_client.is_configured():
        raise SystemExit("GEMINI_API_KEY is not set in backend/.env")

    names = [s.strip() for s in args.skills.split(",") if s.strip()]
    plan = load_plan(names, args.target)

    approved = []
    for skill, existing, need in plan:
        print(f"\n=== {skill['name']}: {len(existing)} existing, target {args.target} ===")
        if need <= 0:
            print("already enough questions")
            continue
        seen = {_norm(q) for q in existing}
        try:
            raw_items = generate(skill, existing, need + 3)
        except (ai_client.AIError, ValueError) as exc:
            print(f"[error] generation failed: {exc}")
            continue
        kept = 0
        for item in raw_items:
            if kept >= need:
                break
            clean = validate(item, seen)
            if isinstance(clean, str):
                print(f"  - rejected: {clean}")
                continue
            ok, note = independent_check(clean)
            if not ok:
                print(f"  - rejected ({note}): {clean['question'][:70]}")
                continue
            clean = shuffle_options(clean)
            seen.add(_norm(clean["question"]))
            approved.append((skill, clean))
            kept += 1
            print(f"  + [{clean['difficulty']}] {clean['question']}")
            for i, o in enumerate(clean["options"]):
                print(f"      {LETTERS[i].upper()}{'*' if i == clean['correct_index'] else ' '} {o}")

    print(f"\n{len(approved)} question(s) passed all checks.")
    if not args.save:
        print("DRY RUN: nothing saved. Review above, then re-run with --save.")
        return
    if approved:
        save(approved)
        print(f"Saved {len(approved)} question(s).")


if __name__ == "__main__":
    main()