"""
Gemini AI client for GrowthAI using Google's official `google-genai` SDK.

Reads GEMINI_API_KEY (and optional GEMINI_MODEL) from backend/.env or
process environment variables. Never logs, prints, or exposes the API key.
"""

import os
from pathlib import Path
import re
from typing import Any, Optional

from google import genai
from google.genai import errors, types

# Default and fallback Gemini models verified against the Google GenAI API.
DEFAULT_MODEL = "gemini-3.5-flash"

FALLBACK_MODELS = [
    "gemini-3.5-flash",
    "gemini-3.5-flash-lite",
    "gemini-3.1-flash-lite",
    "gemini-3.7-flash",
    "gemini-3.6-flash",
    "gemini-flash-lite-latest",
    "gemini-3-flash-preview",
]

COACH_SYSTEM_PROMPT = (
    "You are the GrowthAI Study Coach, a knowledgeable and supportive academic mentor for students.\n"
    "Always answer the student's question directly, completely, and clearly.\n"
    "When the student asks about a technical, academic, or software topic (such as Excel formulas, "
    "programming, math, or science), explain what the concept does, show its syntax or structure, "
    "and walk through a clear, concrete example.\n"
    "When the student asks about study planning, focus, or overcoming procrastination, provide "
    "practical, actionable steps tailored to their situation.\n"
    "If student study context is provided, use it only as helpful background when relevant.\n"
    "IMPORTANT: Output ONLY the final student-facing answer. Never output internal reasoning, "
    "self-check questions, rubric checklists (such as 'concise? Yes'), or 'Think' markers."
)

# Patterns that indicate leaked internal reasoning / checklist text rather than a real answer.
_CHECKLIST_LEAK_RE = re.compile(
    r"(?:concise\?\s*yes|concrete\s+example\?\s*yes|realistic\s+next\s+steps\?\s*yes|"
    r"tone\s+warm(?:/grounded)?\?\s*yes)",
    re.IGNORECASE,
)
_THOUGHT_TAG_RE = re.compile(
    r"<(?:thought|thinking)>.*?</(?:thought|thinking)>",
    re.IGNORECASE | re.DOTALL,
)


class AIError(RuntimeError):
    """Raised when the Gemini API is not configured or a request fails safely."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int = 502,
        error_code: str = "ai_error",
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.error_code = error_code


def _ensure_env() -> None:
    """Ensure backend/.env has been loaded into os.environ."""
    if os.getenv("GEMINI_API_KEY"):
        return
    try:
        from database import ENV_PATH, _load_env_file

        _load_env_file(ENV_PATH)
    except Exception:
        env_path = Path(__file__).resolve().parent / ".env"
        if env_path.is_file():
            for raw_line in env_path.read_text(encoding="utf-8").splitlines():
                line = raw_line.strip()
                if not line or line.startswith("#"):
                    continue
                if line.startswith("export "):
                    line = line[len("export ") :]
                key, sep, value = line.partition("=")
                if not sep:
                    continue
                key = key.strip()
                value = value.strip().strip("\"'")
                if key and key not in os.environ:
                    os.environ[key] = value


def _api_key() -> Optional[str]:
    _ensure_env()
    key = os.getenv("GEMINI_API_KEY")
    if not key:
        return None
    cleaned = key.strip()
    if not cleaned or cleaned.startswith("your-"):
        return None
    return cleaned


def _sanitize_message(text: str, secret: Optional[str] = None) -> str:
    """Strip any accidental secret value from error messages."""
    if not text:
        return "Unknown Gemini API error."
    out = str(text)
    if secret and secret in out:
        out = out.replace(secret, "[REDACTED]")
    raw_env_key = os.getenv("GEMINI_API_KEY")
    if raw_env_key and raw_env_key.strip() and raw_env_key.strip() in out:
        out = out.replace(raw_env_key.strip(), "[REDACTED]")
    return out


def is_configured() -> bool:
    """Return True if a non-placeholder GEMINI_API_KEY is available."""
    return bool(_api_key())


def get_active_model() -> str:
    """Return the configured primary Gemini model name."""
    _ensure_env()
    configured = (os.getenv("GEMINI_MODEL") or "").strip()
    if configured.startswith("models/"):
        configured = configured[len("models/") :]
    return configured or DEFAULT_MODEL


def _candidate_models(prefer: Optional[list[str]] = None) -> list[str]:
    primary = get_active_model()
    raw_order = (list(prefer) if prefer else []) + [primary] + FALLBACK_MODELS
    models: list[str] = []
    for m in raw_order:
        if not m:
            continue
        clean = m.strip()
        if clean.startswith("models/"):
            clean = clean[len("models/") :]
        if clean and clean not in models:
            models.append(clean)
    return models


def _create_client(api_key: str, timeout_seconds: int = 60) -> genai.Client:
    timeout_ms = max(2000, int(timeout_seconds * 1000))
    http_options = types.HttpOptions(
        timeout=timeout_ms,
        retry_options=types.HttpRetryOptions(attempts=1),
    )
    return genai.Client(api_key=api_key, http_options=http_options)


def _clean_coach_answer(raw_text: str) -> str:
    """
    Strip any leaked internal thinking tags or checklist preambles and validate
    that the remaining text is a genuine student-facing answer.
    """
    if not raw_text:
        return ""

    cleaned = _THOUGHT_TAG_RE.sub("", raw_text).strip()

    # If the model leaked a checklist preamble ending with "Think" before the real answer,
    # strip the preamble up through the "Think" marker.
    if _CHECKLIST_LEAK_RE.search(cleaned):
        think_split = re.split(r"\bThink\b[:\s]*", cleaned, maxsplit=1)
        if len(think_split) == 2 and _CHECKLIST_LEAK_RE.search(think_split[0]):
            cleaned = think_split[1].strip()

    # Remove any isolated checklist lines that still remain.
    filtered_lines: list[str] = []
    for line in cleaned.splitlines():
        if _CHECKLIST_LEAK_RE.search(line):
            continue
        if re.fullmatch(r"\s*Think\.?\s*", line, flags=re.IGNORECASE):
            continue
        filtered_lines.append(line)

    cleaned = "\n".join(filtered_lines).strip()
    cleaned = re.sub(r"(?:\.\s*|\s+)Think\s*$", "", cleaned).strip()
    return cleaned


def _extract_response_text(response: Any) -> str:
    """
    Extract generated text from a google-genai GenerateContentResponse,
    explicitly excluding internal `thought` parts (`part.thought == True`).
    """
    candidates = getattr(response, "candidates", None) or []
    if candidates:
        content = getattr(candidates[0], "content", None)
        parts = getattr(content, "parts", None) or []
        if parts:
            non_thought_chunks = [
                p.text
                for p in parts
                if not getattr(p, "thought", False)
                and isinstance(getattr(p, "text", None), str)
            ]
            joined = "".join(non_thought_chunks).strip()
            if joined:
                return joined

    try:
        direct_text = getattr(response, "text", None)
        if isinstance(direct_text, str) and direct_text.strip():
            return direct_text.strip()
    except Exception:
        pass

    if not candidates:
        raise AIError(
            "Gemini returned no candidates (the prompt may have been blocked by safety filters).",
            status_code=502,
            error_code="empty_candidates",
        )

    raise AIError(
        "Gemini returned an empty response.",
        status_code=502,
        error_code="empty_response",
    )


def _generate_single_model(
    client: genai.Client,
    model_name: str,
    contents: Any,
    config: types.GenerateContentConfig,
) -> Any:
    """
    Call `client.models.generate_content`. If `thinking_config` is set on `config`
    and a lite model rejects `thinking_config` with HTTP 400 INVALID_ARGUMENT,
    retry once on the same model without `thinking_config`.
    """
    try:
        return client.models.generate_content(
            model=model_name,
            contents=contents,
            config=config,
        )
    except errors.APIError as exc:
        status_code = getattr(exc, "code", None)
        msg = (getattr(exc, "message", "") or str(exc)).lower()
        if (
            status_code == 400
            and getattr(config, "thinking_config", None) is not None
            and "api_key" not in msg
            and "api key" not in msg
        ):
            fallback_cfg = config.model_copy(update={"thinking_config": None})
            return client.models.generate_content(
                model=model_name,
                contents=contents,
                config=fallback_cfg,
            )
        raise


def _call_gemini_with_fallback(
    *,
    contents: Any,
    config: types.GenerateContentConfig,
    timeout: int = 60,
    prefer: Optional[list[str]] = None,
    sanitize_coach_output: bool = False,
) -> tuple[str, str]:
    """
    Execute `client.models.generate_content` across candidate models.
    Returns `(text, model_used)`.
    """
    key = _api_key()
    if not key:
        raise AIError(
            "GEMINI_API_KEY is not set. Add it to backend/.env to enable AI features.",
            status_code=503,
            error_code="missing_api_key",
        )

    client = _create_client(key, timeout_seconds=timeout)
    models = _candidate_models(prefer=prefer)

    saw_quota_error = False
    saw_unavailable_error = False
    last_error_detail = "All candidate Gemini models failed."

    for model_name in models:
        try:
            response = _generate_single_model(
                client=client,
                model_name=model_name,
                contents=contents,
                config=config,
            )
            text = _extract_response_text(response)
            if sanitize_coach_output:
                text = _clean_coach_answer(text)
                if not text or _CHECKLIST_LEAK_RE.search(text):
                    last_error_detail = (
                        f"Gemini model {model_name} returned an incomplete or invalid response."
                    )
                    saw_unavailable_error = True
                    continue
            return text, model_name
        except AIError as exc:
            if exc.error_code in ("empty_candidates", "empty_response"):
                last_error_detail = str(exc)
                saw_unavailable_error = True
                continue
            raise
        except errors.APIError as exc:
            status_code = getattr(exc, "code", None) or 502
            safe_msg = _sanitize_message(getattr(exc, "message", "") or str(exc), key)
            lower_msg = safe_msg.lower()

            # Authentication / invalid API key errors should fail immediately.
            if status_code in (401, 403) or (
                status_code == 400
                and ("api_key_invalid" in lower_msg or "api key not valid" in lower_msg)
            ):
                raise AIError(
                    "Gemini API authentication failed. Please verify that GEMINI_API_KEY in backend/.env is valid.",
                    status_code=503,
                    error_code="invalid_api_key",
                ) from None

            # Quota / rate limit (429): try fallback models before giving up.
            if status_code == 429 or "resource_exhausted" in lower_msg or "quota" in lower_msg:
                saw_quota_error = True
                last_error_detail = "Gemini API quota or rate limit reached."
                continue

            # Model deprecated/not found (404) or transient server demand (500/502/503/504): try next model.
            if status_code in (404, 500, 502, 503, 504):
                if status_code in (500, 502, 503, 504):
                    saw_unavailable_error = True
                last_error_detail = f"Gemini model {model_name} unavailable (HTTP {status_code})."
                continue

            raise AIError(
                f"Gemini API request failed (HTTP {status_code}).",
                status_code=502,
                error_code="api_error",
            ) from None
        except Exception as exc:
            safe_msg = _sanitize_message(str(exc), key)
            last_error_detail = f"Failed to reach Gemini API: {safe_msg}"
            saw_unavailable_error = True
            continue

    if saw_quota_error:
        raise AIError(
            "Gemini API quota or rate limit exceeded. Please wait a moment and try again.",
            status_code=429,
            error_code="quota_exceeded",
        )

    if saw_unavailable_error:
        raise AIError(
            "Gemini AI service is temporarily experiencing high demand or is unreachable. Please try again shortly.",
            status_code=503,
            error_code="service_unavailable",
        )

    raise AIError(
        _sanitize_message(last_error_detail, key),
        status_code=502,
        error_code="all_models_failed",
    )


def generate_text(
    prompt: str,
    *,
    system: Optional[str] = None,
    json_output: bool = False,
    temperature: float = 0.4,
    max_tokens: int = 2048,
    timeout: int = 60,
    prefer: Optional[list[str]] = None,
) -> str:
    """
    Send a single-turn prompt to Gemini using `google-genai` and return the text response.
    Preserves full compatibility with `ai_goal_skills.py` and `generate_questions.py`.
    """
    config_kwargs: dict[str, Any] = {
        "temperature": temperature,
        "max_output_tokens": max_tokens,
        "response_mime_type": "application/json" if json_output else "text/plain",
        "thinking_config": types.ThinkingConfig(
            include_thoughts=False,
            thinking_budget=0,
        ),
    }
    if system:
        config_kwargs["system_instruction"] = system

    config = types.GenerateContentConfig(**config_kwargs)
    text, _ = _call_gemini_with_fallback(
        contents=prompt,
        config=config,
        timeout=timeout,
        prefer=prefer,
    )
    return text


def _build_coach_contents(
    question: str,
    *,
    student_context: Optional[str] = None,
    history: Optional[list[dict[str, str]]] = None,
) -> list[types.Content]:
    """
    Build structured multi-turn `types.Content` objects that clearly separate
    conversation history, optional student study context, and the student's question.
    """
    contents: list[types.Content] = []
    if history:
        for turn in history[-8:]:
            if not isinstance(turn, dict):
                continue
            raw_role = str(turn.get("role") or "").strip().lower()
            text_val = _clean_coach_answer(str(turn.get("content") or "").strip())
            if not text_val:
                continue
            sdk_role = "model" if raw_role in ("assistant", "model", "coach") else "user"
            contents.append(
                types.Content(
                    role=sdk_role,
                    parts=[types.Part.from_text(text=text_val[:2000])],
                )
            )

    cleaned_context = (student_context or "").strip()
    if cleaned_context:
        user_prompt = (
            "Student Study Context (background reference only):\n"
            f"{cleaned_context}\n\n"
            "Student Question:\n"
            f"{question}"
        )
    else:
        user_prompt = question

    contents.append(
        types.Content(
            role="user",
            parts=[types.Part.from_text(text=user_prompt)],
        )
    )
    return contents


def generate_coach_reply(
    question: str,
    *,
    student_context: Optional[str] = None,
    history: Optional[list[dict[str, str]]] = None,
    temperature: float = 0.4,
    max_tokens: int = 2048,
    timeout: int = 45,
) -> dict[str, str]:
    """
    Generate a conversational AI Study Coach answer for a student's question.
    Returns `{"answer": str, "model": str}`.
    """
    cleaned_question = (question or "").strip()
    if not cleaned_question:
        raise AIError(
            "Question must not be empty.",
            status_code=400,
            error_code="empty_question",
        )

    contents = _build_coach_contents(
        cleaned_question,
        student_context=student_context,
        history=history,
    )

    config = types.GenerateContentConfig(
        system_instruction=COACH_SYSTEM_PROMPT,
        temperature=temperature,
        max_output_tokens=max_tokens,
        response_mime_type="text/plain",
        thinking_config=types.ThinkingConfig(
            include_thoughts=False,
            thinking_budget=0,
        ),
    )

    answer_text, model_used = _call_gemini_with_fallback(
        contents=contents,
        config=config,
        timeout=timeout,
        sanitize_coach_output=True,
    )
    return {
        "answer": answer_text,
        "model": model_used,
    }
