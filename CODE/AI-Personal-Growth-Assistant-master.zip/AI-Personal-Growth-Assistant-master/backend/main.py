from datetime import date, datetime
import hashlib
import hmac
import os
from typing import List, Optional

from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError
from pydantic import BaseModel, EmailStr

from database import engine
import ai_goal_skills
from security import (
    create_token,
    get_current_user,
    get_jwt_secret,
    hash_password,
    validate_password_strength,
    verify_password,
)


def _get_owned_goal(connection, goal_id: int, user_id: int):
    """Fetch a goal owned by user_id or raise 404 (avoids leaking existence)."""
    row = connection.execute(
        text("SELECT id, user_id FROM goals WHERE id = :goal_id"),
        {"goal_id": goal_id},
    ).fetchone()
    if row is None or row.user_id != user_id:
        raise HTTPException(status_code=404, detail="Goal not found")
    return row


def _get_owned_attempt(connection, attempt_id: int, user_id: int):
    """Fetch an assessment attempt owned by user_id or raise 404."""
    row = connection.execute(
        text("SELECT id, user_id, goal_id, status, started_at FROM assessment_attempts WHERE id = :attempt_id"),
        {"attempt_id": attempt_id},
    ).fetchone()
    if row is None or row.user_id != user_id:
        raise HTTPException(status_code=404, detail="Assessment attempt not found")
    return row


# ---------- Request/response models ----------

class RegisterRequest(BaseModel):
    name: str
    email: EmailStr
    password: str


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class HabitCreate(BaseModel):
    name: str
    frequency: str = "daily"
    target_count: int = 1


class ProgressCreate(BaseModel):
    habit_id: int
    completed: bool
    notes: str = ""


class TaskCreate(BaseModel):
    goal_id: int
    title: str
    description: str = ""
    estimated_minutes: int = 30
    difficulty: str = "medium"
    scheduled_date: Optional[str] = None  # YYYY-MM-DD; defaults to today (DB)
    scheduled_time: Optional[str] = None  # HH:MM


class TaskStatusUpdate(BaseModel):
    status: str


class TaskLogCreate(BaseModel):
    task_id: int
    status: str
    reason: str = ""
    actual_minutes: Optional[int] = None


class EnergyCheckinCreate(BaseModel):
    energy_level: str
    notes: str = ""


class ProfileCreate(BaseModel):
    age: Optional[int] = None
    occupation: str = ""
    daily_available_minutes: int = 60
    productive_time: str = ""
    sleep_hours: Optional[float] = None
    distraction_level: str = ""
    procrastination_level: str = ""
    challenges: str = ""


class AssessmentStartRequest(BaseModel):
    goal_id: int


class GoalCreate(BaseModel):
    title: str
    description: str = ""
    target_date: Optional[str] = None  # YYYY-MM-DD
    status: str = "active"


class GoalUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    target_date: Optional[str] = None
    status: Optional[str] = None


class AssessmentAnswerRequest(BaseModel):
    attempt_id: int
    question_id: int
    selected_answer: str
    time_ms: Optional[int] = None  # informational only; server clock is authoritative


class AssessmentCompleteRequest(BaseModel):
    attempt_id: int


class AssessmentSubmitAnswer(BaseModel):
    question_id: int
    selected_answer: str
    time_ms: Optional[int] = None


class AssessmentSubmitRequest(BaseModel):
    attempt_id: int
    answers: List[AssessmentSubmitAnswer]
    tab_switches: int = 0  # informational integrity signal, never affects scoring


# ---------- App setup ----------

app = FastAPI(title="AI Personal Growth Assistant")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:4173",
        "http://127.0.0.1:4173",
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:5174",
        "http://127.0.0.1:5174",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------- Auth ----------

@app.post("/register")
def register_user(data: RegisterRequest):
    policy_error = validate_password_strength(data.password)
    if policy_error:
        raise HTTPException(status_code=400, detail=policy_error)

    hashed_password = hash_password(data.password)

    try:
        with engine.connect() as conn:
            result = conn.execute(
                text("""
                    INSERT INTO users (name, email, password_hash)
                    VALUES (:name, :email, :password_hash)
                    RETURNING id, name, email
                """),
                {
                    "name": data.name,
                    "email": data.email,
                    "password_hash": hashed_password,
                },
            )
            user = result.fetchone()
            conn.commit()
    except IntegrityError:
        raise HTTPException(status_code=400, detail="Email is already registered")

    return {
        "message": "Registration successful",
        "user": {
            "id": user.id,
            "name": user.name,
            "email": user.email,
        },
    }


@app.post("/login")
def login_user(data: LoginRequest):
    with engine.connect() as conn:
        result = conn.execute(
            text("""
                SELECT id, name, email, password_hash
                FROM users
                WHERE email = :email
            """),
            {"email": data.email},
        )
        user = result.fetchone()

    if user is None or not verify_password(data.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid email or password")

    return {
        "message": "Login successful",
        "access_token": create_token(user.id),
        "token_type": "bearer",
        "user": {
            "id": user.id,
            "name": user.name,
            "email": user.email,
        },
    }


@app.get("/me")
def me(user: dict = Depends(get_current_user)):
    return {"user": user}


@app.get("/")
def home():
    return {"message": "AI Personal Growth Assistant API is running!"}


@app.get("/database-test")
def database_test():
    try:
        with engine.connect():
            return {"status": "success", "message": "FastAPI connected to PostgreSQL!"}
    except Exception as e:
        return {"status": "error", "message": str(e)}


# ---------- Goals ----------

GOAL_STATUSES = {"active", "completed", "archived"}
TASK_DIFFICULTIES = {"easy", "medium", "hard"}
_DATE_FORMAT = "%Y-%m-%d"


PREDICTION_FEATURES = [
    "duration_minutes", "duration_missing", "available_minutes", "energy_level",
    "historical_completion_rate", "historical_skip_rate", "recent_skip_count",
    "difficulty", "productive_time_match",
]


def _prediction_features(duration, available_minutes, energy, completion_rate,
                         skip_rate, recent_skips, difficulty, scheduled_time,
                         productive_time):
    energy_values = {"very low": 1, "low": 1, "medium": 2, "high": 3, "very high": 3}
    difficulty_values = {"easy": 1, "medium": 2, "hard": 3}
    energy_value = energy_values.get((energy or "").strip().lower(), 0)
    match = 0
    if scheduled_time and productive_time:
        hour = scheduled_time.hour if hasattr(scheduled_time, "hour") else int(str(scheduled_time)[:2])
        period = "morning" if 5 <= hour < 12 else "afternoon" if 12 <= hour < 17 else "evening"
        match = int(period in productive_time.lower())
    return [
        float(duration or 0), int(duration is None), float(available_minutes or 0),
        float(energy_value), float(completion_rate), float(skip_rate),
        float(recent_skips), float(difficulty_values.get((difficulty or "").lower(), 0)),
        float(match),
    ]


def _prediction_model(connection, user_id, exclude_task_id):
    """Return strictly user-local historical examples ordered by outcome time."""
    records = connection.execute(text("""
        SELECT t.estimated_minutes, t.difficulty, t.scheduled_time, l.status, l.logged_at,
               energy.energy_level
        FROM (
            SELECT DISTINCT ON (task_id) task_id, user_id, status, logged_at, id
            FROM task_logs
            WHERE user_id = :user_id AND status IN ('completed', 'skipped')
              AND task_id <> :exclude_task_id
            ORDER BY task_id, logged_at DESC, id DESC
        ) l
        JOIN tasks t ON t.id = l.task_id AND t.user_id = :user_id
        LEFT JOIN LATERAL (
            SELECT e.energy_level FROM energy_checkins e
            WHERE e.user_id = :user_id
              AND (e.checkin_date + e.checkin_time) <= l.logged_at
            ORDER BY e.checkin_date DESC, e.checkin_time DESC LIMIT 1
        ) energy ON TRUE
        ORDER BY l.logged_at, l.id
    """), {"user_id": user_id, "exclude_task_id": exclude_task_id}).fetchall()
    profile = connection.execute(text("""
        SELECT daily_available_minutes, productive_time FROM user_profiles
        WHERE user_id = :user_id ORDER BY id DESC LIMIT 1
    """), {"user_id": user_id}).fetchone()
    available = profile.daily_available_minutes if profile else None
    productive = profile.productive_time if profile else None

    features, labels, prior_labels = [], [], []
    for row in records:
        total = len(prior_labels)
        completed = sum(prior_labels)
        skipped = total - completed
        recent_skips = sum(1 for label in prior_labels[-5:] if label == 0)
        features.append(_prediction_features(
            row.estimated_minutes, available, row.energy_level,
            completed / total if total else 0,
            skipped / total if total else 0,
            recent_skips, row.difficulty, row.scheduled_time, productive,
        ))
        labels.append(1 if row.status == "completed" else 0)
        prior_labels.append(labels[-1])
    return features, labels, available, productive


def _parse_date_or_400(value: Optional[str], field_name: str):
    if value is None:
        return None
    try:
        return datetime.strptime(value, _DATE_FORMAT).date()
    except ValueError:
        raise HTTPException(status_code=400, detail=f"{field_name} must be YYYY-MM-DD")


def _parse_time_or_400(value: Optional[str]):
    if value is None:
        return None
    try:
        return datetime.strptime(value, "%H:%M").time()
    except ValueError:
        raise HTTPException(status_code=400, detail="scheduled_time must be HH:MM (24-hour)")
# Built-in skill sets for the demo goals. Used only when no existing goal with
# the same title has skills yet (for example on a freshly created database).
DEFAULT_GOAL_SKILLS = {
    "become a data analyst": [
        ("Python", "high"), ("SQL", "high"), ("Statistics", "high"),
        ("Excel", "medium"), ("Data Visualization", "medium"),
    ],
    "become a business owner": [
        ("Market Research", "high"), ("Marketing", "high"), ("Finance", "high"),
        ("Sales", "high"), ("Communication", "medium"),
    ],
    "prepare for neet biology": [
        ("Human Physiology", "high"), ("Genetics", "high"), ("Cell Biology", "medium"),
    ],
}

def _create_goal(data: GoalCreate, current_user: dict):
    if not data.title.strip():
        raise HTTPException(status_code=400, detail="Title is required")
    if data.status not in GOAL_STATUSES:
        raise HTTPException(status_code=400, detail="Status must be active, completed or archived")

    target_date = _parse_date_or_400(data.target_date, "target_date")

    with engine.connect() as connection:
        query = text("""
            INSERT INTO goals (user_id, title, description, target_date, status)
            VALUES (:user_id, :title, :description, :target_date, :status)
            RETURNING id, user_id, title, description, target_date, status
        """)
        result = connection.execute(query, {
            "user_id": current_user["id"],
            "title": data.title.strip(),
            "description": data.description.strip(),
            "target_date": target_date,
            "status": data.status,
        })
        goal = result.fetchone()

        # Template-based goal-skill mapping: reuse the skill set of the
        # earliest existing goal with the same title (case-insensitive).
        skills_mapped = 0
        template = connection.execute(
            text("""
                SELECT g.id FROM goals g
                WHERE g.id <> :new_id
                  AND lower(trim(g.title)) = lower(trim(:title))
                  AND EXISTS (SELECT 1 FROM goal_skills gs WHERE gs.goal_id = g.id)
                ORDER BY g.id
                LIMIT 1
            """),
            {"new_id": goal.id, "title": goal.title},
                ).fetchone()
        if template is not None:
            mapped = connection.execute(
                text("""
                    INSERT INTO goal_skills (goal_id, skill_id, importance)
                    SELECT :new_id, gs.skill_id, gs.importance
                    FROM goal_skills gs
                    WHERE gs.goal_id = :template_id
                """),
                {"new_id": goal.id, "template_id": template.id},
            )
            skills_mapped = mapped.rowcount
        else:
            # Fall back to built-in mappings when this title has no populated template.
            fallback_skills = DEFAULT_GOAL_SKILLS.get(goal.title.strip().lower(), [])
            for skill_name, importance in fallback_skills:
                mapped = connection.execute(
                    text("""
                        INSERT INTO goal_skills (goal_id, skill_id, importance)
                        SELECT :goal_id, s.id, :importance
                        FROM skills s
                        WHERE lower(trim(s.name)) = lower(trim(:skill_name))
                    """),
                    {"goal_id": goal.id, "skill_name": skill_name, "importance": importance},
                )
                skills_mapped += mapped.rowcount

        connection.commit()

    if skills_mapped == 0:
        # No template for this title: the AI prepares skills + questions in the background.
        try:
            ai_goal_skills.ensure_goal_skills_async(goal.id)
        except Exception:
            pass

    return {
        "message": "Goal created successfully"
        if skills_mapped
        else "Goal created. For a new topic the AI is preparing the skills; open Skill assessment and check again in a minute.",
        "skills_mapped": skills_mapped,
        "goal": {
            "id": goal.id,
            "user_id": goal.user_id,
            "title": goal.title,
            "description": goal.description,
            "target_date": goal.target_date,
            "status": goal.status,
        },
    }


@app.post("/goals")
def create_goal(data: GoalCreate, current_user: dict = Depends(get_current_user)):
    return _create_goal(data, current_user)


@app.put("/goals/{goal_id}")
def update_goal(goal_id: int, data: GoalUpdate, current_user: dict = Depends(get_current_user)):
    updates = data.model_dump(exclude_none=True)

    if not updates:
        raise HTTPException(status_code=400, detail="No fields to update")
    if "title" in updates:
        if not str(updates["title"]).strip():
            raise HTTPException(status_code=400, detail="Title cannot be empty")
        updates["title"] = str(updates["title"]).strip()
    if "description" in updates:
        updates["description"] = str(updates["description"]).strip()
    if "status" in updates and updates["status"] not in GOAL_STATUSES:
        raise HTTPException(status_code=400, detail="Status must be active, completed or archived")

    set_clauses = []
    params = {"goal_id": goal_id, "user_id": current_user["id"]}
    for field, value in updates.items():
        if field == "target_date":
            params["target_date"] = _parse_date_or_400(value, "target_date")
            set_clauses.append("target_date = :target_date")
        else:
            params[field] = value
            set_clauses.append(f"{field} = :{field}")

    with engine.connect() as connection:
        _get_owned_goal(connection, goal_id, current_user["id"])
        query = text(f"""
            UPDATE goals
            SET {', '.join(set_clauses)}
            WHERE id = :goal_id AND user_id = :user_id
            RETURNING id, user_id, title, description, target_date, status
        """)
        result = connection.execute(query, params)
        connection.commit()
        goal = result.fetchone()

    if goal is None:
        raise HTTPException(status_code=404, detail="Goal not found")

    return {
        "message": "Goal updated successfully",
        "goal": {
            "id": goal.id,
            "user_id": goal.user_id,
            "title": goal.title,
            "description": goal.description,
            "target_date": goal.target_date,
            "status": goal.status,
        },
    }


@app.get("/goals")
def get_goals(current_user: dict = Depends(get_current_user)):
    with engine.connect() as connection:
        query = text("""
            SELECT id, user_id, title, description, target_date, status
            FROM goals
            WHERE user_id = :user_id
            ORDER BY id
        """)
        result = connection.execute(query, {"user_id": current_user["id"]})
        goals = [
            {
                "id": row.id,
                "user_id": row.user_id,
                "title": row.title,
                "description": row.description,
                "target_date": row.target_date,
                "status": row.status,
            }
            for row in result
        ]
        return {"goals": goals}


@app.get("/goals/{goal_id}/skills")
def get_goal_skills(goal_id: int, current_user: dict = Depends(get_current_user)):
    with engine.connect() as connection:
        _get_owned_goal(connection, goal_id, current_user["id"])
        query = text("""
            SELECT s.id, s.name, s.category, s.description, gs.importance
            FROM goal_skills gs
            JOIN skills s ON s.id = gs.skill_id
            WHERE gs.goal_id = :goal_id
            ORDER BY CASE gs.importance WHEN 'high' THEN 0 WHEN 'medium' THEN 1 WHEN 'low' THEN 2 ELSE 3 END, s.name
        """)
        result = connection.execute(query, {"goal_id": goal_id})
        skills = [
            {
                "id": row.id,
                "name": row.name,
                "category": row.category,
                "description": row.description,
                "importance": row.importance,
            }
            for row in result
        ]
        preparing = False
        if not skills:
            try:
                preparing = ai_goal_skills.ensure_goal_skills_async(goal_id)
            except Exception:
                preparing = False
        return {"goal_id": goal_id, "skills": skills, "preparing": preparing}

@app.get("/goals/{goal_id}/skill-gaps")
def get_skill_gaps(goal_id: int, current_user: dict = Depends(get_current_user)):
    with engine.connect() as connection:
        _get_owned_goal(connection, goal_id, current_user["id"])
        query = text("""
            SELECT gs.skill_id, s.name, s.category, gs.importance,
                   sa.score_percentage, sa.skill_level
            FROM goal_skills gs
            JOIN skills s ON s.id = gs.skill_id
            LEFT JOIN LATERAL (
                SELECT score_percentage, skill_level
                FROM skill_assessments sa2
                WHERE sa2.user_id = :user_id
                  AND sa2.goal_id = :goal_id
                  AND sa2.skill_id = gs.skill_id
                ORDER BY sa2.created_at DESC
                LIMIT 1
            ) sa ON TRUE
            WHERE gs.goal_id = :goal_id
            ORDER BY CASE gs.importance WHEN 'high' THEN 0 WHEN 'medium' THEN 1 WHEN 'low' THEN 2 ELSE 3 END, s.name
        """)
        result = connection.execute(query, {"goal_id": goal_id, "user_id": current_user["id"]})

        skills = []
        for row in result:
            if row.skill_level is None:
                gap_status = "not_assessed"
            elif row.skill_level in ("beginner", "intermediate"):
                gap_status = "gap"
            else:
                gap_status = "strong"

            skills.append({
                "skill_id": row.skill_id,
                "name": row.name,
                "category": row.category,
                "importance": row.importance,
                "score_percentage": row.score_percentage,
                "skill_level": row.skill_level,
                "gap_status": gap_status,
            })

        return {"goal_id": goal_id, "user_id": current_user["id"], "skills": skills}

@app.get("/goals/{goal_id}/roadmap")
def get_roadmap(goal_id: int, current_user: dict = Depends(get_current_user)):
    with engine.connect() as connection:
        _get_owned_goal(connection, goal_id, current_user["id"])
        query = text("""
            SELECT gs.skill_id, s.name, s.category, gs.importance,
                   sa.score_percentage, sa.skill_level
            FROM goal_skills gs
            JOIN skills s ON s.id = gs.skill_id
            LEFT JOIN LATERAL (
                SELECT score_percentage, skill_level
                FROM skill_assessments sa2
                WHERE sa2.user_id = :user_id
                  AND sa2.goal_id = :goal_id
                  AND sa2.skill_id = gs.skill_id
                ORDER BY sa2.created_at DESC
                LIMIT 1
            ) sa ON TRUE
            WHERE gs.goal_id = :goal_id
        """)
        result = connection.execute(query, {"goal_id": goal_id, "user_id": current_user["id"]})

        importance_rank = {"high": 0, "medium": 1, "low": 2}
        items = []

        for row in result:
            if row.skill_level is None:
                gap_status = "not_assessed"
                priority = 1
                recommendation = f"Take the skill assessment for {row.name} to find your level."
            elif row.skill_level == "beginner":
                gap_status = "gap"
                priority = 0
                recommendation = f"Start with {row.name} fundamentals — this is a weak area."
            elif row.skill_level == "intermediate":
                gap_status = "gap"
                priority = 0
                recommendation = f"Strengthen {row.name} with practice tasks — you're partway there."
            else:
                gap_status = "strong"
                priority = 2
                recommendation = f"{row.name} is solid — light review is enough."

            items.append({
                "skill_id": row.skill_id,
                "name": row.name,
                "category": row.category,
                "importance": row.importance,
                "skill_level": row.skill_level,
                "gap_status": gap_status,
                "recommendation": recommendation,
                "_priority": priority,
                "_importance_rank": importance_rank.get(row.importance, 3),
            })

        items.sort(key=lambda x: (x["_priority"], x["_importance_rank"]))

        roadmap = []
        for step_number, item in enumerate(items, start=1):
            item.pop("_priority")
            item.pop("_importance_rank")
            item["step"] = step_number
            roadmap.append(item)

        return {"goal_id": goal_id, "user_id": current_user["id"], "roadmap": roadmap}
# ---------- Assessment ----------

# Server-enforced time budget and attempt cap (see .env.example).
PER_QUESTION_SECONDS = int(os.getenv("ASSESSMENT_SECONDS_PER_QUESTION", "120"))
SUBMIT_GRACE_SECONDS = int(os.getenv("ASSESSMENT_SUBMIT_GRACE_SECONDS", "30"))
MAX_ATTEMPTS_PER_GOAL = int(os.getenv("MAX_ASSESSMENT_ATTEMPTS_PER_GOAL", "5"))
_VALID_LETTERS = set("abcd")


def _attempt_hmac(attempt_id: int, purpose: str, *parts) -> str:
    """Deterministic per-attempt ordering key.

    Uses the same secret as token signing; the purpose prefix keeps the
    namespaces separate. Presentation is never stored — it is recomputed
    identically on every request for the life of the attempt.
    """
    message = ":".join([purpose, str(attempt_id), *[str(p) for p in parts]])
    return hmac.new(get_jwt_secret(), message.encode("utf-8"), hashlib.sha256).hexdigest()


def _shuffle_options(attempt_id: int, question_id: int, options: dict) -> list:
    """Return [(canonical_letter, text)] in this attempt's deterministic order."""
    pairs = sorted(
        options.items(),
        key=lambda item: (_attempt_hmac(attempt_id, "opts", question_id, item[0]), item[0]),
    )
    return pairs


def _presented_to_canonical(attempt_id: int, question_id: int, options: dict, presented_letter: str):
    """Translate a letter the user saw back to the canonical DB letter by
    recomputing the exact mapping used when the question was served."""
    presented = presented_letter.strip().lower()
    ordered = _shuffle_options(attempt_id, question_id, options)
    for position, (canonical_letter, _) in enumerate(ordered):
        if "abcd"[position] == presented:
            return canonical_letter
    return None


def _deadline_seconds(question_count: int) -> int:
    return question_count * PER_QUESTION_SECONDS + SUBMIT_GRACE_SECONDS


def _elapsed_seconds(connection, attempt_id: int) -> float:
    """Elapsed time measured entirely on the server clock."""
    return float(connection.execute(
        text("SELECT EXTRACT(EPOCH FROM (now() - started_at)) FROM assessment_attempts WHERE id = :i"),
        {"i": attempt_id},
    ).scalar() or 0)


def _ensure_attempt_not_expired(connection, attempt) -> None:
    """Enforce the server-side budget; mark and reject expired attempts."""
    question_count = connection.execute(
        text("""
            SELECT COUNT(*) FROM assessment_questions aq
            JOIN goal_skills gs ON gs.skill_id = aq.skill_id
            WHERE gs.goal_id = :goal_id
        """),
        {"goal_id": attempt.goal_id},
    ).scalar() or 0

    if _elapsed_seconds(connection, attempt.id) > _deadline_seconds(question_count):
        connection.execute(
            text("UPDATE assessment_attempts SET status = 'expired' WHERE id = :i"),
            {"i": attempt.id},
        )
        connection.commit()
        raise HTTPException(
            status_code=400,
            detail="Assessment time limit exceeded — this attempt has expired.",
        )


def _load_goal_question_rows(connection, goal_id: int):
    return connection.execute(
        text("""
            SELECT aq.id, aq.skill_id, aq.question,
                   aq.option_a, aq.option_b, aq.option_c, aq.option_d,
                   aq.difficulty, aq.correct_answer
            FROM assessment_questions aq
            JOIN goal_skills gs ON gs.skill_id = aq.skill_id
            WHERE gs.goal_id = :goal_id
        """),
        {"goal_id": goal_id},
    ).fetchall()


def _build_presentation(attempt_id: int, rows) -> list:
    """Deterministic per-attempt question order and option layout."""
    ordered = sorted(rows, key=lambda r: (_attempt_hmac(attempt_id, "qorder", r.id), r.id))
    questions = []
    for row in ordered:
        options = {
            "a": row.option_a,
            "b": row.option_b,
            "c": row.option_c,
            "d": row.option_d,
        }
        shuffled = _shuffle_options(attempt_id, row.id, options)
        questions.append({
            "id": row.id,
            "skill_id": row.skill_id,
            "question": row.question,
            "difficulty": row.difficulty,
            "options": [
                {"letter": "abcd"[position], "text": option_text}
                for position, (_, option_text) in enumerate(shuffled)
            ],
        })
    return questions


@app.post("/assessment/start")
def start_assessment(data: AssessmentStartRequest, current_user: dict = Depends(get_current_user)):
    with engine.connect() as connection:
        _get_owned_goal(connection, data.goal_id, current_user["id"])

        # Skills with no questions yet are being prepared by the AI in the background.
        if ai_goal_skills.prepare_goal_questions(data.goal_id):
            raise HTTPException(
                status_code=409,
                detail="Your assessment questions are still being prepared. Please try again in a minute.",
            )

        rows = _load_goal_question_rows(connection, data.goal_id)
        if not rows:
            raise HTTPException(status_code=400, detail="No assessment questions are linked to this goal")

        # Resume the open attempt first — resuming is always allowed, even at
        # the cap, because that attempt was already started.
        attempt = connection.execute(
            text("""
                SELECT id, user_id, goal_id, status, started_at FROM assessment_attempts
                WHERE user_id = :user_id AND goal_id = :goal_id AND status = 'in_progress'
                ORDER BY started_at DESC
                LIMIT 1
            """),
            {"user_id": current_user["id"], "goal_id": data.goal_id},
        ).fetchone()

        resumed = attempt is not None
        if resumed:
            _ensure_attempt_not_expired(connection, attempt)
            attempt_id = attempt.id
        else:
            used = connection.execute(
                text("""
                    SELECT COUNT(*) FROM assessment_attempts
                    WHERE user_id = :user_id AND goal_id = :goal_id
                      AND status IN ('completed', 'expired')
                """),
                {"user_id": current_user["id"], "goal_id": data.goal_id},
            ).scalar() or 0
            if used >= MAX_ATTEMPTS_PER_GOAL:
                raise HTTPException(
                    status_code=400,
                    detail=f"Maximum assessment attempts reached for this goal ({MAX_ATTEMPTS_PER_GOAL}).",
                )

            attempt_id = connection.execute(
                text("""
                    INSERT INTO assessment_attempts (user_id, goal_id, status)
                    VALUES (:user_id, :goal_id, 'in_progress')
                    RETURNING id
                """),
                {"user_id": current_user["id"], "goal_id": data.goal_id},
            ).fetchone().id

        questions = _build_presentation(attempt_id, rows)
        connection.commit()

    return {
        "attempt_id": attempt_id,
        "goal_id": data.goal_id,
        "total_questions": len(questions),
        "resumed": resumed,
        "time_limit_seconds": _deadline_seconds(len(questions)),
        "questions": questions,
    }


@app.post("/assessment/answer")
def submit_answer(data: AssessmentAnswerRequest, current_user: dict = Depends(get_current_user)):
    with engine.connect() as connection:
        attempt = _get_owned_attempt(connection, data.attempt_id, current_user["id"])

        if attempt.status in ("completed", "expired"):
            raise HTTPException(status_code=400, detail=f"This attempt is already {attempt.status}")

        _ensure_attempt_not_expired(connection, attempt)

        # The question must exist AND belong to this attempt's goal.
        question = connection.execute(
            text("""
                SELECT aq.correct_answer, aq.option_a, aq.option_b, aq.option_c, aq.option_d
                FROM assessment_questions aq
                JOIN goal_skills gs ON gs.skill_id = aq.skill_id
                WHERE aq.id = :question_id AND gs.goal_id = :goal_id
            """),
            {"question_id": data.question_id, "goal_id": attempt.goal_id},
        ).fetchone()

        if question is None:
            raise HTTPException(status_code=404, detail="Question not found for this assessment")

        presented = data.selected_answer.strip().lower()
        if presented not in _VALID_LETTERS:
            raise HTTPException(status_code=400, detail="selected_answer must be one of a, b, c, d")

        options = {
            "a": question.option_a,
            "b": question.option_b,
            "c": question.option_c,
            "d": question.option_d,
        }
        canonical = _presented_to_canonical(attempt.id, data.question_id, options, presented)
        is_correct = canonical.strip().lower() == question.correct_answer.strip().lower()

        time_ms = data.time_ms if isinstance(data.time_ms, int) and 0 <= data.time_ms <= 3_600_000 else None

        # Idempotent: a repeated answer is a no-op instead of an error, so a
        # retry after a network failure cannot brick the attempt.
        result = connection.execute(
            text("""
                INSERT INTO assessment_answers (
                    user_id, goal_id, question_id, selected_answer, is_correct, attempt_id, time_ms
                )
                VALUES (
                    :user_id, :goal_id, :question_id, :selected_answer, :is_correct, :attempt_id, :time_ms
                )
                ON CONFLICT ON CONSTRAINT unique_attempt_question DO NOTHING
                RETURNING id
            """),
            {
                "user_id": attempt.user_id,
                "goal_id": attempt.goal_id,
                "question_id": data.question_id,
                "selected_answer": presented,
                "is_correct": is_correct,
                "attempt_id": data.attempt_id,
                "time_ms": time_ms,
            },
        )
        connection.commit()

    # Ack-only response: is_correct is never revealed, so answers cannot be
    # brute-forced by replaying this endpoint.
    return {
        "attempt_id": data.attempt_id,
        "question_id": data.question_id,
        "selected_answer": presented,
        "recorded": result.fetchone() is not None,
    }


@app.post("/assessment/complete")
def complete_assessment(data: AssessmentCompleteRequest, current_user: dict = Depends(get_current_user)):
    with engine.connect() as connection:
        attempt = _get_owned_attempt(connection, data.attempt_id, current_user["id"])

        if attempt.status == "completed":
            raise HTTPException(status_code=400, detail="This attempt is already completed")
        if attempt.status == "expired":
            raise HTTPException(status_code=400, detail="This attempt has expired")

        _ensure_attempt_not_expired(connection, attempt)

        skill_scores_query = text("""
            SELECT
                aq.skill_id,
                s.name AS skill_name,
                COUNT(*) AS total_questions,
                COUNT(*) FILTER (WHERE aa.is_correct = TRUE) AS correct_answers
            FROM assessment_answers aa
            JOIN assessment_questions aq ON aq.id = aa.question_id
            JOIN skills s ON s.id = aq.skill_id
            WHERE aa.attempt_id = :attempt_id
            GROUP BY aq.skill_id, s.name
        """)
        skill_rows = connection.execute(skill_scores_query, {"attempt_id": data.attempt_id}).fetchall()

        if not skill_rows:
            raise HTTPException(status_code=400, detail="No answers found for this attempt")

        skill_results = []
        total_questions_overall = 0
        total_correct_overall = 0

        for row in skill_rows:
            score_percentage = round((row.correct_answers / row.total_questions) * 100, 2)

            if score_percentage < 40:
                skill_level = "beginner"
            elif score_percentage < 70:
                skill_level = "intermediate"
            else:
                skill_level = "advanced"

            insert_skill_assessment = text("""
                INSERT INTO skill_assessments (
                    attempt_id, user_id, goal_id, skill_id,
                    total_questions, correct_answers, score_percentage, skill_level
                )
                VALUES (
                    :attempt_id, :user_id, :goal_id, :skill_id,
                    :total_questions, :correct_answers, :score_percentage, :skill_level
                )
                RETURNING id
            """)
            connection.execute(insert_skill_assessment, {
                "attempt_id": data.attempt_id,
                "user_id": attempt.user_id,
                "goal_id": attempt.goal_id,
                "skill_id": row.skill_id,
                "total_questions": row.total_questions,
                "correct_answers": row.correct_answers,
                "score_percentage": score_percentage,
                "skill_level": skill_level,
            })

            skill_results.append({
                "skill_id": row.skill_id,
                "skill_name": row.skill_name,
                "total_questions": row.total_questions,
                "correct_answers": row.correct_answers,
                "score_percentage": score_percentage,
                "skill_level": skill_level,
            })

            total_questions_overall += row.total_questions
            total_correct_overall += row.correct_answers

        overall_score = round((total_correct_overall / total_questions_overall) * 100, 2)

        update_attempt = text("""
            UPDATE assessment_attempts
            SET status = 'completed', completed_at = CURRENT_TIMESTAMP, score_percentage = :score
            WHERE id = :attempt_id
        """)
        connection.execute(update_attempt, {"score": overall_score, "attempt_id": data.attempt_id})

        connection.commit()

    return {
        "attempt_id": data.attempt_id,
        "overall_score_percentage": overall_score,
        "skills": skill_results,
    }


@app.post("/assessment/submit")
def submit_assessment(data: AssessmentSubmitRequest, current_user: dict = Depends(get_current_user)):
    """Atomic batch submission: validate, record, and score in one transaction.

    tab_switches is an informational integrity signal reported by the client;
    it never affects scores, skill levels, or attempt status.
    """
    try:
        tab_switches = max(0, min(int(data.tab_switches or 0), 100_000))
    except (TypeError, ValueError):
        tab_switches = 0

    with engine.connect() as connection:
        attempt = _get_owned_attempt(connection, data.attempt_id, current_user["id"])

        if attempt.status == "completed":
            raise HTTPException(status_code=400, detail="This attempt is already completed")
        if attempt.status == "expired":
            raise HTTPException(status_code=400, detail="This attempt has expired")

        _ensure_attempt_not_expired(connection, attempt)

        if not data.answers:
            raise HTTPException(status_code=400, detail="No answers provided")

        question_rows = {row.id: row for row in _load_goal_question_rows(connection, attempt.goal_id)}

        for answer in data.answers:
            row = question_rows.get(answer.question_id)
            if row is None:
                raise HTTPException(
                    status_code=400,
                    detail=f"Question {answer.question_id} does not belong to this assessment",
                )

            presented = answer.selected_answer.strip().lower()
            if presented not in _VALID_LETTERS:
                raise HTTPException(status_code=400, detail="selected_answer must be one of a, b, c, d")

            options = {
                "a": row.option_a,
                "b": row.option_b,
                "c": row.option_c,
                "d": row.option_d,
            }
            canonical = _presented_to_canonical(attempt.id, answer.question_id, options, presented)
            is_correct = canonical.strip().lower() == row.correct_answer.strip().lower()

            time_ms = answer.time_ms if isinstance(answer.time_ms, int) and 0 <= answer.time_ms <= 3_600_000 else None

            connection.execute(
                text("""
                    INSERT INTO assessment_answers (
                        user_id, goal_id, question_id, selected_answer, is_correct, attempt_id, time_ms
                    )
                    VALUES (
                        :user_id, :goal_id, :question_id, :selected_answer, :is_correct, :attempt_id, :time_ms
                    )
                    ON CONFLICT ON CONSTRAINT unique_attempt_question DO NOTHING
                """),
                {
                    "user_id": attempt.user_id,
                    "goal_id": attempt.goal_id,
                    "question_id": answer.question_id,
                    "selected_answer": presented,
                    "is_correct": is_correct,
                    "attempt_id": data.attempt_id,
                    "time_ms": time_ms,
                },
            )

        connection.execute(
            text("UPDATE assessment_attempts SET tab_switches = :ts WHERE id = :i"),
            {"ts": tab_switches, "i": data.attempt_id},
        )

        # ---- scoring: identical logic to /assessment/complete ----
        skill_rows = connection.execute(
            text("""
                SELECT
                    aq.skill_id,
                    s.name AS skill_name,
                    COUNT(*) AS total_questions,
                    COUNT(*) FILTER (WHERE aa.is_correct = TRUE) AS correct_answers
                FROM assessment_answers aa
                JOIN assessment_questions aq ON aq.id = aa.question_id
                JOIN skills s ON s.id = aq.skill_id
                WHERE aa.attempt_id = :attempt_id
                GROUP BY aq.skill_id, s.name
            """),
            {"attempt_id": data.attempt_id},
        ).fetchall()

        if not skill_rows:
            raise HTTPException(status_code=400, detail="No answers were recorded for this attempt")

        skill_results = []
        total_questions_overall = 0
        total_correct_overall = 0

        for row in skill_rows:
            score_percentage = round((row.correct_answers / row.total_questions) * 100, 2)

            if score_percentage < 40:
                skill_level = "beginner"
            elif score_percentage < 70:
                skill_level = "intermediate"
            else:
                skill_level = "advanced"

            connection.execute(
                text("""
                    INSERT INTO skill_assessments (
                        attempt_id, user_id, goal_id, skill_id,
                        total_questions, correct_answers, score_percentage, skill_level
                    )
                    VALUES (
                        :attempt_id, :user_id, :goal_id, :skill_id,
                        :total_questions, :correct_answers, :score_percentage, :skill_level
                    )
                """),
                {
                    "attempt_id": data.attempt_id,
                    "user_id": attempt.user_id,
                    "goal_id": attempt.goal_id,
                    "skill_id": row.skill_id,
                    "total_questions": row.total_questions,
                    "correct_answers": row.correct_answers,
                    "score_percentage": score_percentage,
                    "skill_level": skill_level,
                },
            )

            skill_results.append({
                "skill_id": row.skill_id,
                "skill_name": row.skill_name,
                "total_questions": row.total_questions,
                "correct_answers": row.correct_answers,
                "score_percentage": score_percentage,
                "skill_level": skill_level,
            })

            total_questions_overall += row.total_questions
            total_correct_overall += row.correct_answers

        overall_score = round((total_correct_overall / total_questions_overall) * 100, 2)

        connection.execute(
            text("""
                UPDATE assessment_attempts
                SET status = 'completed', completed_at = CURRENT_TIMESTAMP, score_percentage = :score
                WHERE id = :attempt_id
            """),
            {"score": overall_score, "attempt_id": data.attempt_id},
        )

        connection.commit()

    return {
        "attempt_id": data.attempt_id,
        "overall_score_percentage": overall_score,
        "skills": skill_results,
        "integrity": {"tab_switches": tab_switches},
    }


# ---------- Habits ----------

@app.post("/habits")
def create_habit(habit: HabitCreate, current_user: dict = Depends(get_current_user)):
    with engine.connect() as connection:
        values = {**habit.model_dump(), "user_id": current_user["id"]}
        query = text("""
            INSERT INTO habits (user_id, name, frequency, target_count)
            VALUES (:user_id, :name, :frequency, :target_count)
            RETURNING id, user_id, name, frequency, target_count
        """)
        result = connection.execute(query, values)
        connection.commit()
        new_habit = result.fetchone()

    return {
        "message": "Habit created successfully",
        "habit": {
            "id": new_habit.id,
            "user_id": new_habit.user_id,
            "name": new_habit.name,
            "frequency": new_habit.frequency,
            "target_count": new_habit.target_count,
        },
    }


@app.get("/habits")
def get_habits(current_user: dict = Depends(get_current_user)):
    with engine.connect() as connection:
        query = text("""
            SELECT id, user_id, name, frequency, target_count
            FROM habits
            WHERE user_id = :user_id
            ORDER BY id
        """)
        result = connection.execute(query, {"user_id": current_user["id"]})
        habits = [
            {
                "id": row.id,
                "user_id": row.user_id,
                "name": row.name,
                "frequency": row.frequency,
                "target_count": row.target_count,
            }
            for row in result
        ]
        return {"habits": habits}


# ---------- Progress ----------

@app.post("/progress")
def create_progress(progress: ProgressCreate, current_user: dict = Depends(get_current_user)):
    with engine.connect() as connection:
        habit = connection.execute(
            text("SELECT id, user_id FROM habits WHERE id = :habit_id"),
            {"habit_id": progress.habit_id},
        ).fetchone()
        if habit is None or habit.user_id != current_user["id"]:
            raise HTTPException(status_code=404, detail="Habit not found")

        values = {**progress.model_dump(), "user_id": current_user["id"]}
        query = text("""
            INSERT INTO progress (user_id, habit_id, completed, notes)
            VALUES (:user_id, :habit_id, :completed, :notes)
            RETURNING id, user_id, habit_id, completed, progress_date, notes
        """)
        result = connection.execute(query, values)
        connection.commit()
        new_progress = result.fetchone()

    return {
        "message": "Progress recorded successfully",
        "progress": {
            "id": new_progress.id,
            "user_id": new_progress.user_id,
            "habit_id": new_progress.habit_id,
            "completed": new_progress.completed,
            "progress_date": new_progress.progress_date,
            "notes": new_progress.notes,
        },
    }


@app.get("/progress")
def get_progress(current_user: dict = Depends(get_current_user)):
    with engine.connect() as connection:
        query = text("""
            SELECT id, user_id, habit_id, completed, progress_date, notes
            FROM progress
            WHERE user_id = :user_id
            ORDER BY progress_date DESC, id DESC
        """)
        result = connection.execute(query, {"user_id": current_user["id"]})
        progress_records = [
            {
                "id": row.id,
                "user_id": row.user_id,
                "habit_id": row.habit_id,
                "completed": row.completed,
                "progress_date": row.progress_date,
                "notes": row.notes,
            }
            for row in result
        ]
        return {"progress": progress_records}


@app.get("/progress-summary")
def progress_summary(current_user: dict = Depends(get_current_user)):
    with engine.connect() as connection:
        query = text("""
            SELECT
                COUNT(*) AS total,
                COUNT(*) FILTER (WHERE completed = TRUE) AS completed,
                COUNT(*) FILTER (WHERE completed = FALSE) AS not_completed
            FROM progress
            WHERE user_id = :user_id
        """)
        result = connection.execute(query, {"user_id": current_user["id"]})
        row = result.fetchone()

        total = row.total
        completed = row.completed
        not_completed = row.not_completed
        completion_rate = round((completed / total) * 100, 2) if total > 0 else 0

        return {
            "user_id": current_user["id"],
            "total_progress_records": total,
            "completed": completed,
            "not_completed": not_completed,
            "completion_rate": completion_rate,
        }


# ---------- Tasks ----------

@app.post("/tasks")
def create_task(task: TaskCreate, current_user: dict = Depends(get_current_user)):
    with engine.connect() as connection:
        _get_owned_goal(connection, task.goal_id, current_user["id"])
        values = {
            **task.model_dump(exclude={"scheduled_date", "scheduled_time"}),
            "user_id": current_user["id"],
            "scheduled_date": _parse_date_or_400(task.scheduled_date, "scheduled_date"),
            "scheduled_time": _parse_time_or_400(task.scheduled_time),
        }
        query = text("""
            INSERT INTO tasks (
                user_id, goal_id, title, description,
                estimated_minutes, difficulty, scheduled_date, scheduled_time
            )
            VALUES (
                :user_id, :goal_id, :title, :description,
                :estimated_minutes, :difficulty, :scheduled_date, :scheduled_time
            )
            RETURNING id, user_id, goal_id, title,
                      description, estimated_minutes,
                      difficulty, scheduled_date, scheduled_time, status
        """)
        result = connection.execute(query, values)
        connection.commit()
        new_task = result.fetchone()

    return {
        "message": "Task created successfully",
        "task": {
            "id": new_task.id,
            "user_id": new_task.user_id,
            "goal_id": new_task.goal_id,
            "title": new_task.title,
            "description": new_task.description,
            "estimated_minutes": new_task.estimated_minutes,
            "difficulty": new_task.difficulty,
            "scheduled_date": new_task.scheduled_date,
            "scheduled_time": new_task.scheduled_time,
            "status": new_task.status,
        },
    }


class DifficultyRecommendation(BaseModel):
    recommended_difficulty: str
    explanation: str


def _recommended_difficulty(connection, user_id: int) -> DifficultyRecommendation:
    """Shared rule: latest energy + skip rate -> today's difficulty. Used by the
    plan generator and mirrored by GET /tasks/adaptive-recommendation."""
    energy_row = connection.execute(
        text("""
            SELECT energy_level FROM energy_checkins
            WHERE user_id = :user_id
            ORDER BY checkin_date DESC, checkin_time DESC
            LIMIT 1
        """),
        {"user_id": user_id},
    ).fetchone()
    latest_energy = energy_row.energy_level if energy_row else None

    skip_row = connection.execute(
        text("""
            SELECT
                COUNT(*) AS total,
                COUNT(*) FILTER (WHERE status IN ('skipped', 'postponed')) AS skipped
            FROM task_logs
            WHERE user_id = :user_id
        """),
        {"user_id": user_id},
    ).fetchone()
    skip_rate = round((skip_row.skipped / skip_row.total) * 100, 2) if skip_row.total > 0 else 0

    low_energy = latest_energy is not None and latest_energy.lower() in ("low", "very low")
    high_skip = skip_rate > 40

    if low_energy and high_skip:
        return DifficultyRecommendation(
            recommended_difficulty="easy",
            explanation="Low energy and frequent skips — starting with small, easy tasks to rebuild momentum.",
        )
    if low_energy or high_skip:
        return DifficultyRecommendation(
            recommended_difficulty="medium",
            explanation="Some strain detected — medium difficulty tasks are a safer bet today.",
        )
    return DifficultyRecommendation(
        recommended_difficulty="hard",
        explanation="Energy and consistency look good — time for a challenging task.",
    )


@app.post("/tasks/generate-daily-plan")
def generate_daily_plan(current_user: dict = Depends(get_current_user)):
    """Build today's plan from the active goal's skill gaps: candidate skills come
    from the gap-first roadmap (unassessed first, then weak skills), one task per
    top skill sized to the recommended difficulty, capped by the profile's
    daily_available_minutes. Existing non-completed tasks for today are kept."""
    with engine.connect() as connection:
        goal_row = connection.execute(
            text("""
                SELECT id, title FROM goals
                WHERE user_id = :user_id AND status = 'active'
                ORDER BY id
                LIMIT 1
            """),
            {"user_id": current_user["id"]},
        ).fetchone()

        if goal_row is None:
            raise HTTPException(
                status_code=400,
                detail="Set an active goal first — the daily plan is built from its skill gaps.",
            )

        roadmap_rows = connection.execute(
            text("""
                SELECT gs.skill_id, s.name, s.category, gs.importance, sa.skill_level
                FROM goal_skills gs
                JOIN skills s ON s.id = gs.skill_id
                LEFT JOIN LATERAL (
                    SELECT skill_level
                    FROM skill_assessments sa2
                    WHERE sa2.user_id = :user_id
                      AND sa2.goal_id = :goal_id
                      AND sa2.skill_id = gs.skill_id
                    ORDER BY sa2.created_at DESC
                    LIMIT 1
                ) sa ON TRUE
                WHERE gs.goal_id = :goal_id
            """),
            {"user_id": current_user["id"], "goal_id": goal_row.id},
        ).fetchall()

        importance_rank = {"high": 0, "medium": 1, "low": 2}
        candidates = []
        for row in roadmap_rows:
            if row.skill_level is None:
                priority = 0
                template = "Explore {skill} basics: read or watch an introduction and note 3 key ideas."
            elif row.skill_level in ("beginner", "intermediate"):
                priority = 1
                template = "Practice {skill} with one short, focused exercise."
            else:
                priority = 2
                template = "Light {skill} review: revisit notes and refresh the key concepts."
            candidates.append({
                "skill_id": row.skill_id,
                "name": row.name,
                "template": template,
                "_priority": priority,
                "_importance_rank": importance_rank.get(row.importance, 3),
            })

        candidates.sort(key=lambda c: (c["_priority"], c["_importance_rank"]))

        recommendation = _recommended_difficulty(connection, current_user["id"])
        difficulty = recommendation.recommended_difficulty
        task_minutes = {"easy": 20, "medium": 40, "hard": 60}[difficulty]

        profile_row = connection.execute(
            text("""
                SELECT daily_available_minutes FROM user_profiles
                WHERE user_id = :user_id
                ORDER BY id DESC
                LIMIT 1
            """),
            {"user_id": current_user["id"]},
        ).fetchone()
        available_minutes = profile_row.daily_available_minutes if profile_row else 60
        if not available_minutes or available_minutes <= 0:
            available_minutes = 60

        today = date.today()
        created_tasks = []

        for candidate in candidates:
            if task_minutes > available_minutes:
                break
            result = connection.execute(
                text("""
                    INSERT INTO tasks (
                        user_id, goal_id, title, description,
                        estimated_minutes, difficulty, scheduled_date
                    )
                    VALUES (
                        :user_id, :goal_id, :title, :description,
                        :estimated_minutes, :difficulty, :scheduled_date
                    )
                    RETURNING id, title, estimated_minutes, difficulty, scheduled_date, status
                """),
                {
                    "user_id": current_user["id"],
                    "goal_id": goal_row.id,
                    "title": candidate["template"].format(skill=candidate["name"]),
                    "description": f"Auto-generated from your skill-gap roadmap for '{goal_row.title}'.",
                    "estimated_minutes": task_minutes,
                    "difficulty": difficulty,
                    "scheduled_date": today,
                },
            )
            task = result.fetchone()
            created_tasks.append({
                "id": task.id,
                "title": task.title,
                "estimated_minutes": task.estimated_minutes,
                "difficulty": task.difficulty,
                "scheduled_date": task.scheduled_date,
                "status": task.status,
                "skill_id": candidate["skill_id"],
                "skill_name": candidate["name"],
            })
            available_minutes -= task_minutes

        connection.commit()

    return {
        "message": "Daily plan generated",
        "goal_id": goal_row.id,
        "goal_title": goal_row.title,
        "recommended_difficulty": difficulty,
        "explanation": recommendation.explanation,
        "tasks_created": created_tasks,
        "planned_minutes": sum(t["estimated_minutes"] for t in created_tasks),
    }


@app.get("/tasks")
def get_tasks(current_user: dict = Depends(get_current_user)):
    with engine.connect() as connection:
        query = text("""
            SELECT
                id, user_id, goal_id, title, description,
                estimated_minutes, difficulty, scheduled_date,
                scheduled_time, status
            FROM tasks
            WHERE user_id = :user_id
            ORDER BY scheduled_date, id
        """)
        result = connection.execute(query, {"user_id": current_user["id"]})
        tasks = [
            {
                "id": row.id,
                "user_id": row.user_id,
                "goal_id": row.goal_id,
                "title": row.title,
                "description": row.description,
                "estimated_minutes": row.estimated_minutes,
                "difficulty": row.difficulty,
                "scheduled_date": row.scheduled_date,
                "scheduled_time": row.scheduled_time,
                "status": row.status,
            }
            for row in result
        ]
        return {"tasks": tasks}


@app.put("/tasks/{task_id}/status")
def update_task_status(task_id: int, body: TaskStatusUpdate, current_user: dict = Depends(get_current_user)):
    with engine.connect() as connection:
        task = connection.execute(
            text("SELECT id, user_id FROM tasks WHERE id = :task_id"),
            {"task_id": task_id},
        ).fetchone()
        if task is None or task.user_id != current_user["id"]:
            raise HTTPException(status_code=404, detail="Task not found")

        if body.status in ("skipped", "postponed"):
            skip_log = connection.execute(
                text("""
                    SELECT id FROM task_logs
                    WHERE task_id = :task_id AND user_id = :user_id
                      AND status IN ('skipped', 'postponed')
                      AND reason IS NOT NULL AND reason != ''
                    ORDER BY logged_at DESC LIMIT 1
                """),
                {"task_id": task_id, "user_id": current_user["id"]},
            ).fetchone()
            if skip_log is None:
                raise HTTPException(status_code=422, detail="Save a skip reason before marking this task skipped.")

        query = text("""
            UPDATE tasks
            SET status = :status
            WHERE id = :task_id
            RETURNING id, title, status
        """)
        result = connection.execute(query, {"task_id": task_id, "status": body.status})
        connection.commit()
        updated_task = result.fetchone()

    if updated_task is None:
        raise HTTPException(status_code=404, detail="Task not found")

    return {
        "message": "Task status updated successfully",
        "task": {"id": updated_task.id, "title": updated_task.title, "status": updated_task.status},
    }


# ---------- Task logs ----------

@app.post("/task-logs")
def create_task_log(log: TaskLogCreate, current_user: dict = Depends(get_current_user)):
    if log.status in ("skipped", "postponed") and not log.reason.strip():
        raise HTTPException(status_code=422, detail="A reason is required when skipping or postponing a task.")

    with engine.connect() as connection:
        task = connection.execute(
            text("SELECT id, user_id FROM tasks WHERE id = :task_id"),
            {"task_id": log.task_id},
        ).fetchone()
        if task is None or task.user_id != current_user["id"]:
            raise HTTPException(status_code=404, detail="Task not found")

        values = {**log.model_dump(), "user_id": current_user["id"]}
        query = text("""
            INSERT INTO task_logs (
                task_id, user_id, status, reason, actual_minutes
            )
            VALUES (
                :task_id, :user_id, :status, :reason, :actual_minutes
            )
            RETURNING id, task_id, user_id, status,
                      reason, actual_minutes, logged_at
        """)
        result = connection.execute(query, values)
        connection.commit()
        new_log = result.fetchone()

    return {
        "message": "Task log created successfully",
        "log": {
            "id": new_log.id,
            "task_id": new_log.task_id,
            "user_id": new_log.user_id,
            "status": new_log.status,
            "reason": new_log.reason,
            "actual_minutes": new_log.actual_minutes,
            "logged_at": new_log.logged_at,
        },
    }


@app.get("/task-logs")
def get_task_logs(current_user: dict = Depends(get_current_user)):
    with engine.connect() as connection:
        query = text("""
            SELECT id, task_id, user_id, status, reason, actual_minutes, logged_at
            FROM task_logs
            WHERE user_id = :user_id
            ORDER BY logged_at DESC
        """)
        result = connection.execute(query, {"user_id": current_user["id"]})
        logs = [
            {
                "id": row.id,
                "task_id": row.task_id,
                "user_id": row.user_id,
                "status": row.status,
                "reason": row.reason,
                "actual_minutes": row.actual_minutes,
                "logged_at": row.logged_at,
            }
            for row in result
        ]
        return {"task_logs": logs}


@app.get("/tasks/prediction")
def predict_task_completion(task_id: int, current_user: dict = Depends(get_current_user)):
    """Advisory prediction for one of the authenticated user's own tasks."""
    with engine.connect() as connection:
        task = connection.execute(text("""
            SELECT id, estimated_minutes, difficulty, scheduled_time, status
            FROM tasks WHERE id = :task_id AND user_id = :user_id
        """), {"task_id": task_id, "user_id": current_user["id"]}).fetchone()
        if task is None:
            raise HTTPException(status_code=404, detail="Task not found")
        if task.status != "pending":
            raise HTTPException(status_code=409, detail="Predictions are available for pending tasks only")

        features, labels, available, productive = _prediction_model(
            connection, current_user["id"], exclude_task_id=task_id
        )
        latest_energy = connection.execute(text("""
            SELECT energy_level FROM energy_checkins WHERE user_id = :user_id
            ORDER BY checkin_date DESC, checkin_time DESC LIMIT 1
        """), {"user_id": current_user["id"]}).scalar()

    total = len(labels)
    completed = sum(labels)
    skipped = total - completed
    current = _prediction_features(
        task.estimated_minutes, available, latest_energy,
        completed / total if total else 0,
        skipped / total if total else 0,
        sum(label == 0 for label in labels[-5:]), task.difficulty,
        task.scheduled_time, productive,
    )
    class_counts = {"completed": completed, "skipped": skipped}
    if total < 6 or len(set(labels)) < 2:
        return {
            "status": "insufficient_data",
            "message": "At least 6 completed/skipped task logs including both outcomes are required.",
            "training_examples": total,
            "class_counts": class_counts,
            "completion_probability": None,
            "predicted_status": None,
            "evaluation_metrics": None,
            "model": "LogisticRegression",
            "features": PREDICTION_FEATURES,
        }
    try:
        from sklearn.linear_model import LogisticRegression
        from sklearn.metrics import accuracy_score, precision_score, recall_score, roc_auc_score
        from sklearn.model_selection import train_test_split
        from sklearn.pipeline import make_pipeline
        from sklearn.preprocessing import StandardScaler

    except ImportError:
        return {
            "status": "unavailable",
            "message": "Prediction is unavailable on this machine because the ML libraries could not be loaded (Windows App Control may be blocking them).",
            "training_examples": total,
            "class_counts": class_counts,
            "completion_probability": None,
            "predicted_status": None,
            "evaluation_metrics": None,
            "model": "LogisticRegression",
            "features": PREDICTION_FEATURES,
        }

    model = make_pipeline(StandardScaler(), LogisticRegression(random_state=42, max_iter=1000))
    metrics = None
    if total >= 10 and min(completed, skipped) >= 2:
        x_train, x_test, y_train, y_test = train_test_split(
            features, labels, test_size=0.25, random_state=42, stratify=labels
        )
        evaluation_model = make_pipeline(StandardScaler(), LogisticRegression(random_state=42, max_iter=1000))
        evaluation_model.fit(x_train, y_train)
        probabilities = evaluation_model.predict_proba(x_test)[:, 1]
        predictions = (probabilities >= 0.5).astype(int)
        metrics = {
            "holdout_size": len(y_test),
            "accuracy": round(float(accuracy_score(y_test, predictions)), 3),
            "precision": round(float(precision_score(y_test, predictions, zero_division=0)), 3),
            "recall": round(float(recall_score(y_test, predictions, zero_division=0)), 3),
            "roc_auc": round(float(roc_auc_score(y_test, probabilities)), 3),
        }
    model.fit(features, labels)
    probability = float(model.predict_proba([current])[0][1])
    return {
        "status": "ok",
        "training_examples": total,
        "class_counts": class_counts,
        "completion_probability": round(probability, 4),
        "predicted_status": "Likely to Complete" if probability >= 0.5 else "At Risk",
        "evaluation_metrics": metrics,
        "model": "LogisticRegression",
        "features": PREDICTION_FEATURES,
        "advisory_only": True,
    }

@app.get("/task-logs/procrastination-summary")
def procrastination_summary(current_user: dict = Depends(get_current_user)):
    with engine.connect() as connection:
        totals_query = text("""
            SELECT
                COUNT(*) AS total_tasks,
                COUNT(*) FILTER (WHERE status = 'completed') AS completed,
                COUNT(*) FILTER (WHERE status IN ('skipped', 'postponed')) AS skipped_or_postponed
            FROM tasks
            WHERE user_id = :user_id
        """)
        totals = connection.execute(totals_query, {"user_id": current_user["id"]}).fetchone()

        log_count = connection.execute(
            text("SELECT COUNT(*) FROM task_logs WHERE user_id = :user_id"),
            {"user_id": current_user["id"]},
        ).scalar_one()

        reasons_query = text("""
            SELECT reason, COUNT(*) AS count
            FROM task_logs
            WHERE user_id = :user_id
              AND status IN ('skipped', 'postponed')
              AND reason IS NOT NULL
              AND reason != ''
            GROUP BY reason
            ORDER BY count DESC
            LIMIT 5
        """)
        reasons = connection.execute(reasons_query, {"user_id": current_user["id"]}).fetchall()

        top_reasons = [{"reason": row.reason, "count": row.count} for row in reasons]

        total = totals.total_tasks
        skip_rate = round((totals.skipped_or_postponed / total) * 100, 2) if total > 0 else 0
        completion_rate = round((totals.completed / total) * 100, 2) if total > 0 else 0

        return {
            "user_id": current_user["id"],
            "total_logs": log_count,
            "total_tasks": total,
            "completed": totals.completed,
            "completion_rate_percentage": completion_rate,
            "skipped_or_postponed": totals.skipped_or_postponed,
            "skip_rate_percentage": skip_rate,
            "top_skip_reasons": top_reasons,
        }

@app.get("/tasks/adaptive-recommendation")
def adaptive_recommendation(current_user: dict = Depends(get_current_user)):
    with engine.connect() as connection:
        energy_query = text("""
            SELECT energy_level FROM energy_checkins
            WHERE user_id = :user_id
            ORDER BY checkin_date DESC, checkin_time DESC
            LIMIT 1
        """)
        energy_row = connection.execute(energy_query, {"user_id": current_user["id"]}).fetchone()
        latest_energy = energy_row.energy_level if energy_row else None

        skip_query = text("""
            SELECT
                COUNT(*) AS total,
                COUNT(*) FILTER (WHERE status IN ('skipped', 'postponed')) AS skipped
            FROM task_logs
            WHERE user_id = :user_id
        """)
        skip_row = connection.execute(skip_query, {"user_id": current_user["id"]}).fetchone()
        skip_rate = round((skip_row.skipped / skip_row.total) * 100, 2) if skip_row.total > 0 else 0

        low_energy = latest_energy is not None and latest_energy.lower() in ("low", "very low")
        high_skip = skip_rate > 40

        if low_energy and high_skip:
            recommended_difficulty = "easy"
            explanation = "Low energy and frequent skips — start with small, easy tasks to rebuild momentum."
        elif low_energy or high_skip:
            recommended_difficulty = "medium"
            explanation = "Some strain detected — medium difficulty tasks are a safer bet today."
        else:
            recommended_difficulty = "hard"
            explanation = "Energy and consistency look good — this is a good time for a challenging task."

        return {
            "user_id": current_user["id"],
            "latest_energy": latest_energy,
            "skip_rate_percentage": skip_rate,
            "recommended_difficulty": recommended_difficulty,
            "explanation": explanation,
        }

# ---------- Energy check-ins ----------

@app.post("/energy-checkins")
def create_energy_checkin(checkin: EnergyCheckinCreate, current_user: dict = Depends(get_current_user)):
    with engine.connect() as connection:
        values = {**checkin.model_dump(), "user_id": current_user["id"]}
        query = text("""
            INSERT INTO energy_checkins (user_id, energy_level, notes)
            VALUES (:user_id, :energy_level, :notes)
            RETURNING id, user_id, energy_level, checkin_date, checkin_time, notes
        """)
        result = connection.execute(query, values)
        connection.commit()
        new_checkin = result.fetchone()

    return {
        "message": "Energy check-in recorded successfully",
        "checkin": {
            "id": new_checkin.id,
            "user_id": new_checkin.user_id,
            "energy_level": new_checkin.energy_level,
            "checkin_date": new_checkin.checkin_date,
            "checkin_time": new_checkin.checkin_time,
            "notes": new_checkin.notes,
        },
    }


@app.get("/energy-checkins")
def get_energy_checkins(current_user: dict = Depends(get_current_user)):
    with engine.connect() as connection:
        query = text("""
            SELECT id, user_id, energy_level, checkin_date, checkin_time, notes
            FROM energy_checkins
            WHERE user_id = :user_id
            ORDER BY checkin_date DESC, checkin_time DESC
        """)
        result = connection.execute(query, {"user_id": current_user["id"]})
        checkins = [
            {
                "id": row.id,
                "user_id": row.user_id,
                "energy_level": row.energy_level,
                "checkin_date": row.checkin_date,
                "checkin_time": row.checkin_time,
                "notes": row.notes,
            }
            for row in result
        ]
        return {"energy_checkins": checkins}


# ---------- Profiles ----------

@app.get("/profiles")
def get_profile(current_user: dict = Depends(get_current_user)):
    with engine.connect() as connection:
        profile = connection.execute(
            text("""
                SELECT id, user_id, age, occupation, daily_available_minutes,
                       productive_time, sleep_hours, distraction_level,
                       procrastination_level, challenges
                FROM user_profiles WHERE user_id = :user_id
                ORDER BY id LIMIT 1
            """),
            {"user_id": current_user["id"]},
        ).fetchone()
    return {"profile": dict(profile._mapping) if profile else None}


@app.put("/profiles")
def save_profile(profile: ProfileCreate, current_user: dict = Depends(get_current_user)):
    values = {**profile.model_dump(), "user_id": current_user["id"]}
    with engine.begin() as connection:
        existing = connection.execute(
            text("SELECT id FROM user_profiles WHERE user_id = :user_id ORDER BY id LIMIT 1 FOR UPDATE"),
            {"user_id": current_user["id"]},
        ).fetchone()
        if existing:
            result = connection.execute(text("""
                UPDATE user_profiles SET
                    age = :age, occupation = :occupation,
                    daily_available_minutes = :daily_available_minutes,
                    productive_time = :productive_time, sleep_hours = :sleep_hours,
                    distraction_level = :distraction_level,
                    procrastination_level = :procrastination_level, challenges = :challenges
                WHERE id = :profile_id AND user_id = :user_id
                RETURNING id, user_id, age, occupation, daily_available_minutes,
                          productive_time, sleep_hours, distraction_level,
                          procrastination_level, challenges
            """), {**values, "profile_id": existing.id})
            message = "Profile updated successfully"
        else:
            result = connection.execute(text("""
                INSERT INTO user_profiles (
                    user_id, age, occupation, daily_available_minutes, productive_time,
                    sleep_hours, distraction_level, procrastination_level, challenges
                )
                VALUES (:user_id, :age, :occupation, :daily_available_minutes,
                        :productive_time, :sleep_hours, :distraction_level,
                        :procrastination_level, :challenges)
                RETURNING id, user_id, age, occupation, daily_available_minutes,
                          productive_time, sleep_hours, distraction_level,
                          procrastination_level, challenges
            """), values)
            message = "Profile saved successfully"
        saved = dict(result.fetchone()._mapping)
    return {"message": message, "profile": saved}

@app.post("/profiles")
def create_profile(profile: ProfileCreate, current_user: dict = Depends(get_current_user)):
    with engine.connect() as connection:
        values = {**profile.model_dump(), "user_id": current_user["id"]}
        query = text("""
            INSERT INTO user_profiles (
                user_id, age, occupation, daily_available_minutes,
                productive_time, sleep_hours, distraction_level,
                procrastination_level, challenges
            )
            VALUES (
                :user_id, :age, :occupation, :daily_available_minutes,
                :productive_time, :sleep_hours, :distraction_level,
                :procrastination_level, :challenges
            )
            RETURNING id, user_id, age, occupation,
                      daily_available_minutes, productive_time,
                      sleep_hours, distraction_level,
                      procrastination_level, challenges
        """)
        result = connection.execute(query, values)
        connection.commit()
        new_profile = result.fetchone()

    return {
        "message": "Profile created successfully",
        "profile": {
            "id": new_profile.id,
            "user_id": new_profile.user_id,
            "age": new_profile.age,
            "occupation": new_profile.occupation,
            "daily_available_minutes": new_profile.daily_available_minutes,
            "productive_time": new_profile.productive_time,
            "sleep_hours": new_profile.sleep_hours,
            "distraction_level": new_profile.distraction_level,
            "procrastination_level": new_profile.procrastination_level,
            "challenges": new_profile.challenges,
        }
    }


# ---------- Conversational AI Study Coach ----------

import ai_client


class CoachHistoryTurn(BaseModel):
    role: str
    content: str


class CoachChatRequest(BaseModel):
    question: Optional[str] = None
    message: Optional[str] = None
    goal_id: Optional[int] = None
    history: Optional[List[CoachHistoryTurn]] = None


def _build_coach_student_context(
    connection,
    user_id: int,
    goal_id: Optional[int] = None,
) -> tuple[str, dict]:
    """Assemble lightweight, real student study context from PostgreSQL for the AI Coach."""
    context_lines: list[str] = []
    summary_meta: dict = {
        "goal_id": None,
        "goal_title": None,
        "skills_count": 0,
        "pending_tasks_count": 0,
        "recommended_difficulty": None,
    }

    goal_row = None
    if goal_id is not None:
        goal_row = connection.execute(
            text(
                "SELECT id, title, description, status FROM goals "
                "WHERE id = :goal_id AND user_id = :user_id"
            ),
            {"goal_id": goal_id, "user_id": user_id},
        ).fetchone()

    if goal_row is None:
        goal_row = connection.execute(
            text(
                "SELECT id, title, description, status FROM goals "
                "WHERE user_id = :user_id "
                "ORDER BY CASE WHEN status = 'active' THEN 0 ELSE 1 END, id DESC LIMIT 1"
            ),
            {"user_id": user_id},
        ).fetchone()

    if goal_row is not None:
        summary_meta["goal_id"] = goal_row.id
        summary_meta["goal_title"] = goal_row.title
        desc_part = f" ({goal_row.description})" if goal_row.description else ""
        context_lines.append(f"- Active Study Goal: {goal_row.title}{desc_part}")

        skill_rows = connection.execute(
            text("""
                SELECT
                    s.id,
                    s.name,
                    sa.skill_level,
                    sa.score_percentage
                FROM goal_skills gs
                JOIN skills s ON s.id = gs.skill_id
                LEFT JOIN LATERAL (
                    SELECT skill_level, score_percentage
                    FROM skill_assessments
                    WHERE user_id = :user_id
                      AND goal_id = :goal_id
                      AND skill_id = s.id
                    ORDER BY id DESC
                    LIMIT 1
                ) sa ON TRUE
                WHERE gs.goal_id = :goal_id
                ORDER BY s.id
            """),
            {"user_id": user_id, "goal_id": goal_row.id},
        ).fetchall()

        summary_meta["skills_count"] = len(skill_rows)
        if skill_rows:
            skill_descriptions = []
            for s in skill_rows:
                if s.skill_level is not None and s.score_percentage is not None:
                    skill_descriptions.append(
                        f"{s.name} ({s.skill_level}, {s.score_percentage}%)"
                    )
                else:
                    skill_descriptions.append(f"{s.name} (unassessed)")
            context_lines.append(f"- Mapped Goal Skills: {', '.join(skill_descriptions)}")

    try:
        rec = _recommended_difficulty(connection, user_id)
        summary_meta["recommended_difficulty"] = rec.recommended_difficulty
        context_lines.append(
            f"- Adaptive Difficulty Recommendation: {rec.recommended_difficulty} ({rec.explanation})"
        )
    except Exception:
        pass

    pending_rows = connection.execute(
        text("""
            SELECT title, difficulty, estimated_minutes
            FROM tasks
            WHERE user_id = :user_id AND status = 'pending'
            ORDER BY scheduled_date ASC NULLS LAST, id DESC
            LIMIT 5
        """),
        {"user_id": user_id},
    ).fetchall()
    summary_meta["pending_tasks_count"] = len(pending_rows)
    if pending_rows:
        task_strs = [
            f"{t.title} ({t.estimated_minutes or 30}m, {t.difficulty or 'medium'})"
            for t in pending_rows
        ]
        context_lines.append(f"- Upcoming Pending Tasks: {'; '.join(task_strs)}")

    return "\n".join(context_lines), summary_meta


@app.get("/ai/coach/status")
def get_ai_coach_status(current_user: dict = Depends(get_current_user)):
    """Return whether Gemini AI Coach is configured (never exposes the API key)."""
    configured = ai_client.is_configured()
    return {
        "configured": configured,
        "provider": "google-genai",
        "model": ai_client.get_active_model() if configured else None,
    }


@app.post("/ai/coach/chat")
@app.post("/coach/chat")
def ai_coach_chat(
    payload: CoachChatRequest,
    current_user: dict = Depends(get_current_user),
):
    """Answer a student's study or growth question using Google's Gemini SDK (`google-genai`)."""
    raw_question = payload.question if payload.question is not None else payload.message
    question = (raw_question or "").strip()
    if not question:
        raise HTTPException(
            status_code=400,
            detail="Please provide a non-empty question for the AI Study Coach.",
        )
    if len(question) > 2000:
        raise HTTPException(
            status_code=400,
            detail="Question must be 2000 characters or fewer.",
        )

    if not ai_client.is_configured():
        raise HTTPException(
            status_code=503,
            detail="AI Study Coach is not configured. Add GEMINI_API_KEY to backend/.env.",
        )

    with engine.connect() as connection:
        if payload.goal_id is not None:
            _get_owned_goal(connection, payload.goal_id, current_user["id"])
        student_context, context_meta = _build_coach_student_context(
            connection,
            current_user["id"],
            payload.goal_id,
        )

    history_dicts: list[dict[str, str]] = []
    if payload.history:
        for item in payload.history[-8:]:
            history_dicts.append({"role": item.role, "content": item.content})

    try:
        result = ai_client.generate_coach_reply(
            question,
            student_context=student_context,
            history=history_dicts,
        )
    except ai_client.AIError as exc:
        status_code = getattr(exc, "status_code", 502) or 502
        raise HTTPException(status_code=status_code, detail=str(exc)) from None

    return {
        "answer": result["answer"],
        "model": result["model"],
        "context": context_meta,
    }



# ---------- Data Analyst Curriculum & Detailed Learning Topics ----------

import data_analyst_curriculum


class TopicProgressUpdateRequest(BaseModel):
    status: str
    quiz_score: Optional[int] = None


class TopicLessonGenerateRequest(BaseModel):
    force: bool = False


def _get_owned_goal_with_title(connection, goal_id: int, user_id: int):
    _get_owned_goal(connection, goal_id, user_id)
    row = connection.execute(
        text("SELECT id, user_id, title, description, status FROM goals WHERE id = :goal_id"),
        {"goal_id": goal_id},
    ).fetchone()
    if row is None or row.user_id != user_id:
        raise HTTPException(status_code=404, detail="Goal not found")
    return row


@app.get("/goals/{goal_id}/curriculum")
def get_goal_curriculum(goal_id: int, current_user: dict = Depends(get_current_user)):
    """Retrieve the ordered 8-stage, 65-topic Data Analyst curriculum and user progress."""
    with engine.connect() as connection:
        goal_row = _get_owned_goal_with_title(connection, goal_id, current_user["id"])
        return data_analyst_curriculum.get_curriculum_for_goal(
            connection,
            goal_row.id,
            goal_row.title,
            current_user["id"],
        )


@app.get("/goals/{goal_id}/curriculum/stages/{stage_number}")
def get_goal_curriculum_stage(
    goal_id: int,
    stage_number: int,
    current_user: dict = Depends(get_current_user),
):
    """Retrieve a single Data Analyst learning stage and its ordered topics."""
    with engine.connect() as connection:
        goal_row = _get_owned_goal_with_title(connection, goal_id, current_user["id"])
        if not data_analyst_curriculum.is_data_analyst_goal(goal_row.title):
            raise HTTPException(
                status_code=400,
                detail="Detailed learning curriculum is only available for the Data Analyst goal.",
            )
        curriculum = data_analyst_curriculum.get_curriculum_for_goal(
            connection,
            goal_row.id,
            goal_row.title,
            current_user["id"],
        )
        stage = next(
            (s for s in curriculum["stages"] if s["stage_number"] == stage_number),
            None,
        )
        if stage is None:
            raise HTTPException(status_code=404, detail="Learning stage not found")
        return {
            "goal_id": goal_row.id,
            "goal_title": goal_row.title,
            "stage": stage,
        }


@app.get("/goals/{goal_id}/curriculum/topics/{topic_id}")
def get_goal_curriculum_topic(
    goal_id: int,
    topic_id: int,
    current_user: dict = Depends(get_current_user),
):
    """Retrieve a Data Analyst topic, its lesson content, and the user's progress."""
    with engine.connect() as connection:
        goal_row = _get_owned_goal_with_title(connection, goal_id, current_user["id"])
        if not data_analyst_curriculum.is_data_analyst_goal(goal_row.title):
            raise HTTPException(
                status_code=400,
                detail="Detailed learning curriculum is only available for the Data Analyst goal.",
            )
        detail = data_analyst_curriculum.get_topic_detail(
            connection,
            goal_row.id,
            goal_row.title,
            current_user["id"],
            topic_id,
            use_gemini_if_missing=True,
            force_regenerate=False,
        )
        if detail is None:
            raise HTTPException(status_code=404, detail="Topic not found")
        return detail


@app.post("/goals/{goal_id}/curriculum/topics/{topic_id}/generate-lesson")
def generate_goal_curriculum_topic_lesson(
    goal_id: int,
    topic_id: int,
    payload: Optional[TopicLessonGenerateRequest] = None,
    current_user: dict = Depends(get_current_user),
):
    """Generate or retrieve structured lesson content for a Data Analyst topic."""
    force_flag = bool(payload.force) if payload else False
    with engine.connect() as connection:
        goal_row = _get_owned_goal_with_title(connection, goal_id, current_user["id"])
        if not data_analyst_curriculum.is_data_analyst_goal(goal_row.title):
            raise HTTPException(
                status_code=400,
                detail="Detailed learning curriculum is only available for the Data Analyst goal.",
            )
        detail = data_analyst_curriculum.get_topic_detail(
            connection,
            goal_row.id,
            goal_row.title,
            current_user["id"],
            topic_id,
            use_gemini_if_missing=True,
            force_regenerate=force_flag,
        )
        if detail is None:
            raise HTTPException(status_code=404, detail="Topic not found")
        return detail


@app.put("/goals/{goal_id}/curriculum/topics/{topic_id}/progress")
@app.post("/goals/{goal_id}/curriculum/topics/{topic_id}/progress")
def update_goal_curriculum_topic_progress(
    goal_id: int,
    topic_id: int,
    payload: TopicProgressUpdateRequest,
    current_user: dict = Depends(get_current_user),
):
    """Mark a Data Analyst topic as not_started, in_progress, or completed for the current user."""
    clean_status = (payload.status or "").strip().lower()
    if clean_status not in data_analyst_curriculum.VALID_PROGRESS_STATUSES:
        raise HTTPException(
            status_code=400,
            detail="status must be one of: not_started, in_progress, completed",
        )
    if payload.quiz_score is not None and not (0 <= payload.quiz_score <= 100):
        raise HTTPException(
            status_code=400,
            detail="quiz_score must be between 0 and 100",
        )

    with engine.connect() as connection:
        goal_row = _get_owned_goal_with_title(connection, goal_id, current_user["id"])
        if not data_analyst_curriculum.is_data_analyst_goal(goal_row.title):
            raise HTTPException(
                status_code=400,
                detail="Detailed learning curriculum is only available for the Data Analyst goal.",
            )
        updated = data_analyst_curriculum.update_user_topic_progress(
            connection,
            current_user["id"],
            topic_id,
            clean_status,
            payload.quiz_score,
        )
        if updated is None:
            raise HTTPException(status_code=404, detail="Topic not found")
        return {
            "goal_id": goal_row.id,
            **updated,
        }


@app.get("/goals/{goal_id}/curriculum/progress")
def get_goal_curriculum_progress(
    goal_id: int,
    current_user: dict = Depends(get_current_user),
):
    """Retrieve the authenticated user's topic completion and stage progress for a Data Analyst goal."""
    with engine.connect() as connection:
        goal_row = _get_owned_goal_with_title(connection, goal_id, current_user["id"])
        curriculum = data_analyst_curriculum.get_curriculum_for_goal(
            connection,
            goal_row.id,
            goal_row.title,
            current_user["id"],
        )
        if not curriculum["supported"]:
            return {
                "goal_id": goal_row.id,
                "supported": False,
                "summary": None,
                "stages": [],
            }
        return {
            "goal_id": goal_row.id,
            "supported": True,
            "summary": curriculum["summary"],
            "stages": [
                {
                    "stage_number": s["stage_number"],
                    "title": s["title"],
                    "skill_name": s["skill_name"],
                    "progress": s["progress"],
                }
                for s in curriculum["stages"]
            ],
        }
