"""
Automated tests for the GrowthAI Gemini integration (`backend/ai_client.py`)
and the Conversational AI Study Coach endpoints (`/ai/coach/status`, `/ai/coach/chat`, `/coach/chat`).
"""

import os
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient
from google.genai import errors

import ai_client
from main import app
from security import get_current_user


@pytest.fixture
def auth_client():
    """Return a TestClient with an authenticated student dependency override."""
    app.dependency_overrides[get_current_user] = lambda: {
        "id": 1,
        "name": "Test Student",
        "email": "student@example.com",
    }
    try:
        with TestClient(app) as client:
            yield client
    finally:
        app.dependency_overrides.pop(get_current_user, None)


def test_ai_client_missing_key_raises_safe_error(monkeypatch):
    """When GEMINI_API_KEY is missing, ai_client must report unconfigured and raise 503 AIError."""
    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    monkeypatch.setattr(ai_client, "_ensure_env", lambda: None)

    assert ai_client.is_configured() is False

    with pytest.raises(ai_client.AIError) as exc_info:
        ai_client.generate_text("Explain recursion.")
    assert exc_info.value.status_code == 503
    assert exc_info.value.error_code == "missing_api_key"


def test_ai_client_never_leaks_api_key_in_error_messages(monkeypatch):
    """Even if an exception string contains the raw API key, ai_client must redact it."""
    fake_secret = "AIzaSy_SUPER_SECRET_TEST_KEY_999999"
    monkeypatch.setenv("GEMINI_API_KEY", fake_secret)

    class BrokenModels:
        def generate_content(self, **kwargs):
            raise RuntimeError(f"Connection failed for key={fake_secret} on host")

    monkeypatch.setattr(
        ai_client,
        "_create_client",
        lambda api_key, timeout_seconds=60: SimpleNamespace(models=BrokenModels()),
    )

    with pytest.raises(ai_client.AIError) as exc_info:
        ai_client.generate_coach_reply("How do I focus?")

    assert fake_secret not in str(exc_info.value)


def test_ai_client_quota_limit_429_handling(monkeypatch):
    """When Gemini returns 429 RESOURCE_EXHAUSTED across models, raise 429 AIError safely."""
    fake_secret = "AIzaSy_QUOTA_TEST_KEY_12345"
    monkeypatch.setenv("GEMINI_API_KEY", fake_secret)

    class QuotaExhaustedModels:
        def generate_content(self, **kwargs):
            raise errors.ClientError(
                429,
                {
                    "error": {
                        "code": 429,
                        "message": f"Resource exhausted for key {fake_secret}",
                        "status": "RESOURCE_EXHAUSTED",
                    }
                },
            )

    monkeypatch.setattr(
        ai_client,
        "_create_client",
        lambda api_key, timeout_seconds=60: SimpleNamespace(models=QuotaExhaustedModels()),
    )

    with pytest.raises(ai_client.AIError) as exc_info:
        ai_client.generate_coach_reply("Help me plan my study session.")

    assert exc_info.value.status_code == 429
    assert exc_info.value.error_code == "quota_exceeded"
    assert fake_secret not in str(exc_info.value)


def test_ai_client_fallback_when_primary_model_unavailable(monkeypatch):
    """If the primary model returns 404 or 503, ai_client should fall back to the next working model."""
    monkeypatch.setenv("GEMINI_API_KEY", "AIzaSy_FALLBACK_TEST_KEY")
    monkeypatch.setenv("GEMINI_MODEL", "gemini-3.8-flash")

    attempts = []

    class FallbackModels:
        def generate_content(self, *, model, contents, config):
            attempts.append(model)
            if len(attempts) == 1:
                raise errors.ServerError(
                    503,
                    {
                        "error": {
                            "code": 503,
                            "message": "High demand",
                            "status": "UNAVAILABLE",
                        }
                    },
                )
            return SimpleNamespace(text="Start with a 25-minute Pomodoro block.")

    monkeypatch.setattr(
        ai_client,
        "_create_client",
        lambda api_key, timeout_seconds=60: SimpleNamespace(models=FallbackModels()),
    )

    result = ai_client.generate_coach_reply("How should I start studying?")
    assert result["answer"] == "Start with a 25-minute Pomodoro block."
    assert len(attempts) == 2
    assert result["model"] == attempts[1]


def test_vlookup_question_excludes_thought_parts_and_returns_real_explanation(
    auth_client,
    monkeypatch,
):
    """
    Verify that asking 'Explain Excel VLOOKUP with a simple example' via POST /coach/chat:
    1. Separates system_instruction, student context, history, and student question.
    2. Disables internal thought output in GenerateContentConfig.
    3. Excludes any `thought=True` checklist parts and returns the complete VLOOKUP explanation
       with a concrete example.
    """
    monkeypatch.setenv("GEMINI_API_KEY", "AIzaSy_VLOOKUP_TEST_KEY")
    monkeypatch.setenv("GEMINI_MODEL", "gemini-3.5-flash")

    captured_call = {}

    vlookup_explanation = (
        "VLOOKUP (Vertical Lookup) searches for a value in the first column of a table "
        "and returns a corresponding value from another column in the same row.\n\n"
        "Syntax:\n"
        "`=VLOOKUP(lookup_value, table_array, col_index_num, [range_lookup])`\n\n"
        "Simple Example:\n"
        "Suppose cells A2:C4 contain Product IDs in column A, Names in column B, and Prices in column C:\n"
        "- A2: 101 | B2: Notebook | C2: $4.50\n"
        "- A3: 102 | B3: Backpack | C3: $29.00\n\n"
        "Formula: `=VLOOKUP(102, A2:C4, 3, FALSE)`\n"
        "Result: `$29.00` (looks up ID 102 in column A and returns the price from column 3)."
    )

    class MockVlookupModels:
        def generate_content(self, *, model, contents, config):
            captured_call["model"] = model
            captured_call["contents"] = contents
            captured_call["config"] = config

            thought_part = SimpleNamespace(
                thought=True,
                text="concise? Yes. Concrete example? Yes. Realistic next steps? Yes. Tone warm/grounded? Yes.Think",
            )
            answer_part = SimpleNamespace(
                thought=False,
                text=vlookup_explanation,
            )
            candidate = SimpleNamespace(
                content=SimpleNamespace(parts=[thought_part, answer_part])
            )
            return SimpleNamespace(
                candidates=[candidate],
                text=thought_part.text + answer_part.text,
            )

    monkeypatch.setattr(
        ai_client,
        "_create_client",
        lambda api_key, timeout_seconds=60: SimpleNamespace(models=MockVlookupModels()),
    )

    res = auth_client.post(
        "/coach/chat",
        json={
            "question": "Explain Excel VLOOKUP with a simple example",
            "history": [
                {"role": "user", "content": "I am learning spreadsheet formulas today."}
            ],
        },
    )
    assert res.status_code == 200
    data = res.json()
    answer = data["answer"]

    # Must contain the actual VLOOKUP explanation and concrete example
    assert "VLOOKUP" in answer
    assert "=VLOOKUP(" in answer
    assert "102" in answer

    # Must NOT contain internal checklist or thought markers
    assert "concise? Yes" not in answer
    assert "Concrete example? Yes" not in answer
    assert "Realistic next steps? Yes" not in answer
    assert "Tone warm/grounded? Yes" not in answer
    assert not answer.endswith("Think")

    # Verify prompt separation and thinking_config
    cfg = captured_call["config"]
    assert cfg.system_instruction == ai_client.COACH_SYSTEM_PROMPT
    assert cfg.thinking_config is not None
    assert cfg.thinking_config.include_thoughts is False
    assert cfg.thinking_config.thinking_budget == 0

    sent_contents = captured_call["contents"]
    assert len(sent_contents) == 2
    assert sent_contents[0].role == "user"
    assert "spreadsheet formulas" in sent_contents[0].parts[0].text
    assert sent_contents[1].role == "user"
    assert "Student Question:\nExplain Excel VLOOKUP with a simple example" in (
        sent_contents[1].parts[0].text
    ) or sent_contents[1].parts[0].text == "Explain Excel VLOOKUP with a simple example"


def test_corrupted_checklist_only_response_falls_back_to_next_model(monkeypatch):
    """
    If a model emits only internal checklist text ('concise? Yes...Think'),
    ai_client must reject it and fall back to the next candidate model.
    """
    monkeypatch.setenv("GEMINI_API_KEY", "AIzaSy_CHECKLIST_FALLBACK_KEY")
    monkeypatch.setenv("GEMINI_MODEL", "gemini-3.5-flash")

    models_tried = []

    class ChecklistThenGoodModels:
        def generate_content(self, *, model, contents, config):
            models_tried.append(model)
            if len(models_tried) == 1:
                return SimpleNamespace(
                    candidates=[
                        SimpleNamespace(
                            content=SimpleNamespace(
                                parts=[
                                    SimpleNamespace(
                                        thought=False,
                                        text="concise? Yes. Concrete example? Yes. Realistic next steps? Yes. Tone warm/grounded? Yes.Think",
                                    )
                                ]
                            )
                        )
                    ],
                    text="concise? Yes. Concrete example? Yes. Realistic next steps? Yes. Tone warm/grounded? Yes.Think",
                )
            return SimpleNamespace(
                candidates=[
                    SimpleNamespace(
                        content=SimpleNamespace(
                            parts=[
                                SimpleNamespace(
                                    thought=False,
                                    text="VLOOKUP looks up a value vertically in the leftmost column of a range, e.g. `=VLOOKUP(A2, D2:F20, 2, FALSE)`.",
                                )
                            ]
                        )
                    )
                ],
                text="VLOOKUP looks up a value vertically in the leftmost column of a range, e.g. `=VLOOKUP(A2, D2:F20, 2, FALSE)`.",
            )

    monkeypatch.setattr(
        ai_client,
        "_create_client",
        lambda api_key, timeout_seconds=60: SimpleNamespace(models=ChecklistThenGoodModels()),
    )

    result = ai_client.generate_coach_reply("Explain Excel VLOOKUP with a simple example")
    assert len(models_tried) == 2
    assert "VLOOKUP" in result["answer"]
    assert "concise? Yes" not in result["answer"]


def test_coach_endpoints_require_authentication():
    """Unauthenticated requests to /ai/coach/status and /ai/coach/chat must return 401."""
    with TestClient(app) as client:
        status_res = client.get("/ai/coach/status")
        assert status_res.status_code == 401

        chat_res = client.post("/ai/coach/chat", json={"question": "Hello"})
        assert chat_res.status_code == 401


def test_coach_chat_validation_and_missing_key(auth_client, monkeypatch):
    """Validate empty question (400) and missing GEMINI_API_KEY (503) on /ai/coach/chat."""
    empty_res = auth_client.post("/ai/coach/chat", json={"question": "   "})
    assert empty_res.status_code == 400

    monkeypatch.delenv("GEMINI_API_KEY", raising=False)
    monkeypatch.setattr(ai_client, "_ensure_env", lambda: None)

    missing_key_res = auth_client.post(
        "/ai/coach/chat",
        json={"question": "How do I study effectively?"},
    )
    assert missing_key_res.status_code == 503
    assert "GEMINI_API_KEY" in missing_key_res.json()["detail"]


@pytest.mark.skipif(
    os.getenv("RUN_LIVE_GEMINI_TESTS") != "1",
    reason="Optional live Gemini test; set RUN_LIVE_GEMINI_TESTS=1 to run against live API.",
)
def test_coach_chat_live_gemini_vlookup(auth_client):
    """
    Optional live integration test verifying /coach/chat on the VLOOKUP prompt.
    """
    raw_key = (os.getenv("GEMINI_API_KEY") or "").strip()
    assert ai_client.is_configured() is True

    chat_res = auth_client.post(
        "/coach/chat",
        json={
            "question": "Explain Excel VLOOKUP with a simple example",
        },
    )
    assert chat_res.status_code == 200
    chat_data = chat_res.json()
    answer = chat_data.get("answer") or ""
    assert "VLOOKUP" in answer.upper()
    assert "concise? Yes" not in answer
    assert not answer.endswith("Think")
    if raw_key:
        assert raw_key not in chat_res.text
