-- Phase 4: assessment hardening
-- Additive, nullable columns only; existing rows remain valid.

ALTER TABLE assessment_answers
    ADD COLUMN IF NOT EXISTS time_ms INTEGER;

ALTER TABLE assessment_attempts
    ADD COLUMN IF NOT EXISTS tab_switches INTEGER;
