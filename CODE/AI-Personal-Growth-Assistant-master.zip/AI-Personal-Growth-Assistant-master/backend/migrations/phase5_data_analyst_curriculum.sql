-- Phase 5: Detailed Learning Topics & Curriculum for the Data Analyst goal
-- Additive tables only; preserves all existing tables and data.

CREATE TABLE IF NOT EXISTS public.curriculum_stages (
    id SERIAL PRIMARY KEY,
    goal_slug VARCHAR(80) NOT NULL,
    stage_number INTEGER NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    skill_name VARCHAR(100),
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT curriculum_stages_goal_stage_key UNIQUE (goal_slug, stage_number)
);

CREATE TABLE IF NOT EXISTS public.curriculum_topics (
    id SERIAL PRIMARY KEY,
    stage_id INTEGER NOT NULL REFERENCES public.curriculum_stages(id) ON DELETE CASCADE,
    goal_slug VARCHAR(80) NOT NULL,
    stage_number INTEGER NOT NULL,
    topic_order INTEGER NOT NULL,
    global_order INTEGER NOT NULL,
    slug VARCHAR(140) NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    skill_name VARCHAR(100),
    estimated_minutes INTEGER NOT NULL DEFAULT 25,
    lesson_json TEXT,
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT curriculum_topics_slug_key UNIQUE (slug),
    CONSTRAINT curriculum_topics_stage_order_key UNIQUE (stage_id, topic_order)
);

CREATE TABLE IF NOT EXISTS public.user_topic_progress (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    topic_id INTEGER NOT NULL REFERENCES public.curriculum_topics(id) ON DELETE CASCADE,
    status VARCHAR(30) NOT NULL DEFAULT 'not_started',
    quiz_score INTEGER,
    started_at TIMESTAMP WITHOUT TIME ZONE,
    completed_at TIMESTAMP WITHOUT TIME ZONE,
    updated_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT user_topic_progress_user_topic_key UNIQUE (user_id, topic_id)
);

CREATE INDEX IF NOT EXISTS idx_curriculum_topics_stage_id
    ON public.curriculum_topics (stage_id, topic_order);

CREATE INDEX IF NOT EXISTS idx_user_topic_progress_user_id
    ON public.user_topic_progress (user_id);
