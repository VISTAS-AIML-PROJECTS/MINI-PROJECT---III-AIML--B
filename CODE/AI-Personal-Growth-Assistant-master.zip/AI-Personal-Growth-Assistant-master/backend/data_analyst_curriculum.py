"""
Data Analyst Curriculum, Personalization, Gemini Lesson Generation, and Progress Persistence.

Implements the 8-stage, 65-topic ordered curriculum exclusively for the
'Become a Data Analyst' / 'Data Analyst' learning goal.
"""

from datetime import datetime, timezone
import json
import re
import threading
from typing import Any, Optional

from sqlalchemy import text

import ai_client

GOAL_SLUG = "data_analyst"
VALID_PROGRESS_STATUSES = {"not_started", "in_progress", "completed"}

_schema_lock = threading.Lock()
_schema_initialized = False

# Map each of the 5 Data Analyst skills to the curriculum stages that teach it.
SKILL_TO_STAGE_NUMBERS: dict[str, list[int]] = {
    "excel": [1, 2],
    "statistics": [3],
    "sql": [4],
    "python": [5, 6],
    "data visualization": [7, 8],
}

# Ordered 8-stage, 65-topic Data Analyst curriculum.
DATA_ANALYST_STAGES: list[dict[str, Any]] = [
    {
        "stage_number": 1,
        "title": "Data Analysis Fundamentals",
        "skill_name": "Excel",
        "description": (
            "Start from zero: understand what data analysis is, how analysts work with "
            "stakeholders, the difference between structured and unstructured data, and how "
            "to frame measurable business questions and KPIs."
        ),
        "topics": [
            (
                "What Is Data Analysis?",
                "Learn how raw observations become evidence-backed decisions through descriptive, diagnostic, predictive, and prescriptive analysis.",
                20,
            ),
            (
                "The Data Analyst Role and Workflow",
                "Walk through the 6-step lifecycle of a data project: Ask, Prepare, Process, Analyze, Share, and Act.",
                25,
            ),
            (
                "Types of Data: Structured and Unstructured",
                "Distinguish tabular rows and columns, numeric vs. categorical variables, and unstructured text, logs, or media.",
                25,
            ),
            (
                "Asking Business Questions",
                "Translate vague stakeholder requests into specific, testable, and time-bound analytical questions.",
                25,
            ),
            (
                "Metrics, KPIs, and Basic Reporting",
                "Choose meaningful Key Performance Indicators (KPIs) vs. vanity metrics and summarize findings clearly.",
                30,
            ),
        ],
    },
    {
        "stage_number": 2,
        "title": "Excel and Spreadsheets",
        "skill_name": "Excel",
        "description": (
            "Master spreadsheet fundamentals from cell references and core formulas to "
            "VLOOKUP/XLOOKUP, Pivot Tables, charts, and a hands-on spreadsheet mini project."
        ),
        "topics": [
            (
                "Spreadsheet Basics and Data Types",
                "Navigate cells, rows, columns, and sheets while formatting text, numbers, currencies, and ISO dates cleanly.",
                20,
            ),
            (
                "Formulas and Cell References",
                "Write arithmetic formulas and master relative (A2), absolute ($A$2), and mixed ($A2) cell references.",
                25,
            ),
            (
                "Common Functions: SUM, AVERAGE, COUNT, IF",
                "Aggregate columns and build conditional logic using SUM, AVERAGE, COUNT, COUNTA, and IF.",
                30,
            ),
            (
                "Sorting, Filtering, and Removing Duplicates",
                "Inspect large tables, apply multi-column sorts and filters, and deduplicate dirty records safely.",
                25,
            ),
            (
                "Lookup Functions",
                "Connect tables vertically using VLOOKUP, XLOOKUP, and INDEX/MATCH without manual copy-pasting.",
                35,
            ),
            (
                "Pivot Tables",
                "Summarize thousands of rows in seconds by grouping dimensions, values, and calculated percentages in Pivot Tables.",
                35,
            ),
            (
                "Charts and Basic Reporting",
                "Build clean bar, line, and column charts in Excel and arrange a readable summary sheet.",
                30,
            ),
            (
                "Excel Mini Project",
                "Clean, join, summarize, and chart a multi-sheet retail order dataset in spreadsheets from start to finish.",
                45,
            ),
        ],
    },
    {
        "stage_number": 3,
        "title": "Statistics Fundamentals",
        "skill_name": "Statistics",
        "description": (
            "Build the mathematical intuition every analyst needs to summarize distributions, "
            "spot outliers, avoid misleading averages, and interpret relationships accurately."
        ),
        "topics": [
            (
                "Mean, Median, and Mode",
                "Measure central tendency and know when skewed values make the median far more reliable than the mean.",
                25,
            ),
            (
                "Range, Variance, and Standard Deviation",
                "Quantify how spread out or consistent a dataset is around its average.",
                30,
            ),
            (
                "Percentages and Ratios",
                "Calculate percentage change, conversion rates, shares of total, and basis-point differences accurately.",
                25,
            ),
            (
                "Distributions and Outliers",
                "Recognize normal vs. skewed distributions and detect outliers using quartiles and the Interquartile Range (IQR).",
                30,
            ),
            (
                "Correlation Versus Causation",
                "Interpret positive and negative correlation coefficients (r) and identify confounding variables.",
                25,
            ),
            (
                "Basic Probability and Sampling",
                "Understand random vs. biased samples, conditional probability, and why sample size matters in A/B tests.",
                30,
            ),
        ],
    },
    {
        "stage_number": 4,
        "title": "SQL and Databases",
        "skill_name": "SQL",
        "description": (
            "Query relational databases using PostgreSQL-compatible SQL — from SELECT and WHERE "
            "to JOINs, CTEs, Window Functions, and a complete SQL analytics project."
        ),
        "topics": [
            (
                "Database and Table Basics",
                "Understand relational tables, primary keys, foreign keys, schemas, and PostgreSQL data types.",
                20,
            ),
            (
                "SELECT and FROM",
                "Retrieve specific columns, alias column names with AS, and inspect distinct values with DISTINCT.",
                25,
            ),
            (
                "WHERE and Comparison Operators",
                "Filter rows using =, <>, >, <, BETWEEN, IN, LIKE/ILIKE, and boolean AND/OR conditions.",
                25,
            ),
            (
                "ORDER BY and LIMIT",
                "Sort query results ascending or descending and return top-N records cleanly.",
                20,
            ),
            (
                "Aggregate Functions: COUNT, SUM, AVG",
                "Compute table-wide totals, averages, minimums, and maximums across numeric and non-null columns.",
                25,
            ),
            (
                "GROUP BY and HAVING",
                "Segment metrics by category or date and filter grouped results using HAVING.",
                30,
            ),
            (
                "CASE WHEN",
                "Create conditional buckets, custom labels, and pivoted counts inside SQL SELECT queries.",
                30,
            ),
            (
                "INNER JOIN and LEFT JOIN",
                "Combine related tables on primary/foreign keys while understanding which rows are kept or excluded.",
                35,
            ),
            (
                "NULL Values and Data Validation",
                "Handle missing data safely with IS NULL, IS NOT NULL, COALESCE, and NULLIF in PostgreSQL.",
                25,
            ),
            (
                "Subqueries and Common Table Expressions",
                "Break complex multi-step questions into readable, modular WITH (CTE) blocks.",
                35,
            ),
            (
                "Window Functions",
                "Compute running totals, rankings (ROW_NUMBER, RANK), and period-over-period comparisons (LAG/LEAD) with OVER().",
                40,
            ),
            (
                "SQL Practice Project",
                "Write end-to-end PostgreSQL queries to analyze customer retention, revenue by cohort, and top products.",
                45,
            ),
        ],
    },
    {
        "stage_number": 5,
        "title": "Python Fundamentals",
        "skill_name": "Python",
        "description": (
            "Learn core Python programming from scratch — variables, control flow, loops, "
            "data structures, reusable functions, and error handling."
        ),
        "topics": [
            (
                "Python Introduction and Setup",
                "Understand how Python executes scripts and notebooks, and run your first expressions.",
                20,
            ),
            (
                "Variables and Data Types",
                "Store and inspect integers (int), floats (float), strings (str), booleans (bool), and None.",
                25,
            ),
            (
                "print() and input()",
                "Display formatted output using f-strings and parse user input safely.",
                20,
            ),
            (
                "Operators",
                "Use arithmetic, comparison, and logical operators (and, or, not) to evaluate expressions.",
                20,
            ),
            (
                "if / elif / else",
                "Control program branching based on thresholds and multi-condition rules.",
                25,
            ),
            (
                "for and while Loops",
                "Iterate over sequences, accumulate totals, and control loops with break and continue.",
                30,
            ),
            (
                "Lists, Tuples, and Dictionaries",
                "Organize collections of records using mutable lists, immutable tuples, and key-value dictionaries.",
                35,
            ),
            (
                "Functions",
                "Encapsulate repeatable logic with def, parameters, default arguments, and return values.",
                30,
            ),
            (
                "Error Handling",
                "Catch and handle bad data gracefully using try, except, ValueError, and KeyError.",
                25,
            ),
            (
                "Beginner Python Projects",
                "Combine loops, dictionaries, and functions to build a transaction summary analyzer in pure Python.",
                45,
            ),
        ],
    },
    {
        "stage_number": 6,
        "title": "Python for Data Analysis",
        "skill_name": "Python",
        "description": (
            "Use NumPy and Pandas to load, clean, filter, group, merge, and explore real-world "
            "tabular datasets programmatically."
        ),
        "topics": [
            (
                "Working with Python Libraries",
                "Import standard and third-party analytics packages (numpy as np, pandas as pd) and inspect versions.",
                20,
            ),
            (
                "NumPy Arrays and Basic Operations",
                "Perform fast vectorized math, array slicing, and summary statistics with NumPy.",
                30,
            ),
            (
                "Pandas Series and DataFrames",
                "Create 1D Series and 2D DataFrames, and inspect shape, columns, dtypes, head(), and info().",
                30,
            ),
            (
                "Reading CSV and Excel Files",
                "Load external CSV and spreadsheet files with pd.read_csv() and pd.read_excel() and export clean tables.",
                25,
            ),
            (
                "Selecting, Filtering, and Sorting Data",
                "Slice rows and columns using .loc[], .iloc[], boolean masks, .query(), and .sort_values().",
                30,
            ),
            (
                "Handling Missing and Duplicate Values",
                "Detect nulls with .isna().sum(), impute or drop missing values with .fillna() / .dropna(), and remove duplicates.",
                30,
            ),
            (
                "Data Type Conversion and Data Cleaning",
                "Convert strings to numeric or datetime types (pd.to_datetime, .astype) and standardize messy text columns.",
                30,
            ),
            (
                "Grouping and Aggregation",
                "Summarize metrics across categories using .groupby(), .agg(), and .pivot_table().",
                35,
            ),
            (
                "Merging and Joining DataFrames",
                "Combine multiple DataFrames horizontally and vertically using pd.merge() and pd.concat().",
                35,
            ),
            (
                "Exploratory Data Analysis with Pandas",
                "Run a complete Exploratory Data Analysis (EDA) workflow to profile distributions, anomalies, and trends.",
                40,
            ),
        ],
    },
    {
        "stage_number": 7,
        "title": "Data Visualization",
        "skill_name": "Data Visualization",
        "description": (
            "Communicate findings clearly by choosing the right chart, applying data storytelling "
            "principles, and building interactive dashboards."
        ),
        "topics": [
            (
                "Choosing the Right Chart",
                "Match your analytical goal (comparison, trend, distribution, composition, relationship) to the clearest chart type.",
                25,
            ),
            (
                "Bar Charts, Line Charts, and Histograms",
                "Compare categories with bar charts, track time-series trends with line charts, and inspect distributions with histograms.",
                30,
            ),
            (
                "Scatter Plots and Relationship Analysis",
                "Visualize correlations, clusters, and outliers between two continuous variables.",
                25,
            ),
            (
                "Data Storytelling",
                "Structure executive takeaways using context, action titles, annotations, and visual hierarchy.",
                30,
            ),
            (
                "Power BI Fundamentals",
                "Connect data sources in Power BI, model star-schema relationships, and write basic DAX measures.",
                35,
            ),
            (
                "Building Interactive Dashboards",
                "Design cohesive dashboard layouts withKPI cards, slicers, cross-filtering, and drill-downs.",
                35,
            ),
            (
                "Dashboard Mini Project",
                "Design and document an executive KPI dashboard that answers three core business questions at a glance.",
                45,
            ),
        ],
    },
    {
        "stage_number": 8,
        "title": "Real-World Data Analyst Projects",
        "skill_name": "Data Visualization",
        "description": (
            "Synthesize Excel, Statistics, SQL, Python/Pandas, and Data Visualization into "
            "portfolio-ready business case studies."
        ),
        "topics": [
            (
                "Sales Performance Analysis",
                "Analyze revenue trends, regional performance, average order value, and seasonal dips.",
                45,
            ),
            (
                "Customer and Product Analysis",
                "Evaluate customer retention, repeat purchase behavior, and Pareto (80/20) product contribution.",
                45,
            ),
            (
                "Marketing Campaign Analysis",
                "Measure funnel conversion rates, cost per acquisition (CPA), and return on ad spend (ROAS).",
                45,
            ),
            (
                "Data Cleaning and Quality Checks",
                "Build a repeatable data quality checklist to audit nulls, duplicates, schema drift, and impossible values.",
                40,
            ),
            (
                "Business Insights and Recommendations",
                "Turn raw analytical findings into quantified, prioritized business recommendations.",
                35,
            ),
            (
                "Final End-to-End Data Analyst Project",
                "Execute a full capstone project from business problem and SQL extraction to Pandas EDA and dashboard delivery.",
                60,
            ),
            (
                "Portfolio and Project Documentation",
                "Write clear README case studies that showcase your problem statement, methodology, code, and business impact.",
                35,
            ),
        ],
    },
]


def _slugify(stage_number: int, topic_order: int, title: str) -> str:
    clean = re.sub(r"[^a-z0-9]+", "-", title.lower()).strip("-")
    return f"da-s{stage_number}-t{topic_order}-{clean[:80]}"


def is_data_analyst_goal(title: Optional[str]) -> bool:
    """Return True strictly for the 'Become a Data Analyst' / 'Data Analyst' learning goal."""
    if not title:
        return False
    norm = re.sub(r"\s+", " ", title.strip().lower())
    return norm in ("become a data analyst", "data analyst") or "data analyst" in norm


def linked_stages_for_skill(skill_name: Optional[str]) -> list[int]:
    if not skill_name:
        return []
    key = skill_name.strip().lower()
    if key in SKILL_TO_STAGE_NUMBERS:
        return list(SKILL_TO_STAGE_NUMBERS[key])
    for k, stages in SKILL_TO_STAGE_NUMBERS.items():
        if k in key or key in k:
            return list(stages)
    return []


def ensure_curriculum_seeded(connection) -> None:
    """Create the curriculum tables if needed and ensure all 8 stages & 65 topics exist."""
    global _schema_initialized
    with _schema_lock:
        if not _schema_initialized:
            connection.execute(
                text("""
                    CREATE TABLE IF NOT EXISTS public.curriculum_stages (
                        id SERIAL PRIMARY KEY,
                        goal_slug VARCHAR(80) NOT NULL,
                        stage_number INTEGER NOT NULL,
                        title VARCHAR(200) NOT NULL,
                        description TEXT NOT NULL,
                        skill_name VARCHAR(100),
                        created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                        CONSTRAINT curriculum_stages_goal_stage_key UNIQUE (goal_slug, stage_number)
                    );

                    CREATE TABLE IF NOT EXISTS public.curriculum_topics (
                        id SERIAL PRIMARY KEY,
                        stage_id INTEGER NOT NULL REFERENCES public.curriculum_stages(id) ON DELETE CASCADE,
                        goal_slug VARCHAR(80) NOT NULL,
                        stage_number INTEGER NOT NULL,
                        topic_order INTEGER NOT NULL,
                        global_order INTEGER NOT NULL,
                        slug VARCHAR(140) NOT NULL,
                        title VARCHAR(200) NOT NULL,
                        description TEXT NOT NULL,
                        skill_name VARCHAR(100),
                        estimated_minutes INTEGER NOT NULL DEFAULT 25,
                        lesson_json TEXT,
                        created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                        CONSTRAINT curriculum_topics_slug_key UNIQUE (slug),
                        CONSTRAINT curriculum_topics_stage_order_key UNIQUE (stage_id, topic_order)
                    );

                    CREATE TABLE IF NOT EXISTS public.user_topic_progress (
                        id SERIAL PRIMARY KEY,
                        user_id INTEGER NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
                        topic_id INTEGER NOT NULL REFERENCES public.curriculum_topics(id) ON DELETE CASCADE,
                        status VARCHAR(30) NOT NULL DEFAULT 'not_started',
                        quiz_score INTEGER,
                        started_at TIMESTAMP WITHOUT TIME ZONE,
                        completed_at TIMESTAMP WITHOUT TIME ZONE,
                        updated_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
                        CONSTRAINT user_topic_progress_user_topic_key UNIQUE (user_id, topic_id)
                    );
                """)
            )
            _schema_initialized = True

        count_row = connection.execute(
            text(
                "SELECT COUNT(*) AS cnt FROM curriculum_topics WHERE goal_slug = :slug"
            ),
            {"slug": GOAL_SLUG},
        ).fetchone()
        if count_row and count_row.cnt >= 65:
            return

        global_idx = 0
        for stage_spec in DATA_ANALYST_STAGES:
            stage_num = stage_spec["stage_number"]
            stage_row = connection.execute(
                text("""
                    INSERT INTO curriculum_stages (goal_slug, stage_number, title, description, skill_name)
                    VALUES (:goal_slug, :stage_number, :title, :description, :skill_name)
                    ON CONFLICT (goal_slug, stage_number) DO UPDATE SET
                        title = EXCLUDED.title,
                        description = EXCLUDED.description,
                        skill_name = EXCLUDED.skill_name
                    RETURNING id
                """),
                {
                    "goal_slug": GOAL_SLUG,
                    "stage_number": stage_num,
                    "title": stage_spec["title"],
                    "description": stage_spec["description"],
                    "skill_name": stage_spec["skill_name"],
                },
            ).fetchone()
            stage_id = stage_row.id

            for topic_order, (t_title, t_desc, est_min) in enumerate(
                stage_spec["topics"], start=1
            ):
                global_idx += 1
                slug = _slugify(stage_num, topic_order, t_title)
                connection.execute(
                    text("""
                        INSERT INTO curriculum_topics (
                            stage_id, goal_slug, stage_number, topic_order, global_order,
                            slug, title, description, skill_name, estimated_minutes
                        )
                        VALUES (
                            :stage_id, :goal_slug, :stage_number, :topic_order, :global_order,
                            :slug, :title, :description, :skill_name, :estimated_minutes
                        )
                        ON CONFLICT (slug) DO UPDATE SET
                            stage_id = EXCLUDED.stage_id,
                            stage_number = EXCLUDED.stage_number,
                            topic_order = EXCLUDED.topic_order,
                            global_order = EXCLUDED.global_order,
                            title = EXCLUDED.title,
                            description = EXCLUDED.description,
                            skill_name = EXCLUDED.skill_name,
                            estimated_minutes = EXCLUDED.estimated_minutes
                    """),
                    {
                        "stage_id": stage_id,
                        "goal_slug": GOAL_SLUG,
                        "stage_number": stage_num,
                        "topic_order": topic_order,
                        "global_order": global_idx,
                        "slug": slug,
                        "title": t_title,
                        "description": t_desc,
                        "skill_name": stage_spec["skill_name"],
                        "estimated_minutes": est_min,
                    },
                )
        connection.commit()


def _build_curated_lesson(topic_row: Any) -> dict[str, Any]:
    """
    Build a detailed, beginner-friendly, domain-accurate structured lesson for any
    Data Analyst curriculum topic. Used when Gemini is unavailable or hits quota/timeout,
    and ensures SQL topics use PostgreSQL syntax, Python topics use valid Python 3,
    and Pandas topics use runnable examples with expected output.
    """
    stage_num = int(topic_row.stage_number)
    title = str(topic_row.title)
    desc = str(topic_row.description)
    skill = str(topic_row.skill_name or "Data Analysis")

    if stage_num == 4:
        # Stage 4: SQL and Databases (PostgreSQL syntax)
        lang = "sql"
        if "SELECT and FROM" in title:
            code_example = (
                "-- PostgreSQL query: select specific columns and compute a derived column\n"
                "SELECT\n"
                "    order_id,\n"
                "    customer_id,\n"
                "    unit_price * quantity AS line_total\n"
                "FROM sales_orders\n"
                "LIMIT 3;"
            )
            expected_output = (
                " order_id | customer_id | line_total \n"
                "----------+-------------+------------\n"
                "     1001 |         42  |     120.00\n"
                "     1002 |         19  |      45.50\n"
                "     1003 |         42  |      89.90\n"
                "(3 rows)"
            )
        elif "WHERE" in title:
            code_example = (
                "-- PostgreSQL query: filter rows matching multiple conditions\n"
                "SELECT order_id, region, order_total, order_date\n"
                "FROM sales_orders\n"
                "WHERE region IN ('North', 'West')\n"
                "  AND order_total >= 100.00\n"
                "  AND order_date >= DATE '2026-01-01';"
            )
            expected_output = (
                " order_id | region | order_total | order_date \n"
                "----------+--------+-------------+------------\n"
                "     1001 | North  |      120.00 | 2026-01-14\n"
                "     1008 | West   |      240.00 | 2026-02-03"
            )
        elif "GROUP BY" in title or "Aggregate" in title:
            code_example = (
                "-- PostgreSQL query: aggregate revenue by region and filter groups with HAVING\n"
                "SELECT\n"
                "    region,\n"
                "    COUNT(*) AS total_orders,\n"
                "    ROUND(AVG(order_total), 2) AS avg_order_value,\n"
                "    SUM(order_total) AS total_revenue\n"
                "FROM sales_orders\n"
                "GROUP BY region\n"
                "HAVING COUNT(*) >= 2\n"
                "ORDER BY total_revenue DESC;"
            )
            expected_output = (
                " region | total_orders | avg_order_value | total_revenue \n"
                "--------+--------------+-----------------+---------------\n"
                " North  |            4 |          145.00 |        580.00\n"
                " West   |            3 |          130.00 |        390.00"
            )
        elif "JOIN" in title:
            code_example = (
                "-- PostgreSQL query: join customers with their orders\n"
                "SELECT\n"
                "    c.customer_id,\n"
                "    c.customer_name,\n"
                "    COALESCE(SUM(o.order_total), 0) AS lifetime_spend\n"
                "FROM customers AS c\n"
                "LEFT JOIN sales_orders AS o\n"
                "    ON o.customer_id = c.customer_id\n"
                "GROUP BY c.customer_id, c.customer_name\n"
                "ORDER BY lifetime_spend DESC;"
            )
            expected_output = (
                " customer_id | customer_name | lifetime_spend \n"
                "-------------+---------------+----------------\n"
                "          42 | Priya Patel   |         209.90\n"
                "          19 | Lucas Meyer   |          45.50\n"
                "          55 | Dana Kim      |           0.00"
            )
        elif "Window" in title:
            code_example = (
                "-- PostgreSQL query: rank orders per customer and compute running total\n"
                "SELECT\n"
                "    customer_id,\n"
                "    order_date,\n"
                "    order_total,\n"
                "    ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY order_date) AS order_seq,\n"
                "    SUM(order_total) OVER (\n"
                "        PARTITION BY customer_id\n"
                "        ORDER BY order_date\n"
                "        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW\n"
                "    ) AS running_spend\n"
                "FROM sales_orders;"
            )
            expected_output = (
                " customer_id | order_date | order_total | order_seq | running_spend \n"
                "-------------+------------+-------------+-----------+---------------\n"
                "          42 | 2026-01-14 |      120.00 |         1 |        120.00\n"
                "          42 | 2026-01-28 |       89.90 |         2 |        209.90"
            )
        else:
            code_example = (
                f"-- PostgreSQL example for: {title}\n"
                "WITH clean_orders AS (\n"
                "    SELECT\n"
                "        order_id,\n"
                "        COALESCE(region, 'Unassigned') AS region,\n"
                "        CASE\n"
                "            WHEN order_total >= 150 THEN 'High Value'\n"
                "            ELSE 'Standard'\n"
                "        END AS order_tier,\n"
                "        order_total\n"
                "    FROM sales_orders\n"
                "    WHERE order_total IS NOT NULL\n"
                ")\n"
                "SELECT region, order_tier, COUNT(*) AS orders_count, SUM(order_total) AS revenue\n"
                "FROM clean_orders\n"
                "GROUP BY region, order_tier\n"
                "ORDER BY revenue DESC\n"
                "LIMIT 5;"
            )
            expected_output = (
                " region | order_tier | orders_count | revenue \n"
                "--------+------------+--------------+---------\n"
                " North  | High Value |            2 |  360.00\n"
                " West   | Standard   |            3 |  245.00"
            )
    elif stage_num == 5:
        # Stage 5: Python Fundamentals (valid Python 3 code)
        lang = "python"
        if "Variables" in title or "Introduction" in title:
            code_example = (
                "# Python 3: variables and core data types for analytics\n"
                "customer_name = 'Amina'       # str\n"
                "orders_count = 4              # int\n"
                "total_spent = 189.50          # float\n"
                "is_active_member = True       # bool\n\n"
                "avg_order = round(total_spent / orders_count, 2)\n"
                "print(type(customer_name), type(orders_count), type(total_spent))\n"
                "print(f'{customer_name} placed {orders_count} orders (avg: ${avg_order})')"
            )
            expected_output = (
                "<class 'str'> <class 'int'> <class 'float'>\n"
                "Amina placed 4 orders (avg: $47.38)"
            )
        elif "if / elif / else" in title or "Operators" in title:
            code_example = (
                "# Python 3: conditional customer segmentation\n"
                "monthly_spend = 320.0\n"
                "orders = 6\n\n"
                "if monthly_spend >= 300 and orders >= 5:\n"
                "    segment = 'VIP'\n"
                "elif monthly_spend >= 100:\n"
                "    segment = 'Regular'\n"
                "else:\n"
                "    segment = 'Starter'\n\n"
                "print(f'Customer Segment: {segment}')"
            )
            expected_output = "Customer Segment: VIP"
        elif "Lists, Tuples, and Dictionaries" in title:
            code_example = (
                "# Python 3: dictionaries and lists of transaction records\n"
                "orders = [\n"
                "    {'id': 101, 'category': 'SQL Course', 'amount': 49.0},\n"
                "    {'id': 102, 'category': 'Python Course', 'amount': 79.0},\n"
                "    {'id': 103, 'category': 'SQL Course', 'amount': 49.0},\n"
                "]\n\n"
                "totals_by_category = {}\n"
                "for row in orders:\n"
                "    cat = row['category']\n"
                "    totals_by_category[cat] = totals_by_category.get(cat, 0.0) + row['amount']\n\n"
                "print(totals_by_category)"
            )
            expected_output = "{'SQL Course': 98.0, 'Python Course': 79.0}"
        elif "Error Handling" in title:
            code_example = (
                "# Python 3: safe parsing of messy numeric strings with try / except\n"
                "raw_values = ['120.50', 'N/A', '89.50', '', '40.00']\n"
                "clean_numbers = []\n\n"
                "for item in raw_values:\n"
                "    try:\n"
                "        clean_numbers.append(float(item))\n"
                "    except ValueError:\n"
                "        print(f'Skipping invalid value: {item!r}')\n\n"
                "print('Valid sum:', sum(clean_numbers))"
            )
            expected_output = (
                "Skipping invalid value: 'N/A'\n"
                "Skipping invalid value: ''\n"
                "Valid sum: 250.0"
            )
        else:
            code_example = (
                f"# Python 3 example for: {title}\n"
                "daily_sales = [120.0, 85.5, 210.0, 95.0, 150.5]\n\n"
                "def summarize_sales(amounts):\n"
                "    if not amounts:\n"
                "        return {'count': 0, 'total': 0.0, 'average': 0.0}\n"
                "    total = round(sum(amounts), 2)\n"
                "    avg = round(total / len(amounts), 2)\n"
                "    high_days = [x for x in amounts if x >= 100.0]\n"
                "    return {'count': len(amounts), 'total': total, 'average': avg, 'high_days': len(high_days)}\n\n"
                "report = summarize_sales(daily_sales)\n"
                "print(f\"Orders: {report['count']} | Total: ${report['total']:.2f} | Avg: ${report['average']:.2f}\")\n"
                "print(f\"Days >= $100: {report['high_days']}\")"
            )
            expected_output = (
                "Orders: 5 | Total: $661.00 | Avg: $132.20\n"
                "Days >= $100: 3"
            )
    elif stage_num == 6:
        # Stage 6: Python for Data Analysis (runnable Pandas / NumPy example)
        lang = "python"
        if "NumPy" in title:
            code_example = (
                "# Runnable NumPy example: vectorized array operations\n"
                "import numpy as np\n\n"
                "prices = np.array([20.0, 35.0, 50.0, 15.0])\n"
                "quantities = np.array([3, 2, 1, 4])\n"
                "revenues = prices * quantities\n\n"
                "print('Line revenues:', revenues)\n"
                "print('Total revenue:', np.sum(revenues))\n"
                "print('Mean revenue :', np.mean(revenues))"
            )
            expected_output = (
                "Line revenues: [60. 70. 50. 60.]\n"
                "Total revenue: 240.0\n"
                "Mean revenue : 60.0"
            )
        elif "Missing" in title or "Duplicate" in title:
            code_example = (
                "# Runnable Pandas example: handling missing and duplicate values\n"
                "import pandas as pd\n\n"
                "df = pd.DataFrame({\n"
                "    'order_id': [1, 2, 2, 3],\n"
                "    'city': ['Austin', 'Seattle', 'Seattle', None],\n"
                "    'amount': [100.0, 200.0, 200.0, None],\n"
                "})\n\n"
                "df_clean = df.drop_duplicates(subset=['order_id']).copy()\n"
                "df_clean['city'] = df_clean['city'].fillna('Unknown')\n"
                "df_clean['amount'] = df_clean['amount'].fillna(df_clean['amount'].median())\n"
                "print(df_clean.to_string(index=False))"
            )
            expected_output = (
                " order_id    city  amount\n"
                "        1  Austin   100.0\n"
                "        2 Seattle   200.0\n"
                "        3 Unknown   150.0"
            )
        elif "Merging" in title or "Joining" in title:
            code_example = (
                "# Runnable Pandas example: merging customers and orders DataFrames\n"
                "import pandas as pd\n\n"
                "customers = pd.DataFrame({'customer_id': [1, 2], 'name': ['Maya', 'Liam']})\n"
                "orders = pd.DataFrame({'order_id': [501, 502], 'customer_id': [1, 2], 'total': [95.0, 140.0]})\n\n"
                "merged = pd.merge(customers, orders, on='customer_id', how='left')\n"
                "print(merged.to_string(index=False))"
            )
            expected_output = (
                " customer_id name  order_id  total\n"
                "           1 Maya       501   95.0\n"
                "           2 Liam       502  140.0"
            )
        else:
            code_example = (
                f"# Runnable Pandas example for: {title}\n"
                "import pandas as pd\n\n"
                "data = {\n"
                "    'order_id': [101, 102, 103, 104],\n"
                "    'category': ['Electronics', 'Books', 'Electronics', 'Books'],\n"
                "    'revenue': [250.0, 35.0, 180.0, 45.0],\n"
                "}\n"
                "df = pd.DataFrame(data)\n\n"
                "summary = (\n"
                "    df.groupby('category', as_index=False)\n"
                "      .agg(orders=('order_id', 'count'), total_revenue=('revenue', 'sum'), avg_revenue=('revenue', 'mean'))\n"
                "      .sort_values(by='total_revenue', ascending=False)\n"
                ")\n"
                "print(summary.to_string(index=False))"
            )
            expected_output = (
                "   category  orders  total_revenue  avg_revenue\n"
                "Electronics       2          430.0        215.0\n"
                "      Books       2           80.0         40.0"
            )
    elif stage_num == 2:
        # Stage 2: Excel and Spreadsheets
        lang = "excel"
        code_example = (
            "Sample Sheet (Cells A1:D5):\n"
            "| Row | A (Product ID) | B (Category) | C (Units) | D (Unit Price) | E (Line Total) |\n"
            "|  2  | P-101          | Hardware     | 4         | 25.00          | =C2*D2         |\n"
            "|  3  | P-102          | Software     | 2         | 80.00          | =C3*D3         |\n"
            "|  4  | P-103          | Hardware     | 5         | 30.00          | =C4*D4         |\n\n"
            "Summary Formulas:\n"
            "- Total Revenue:   =SUM(E2:E4)\n"
            "- Average Revenue: =AVERAGE(E2:E4)\n"
            "- Lookup Price:    =VLOOKUP(\"P-102\", A2:D4, 4, FALSE)"
        )
        expected_output = (
            "E2 = 100.00 | E3 = 160.00 | E4 = 150.00\n"
            "Total Revenue = 410.00\n"
            "Average Revenue = 136.67\n"
            "Lookup Price for P-102 = 80.00"
        )
    elif stage_num == 3:
        # Stage 3: Statistics Fundamentals
        lang = "text"
        code_example = (
            "Dataset: Daily customer wait times (in minutes) = [4, 5, 5, 6, 7, 9, 27]\n\n"
            "Step-by-step calculation:\n"
            "1. Mean (Average) = (4 + 5 + 5 + 6 + 7 + 9 + 27) / 7 = 63 / 7 = 9.0 minutes\n"
            "2. Median (Middle value of sorted list, 4th of 7) = 6.0 minutes\n"
            "3. Mode (Most frequent value) = 5.0 minutes\n"
            "4. Insight: Because of the single 27-minute outlier, the Mean (9.0m) overstates "
            "typical wait time compared to the Median (6.0m)."
        )
        expected_output = (
            "Mean: 9.0 min | Median: 6.0 min | Mode: 5.0 min (Outlier = 27 min)"
        )
    else:
        # Stages 1, 7, 8: Data Analysis Fundamentals, Visualization, Real-World Projects
        lang = "text"
        code_example = (
            f"Practical Case Walkthrough — {title}:\n"
            "1. Business Question: Why did monthly subscription renewals drop by 8% in Q2?\n"
            "2. Metric Definition: Renewal Rate = (Renewed Contracts / Up-for-Renewal Contracts) * 100\n"
            "3. Segmentation: Break down Renewal Rate by customer plan tier, onboarding completion, and support ticket volume.\n"
            "4. Finding: Customers who completed onboarding within 7 days had an 89% renewal rate vs. 61% for those who did not."
        )
        expected_output = (
            "Actionable Takeaway: Prioritize a 7-day onboarding checklist for new accounts "
            "to close the 28-percentage-point renewal gap."
        )

    return {
        "title": title,
        "stage_number": stage_num,
        "skill_name": skill,
        "introduction": (
            f"Welcome to **{title}**. {desc} "
            "This beginner-friendly lesson starts from first principles so you understand "
            "both *why* this concept matters to a Data Analyst and *how* to apply it step by step."
        ),
        "learning_objectives": [
            f"Understand the core purpose and terminology of {title} from scratch.",
            f"Walk through a concrete {skill} example and interpret its output accurately.",
            f"Apply {title} in a hands-on practice task and verify your understanding with a short quiz.",
        ],
        "sections": [
            {
                "heading": "1. Core Concept Explained from Zero",
                "body": (
                    f"{desc}\n\n"
                    f"As a Data Analyst, you use **{title}** whenever you need to turn raw, messy records "
                    "into trustworthy answers for your team. Instead of guessing, you follow a repeatable "
                    "structure: define the input data, apply a clear operation or rule, and verify that the "
                    "resulting output matches expectations."
                ),
            },
            {
                "heading": "2. Step-by-Step Workflow",
                "body": (
                    "Follow these three steps whenever you apply this topic in practice:\n"
                    "1. **Inspect the inputs**: Check column names, data types, units, and any missing values before writing formulas or code.\n"
                    "2. **Start with a small testable slice**: Run your logic on 3–5 sample rows first so you can verify the result by hand.\n"
                    "3. **Validate edge cases**: Check what happens when values are zero, duplicated, missing (NULL/NaN), or unusually large."
                ),
            },
            {
                "heading": "3. Common Beginner Pitfalls to Avoid",
                "body": (
                    "- Skipping data-type checks (for example, treating numbers stored as text as if they were numeric).\n"
                    "- Reporting a single summary number without checking whether outliers or missing rows skewed the result.\n"
                    "- Writing a complex formula or query all at once instead of building and verifying it one clause at a time."
                ),
            },
        ],
        "examples": [
            {
                "title": f"Worked Example: {title}",
                "language": lang,
                "code": code_example,
                "expected_output": expected_output,
                "explanation": (
                    "Read through each line of the example above and compare it with the expected output. "
                    "Notice how every input field maps cleanly to the final result."
                ),
            }
        ],
        "practice_task": {
            "title": f"Hands-On Practice: Apply {title}",
            "instructions": (
                f"Using the worked example above as your template, adapt the {skill} logic to answer "
                "a slightly modified scenario:\n"
                "1. Identify the key input fields or variables required.\n"
                "2. Write out the formula, query, or calculation step by step.\n"
                "3. State what the expected output should look like for a 3-row sample and explain how you would spot an error."
            ),
            "starter_hint": (
                "Start by copying the structure from the Worked Example and changing one filter, "
                "column, or threshold at a time."
            ),
            "expected_outcome": (
                f"A clear, working {skill} solution that produces the expected summary output and handles missing or edge-case values."
            ),
        },
        "quiz": [
            {
                "question": f"What is the primary goal of mastering '{title}' in the Data Analyst workflow?",
                "options": [
                    f"To accurately transform, analyze, or communicate data when working on {skill} tasks",
                    "To memorize syntax without checking whether the underlying data is clean",
                    "To replace business questions with random charts",
                    "To skip data validation and ship raw tables directly to executives",
                ],
                "correct_index": 0,
                "explanation": (
                    f"'{title}' helps analysts reliably process, analyze, and communicate evidence-backed insights."
                ),
            },
            {
                "question": "Why should a beginner test their formula, query, or script on a small 3–5 row sample first?",
                "options": [
                    "So you can verify the calculation by hand and catch logic errors early",
                    "Because databases and spreadsheets cannot store more than 5 rows",
                    "To permanently delete the rest of the dataset",
                    "Because data types only matter in small tables",
                ],
                "correct_index": 0,
                "explanation": (
                    "Verifying your logic on a small slice lets you confirm the exact numbers before scaling to thousands of rows."
                ),
            },
            {
                "question": "What should you check before trusting a summary metric or output table?",
                "options": [
                    "Data types, missing values (NULL/NaN), duplicates, and extreme outliers",
                    "Only the font color of the table header",
                    "Whether the result is an even number",
                    "Nothing — the first output is always final",
                ],
                "correct_index": 0,
                "explanation": (
                    "Checking data types, nulls, duplicates, and outliers prevents silent calculation mistakes."
                ),
            },
        ],
        "completion_criterion": (
            f"Review the step-by-step lesson and worked example, complete the practice task, "
            f"and answer the quiz questions to mark '{title}' complete."
        ),
        "example_verification_note": (
            "Reference example provided for study and local practice (not executed in a live sandbox)."
        ),
        "generated_by": "curated_curriculum",
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }


def _normalize_lesson_payload(raw_data: Any, topic_row: Any, source: str = "gemini") -> dict[str, Any]:
    """Validate and merge a Gemini-generated JSON lesson with fallback defaults so no field is ever missing."""
    base = _build_curated_lesson(topic_row)
    if not isinstance(raw_data, dict):
        return base

    intro = str(raw_data.get("introduction") or "").strip()
    if len(intro) >= 30:
        base["introduction"] = intro

    raw_objs = raw_data.get("learning_objectives")
    if isinstance(raw_objs, list):
        clean_objs = [str(x).strip() for x in raw_objs if str(x).strip()]
        if len(clean_objs) >= 2:
            base["learning_objectives"] = clean_objs[:5]

    raw_sections = raw_data.get("sections")
    if isinstance(raw_sections, list):
        clean_sections = []
        for s in raw_sections:
            if isinstance(s, dict):
                h = str(s.get("heading") or "").strip()
                b = str(s.get("body") or "").strip()
                if h and b:
                    clean_sections.append({"heading": h, "body": b})
        if len(clean_sections) >= 2:
            base["sections"] = clean_sections[:6]

    raw_examples = raw_data.get("examples")
    if isinstance(raw_examples, list):
        clean_examples = []
        for ex in raw_examples:
            if isinstance(ex, dict):
                code = str(ex.get("code") or "").strip()
                if code:
                    clean_examples.append(
                        {
                            "title": str(ex.get("title") or f"Example: {topic_row.title}").strip(),
                            "language": str(ex.get("language") or base["examples"][0]["language"]).strip(),
                            "code": code,
                            "expected_output": str(
                                ex.get("expected_output") or base["examples"][0]["expected_output"]
                            ).strip(),
                            "explanation": str(
                                ex.get("explanation") or base["examples"][0]["explanation"]
                            ).strip(),
                        }
                    )
        if clean_examples:
            base["examples"] = clean_examples[:3]

    raw_practice = raw_data.get("practice_task")
    if isinstance(raw_practice, dict):
        instr = str(raw_practice.get("instructions") or "").strip()
        if instr:
            base["practice_task"] = {
                "title": str(raw_practice.get("title") or base["practice_task"]["title"]).strip(),
                "instructions": instr,
                "starter_hint": str(
                    raw_practice.get("starter_hint") or base["practice_task"]["starter_hint"]
                ).strip(),
                "expected_outcome": str(
                    raw_practice.get("expected_outcome") or base["practice_task"]["expected_outcome"]
                ).strip(),
            }

    raw_quiz = raw_data.get("quiz")
    if isinstance(raw_quiz, list):
        clean_quiz = []
        for q in raw_quiz:
            if not isinstance(q, dict):
                continue
            q_text = str(q.get("question") or "").strip()
            opts = q.get("options")
            c_idx = q.get("correct_index")
            if (
                q_text
                and isinstance(opts, list)
                and len(opts) >= 3
                and isinstance(c_idx, int)
                and 0 <= c_idx < len(opts)
            ):
                clean_quiz.append(
                    {
                        "question": q_text,
                        "options": [str(o).strip() for o in opts[:4]],
                        "correct_index": c_idx,
                        "explanation": str(q.get("explanation") or "").strip()
                        or "Review the lesson concepts and worked example above.",
                    }
                )
        if clean_quiz:
            base["quiz"] = clean_quiz[:4]

    crit = str(raw_data.get("completion_criterion") or "").strip()
    if crit:
        base["completion_criterion"] = crit

    base["generated_by"] = source
    base["generated_at"] = datetime.now(timezone.utc).isoformat()
    return base


def _generate_lesson_via_gemini(topic_row: Any) -> Optional[dict[str, Any]]:
    """Call Gemini (`ai_client.generate_text`) to build structured JSON lesson content for `topic_row`."""
    if not ai_client.is_configured():
        return None

    stage_num = int(topic_row.stage_number)
    stage_Rule = ""
    if stage_num == 4:
        stage_Rule = "Use PostgreSQL-compatible SQL syntax in all SQL code examples and show realistic query output tables."
    elif stage_num == 5:
        stage_Rule = "Use valid, beginner-friendly Python 3 code in all examples and show exact printed output."
    elif stage_num == 6:
        stage_Rule = "Use runnable Python 3 + pandas/numpy code (creating small in-memory DataFrames/arrays) and show exact expected output."
    elif stage_num == 2:
        stage_Rule = "Use clear Excel cell tables (e.g. A1:D5) and exact spreadsheet formulas with expected cell values."

    prompt = (
        f"Create a beginner-friendly, structured lesson for a student pursuing 'Become a Data Analyst'.\n"
        f"Stage {stage_num}: {topic_row.skill_name}\n"
        f"Topic ({topic_row.topic_order}): {topic_row.title}\n"
        f"Topic Summary: {topic_row.description}\n"
        f"{stage_Rule}\n\n"
        "The student may be a complete beginner starting from zero. Explain every concept clearly BEFORE asking them to solve the exercise.\n"
        "Return ONLY valid JSON matching this exact structure:\n"
        "{\n"
        '  "introduction": "2-3 sentences welcoming the student and explaining why this topic matters",\n'
        '  "learning_objectives": ["objective 1", "objective 2", "objective 3"],\n'
        '  "sections": [\n'
        '    {"heading": "1. ...", "body": "clear step-by-step explanation"},\n'
        '    {"heading": "2. ...", "body": "practical rules and syntax/formulas"}\n'
        "  ],\n"
        '  "examples": [\n'
        "    {\n"
        '      "title": "Worked Example title",\n'
        '      "language": "sql|python|excel|text",\n'
        '      "code": "concrete code, SQL query, or spreadsheet formula table",\n'
        '      "expected_output": "realistic expected output",\n'
        '      "explanation": "step-by-step walkthrough of how the example produces the output"\n'
        "    }\n"
        "  ],\n"
        '  "practice_task": {\n'
        '    "title": "Practice task title",\n'
        '    "instructions": "clear beginner-friendly exercise instructions",\n'
        '    "starter_hint": "helpful hint",\n'
        '    "expected_outcome": "what a correct solution produces"\n'
        "  },\n"
        '  "quiz": [\n'
        "    {\n"
        '      "question": "Multiple-choice question 1",\n'
        '      "options": ["Option A", "Option B", "Option C", "Option D"],\n'
        '      "correct_index": 0,\n'
        '      "explanation": "Why this option is correct"\n'
        "    },\n"
        "    {\n"
        '      "question": "Multiple-choice question 2",\n'
        '      "options": ["Option A", "Option B", "Option C", "Option D"],\n'
        '      "correct_index": 1,\n'
        '      "explanation": "Why this option is correct"\n'
        "    }\n"
        "  ],\n"
        '  "completion_criterion": "One sentence stating what the student should complete"\n'
        "}"
    )

    try:
        raw = ai_client.generate_text(
            prompt,
            system=(
                "You are an expert Data Analytics curriculum designer. "
                "Output ONLY valid JSON with no markdown fences or extra commentary."
            ),
            json_output=True,
            temperature=0.3,
            max_tokens=2048,
            timeout=18,
            prefer=["gemini-3.5-flash-lite", "gemini-3.1-flash-lite", "gemini-3.5-flash"],
        )
        cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw.strip())
        parsed = json.loads(cleaned)
        return _normalize_lesson_payload(parsed, topic_row, source="gemini")
    except Exception:
        return None


def get_or_create_topic_lesson(
    connection,
    topic_row: Any,
    *,
    use_gemini_if_missing: bool = True,
    force_regenerate: bool = False,
) -> dict[str, Any]:
    """
    Return the persisted lesson JSON for `topic_row`.
    If not yet stored in PostgreSQL (or if `force_regenerate` is True), generate it
    (using Gemini when available with automatic fallback to curated content) and persist
    it in `curriculum_topics.lesson_json` so Gemini is never called repeatedly for the
    same already-generated topic.
    """
    if topic_row.lesson_json and not force_regenerate:
        try:
            loaded = json.loads(topic_row.lesson_json)
            if isinstance(loaded, dict) and loaded.get("introduction"):
                return loaded
        except Exception:
            pass

    lesson_data = None
    if use_gemini_if_missing:
        lesson_data = _generate_lesson_via_gemini(topic_row)

    if lesson_data is None:
        lesson_data = _build_curated_lesson(topic_row)

    serialized = json.dumps(lesson_data, ensure_ascii=False)
    connection.execute(
        text("UPDATE curriculum_topics SET lesson_json = :lesson_json WHERE id = :id"),
        {"lesson_json": serialized, "id": topic_row.id},
    )
    connection.commit()
    return lesson_data


def _load_goal_skill_assessments(connection, goal_id: int, user_id: int) -> dict[str, dict[str, Any]]:
    """
    Load the user's latest assessment outcome per skill for `goal_id`, keyed by
    lowercase skill name (e.g. 'excel', 'sql', 'python', 'statistics', 'data visualization').
    """
    rows = connection.execute(
        text("""
            SELECT gs.skill_id, s.name, s.category, gs.importance,
                   sa.score_percentage, sa.skill_level
            FROM goal_skills gs
            JOIN skills s ON s.id = gs.skill_id
            LEFT JOIN LATERAL (
                SELECT score_percentage, skill_level
                FROM skill_assessments sa2
                WHERE sa2.user_id = :user_id
                  AND sa2.goal_id = :goal_id
                  AND sa2.skill_id = gs.skill_id
                ORDER BY sa2.created_at DESC, sa2.id DESC
                LIMIT 1
            ) sa ON TRUE
            WHERE gs.goal_id = :goal_id
        """),
        {"goal_id": goal_id, "user_id": user_id},
    ).fetchall()

    by_name: dict[str, dict[str, Any]] = {}
    for r in rows:
        score = float(r.score_percentage) if r.score_percentage is not None else None
        if r.skill_level is None:
            gap_status = "not_assessed"
        elif r.skill_level in ("beginner", "intermediate"):
            gap_status = "gap"
        else:
            gap_status = "strong"

        by_name[r.name.strip().lower()] = {
            "skill_id": r.skill_id,
            "skill_name": r.name,
            "category": r.category,
            "importance": r.importance,
            "score_percentage": score,
            "skill_level": r.skill_level,
            "gap_status": gap_status,
            "is_priority": gap_status == "gap",
            "is_mastered_in_assessment": gap_status == "strong",
        }
    return by_name


def get_curriculum_for_goal(
    connection,
    goal_id: int,
    goal_title: str,
    user_id: int,
) -> dict[str, Any]:
    """
    Assemble the full 8-stage, 65-topic Data Analyst curriculum personalized with
    the user's skill-gap assessment results and saved topic progress.
    """
    if not is_data_analyst_goal(goal_title):
        return {
            "goal_id": goal_id,
            "goal_title": goal_title,
            "is_data_analyst_goal": False,
            "supported": False,
            "stages": [],
            "summary": None,
        }

    ensure_curriculum_seeded(connection)
    skill_map = _load_goal_skill_assessments(connection, goal_id, user_id)

    stage_rows = connection.execute(
        text("""
            SELECT id, stage_number, title, description, skill_name
            FROM curriculum_stages
            WHERE goal_slug = :slug
            ORDER BY stage_number ASC
        """),
        {"slug": GOAL_SLUG},
    ).fetchall()

    topic_rows = connection.execute(
        text("""
            SELECT
                t.id,
                t.stage_id,
                t.stage_number,
                t.topic_order,
                t.global_order,
                t.slug,
                t.title,
                t.description,
                t.skill_name,
                t.estimated_minutes,
                (t.lesson_json IS NOT NULL) AS has_saved_lesson,
                COALESCE(p.status, 'not_started') AS status,
                p.quiz_score,
                p.started_at,
                p.completed_at
            FROM curriculum_topics t
            LEFT JOIN user_topic_progress p
                ON p.topic_id = t.id AND p.user_id = :user_id
            WHERE t.goal_slug = :slug
            ORDER BY t.stage_number ASC, t.topic_order ASC
        """),
        {"slug": GOAL_SLUG, "user_id": user_id},
    ).fetchall()

    topics_by_stage: dict[int, list[dict[str, Any]]] = {}
    total_topics = 0
    completed_topics = 0
    in_progress_topics = 0

    for tr in topic_rows:
        total_topics += 1
        st = tr.status or "not_started"
        if st == "completed":
            completed_topics += 1
        elif st == "in_progress":
            in_progress_topics += 1

        sk_info = skill_map.get((tr.skill_name or "").strip().lower(), {})
        is_priority = bool(sk_info.get("is_priority", False))
        is_mastered_in_assessment = bool(sk_info.get("is_mastered_in_assessment", False))

        topic_dict = {
            "id": tr.id,
            "stage_id": tr.stage_id,
            "stage_number": tr.stage_number,
            "topic_order": tr.topic_order,
            "global_order": tr.global_order,
            "slug": tr.slug,
            "title": tr.title,
            "description": tr.description,
            "skill_name": tr.skill_name,
            "estimated_minutes": tr.estimated_minutes,
            "status": st,
            "quiz_score": tr.quiz_score,
            "started_at": tr.started_at.isoformat() if tr.started_at else None,
            "completed_at": tr.completed_at.isoformat() if tr.completed_at else None,
            "has_saved_lesson": bool(tr.has_saved_lesson),
            "is_priority": is_priority and st != "completed",
            "is_mastered_in_assessment": is_mastered_in_assessment,
            "skill_level": sk_info.get("skill_level"),
            "gap_status": sk_info.get("gap_status", "not_assessed"),
        }
        topics_by_stage.setdefault(tr.stage_number, []).append(topic_dict)

    stages_out: list[dict[str, Any]] = []
    priority_skills: list[str] = []
    mastered_skills: list[str] = []
    unassessed_skills: list[str] = []

    for name_key, info in skill_map.items():
        if info["gap_status"] == "gap":
            priority_skills.append(info["skill_name"])
        elif info["gap_status"] == "strong":
            mastered_skills.append(info["skill_name"])
        else:
            unassessed_skills.append(info["skill_name"])

    for sr in stage_rows:
        s_topics = topics_by_stage.get(sr.stage_number, [])
        s_total = len(s_topics)
        s_completed = sum(1 for t in s_topics if t["status"] == "completed")
        s_in_prog = sum(1 for t in s_topics if t["status"] == "in_progress")
        s_not_started = s_total - s_completed - s_in_prog
        s_pct = round((s_completed / s_total) * 100) if s_total > 0 else 0

        sk_info = skill_map.get((sr.skill_name or "").strip().lower())
        if sk_info is None:
            sk_summary = {
                "skill_id": None,
                "skill_name": sr.skill_name,
                "skill_level": None,
                "score_percentage": None,
                "gap_status": "not_assessed",
                "is_priority": False,
                "is_mastered_in_assessment": False,
                "recommendation_badge": (
                    "Start Here (Beginner Foundation)"
                    if sr.stage_number == 1
                    else "Diagnostic Available"
                ),
            }
        else:
            if sk_info["gap_status"] == "gap":
                badge = f"Priority Focus · {sk_info['skill_level'].title()} ({round(sk_info['score_percentage'] or 0)}%)"
            elif sk_info["gap_status"] == "strong":
                badge = f"Assessment Mastered ({round(sk_info['score_percentage'] or 0)}%) · Review Anytime"
            else:
                badge = (
                    "Recommended Beginner Start"
                    if sr.stage_number == 1
                    else "Not Assessed Yet"
                )
            sk_summary = {
                "skill_id": sk_info["skill_id"],
                "skill_name": sk_info["skill_name"],
                "skill_level": sk_info["skill_level"],
                "score_percentage": sk_info["score_percentage"],
                "gap_status": sk_info["gap_status"],
                "is_priority": sk_info["is_priority"],
                "is_mastered_in_assessment": sk_info["is_mastered_in_assessment"],
                "recommendation_badge": badge,
            }

        stages_out.append(
            {
                "id": sr.id,
                "stage_number": sr.stage_number,
                "title": sr.title,
                "description": sr.description,
                "skill_name": sr.skill_name,
                "skill_assessment": sk_summary,
                "progress": {
                    "total_topics": s_total,
                    "completed_topics": s_completed,
                    "in_progress_topics": s_in_prog,
                    "not_started_topics": s_not_started,
                    "progress_percentage": s_pct,
                    "label": f"{s_completed} of {s_total} topics completed",
                },
                "topics": s_topics,
            }
        )

    # Determine beginner start topic (Stage 1, Topic 1) and personalized next recommended topic
    all_flat_topics = [t for st in stages_out for t in st["topics"]]
    beginner_start_topic = all_flat_topics[0] if all_flat_topics else None

    # Next recommended topic:
    # 1. Any topic currently 'in_progress'
    # 2. Otherwise, first uncompleted priority-gap topic
    # 3. Otherwise, first uncompleted topic in curriculum order (starting at Stage 1)
    in_prog_first = next((t for t in all_flat_topics if t["status"] == "in_progress"), None)
    priority_first = next(
        (t for t in all_flat_topics if t["is_priority"] and t["status"] != "completed"),
        None,
    )
    sequential_first = next((t for t in all_flat_topics if t["status"] != "completed"), None)
    next_recommended = in_prog_first or priority_first or sequential_first or beginner_start_topic

    not_started_topics = total_topics - completed_topics - in_progress_topics
    overall_pct = round((completed_topics / total_topics) * 100) if total_topics > 0 else 0

    return {
        "goal_id": goal_id,
        "goal_title": goal_title,
        "is_data_analyst_goal": True,
        "supported": True,
        "summary": {
            "total_stages": len(stages_out),
            "total_topics": total_topics,
            "completed_topics": completed_topics,
            "in_progress_topics": in_progress_topics,
            "not_started_topics": not_started_topics,
            "progress_percentage": overall_pct,
            "progress_label": f"{completed_topics} of {total_topics} topics completed",
            "priority_skills": priority_skills,
            "mastered_skills": mastered_skills,
            "unassessed_skills": unassessed_skills,
            "next_recommended_topic": (
                {
                    "id": next_recommended["id"],
                    "stage_number": next_recommended["stage_number"],
                    "topic_order": next_recommended["topic_order"],
                    "title": next_recommended["title"],
                    "skill_name": next_recommended["skill_name"],
                    "status": next_recommended["status"],
                    "is_priority": next_recommended["is_priority"],
                }
                if next_recommended
                else None
            ),
            "beginner_start_topic": (
                {
                    "id": beginner_start_topic["id"],
                    "stage_number": beginner_start_topic["stage_number"],
                    "topic_order": beginner_start_topic["topic_order"],
                    "title": beginner_start_topic["title"],
                    "status": beginner_start_topic["status"],
                }
                if beginner_start_topic
                else None
            ),
        },
        "stages": stages_out,
    }


def get_topic_detail(
    connection,
    goal_id: int,
    goal_title: str,
    user_id: int,
    topic_id: int,
    *,
    use_gemini_if_missing: bool = True,
    force_regenerate: bool = False,
) -> Optional[dict[str, Any]]:
    """
    Retrieve a topic, its structured lesson content, previous/next navigation links,
    and the authenticated user's progress status.
    """
    ensure_curriculum_seeded(connection)

    topic_row = connection.execute(
        text("""
            SELECT
                t.id,
                t.stage_id,
                t.stage_number,
                t.topic_order,
                t.global_order,
                t.slug,
                t.title,
                t.description,
                t.skill_name,
                t.estimated_minutes,
                t.lesson_json,
                s.title AS stage_title,
                COALESCE(p.status, 'not_started') AS status,
                p.quiz_score,
                p.started_at,
                p.completed_at
            FROM curriculum_topics t
            JOIN curriculum_stages s ON s.id = t.stage_id
            LEFT JOIN user_topic_progress p
                ON p.topic_id = t.id AND p.user_id = :user_id
            WHERE t.id = :topic_id AND t.goal_slug = :slug
        """),
        {"topic_id": topic_id, "user_id": user_id, "slug": GOAL_SLUG},
    ).fetchone()

    if topic_row is None:
        return None

    lesson = get_or_create_topic_lesson(
        connection,
        topic_row,
        use_gemini_if_missing=use_gemini_if_missing,
        force_regenerate=force_regenerate,
    )

    prev_row = connection.execute(
        text("""
            SELECT id, stage_number, topic_order, title
            FROM curriculum_topics
            WHERE goal_slug = :slug AND global_order = :prev_order
        """),
        {"slug": GOAL_SLUG, "prev_order": topic_row.global_order - 1},
    ).fetchone()

    next_row = connection.execute(
        text("""
            SELECT id, stage_number, topic_order, title
            FROM curriculum_topics
            WHERE goal_slug = :slug AND global_order = :next_order
        """),
        {"slug": GOAL_SLUG, "next_order": topic_row.global_order + 1},
    ).fetchone()

    skill_map = _load_goal_skill_assessments(connection, goal_id, user_id)
    sk_info = skill_map.get((topic_row.skill_name or "").strip().lower(), {})

    return {
        "goal_id": goal_id,
        "goal_title": goal_title,
        "topic": {
            "id": topic_row.id,
            "stage_id": topic_row.stage_id,
            "stage_number": topic_row.stage_number,
            "stage_title": topic_row.stage_title,
            "topic_order": topic_row.topic_order,
            "global_order": topic_row.global_order,
            "slug": topic_row.slug,
            "title": topic_row.title,
            "description": topic_row.description,
            "skill_name": topic_row.skill_name,
            "estimated_minutes": topic_row.estimated_minutes,
            "status": topic_row.status,
            "quiz_score": topic_row.quiz_score,
            "started_at": topic_row.started_at.isoformat() if topic_row.started_at else None,
            "completed_at": topic_row.completed_at.isoformat() if topic_row.completed_at else None,
            "is_priority": bool(sk_info.get("is_priority", False))
            and topic_row.status != "completed",
            "is_mastered_in_assessment": bool(sk_info.get("is_mastered_in_assessment", False)),
            "skill_level": sk_info.get("skill_level"),
            "gap_status": sk_info.get("gap_status", "not_assessed"),
        },
        "lesson": lesson,
        "previous_topic": (
            {
                "id": prev_row.id,
                "stage_number": prev_row.stage_number,
                "topic_order": prev_row.topic_order,
                "title": prev_row.title,
            }
            if prev_row
            else None
        ),
        "next_topic": (
            {
                "id": next_row.id,
                "stage_number": next_row.stage_number,
                "topic_order": next_row.topic_order,
                "title": next_row.title,
            }
            if next_row
            else None
        ),
    }


def update_user_topic_progress(
    connection,
    user_id: int,
    topic_id: int,
    status: str,
    quiz_score: Optional[int] = None,
) -> Optional[dict[str, Any]]:
    """
    Persist a user's progress on `topic_id` ('not_started', 'in_progress', 'completed')
    and return updated topic + stage + overall progress counts.
    """
    ensure_curriculum_seeded(connection)

    topic_row = connection.execute(
        text("""
            SELECT id, stage_id, stage_number, topic_order, title
            FROM curriculum_topics
            WHERE id = :topic_id AND goal_slug = :slug
        """),
        {"topic_id": topic_id, "slug": GOAL_SLUG},
    ).fetchone()

    if topic_row is None:
        return None

    clean_status = status.strip().lower()
    if clean_status not in VALID_PROGRESS_STATUSES:
        raise ValueError(f"status must be one of {sorted(VALID_PROGRESS_STATUSES)}")

    is_started = clean_status in ("in_progress", "completed")
    is_completed = clean_status == "completed"

    connection.execute(
        text("""
            INSERT INTO user_topic_progress (
                user_id, topic_id, status, quiz_score, started_at, completed_at, updated_at
            )
            VALUES (
                :user_id,
                :topic_id,
                :status,
                :quiz_score,
                CASE WHEN :is_started THEN CURRENT_TIMESTAMP ELSE NULL END,
                CASE WHEN :is_completed THEN CURRENT_TIMESTAMP ELSE NULL END,
                CURRENT_TIMESTAMP
            )
            ON CONFLICT (user_id, topic_id) DO UPDATE SET
                status = EXCLUDED.status,
                quiz_score = COALESCE(EXCLUDED.quiz_score, user_topic_progress.quiz_score),
                started_at = CASE
                    WHEN EXCLUDED.status = 'not_started' THEN NULL
                    ELSE COALESCE(user_topic_progress.started_at, CURRENT_TIMESTAMP)
                END,
                completed_at = CASE
                    WHEN EXCLUDED.status = 'completed' THEN COALESCE(user_topic_progress.completed_at, CURRENT_TIMESTAMP)
                    ELSE NULL
                END,
                updated_at = CURRENT_TIMESTAMP
        """),
        {
            "user_id": user_id,
            "topic_id": topic_id,
            "status": clean_status,
            "quiz_score": quiz_score,
            "is_started": is_started,
            "is_completed": is_completed,
        },
    )
    connection.commit()

    saved_row = connection.execute(
        text("""
            SELECT status, quiz_score, started_at, completed_at, updated_at
            FROM user_topic_progress
            WHERE user_id = :user_id AND topic_id = :topic_id
        """),
        {"user_id": user_id, "topic_id": topic_id},
    ).fetchone()

    stage_counts = connection.execute(
        text("""
            SELECT
                COUNT(*) AS total_topics,
                COUNT(*) FILTER (WHERE COALESCE(p.status, 'not_started') = 'completed') AS completed_topics,
                COUNT(*) FILTER (WHERE COALESCE(p.status, 'not_started') = 'in_progress') AS in_progress_topics
            FROM curriculum_topics t
            LEFT JOIN user_topic_progress p
                ON p.topic_id = t.id AND p.user_id = :user_id
            WHERE t.stage_id = :stage_id
        """),
        {"user_id": user_id, "stage_id": topic_row.stage_id},
    ).fetchone()

    overall_counts = connection.execute(
        text("""
            SELECT
                COUNT(*) AS total_topics,
                COUNT(*) FILTER (WHERE COALESCE(p.status, 'not_started') = 'completed') AS completed_topics,
                COUNT(*) FILTER (WHERE COALESCE(p.status, 'not_started') = 'in_progress') AS in_progress_topics
            FROM curriculum_topics t
            LEFT JOIN user_topic_progress p
                ON p.topic_id = t.id AND p.user_id = :user_id
            WHERE t.goal_slug = :slug
        """),
        {"user_id": user_id, "slug": GOAL_SLUG},
    ).fetchone()

    s_total = stage_counts.total_topics or 0
    s_comp = stage_counts.completed_topics or 0
    o_total = overall_counts.total_topics or 0
    o_comp = overall_counts.completed_topics or 0

    return {
        "topic_id": topic_row.id,
        "stage_number": topic_row.stage_number,
        "topic_order": topic_row.topic_order,
        "title": topic_row.title,
        "status": saved_row.status if saved_row else clean_status,
        "quiz_score": saved_row.quiz_score if saved_row else quiz_score,
        "started_at": saved_row.started_at.isoformat() if saved_row and saved_row.started_at else None,
        "completed_at": saved_row.completed_at.isoformat() if saved_row and saved_row.completed_at else None,
        "stage_progress": {
            "stage_number": topic_row.stage_number,
            "total_topics": s_total,
            "completed_topics": s_comp,
            "in_progress_topics": stage_counts.in_progress_topics or 0,
            "progress_percentage": round((s_comp / s_total) * 100) if s_total > 0 else 0,
            "label": f"{s_comp} of {s_total} topics completed",
        },
        "overall_progress": {
            "total_topics": o_total,
            "completed_topics": o_comp,
            "in_progress_topics": overall_counts.in_progress_topics or 0,
            "progress_percentage": round((o_comp / o_total) * 100) if o_total > 0 else 0,
            "label": f"{o_comp} of {o_total} topics completed",
        },
    }
