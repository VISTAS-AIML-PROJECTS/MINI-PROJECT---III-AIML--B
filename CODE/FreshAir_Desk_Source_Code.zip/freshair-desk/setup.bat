@echo off
setlocal EnableExtensions
title FreshAir Desk - Firmware Upload

echo.
echo ============================================================
echo   FreshAir Desk - Firmware Upload
echo ============================================================
echo.

set "ARDUINO_CLI_DIR=%LOCALAPPDATA%\Programs\Arduino IDE\resources\app\lib\backend\resources"
if not exist "%ARDUINO_CLI_DIR%\arduino-cli.exe" set "ARDUINO_CLI_DIR=%LOCALAPPDATA%\Programs\arduino-ide\resources\app\lib\backend\resources"
if not exist "%ARDUINO_CLI_DIR%\arduino-cli.exe" (
    echo [ERROR] Arduino IDE command-line tools were not found.
    echo Open Arduino IDE once, then run this file again.
    goto :failed
)
set "ARDUINO_CLI=%ARDUINO_CLI_DIR%\arduino-cli.exe"

echo [1/4] Checking ESP32 board package...
"%ARDUINO_CLI%" core list 2>nul | findstr /I /C:"esp32:esp32" >nul
if errorlevel 1 (
    echo Installing the ESP32 board package. This needs internet access...
    "%ARDUINO_CLI%" core update-index
    if errorlevel 1 goto :failed
    "%ARDUINO_CLI%" core install esp32:esp32
    if errorlevel 1 goto :failed
)

echo [2/4] Checking sensor libraries...
"%ARDUINO_CLI%" lib list 2>nul | findstr /I /C:"BH1750" >nul
if errorlevel 1 (
    "%ARDUINO_CLI%" lib install "BH1750"
    if errorlevel 1 goto :failed
)
"%ARDUINO_CLI%" lib list 2>nul | findstr /I /C:"DHT sensor library" >nul
if errorlevel 1 (
    "%ARDUINO_CLI%" lib install "DHT sensor library"
    if errorlevel 1 goto :failed
)
"%ARDUINO_CLI%" lib list 2>nul | findstr /I /C:"Adafruit Unified Sensor" >nul
if errorlevel 1 (
    "%ARDUINO_CLI%" lib install "Adafruit Unified Sensor"
    if errorlevel 1 goto :failed
)

echo [3/4] Finding the ESP32 USB connection...
set "ESP_PORT="
set "PORT_LIST=%TEMP%\freshair_board_list.txt"
set "PORT_MATCH=%TEMP%\freshair_board_port.txt"
"%ARDUINO_CLI%" board list > "%PORT_LIST%" 2>&1
type "%PORT_LIST%"
findstr /R /I /C:"^COM[0-9][0-9]*" "%PORT_LIST%" > "%PORT_MATCH%"
for /f "usebackq tokens=1" %%P in ("%PORT_MATCH%") do if not defined ESP_PORT set "ESP_PORT=%%P"
if not defined ESP_PORT (
    echo [ERROR] No COM port was found.
    echo Check that the ESP32 is connected by USB, then run this file again.
    goto :failed
)
echo ESP32 connection: %ESP_PORT%

echo [4/4] Building and uploading the dashboard program...
"%ARDUINO_CLI%" compile --fqbn esp32:esp32:esp32 "%~dp0firmware\03_dashboard"
if errorlevel 1 (
    echo.
    echo [ERROR] The program could not be built, so nothing was uploaded.
    echo Read the error shown above. If it says Windows could not start the compiler,
    echo restart the laptop and run this file once more.
    goto :failed
)

"%ARDUINO_CLI%" upload --fqbn esp32:esp32:esp32 --port %ESP_PORT% "%~dp0firmware\03_dashboard"
if errorlevel 1 (
    echo.
    echo [ERROR] The program built, but the upload failed.
    echo Close Arduino Serial Monitor if it is open, then try again.
    goto :failed
)

echo.
echo Upload completed. The ESP32 should join the iPhone hotspot.
echo Keep the laptop connected to the same hotspot and start ai_server\start.bat for AI insights.
echo The dashboard address is shown in the ESP32 Serial Monitor.
goto :done

:failed
echo.
echo Upload did not complete. No log file is needed.
:done
echo.
pause
endlocal
