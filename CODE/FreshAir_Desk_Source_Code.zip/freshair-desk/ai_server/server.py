import os, sys, time, json, threading, subprocess, requests
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
from datetime import datetime
from flask import Flask, jsonify
from flask_cors import CORS
from dotenv import load_dotenv
from groq import Groq

load_dotenv()

api_key = [SET_LOCALLY]
if not api_key:
    print("[ERROR] GROQ_API_KEY not set. Add it to ai_server/.env")
    exit(1)

client = Groq(api_key=api_key)

MODEL      = "qwen/qwen3.8-27b"
ESP32_URLS = ["http://172.20.10.5/json"]
POLL_EVERY = 30   # seconds between automatic refreshes (Groq free: 14400 req/day)

app = Flask(__name__)
CORS(app)

cache = {
    "summary":      "Starting up — first reading in a moment...",
    "suggestions":  [],
    "score":        None,
    "focus_impact": "",
    "updated":      0,
    "error":        None
}
lock          = threading.Lock()
last_overall  = None   # track last known status for change detection


def now():
    return datetime.now().strftime("%H:%M:%S")


def build_prompt(data):
    return f"""You are an indoor desk environment assistant. Analyse the readings below and respond with ONLY a JSON object — no markdown, no code fences.

Sensor readings right now:
- Temperature : {data.get('temp',  'N/A')} degC  (ideal 21-26 degC)
- Humidity    : {data.get('hum',   'N/A')} %     (ideal 40-60 %)
- Light       : {data.get('lux',   'N/A')} lux   (ideal 6 lux; <4 = too dark, >8 = too bright)
- Air quality : {data.get('ratio', 'N/A')} RS/R0 (clean air ~3.6; lower = more pollutants)
- Overall     : {data.get('overall', 'N/A')}

Return exactly this JSON:
{{
  "summary": "<2-3 sentences about current environment>",
  "suggestions": ["<action 1>", "<action 2>"],
  "score": <integer 1-10>,
  "focus_impact": "<one sentence on how this affects focus/productivity>"
}}"""


def parse_model_json(text):
    text = text.strip()
    if "```" in text:
        for part in text.split("```"):
            part = part.strip().lstrip("json").strip()
            try:
                return json.loads(part)
            except Exception:
                continue
    return json.loads(text)


def call_ai(data):
    prompt = build_prompt(data)
    for attempt in range(3):
        try:
            resp = client.chat.completions.create(
                model=MODEL,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.3,
                max_tokens=[SET_LOCALLY]
            )
            parsed = parse_model_json(resp.choices[0].message.content)
            print(f"[{now()}] Groq OK (attempt {attempt+1})", flush=True)
            return parsed
        except Exception as e:
            err_str = str(e)
            if "429" in err_str or "rate_limit" in err_str.lower():
                wait = 10 * (attempt + 1)
                print(f"[{now()}] Rate limited, waiting {wait}s...", flush=True)
                time.sleep(wait)
            elif "503" in err_str or "502" in err_str:
                wait = 5 * (attempt + 1)
                print(f"[{now()}] Groq overloaded, waiting {wait}s...", flush=True)
                time.sleep(wait)
            else:
                print(f"[{now()}] Groq error: {err_str[:120]}", flush=True)
                raise
    raise Exception("Groq failed after 3 attempts")


def fetch_and_update():
    global last_overall

    # Reach ESP32
    data = None
    for url in ESP32_URLS:
        try:
            resp = requests.get(url, timeout=5)
            resp.raise_for_status()
            data = resp.json()
            break
        except Exception:
            continue
    if data is None:
        msg = "ESP32 not reachable — check it is powered and on the same hotspot."
        print(f"[{now()}] {msg}")
        with lock:
            cache["error"] = msg
        return

    # Check if overall status changed — if so, force AI refresh regardless of timer
    current_overall = data.get("overall")
    changed = (current_overall != last_overall)
    if changed and last_overall is not None:
        print(f"[{now()}] Status changed: {last_overall} -> {current_overall}. Refreshing AI suggestion...")
    last_overall = current_overall

    # Request AI recommendations from Groq
    try:
        parsed = call_ai(data)
        parsed["updated"] = int(time.time())
        parsed["error"]   = None
        with lock:
            cache.update(parsed)
        print(f"[{now()}] Suggestion updated. Score: {parsed.get('score')}/10 | {current_overall}")
    except Exception as e:
        print(f"[{now()}] Groq recommendation request failed: {e}")
        with lock:
            cache["error"] = "AI temporarily unavailable — will retry shortly."


def background_poller():
    global last_overall
    while True:
        time.sleep(POLL_EVERY)
        # Also force a refresh if status changed (poll ESP32 quickly to detect change)
        try:
            for url in ESP32_URLS:
                try:
                    data = requests.get(url, timeout=4).json()
                    current = data.get("overall")
                    if current != last_overall:
                        fetch_and_update()
                        break
                    break
                except Exception:
                    continue
            else:
                fetch_and_update()
        except Exception:
            fetch_and_update()


@app.route("/suggest")
def get_suggestion():
    with lock:
        return jsonify(cache)


@app.route("/suggest/refresh", methods=["POST"])
def refresh_now():
    # Fire in background — don't block the HTTP response
    threading.Thread(target=fetch_and_update, daemon=True).start()
    with lock:
        resp = dict(cache)
    resp["refreshing"] = True
    return jsonify(resp)


if __name__ == "__main__":
    all_ips = []
    try:
        out = subprocess.check_output("ipconfig", shell=True).decode(errors="ignore")
        for line in out.splitlines():
            if "IPv4" in line:
                ip = line.split(":")[-1].strip()
                if not ip.startswith("127."):
                    all_ips.append(ip)
    except Exception:
        pass

    # First fetch immediately in background
    threading.Thread(target=fetch_and_update, daemon=True).start()
    threading.Thread(target=background_poller, daemon=True).start()

    print()
    print("=" * 54)
    print("  FreshAir Desk -- AI Server")
    print("=" * 54)
    print("  Detected IPs:")
    for ip in all_ips:
        label = ""
        if ip.startswith("172.20.10."):   label = "  << iPhone hotspot (AI server network)"
        print(f"    {ip}{label}")
    print()
    print(f"  Model: {MODEL}  |  Poll every {POLL_EVERY}s")
    print("=" * 54)
    print()

    app.run(host="0.0.0.0", port=5000, debug=False)
