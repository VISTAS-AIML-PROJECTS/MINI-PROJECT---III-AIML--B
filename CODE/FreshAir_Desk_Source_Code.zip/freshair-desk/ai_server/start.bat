@echo off
setlocal EnableExtensions
title FreshAir Desk AI Server
cd /d "%~dp0"

echo.
echo ================================================
echo   FreshAir Desk - AI Server
echo ================================================
echo.

if not exist "%~dp0.env" goto noenv

set "PYTHON=%USERPROFILE%\anaconda3\python.exe"
if exist "%PYTHON%" goto pythonfound

set "PYTHON=%USERPROFILE%\miniconda3\python.exe"
if exist "%PYTHON%" goto pythonfound

set "PYTHON=%LOCALAPPDATA%\Programs\Python\Python314\python.exe"
if exist "%PYTHON%" goto pythonfound

set "PYTHON=%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
if exist "%PYTHON%" goto pythonfound

set "PYTHON=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if exist "%PYTHON%" goto pythonfound

set "PYTHON=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
if exist "%PYTHON%" goto pythonfound

echo [ERROR] Python was not found. Install Anaconda or Python, then try again.
goto finish

:pythonfound
echo [OK] Using Python:
echo %PYTHON%
"%PYTHON%" --version
if errorlevel 1 goto pythonerror

echo.
echo [SETUP] Installing required packages. Please leave this window open...
"%PYTHON%" -m pip install -r "%~dp0requirements.txt"
if errorlevel 1 goto piperror

echo.
echo [OK] Packages are ready. Starting the AI server...
echo Keep this window open while using FreshAir Desk.
echo.
"%PYTHON%" "%~dp0server.py"
echo.
echo The AI server has stopped.
goto finish

:noenv
echo [ERROR] The AI settings file is missing:
echo %~dp0.env
echo Contact me before changing or copying API keys.
goto finish

:pythonerror
echo.
echo [ERROR] Python could not start. The AI server did not start.
goto finish

:piperror
echo.
echo [ERROR] Required packages could not be installed. Check internet access.
goto finish

:finish
echo.
pause
endlocal
