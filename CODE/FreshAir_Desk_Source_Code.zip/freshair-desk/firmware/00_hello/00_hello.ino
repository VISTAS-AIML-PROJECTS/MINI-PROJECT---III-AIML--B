// FreshAir Desk — ESP32 bring-up sketch
// Verifies board boots, serial works, and uptime increments correctly.

#define BAUD_RATE     115200
#define INTERVAL_MS   2000

unsigned long last_print = 0;

void setup() {
  Serial.begin(BAUD_RATE);
  delay(500);
  Serial.println("=== FreshAir Desk ESP32 bring-up ===");
  Serial.print("Board: ");
  Serial.println(ARDUINO_BOARD);
  Serial.print("CPU freq: ");
  Serial.print(ESP.getCpuFreqMHz());
  Serial.println(" MHz");
  Serial.println("Serial OK. Printing uptime every 2 s.");
  Serial.println("=====================================");
}

void loop() {
  unsigned long now = millis();
  if (now - last_print >= INTERVAL_MS) {
    last_print = now;
    Serial.print("uptime_ms=");
    Serial.print(now);
    Serial.print("  uptime_s=");
    Serial.println(now / 1000);
  }
}
