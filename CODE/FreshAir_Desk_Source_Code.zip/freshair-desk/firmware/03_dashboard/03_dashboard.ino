// FreshAir Desk — Milestone 5+6: rule-based classifier + web dashboard
// DHT22 OUT→19 | BH1750 SDA→21 SCL→22 | MQ135 A0→34 D0→32
// LED RED→25   | LED GREEN→33

#include <Wire.h>
#include <BH1750.h>
#include <DHT.h>
#include <WiFi.h>
#include <WebServer.h>

// ── Wi-Fi — iPhone hotspot only ───────────────────────────────────────────
// Network 1: iPhone hotspot
const char* SSID1     = "[SET_LOCALLY]";
const char* PASSWORD1 = "[SET_LOCALLY]";
IPAddress STATIC_IP1(172, 20, 10,   5);
IPAddress GATEWAY1  (172, 20, 10,   1);
IPAddress SUBNET1   (255, 255, 255, 0);
IPAddress DNS1      (172, 20, 10,   1);
const char* AI_URL1 = "http://172.20.10.2:5000";


// Set at runtime by connectWiFi()
String g_ai_server_url = "";

// ── Pins ──────────────────────────────────────────────────────────────────
#define DHT_PIN    19
#define DHT_TYPE   DHT22
#define MQ135_AOUT 34
#define MQ135_DOUT 32
#define LED_RED    25
#define LED_GREEN  33

// ── MQ135 calibration ─────────────────────────────────────────────────────
#define MQ135_RL   10000.0
#define MQ135_VCC  3.3
#define MQ135_R0   12741.0

// ── Error codes ───────────────────────────────────────────────────────────
// Printed to Serial whenever the fault occurs. Each includes a fix hint.
#define EC_DHT_TIMEOUT  "[E001] DHT22 read timeout    — fix: OUT→GPIO19, 10K pull-up on data line, 3V3+GND supply."
#define EC_BH_INIT      "[E002] BH1750 I2C not found  — fix: SDA→GPIO21, SCL→GPIO22, 3V3+GND supply, address 0x23."
#define EC_BH_READ      "[E003] BH1750 read failed    — fix: sensor lost I2C comms. Power-cycle the board."
#define EC_MQ_SAT       "[E004] MQ135 voltage OOB     — fix: A0→GPIO34, power from 3V3 (not 5V), allow ≥1 min warm-up."
#define EC_WIFI_TIMEOUT "[E005] WiFi connect timeout  — fix: hotspot name \"iPhone\", password correct, phone in range."
#define EC_WIFI_LOST    "[E006] WiFi connection dropped — reconnecting..."
#define EC_WIFI_FAIL    "[E007] WiFi reconnect failed — dashboard offline, serial readings continue."

// ── Classifier levels ─────────────────────────────────────────────────────
enum Level { GOOD, ATTENTION, POOR, SENSOR_ERR };

// Thresholds
#define TEMP_GOOD_LO   21.0
#define TEMP_GOOD_HI   26.0
#define TEMP_ATTN_LO   18.0
#define TEMP_ATTN_HI   30.0
#define HUM_GOOD_LO    40.0
#define HUM_GOOD_HI    60.0
#define HUM_ATTN_LO    30.0
#define HUM_ATTN_HI    65.0
#define LUX_DARK       4.0   // below this = dark (Poor)
#define LUX_DIM        6.0   // 4-5 = better lighting needed (Attention)
#define LUX_IDEAL      7.0   // 6 = good; 7-8 = bright (Attention)
#define LUX_BRIGHT     8.0   // above this = too bright (Poor)
#define AIR_GOOD       3.0
#define AIR_ATTN       2.0

// ── History ───────────────────────────────────────────────────────────────
#define HISTORY_SIZE 60
struct Reading {
  float temp, hum, lux, ratio;
  Level overall;
  unsigned long ts;
};
Reading history[HISTORY_SIZE];
int histHead = 0, histCount = 0;

// ── Globals ───────────────────────────────────────────────────────────────
DHT       dht(DHT_PIN, DHT_TYPE);
BH1750    lightMeter;
WebServer server(80);

float g_temp  = 0, g_hum = 0, g_lux = 0, g_ratio = 0;
bool  g_dht_ok = false, g_bh_ok = false, g_mq_ok = false;
bool  g_bh_init_ok = false;
bool  g_wifi_ok = false;

Level g_lvl_temp, g_lvl_hum, g_lvl_lux, g_lvl_air, g_overall;

const char* g_tip_temp = "";
const char* g_tip_hum  = "";
const char* g_tip_lux  = "";
const char* g_tip_air  = "";

unsigned long lastRead = 0, lastHistory = 0, lastWifiCheck = 0;

// ── Classifier ────────────────────────────────────────────────────────────
Level classifyTemp(float t) {
  if (t >= TEMP_GOOD_LO && t <= TEMP_GOOD_HI) return GOOD;
  if (t >= TEMP_ATTN_LO && t <= TEMP_ATTN_HI) return ATTENTION;
  return POOR;
}
Level classifyHum(float h) {
  if (h >= HUM_GOOD_LO && h <= HUM_GOOD_HI) return GOOD;
  if (h >= HUM_ATTN_LO && h <= HUM_ATTN_HI) return ATTENTION;
  return POOR;
}
Level classifyLux(float l) {
  if (l < LUX_DARK)   return POOR;        // < 4: dark
  if (l < LUX_DIM)    return ATTENTION;   // 4–5: better lighting needed
  if (l < LUX_IDEAL)  return GOOD;        // 6: ideal
  if (l <= LUX_BRIGHT) return ATTENTION;  // 7–8: bright
  return POOR;                            // > 8: too bright
}
Level classifyAir(float r) {
  if (r >= AIR_GOOD)  return GOOD;
  if (r >= AIR_ATTN)  return ATTENTION;
  return POOR;
}

Level worstOf(Level a, Level b) { return (a > b) ? a : b; }

const char* tipTemp(Level l, float t) {
  if (l == GOOD)          return "Comfortable temperature for desk work.";
  if (t > TEMP_ATTN_HI)  return "Too hot — open a window or turn on a fan.";
  if (t < TEMP_ATTN_LO)  return "Too cold — close windows and warm the room.";
  if (t > TEMP_GOOD_HI)  return "Slightly warm — consider some ventilation.";
  return "Slightly cool — a warm drink or light layer may help.";
}
const char* tipHum(Level l, float h) {
  if (l == GOOD)          return "Humidity is in the ideal comfort range.";
  if (h > HUM_ATTN_HI)   return "Very humid — open a window or use a dehumidifier.";
  if (h < HUM_ATTN_LO)   return "Very dry — place a water bowl near your desk.";
  if (h > HUM_GOOD_HI)   return "Slightly humid — a bit of ventilation will help.";
  return "Slightly dry — stay hydrated and consider a humidifier.";
}
const char* tipLux(Level l, float lux) {
  if (l == GOOD)      return "Good lighting for focused desk work.";
  if (l == ATTENTION) return lux < LUX_DIM
                             ? "Better lighting needed — turn on your desk lamp."
                             : "Bright — consider dimming the lights slightly.";
  return lux > LUX_BRIGHT
         ? "Too bright — close the blinds or dim overhead lights."
         : "Too dark — switch on your desk lamp.";
}
const char* tipAir(Level l) {
  if (l == GOOD)      return "Air quality looks clean and fresh.";
  if (l == ATTENTION) return "Air getting stale — open a window soon.";
  return "Poor air — open a window or step outside briefly.";
}

// ── LED feedback ──────────────────────────────────────────────────────────
void blink(int pin, int times, int ms) {
  for (int i = 0; i < times; i++) {
    digitalWrite(pin, HIGH); delay(ms);
    digitalWrite(pin, LOW);  delay(ms);
  }
}
void updateLED() {
  digitalWrite(LED_RED,   LOW);
  digitalWrite(LED_GREEN, LOW);
  if      (g_overall == GOOD)      blink(LED_GREEN, 2, 120);
  else if (g_overall == ATTENTION) blink(LED_RED,   2, 300);
  else                             blink(LED_RED,   4, 100);
}

// ── Sensor read + classify ────────────────────────────────────────────────
void readAndClassify() {
  g_temp = dht.readTemperature();
  g_hum  = dht.readHumidity();
  g_dht_ok = !isnan(g_temp) && !isnan(g_hum);
  if (!g_dht_ok) Serial.println(EC_DHT_TIMEOUT);

  if (g_bh_init_ok) {
    g_lux   = lightMeter.readLightLevel();
    g_bh_ok = g_lux >= 0;
    if (!g_bh_ok) Serial.println(EC_BH_READ);
  } else {
    g_bh_ok = false;
  }

  int   raw = analogRead(MQ135_AOUT);
  float vrl = raw * (MQ135_VCC / 4095.0);
  g_mq_ok   = (vrl > 0.001 && vrl < MQ135_VCC - 0.01);
  if (g_mq_ok) {
    g_ratio = ((MQ135_VCC - vrl) / vrl) * MQ135_RL / MQ135_R0;
  } else {
    g_ratio = -1;
    Serial.println(EC_MQ_SAT);
  }

  g_lvl_temp = g_dht_ok ? classifyTemp(g_temp)  : SENSOR_ERR;
  g_lvl_hum  = g_dht_ok ? classifyHum(g_hum)    : SENSOR_ERR;
  g_lvl_lux  = g_bh_ok  ? classifyLux(g_lux)    : SENSOR_ERR;
  g_lvl_air  = g_mq_ok  ? classifyAir(g_ratio)  : SENSOR_ERR;

  g_tip_temp = g_dht_ok ? tipTemp(g_lvl_temp, g_temp) : "E001 — check DHT22 wiring on GPIO19.";
  g_tip_hum  = g_dht_ok ? tipHum(g_lvl_hum,  g_hum)  : "E001 — check DHT22 wiring on GPIO19.";
  g_tip_lux  = g_bh_ok  ? tipLux(g_lvl_lux, g_lux)    : "E002/E003 — check BH1750 on GPIO21/22.";
  g_tip_air  = g_mq_ok  ? tipAir(g_lvl_air)           : "E004 — check MQ135 on GPIO34, 3V3 supply.";

  g_overall = GOOD;
  if (g_lvl_temp != SENSOR_ERR) g_overall = worstOf(g_overall, g_lvl_temp);
  if (g_lvl_hum  != SENSOR_ERR) g_overall = worstOf(g_overall, g_lvl_hum);
  if (g_lvl_lux  != SENSOR_ERR) g_overall = worstOf(g_overall, g_lvl_lux);
  if (g_lvl_air  != SENSOR_ERR) g_overall = worstOf(g_overall, g_lvl_air);
  if ((g_lvl_temp == SENSOR_ERR || g_lvl_hum == SENSOR_ERR ||
       g_lvl_lux  == SENSOR_ERR || g_lvl_air  == SENSOR_ERR) && g_overall == GOOD)
    g_overall = ATTENTION;

  updateLED();
}

void pushHistory() {
  Reading r;
  r.temp    = g_dht_ok ? g_temp  : -99;
  r.hum     = g_dht_ok ? g_hum   : -99;
  r.lux     = g_bh_ok  ? g_lux   : -1;
  r.ratio   = g_mq_ok  ? g_ratio : -1;
  r.overall = g_overall;
  r.ts      = millis() / 1000;
  history[histHead] = r;
  histHead = (histHead + 1) % HISTORY_SIZE;
  if (histCount < HISTORY_SIZE) histCount++;
}

// ── HTML helpers ──────────────────────────────────────────────────────────
String levelClass(Level l) {
  if (l == GOOD)      return "good";
  if (l == ATTENTION) return "attn";
  return "poor";
}
String levelLabel(Level l) {
  if (l == GOOD)      return "Good";
  if (l == ATTENTION) return "Attention";
  if (l == POOR)      return "Poor";
  return "Error";
}
String overallBadge() {
  if (g_overall == GOOD)
    return "<span class='badge badge-good'>&#10003;&nbsp; All Good</span>";
  if (g_overall == ATTENTION)
    return "<span class='badge badge-attn'>&#9888;&nbsp; Attention Needed</span>";
  return "<span class='badge badge-poor'>&#9888;&nbsp; Poor Conditions</span>";
}
String histPill(Level l) {
  if (l == GOOD)
    return "<span class='pill pill-good'><span class='dot dot-good'></span>Good</span>";
  if (l == ATTENTION)
    return "<span class='pill pill-attn'><span class='dot dot-attn'></span>Attention</span>";
  return "<span class='pill pill-poor'><span class='dot dot-poor'></span>Poor</span>";
}

// ── Dashboard HTML ────────────────────────────────────────────────────────
void handleRoot() {
  String html = R"rawhtml(<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="refresh" content="5">
<title>FreshAir Desk</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#f0f4f8;color:#1a202c;min-height:100vh}
.topbar{background:#fff;border-bottom:1px solid #e2e8f0;padding:16px 24px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px}
.topbar-title{font-size:1.1rem;font-weight:700;color:#1a202c}
.topbar-sub{font-size:.73rem;color:#94a3b8;margin-top:2px}
.badge{padding:6px 16px;border-radius:999px;font-size:.78rem;font-weight:600;letter-spacing:.3px}
.badge-good{background:#dcfce7;color:#16a34a}
.badge-attn{background:#fef9c3;color:#a16207}
.badge-poor{background:#fee2e2;color:#dc2626}
.main{max-width:960px;margin:0 auto;padding:24px 16px}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:14px;margin-bottom:28px}
.card{background:#fff;border-radius:16px;padding:22px 18px 18px;box-shadow:0 1px 3px rgba(0,0,0,.06);border:1px solid #e2e8f0;position:relative;overflow:hidden}
.card::before{content:'';position:absolute;top:0;left:0;right:0;height:4px;border-radius:16px 16px 0 0}
.card-good::before{background:linear-gradient(90deg,#34d399,#10b981)}
.card-attn::before{background:linear-gradient(90deg,#fcd34d,#f59e0b)}
.card-poor::before{background:linear-gradient(90deg,#f87171,#ef4444)}
.card-icon{font-size:1.4rem;margin-bottom:8px}
.card-label{font-size:.68rem;font-weight:700;text-transform:uppercase;letter-spacing:1.2px;color:#94a3b8;margin-bottom:4px}
.card-value{font-size:2.4rem;font-weight:800;line-height:1;margin-bottom:2px}
.val-good{color:#059669}.val-attn{color:#d97706}.val-poor{color:#dc2626}.val-err{color:#94a3b8}
.card-unit{font-size:.75rem;color:#94a3b8;margin-bottom:10px}
.card-level{display:inline-block;font-size:.68rem;font-weight:700;padding:2px 9px;border-radius:999px;margin-bottom:8px;letter-spacing:.3px}
.lv-good{background:#dcfce7;color:#16a34a}
.lv-attn{background:#fef9c3;color:#a16207}
.lv-poor{background:#fee2e2;color:#dc2626}
.lv-err{background:#f1f5f9;color:#64748b}
.err-code{font-size:.68rem;font-family:monospace;color:#dc2626;font-weight:700;margin-bottom:4px}
.card-tip{font-size:.74rem;color:#64748b;line-height:1.45;border-top:1px solid #f1f5f9;padding-top:8px;margin-top:2px}
.section-title{font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#94a3b8;margin-bottom:10px}
.table-wrap{background:#fff;border-radius:16px;box-shadow:0 1px 3px rgba(0,0,0,.06);border:1px solid #e2e8f0;overflow:hidden}
table{width:100%;border-collapse:collapse;font-size:.81rem}
thead{background:#f8fafc}
th{text-align:left;padding:10px 14px;color:#64748b;font-weight:600;font-size:.7rem;text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid #e8edf3}
td{padding:9px 14px;border-bottom:1px solid #f1f5f9;color:#374151}
tr:last-child td{border-bottom:none}
tr:hover td{background:#fafbfc}
.pill{display:inline-flex;align-items:center;gap:4px;padding:2px 9px;border-radius:999px;font-size:.7rem;font-weight:600}
.pill-good{background:#dcfce7;color:#16a34a}
.pill-attn{background:#fef9c3;color:#a16207}
.pill-poor{background:#fee2e2;color:#dc2626}
.dot{width:6px;height:6px;border-radius:50%;display:inline-block;flex-shrink:0}
.dot-good{background:#22c55e}.dot-attn{background:#eab308}.dot-poor{background:#ef4444}
footer{text-align:center;font-size:.7rem;color:#94a3b8;margin-top:18px;padding-bottom:24px}
.ai-wrap{background:#fff;border-radius:16px;padding:20px 22px;box-shadow:0 1px 3px rgba(0,0,0,.06);border:1px solid #e2e8f0;margin-bottom:28px;border-top:4px solid #6366f1}
.ai-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;flex-wrap:wrap;gap:8px}
.ai-title{font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:1.2px;color:#6366f1}
.ai-score{width:50px;height:50px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.3rem;font-weight:800;flex-shrink:0}
.sc-good{background:#dcfce7;color:#16a34a}.sc-attn{background:#fef9c3;color:#a16207}.sc-poor{background:#fee2e2;color:#dc2626}.sc-nil{background:#f1f5f9;color:#94a3b8}
.ai-summary{font-size:.85rem;color:#374151;line-height:1.65;margin-bottom:12px}
.ai-list{list-style:none;margin-bottom:12px}
.ai-list li{font-size:.81rem;color:#4b5563;padding:3px 0 3px 20px;position:relative;line-height:1.45}
.ai-list li::before{content:'→';position:absolute;left:0;color:#6366f1;font-weight:700}
.ai-focus{font-size:.77rem;color:#6366f1;font-style:italic;padding:7px 12px;background:#f0f0ff;border-radius:8px;margin-bottom:12px}
.ai-footer{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px}
.ai-updated{font-size:.67rem;color:#94a3b8}
.ai-btn{background:#6366f1;color:#fff;border:none;padding:6px 16px;border-radius:8px;font-size:.74rem;font-weight:600;cursor:pointer;transition:background .15s}
.ai-btn:hover{background:#4f46e5}.ai-btn:disabled{background:#a5b4fc;cursor:not-allowed}
.ai-offline{font-size:.8rem;color:#94a3b8;font-style:italic;padding:8px 0}
</style>
</head>
<body>
)rawhtml";

  html += "<div class='topbar'>";
  html += "<div><div class='topbar-title'>&#127807; FreshAir Desk</div>"
          "<div class='topbar-sub'>Refreshes every 5 s &nbsp;&bull;&nbsp; Uptime: "
          + String(millis()/1000) + " s</div></div>";
  html += overallBadge();
  html += "</div><div class='main'>";

  html += "<div class='cards'>";

  // Temperature
  {
    String lc = levelClass(g_lvl_temp);
    html += "<div class='card card-" + lc + "'>";
    html += "<div class='card-icon'>&#127777;</div>";
    html += "<div class='card-label'>Temperature</div>";
    if (!g_dht_ok) {
      html += "<div class='err-code'>E001</div>";
      html += "<div class='card-value val-err'>—</div>";
      html += "<div class='card-unit'>°C</div>";
      html += "<span class='card-level lv-err'>Sensor Error</span>";
    } else {
      html += "<div class='card-value val-" + lc + "'>" + String(g_temp,1) + "</div>";
      html += "<div class='card-unit'>°C &nbsp;·&nbsp; ideal 21–26</div>";
      html += "<span class='card-level lv-" + lc + "'>" + levelLabel(g_lvl_temp) + "</span>";
    }
    html += "<div class='card-tip'>" + String(g_tip_temp) + "</div></div>";
  }

  // Humidity
  {
    String lc = levelClass(g_lvl_hum);
    html += "<div class='card card-" + lc + "'>";
    html += "<div class='card-icon'>&#128167;</div>";
    html += "<div class='card-label'>Humidity</div>";
    if (!g_dht_ok) {
      html += "<div class='err-code'>E001</div>";
      html += "<div class='card-value val-err'>—</div>";
      html += "<div class='card-unit'>% RH</div>";
      html += "<span class='card-level lv-err'>Sensor Error</span>";
    } else {
      html += "<div class='card-value val-" + lc + "'>" + String(g_hum,1) + "</div>";
      html += "<div class='card-unit'>% RH &nbsp;·&nbsp; ideal 40–60</div>";
      html += "<span class='card-level lv-" + lc + "'>" + levelLabel(g_lvl_hum) + "</span>";
    }
    html += "<div class='card-tip'>" + String(g_tip_hum) + "</div></div>";
  }

  // Light
  {
    String lc = levelClass(g_lvl_lux);
    html += "<div class='card card-" + lc + "'>";
    html += "<div class='card-icon'>&#128161;</div>";
    html += "<div class='card-label'>Light</div>";
    if (!g_bh_ok) {
      html += "<div class='err-code'>" + String(g_bh_init_ok ? "E003" : "E002") + "</div>";
      html += "<div class='card-value val-err'>—</div>";
      html += "<div class='card-unit'>lux</div>";
      html += "<span class='card-level lv-err'>Sensor Error</span>";
    } else {
      html += "<div class='card-value val-" + lc + "'>" + String(g_lux,0) + "</div>";
      html += "<div class='card-unit'>lux &nbsp;·&nbsp; desk work &gt;300</div>";
      html += "<span class='card-level lv-" + lc + "'>" + levelLabel(g_lvl_lux) + "</span>";
    }
    html += "<div class='card-tip'>" + String(g_tip_lux) + "</div></div>";
  }

  // Air Quality
  {
    String lc = levelClass(g_lvl_air);
    html += "<div class='card card-" + lc + "'>";
    html += "<div class='card-icon'>&#129481;</div>";
    html += "<div class='card-label'>Air Quality</div>";
    if (!g_mq_ok) {
      html += "<div class='err-code'>E004</div>";
      html += "<div class='card-value val-err'>—</div>";
      html += "<div class='card-unit'>RS/R0</div>";
      html += "<span class='card-level lv-err'>Sensor Error</span>";
    } else {
      html += "<div class='card-value val-" + lc + "'>" + String(g_ratio,2) + "</div>";
      html += "<div class='card-unit'>RS/R0 &nbsp;·&nbsp; clean air ~3.6</div>";
      html += "<span class='card-level lv-" + lc + "'>" + levelLabel(g_lvl_air) + "</span>";
    }
    html += "<div class='card-tip'>" + String(g_tip_air) + "</div></div>";
  }

  html += "</div>"; // end cards

  // ── AI Insights card ───────────────────────────────────────────────────
  html += "<div class='ai-wrap'>";
  html += "<div class='ai-header'>";
  html += "<span class='ai-title'>&#129504; AI Insights</span>";
  html += "<div style='display:flex;align-items:center;gap:12px'>";
  html += "<div class='ai-score sc-nil' id='ai-score'>—</div>";
  html += "<button class='ai-btn' id='ai-btn' onclick='refreshNow()'>Refresh Now</button>";
  html += "</div></div>";
  html += "<div id='ai-body' style='display:none'>";
  html += "<div class='ai-summary' id='ai-summary'></div>";
  html += "<ul class='ai-list' id='ai-list'></ul>";
  html += "<div class='ai-focus' id='ai-focus' style='display:none'></div>";
  html += "</div>";
  html += "<div class='ai-offline' id='ai-offline' style='display:none'>AI server offline — run ai_server/start.bat on your laptop.</div>";
  html += "<div class='ai-footer'>";
  html += "<span class='ai-updated' id='ai-updated'>Waiting for first reading...</span>";
  html += "</div></div>";

  if (histCount > 0) {
    html += "<div class='section-title'>History &mdash; last 30 min</div>";
    html += "<div class='table-wrap'><table><thead><tr>"
            "<th>Time (s)</th><th>Temp °C</th><th>Hum %</th>"
            "<th>Lux</th><th>RS/R0</th><th>Status</th>"
            "</tr></thead><tbody>";
    for (int i = 0; i < histCount; i++) {
      int idx = ((histHead - 1 - i) + HISTORY_SIZE) % HISTORY_SIZE;
      Reading& r = history[idx];
      html += "<tr><td>" + String(r.ts) + "</td>";
      html += "<td>" + (r.temp  == -99 ? "<span style='color:#dc2626;font-family:monospace'>E001</span>" : String(r.temp,  1)) + "</td>";
      html += "<td>" + (r.hum   == -99 ? "<span style='color:#dc2626;font-family:monospace'>E001</span>" : String(r.hum,   1)) + "</td>";
      html += "<td>" + (r.lux   == -1  ? "<span style='color:#dc2626;font-family:monospace'>E002</span>" : String(r.lux,   0)) + "</td>";
      html += "<td>" + (r.ratio == -1  ? "<span style='color:#dc2626;font-family:monospace'>E004</span>" : String(r.ratio, 2)) + "</td>";
      html += "<td>" + histPill(r.overall) + "</td></tr>";
    }
    html += "</tbody></table></div>";
  }

  html += "<footer>FreshAir Desk v0.7 &nbsp;&bull;&nbsp; ESP32 @ ";
  html += g_wifi_ok ? WiFi.localIP().toString() : "offline";
  html += "</footer>";

  // The laptop can receive different client addresses from the iPhone hotspot.
  // Probe its usable client range so the dashboard can find the local AI server.
  html += "<script>const AI_URLS=Array.from({length:13},(_,i)=>'http://172.20.10.'+(i+2)+':5000');</script>";
  html += R"rawjs(
<script>
let AI_URL=null;
async function findServer(){
  const results=await Promise.all(AI_URLS.map(async u=>{
    try{
      const r=await fetch(u+'/suggest',{signal:AbortSignal.timeout(1000)});
      return r.ok?u:null;
    }catch(e){return null;}
  }));
  AI_URL=results.find(Boolean)||null;
  return AI_URL;
}
function scoreClass(n){return n>=7?'sc-good':n>=4?'sc-attn':'sc-poor';}
function renderSuggestion(d){
  const sc=d.score;
  const el=document.getElementById('ai-score');
  el.textContent=sc!=null?sc:'—';
  el.className='ai-score '+(sc!=null?scoreClass(sc):'sc-nil');
  document.getElementById('ai-summary').textContent=d.summary||'—';
  document.getElementById('ai-list').innerHTML=(d.suggestions||[]).map(s=>'<li>'+s+'</li>').join('');
  const fi=document.getElementById('ai-focus');
  if(d.focus_impact){fi.textContent=d.focus_impact;fi.style.display='block';}else{fi.style.display='none';}
  document.getElementById('ai-body').style.display='block';
  document.getElementById('ai-offline').style.display='none';
  if(d.updated)document.getElementById('ai-updated').textContent='Updated '+new Date(d.updated*1000).toLocaleTimeString();
}
async function fetchSuggestion(){
  const url=AI_URL||(await findServer());
  if(!url){
    document.getElementById('ai-body').style.display='none';
    document.getElementById('ai-offline').style.display='block';
    document.getElementById('ai-updated').textContent='';
    return;
  }
  try{
    const r=await fetch(url+'/suggest',{signal:AbortSignal.timeout(6000)});
    renderSuggestion(await r.json());
  }catch(e){
    AI_URL=null; // force re-probe next time
    document.getElementById('ai-body').style.display='none';
    document.getElementById('ai-offline').style.display='block';
    document.getElementById('ai-updated').textContent='';
  }
}
async function refreshNow(){
  const btn=document.getElementById('ai-btn');
  btn.textContent='Asking AI...';btn.disabled=true;
  const url=AI_URL||(await findServer());
  if(!url){btn.textContent='Refresh Now';btn.disabled=false;return;}
  try{await fetch(url+'/suggest/refresh',{method:'POST',signal:AbortSignal.timeout(5000)});}catch(e){}
  let polls=20;
  const prev=document.getElementById('ai-updated').textContent;
  const id=setInterval(async()=>{
    try{
      const r=await fetch(url+'/suggest',{signal:AbortSignal.timeout(4000)});
      const d=await r.json();
      const ts='Updated '+new Date(d.updated*1000).toLocaleTimeString();
      if(d.score!=null&&ts!==prev){renderSuggestion(d);clearInterval(id);btn.textContent='Refresh Now';btn.disabled=false;return;}
    }catch(e){}
    if(--polls<=0){clearInterval(id);btn.textContent='Refresh Now';btn.disabled=false;}
  },3000);
}
fetchSuggestion();
setInterval(fetchSuggestion,30000);
</script>
)rawjs";

  html += "</div></body></html>";
  server.send(200, "text/html", html);
}

// ── JSON endpoint ─────────────────────────────────────────────────────────
void handleJson() {
  String json = "{";
  json += "\"temp\":"    + (g_dht_ok ? String(g_temp,  1) : String("null")) + ",";
  json += "\"hum\":"     + (g_dht_ok ? String(g_hum,   1) : String("null")) + ",";
  json += "\"lux\":"     + (g_bh_ok  ? String(g_lux,   1) : String("null")) + ",";
  json += "\"ratio\":"   + (g_mq_ok  ? String(g_ratio, 3) : String("null")) + ",";
  json += "\"overall\":\"" + levelLabel(g_overall) + "\",";
  json += "\"wifi\":"    + String(g_wifi_ok ? "true" : "false") + ",";
  json += "\"uptime\":"  + String(millis()/1000);
  json += "}";
  server.send(200, "application/json", json);
}

// ── WiFi connect helper ───────────────────────────────────────────────────
bool tryNetwork(const char* ssid, const char* pass,
                IPAddress sip, IPAddress gw, IPAddress sn, IPAddress dns,
                const char* aiUrl, int timeoutSec) {
  WiFi.disconnect(true);
  delay(300);
  WiFi.config(sip, gw, sn, dns);
  WiFi.begin(ssid, pass);
  Serial.print("[WIFI] Trying ["); Serial.print(ssid); Serial.print("] ");
  int tries = timeoutSec * 2;
  while (WiFi.status() != WL_CONNECTED && tries-- > 0) {
    delay(500); Serial.print(".");
  }
  if (WiFi.status() == WL_CONNECTED) {
    g_ai_server_url = String(aiUrl);
    Serial.println("\n[WIFI] Connected. IP: " + WiFi.localIP().toString());
    Serial.println("[WIFI] AI server: " + g_ai_server_url);
    return true;
  }
  Serial.println(" failed.");
  return false;
}

bool connectWiFi() {
  WiFi.mode(WIFI_STA);
  Serial.println("[WIFI] Connecting to iPhone hotspot...");
  if (tryNetwork(SSID1, PASSWORD1, STATIC_IP1, GATEWAY1, SUBNET1, DNS1, AI_URL1, 30))
    return true;
  Serial.println(EC_WIFI_TIMEOUT);
  return false;
}

// ── Setup ─────────────────────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  delay(500);

  Serial.println("\n====================================");
  Serial.println("  FreshAir Desk v0.6 — booting");
  Serial.println("====================================");

  pinMode(LED_RED,   OUTPUT);
  pinMode(LED_GREEN, OUTPUT);

  dht.begin();
  Serial.println("[INIT] DHT22 ready on GPIO19.");

  Wire.begin(21, 22);
  g_bh_init_ok = lightMeter.begin(BH1750::CONTINUOUS_HIGH_RES_MODE);
  if (g_bh_init_ok) {
    Serial.println("[INIT] BH1750 found on I2C (SDA=21, SCL=22).");
  } else {
    Serial.println(EC_BH_INIT);
  }

  pinMode(MQ135_DOUT, INPUT);
  Serial.println("[INIT] MQ135 analog on GPIO34. Allow >=1 min warm-up for stable readings.");

  Serial.println("[INIT] Scanning Wi-Fi networks...");
  int n = WiFi.scanNetworks();
  for (int i = 0; i < n; i++)
    Serial.println("  [" + WiFi.SSID(i) + "] ch=" + String(WiFi.channel(i)) + " rssi=" + String(WiFi.RSSI(i)));

  g_wifi_ok = connectWiFi();
  if (g_wifi_ok) {
    blink(LED_GREEN, 3, 200);
    server.on("/",     handleRoot);
    server.on("/json", handleJson);
    server.begin();
    Serial.println("[INIT] Web server started. Dashboard: http://" + WiFi.localIP().toString());
  } else {
    blink(LED_RED, 5, 100);
    Serial.println("[INIT] Serial-only mode — no dashboard until WiFi connects.");
  }

  readAndClassify();
  pushHistory();
  lastRead = lastHistory = lastWifiCheck = millis();

  Serial.println();
  Serial.println("uptime_s | temp_C | hum_%  | lux    | rs_r0 | t_lvl     | h_lvl | l_lvl | a_lvl | overall");
  Serial.println("--------------------------------------------------------------------------------------------");
}

// ── Loop ──────────────────────────────────────────────────────────────────
void loop() {
  if (g_wifi_ok) server.handleClient();

  unsigned long now = millis();

  // WiFi watchdog — check every 30 s, attempt reconnect if dropped
  if (now - lastWifiCheck >= 30000) {
    lastWifiCheck = now;
    if (WiFi.status() != WL_CONNECTED) {
      Serial.println(EC_WIFI_LOST);
      WiFi.disconnect(true);
      delay(500);
      g_wifi_ok = connectWiFi();
      if (!g_wifi_ok) {
        Serial.println(EC_WIFI_FAIL);
      } else {
        server.on("/",     handleRoot);
        server.on("/json", handleJson);
        server.begin();
        Serial.println("[WIFI] Reconnected. Dashboard: http://" + WiFi.localIP().toString());
      }
    }
  }

  if (now - lastRead >= 2000) {
    lastRead = now;
    readAndClassify();

    Serial.print(now / 1000);
    Serial.print(" | ");
    Serial.print(g_dht_ok ? String(g_temp, 1) : "E001  ");
    Serial.print(" | ");
    Serial.print(g_dht_ok ? String(g_hum,  1) : "E001  ");
    Serial.print(" | ");
    Serial.print(g_bh_ok  ? String(g_lux,  1) : (g_bh_init_ok ? "E003  " : "E002  "));
    Serial.print(" | ");
    Serial.print(g_mq_ok  ? String(g_ratio, 3) : "E004 ");
    Serial.print(" | ");
    Serial.print(levelLabel(g_lvl_temp)); Serial.print(" | ");
    Serial.print(levelLabel(g_lvl_hum));  Serial.print(" | ");
    Serial.print(levelLabel(g_lvl_lux));  Serial.print(" | ");
    Serial.print(levelLabel(g_lvl_air));  Serial.print(" | ");
    Serial.println(levelLabel(g_overall));
  }

  if (now - lastHistory >= 30000) {
    lastHistory = now;
    pushHistory();
  }
}
