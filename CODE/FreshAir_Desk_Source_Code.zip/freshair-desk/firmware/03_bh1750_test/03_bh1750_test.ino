// FreshAir Desk — BH1750 (GY-302) standalone test
// Requires: "BH1750" library by Christopher Laws (claws/BH1750)
// Wiring: docs/diagrams/bh1750_wiring.svg
// Run 01_i2c_scanner first to confirm the address below.

#include <Wire.h>
#include <BH1750.h>

#define SDA_PIN 21
#define SCL_PIN 22
#define BH1750_ADDR 0x23   // change to 0x5C if ADDR is tied high
#define BAUD_RATE 115200
#define READ_INTERVAL_MS 1000

BH1750 light_meter(BH1750_ADDR);
unsigned long last_read = 0;

void setup() {
  Serial.begin(BAUD_RATE);
  delay(500);
  Wire.begin(SDA_PIN, SCL_PIN);

  if (light_meter.begin(BH1750::CONTINUOUS_HIGH_RES_MODE)) {
    Serial.println("=== FreshAir Desk BH1750 test ===");
    Serial.println("BH1750 init OK");
  } else {
    Serial.println("BH1750 init FAILED — check wiring/address (run 01_i2c_scanner).");
  }
  Serial.println("light_lux,valid");
}

void loop() {
  unsigned long now = millis();
  if (now - last_read < READ_INTERVAL_MS) {
    return;
  }
  last_read = now;

  float lux = light_meter.readLightLevel();
  bool valid = lux >= 0;

  Serial.print(valid ? String(lux, 1) : "NaN");
  Serial.print(",");
  Serial.println(valid ? "true" : "false");

  if (!valid) {
    Serial.println("  WARNING: read failed — check I2C wiring/address.");
  }
}
