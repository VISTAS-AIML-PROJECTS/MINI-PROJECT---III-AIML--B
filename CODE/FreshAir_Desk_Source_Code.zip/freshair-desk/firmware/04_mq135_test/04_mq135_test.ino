// FreshAir Desk — MQ135 standalone test
// No library — MQ135 output is treated as a relative gas trend only, never a
// calibrated CO2/eCO2/VOC/AQI value (rules.md, project.md).
// Wiring: docs/diagrams/mq135_wiring.svg — powered from 3V3, read on GPIO34.

#define MQ135_PIN         34
#define BAUD_RATE         115200
#define READ_INTERVAL_MS  1000
#define WARMUP_MS         (3UL * 60UL * 1000UL)  // 3 min minimum for a demo;
                                                   // real calibration needs far
                                                   // longer documented burn-in.
#define SMOOTHING_SAMPLES 10

unsigned long last_read = 0;
unsigned long boot_time = 0;
int history[SMOOTHING_SAMPLES];
int history_index = 0;
bool history_filled = false;

void setup() {
  Serial.begin(BAUD_RATE);
  delay(500);
  analogReadResolution(12); // 0-4095 on ESP32
  boot_time = millis();
  Serial.println("=== FreshAir Desk MQ135 test ===");
  Serial.println("NOTE: gas_adc is a relative trend signal, not a calibrated");
  Serial.println("      CO2/eCO2/VOC/AQI reading.");
  Serial.println("gas_adc_raw,gas_adc_avg,warming_up");
}

int smoothed_average() {
  int count = history_filled ? SMOOTHING_SAMPLES : history_index;
  if (count == 0) return 0;
  long sum = 0;
  for (int i = 0; i < count; i++) sum += history[i];
  return sum / count;
}

void loop() {
  unsigned long now = millis();
  if (now - last_read < READ_INTERVAL_MS) {
    return;
  }
  last_read = now;

  int raw = analogRead(MQ135_PIN);
  history[history_index] = raw;
  history_index++;
  if (history_index >= SMOOTHING_SAMPLES) {
    history_index = 0;
    history_filled = true;
  }

  bool warming_up = (now - boot_time) < WARMUP_MS;

  Serial.print(raw);
  Serial.print(",");
  Serial.print(smoothed_average());
  Serial.print(",");
  Serial.println(warming_up ? "true" : "false");
}
