// FreshAir Desk — sensor acquisition, validation, and smoothing
#ifndef FRESHAIR_SENSORS_H
#define FRESHAIR_SENSORS_H

#include <Arduino.h>

struct Reading {
  float temperature_c;
  float humidity_pct;
  float light_lux;
  int   gas_adc_raw;
  int   gas_adc_avg;

  bool temp_valid;
  bool humidity_valid;
  bool light_valid;
  bool gas_valid;
  bool gas_warming_up;
};

void sensors_init();
void sensors_read(Reading &out);
int  sensors_gas_baseline(); // established once warm-up completes

#endif
