// FreshAir Desk — rule-based environment classifier
// This is a documented threshold rule set, not an AI/ML model (rules.md).
#ifndef FRESHAIR_CLASSIFY_H
#define FRESHAIR_CLASSIFY_H

#include <Arduino.h>
#include "sensors.h"

enum Status {
  STATUS_INVALID = 0,
  STATUS_GOOD,
  STATUS_ATTENTION,
  STATUS_POOR
};

const char* status_name(Status s);

Status classify_comfort(const Reading &r);
Status classify_light(const Reading &r);
Status classify_gas(const Reading &r, int baseline);
Status overall_status(Status comfort, Status light, Status gas);
String build_recommendation(Status comfort, Status light, Status gas);

#endif
