// FreshAir Desk — sensor acquisition, validation, and smoothing
#include "sensors.h"
#include "config.h"
#include <DHT.h>
#include <Wire.h>
#include <BH1750.h>

static DHT dht(PIN_DHT22, DHT22);
static BH1750 light_meter(BH1750_ADDR);

static int gas_history[GAS_SMOOTHING_SAMPLES];
static int gas_history_index = 0;
static bool gas_history_filled = false;
static unsigned long boot_time = 0;
static int gas_baseline = -1; // set once, right after warm-up ends

// MQ135 rail watchdog: a disconnected or shorted analog input still returns
// an in-range ADC value (e.g. 0 when grounded), so a plain range check can't
// catch it. Treat a reading pinned at either rail for longer than physically
// plausible as a stuck/disconnected sensor rather than a real gas trend.
static bool gas_in_rail = false;
static unsigned long gas_rail_since = 0;
static bool gas_was_stuck = false;

void sensors_init() {
  dht.begin();
  Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL);
  light_meter.begin(BH1750::CONTINUOUS_HIGH_RES_MODE);
  analogReadResolution(12);
  boot_time = millis();
}

static int gas_smoothed_average() {
  int count = gas_history_filled ? GAS_SMOOTHING_SAMPLES : gas_history_index;
  if (count == 0) return 0;
  long sum = 0;
  for (int i = 0; i < count; i++) sum += gas_history[i];
  return sum / count;
}

int sensors_gas_baseline() {
  return gas_baseline;
}

void sensors_read(Reading &out) {
  unsigned long now = millis();

  // --- DHT22 ---
  // The library itself reports NaN on a failed/missing read, so that is the
  // failure signal — a steady room legitimately holds the same value for a
  // long time and must not be flagged invalid because of that.
  float t = dht.readTemperature();
  float h = dht.readHumidity();
  out.temp_valid = !isnan(t);
  out.humidity_valid = !isnan(h);
  out.temperature_c = t;
  out.humidity_pct = h;

  // --- BH1750 ---
  // readLightLevel() returns a negative value on a failed read; a real dark
  // room legitimately reads 0 and must stay valid.
  float lux = light_meter.readLightLevel();
  out.light_valid = lux >= 0;
  out.light_lux = lux;

  // --- MQ135 ---
  int raw = analogRead(PIN_MQ135_AOUT);

  bool at_rail = (raw <= GAS_RAIL_LOW || raw >= GAS_RAIL_HIGH);
  if (at_rail) {
    if (!gas_in_rail) {
      gas_in_rail = true;
      gas_rail_since = now;
    }
  } else {
    gas_in_rail = false;
  }
  bool gas_stuck = gas_in_rail && (now - gas_rail_since > GAS_RAIL_TIMEOUT_MS);

  if (gas_was_stuck && !gas_stuck) {
    // Just recovered from a stuck rail: the smoothing window still holds
    // rail samples, so discard it and require a full fresh window of
    // non-rail samples before the average/baseline can be trusted again.
    gas_history_index = 0;
    gas_history_filled = false;
  }
  gas_was_stuck = gas_stuck;

  gas_history[gas_history_index] = raw;
  gas_history_index++;
  if (gas_history_index >= GAS_SMOOTHING_SAMPLES) {
    gas_history_index = 0;
    gas_history_filled = true;
  }
  out.gas_adc_raw = raw;
  out.gas_adc_avg = gas_smoothed_average();
  out.gas_warming_up = (now - boot_time) < MQ135_WARMUP_MS;
  out.gas_valid = !gas_stuck;

  if (!out.gas_warming_up && !gas_stuck && gas_baseline < 0 && gas_history_filled) {
    gas_baseline = out.gas_adc_avg; // first stable average after warm-up
  }
}
