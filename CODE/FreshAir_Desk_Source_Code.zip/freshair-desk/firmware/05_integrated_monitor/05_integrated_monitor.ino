// FreshAir Desk — integrated monitor
// Combines DHT22 + BH1750 + MQ135 on a fixed interval, validates readings,
// classifies the desk environment with a documented rule set, and prints one
// structured line per cycle plus one concrete recommendation.
//
// Requires: "DHT sensor library" + "Adafruit Unified Sensor" + "BH1750" (claws)
// Wiring: docs/diagrams/full_system_wiring.svg
// Run 01-04 individually first — see docs/SOP.md section 2.

#include "config.h"
#include "sensors.h"
#include "classify.h"

Reading reading;
unsigned long last_sample = 0;

void setup_leds() {
  if (!LEDS_ENABLED) return;
  pinMode(PIN_LED_GOOD, OUTPUT);
  pinMode(PIN_LED_ATTENTION, OUTPUT);
  pinMode(PIN_LED_POOR, OUTPUT);
}

void update_leds(Status overall) {
  if (!LEDS_ENABLED) return;
  digitalWrite(PIN_LED_GOOD, overall == STATUS_GOOD ? HIGH : LOW);
  digitalWrite(PIN_LED_ATTENTION, overall == STATUS_ATTENTION ? HIGH : LOW);
  digitalWrite(PIN_LED_POOR, overall == STATUS_POOR ? HIGH : LOW);
}

void setup() {
  Serial.begin(BAUD_RATE);
  delay(500);
  Serial.println("=== FreshAir Desk integrated monitor ===");
  Serial.println("NOTE: gas readings are a relative trend, not calibrated CO2/eCO2/VOC/AQI.");
  Serial.println("uptime_s,temperature_c,humidity_pct,light_lux,gas_adc_avg,"
                  "comfort,light,gas,overall,recommendation");

  sensors_init();
  setup_leds();
}

void loop() {
  unsigned long now = millis();
  if (now - last_sample < SAMPLE_INTERVAL_MS) {
    return; // millis()-based scheduling, no blocking delay() (rules.md)
  }
  last_sample = now;

  sensors_read(reading);

  Status comfort = classify_comfort(reading);
  Status light   = classify_light(reading);
  Status gas     = classify_gas(reading, sensors_gas_baseline());
  Status overall = overall_status(comfort, light, gas);
  String recommendation = build_recommendation(comfort, light, gas);

  update_leds(overall);

  Serial.print(now / 1000);
  Serial.print(",");
  Serial.print(reading.temp_valid ? String(reading.temperature_c, 1) : "NaN");
  Serial.print(",");
  Serial.print(reading.humidity_valid ? String(reading.humidity_pct, 1) : "NaN");
  Serial.print(",");
  Serial.print(reading.light_valid ? String(reading.light_lux, 1) : "NaN");
  Serial.print(",");
  Serial.print(reading.gas_warming_up ? "warming_up" : String(reading.gas_adc_avg));
  Serial.print(",");
  Serial.print(status_name(comfort));
  Serial.print(",");
  Serial.print(status_name(light));
  Serial.print(",");
  Serial.print(status_name(gas));
  Serial.print(",");
  Serial.print(status_name(overall));
  Serial.print(",");
  Serial.println(recommendation);
}
