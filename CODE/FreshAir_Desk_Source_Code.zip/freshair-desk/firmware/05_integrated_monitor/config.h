// FreshAir Desk — integrated monitor configuration
// All pins and thresholds live here so they can be revised after real
// testing without hunting through the rest of the sketch (rules.md).

#ifndef FRESHAIR_CONFIG_H
#define FRESHAIR_CONFIG_H

// ---- Pins (docs/pin_map.md) ----
#define PIN_DHT22        4
#define PIN_I2C_SDA      21
#define PIN_I2C_SCL      22
#define PIN_MQ135_AOUT   34

#define PIN_LED_GOOD      25
#define PIN_LED_ATTENTION 26
#define PIN_LED_POOR      27
#define LEDS_ENABLED      false  // set true once LEDs are wired (see resistor warning in pin_map.md)

#define BH1750_ADDR 0x23   // confirm with 01_i2c_scanner, change to 0x5C if needed

// ---- Timing ----
#define BAUD_RATE            115200
#define SAMPLE_INTERVAL_MS   2500UL   // limited by DHT22's max sample rate
#define MQ135_WARMUP_MS       (3UL * 60UL * 1000UL)
#define GAS_SMOOTHING_SAMPLES 10

// A raw ADC reading pinned at either rail (disconnected, shorted-to-ground,
// or a saturated sensor) for longer than this is treated as a stuck/failed
// input rather than a real gas trend.
#define GAS_RAIL_LOW          5
#define GAS_RAIL_HIGH         4090
#define GAS_RAIL_TIMEOUT_MS   (30UL * 1000UL)

// ---- Comfort thresholds (temperature °C / humidity %) ----
#define TEMP_GOOD_MIN   20.0
#define TEMP_GOOD_MAX   26.0
#define TEMP_OK_MIN     18.0
#define TEMP_OK_MAX     29.0
#define HUM_GOOD_MIN    30.0
#define HUM_GOOD_MAX    60.0
#define HUM_OK_MIN      20.0
#define HUM_OK_MAX      70.0

// ---- Light thresholds (lux, desk task lighting) ----
#define LUX_GOOD_MIN    300.0
#define LUX_GOOD_MAX    750.0
#define LUX_OK_MIN      150.0
#define LUX_OK_MAX      1000.0

// ---- Gas trend thresholds (ADC counts above the boot-time baseline) ----
// Placeholder values pending real calibration — see rules.md: MQ135 output is
// a relative trend, not a calibrated concentration.
#define GAS_ATTENTION_DELTA  150
#define GAS_POOR_DELTA       400

#endif
