// FreshAir Desk — rule-based environment classifier
// Thresholds live in config.h so they can be revised after real testing.
#include "classify.h"
#include "config.h"

const char* status_name(Status s) {
  switch (s) {
    case STATUS_GOOD:      return "good";
    case STATUS_ATTENTION: return "attention";
    case STATUS_POOR:      return "poor";
    default:                return "invalid";
  }
}

Status classify_comfort(const Reading &r) {
  if (!r.temp_valid || !r.humidity_valid) return STATUS_INVALID;

  bool temp_good = (r.temperature_c >= TEMP_GOOD_MIN && r.temperature_c <= TEMP_GOOD_MAX);
  bool temp_ok   = (r.temperature_c >= TEMP_OK_MIN   && r.temperature_c <= TEMP_OK_MAX);
  bool hum_good  = (r.humidity_pct  >= HUM_GOOD_MIN  && r.humidity_pct  <= HUM_GOOD_MAX);
  bool hum_ok    = (r.humidity_pct  >= HUM_OK_MIN    && r.humidity_pct  <= HUM_OK_MAX);

  if (temp_good && hum_good) return STATUS_GOOD;
  if (temp_ok && hum_ok)     return STATUS_ATTENTION;
  return STATUS_POOR;
}

Status classify_light(const Reading &r) {
  if (!r.light_valid) return STATUS_INVALID;

  if (r.light_lux >= LUX_GOOD_MIN && r.light_lux <= LUX_GOOD_MAX) return STATUS_GOOD;
  if (r.light_lux >= LUX_OK_MIN   && r.light_lux <= LUX_OK_MAX)   return STATUS_ATTENTION;
  return STATUS_POOR;
}

Status classify_gas(const Reading &r, int baseline) {
  if (!r.gas_valid || r.gas_warming_up || baseline < 0) return STATUS_INVALID;

  int delta = r.gas_adc_avg - baseline;
  if (delta <= GAS_ATTENTION_DELTA) return STATUS_GOOD;
  if (delta <= GAS_POOR_DELTA)      return STATUS_ATTENTION;
  return STATUS_POOR;
}

Status overall_status(Status comfort, Status light, Status gas) {
  // Worst-of-three, ignoring dimensions that are still invalid/warming up so
  // one un-warmed sensor doesn't mask real problems elsewhere while also not
  // being falsely reported as "poor" itself.
  Status worst = STATUS_GOOD;
  Status values[3] = { comfort, light, gas };
  bool any_valid = false;
  for (int i = 0; i < 3; i++) {
    if (values[i] == STATUS_INVALID) continue;
    any_valid = true;
    if (values[i] > worst) worst = values[i];
  }
  return any_valid ? worst : STATUS_INVALID;
}

String build_recommendation(Status comfort, Status light, Status gas) {
  String parts = "";
  if (comfort == STATUS_POOR || comfort == STATUS_ATTENTION) {
    parts += "Adjust room temperature/humidity (fan, heater, or ventilation). ";
  }
  if (light == STATUS_POOR || light == STATUS_ATTENTION) {
    parts += "Improve desk lighting. ";
  }
  if (gas == STATUS_POOR || gas == STATUS_ATTENTION) {
    parts += "Ventilate the room — open a window or improve airflow. ";
  }
  if (parts.length() == 0) {
    if (comfort == STATUS_INVALID && light == STATUS_INVALID && gas == STATUS_INVALID) {
      parts = "No valid readings yet.";
    } else {
      parts = "Conditions look good — no action needed.";
    }
  }
  return parts;
}
