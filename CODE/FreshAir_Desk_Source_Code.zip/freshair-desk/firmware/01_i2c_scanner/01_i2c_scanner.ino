// FreshAir Desk — I2C address scanner
// Run this before trusting any BH1750 wiring/address in code.
// project.md: "Confirm its I2C address with a scanner before integrating it."

#include <Wire.h>

#define SDA_PIN 21
#define SCL_PIN 22
#define BAUD_RATE 115200
#define SCAN_INTERVAL_MS 5000

unsigned long last_scan = 0;

void scan_bus() {
  Serial.println("Scanning I2C bus...");
  int found = 0;
  for (uint8_t address = 1; address < 127; address++) {
    Wire.beginTransmission(address);
    uint8_t error = Wire.endTransmission();
    if (error == 0) {
      Serial.print("  device found at 0x");
      if (address < 16) Serial.print("0");
      Serial.println(address, HEX);
      found++;
    }
  }
  if (found == 0) {
    Serial.println("  no I2C devices found — check SDA/SCL wiring and GND.");
  } else {
    Serial.print("  total devices found: ");
    Serial.println(found);
  }
  Serial.println("---");
}

void setup() {
  Serial.begin(BAUD_RATE);
  delay(500);
  Wire.begin(SDA_PIN, SCL_PIN);
  Serial.println("=== FreshAir Desk I2C scanner ===");
  Serial.print("SDA=GPIO"); Serial.print(SDA_PIN);
  Serial.print(" SCL=GPIO"); Serial.println(SCL_PIN);
}

void loop() {
  unsigned long now = millis();
  if (now - last_scan >= SCAN_INTERVAL_MS || last_scan == 0) {
    last_scan = now;
    scan_bus();
  }
}
