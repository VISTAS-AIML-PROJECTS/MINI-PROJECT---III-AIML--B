// FreshAir Desk — MQ135 R0 calibration
// Run this ONCE in clean air (open window, no cooking/smoke/incense nearby)
// after the sensor has been powered for at least 24h.
// MQ135 A0 → GPIO34 | VCC → 3V3

#define MQ135_AOUT  34
#define RL          10000.0   // load resistor on module in ohms (typically 10K)
#define VCC         3.3       // supply voltage
#define ADC_MAX     4095.0
#define RS_R0_RATIO 3.6       // datasheet: RS/R0 = 3.6 in clean air

// Warm-up and sampling config
#define WARMUP_MINUTES   5    // minimum before sampling; 24h ideal but 5m is usable
#define SAMPLE_COUNT     200  // readings to average for R0
#define SAMPLE_INTERVAL  2000 // ms between samples

float readRS() {
  int   raw = analogRead(MQ135_AOUT);
  float vrl = raw * (VCC / ADC_MAX);           // voltage across load resistor
  if (vrl <= 0.001) return -1;                 // guard: avoid divide-by-zero
  float rs  = ((VCC - vrl) / vrl) * RL;        // sensor resistance
  return rs;
}

void warmup() {
  long warmup_ms = (long)WARMUP_MINUTES * 60 * 1000;
  long start     = millis();
  Serial.println("=== WARM-UP ===");
  Serial.print("Waiting "); Serial.print(WARMUP_MINUTES); Serial.println(" minutes...");
  Serial.println("(For best results power the sensor for 24h before running this sketch)");
  Serial.println();

  while (millis() - start < warmup_ms) {
    long remaining = (warmup_ms - (millis() - start)) / 1000;
    float rs = readRS();
    Serial.print("  remaining: "); Serial.print(remaining);
    Serial.print("s  |  RS now: ");
    if (rs < 0) Serial.println("ERR (check wiring)");
    else { Serial.print(rs, 1); Serial.println(" ohm"); }
    delay(10000); // print every 10s during warm-up
  }

  Serial.println();
  Serial.println("Warm-up done. Starting calibration samples...");
  Serial.println("------------------------------------------------");
}

void setup() {
  Serial.begin(115200);
  while (!Serial) {}

  Serial.println();
  Serial.println("========================================");
  Serial.println("  FreshAir Desk — MQ135 R0 Calibration");
  Serial.println("========================================");
  Serial.println("IMPORTANT: Run in clean outdoor-quality air.");
  Serial.println("  Open a window. No cooking, smoke, or");
  Serial.println("  incense in the room.");
  Serial.println();
  Serial.print("RL assumed: "); Serial.print((int)RL); Serial.println(" ohm");
  Serial.print("VCC:        "); Serial.print(VCC);     Serial.println(" V");
  Serial.println();

  warmup();
}

void loop() {
  double rs_sum  = 0;
  double rs_min  = 1e9;
  double rs_max  = 0;
  int    good    = 0;
  int    errors  = 0;

  Serial.print("Collecting "); Serial.print(SAMPLE_COUNT); Serial.println(" samples...");
  Serial.println("  #   |   RS (ohm)");
  Serial.println("------+------------");

  for (int i = 1; i <= SAMPLE_COUNT; i++) {
    float rs = readRS();

    if (rs < 0) {
      errors++;
      Serial.print("  "); Serial.print(i);
      Serial.println(" |  ERR");
    } else {
      rs_sum += rs;
      if (rs < rs_min) rs_min = rs;
      if (rs > rs_max) rs_max = rs;
      good++;

      Serial.print("  "); Serial.print(i);
      Serial.print(" |  "); Serial.println(rs, 1);
    }

    delay(SAMPLE_INTERVAL);
  }

  // Results
  Serial.println();
  Serial.println("========================================");
  Serial.println("  CALIBRATION RESULTS");
  Serial.println("========================================");

  if (good < 10) {
    Serial.println("ERROR: too few valid samples. Check wiring.");
    Serial.println("Halting.");
    while (1) {}
  }

  double rs_avg = rs_sum / good;
  double r0     = rs_avg / RS_R0_RATIO;

  Serial.print("Samples:    "); Serial.print(good);
  if (errors) { Serial.print("  ("); Serial.print(errors); Serial.print(" errors)"); }
  Serial.println();
  Serial.print("RS average: "); Serial.print(rs_avg, 1); Serial.println(" ohm");
  Serial.print("RS min:     "); Serial.print(rs_min, 1); Serial.println(" ohm");
  Serial.print("RS max:     "); Serial.print(rs_max, 1); Serial.println(" ohm");
  Serial.println();
  Serial.print(">>> R0 = "); Serial.print(r0, 1); Serial.println(" ohm <<<");
  Serial.println();
  Serial.println("Copy R0 into your main sketch:");
  Serial.print("  #define MQ135_R0  "); Serial.println(r0, 1);
  Serial.println();

  // Spread check — warn if RS varied too much (sensor not settled or dirty air)
  double spread_pct = ((rs_max - rs_min) / rs_avg) * 100.0;
  if (spread_pct > 20.0) {
    Serial.println("WARNING: RS spread > 20%. Sensor may not be settled or");
    Serial.println("  air quality changed during sampling. Re-run after longer");
    Serial.println("  warm-up or in steadier conditions.");
  } else {
    Serial.println("Spread looks good. R0 is reliable.");
  }

  Serial.println();
  Serial.println("Done. Reset the board to run again.");
  while (1) {}  // halt — results stay visible on Serial Monitor
}
