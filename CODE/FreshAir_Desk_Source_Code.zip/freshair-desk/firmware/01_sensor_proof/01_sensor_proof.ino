// FreshAir Desk — Milestone 3: sensors + LED status (R0-calibrated)
// DHT22 OUT→19 | BH1750 SDA→21 SCL→22 | MQ135 A0→34 D0→32
// LED RED→25   | LED GREEN→33

#include <Wire.h>
#include <BH1750.h>
#include <DHT.h>

#define DHT_PIN    19
#define DHT_TYPE   DHT22
#define MQ135_AOUT 34
#define MQ135_DOUT 32
#define LED_RED    25
#define LED_GREEN  33

// MQ135 calibration — R0 measured after 20h warm-up in clean air
#define MQ135_RL   10000.0   // load resistor on module (ohms)
#define MQ135_VCC  3.3
#define MQ135_R0   12741.0   // from calibration: RS in clean air / 3.6

// RS/R0 thresholds (clean air = 3.6; lower = more gas detected)
#define MQ135_RATIO_SAFE  2.0   // below this = poor air trend

// Safe environment thresholds
#define TEMP_MIN  18.0
#define TEMP_MAX  30.0
#define HUM_MIN   30.0
#define HUM_MAX   65.0

DHT    dht(DHT_PIN, DHT_TYPE);
BH1750 lightMeter;

float readMQ135Ratio() {
  int   raw = analogRead(MQ135_AOUT);
  float vrl = raw * (MQ135_VCC / 4095.0);
  if (vrl < 0.001) return -1;
  float rs    = ((MQ135_VCC - vrl) / vrl) * MQ135_RL;
  return rs / MQ135_R0;
}

void blink(int pin, int times = 2, int ms = 150) {
  for (int i = 0; i < times; i++) {
    digitalWrite(pin, HIGH); delay(ms);
    digitalWrite(pin, LOW);  delay(ms);
  }
}

void setup() {
  Serial.begin(115200);
  while (!Serial) {}

  pinMode(LED_RED,   OUTPUT);
  pinMode(LED_GREEN, OUTPUT);

  dht.begin();
  Wire.begin(21, 22);
  if (!lightMeter.begin(BH1750::CONTINUOUS_HIGH_RES_MODE)) {
    Serial.println("[BH1750] init failed");
  }
  pinMode(MQ135_DOUT, INPUT);

  Serial.println("uptime_s | temp_C | hum_pct | lux   | rs_r0 | status");
  Serial.println("---------------------------------------------------------");
}

void loop() {
  float temp  = dht.readTemperature();
  float hum   = dht.readHumidity();
  float lux   = lightMeter.readLightLevel();
  float ratio = readMQ135Ratio();

  bool dht_ok = !isnan(temp) && !isnan(hum);
  bool bh_ok  = lux >= 0;
  bool mq_ok  = ratio > 0;

  bool safe = dht_ok && bh_ok && mq_ok
           && temp  >= TEMP_MIN  && temp  <= TEMP_MAX
           && hum   >= HUM_MIN   && hum   <= HUM_MAX
           && ratio >= MQ135_RATIO_SAFE;

  // Serial output
  Serial.print(millis() / 1000); Serial.print(" | ");

  if (!dht_ok) Serial.print("DHT_ERR | DHT_ERR");
  else {
    Serial.print(temp, 1); Serial.print(" | ");
    Serial.print(hum,  1);
  }
  Serial.print(" | ");

  if (!bh_ok) Serial.print("BH_ERR ");
  else        Serial.print(lux, 1);
  Serial.print(" | ");

  if (!mq_ok) Serial.print("MQ_ERR");
  else        Serial.print(ratio, 3);
  Serial.print(" | ");

  Serial.println(safe ? "SAFE" : "WARN");

  // Blink the right LED
  digitalWrite(safe ? LED_RED   : LED_GREEN, LOW);
  blink(safe        ? LED_GREEN : LED_RED);

  delay(2000);
}
