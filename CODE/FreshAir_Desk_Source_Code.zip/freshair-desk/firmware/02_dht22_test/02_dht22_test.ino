// FreshAir Desk — DHT22 standalone test
// Requires: "DHT sensor library" by Adafruit + "Adafruit Unified Sensor"
// Wiring: docs/diagrams/dht22_wiring.svg

#include <DHT.h>

#define DHT_PIN       4
#define DHT_TYPE      DHT22
#define BAUD_RATE     115200
#define READ_INTERVAL_MS 2500   // DHT22 should not be polled faster than ~2s

DHT dht(DHT_PIN, DHT_TYPE);
unsigned long last_read = 0;

void setup() {
  Serial.begin(BAUD_RATE);
  delay(500);
  dht.begin();
  Serial.println("=== FreshAir Desk DHT22 test ===");
  Serial.println("temperature_c,humidity_pct,valid");
}

void loop() {
  unsigned long now = millis();
  if (now - last_read < READ_INTERVAL_MS) {
    return;
  }
  last_read = now;

  float humidity_pct = dht.readHumidity();
  float temperature_c = dht.readTemperature();
  bool valid = !isnan(humidity_pct) && !isnan(temperature_c);

  Serial.print(valid ? String(temperature_c, 1) : "NaN");
  Serial.print(",");
  Serial.print(valid ? String(humidity_pct, 1) : "NaN");
  Serial.print(",");
  Serial.println(valid ? "true" : "false");

  if (!valid) {
    Serial.println("  WARNING: read failed — check DATA pin and pull-up resistor.");
  }
}
