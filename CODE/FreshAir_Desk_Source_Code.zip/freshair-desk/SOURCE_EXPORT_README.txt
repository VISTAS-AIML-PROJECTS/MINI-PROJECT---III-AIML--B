FreshAir Desk source-code export

This ZIP contains the project's firmware, sensor sketches/modules, Python AI server,
launch scripts, dependency list, and an example environment file.

Security: the private ai_server/.env file is intentionally excluded. Embedded Wi-Fi
and API credential values have been replaced with [SET_LOCALLY]. Before running,
set your own Wi-Fi details in the firmware and put your Groq key in ai_server/.env.
Never commit the real .env file or a live key to GitHub.

This archive contains source/configuration files only. It omits PDFs, logs, caches,
generated outputs, and other reference material.
