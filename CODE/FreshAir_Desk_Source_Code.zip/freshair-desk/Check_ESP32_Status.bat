@echo off
setlocal EnableExtensions
title FreshAir Desk - ESP32 Status

set "ARDUINO_CLI_DIR=%LOCALAPPDATA%\Programs\Arduino IDE\resources\app\lib\backend\resources"
if not exist "%ARDUINO_CLI_DIR%\arduino-cli.exe" set "ARDUINO_CLI_DIR=%LOCALAPPDATA%\Programs\arduino-ide\resources\app\lib\backend\resources"
if not exist "%ARDUINO_CLI_DIR%\arduino-cli.exe" (
    echo Arduino IDE command-line tools were not found.
    echo Open Arduino IDE once, then try again.
    goto :done
)
set "ARDUINO_CLI=%ARDUINO_CLI_DIR%\arduino-cli.exe"
set "PORT_LIST=%TEMP%\freshair_board_list.txt"
set "PORT_MATCH=%TEMP%\freshair_board_port.txt"

echo Finding the ESP32 USB connection...
"%ARDUINO_CLI%" board list > "%PORT_LIST%" 2>&1
type "%PORT_LIST%"
set "ESP_PORT="
findstr /R /I /C:"^COM[0-9][0-9]*" "%PORT_LIST%" > "%PORT_MATCH%"
for /f "usebackq tokens=1" %%P in ("%PORT_MATCH%") do if not defined ESP_PORT set "ESP_PORT=%%P"
if not defined ESP_PORT (
    echo.
    echo No COM port found. Connect the ESP32 to the laptop by USB and try again.
    goto :done
)

echo.
echo Opening the ESP32 status window on %ESP_PORT%.
echo Press the ESP32 EN/RESET button once to show its startup messages.
echo Leave the laptop connected to the iPhone hotspot.
echo.
"%ARDUINO_CLI%" monitor -p %ESP_PORT% --config baudrate=115200

:done
echo.
pause
endlocal
