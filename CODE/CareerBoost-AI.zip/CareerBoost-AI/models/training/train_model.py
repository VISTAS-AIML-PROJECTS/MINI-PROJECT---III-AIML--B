import os
import json
import joblib

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline


# ============================================================
# CAREERBOOST AI - MODEL TRAINING
# ============================================================

BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.dirname(
            os.path.abspath(__file__)
        )
    )
)


# ============================================================
# LOAD CAREER DOMAINS
# ============================================================

domains_path = os.path.join(
    BASE_DIR,
    "data",
    "domains.json"
)

with open(domains_path, "r", encoding="utf-8") as file:
    domains_data = json.load(file)

domains = domains_data["domains"]


# ============================================================
# LOAD SKILLS
# ============================================================

skills_path = os.path.join(
    BASE_DIR,
    "data",
    "skills.json"
)

with open(skills_path, "r", encoding="utf-8") as file:
    skills_data = json.load(file)


# ============================================================
# LOAD MANUAL RESUME TRAINING SAMPLES
# ============================================================

samples_path = os.path.join(
    BASE_DIR,
    "data",
    "training_samples.json"
)

with open(samples_path, "r", encoding="utf-8") as file:
    samples_data = json.load(file)


# ============================================================
# CREATE TRAINING DATA
# ============================================================

training_texts = []
training_labels = []

manual_sample_count = 0
generated_sample_count = 0

for domain in domains:
    manual_samples = samples_data.get(domain, [])

    for sample in manual_samples:
        training_texts.append(sample)
        training_labels.append(domain)
        manual_sample_count += 1

    required_skills = skills_data.get(domain, [])
    skill_text = " ".join(required_skills[:12])

    if not skill_text:
        skill_text = domain

    while len(manual_samples) < 3:
        sample_number = len(manual_samples)

        generated_samples = [
            f"{domain} with experience in {skill_text}.",
            f"Professional {domain} skilled in {skill_text} and software development.",
            f"Experienced {domain} working with {skill_text} on real world projects."
        ]

        training_texts.append(generated_samples[sample_number])
        training_labels.append(domain)

        manual_samples.append(generated_samples[sample_number])
        generated_sample_count += 1


# ============================================================
# CHECK TRAINING DATA
# ============================================================

if len(set(training_labels)) < 2:
    raise ValueError(
        "At least two career domains are required for training."
    )


# ============================================================
# CREATE MACHINE LEARNING PIPELINE
# ============================================================

model = Pipeline(
    [
        (
            "tfidf",
            TfidfVectorizer(
                lowercase=True,
                ngram_range=(1, 2)
            )
        ),
        (
            "classifier",
            LogisticRegression(
                max_iter=3000
            )
        )
    ]
)


# ============================================================
# TRAIN MODEL
# ============================================================

print()
print("============================================")
print("CareerBoost AI - Model Training")
print("============================================")
print()

print("Training domains:", len(set(training_labels)))
print("Training samples:", len(training_texts))
print("Manual samples used:", manual_sample_count)
print("Starter samples generated:", generated_sample_count)
print()

model.fit(
    training_texts,
    training_labels
)


# ============================================================
# SAVE TRAINED MODEL
# ============================================================

models_path = os.path.join(
    BASE_DIR,
    "models"
)

os.makedirs(
    models_path,
    exist_ok=True
)

model_path = os.path.join(
    models_path,
    "career_domain_model.pkl"
)

joblib.dump(
    model,
    model_path
)


# ============================================================
# TRAINING COMPLETE
# ============================================================

print("============================================")
print("MODEL TRAINING COMPLETED")
print("============================================")
print()

print("Model saved at:")
print(model_path)
print()

print("CareerBoost AI model is ready.")