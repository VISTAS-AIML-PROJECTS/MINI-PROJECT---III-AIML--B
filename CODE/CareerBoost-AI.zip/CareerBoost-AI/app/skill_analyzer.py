import re


def normalize_text(text):
    return re.sub(r"[^a-zA-Z0-9+#.\- ]", " ", text.lower())


def find_skills(resume_text, required_skills):
    text = normalize_text(resume_text)

    found_skills = []
    missing_skills = []

    for skill in required_skills:
        skill_normalized = skill.lower()

        if skill_normalized in text:
            found_skills.append(skill)
        else:
            missing_skills.append(skill)

    return found_skills, missing_skills


def calculate_match_percentage(found_skills, required_skills):
    if not required_skills:
        return 0

    percentage = (len(found_skills) / len(required_skills)) * 100

    return round(percentage)