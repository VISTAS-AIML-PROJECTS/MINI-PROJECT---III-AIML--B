from flask import Flask, render_template, request
import json
import os
import joblib

from app.resume_parser import extract_resume_text
from app.skill_analyzer import find_skills, calculate_match_percentage
from app.career_gap_analyzer import analyze_career_gap


# ============================================================
# PROJECT PATH
# ============================================================

BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)


# ============================================================
# ML MODEL PATH
# ============================================================

MODEL_PATH = os.path.join(
    BASE_DIR,
    "models",
    "career_domain_model.pkl"
)


# ============================================================
# LOAD ML MODEL
# ============================================================

career_model = None

if os.path.exists(MODEL_PATH):
    try:
        career_model = joblib.load(MODEL_PATH)
        print("Career domain ML model loaded successfully.")

    except Exception as e:
        print("Could not load ML model:", e)


# ============================================================
# FLASK APPLICATION
# ============================================================

app = Flask(
    __name__,
    template_folder=os.path.join(BASE_DIR, "templates"),
    static_folder=os.path.join(BASE_DIR, "static")
)


# ============================================================
# LOAD CAREER DOMAINS
# ============================================================

def load_domains():

    data_path = os.path.join(
        BASE_DIR,
        "data",
        "domains.json"
    )

    with open(
        data_path,
        "r",
        encoding="utf-8"
    ) as file:

        data = json.load(file)

    return data["domains"]


# ============================================================
# LOAD REQUIRED SKILLS
# ============================================================

def load_skills():

    data_path = os.path.join(
        BASE_DIR,
        "data",
        "skills.json"
    )

    with open(
        data_path,
        "r",
        encoding="utf-8"
    ) as file:

        return json.load(file)


# ============================================================
# LOAD COURSE & CERTIFICATION RECOMMENDATIONS
# ============================================================

def load_recommendations():

    data_path = os.path.join(
        BASE_DIR,
        "data",
        "recommendations.json"
    )

    with open(
        data_path,
        "r",
        encoding="utf-8"
    ) as file:

        return json.load(file)


# ============================================================
# PREDICT CAREER DOMAIN USING ML MODEL
# ============================================================

def predict_career_domain(resume_text):

    if career_model is None:
        return None

    try:

        prediction = career_model.predict(
            [resume_text]
        )

        return prediction[0]

    except Exception as e:

        print("ML prediction error:", e)

        return None


# ============================================================
# HOME PAGE
# ============================================================

@app.route("/")
def home():

    domains = load_domains()

    return render_template(
        "index.html",
        domains=domains
    )


# ============================================================
# RESUME ANALYSIS
# ============================================================

@app.route("/analyze", methods=["POST"])
def analyze():

    # --------------------------------------------------------
    # GET USER INPUT
    # --------------------------------------------------------

    career_domain = request.form.get(
        "career_domain"
    )

    resume = request.files.get(
        "resume"
    )


    # --------------------------------------------------------
    # VALIDATE INPUT
    # --------------------------------------------------------

    if not career_domain or not resume:

        return """
        <h2>Please select a career domain and upload your resume.</h2>
        <br>
        <a href="/">Go Back</a>
        """


    # --------------------------------------------------------
    # EXTRACT RESUME TEXT
    # --------------------------------------------------------

    resume_text = extract_resume_text(
        resume
    )


    # --------------------------------------------------------
    # ML CAREER DOMAIN PREDICTION
    # --------------------------------------------------------

    predicted_domain = predict_career_domain(
        resume_text
    )


    # --------------------------------------------------------
    # LOAD REQUIRED SKILLS
    # --------------------------------------------------------

    skills_data = load_skills()

    required_skills = skills_data.get(
        career_domain,
        []
    )


    # --------------------------------------------------------
    # FIND EXISTING & MISSING SKILLS
    # --------------------------------------------------------

    found_skills, missing_skills = find_skills(
        resume_text,
        required_skills
    )


    # --------------------------------------------------------
    # CALCULATE MATCH PERCENTAGE
    # --------------------------------------------------------

    match_percentage = calculate_match_percentage(
        found_skills,
        required_skills
    )


    # --------------------------------------------------------
    # CAREER GAP ANALYSIS
    # --------------------------------------------------------

    career_gap = analyze_career_gap(
        found_skills,
        missing_skills,
        required_skills
    )


    # --------------------------------------------------------
    # LOAD RECOMMENDATIONS
    # --------------------------------------------------------

    recommendations_data = load_recommendations()

    domain_recommendations = recommendations_data.get(
        career_domain,
        {}
    )


    # --------------------------------------------------------
    # RECOMMENDED COURSES
    # --------------------------------------------------------

    recommended_courses = []


    # --------------------------------------------------------
    # RECOMMENDED CERTIFICATIONS
    # --------------------------------------------------------

    recommended_certifications = []


    # --------------------------------------------------------
    # GET RECOMMENDATIONS FOR MISSING SKILLS
    # --------------------------------------------------------

    for skill in missing_skills:

        skill_data = domain_recommendations.get(
            skill,
            {}
        )

        courses = skill_data.get(
            "courses",
            []
        )

        certifications = skill_data.get(
            "certifications",
            []
        )

        recommended_courses.extend(
            courses
        )

        recommended_certifications.extend(
            certifications
        )


    # --------------------------------------------------------
    # REMOVE DUPLICATES
    # --------------------------------------------------------

    recommended_courses = list(
        dict.fromkeys(
            recommended_courses
        )
    )

    recommended_certifications = list(
        dict.fromkeys(
            recommended_certifications
        )
    )


    # ========================================================
    # DISPLAY PROFESSIONAL DASHBOARD
    # ========================================================

    return render_template(
        "analysis.html",

        career_domain=career_domain,

        predicted_domain=predicted_domain,

        resume=resume,

        match_percentage=match_percentage,

        found_skills=found_skills,

        missing_skills=missing_skills,

        career_gap=career_gap,

        recommended_courses=recommended_courses,

        recommended_certifications=recommended_certifications,

        resume_text=resume_text
    )


# ============================================================
# RUN APPLICATION
# ============================================================

if __name__ == "__main__":

    app.run(
        debug=True
    )