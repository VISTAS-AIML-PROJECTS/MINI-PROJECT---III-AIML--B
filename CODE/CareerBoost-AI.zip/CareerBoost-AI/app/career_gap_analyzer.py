def analyze_career_gap(
    found_skills,
    missing_skills,
    required_skills
):
    """
    Analyze the career gap based on
    existing and missing skills.
    """

    total_skills = len(required_skills)
    existing_count = len(found_skills)
    missing_count = len(missing_skills)

    if total_skills == 0:
        return {
            "gap_percentage": 0,
            "gap_level": "No Data",
            "message": "No required skills found for this career domain."
        }

    gap_percentage = round(
        (missing_count / total_skills) * 100
    )

    if gap_percentage == 0:
        gap_level = "No Career Gap"
        message = "Your resume covers all the required skills for this career domain."

    elif gap_percentage <= 25:
        gap_level = "Low Career Gap"
        message = "You have a small number of skills to improve."

    elif gap_percentage <= 50:
        gap_level = "Moderate Career Gap"
        message = "You have some important skills to develop."

    else:
        gap_level = "High Career Gap"
        message = "Several important skills are missing and should be developed."

    return {
        "gap_percentage": gap_percentage,
        "gap_level": gap_level,
        "message": message
    }