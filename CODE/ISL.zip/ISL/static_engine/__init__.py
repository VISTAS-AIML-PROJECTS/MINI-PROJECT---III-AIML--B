"""SIGNVISION Static Engine Package.

Exposes base contracts and shared classification logic for single-frame alphabet recognition.
"""

from static_engine.base import (
    StaticClassifierProtocol,
    BaseStaticClassifier,
    SklearnStaticClassifier,
)

__all__ = [
    "StaticClassifierProtocol",
    "BaseStaticClassifier",
    "SklearnStaticClassifier",
]
