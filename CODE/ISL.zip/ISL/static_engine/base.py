"""SIGNVISION Static Engine - Base Classifier Contract & Shared Logic.

Defines the generic interface and BaseStaticClassifier providing shared inference,
margin computation, and prediction formatting for all static classifiers.
"""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union
import numpy as np
from common.types import PredictionResult, EngineType
from common.exceptions import (
    ModelError,
    ModelInferenceError,
    ModelNotLoadedError,
    InvalidFeatureShapeError,
)
import joblib


class StaticClassifierProtocol(ABC):
    """Abstract contract for static alphabet/numeral classifiers."""

    @abstractmethod
    def fit(self, X: np.ndarray, y: np.ndarray) -> "StaticClassifierProtocol":
        pass

    @abstractmethod
    def predict(self, feature_vector: np.ndarray) -> int:
        pass

    @abstractmethod
    def predict_proba(self, feature_vector: np.ndarray) -> np.ndarray:
        pass

    @abstractmethod
    def infer(self, feature_vector: np.ndarray, class_names: List[str]) -> PredictionResult:
        pass

    @abstractmethod
    def save(self, filepath: Union[str, Path]) -> None:
        pass

    @abstractmethod
    def load(self, filepath: Union[str, Path]) -> "StaticClassifierProtocol":
        pass

    @abstractmethod
    def metadata(self) -> Dict[str, Any]:
        pass

    def is_ready(self) -> bool:
        """Check if classifier is loaded and ready for inference."""
        return False


class BaseStaticClassifier(StaticClassifierProtocol):
    """Base implementation providing shared probability parsing, confidence, and margin calculation."""

    def __init__(self) -> None:
        self.is_fitted: bool = False
        self.expected_dim: Optional[int] = None
        self.num_classes: Optional[int] = None

    def is_ready(self) -> bool:
        """Return True if model is fitted/loaded and ready for inference."""
        return bool(self.is_fitted and getattr(self, "estimator", None) is not None)

    def infer(self, feature_vector: np.ndarray, class_names: List[str]) -> PredictionResult:
        """Execute full inference, computing top class, confidence, and margin."""
        proba = self.predict_proba(feature_vector)
        if proba is None or len(proba) == 0:
            raise ModelInferenceError("Classifier returned empty probability array.")

        sorted_indices = np.argsort(proba)[::-1]
        top_idx = int(sorted_indices[0])
        top_conf = float(proba[top_idx])

        margin = (
            float(proba[top_idx] - proba[sorted_indices[1]])
            if len(proba) > 1
            else top_conf
        )

        name = class_names[top_idx] if top_idx < len(class_names) else f"class_{top_idx}"

        return PredictionResult(
            engine=EngineType.STATIC,
            class_id=top_idx,
            class_name=name,
            confidence=top_conf,
            probabilities=proba,
            margin=margin,
        )


class SklearnStaticClassifier(BaseStaticClassifier):
    """Concrete wrapper bridging scikit-learn classifiers to StaticClassifierProtocol."""

    def __init__(
        self,
        estimator: Optional[Any] = None,
        feature_pruner: Optional[Any] = None,
        expected_dim: Optional[int] = None,
        class_names: Optional[List[str]] = None,
        metadata_dict: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__()
        self.estimator = estimator
        self.feature_pruner = feature_pruner
        self.expected_dim = expected_dim
        self.class_names = list(class_names) if class_names is not None else None
        self._custom_metadata = metadata_dict or {}

        if estimator is not None and hasattr(estimator, "classes_"):
            self.is_fitted = True
            self.num_classes = len(estimator.classes_)
            if hasattr(estimator, "n_features_in_"):
                self.expected_dim = int(estimator.n_features_in_)

    def _prepare_input(self, X: np.ndarray) -> np.ndarray:
        if X is None or not isinstance(X, np.ndarray):
            raise InvalidFeatureShapeError("Input features must be a valid NumPy ndarray.")
        arr = X
        if np.isnan(arr).any() or np.isinf(arr).any():
            raise InvalidFeatureShapeError("Input features contain NaN or Inf values.")
        if self.feature_pruner is not None and arr.shape[-1] != self.expected_dim:
            if arr.shape[-1] < self.expected_dim:
                raise InvalidFeatureShapeError(
                    f"Feature dimension mismatch: expected at least {self.expected_dim}, got {arr.shape[-1]}"
                )
            try:
                arr = self.feature_pruner.prune(arr)
            except Exception as e:
                raise InvalidFeatureShapeError(f"Feature pruning failed for input shape {arr.shape}: {e}") from e
        if self.expected_dim is not None and arr.shape[-1] != self.expected_dim:
            raise InvalidFeatureShapeError(
                f"Feature dimension mismatch: expected {self.expected_dim}, got {arr.shape[-1]}"
            )
        return arr

    def fit(self, X: np.ndarray, y: np.ndarray) -> "SklearnStaticClassifier":
        if self.estimator is None:
            raise ModelError("Cannot fit: estimator is None.")
        X_in = self._prepare_input(X)
        self.estimator.fit(X_in, y)
        self.is_fitted = True
        self.num_classes = len(self.estimator.classes_)
        self.expected_dim = int(X_in.shape[-1])
        return self

    def predict(self, feature_vector: np.ndarray) -> int:
        if not self.is_fitted or self.estimator is None:
            raise ModelNotLoadedError("Model is not fitted or loaded.")
        X_in = self._prepare_input(feature_vector)
        if X_in.ndim == 1:
            X_in = X_in.reshape(1, -1)
        preds = self.estimator.predict(X_in)
        return int(preds[0])

    def predict_proba(self, feature_vector: np.ndarray) -> np.ndarray:
        if not self.is_fitted or self.estimator is None:
            raise ModelNotLoadedError("Model is not fitted or loaded.")
        X_in = self._prepare_input(feature_vector)
        if X_in.ndim == 1:
            X_in = X_in.reshape(1, -1)

        if hasattr(self.estimator, "predict_proba"):
            probs = self.estimator.predict_proba(X_in)
            return np.asarray(probs[0], dtype=np.float32)
        elif hasattr(self.estimator, "decision_function"):
            df = self.estimator.decision_function(X_in)[0]
            exp_df = np.exp(df - np.max(df))
            return (exp_df / np.sum(exp_df)).astype(np.float32)
        else:
            raise ModelInferenceError("Estimator has neither predict_proba nor decision_function.")

    def save(self, filepath: Union[str, Path]) -> None:
        if not self.is_fitted or self.estimator is None:
            raise ModelNotLoadedError("Cannot save un-fitted model.")
        fp = Path(filepath)
        fp.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "estimator": self.estimator,
            "feature_pruner": self.feature_pruner,
            "expected_dim": self.expected_dim,
            "num_classes": self.num_classes,
            "class_names": self.class_names,
            "metadata": self.metadata(),
        }
        joblib.dump(payload, fp)

    def load(self, filepath: Union[str, Path]) -> "SklearnStaticClassifier":
        fp = Path(filepath)
        if not fp.exists():
            raise FileNotFoundError(f"Model file not found: {fp}")
        try:
            payload = joblib.load(fp)
        except Exception as e:
            raise ModelError(f"Corrupted or invalid model file {fp}: {e}") from e
        if isinstance(payload, dict) and "estimator" in payload:
            self.estimator = payload["estimator"]
            self.feature_pruner = payload.get("feature_pruner")
            self.expected_dim = payload.get("expected_dim")
            self.num_classes = payload.get("num_classes")
            self.class_names = payload.get("class_names")
            self._custom_metadata = payload.get("metadata", {})
        else:
            self.estimator = payload
            self.num_classes = len(self.estimator.classes_) if hasattr(self.estimator, "classes_") else None
            self.expected_dim = getattr(self.estimator, "n_features_in_", None)
        self.is_fitted = True
        return self

    def metadata(self) -> Dict[str, Any]:
        base_meta = {
            "estimator_type": self.estimator.__class__.__name__ if self.estimator else "None",
            "is_fitted": self.is_fitted,
            "expected_dim": self.expected_dim,
            "num_classes": self.num_classes,
            "class_names": self.class_names,
        }
        base_meta.update(self._custom_metadata)
        return base_meta
