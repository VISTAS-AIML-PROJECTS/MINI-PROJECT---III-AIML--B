"""SIGNVISION Chatbot Package.

Exposes local Ollama LLM integration contracts and implementations: client,
prompt templates, and fallback response handlers.
"""

from chatbot.ollama_client import OllamaClientProtocol, OllamaClient
from chatbot.prompt_templates import PromptTemplateRegistry
from chatbot.response_handler import ResponseHandlerProtocol, ResponseHandler

__all__ = [
    "OllamaClientProtocol",
    "OllamaClient",
    "PromptTemplateRegistry",
    "ResponseHandlerProtocol",
    "ResponseHandler",
]
