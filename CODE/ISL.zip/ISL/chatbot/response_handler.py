"""SIGNVISION Chatbot - Response Handler.

Defines the interface and concrete ResponseHandler for sanitizing LLM text,
managing bounded conversation context, and generating structured ChatbotResponse
contracts without crashing when Ollama is offline or times out.
"""

from abc import ABC, abstractmethod
import asyncio
import time
from typing import Any, Dict, List, Optional, Union

from common.config import OllamaConfig
from common.exceptions import (
    OllamaError,
    OllamaUnavailableError,
    OllamaTimeoutError,
    OllamaModelUnavailableError,
)
from common.types import ChatbotResponse, Transcript
from chatbot.ollama_client import OllamaClient, OllamaClientProtocol
from chatbot.prompt_templates import PromptTemplateRegistry


class ResponseHandlerProtocol(ABC):
    """Abstract interface for parsing responses, managing context, and fallback recovery."""

    @abstractmethod
    def handle_success(self, raw_response: str) -> str:
        """Clean and sanitize the generated LLM text string."""
        pass

    @abstractmethod
    def handle_fallback(self, gloss_string: str, error_context: Optional[str] = None) -> str:
        """Provide a reliable fallback message when Ollama is offline or times out."""
        pass

    @abstractmethod
    async def process_transcript(
        self, transcript_input: Union[str, Transcript]
    ) -> ChatbotResponse:
        """Execute end-to-end transcript to conversational response pipeline."""
        pass


class ResponseHandler(ResponseHandlerProtocol):
    """Concrete response handler providing clean formatting, context management, and offline fallback."""

    def __init__(
        self,
        client: Optional[OllamaClientProtocol] = None,
        config: Optional[OllamaConfig] = None,
        max_history_messages: Optional[int] = None,
    ) -> None:
        self.config = config or OllamaConfig()
        self.client = client or OllamaClient(self.config)
        self.max_history = (
            max_history_messages
            if max_history_messages is not None
            else getattr(self.config, "max_history_messages", 10)
        )
        self._history: List[Dict[str, str]] = []

    def get_history(self) -> List[Dict[str, str]]:
        """Return a copy of the current bounded conversation history."""
        return list(self._history)

    def clear_history(self) -> None:
        """Reset conversation context history."""
        self._history.clear()

    def _append_history(self, role: str, content: str) -> None:
        """Append turn to history enforcing FIFO bounded memory."""
        self._history.append({"role": role, "content": content})
        while len(self._history) > self.max_history:
            self._history.pop(0)

    def handle_success(self, raw_response: str) -> str:
        """Strip redundant quotation marks, leading labels, and extra whitespace."""
        if not raw_response or not isinstance(raw_response, str):
            return ""

        cleaned = raw_response.strip()
        # Remove surrounding quotes if model outputs them
        if (cleaned.startswith('"') and cleaned.endswith('"')) or (
            cleaned.startswith("'") and cleaned.endswith("'")
        ):
            cleaned = cleaned[1:-1].strip()

        # Remove accidental "Assistant:" or "AI:" prefix if generated
        for prefix in ("Assistant:", "AI:", "Response:"):
            if cleaned.startswith(prefix):
                cleaned = cleaned[len(prefix):].strip()

        return cleaned

    def handle_fallback(self, gloss_string: str, error_context: Optional[str] = None) -> str:
        """Return raw gloss transcript wrapped in an offline notice."""
        gloss = gloss_string.strip() if gloss_string else ""
        if not gloss:
            return "No signs detected to translate."

        reason = f" ({error_context})" if error_context else ""
        return f"[Direct Transcript{reason}]: {gloss}"

    async def process_transcript(
        self, transcript_input: Union[str, Transcript]
    ) -> ChatbotResponse:
        """Generate conversational response from transcript using Ollama.

        - Rejects empty/whitespace input without calling Ollama (NO_INPUT).
        - Isolates system prompt from user transcript to resist prompt injection.
        - Measures request latency.
        - Preserves transcript on failures with controlled fallback.
        """
        # 1. Extract raw transcript text
        if isinstance(transcript_input, Transcript):
            raw_text = transcript_input.text.strip()
        elif isinstance(transcript_input, str):
            raw_text = transcript_input.strip()
        else:
            raw_text = str(transcript_input).strip() if transcript_input else ""

        # 2. Section 10: Empty transcript check -> DO NOT call Ollama
        if not raw_text:
            return ChatbotResponse(
                text="",
                success=False,
                model=getattr(self.client, "model_name", self.config.model_name),
                latency_ms=0.0,
                status="NO_INPUT",
                error="Empty transcript provided; inference skipped.",
            )

        # 3. Prompt construction with injection resistance
        messages = PromptTemplateRegistry.build_chat_messages(
            transcript=raw_text,
            conversation_history=self._history,
            system_prompt=self.config.system_prompt,
        )

        start_time = time.perf_counter()
        model_name = getattr(self.client, "model_name", self.config.model_name)

        try:
            chat_result = await self.client.chat(messages)
            latency_ms = (time.perf_counter() - start_time) * 1000.0

            raw_reply = chat_result.get("message", {}).get("content", "")
            clean_reply = self.handle_success(raw_reply)

            if not clean_reply:
                fallback_msg = self.handle_fallback(raw_text, error_context="Empty Response")
                return ChatbotResponse(
                    text=fallback_msg,
                    success=False,
                    model=model_name,
                    latency_ms=latency_ms,
                    status="EMPTY_RESPONSE",
                    error="Ollama returned an empty message content.",
                )

            # Record in bounded conversation history
            self._append_history("user", raw_text)
            self._append_history("assistant", clean_reply)

            return ChatbotResponse(
                text=clean_reply,
                success=True,
                model=model_name,
                latency_ms=latency_ms,
                status="SUCCESS",
            )

        except OllamaTimeoutError as e:
            latency_ms = (time.perf_counter() - start_time) * 1000.0
            fallback = self.handle_fallback(raw_text, error_context="Timeout")
            return ChatbotResponse(
                text=fallback,
                success=False,
                model=model_name,
                latency_ms=latency_ms,
                status="TIMEOUT",
                error=str(e),
            )

        except OllamaModelUnavailableError as e:
            latency_ms = (time.perf_counter() - start_time) * 1000.0
            fallback = self.handle_fallback(raw_text, error_context="Model Unavailable")
            return ChatbotResponse(
                text=fallback,
                success=False,
                model=model_name,
                latency_ms=latency_ms,
                status="MODEL_UNAVAILABLE",
                error=str(e),
            )

        except OllamaUnavailableError as e:
            latency_ms = (time.perf_counter() - start_time) * 1000.0
            fallback = self.handle_fallback(raw_text, error_context="Offline")
            return ChatbotResponse(
                text=fallback,
                success=False,
                model=model_name,
                latency_ms=latency_ms,
                status="UNAVAILABLE",
                error=str(e),
            )

        except Exception as e:
            latency_ms = (time.perf_counter() - start_time) * 1000.0
            fallback = self.handle_fallback(raw_text, error_context="Error")
            return ChatbotResponse(
                text=fallback,
                success=False,
                model=model_name,
                latency_ms=latency_ms,
                status="ERROR",
                error=str(e),
            )

    def process_transcript_sync(
        self, transcript_input: Union[str, Transcript]
    ) -> ChatbotResponse:
        """Synchronous wrapper for process_transcript."""
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            # If already running inside an active loop (e.g. pytest-asyncio)
            # Use task or threadpool
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                future = pool.submit(asyncio.run, self.process_transcript(transcript_input))
                return future.result()
        else:
            return asyncio.run(self.process_transcript(transcript_input))
