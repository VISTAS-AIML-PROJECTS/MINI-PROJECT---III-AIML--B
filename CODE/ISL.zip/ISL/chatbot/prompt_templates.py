"""SIGNVISION Chatbot - Prompt Templates Contract.

Defines standardized, injection-resistant prompt templates for sign transcript
conversational assistance and gloss translation. Strictly isolates system
instructions from untrusted user transcript content.
"""

from typing import Dict, List, Optional


class PromptTemplateRegistry:
    """Factory and registry for prompt construction and system instruction management."""

    DEFAULT_SYSTEM_PROMPT = (
        "You are the conversational assistant for an Indian Sign Language (ISL) communication system. "
        "The text you receive is a transcript produced by a sign-recognition pipeline and may contain "
        "imperfect or non-standard English phrasing or recognition errors. "
        "Respond naturally, concisely, and helpfully based only on the user's message. "
        "Preserve the user's intended meaning where reasonably obvious, but do not invent facts. "
        "Do not explain the recognition pipeline or internal mechanics unless asked. "
        "If the user message is ambiguous, clarify politely rather than assuming certainty."
    )

    @classmethod
    def get_system_prompt(cls) -> str:
        """Return the immutable default system prompt for the ISL assistant."""
        return cls.DEFAULT_SYSTEM_PROMPT

    @staticmethod
    def build_user_message(transcript: str) -> str:
        """Format the recognized transcript as structured, isolated user content.

        Prevents system prompt alteration and mitigates prompt injection by treating
        the entire transcript as user data.
        """
        clean_text = transcript.strip() if transcript else ""
        return (
            f"User signed transcript: \"{clean_text}\"\n"
            "Please provide a natural, concise conversational response."
        )

    @classmethod
    def build_chat_messages(
        cls,
        transcript: str,
        conversation_history: Optional[List[Dict[str, str]]] = None,
        system_prompt: Optional[str] = None,
    ) -> List[Dict[str, str]]:
        """Construct structured multi-turn message payload for Ollama /api/chat.

        System prompt is strictly maintained at role 'system', and user transcript
        is passed as role 'user', guaranteeing injection resistance.
        """
        sys_content = system_prompt or cls.DEFAULT_SYSTEM_PROMPT
        messages: List[Dict[str, str]] = [{"role": "system", "content": sys_content}]

        if conversation_history:
            for turn in conversation_history:
                role = turn.get("role", "user")
                content = turn.get("content", "")
                if role in ("user", "assistant") and content:
                    messages.append({"role": role, "content": content})

        messages.append({"role": "user", "content": cls.build_user_message(transcript)})
        return messages

    @staticmethod
    def build_gloss_translation_prompt(gloss_string: str) -> str:
        """Legacy helper: create prompt instructing LLM to convert ISL glosses into English."""
        return (
            f"The following is an Indian Sign Language (ISL) gloss transcript: \"{gloss_string}\".\n"
            "Translate this transcript into a natural, grammatically correct English sentence.\n"
            "Respond ONLY with the translated English sentence, with no extraneous commentary."
        )

    @staticmethod
    def build_chat_prompt(conversation_history: List[Dict[str, str]], current_message: str) -> str:
        """Legacy helper: format multi-turn text prompt."""
        history_lines = [f"{turn['role'].capitalize()}: {turn['content']}" for turn in conversation_history]
        history_block = "\n".join(history_lines)
        return (
            f"{history_block}\nUser: {current_message}\nAssistant:"
            if history_block else f"User: {current_message}\nAssistant:"
        )
