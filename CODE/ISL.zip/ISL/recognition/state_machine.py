"""SIGNVISION Recognition - State Machine.

Defines the interface and concrete RecognitionStateMachine for tracking
signing interaction lifecycle (IDLE -> PREPARATION -> ACTIVE -> CONFIRMED -> UNKNOWN).
"""

from abc import ABC, abstractmethod
from typing import Optional
from common.types import FilteredToken, LandmarkFrame, SignState


class RecognitionStateMachineProtocol(ABC):
    """Abstract interface for managing sign recognition lifecycle states."""

    @abstractmethod
    def update(
        self,
        landmark_frame: LandmarkFrame,
        filtered_token: Optional[FilteredToken],
        timestamp_ns: int
    ) -> SignState:
        """Update system state based on presence of hands and filtered tokens."""
        pass

    @abstractmethod
    def get_state(self) -> SignState:
        """Return the current system state."""
        pass

    @abstractmethod
    def reset(self) -> None:
        """Force system back to IDLE state."""
        pass


from common.config import RecognitionConfig


class RecognitionStateMachine(RecognitionStateMachineProtocol):
    """Concrete state machine governing recognition lifecycle.

    Lifecycle:
        IDLE -> OBSERVING/PREPARATION -> CANDIDATE/ACTIVE -> CONFIRMED -> COOLDOWN -> IDLE/ACTIVE
    """

    def __init__(
        self,
        preparation_frames: int = 2,
        cooldown_frames: int = 5,
        use_observing_nomenclature: bool = False,
    ) -> None:
        self.preparation_frames = preparation_frames
        self.cooldown_frames = cooldown_frames
        self.use_observing_nomenclature = use_observing_nomenclature
        self._state: SignState = SignState.IDLE
        self._hands_present_count: int = 0
        self._cooldown_counter: int = 0

    @classmethod
    def from_config(cls, config: RecognitionConfig) -> "RecognitionStateMachine":
        use_observing = getattr(config, "use_observing_nomenclature", True)
        return cls(
            preparation_frames=2,
            cooldown_frames=5,
            use_observing_nomenclature=use_observing,
        )

    @property
    def is_cooling_down(self) -> bool:
        return self._state == SignState.COOLDOWN

    def can_emit(self) -> bool:
        return self._state != SignState.COOLDOWN

    def update(
        self,
        landmark_frame: Optional[LandmarkFrame],
        filtered_token: Optional[FilteredToken],
        timestamp_ns: int,
    ) -> SignState:
        """Advance the state machine given the current observation."""
        has_hands = landmark_frame is not None and landmark_frame.has_any_hand
        has_pose = landmark_frame is not None and landmark_frame.has_pose
        is_tracked = has_hands or has_pose

        if not is_tracked:
            self._state = SignState.IDLE
            self._hands_present_count = 0
            self._cooldown_counter = 0
            return self._state

        # Pose tracking is sufficient to preserve lifecycle state while hand landmarks
        # are temporarily unavailable during a dynamic sign.
        self._hands_present_count += 1

        # 1. Transitions from CONFIRMED -> enter COOLDOWN on subsequent frame
        if self._state == SignState.CONFIRMED:
            self._state = SignState.COOLDOWN
            self._cooldown_counter = max(1, self.cooldown_frames - 1)
            return self._state

        # 2. If currently in COOLDOWN, decrement counter and suppress tokens
        if self._state == SignState.COOLDOWN:
            self._cooldown_counter -= 1
            if self._cooldown_counter <= 0:
                self._state = (
                    SignState.CANDIDATE
                    if self.use_observing_nomenclature
                    else SignState.ACTIVE
                )
            return self._state

        # 3. If token confirmed and not in cooldown, transition to CONFIRMED
        if filtered_token is not None:
            self._state = SignState.CONFIRMED
            self._cooldown_counter = self.cooldown_frames
            return self._state

        # 4. Transitions from IDLE
        if self._state == SignState.IDLE:
            self._state = (
                SignState.OBSERVING
                if self.use_observing_nomenclature
                else SignState.PREPARATION
            )
            return self._state

        # 5. Transitions from OBSERVING / PREPARATION
        if self._state in (SignState.PREPARATION, SignState.OBSERVING):
            if self._hands_present_count >= self.preparation_frames:
                self._state = (
                    SignState.CANDIDATE
                    if self.use_observing_nomenclature
                    else SignState.ACTIVE
                )
            return self._state

        return self._state

    def get_state(self) -> SignState:
        return self._state

    def reset(self) -> None:
        self._state = SignState.IDLE
        self._hands_present_count = 0
        self._cooldown_counter = 0
