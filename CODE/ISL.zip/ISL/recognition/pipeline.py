"""SIGNVISION Recognition - Integrated Recognition Pipeline.

Coordinates the end-to-end recognition flow:
LandmarkFrame -> Canonicalization -> Engine Router -> Static/Dynamic Inference
-> Confidence Gate -> Temporal Filter -> State Machine -> RecognitionEvent.

Architectural Boundaries:
- Imports only from common, preprocessing, static_engine, dynamic_engine, and recognition.
- Strictly decoupled from chatbot, Ollama, UI, and text processing.
"""

import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union
import numpy as np

from common.config import RecognitionConfig, StaticEngineConfig, DynamicEngineConfig
from common.exceptions import (
    ModelError,
    ModelNotLoadedError,
    InvalidFeatureShapeError,
    InvalidSequenceLengthError,
)
from common.types import (
    EngineType,
    FilteredToken,
    GatedPrediction,
    GatingStatus,
    LandmarkFrame,
    LandmarkPoint,
    PredictionResult,
    RecognitionEvent,
    RecognitionMode,
    SignState,
)
from preprocessing.canonicalizer import (
    LandmarkCanonicalizer,
    LandmarkPreprocessingPipeline,
)
from preprocessing.normalizer import NormalizerProtocol, CropSpaceNormalizer
from preprocessing.temporal_window import SlidingTemporalWindow
from static_engine.base import StaticClassifierProtocol, SklearnStaticClassifier
from dynamic_engine.base import DynamicClassifierProtocol, SklearnDynamicClassifier
from recognition.router import EngineRouterProtocol, EngineRouter
from recognition.confidence_gate import ConfidenceGateProtocol, ConfidenceGate
from recognition.temporal_filter import TemporalFilterProtocol, TemporalFilter
from recognition.state_machine import (
    RecognitionStateMachineProtocol,
    RecognitionStateMachine,
)


class RecognitionPipeline:
    """Integrated recognition coordinator for static and dynamic ISL gestures."""

    def __init__(
        self,
        static_classifier: Optional[StaticClassifierProtocol] = None,
        dynamic_classifier: Optional[DynamicClassifierProtocol] = None,
        router: Optional[EngineRouterProtocol] = None,
        confidence_gate: Optional[ConfidenceGateProtocol] = None,
        temporal_filter: Optional[TemporalFilterProtocol] = None,
        state_machine: Optional[RecognitionStateMachineProtocol] = None,
        dynamic_buffer: Optional[SlidingTemporalWindow] = None,
        canonicalizer: Optional[LandmarkCanonicalizer] = None,
        normalizer: Optional[NormalizerProtocol] = None,
        static_class_names: Optional[List[str]] = None,
        dynamic_class_names: Optional[List[str]] = None,
        config: Optional[RecognitionConfig] = None,
    ) -> None:
        self.config = config or RecognitionConfig()
        self.static_classifier = static_classifier
        self.dynamic_classifier = dynamic_classifier
        self.router = router or EngineRouter.from_config(self.config)
        self.confidence_gate = confidence_gate or ConfidenceGate.from_config(self.config)
        self.temporal_filter = temporal_filter or TemporalFilter.from_config(self.config)
        self.state_machine = state_machine or RecognitionStateMachine.from_config(self.config)
        self.canonicalizer = canonicalizer or LandmarkCanonicalizer()
        self.normalizer = normalizer

        # Dynamic temporal buffer
        if dynamic_buffer is not None:
            self.dynamic_buffer = dynamic_buffer
        else:
            dyn_cfg = DynamicEngineConfig()
            self.dynamic_buffer = SlidingTemporalWindow(
                sequence_length=dyn_cfg.sequence_length,
                decimation_factor=dyn_cfg.webcam_decimation_factor,
                inference_stride=dyn_cfg.inference_stride,
            )

        self.static_class_names = (
            list(static_class_names)
            if static_class_names is not None
            else (getattr(static_classifier, "class_names", None) or [])
        )
        self.dynamic_class_names = (
            list(dynamic_class_names)
            if dynamic_class_names is not None
            else (getattr(dynamic_classifier, "class_names", None) or [])
        )

        # Internal kinematic tracking
        self._prev_wrist_coords: Optional[Tuple[Optional[Tuple[float, float, float]], Optional[Tuple[float, float, float]]]] = None
        self._motion_history: List[float] = []
        self._unknown_frame_count: int = 0
        self._static_frame_count: int = 0
        self._last_timings: Dict[str, float] = {}

        # Dynamic pipeline diagnostic telemetry
        self._last_engine_type: str = EngineType.UNKNOWN.value
        self._last_motion_magnitude: float = 0.0
        self._dynamic_infer_count: int = 0
        self._last_buffer_reset_reason: Optional[str] = None

    @classmethod
    def from_artifacts(
        cls,
        static_model_path: Union[str, Path] = Path("models/static/dataset1_static_classifier.joblib"),
        dynamic_model_path: Union[str, Path] = Path("models/dynamic/dataset2_dynamic_classifier.joblib"),
        config: Optional[RecognitionConfig] = None,
    ) -> "RecognitionPipeline":
        """Factory instantiating and loading verified production model artifacts."""
        cfg = config or RecognitionConfig()

        static_clf = None
        s_path = Path(static_model_path)
        if s_path.exists():
            static_clf = SklearnStaticClassifier().load(s_path)

        dynamic_clf = None
        d_path = Path(dynamic_model_path)
        if d_path.exists():
            dynamic_clf = SklearnDynamicClassifier().load(d_path)

        return cls(
            static_classifier=static_clf,
            dynamic_classifier=dynamic_clf,
            config=cfg,
        )

    def _compute_motion_magnitude(self, landmark_frame: Optional[LandmarkFrame]) -> float:
        """Compute Euclidean displacement of wrist keypoints between consecutive frames."""
        if landmark_frame is None:
            self._prev_wrist_coords = None
            self._motion_history.clear()
            return 0.0

        curr_left: Optional[Tuple[float, float, float]] = None
        curr_right: Optional[Tuple[float, float, float]] = None

        if landmark_frame.left_hand is not None and landmark_frame.left_hand.is_present:
            lm = landmark_frame.left_hand.landmarks[0]
            curr_left = (lm.x, lm.y, lm.z)
        if landmark_frame.right_hand is not None and landmark_frame.right_hand.is_present:
            lm = landmark_frame.right_hand.landmarks[0]
            curr_right = (lm.x, lm.y, lm.z)

        # Fallback to pose wrists if hand landmarks not detected
        if curr_left is None and landmark_frame.pose is not None and landmark_frame.pose.is_present:
            if len(landmark_frame.pose.landmarks) > 15:
                plm = landmark_frame.pose.landmarks[15]
                curr_left = (plm.x, plm.y, plm.z)
        if curr_right is None and landmark_frame.pose is not None and landmark_frame.pose.is_present:
            if len(landmark_frame.pose.landmarks) > 16:
                prm = landmark_frame.pose.landmarks[16]
                curr_right = (prm.x, prm.y, prm.z)

        displacements: List[float] = []
        if self._prev_wrist_coords is not None:
            prev_left, prev_right = self._prev_wrist_coords
            if curr_left is not None and prev_left is not None:
                dx = curr_left[0] - prev_left[0]
                dy = curr_left[1] - prev_left[1]
                dz = curr_left[2] - prev_left[2]
                displacements.append(float(np.sqrt(dx * dx + dy * dy + dz * dz)))
            if curr_right is not None and prev_right is not None:
                dx = curr_right[0] - prev_right[0]
                dy = curr_right[1] - prev_right[1]
                dz = curr_right[2] - prev_right[2]
                displacements.append(float(np.sqrt(dx * dx + dy * dy + dz * dz)))

        self._prev_wrist_coords = (curr_left, curr_right)
        inst_disp = max(displacements) if displacements else 0.0
        self._motion_history.append(inst_disp)
        if len(self._motion_history) > 4:
            self._motion_history.pop(0)
        return max(self._motion_history) if self._motion_history else 0.0

    def _compute_sequence_motion(self, seq: np.ndarray) -> float:
        """Compute the maximum wrist kinematic motion (displacement or velocity) in the sequence.

        Grounded in Dataset 2 empirical distribution (training signs have displacement >= 0.315
        and peak velocity >= 0.113, whereas idle/stationary postures exhibit motion < 0.035).
        """
        if seq is None or len(seq) == 0:
            return 0.0

        dim = seq.shape[-1]
        wrist_trajectories: List[np.ndarray] = []

        if dim == 168:
            # Pose wrists (robust even when hand palm tracker fails)
            wrist_trajectories.append(seq[:, 141:144])  # Left pose wrist
            wrist_trajectories.append(seq[:, 144:147])  # Right pose wrist
            # Hand wrists if present
            wrist_trajectories.append(seq[:, 0:3])      # Left hand wrist
            wrist_trajectories.append(seq[:, 63:66])    # Right hand wrist
        elif dim in (45, 39):
            wrist_trajectories.append(seq[:, 15:18])    # Left pose wrist
            wrist_trajectories.append(seq[:, 18:21])    # Right pose wrist

        max_motion = 0.0
        for w in wrist_trajectories:
            if np.any(np.abs(w) > 1e-5):
                disp = float(np.max(np.linalg.norm(w - w[0], axis=-1)))
                vel = float(np.max(np.linalg.norm(np.diff(w, axis=0), axis=-1))) if len(w) > 1 else 0.0
                max_motion = max(max_motion, disp, vel)

        return max_motion

    def process_frame(
        self,
        landmark_frame: Optional[LandmarkFrame],
        timestamp_ns: Optional[int] = None,
    ) -> Optional[RecognitionEvent]:
        """Process a single LandmarkFrame through the full recognition pipeline.

        Returns:
            Optional[RecognitionEvent]: Emitted recognition event if a sign reaches CONFIRMED state.
        """
        t_total_start = time.perf_counter()
        t_now_ns = (
            timestamp_ns
            if timestamp_ns is not None
            else (
                landmark_frame.timestamp_ns
                if landmark_frame is not None and getattr(landmark_frame, "timestamp_ns", None) is not None
                else time.time_ns()
            )
        )

        # 1. Motion & Input Quality
        motion_mag = self._compute_motion_magnitude(landmark_frame)
        self._last_motion_magnitude = float(motion_mag)

        # 2. Router
        t_router_start = time.perf_counter()
        engine_type = self.router.route(landmark_frame, recent_motion_magnitude=motion_mag)
        t_router_end = time.perf_counter()
        self._last_timings["router_ms"] = (t_router_end - t_router_start) * 1000.0
        self._last_engine_type = engine_type.value

        # If insufficient evidence or UNKNOWN, update state machine with None and clear stale prediction telemetry
        if engine_type == EngineType.UNKNOWN or landmark_frame is None or not (landmark_frame.has_any_hand or landmark_frame.has_pose):
            self.temporal_filter.reset()
            if landmark_frame is None or not (landmark_frame.has_any_hand or landmark_frame.has_pose):
                if hasattr(self.confidence_gate, "reset"):
                    self.confidence_gate.reset()
                self._last_buffer_reset_reason = "tracking_lost"
                self.dynamic_buffer.reset()
                self._motion_history.clear()
                self._unknown_frame_count = 0
            elif engine_type == EngineType.UNKNOWN:
                self._unknown_frame_count += 1
                if self._unknown_frame_count >= 5:
                    self._last_buffer_reset_reason = "engine_unknown"
                    self.dynamic_buffer.reset()
            else:
                self._last_buffer_reset_reason = "other"
                self.dynamic_buffer.reset()
            self.state_machine.update(landmark_frame, None, t_now_ns)
            self._last_timings["total_ms"] = (time.perf_counter() - t_total_start) * 1000.0
            return None

        self._unknown_frame_count = 0

        # 3. Canonicalize Frame
        canonical_vector = self.canonicalizer.canonicalize(landmark_frame)

        prediction: Optional[PredictionResult] = None

        # 4. Engine Branching
        if engine_type == EngineType.STATIC:
            self._static_frame_count += 1
            if self._static_frame_count >= 5 and len(self.dynamic_buffer._buffer) > 0:
                self.dynamic_buffer.reset()
                self._last_buffer_reset_reason = "engine_static"
            if self.static_classifier is None:
                raise ModelNotLoadedError("Static classifier requested but not loaded.")
            # Keep static inference on the trained canonical feature layout unless a caller explicitly
            # chooses to feed a different normalized representation.
            static_vector = (
                self.normalizer.transform(canonical_vector)
                if self.normalizer is not None
                else canonical_vector
            )
            t_infer_start = time.perf_counter()
            prediction = self.static_classifier.infer(static_vector, self.static_class_names)
            self._last_timings["inference_ms"] = (time.perf_counter() - t_infer_start) * 1000.0

        elif engine_type == EngineType.DYNAMIC:
            self._static_frame_count = 0
            # Ingest frame into dynamic temporal sequence buffer
            self.dynamic_buffer.append(canonical_vector, t_now_ns)

            if self.dynamic_buffer.is_full and self.dynamic_buffer.should_infer():
                if self.dynamic_classifier is None:
                    raise ModelNotLoadedError("Dynamic classifier requested but not loaded.")
                seq = self.dynamic_buffer.get_sequence(pad_if_incomplete=False)

                # Kinematic sequence motion gate (grounded in Dataset 2 feature distribution)
                seq_motion = self._compute_sequence_motion(seq)
                if seq_motion < self.config.motion_threshold:
                    # Reject stationary sequence during idle/neutral posture to prevent spurious classifications
                    self.state_machine.update(landmark_frame, None, t_now_ns)
                    self._last_timings["total_ms"] = (time.perf_counter() - t_total_start) * 1000.0
                    return None

                t_infer_start = time.perf_counter()
                self._dynamic_infer_count += 1
                prediction = self.dynamic_classifier.infer(seq, self.dynamic_class_names)
                self._last_timings["inference_ms"] = (time.perf_counter() - t_infer_start) * 1000.0
            else:
                # Dynamic sequence buffer not yet full -> no inference
                self.state_machine.update(landmark_frame, None, t_now_ns)
                self._last_timings["total_ms"] = (time.perf_counter() - t_total_start) * 1000.0
                return None

        # 5. Confidence Gate
        t_gate_start = time.perf_counter()
        gated = self.confidence_gate.evaluate(prediction)
        self._last_timings["gate_ms"] = (time.perf_counter() - t_gate_start) * 1000.0

        # 6. Temporal Filter
        t_filter_start = time.perf_counter()
        filtered_token: Optional[FilteredToken] = None
        if gated.status == GatingStatus.ACCEPT:
            filtered_token = self.temporal_filter.filter(gated, t_now_ns)
        else:
            self.temporal_filter.filter(gated, t_now_ns)  # Reset debouncing history on unaccepted frames
        self._last_timings["filter_ms"] = (time.perf_counter() - t_filter_start) * 1000.0

        # 7. State Machine Lifecycle
        t_sm_start = time.perf_counter()
        current_state = self.state_machine.update(landmark_frame, filtered_token, t_now_ns)
        self._last_timings["state_machine_ms"] = (time.perf_counter() - t_sm_start) * 1000.0

        # 8. Token Confirmation Event
        event: Optional[RecognitionEvent] = None
        if current_state == SignState.CONFIRMED and filtered_token is not None:
            event = RecognitionEvent(
                label=filtered_token.token,
                confidence=filtered_token.confidence,
                engine=filtered_token.engine,
                timestamp_ns=t_now_ns,
                frame_index=landmark_frame.frame_index if landmark_frame else None,
                margin=prediction.margin if prediction else None,
                metadata={
                    "motion_magnitude": motion_mag,
                    "engine_type": engine_type.value,
                },
            )
        self._last_timings["total_ms"] = (time.perf_counter() - t_total_start) * 1000.0
        return event

    def reset(self) -> None:
        """Reset internal buffers, debouncers, and state machine."""
        self._last_buffer_reset_reason = "pipeline_reset"
        self.dynamic_buffer.reset()
        self.temporal_filter.reset()
        self.state_machine.reset()
        if hasattr(self.confidence_gate, "reset"):
            self.confidence_gate.reset()
        self._prev_wrist_coords = None
        self._motion_history.clear()
        self._unknown_frame_count = 0
        self._static_frame_count = 0

    def get_last_timings(self) -> Dict[str, float]:
        """Return runtime profiling overheads in milliseconds."""
        return dict(self._last_timings)

    def get_debug_telemetry(self) -> Dict[str, Any]:
        """Return diagnostic telemetry for dynamic recognition pipeline inspection."""
        buf = getattr(self.dynamic_buffer, "_buffer", None)
        buf_len = len(buf) if buf is not None else 0
        buf_full = bool(getattr(self.dynamic_buffer, "is_full", False))
        return {
            "router_engine": self._last_engine_type,
            "motion_magnitude": round(float(self._last_motion_magnitude), 4),
            "buffer_len": buf_len,
            "buffer_is_full": buf_full,
            "dynamic_infer_count": int(self._dynamic_infer_count),
            "last_buffer_reset_reason": self._last_buffer_reset_reason,
        }
