"""SIGNVISION Recognition - Temporal Filter.

Defines the interface and concrete TemporalFilter for debouncing predictions
and suppressing immediate duplicates within a cooldown window.
"""

from abc import ABC, abstractmethod
from typing import Optional
from common.types import FilteredToken, GatedPrediction, EngineType
from common.config import RecognitionConfig


class TemporalFilterProtocol(ABC):
    """Abstract interface for temporal stability filtering and debouncing."""

    @abstractmethod
    def filter(self, gated_prediction: GatedPrediction, timestamp_ns: int) -> Optional[FilteredToken]:
        """Apply debouncing and duplicate suppression."""
        pass

    @abstractmethod
    def reset(self) -> None:
        """Clear filter history and debouncing counter."""
        pass


class TemporalFilter(TemporalFilterProtocol):
    """Concrete temporal debouncing and duplicate suppression filter."""

    def __init__(
        self,
        debounce_count: int = 4,
        suppression_window_seconds: float = 1.0,
    ) -> None:
        self.debounce_count = debounce_count
        self.suppression_window_ns = int(suppression_window_seconds * 1_000_000_000)

        self._current_candidate: Optional[str] = None
        self._consecutive_count: int = 0
        self._last_confirmed_token: Optional[str] = None
        self._last_confirmed_timestamp_ns: int = 0

    @classmethod
    def from_config(cls, config: RecognitionConfig) -> "TemporalFilter":
        return cls(
            debounce_count=config.debounce_frame_count,
            suppression_window_seconds=config.suppression_window_seconds,
        )

    def filter(self, gated_prediction: GatedPrediction, timestamp_ns: int) -> Optional[FilteredToken]:
        """Evaluate consecutive candidate stability and release token if debounced."""
        if gated_prediction is None or not gated_prediction.is_accepted:
            # Reset consecutive count if prediction is rejected or unknown
            self._current_candidate = None
            self._consecutive_count = 0
            return None

        token_name = gated_prediction.sign_name

        # 1. Update debounce counter
        if token_name == self._current_candidate:
            self._consecutive_count += 1
        else:
            self._current_candidate = token_name
            self._consecutive_count = 1

        # 2. Check if debounce threshold reached
        target_debounce = 1 if gated_prediction.engine == EngineType.DYNAMIC else self.debounce_count
        if self._consecutive_count >= target_debounce:
            # Check duplicate suppression cooldown
            time_since_last = timestamp_ns - self._last_confirmed_timestamp_ns
            if (
                token_name == self._last_confirmed_token
                and time_since_last < self.suppression_window_ns
            ):
                return None  # Suppressed duplicate within cooldown

            # Confirm and release token
            self._last_confirmed_token = token_name
            self._last_confirmed_timestamp_ns = timestamp_ns
            return FilteredToken(
                token=token_name,
                engine=gated_prediction.engine,
                timestamp_ns=timestamp_ns,
                confidence=gated_prediction.confidence,
            )

        return None

    def reset(self) -> None:
        """Clear internal tracking state."""
        self._current_candidate = None
        self._consecutive_count = 0
        self._last_confirmed_token = None
        self._last_confirmed_timestamp_ns = 0
