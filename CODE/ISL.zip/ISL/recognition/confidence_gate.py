"""SIGNVISION Recognition - Confidence Gate.

Defines the interface and concrete ConfidenceGate for filtering out
low-confidence or ambiguous classifications before token confirmation.
"""

from abc import ABC, abstractmethod
from typing import Optional
from common.types import EngineType, PredictionResult, GatedPrediction, GatingStatus
from common.config import RecognitionConfig


class ConfidenceGateProtocol(ABC):
    """Abstract interface for prediction confidence and margin validation."""

    @abstractmethod
    def evaluate(self, prediction: PredictionResult) -> GatedPrediction:
        """Validate raw model predictions against configured thresholds."""
        pass

    @abstractmethod
    def update_thresholds(
        self,
        confidence_threshold: float,
        margin_threshold: float,
        dynamic_threshold: Optional[float] = None,
    ) -> None:
        """Dynamically reconfigure gating thresholds."""
        pass

    @abstractmethod
    def get_last_prediction(self) -> Optional[GatedPrediction]:
        """Return the most recently evaluated gated prediction."""
        pass

    @abstractmethod
    def reset(self) -> None:
        """Reset internal prediction state."""
        pass


class ConfidenceGate(ConfidenceGateProtocol):
    """Concrete confidence and margin gate.
    
    Distinguishes three gating states:
    - ACCEPT: High confidence and decisive margin.
    - UNCERTAIN: Borderline confidence or low margin between top classes.
    - REJECT: Low confidence, empty distributions, or invalid predictions.
    """

    UNKNOWN_TOKEN = "UNKNOWN_SIGN"

    def __init__(
        self,
        static_threshold: float = 0.70,
        dynamic_threshold: float = 0.40,
        margin_threshold: float = 0.10,
    ) -> None:
        self.static_threshold = static_threshold
        self.dynamic_threshold = dynamic_threshold
        self.margin_threshold = margin_threshold
        self._last_prediction: Optional[GatedPrediction] = None

    @classmethod
    def from_config(cls, config: RecognitionConfig) -> "ConfidenceGate":
        return cls(
            static_threshold=config.static_confidence_threshold,
            dynamic_threshold=config.dynamic_confidence_threshold,
            margin_threshold=config.top_margin_threshold,
        )

    def evaluate(self, prediction: Optional[PredictionResult]) -> GatedPrediction:
        """Evaluate prediction validity and assign GatingStatus."""
        if prediction is None or not isinstance(prediction, PredictionResult):
            self._last_prediction = GatedPrediction(
                is_accepted=False,
                sign_name=self.UNKNOWN_TOKEN,
                confidence=0.0,
                margin=0.0,
                engine=EngineType.UNKNOWN,
                rejection_reason="Invalid or missing PredictionResult object.",
                status=GatingStatus.REJECT,
            )
            return self._last_prediction

        threshold = (
            self.static_threshold
            if prediction.engine == EngineType.STATIC
            else self.dynamic_threshold
        )

        # 1. Check probability validity
        if prediction.probabilities is None or len(prediction.probabilities) == 0:
            self._last_prediction = GatedPrediction(
                is_accepted=False,
                sign_name=self.UNKNOWN_TOKEN,
                confidence=prediction.confidence,
                margin=prediction.margin,
                engine=prediction.engine,
                rejection_reason="Empty probability distribution.",
                status=GatingStatus.REJECT,
            )
            return self._last_prediction

        # 2. Check confidence threshold
        if prediction.confidence < threshold:
            # If severely below threshold, mark as REJECT; if borderline, mark as UNCERTAIN
            status = GatingStatus.REJECT if prediction.confidence < (0.7 * threshold) else GatingStatus.UNCERTAIN
            self._last_prediction = GatedPrediction(
                is_accepted=False,
                sign_name=self.UNKNOWN_TOKEN,
                confidence=prediction.confidence,
                margin=prediction.margin,
                engine=prediction.engine,
                rejection_reason=f"Confidence {prediction.confidence:.3f} below threshold {threshold:.3f}.",
                status=status,
            )
            return self._last_prediction

        # 3. Check top margin threshold
        if prediction.margin < self.margin_threshold:
            self._last_prediction = GatedPrediction(
                is_accepted=False,
                sign_name=self.UNKNOWN_TOKEN,
                confidence=prediction.confidence,
                margin=prediction.margin,
                engine=prediction.engine,
                rejection_reason=f"Margin {prediction.margin:.3f} below threshold {self.margin_threshold:.3f}.",
                status=GatingStatus.UNCERTAIN,
            )
            return self._last_prediction

        # Accepted
        result = GatedPrediction(
            is_accepted=True,
            sign_name=prediction.class_name,
            confidence=prediction.confidence,
            margin=prediction.margin,
            engine=prediction.engine,
            rejection_reason=None,
            status=GatingStatus.ACCEPT,
        )
        self._last_prediction = result
        return result

    def get_last_prediction(self) -> Optional[GatedPrediction]:
        """Return the most recently evaluated gated prediction."""
        return self._last_prediction

    def reset(self) -> None:
        """Clear last evaluated prediction."""
        self._last_prediction = None

    def update_thresholds(
        self,
        confidence_threshold: float,
        margin_threshold: float,
        dynamic_threshold: Optional[float] = None,
    ) -> None:
        self.static_threshold = confidence_threshold
        self.dynamic_threshold = dynamic_threshold if dynamic_threshold is not None else confidence_threshold
        self.margin_threshold = margin_threshold

