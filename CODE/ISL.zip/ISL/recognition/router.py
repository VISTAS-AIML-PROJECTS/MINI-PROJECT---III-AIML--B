"""SIGNVISION Recognition - Engine Router.

Defines the interface and concrete EngineRouter for directing processing
to either Static Engine (alphabet) or Dynamic Engine (phrase/word).
"""

from abc import ABC, abstractmethod
from typing import Optional
from common.types import EngineType, RecognitionMode, LandmarkFrame


from common.config import RecognitionConfig


class EngineRouterProtocol(ABC):
    """Abstract interface for engine routing decisions."""

    @abstractmethod
    def route(
        self,
        landmark_frame: Optional[LandmarkFrame],
        recent_motion_magnitude: float,
    ) -> EngineType:
        """Determine which recognition engine should process the current observation."""
        pass

    @abstractmethod
    def set_mode(self, mode: RecognitionMode) -> None:
        """Update the active routing mode."""
        pass

    @abstractmethod
    def get_mode(self) -> RecognitionMode:
        """Return the currently configured routing mode."""
        pass


class EngineRouter(EngineRouterProtocol):
    """Concrete router deciding between STATIC, DYNAMIC, and UNKNOWN recognition states."""

    def __init__(
        self,
        mode: RecognitionMode = RecognitionMode.AUTO,
        motion_threshold: float = 0.035,
    ) -> None:
        self._mode = mode
        self.motion_threshold = motion_threshold

    @classmethod
    def from_config(cls, config: RecognitionConfig) -> "EngineRouter":
        """Initialize EngineRouter directly from RecognitionConfig."""
        mode = getattr(config, "mode", getattr(config, "recognition_mode", RecognitionMode.AUTO))
        return cls(
            mode=mode,
            motion_threshold=config.motion_threshold,
        )

    def route(
        self,
        landmark_frame: Optional[LandmarkFrame] = None,
        recent_motion_magnitude: float = 0.0,
    ) -> EngineType:
        """Select engine based on observable input/state and kinematic motion threshold.

        Routing States:
        - STATIC: Stable single-frame hand landmark input observed with low motion.
        - DYNAMIC: Kinematic motion above threshold observed with valid body/hand landmarks.
        - UNKNOWN: Insufficient evidence (e.g. no hands or resting body with no motion).
        """
        # When explicit landmark frame is provided, evaluate observable evidence
        if landmark_frame is not None:
            has_hands = landmark_frame.has_any_hand
            has_pose = landmark_frame.has_pose

            if not has_hands and not has_pose:
                return EngineType.UNKNOWN

            if self._mode == RecognitionMode.STATIC:
                return EngineType.STATIC if has_hands else EngineType.UNKNOWN

            if self._mode == RecognitionMode.DYNAMIC:
                return EngineType.DYNAMIC if (has_pose or has_hands) else EngineType.UNKNOWN

            # AUTO mode:
            if recent_motion_magnitude > self.motion_threshold:
                return EngineType.DYNAMIC if (has_pose or has_hands) else EngineType.UNKNOWN

            # Low motion:
            if has_hands:
                return EngineType.STATIC

            # Resting posture (pose only, no hands, low motion) -> insufficient static evidence
            return EngineType.UNKNOWN

        # Fallback when landmark_frame is None
        if recent_motion_magnitude == 0.0 and self._mode == RecognitionMode.AUTO:
            return EngineType.UNKNOWN

        if self._mode == RecognitionMode.STATIC:
            return EngineType.STATIC
        if self._mode == RecognitionMode.DYNAMIC:
            return EngineType.DYNAMIC

        if recent_motion_magnitude > self.motion_threshold:
            return EngineType.DYNAMIC
        return EngineType.STATIC

    def set_mode(self, mode: RecognitionMode) -> None:
        self._mode = mode

    def get_mode(self) -> RecognitionMode:
        return self._mode
