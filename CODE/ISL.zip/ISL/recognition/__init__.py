"""SIGNVISION Recognition Package.

Exposes decision layer contracts and concrete implementations for engine routing,
confidence gating, temporal debouncing, and state machine lifecycle.
"""

from recognition.router import EngineRouterProtocol, EngineRouter
from recognition.confidence_gate import ConfidenceGateProtocol, ConfidenceGate
from recognition.temporal_filter import TemporalFilterProtocol, TemporalFilter
from recognition.state_machine import (
    RecognitionStateMachineProtocol,
    RecognitionStateMachine,
)
from recognition.pipeline import RecognitionPipeline

__all__ = [
    "EngineRouterProtocol",
    "EngineRouter",
    "ConfidenceGateProtocol",
    "ConfidenceGate",
    "TemporalFilterProtocol",
    "TemporalFilter",
    "RecognitionStateMachineProtocol",
    "RecognitionStateMachine",
    "RecognitionPipeline",
]
