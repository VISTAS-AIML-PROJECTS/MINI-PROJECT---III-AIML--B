"""SIGNVISION Detection Package.

Exposes perception contracts and concrete implementations for camera streaming,
MediaPipe tracking, and structured landmark extraction.
"""

from detection.camera_stream import CameraStreamProtocol, OpenCVCameraStream
from detection.mediapipe_tracker import MediaPipeTrackerProtocol, MediaPipeTracker
from detection.landmark_extractor import LandmarkExtractorProtocol, LandmarkExtractor

__all__ = [
    "CameraStreamProtocol",
    "OpenCVCameraStream",
    "MediaPipeTrackerProtocol",
    "MediaPipeTracker",
    "LandmarkExtractorProtocol",
    "LandmarkExtractor",
]
