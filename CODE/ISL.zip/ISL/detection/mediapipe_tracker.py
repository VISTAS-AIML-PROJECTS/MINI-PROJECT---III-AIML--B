"""SIGNVISION Detection - MediaPipe Tracker.

Defines the interface and concrete implementation for MediaPipe perception,
tracking up to 2 hands and full body pose on RGB frames.
"""

from abc import ABC, abstractmethod
import sys
from typing import Any, Optional, Tuple
import numpy as np

# Ensure broken tensorflow doc probes do not interfere with mediapipe
if "tensorflow" not in sys.modules:
    sys.modules["tensorflow"] = None
    sys.modules["tensorflow.tools"] = None
    sys.modules["tensorflow.tools.docs"] = None

import mediapipe as mp

from common.config import DetectionConfig
from common.exceptions import InvalidFrameError, LandmarkExtractionError


class MediaPipeTrackerProtocol(ABC):
    """Abstract interface for MediaPipe perception pipelines."""

    @abstractmethod
    def process_frame(self, frame_rgb: np.ndarray) -> Tuple[Any, Any]:
        """Process an RGB frame and return raw MediaPipe Hands and Pose results.
        
        Args:
            frame_rgb: 3-channel RGB image array of shape (H, W, 3).
            
        Returns:
            Tuple[Any, Any]: Raw MediaPipe (hands_result, pose_result) objects.
            
        Raises:
            LandmarkExtractionError: If MediaPipe graph computation fails.
        """
        pass

    @abstractmethod
    def close(self) -> None:
        """Release underlying MediaPipe native graph instances and CPU delegates."""
        pass


class MediaPipeTracker(MediaPipeTrackerProtocol):
    """Concrete MediaPipe perception tracker combining Hands and Pose solutions."""

    def __init__(self, config: Optional[DetectionConfig] = None) -> None:
        self.config = config or DetectionConfig()
        self._mp_hands = mp.solutions.hands
        self._mp_pose = mp.solutions.pose

        self.static_image_mode = getattr(self.config, "static_image_mode", False)
        self.enable_pose = getattr(self.config, "enable_pose", True)
        self.enable_hands = getattr(self.config, "enable_hands", True) and getattr(self.config, "max_num_hands", 2) > 0

        if self.enable_hands:
            self._hands = self._mp_hands.Hands(
                static_image_mode=self.static_image_mode,
                max_num_hands=self.config.max_num_hands,
                min_detection_confidence=self.config.min_hand_detection_confidence,
                min_tracking_confidence=self.config.min_hand_tracking_confidence,
                model_complexity=self.config.model_complexity,
            )
        else:
            self._hands = None

        if self.enable_pose:
            self._pose = self._mp_pose.Pose(
                static_image_mode=self.static_image_mode,
                min_detection_confidence=self.config.min_pose_detection_confidence,
                min_tracking_confidence=self.config.min_pose_tracking_confidence,
                model_complexity=self.config.model_complexity,
            )
        else:
            self._pose = None

        self._is_closed: bool = False

    def process_frame(self, frame_rgb: np.ndarray) -> Tuple[Any, Any]:
        """Execute Hands and Pose tracking on the input RGB frame."""
        if self._is_closed:
            raise LandmarkExtractionError("MediaPipeTracker has already been closed.")

        if frame_rgb is None or not isinstance(frame_rgb, np.ndarray):
            raise InvalidFrameError("Input frame must be a valid NumPy ndarray.")

        if frame_rgb.ndim != 3 or frame_rgb.shape[2] != 3:
            raise InvalidFrameError(
                f"Input frame must have shape (H, W, 3), got {getattr(frame_rgb, 'shape', None)}"
            )

        if frame_rgb.size == 0:
            raise InvalidFrameError("Input frame array is empty.")

        try:
            # Ensure C-contiguous array for MediaPipe C++ bindings
            if not frame_rgb.flags.c_contiguous:
                frame_rgb = np.ascontiguousarray(frame_rgb)

            hands_result = self._hands.process(frame_rgb) if self._hands is not None else None
            pose_result = self._pose.process(frame_rgb) if self._pose is not None else None
            return hands_result, pose_result
        except Exception as e:
            raise LandmarkExtractionError(f"MediaPipe inference failed: {e}") from e

    def close(self) -> None:
        """Release MediaPipe resources."""
        if not self._is_closed:
            self._is_closed = True
            if self._hands is not None:
                self._hands.close()
            if self._pose is not None:
                self._pose.close()

    def release(self) -> None:
        """Alias for close() to ensure consistent resource release semantics."""
        self.close()

    def __enter__(self) -> "MediaPipeTracker":
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self.close()

