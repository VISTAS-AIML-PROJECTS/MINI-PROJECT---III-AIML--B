"""SIGNVISION Detection - Camera Stream.

Defines the interface and concrete OpenCV-based camera stream for video capture,
camera lifecycle management, and timestamped frame acquisition.
"""

from abc import ABC, abstractmethod
import threading
import time
from typing import Any, Optional
import cv2
import numpy as np

from common.types import FrameData
from common.config import CameraConfig
from common.exceptions import (
    CameraUnavailableError,
    InvalidFrameError,
    FrameTimeoutError,
)


class CameraStreamProtocol(ABC):
    """Abstract interface for video capture sources."""

    @abstractmethod
    def start(self) -> None:
        """Initialize and open the video capture hardware.
        
        Raises:
            CameraUnavailableError: If the specified camera index cannot be opened.
        """
        pass

    @abstractmethod
    def read(self) -> FrameData:
        """Capture and return the latest frame with timestamp metadata.
        
        Returns:
            FrameData: Timestamped RGB/BGR frame object.
            
        Raises:
            InvalidFrameError: If the captured frame is empty or corrupt.
            FrameTimeoutError: If reading exceeds timeout threshold.
        """
        pass

    @abstractmethod
    def stop(self) -> None:
        """Safely release the camera hardware resource."""
        pass

    @abstractmethod
    def is_opened(self) -> bool:
        """Check whether the camera capture device is currently active."""
        pass


class OpenCVCameraStream(CameraStreamProtocol):
    """Concrete camera capture stream using OpenCV VideoCapture."""

    def __init__(self, config: Optional[CameraConfig] = None) -> None:
        self.config = config or CameraConfig()
        self._cap: Optional[cv2.VideoCapture] = None
        self._frame_index: int = 0
        self._lock = threading.Lock()
        self._is_running: bool = False

    def start(self) -> None:
        """Open the camera with the configured backend and resolution."""
        with self._lock:
            if self._cap is not None and self._cap.isOpened():
                return

            backend = cv2.CAP_DSHOW if self.config.backend.upper() == "DSHOW" else cv2.CAP_ANY
            self._cap = cv2.VideoCapture(self.config.camera_index, backend)

            if not self._cap.isOpened():
                self._cap.release()
                self._cap = None
                raise CameraUnavailableError(
                    f"Unable to open camera at index {self.config.camera_index} "
                    f"with backend {self.config.backend}."
                )

            self._cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.config.frame_width)
            self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.config.frame_height)
            self._cap.set(cv2.CAP_PROP_FPS, self.config.target_fps)
            self._cap.set(cv2.CAP_PROP_BUFFERSIZE, self.config.buffer_size)

            self._frame_index = 0
            self._is_running = True

    def read(self) -> FrameData:
        """Capture a frame, validate shape, and attach timestamp metadata."""
        with self._lock:
            if not self.is_opened() or self._cap is None:
                raise CameraUnavailableError("Camera is not opened. Call start() before reading.")

            start_t = time.perf_counter()
            ret, frame = self._cap.read()

            if not ret or frame is None or frame.size == 0:
                elapsed = time.perf_counter() - start_t
                if elapsed >= self.config.timeout_seconds:
                    raise FrameTimeoutError(
                        f"Frame read timed out after {elapsed:.2f} seconds."
                    )
                raise InvalidFrameError("Failed to read valid frame from camera.")

            # Training videos are processed without a horizontal flip.
            if getattr(self.config, "mirror_mode", False):
                frame = cv2.flip(frame, 1)

            timestamp_ns = time.time_ns()
            # Convert BGR frame from OpenCV to RGB for MediaPipe and system components
            if frame.ndim == 3 and frame.shape[2] == 3:
                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            else:
                frame_rgb = frame

            frame_data = FrameData(
                frame=frame_rgb,
                timestamp_ns=timestamp_ns,
                frame_index=self._frame_index,
                camera_id=self.config.camera_index,
            )
            self._frame_index += 1
            return frame_data

    def stop(self) -> None:
        """Safely release the camera resource."""
        with self._lock:
            self._is_running = False
            if self._cap is not None:
                self._cap.release()
                self._cap = None

    def release(self) -> None:
        """Alias for stop() to provide standard OpenCV lifecycle compatibility."""
        self.stop()

    def is_opened(self) -> bool:
        """Return True if capture device is actively open."""
        return self._cap is not None and self._cap.isOpened() and self._is_running

    def __enter__(self) -> "OpenCVCameraStream":
        """Context manager entry: starts video capture stream."""
        self.start()
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Context manager exit: deterministically releases camera hardware."""
        self.stop()
