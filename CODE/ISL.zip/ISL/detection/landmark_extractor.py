"""SIGNVISION Detection - Landmark Extractor.

Defines the interface and concrete implementation for converting raw MediaPipe
perception results into structured, strongly typed LandmarkFrame domain objects.
"""

from abc import ABC, abstractmethod
from typing import Any, List, Optional, Tuple
from common.types import (
    FrameData,
    HandLandmarks,
    HandType,
    LandmarkFrame,
    LandmarkPoint,
    PoseLandmarks,
)


class LandmarkExtractorProtocol(ABC):
    """Abstract interface for extracting structured landmark domains."""

    @abstractmethod
    def extract(self, frame_data: FrameData, hands_result: Any, pose_result: Any) -> LandmarkFrame:
        """Convert raw perception outputs into a structured LandmarkFrame.
        
        Preserves individual keypoints, handedness labels, confidence scores,
        and missing hand statuses without prematurely flattening into vectors.
        
        Args:
            frame_data: Original timestamped frame metadata.
            hands_result: Raw result object from MediaPipe Hands.
            pose_result: Raw result object from MediaPipe Pose.
            
        Returns:
            LandmarkFrame: Structured domain representation of all detected landmarks.
        """
        pass


class LandmarkExtractor(LandmarkExtractorProtocol):
    """Concrete landmark extractor producing structured LandmarkFrame instances.

    AUTHORITATIVE HANDEDNESS CONVENTION:
    MediaPipe Hands classifies handedness assuming a selfie/mirrored reference frame:
    - On mirrored streams (assume_mirrored_input=True): 'Right' = physical right hand.
    - On unmirrored streams (assume_mirrored_input=False): 'Right' = physical left hand.
    LandmarkExtractor ensures physical right hand consistently maps to right_hand
    and physical left hand consistently maps to left_hand.
    """

    def __init__(self, assume_mirrored_input: bool = True) -> None:
        self.assume_mirrored_input = assume_mirrored_input

    def extract(self, frame_data: FrameData, hands_result: Any, pose_result: Any) -> LandmarkFrame:
        """Extract structured landmarks from raw MediaPipe Hands and Pose results."""
        left_hand: Optional[HandLandmarks] = None
        right_hand: Optional[HandLandmarks] = None
        pose: Optional[PoseLandmarks] = None

        # 1. Parse Hands
        if hands_result is not None and getattr(hands_result, "multi_hand_landmarks", None):
            landmarks_list = hands_result.multi_hand_landmarks
            handedness_list = getattr(hands_result, "multi_handedness", []) or []

            for idx, hand_lms in enumerate(landmarks_list):
                # Extract label and confidence score
                hand_label = "Unknown"
                confidence = 0.5
                if idx < len(handedness_list) and handedness_list[idx].classification:
                    hand_label = handedness_list[idx].classification[0].label
                    confidence = float(handedness_list[idx].classification[0].score)

                # Convert 21 keypoints
                points: List[LandmarkPoint] = []
                for lm in hand_lms.landmark:
                    points.append(
                        LandmarkPoint(
                            x=float(lm.x),
                            y=float(lm.y),
                            z=float(lm.z),
                            visibility=getattr(lm, "visibility", None),
                            presence=getattr(lm, "presence", None),
                        )
                    )

                # Authoritatively map physical hand based on mirroring reference frame
                if self.assume_mirrored_input:
                    is_physical_right = (hand_label.lower() == "right")
                    is_physical_left = (hand_label.lower() == "left")
                else:
                    is_physical_right = (hand_label.lower() == "left")
                    is_physical_left = (hand_label.lower() == "right")

                if is_physical_left:
                    left_hand = HandLandmarks(
                        hand_type=HandType.LEFT,
                        confidence=confidence,
                        landmarks=tuple(points),
                    )
                elif is_physical_right:
                    right_hand = HandLandmarks(
                        hand_type=HandType.RIGHT,
                        confidence=confidence,
                        landmarks=tuple(points),
                    )
                else:
                    # Fallback if unclassified: assign to first available slot
                    if left_hand is None:
                        left_hand = HandLandmarks(
                            hand_type=HandType.UNKNOWN,
                            confidence=confidence,
                            landmarks=tuple(points),
                        )
                    elif right_hand is None:
                        right_hand = HandLandmarks(
                            hand_type=HandType.UNKNOWN,
                            confidence=confidence,
                            landmarks=tuple(points),
                        )

        # 2. Parse Pose
        if pose_result is not None and getattr(pose_result, "pose_landmarks", None):
            pose_points: List[LandmarkPoint] = []
            for lm in pose_result.pose_landmarks.landmark:
                pose_points.append(
                    LandmarkPoint(
                        x=float(lm.x),
                        y=float(lm.y),
                        z=float(lm.z),
                        visibility=float(lm.visibility) if hasattr(lm, "visibility") else None,
                        presence=float(lm.presence) if hasattr(lm, "presence") else None,
                    )
                )
            pose = PoseLandmarks(landmarks=tuple(pose_points))

        return LandmarkFrame(
            timestamp_ns=frame_data.timestamp_ns,
            frame_index=frame_data.frame_index,
            left_hand=left_hand,
            right_hand=right_hand,
            pose=pose,
        )
