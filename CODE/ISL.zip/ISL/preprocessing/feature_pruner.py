"""SIGNVISION Preprocessing - Feature Pruner.

Defines the interface and concrete FeaturePruner for selective landmark channel
slicing and optional dimensionality reduction without mutating source datasets.
"""

from abc import ABC, abstractmethod
from typing import List, Optional, Sequence, Tuple, Union
import numpy as np


class FeaturePrunerProtocol(ABC):
    """Abstract interface for selective landmark feature slicing."""

    @abstractmethod
    def prune(self, features: np.ndarray) -> np.ndarray:
        """Select a configured subset of landmark channels."""
        pass

    @abstractmethod
    def get_output_dimension(self, input_dim: int) -> int:
        """Return the resulting dimension after pruning."""
        pass


class FeaturePruner(FeaturePrunerProtocol):
    """Concrete feature pruner slicing arrays along the last feature dimension."""

    def __init__(self, selected_indices: Optional[Sequence[int]] = None) -> None:
        """Initialize with optional sequence of integer channel indices.
        
        If selected_indices is None or empty, operates in 'no-pruning' pass-through mode.
        """
        self.selected_indices: Optional[np.ndarray] = (
            np.array(selected_indices, dtype=np.int64) if selected_indices is not None and len(selected_indices) > 0
            else None
        )

    def prune(self, features: np.ndarray) -> np.ndarray:
        """Slice the configured feature channels along the trailing axis."""
        if features is None or not isinstance(features, np.ndarray):
            raise ValueError("features must be a valid NumPy ndarray.")

        if self.selected_indices is None:
            return features.copy()

        # Check bounds
        max_idx = np.max(self.selected_indices)
        if max_idx >= features.shape[-1]:
            raise IndexError(
                f"Selected index {max_idx} is out of bounds for feature axis of size {features.shape[-1]}."
            )

        return features[..., self.selected_indices].copy()

    def get_output_dimension(self, input_dim: int) -> int:
        """Return output dimension."""
        if self.selected_indices is None:
            return input_dim
        return len(self.selected_indices)

    @classmethod
    def from_feature_layout(cls, layout: dict, groups: Sequence[str]) -> "FeaturePruner":
        """Instantiate a FeaturePruner by selecting named feature groups from a canonicalizer layout."""
        indices: List[int] = []
        available_groups = layout.get("groups", {})
        for g in groups:
            if g not in available_groups:
                raise KeyError(
                    f"Feature group '{g}' not found in layout. Available groups: {list(available_groups.keys())}"
                )
            group_info = available_groups[g]
            indices.extend(range(group_info["start"], group_info["end"]))
        return cls(selected_indices=indices)

