"""SIGNVISION Preprocessing - Normalizers.

Defines spatial coordinate normalization strategies (Wrist-centered, Bounding-box)
for translation and scale invariance.
"""

from abc import ABC, abstractmethod
from typing import Optional
import numpy as np
from common.exceptions import InvalidFeatureShapeError


class NormalizerProtocol(ABC):
    """Abstract interface for landmark spatial normalization strategies."""

    @abstractmethod
    def fit(self, features: np.ndarray) -> "NormalizerProtocol":
        """Compute statistical normalization parameters across a dataset batch."""
        pass

    @abstractmethod
    def transform(self, features: np.ndarray) -> np.ndarray:
        """Apply spatial normalization to a feature array."""
        pass

    @abstractmethod
    def fit_transform(self, features: np.ndarray) -> np.ndarray:
        """Fit normalization parameters and transform the input batch."""
        pass


class WristCenteredNormalizer(NormalizerProtocol):
    """Normalizes hand coordinates relative to wrist keypoint (landmark 0).
    
    Subtracts wrist (x0, y0, z0) from all landmarks of each respective hand.
    Preserves scale while removing camera translation drift.
    """

    def __init__(self, coords_per_point: int = 3, epsilon: float = 1e-6) -> None:
        self.coords_per_point = coords_per_point
        self.epsilon = epsilon
        self.points_per_hand = 21
        self.hand_len = self.points_per_hand * self.coords_per_point
        self._fitted_dim: Optional[int] = None

    def fit(self, features: np.ndarray) -> "WristCenteredNormalizer":
        """Record feature dimension and validate shape."""
        if features is None or not isinstance(features, np.ndarray):
            raise InvalidFeatureShapeError("Features must be a valid NumPy ndarray.")
        dim = features.shape[-1]
        if dim < self.hand_len:
            raise InvalidFeatureShapeError(
                f"Feature dimension {dim} is too small for hand length {self.hand_len}."
            )
        self._fitted_dim = dim
        return self

    def transform(self, features: np.ndarray) -> np.ndarray:
        """Subtract wrist root from each hand's landmarks."""
        if features is None or not isinstance(features, np.ndarray):
            raise InvalidFeatureShapeError("Features must be a valid NumPy ndarray.")

        orig_shape = features.shape
        if features.ndim == 1:
            arr = features[np.newaxis, :].copy()
        elif features.ndim == 3:
            arr = features.reshape(-1, orig_shape[-1]).copy()
        elif features.ndim == 2:
            arr = features.copy()
        else:
            raise InvalidFeatureShapeError(f"Unsupported feature ndim: {features.ndim}")

        if self._fitted_dim is not None and arr.shape[1] != self._fitted_dim:
            raise InvalidFeatureShapeError(
                f"Expected feature dimension {self._fitted_dim}, got {arr.shape[1]}"
            )

        c = self.coords_per_point
        # Normalize Left Hand (indices 0 .. hand_len - 1)
        if arr.shape[1] >= self.hand_len:
            lh_active = np.any(np.abs(arr[:, :self.hand_len]) > self.epsilon, axis=1)
            lh_wrist = arr[:, 0:c].copy()
            for p in range(self.points_per_hand):
                start = p * c
                end = start + c
                arr[lh_active, start:end] -= lh_wrist[lh_active]

        # Normalize Right Hand (indices hand_len .. 2*hand_len - 1)
        if arr.shape[1] >= 2 * self.hand_len:
            rh_offset = self.hand_len
            rh_active = np.any(np.abs(arr[:, rh_offset:rh_offset + self.hand_len]) > self.epsilon, axis=1)
            rh_wrist = arr[:, rh_offset:rh_offset + c].copy()
            for p in range(self.points_per_hand):
                start = rh_offset + p * c
                end = start + c
                arr[rh_active, start:end] -= rh_wrist[rh_active]

        if len(orig_shape) == 1:
            return arr[0]
        elif len(orig_shape) == 3:
            return arr.reshape(orig_shape)
        return arr

    def fit_transform(self, features: np.ndarray) -> np.ndarray:
        return self.fit(features).transform(features)


class BoundingBoxNormalizer(NormalizerProtocol):
    """Normalizes hand coordinates within a localized bounding box [0, 1]."""

    def __init__(self, coords_per_point: int = 3, epsilon: float = 1e-6) -> None:
        self.coords_per_point = coords_per_point
        self.epsilon = epsilon
        self.points_per_hand = 21
        self.hand_len = self.points_per_hand * self.coords_per_point
        self._fitted_dim: Optional[int] = None

    def fit(self, features: np.ndarray) -> "BoundingBoxNormalizer":
        if features is None or not isinstance(features, np.ndarray):
            raise InvalidFeatureShapeError("Features must be a valid NumPy ndarray.")
        self._fitted_dim = features.shape[-1]
        return self

    def transform(self, features: np.ndarray) -> np.ndarray:
        if features is None or not isinstance(features, np.ndarray):
            raise InvalidFeatureShapeError("Features must be a valid NumPy ndarray.")

        orig_shape = features.shape
        if features.ndim == 1:
            arr = features[np.newaxis, :].copy()
        elif features.ndim == 3:
            arr = features.reshape(-1, orig_shape[-1]).copy()
        elif features.ndim == 2:
            arr = features.copy()
        else:
            raise InvalidFeatureShapeError(f"Unsupported feature ndim: {features.ndim}")

        if self._fitted_dim is not None and arr.shape[1] != self._fitted_dim:
            raise InvalidFeatureShapeError(
                f"Expected feature dimension {self._fitted_dim}, got {arr.shape[1]}"
            )

        c = self.coords_per_point
        # Normalize each hand independently
        for hand_idx in range(2):
            offset = hand_idx * self.hand_len
            if arr.shape[1] >= offset + self.hand_len:
                hand_data = arr[:, offset:offset + self.hand_len]
                active = np.any(np.abs(hand_data) > self.epsilon, axis=1)

                for sample_idx in np.where(active)[0]:
                    pts = hand_data[sample_idx].reshape(-1, c)
                    min_val = pts.min(axis=0)
                    max_val = pts.max(axis=0)
                    scale = max_val - min_val
                    scale = np.where(scale < self.epsilon, 1.0, scale)

                    norm_pts = (pts - min_val) / scale
                    arr[sample_idx, offset:offset + self.hand_len] = norm_pts.flatten()

        if len(orig_shape) == 1:
            return arr[0]
        elif len(orig_shape) == 3:
            return arr.reshape(orig_shape)
        return arr

    def fit_transform(self, features: np.ndarray) -> np.ndarray:
        return self.fit(features).transform(features)


class CropSpaceNormalizer(NormalizerProtocol):
    """Normalizes hand coordinates into Dataset 1 crop-space reference frame.

    Transforms arbitrary live webcam coordinates by:
    1. Detecting active hands (Left Hand: 0..62, Right Hand: 63..125).
    2. Re-anchoring bounding-box center and span to match Dataset 1 crop distributions:
       - Single Right Hand: target_center_x = 0.48, target_bottom_y = 0.88, target_span = 0.81
       - Single Left Hand: target_center_x = 0.48, target_bottom_y = 0.70, target_span = 0.81
       - Bimanual (Both Hands): joint bounding box, target_center_x = 0.48, target_bottom_y = 0.72, target_span = 0.72
    3. Scaling coordinates uniformly to eliminate scale and translation drift while preserving
       finger geometry and left/right semantic slot assignments.
    4. Safely preserving absent-hand zero slots (no phantom hand fabrication).
    """

    def __init__(
        self,
        coords_per_point: int = 3,
        epsilon: float = 1e-6,
        single_rh_center_x: float = 0.48,
        single_rh_bottom_y: float = 0.88,
        single_rh_span: float = 0.81,
        single_lh_center_x: float = 0.48,
        single_lh_bottom_y: float = 0.70,
        single_lh_span: float = 0.81,
        bimanual_center_x: float = 0.48,
        bimanual_bottom_y: float = 0.72,
        bimanual_span: float = 0.72,
    ) -> None:
        self.coords_per_point = coords_per_point
        self.epsilon = epsilon
        self.points_per_hand = 21
        self.hand_len = self.points_per_hand * self.coords_per_point

        self.single_rh_center_x = single_rh_center_x
        self.single_rh_bottom_y = single_rh_bottom_y
        self.single_rh_span = single_rh_span

        self.single_lh_center_x = single_lh_center_x
        self.single_lh_bottom_y = single_lh_bottom_y
        self.single_lh_span = 0.50

        self.bimanual_center_x = bimanual_center_x
        self.bimanual_bottom_y = bimanual_bottom_y
        self.bimanual_span = bimanual_span

        self._fitted_dim: Optional[int] = None

    def fit(self, features: np.ndarray) -> "CropSpaceNormalizer":
        if features is None or not isinstance(features, np.ndarray):
            raise InvalidFeatureShapeError("Features must be a valid NumPy ndarray.")
        self._fitted_dim = features.shape[-1]
        return self

    def transform(self, features: np.ndarray) -> np.ndarray:
        if features is None or not isinstance(features, np.ndarray):
            raise InvalidFeatureShapeError("Features must be a valid NumPy ndarray.")

        orig_shape = features.shape
        if features.ndim == 1:
            arr = features[np.newaxis, :].copy()
        elif features.ndim == 3:
            arr = features.reshape(-1, orig_shape[-1]).copy()
        elif features.ndim == 2:
            arr = features.copy()
        else:
            raise InvalidFeatureShapeError(f"Unsupported feature ndim: {features.ndim}")

        if self._fitted_dim is not None and arr.shape[1] != self._fitted_dim:
            raise InvalidFeatureShapeError(
                f"Expected feature dimension {self._fitted_dim}, got {arr.shape[1]}"
            )

        n_samples = arr.shape[0]
        c = self.coords_per_point
        lh_offset = 0
        rh_offset = self.hand_len

        for i in range(n_samples):
            lh_active = (
                arr.shape[1] >= lh_offset + self.hand_len
                and np.any(np.abs(arr[i, lh_offset:lh_offset + self.hand_len]) > self.epsilon)
            )
            rh_active = (
                arr.shape[1] >= rh_offset + self.hand_len
                and np.any(np.abs(arr[i, rh_offset:rh_offset + self.hand_len]) > self.epsilon)
            )

            if lh_active and rh_active:
                # Bimanual: joint bounding box transformation
                lh_pts = arr[i, lh_offset:lh_offset + self.hand_len].reshape(-1, c)
                rh_pts = arr[i, rh_offset:rh_offset + self.hand_len].reshape(-1, c)
                both = np.vstack([lh_pts, rh_pts])

                min_xy = both[:, :2].min(axis=0)
                max_xy = both[:, :2].max(axis=0)
                center_x = (min_xy[0] + max_xy[0]) / 2.0
                bottom_y = max_xy[1]
                w = max_xy[0] - min_xy[0]
                h = max_xy[1] - min_xy[1]
                span = max(w, h)
                scale = self.bimanual_span / max(span, self.epsilon)

                lh_norm = lh_pts.copy()
                lh_norm[:, 0] = self.bimanual_center_x + (lh_pts[:, 0] - center_x) * scale
                lh_norm[:, 1] = self.bimanual_bottom_y + (lh_pts[:, 1] - bottom_y) * scale
                lh_norm[:, 2] = lh_pts[:, 2] * scale
                arr[i, lh_offset:lh_offset + self.hand_len] = lh_norm.flatten()

                rh_norm = rh_pts.copy()
                rh_norm[:, 0] = self.bimanual_center_x + (rh_pts[:, 0] - center_x) * scale
                rh_norm[:, 1] = self.bimanual_bottom_y + (rh_pts[:, 1] - bottom_y) * scale
                rh_norm[:, 2] = rh_pts[:, 2] * scale
                arr[i, rh_offset:rh_offset + self.hand_len] = rh_norm.flatten()

            elif rh_active:
                # Single Right Hand
                rh_pts = arr[i, rh_offset:rh_offset + self.hand_len].reshape(-1, c)
                min_xy = rh_pts[:, :2].min(axis=0)
                max_xy = rh_pts[:, :2].max(axis=0)
                center_x = (min_xy[0] + max_xy[0]) / 2.0
                bottom_y = max_xy[1]
                h = max_xy[1] - min_xy[1]
                scale = self.single_rh_span / max(h, self.epsilon)

                rh_norm = np.zeros_like(rh_pts)
                rh_norm[:, 0] = self.single_rh_center_x + (rh_pts[:, 0] - center_x) * scale
                rh_norm[:, 1] = self.single_rh_bottom_y + (rh_pts[:, 1] - bottom_y) * scale
                rh_norm[:, 2] = rh_pts[:, 2] * scale
                arr[i, rh_offset:rh_offset + self.hand_len] = rh_norm.flatten()

            elif lh_active:
                # Single Left Hand
                lh_pts = arr[i, lh_offset:lh_offset + self.hand_len].reshape(-1, c)
                min_xy = lh_pts[:, :2].min(axis=0)
                max_xy = lh_pts[:, :2].max(axis=0)
                center_x = (min_xy[0] + max_xy[0]) / 2.0
                bottom_y = max_xy[1]
                h = max_xy[1] - min_xy[1]
                scale = self.single_lh_span / max(h, self.epsilon)

                lh_norm = np.zeros_like(lh_pts)
                lh_norm[:, 0] = self.single_lh_center_x + (lh_pts[:, 0] - center_x) * scale
                lh_norm[:, 1] = self.single_lh_bottom_y + (lh_pts[:, 1] - bottom_y) * scale
                lh_norm[:, 2] = lh_pts[:, 2] * scale
                arr[i, lh_offset:lh_offset + self.hand_len] = lh_norm.flatten()

        if len(orig_shape) == 1:
            return arr[0]
        elif len(orig_shape) == 3:
            return arr.reshape(orig_shape)
        return arr

    def fit_transform(self, features: np.ndarray) -> np.ndarray:
        return self.fit(features).transform(features)
