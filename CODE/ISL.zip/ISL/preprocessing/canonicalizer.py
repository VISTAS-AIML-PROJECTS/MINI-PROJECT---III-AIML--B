"""SIGNVISION Preprocessing - Landmark Canonicalization.

Defines the interface and concrete implementation for converting structured
LandmarkFrames into deterministic, canonical feature vectors with consistent
hand ordering and missing-hand representation.
"""

from abc import ABC, abstractmethod
from typing import Any, List, Optional, Sequence, Tuple
import numpy as np

from common.types import HandLandmarks, LandmarkFrame, LandmarkPoint
from common.config import PreprocessingConfig
from common.exceptions import PreprocessingError


class LandmarkCanonicalizerProtocol(ABC):
    """Abstract interface for canonicalizing landmark features."""

    @abstractmethod
    def canonicalize(self, landmark_frame: LandmarkFrame) -> np.ndarray:
        """Convert a LandmarkFrame into a deterministic 1D feature vector.
        
        Guarantees:
        1. Left Hand is always mapped to slot 0..20.
        2. Right Hand is always mapped to slot 21..41.
        3. Missing hands are padded deterministically with zeros.
        4. Upper body pose landmarks are appended in fixed index order.
        5. Optional presence flags indicate hand/pose availability.
        
        Args:
            landmark_frame: Structured landmark inputs.
            
        Returns:
            np.ndarray: Deterministic 1D feature vector of shape (D,).
            
        Raises:
            PreprocessingError: If input structure cannot be canonicalized.
        """
        pass

    @abstractmethod
    def get_feature_dimension(self) -> int:
        """Return the output feature dimension D produced by this canonicalizer."""
        pass


class LandmarkCanonicalizer(LandmarkCanonicalizerProtocol):
    """Concrete canonicalizer mapping LandmarkFrame into a deterministic 1D vector."""

    def __init__(self, config: Optional[PreprocessingConfig] = None) -> None:
        self.config = config or PreprocessingConfig()
        self._coords_per_point = 3 if self.config.include_z else 2
        self._hand_feature_len = 21 * self._coords_per_point
        self._pose_feature_len = len(self.config.selected_pose_indices) * self._coords_per_point
        self._presence_flags_len = 3 if self.config.include_presence_flags else 0

        self._total_dimension = (
            self._hand_feature_len * 2  # Left + Right Hand
            + self._pose_feature_len     # Upper Pose Keypoints
            + self._presence_flags_len   # Left, Right, Pose present flags
        )

    def canonicalize(self, landmark_frame: LandmarkFrame) -> np.ndarray:
        """Convert LandmarkFrame into a canonical 1D float32 array."""
        if landmark_frame is None or not isinstance(landmark_frame, LandmarkFrame):
            raise PreprocessingError("Input must be a valid LandmarkFrame instance.")

        components: List[np.ndarray] = []

        # 1. Left Hand
        left_present = landmark_frame.left_hand is not None and landmark_frame.left_hand.is_present
        if left_present:
            lh_arr = self._extract_points(landmark_frame.left_hand.landmarks)
        else:
            lh_arr = np.zeros(self._hand_feature_len, dtype=np.float32)
        components.append(lh_arr)

        # 2. Right Hand
        right_present = landmark_frame.right_hand is not None and landmark_frame.right_hand.is_present
        if right_present:
            rh_arr = self._extract_points(landmark_frame.right_hand.landmarks)
        else:
            rh_arr = np.zeros(self._hand_feature_len, dtype=np.float32)
        components.append(rh_arr)

        # 3. Selected Pose Keypoints
        pose_present = landmark_frame.pose is not None and landmark_frame.pose.is_present
        if pose_present and len(self.config.selected_pose_indices) > 0:
            pose_points: List[float] = []
            all_pose_lms = landmark_frame.pose.landmarks
            for idx in self.config.selected_pose_indices:
                if 0 <= idx < len(all_pose_lms):
                    lm = all_pose_lms[idx]
                    pose_points.append(lm.x)
                    pose_points.append(lm.y)
                    if self.config.include_z:
                        pose_points.append(lm.z)
                else:
                    pose_points.extend([0.0] * self._coords_per_point)
            pose_arr = np.array(pose_points, dtype=np.float32)
        else:
            pose_arr = np.zeros(self._pose_feature_len, dtype=np.float32)

        if self._pose_feature_len > 0:
            components.append(pose_arr)

        # 4. Optional Presence Flags [left_present, right_present, pose_present]
        if self.config.include_presence_flags:
            flags = np.array(
                [
                    1.0 if left_present else 0.0,
                    1.0 if right_present else 0.0,
                    1.0 if pose_present else 0.0,
                ],
                dtype=np.float32,
            )
            components.append(flags)

        result = np.concatenate(components).astype(np.float32)
        return result

    def _extract_points(self, landmarks: Tuple[LandmarkPoint, ...]) -> np.ndarray:
        coords: List[float] = []
        for lm in landmarks:
            coords.append(lm.x)
            coords.append(lm.y)
            if self.config.include_z:
                coords.append(lm.z)
        return np.array(coords, dtype=np.float32)

    def get_feature_dimension(self) -> int:
        """Return the output feature dimension D produced by this canonicalizer."""
        return self._total_dimension

    def get_feature_layout(self) -> dict:
        """Return runtime metadata and index slice boundaries for each feature group."""
        c = self._coords_per_point
        layout = {
            "coords_per_point": c,
            "include_z": self.config.include_z,
            "include_presence_flags": self.config.include_presence_flags,
            "groups": {},
            "total_dimension": self._total_dimension,
        }

        cursor = 0
        # 1. Left Hand
        layout["groups"]["left_hand"] = {
            "start": cursor,
            "end": cursor + self._hand_feature_len,
            "points": 21,
            "dimension": self._hand_feature_len,
        }
        cursor += self._hand_feature_len

        # 2. Right Hand
        layout["groups"]["right_hand"] = {
            "start": cursor,
            "end": cursor + self._hand_feature_len,
            "points": 21,
            "dimension": self._hand_feature_len,
        }
        cursor += self._hand_feature_len

        # 3. Pose
        if self._pose_feature_len > 0:
            layout["groups"]["pose"] = {
                "start": cursor,
                "end": cursor + self._pose_feature_len,
                "points": len(self.config.selected_pose_indices),
                "selected_indices": list(self.config.selected_pose_indices),
                "dimension": self._pose_feature_len,
            }
            cursor += self._pose_feature_len

        # 4. Presence Flags
        if self._presence_flags_len > 0:
            layout["groups"]["presence_flags"] = {
                "start": cursor,
                "end": cursor + self._presence_flags_len,
                "flags": ["left_present", "right_present", "pose_present"],
                "dimension": self._presence_flags_len,
            }
            cursor += self._presence_flags_len

        return layout

    def get_feature_summary(self) -> str:
        """Generate human-readable summary of the feature representation."""
        layout = self.get_feature_layout()
        lines = [
            "=" * 50,
            "SIGNVISION LANDMARK FEATURE LAYOUT AUDIT",
            "=" * 50,
            f"Coordinate format: {'3D (x, y, z)' if layout['include_z'] else '2D (x, y)'}",
            f"Coords per point : {layout['coords_per_point']}",
            f"Total dimension  : {layout['total_dimension']}",
            "-" * 50,
        ]
        for name, g in layout["groups"].items():
            lines.append(f"  * {name:<16}: indices [{g['start']:>3}..{g['end']:>3}) (dim: {g['dimension']:>2})")
        lines.append("=" * 50)
        return "\n".join(lines)


class LandmarkPreprocessingPipeline:
    """Unified composable preprocessing pipeline for static frames and dynamic sequences."""

    def __init__(
        self,
        canonicalizer: Optional[LandmarkCanonicalizerProtocol] = None,
        normalizer: Optional[Any] = None,
        pruner: Optional[Any] = None,
    ) -> None:
        self.canonicalizer = canonicalizer or LandmarkCanonicalizer()
        self.normalizer = normalizer
        self.pruner = pruner

    def process_frame(self, frame: LandmarkFrame) -> np.ndarray:
        """Transform a single LandmarkFrame into a normalized, pruned feature vector."""
        # 1. Canonicalize
        feat = self.canonicalizer.canonicalize(frame)

        # 2. Normalize
        if self.normalizer is not None:
            feat = self.normalizer.transform(feat)

        # 3. Prune
        if self.pruner is not None:
            feat = self.pruner.prune(feat)

        return feat.astype(np.float32)

    def process_sequence(self, frames: Sequence[LandmarkFrame]) -> np.ndarray:
        """Transform an ordered sequence of LandmarkFrames into an (N, D) array."""
        if not frames:
            d = self.get_feature_dimension()
            return np.empty((0, d), dtype=np.float32)

        vectors = [self.process_frame(f) for f in frames]
        return np.stack(vectors, axis=0).astype(np.float32)

    def get_feature_dimension(self) -> int:
        """Compute the final output feature dimension after all pipeline stages."""
        dim = self.canonicalizer.get_feature_dimension()
        if self.pruner is not None:
            dim = self.pruner.get_output_dimension(dim)
        return dim

    @staticmethod
    def extract_45d_features(sequence_or_batch: np.ndarray) -> np.ndarray:
        """Convert canonical sequence(s) into validated 45-D dynamic feature representations.

        45-D = 39-D upper-body pose (13 keypoints x 3) + 6-D left/right wrist velocity.
        Velocity definition:
            Delta w_t = w_t - w_{t-1} for t >= 1
            Delta w_0 = 0.0 (deterministic boundary convention)

        Args:
            sequence_or_batch: Array of shape (T, 168), (N, T, 168), (T, 39), or (N, T, 39).

        Returns:
            np.ndarray: Array of shape (T, 45) or (N, T, 45) with dtype float32.
        """
        arr = np.asarray(sequence_or_batch, dtype=np.float32)
        is_single = (arr.ndim == 2)
        if is_single:
            arr = np.expand_dims(arr, axis=0)

        if arr.ndim != 3:
            raise ValueError(f"Expected 2D or 3D sequence array, got shape {sequence_or_batch.shape}")

        N, T, D = arr.shape
        if D == 168:
            pose = arr[:, :, 126:165]
        elif D == 39:
            pose = arr
        elif D == 45:
            return sequence_or_batch.copy().astype(np.float32)
        else:
            raise ValueError(f"Expected feature dimension 168, 39, or 45, got {D}")

        # In 39-D upper pose:
        # Keypoint 15 (left wrist) is at index 15:18 (relative to pose start)
        # Keypoint 16 (right wrist) is at index 18:21 (relative to pose start)
        lw = pose[:, :, 15:18]
        rw = pose[:, :, 18:21]

        lw_vel = np.zeros_like(lw)
        rw_vel = np.zeros_like(rw)
        if T > 1:
            lw_vel[:, 1:] = lw[:, 1:] - lw[:, :-1]
            rw_vel[:, 1:] = rw[:, 1:] - rw[:, :-1]

        res = np.concatenate([pose, lw_vel, rw_vel], axis=-1)
        if is_single:
            return res[0]
        return res

