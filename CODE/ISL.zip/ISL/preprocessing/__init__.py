"""SIGNVISION Preprocessing Package.

Exposes data canonicalization, normalization, temporal buffering,
and feature pruning contracts and concrete implementations.
"""

from preprocessing.canonicalizer import (
    LandmarkCanonicalizerProtocol,
    LandmarkCanonicalizer,
    LandmarkPreprocessingPipeline,
)
from preprocessing.normalizer import (
    NormalizerProtocol,
    WristCenteredNormalizer,
    BoundingBoxNormalizer,
)
from preprocessing.temporal_window import (
    TemporalWindowProtocol,
    SlidingTemporalWindow,
)
from preprocessing.feature_pruner import (
    FeaturePrunerProtocol,
    FeaturePruner,
)

__all__ = [
    "LandmarkCanonicalizerProtocol",
    "LandmarkCanonicalizer",
    "LandmarkPreprocessingPipeline",
    "NormalizerProtocol",
    "WristCenteredNormalizer",
    "BoundingBoxNormalizer",
    "TemporalWindowProtocol",
    "SlidingTemporalWindow",
    "FeaturePrunerProtocol",
    "FeaturePruner",
]
