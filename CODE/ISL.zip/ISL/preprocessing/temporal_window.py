"""SIGNVISION Preprocessing - Temporal Sequence Window.

Defines the interface and concrete SlidingTemporalWindow buffer for maintaining
FIFO feature sequences, decimation (30 FPS to 10 FPS), and stride-based inference triggering.
"""

from abc import ABC, abstractmethod
from collections import deque
from typing import Deque, Optional, Tuple
import numpy as np

from common.config import DynamicEngineConfig
from common.exceptions import InvalidSequenceLengthError, InvalidFeatureShapeError


class TemporalWindowProtocol(ABC):
    """Abstract interface for sliding temporal feature sequence buffers."""

    @abstractmethod
    def append(self, feature_vector: np.ndarray, timestamp_ns: int) -> bool:
        """Push a new frame feature vector into the temporal sequence buffer."""
        pass

    @abstractmethod
    def get_sequence(self, pad_if_incomplete: bool = False, pad_value: float = 0.0) -> np.ndarray:
        """Return the current temporal sequence window."""
        pass

    @abstractmethod
    def should_infer(self) -> bool:
        """Check if the current frame index aligns with the configured inference stride."""
        pass

    @abstractmethod
    def reset(self) -> None:
        """Clear all buffered frames and reset the temporal counter."""
        pass

    @property
    @abstractmethod
    def is_full(self) -> bool:
        """Check if the buffer has reached its target window length T."""
        pass


class SlidingTemporalWindow(TemporalWindowProtocol):
    """Concrete sliding FIFO temporal window with temporal resampling and stride control."""

    def __init__(
        self,
        sequence_length: int = 33,
        decimation_factor: int = 1,
        inference_stride: int = 5,
        target_duration_s: float = 3.2,
        buffer_capacity: Optional[int] = None,
    ) -> None:
        if sequence_length <= 0:
            raise ValueError(f"sequence_length must be positive, got {sequence_length}")
        if decimation_factor <= 0:
            raise ValueError(f"decimation_factor must be positive, got {decimation_factor}")
        if inference_stride <= 0:
            raise ValueError(f"inference_stride must be positive, got {inference_stride}")

        self.sequence_length = sequence_length
        self.decimation_factor = decimation_factor
        self.inference_stride = inference_stride
        self.target_duration_ns = int(round(target_duration_s * 1_000_000_000))

        capacity = buffer_capacity or sequence_length
        self._buffer: Deque[Tuple[np.ndarray, int]] = deque(maxlen=capacity)
        self._raw_frame_count: int = 0
        self._decimated_sample_count: int = 0
        self._expected_dim: Optional[int] = None

    @classmethod
    def from_config(cls, config: DynamicEngineConfig) -> "SlidingTemporalWindow":
        """Instantiate directly from DynamicEngineConfig settings."""
        return cls(
            sequence_length=config.sequence_length,
            decimation_factor=config.webcam_decimation_factor,
            inference_stride=config.inference_stride,
        )

    def append(self, feature_vector: np.ndarray, timestamp_ns: int) -> bool:
        """Ingest a feature vector. Decimates incoming frames by decimation_factor."""
        if feature_vector is None or not isinstance(feature_vector, np.ndarray):
            raise InvalidFeatureShapeError("feature_vector must be a NumPy ndarray.")

        if self._expected_dim is None:
            self._expected_dim = feature_vector.shape[-1]
        elif feature_vector.shape[-1] != self._expected_dim:
            raise InvalidFeatureShapeError(
                f"Feature dimension {feature_vector.shape[-1]} does not match expected {self._expected_dim}."
            )

        self._raw_frame_count += 1

        # Only retain 1 out of every decimation_factor frames
        if self._raw_frame_count % self.decimation_factor != 0:
            return False

        # Add to FIFO buffer
        self._buffer.append((feature_vector.copy().astype(np.float32), int(timestamp_ns)))
        self._decimated_sample_count += 1

        return self.is_full

    def get_sequence(self, pad_if_incomplete: bool = False, pad_value: float = 0.0) -> np.ndarray:
        """Return the (T, D) array of stacked or resampled temporal features.

        When temporal coverage is sufficient (>= target_duration_ns), resamples
        the sequence onto sequence_length points uniformly spaced across target_duration_ns.
        Binary presence flags in canonical 168-D features are preserved via nearest-neighbor.

        Args:
            pad_if_incomplete: If True, pads or stacks partial data when temporal coverage < 3.2s.
            pad_value: Constant value used for padding.

        Returns:
            np.ndarray: Temporal sequence of shape (T, D) with dtype float32.

        Raises:
            InvalidSequenceLengthError: If buffer does not cover 3.2s and pad_if_incomplete is False.
        """
        if not self.is_full:
            if not pad_if_incomplete:
                raise InvalidSequenceLengthError(
                    f"Buffer covers {self.time_span_ns / 1e9:.3f}s ({len(self._buffer)} frames), "
                    f"but requires at least {self.target_duration_ns / 1e9:.3f}s."
                )
            if len(self._buffer) == 0:
                d = self._expected_dim if self._expected_dim is not None else 0
                return np.full((self.sequence_length, d), pad_value, dtype=np.float32)

            current_vectors = [item[0] for item in self._buffer]
            curr_len = len(current_vectors)
            dim = current_vectors[0].shape[-1]
            if curr_len < self.sequence_length:
                pad_len = self.sequence_length - curr_len
                pad_arr = np.full((pad_len, dim), pad_value, dtype=np.float32)
                return np.vstack([pad_arr, np.stack(current_vectors, axis=0)])
            return np.stack(current_vectors[-self.sequence_length:], axis=0)

        # Extract timestamps and feature matrix
        raw_timestamps = np.array([item[1] for item in self._buffer], dtype=np.float64)
        raw_vectors = np.stack([item[0] for item in self._buffer], axis=0)  # Shape (N, D)
        dim = raw_vectors.shape[-1]

        # Ensure strictly monotonic timestamps for interpolation
        sort_idx = np.argsort(raw_timestamps)
        t_sorted = raw_timestamps[sort_idx]
        v_sorted = raw_vectors[sort_idx]

        unique_mask = np.concatenate([[True], np.diff(t_sorted) > 0])
        t_obs = t_sorted[unique_mask]
        X_obs = v_sorted[unique_mask]

        # Target grid: sequence_length points covering [t_end - target_duration_ns, t_end]
        t_end = t_obs[-1]
        t_start = t_end - float(self.target_duration_ns)
        t_target = np.linspace(t_start, t_end, self.sequence_length, dtype=np.float64)

        resampled = np.empty((self.sequence_length, dim), dtype=np.float32)

        # Handle presence flags deliberately for 168-D canonical features
        if dim == 168:
            # Continuous coordinates: left hand (0:63), right hand (63:126), pose (126:165)
            for d in range(165):
                resampled[:, d] = np.interp(t_target, t_obs, X_obs[:, d])

            # Presence flags (165:168) = [left_present, right_present, pose_present]
            # Nearest-neighbor mapping to preserve binary {0.0, 1.0} flags
            nearest_indices = np.abs(t_obs[:, None] - t_target[None, :]).argmin(axis=0)
            resampled[:, 165:168] = X_obs[nearest_indices, 165:168]
        else:
            # General feature dimensions: linear interpolation across all channels
            for d in range(dim):
                resampled[:, d] = np.interp(t_target, t_obs, X_obs[:, d])

        return resampled.astype(np.float32)

    def should_infer(self) -> bool:
        """Return True if the buffer has sufficient temporal coverage and sample aligns with stride."""
        if not self.is_full:
            return False
        return (self._decimated_sample_count % self.inference_stride) == 0

    def reset(self) -> None:
        """Clear buffer and reset counters."""
        self._buffer.clear()
        self._raw_frame_count = 0
        self._decimated_sample_count = 0

    @property
    def time_span_ns(self) -> int:
        """Return the elapsed time in nanoseconds between the oldest and newest buffered frames."""
        if len(self._buffer) < 2:
            return 0
        return int(self._buffer[-1][1] - self._buffer[0][1])

    @property
    def is_full(self) -> bool:
        """Return True when the buffer has the required sequence length and near-target temporal coverage.

        At 30 FPS, the decimated 10 FPS sampling grid can fall just short of the exact 3.2s threshold when
        frames begin at a non-zero offset. Treating a window as full once it reaches the required sample count
        and is within one sampling interval of the target duration preserves the trained contract without
        introducing a false-positive early inference trigger.
        """
        if len(self._buffer) < self.sequence_length:
            return False

        span_ns = self.time_span_ns
        if span_ns >= self.target_duration_ns:
            return True

        if len(self._buffer) < 2:
            return False

        timestamps = np.array([item[1] for item in self._buffer], dtype=np.float64)
        diffs = np.diff(np.sort(timestamps))
        if diffs.size == 0:
            return False

        sample_interval_ns = float(np.median(diffs))
        tolerance_ns = max(sample_interval_ns, 1.0)
        return span_ns >= self.target_duration_ns - tolerance_ns

    def get_timestamps(self) -> Tuple[int, ...]:
        """Return tuple of timestamps corresponding to currently buffered frames."""
        return tuple(item[1] for item in self._buffer)
