# ISL - SIGNVISION: Indian Sign Language Real-Time Communication System

## 1. Project Title
**SIGNVISION: Real-Time Indian Sign Language Perception, Translation, and Conversational Interaction**

---

## 2. Project Objective
SIGNVISION bridges communication barriers between Deaf and hearing communities by translating Indian Sign Language (ISL) gestures into text and natural conversational responses in real time. It integrates MediaPipe perception, dual-engine static and dynamic sign recognition, lexical text accumulation, and an offline local conversational agent (Ollama) into an end-to-end application.

---

## 3. Key Features
- **Landmark Perception**: MediaPipe tracking for two hands (42 landmarks) and upper-body pose (13 landmarks).
- **Dual Recognition Engines**:
  - **Static Engine**: 126-D hand representation for ISL finger-spelling (A–Z) and numerals (1–9).
  - **Dynamic Engine**: 45-D temporal sequence ($33 \times 45$-D upper pose + wrist velocity) for 76 dynamic ISL lexical words.
- **Engine Routing & Gating**: Motion-magnitude-based routing with confidence thresholding and top-margin gating.
- **Temporal Debouncing & Text Processing**: Eliminates duplicate sign bursts and converts telegraphic ISL tokens into fluent English text.
- **Local Conversational Assistant**: Decoupled Ollama LLM integration (`qwen2.5:3b-instruct-q4_K_M`) for contextual responses without cloud dependencies.
- **FastAPI Application Backend**: Clean endpoints (`/health`, `/status`, `/chat`, `/transcript/reset`, `/video_feed`).

---

## 4. Architecture
```
WEBCAM STREAM
     ↓
MediaPipe Tracker (Hands + Pose)
     ↓
Landmark Extractor (LandmarkFrame)
     ↓
Landmark Canonicalizer (168-D)
     ↓
Engine Router ───→ [Static Engine: 126-D RF]  (Alphabet / Numbers)
              └──→ [Dynamic Engine: 33x45-D RF] (Word Signs)
     ↓
Confidence Gate (Static: 0.70, Dynamic: 0.40, Margin: 0.10)
     ↓
Temporal Filter (Debouncing & Duplicate Suppression)
     ↓
Recognition State Machine
     ↓
RecognitionEvent
     ↓
Text Accumulator & Syntax Normalizer
     ↓
Transcript
     ↓ (Explicit Trigger / Async)
Ollama LLM Client (qwen2.5:3b)
     ↓
FastAPI Application Backend & MJPEG Video Feed
```

---

## 5. Dataset Summary
- **Dataset 1 (Static)**: 42,000 images, 35 classes (1–9, A–Z), single-signer video bursts, burst-level partition (28,947 train / 6,263 val / 6,175 test).
- **Dataset 2 (Dynamic)**: 1,166 video clips, 76 classes, 33 frames/clip at 10 FPS, video-level partition (832 train / 180 val / 154 test).
- **Dataset 3 (Reference)**: 11,700 Holistic vectors across 13 conversational phrases.
*Source datasets in `dataset/` remain read-only.*

---

## 6. Recognition Models
- **Static Model**: `models/static/dataset1_static_classifier.joblib` (Random Forest, 100 trees, max depth 25, 126-D features).
- **Dynamic Model**: `models/dynamic/dataset2_dynamic_classifier.joblib` (Random Forest, 100 trees, 45-D features flattened over 33 frames).

---

## 7. Ollama Integration
- **Model**: `qwen2.5:3b-instruct-q4_K_M` via local HTTP daemon (`http://localhost:11434`).
- **Decoupled Lifecycle**: The webcam recognition loop never blocks on Ollama. The LLM is triggered on demand via `POST /chat` or user UI action.
- **Fault-Tolerant Fallback**: If the daemon is unreachable, the system returns direct formatted transcripts without destroying recognized text.

---

## 8. Setup
```bash
# 1. Clone repository and navigate to workspace
cd "ISL - SIGNVISION"

# 2. Create virtual environment
python -m venv .venv
.venv\Scripts\activate

# 3. Install verified dependencies
pip install -r requirements.txt

# 4. Ensure local Ollama is running
ollama run qwen2.5:3b-instruct-q4_K_M
```

---

## 9. Running the Application
```bash
# Start FastAPI backend
python -m uvicorn application.api:app --host 127.0.0.1 --port 8000
```
- Health Check: `http://127.0.0.1:8000/health`
- Runtime Status: `http://127.0.0.1:8000/status`
- Live Video Feed: `http://127.0.0.1:8000/video_feed`

---

## 10. Running Tests
```bash
# Execute complete unit, integration, and architecture test suite (41 tests)
pytest tests/test_all_submodules.py -v
```

---

## 11. Evaluation
```bash
# Execute full empirical benchmarking and plot generation
python evaluation/run_benchmarks.py
```
Outputs:
- Metrics: `evaluation/static_evaluation_metrics.json`, `evaluation/dynamic_evaluation_metrics.json`, `evaluation/system_benchmark.json`
- Plots: `docs/images/*.png` (8 research charts)

---

## 12. Results

| Subsystem | Metric | Result | Dataset / Evaluation Basis |
| :--- | :--- | :---: | :--- |
| **Static Recognition** | Top-1 Accuracy | **99.42%** | Dataset 1 Test Set (6,175 samples, 35 classes) |
| **Static Recognition** | Macro F1-Score | **99.43%** | Dataset 1 Test Set |
| **Dynamic Recognition**| Top-1 Accuracy | **43.51%** | Dataset 2 Test Set (154 videos, 76 classes) |
| **Dynamic Recognition**| Top-3 Accuracy | **64.29%** | Dataset 2 Test Set |
| **Dynamic Recognition**| Macro F1-Score | **38.69%** | Dataset 2 Test Set |
| **Text Processing** | Scenario Success Rate | **100.0%** | 10 Deterministic Scenarios |
| **Perception Loop** | Live Throughput | **9.16 FPS** | 109.14 ms/frame on CPU laptop |
| **Chatbot Turnaround** | Warm Response Time | **3.52 s** | Local CPU (`qwen2.5:3b`) |

---

## 13. Limitations
1. **Single-Signer Static Baseline**: Dataset 1 models were trained on single-signer video bursts; intra-dataset accuracy is ~99.42%, but requires validation on independent multi-signer cohorts.
2. **Burned-In Graphics on Dynamic Videos**: Dataset 2 source videos contain synthetic skeletal lines that caused a 95.09% MediaPipe hand detection failure rate, forcing reliance on 45-D upper-body pose. Signs differing only in handshape collide in pose space.
3. **CPU LLM Turnaround**: Quantized LLM generation on CPU takes ~3.5 seconds; asynchronous decoupling ensures video capture remains fluid.

---

## 14. Future Work
1. Multi-signer fingerspelling data collection across diverse demographic groups.
2. High-resolution raw video collection for dynamic ISL words without burned-in graphics.
3. Native handshape and finger-articulation feature extractors.
4. Sequence modeling with larger multi-signer dynamic corpora.
5. GPU acceleration for sub-second conversational LLM generation.
