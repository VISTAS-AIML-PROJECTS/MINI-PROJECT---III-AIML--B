"""SIGNVISION Application Layer - FastAPI Backend Routes.

Exposes REST and streaming endpoints for health checks, system status,
transcript management, video streaming, and downstream conversational chatbot.
"""

import asyncio
import logging
import time
from pathlib import Path
from typing import Any, Dict, Optional
from fastapi import FastAPI, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from application.services import SignVisionApplication
from common.types import ChatbotResponse

logger = logging.getLogger("signvision.api")


class ChatRequest(BaseModel):
    """Payload schema for /chat endpoint."""
    transcript: Optional[str] = Field(
        default=None,
        description="Optional explicit transcript to process. If omitted, uses current accumulated transcript.",
    )


class ResetResponse(BaseModel):
    """Response schema for /transcript/reset endpoint."""
    status: str
    message: str
    transcript: str


from contextlib import asynccontextmanager


def create_app(app_instance: Optional[SignVisionApplication] = None) -> FastAPI:
    """Application factory instantiating configured FastAPI instance."""
    signvision_app = app_instance or SignVisionApplication()

    @asynccontextmanager
    async def lifespan(app_api: FastAPI):
        signvision_app.startup()
        yield
        signvision_app.shutdown()

    api = FastAPI(
        title="SIGNVISION ISL Communication System",
        description="End-to-End Indian Sign Language Recognition & Chatbot Backend",
        version="1.0.0",
        lifespan=lifespan,
    )

    # Local CORS middleware
    api.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Mount static assets directory
    static_dir = Path(__file__).resolve().parent / "static"
    if static_dir.exists():
        api.mount("/static", StaticFiles(directory=str(static_dir)), name="static")

    @api.get("/", response_class=FileResponse)
    async def get_index():
        """Serve the SIGNVISION frontend application homepage."""
        index_file = static_dir / "index.html"
        if index_file.exists():
            return FileResponse(str(index_file))
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Frontend index.html not found.",
        )

    @api.get("/favicon.ico", include_in_schema=False)
    async def get_favicon():
        """Handle browser favicon request cleanly without 404 error."""
        fav_file = static_dir / "favicon.ico"
        if fav_file.exists():
            return FileResponse(str(fav_file))
        return Response(status_code=status.HTTP_204_NO_CONTENT)

    @api.get("/health", status_code=status.HTTP_200_OK)
    async def get_health() -> Dict[str, str]:
        """Application health check endpoint. Does NOT fail if Ollama is unavailable."""
        return {"status": "ok", "app": "ISL-SIGNVISION"}

    @api.get("/status", status_code=status.HTTP_200_OK)
    async def get_status() -> Dict[str, Any]:
        """Expose runtime system status across camera, recognition, transcript, and Ollama."""
        return await signvision_app.get_system_status()

    @api.post("/chat", status_code=status.HTTP_200_OK)
    async def post_chat(request: ChatRequest) -> Dict[str, Any]:
        """Generate conversational response for current or provided transcript."""
        try:
            response: ChatbotResponse = await signvision_app.trigger_chat(
                transcript_override=request.transcript
            )
            return {
                "text": response.text,
                "success": response.success,
                "model": response.model,
                "latency_ms": response.latency_ms,
                "status": response.status,
                "error": response.error,
            }
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Chatbot interaction failed: {str(e)}",
            )

    @api.post("/transcript/reset", response_model=ResetResponse, status_code=status.HTTP_200_OK)
    async def reset_transcript() -> ResetResponse:
        """Reset only application transcript state without altering models or configuration."""
        signvision_app.reset_transcript()
        return ResetResponse(
            status="success",
            message="Transcript cleared successfully",
            transcript="",
        )

    @api.get("/video_feed")
    async def video_feed(request: Request) -> StreamingResponse:
        """Stream MJPEG video feed for real-time browser preview.

        Presentation/streaming consumer only: does NOT execute perception or step_frame().
        """
        # Ensure camera is opened and perception worker is active
        if not signvision_app.camera_service.is_opened():
            try:
                signvision_app.camera_service.start_camera()
                logger.info("Camera service started on /video_feed request")
            except Exception as e:
                logger.warning(f"Could not open camera on /video_feed: {e}")

        if signvision_app.camera_service.is_opened() and not signvision_app.is_worker_running():
            signvision_app.start_worker()

        async def frame_generator():
            logger.info("Client connected to /video_feed stream")
            last_sent_id = -1
            try:
                while signvision_app._is_running or signvision_app.camera_service.is_opened():
                    if await request.is_disconnected():
                        logger.info("Client disconnected from /video_feed stream")
                        break

                    frame_id, frame_bytes = signvision_app.get_latest_annotated_frame()
                    if frame_bytes:
                        if frame_id != last_sent_id:
                            last_sent_id = frame_id
                            yield (
                                b"--frame\r\n"
                                b"Content-Type: image/jpeg\r\n\r\n" + frame_bytes + b"\r\n"
                            )
                        elif frame_id == 0:
                            # Stream fallback offline placeholder
                            yield (
                                b"--frame\r\n"
                                b"Content-Type: image/jpeg\r\n\r\n" + frame_bytes + b"\r\n"
                            )
                            await asyncio.sleep(0.5)
                            continue

                    # Yield CPU cooperatively for high-throughput streaming
                    await asyncio.sleep(0.01)
            except (GeneratorExit, asyncio.CancelledError):
                logger.info("Client disconnected from /video_feed stream")
            except Exception as e:
                logger.warning(f"Error in /video_feed stream: {e}")

        return StreamingResponse(
            frame_generator(),
            media_type="multipart/x-mixed-replace; boundary=frame",
            headers={
                "Cache-Control": "no-cache, no-store, must-revalidate",
                "Pragma": "no-cache",
                "Expires": "0",
            },
        )

    # Attach internal application instance to FastAPI state
    api.state.signvision_app = signvision_app
    return api


# Module-level instance for uvicorn entrypoint
app = create_app()
