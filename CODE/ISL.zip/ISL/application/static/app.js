/**
 * SIGNVISION — Indian Sign Language Studio Client Application
 * Handles real-time telemetry polling, video feed management, transcript actions,
 * and conversational Ollama LLM interactions.
 */

// Application Configuration
const STATUS_POLL_INTERVAL_MS = 600;

// Application State
const state = {
  lastTranscriptRaw: '',
  lastTranscriptNormalized: '',
  transcriptEditing: false,
  transcriptEdited: false,
  consecutiveErrorCount: 0,
  isSendingChat: false,
};

// DOM Element Selector Helper
function $(id) {
  return document.getElementById(id);
}

function getTranscriptText() {
  const displayEl = $('transcript-display');
  if (state.transcriptEdited && displayEl) return displayEl.innerText.trim();
  return state.lastTranscriptNormalized || state.lastTranscriptRaw;
}

// Notification Toast Utility
function showToast(message, icon = '✓') {
  const shelf = $('toast-shelf');
  if (!shelf) return;

  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.innerHTML = `<span>${icon}</span> <span>${message}</span>`;
  shelf.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 2800);
}

// Browser Text-To-Speech Synthesis
function speakText(text) {
  if (!text || !('speechSynthesis' in window)) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = 1.0;
  window.speechSynthesis.speak(utterance);
}

// ==========================================================================
// System Status Polling Loop
// ==========================================================================

async function pollSystemStatus() {
  try {
    const res = await fetch('/status');
    if (!res.ok) throw new Error(`Status HTTP ${res.status}`);
    const data = await res.json();

    // Mark connection pill as active
    state.consecutiveErrorCount = 0;
    const connPill = $('connection-pill');
    const connText = $('connection-text');
    if (connPill && !connPill.classList.contains('status-connected')) {
      connPill.classList.add('status-connected');
      connText.textContent = 'Live Pipeline';
    }

    // Update Camera Telemetry
    if (data.camera) {
      const isCameraActive = Boolean(data.camera.is_opened || data.camera.opened);
      const camPill = $('camera-state-pill');
      if (camPill) {
        camPill.textContent = isCameraActive ? 'Camera Connected' : 'Camera Disconnected';
        camPill.style.color = isCameraActive ? '#10b981' : '#f59e0b';
      }
      const fallback = $('video-fallback');
      if (isCameraActive && fallback && !fallback.classList.contains('hidden')) {
        fallback.classList.add('hidden');
      }
    }

    // Update Recognition Telemetry
    if (data.recognition) {
      const stateBadge = $('rec-state-badge');
      if (stateBadge) {
        stateBadge.textContent = data.recognition.state || 'ACTIVE';
      }

      const timings = data.recognition.timings_ms;
      const timingsEl = $('rec-timings');
      const fpsValEl = $('fps-val');

      if (timings && timingsEl) {
        const tracking = timings.tracking_ms ? timings.tracking_ms.toFixed(1) : '0.0';
        const total = timings.total_ms ? timings.total_ms.toFixed(1) : '0.0';
        timingsEl.textContent = `Tracking: ${tracking} ms | Total: ${total} ms`;

        // Calculate approximate pipeline FPS from total per-frame latency
        if (timings.total_ms > 0 && fpsValEl) {
          const fps = Math.min(30.0, 1000.0 / timings.total_ms).toFixed(1);
          fpsValEl.textContent = fps;
        }
      }

      // Update Live Recognized Token Display Callout
      const tokenValEl = $('rec-token-val');
      const engineTagEl = $('rec-engine-tag');
      if (tokenValEl) {
        const currPred = data.recognition.current_prediction;
        const handsDetected = Boolean(data.recognition.hands_detected);
        const recState = data.recognition.state;

        if (handsDetected && currPred && currPred.is_accepted) {
          // Active live prediction
          tokenValEl.textContent = currPred.sign_name;
          tokenValEl.style.opacity = '1.0';
          if (engineTagEl) {
            engineTagEl.textContent = `${currPred.engine} (${(currPred.confidence * 100).toFixed(0)}% conf)`;
          }
        } else if (handsDetected) {
          // Hands present but observing / candidate
          tokenValEl.textContent = recState === 'CONFIRMED' ? '...' : (recState || 'OBSERVING');
          tokenValEl.style.opacity = '0.7';
          if (engineTagEl) {
            engineTagEl.textContent = 'HAND DETECTED — RECOGNIZING...';
          }
        } else {
          // No hands in frame -> explicitly UNAVAILABLE / READY
          tokenValEl.textContent = 'READY';
          tokenValEl.style.opacity = '0.5';
          if (engineTagEl) {
            engineTagEl.textContent = 'NO HANDS DETECTED';
          }
        }
      }
    }

    // Update Transcript Display
    if (data.transcript) {
      const normText = (data.transcript.normalized || data.transcript.text || '').trim();
      const rawText = (data.transcript.raw || data.transcript.text || '').trim();
      const tokenCount = data.transcript.token_count !== undefined
        ? data.transcript.token_count
        : (data.transcript.tokens ? data.transcript.tokens.length : 0);

      state.lastTranscriptRaw = rawText;
      state.lastTranscriptNormalized = normText;

      const displayEl = $('transcript-display');
      if (displayEl && !state.transcriptEditing && !state.transcriptEdited) {
        if (normText.length > 0) {
          displayEl.textContent = normText;
          displayEl.classList.remove('placeholder-text');
        } else if (rawText.length > 0) {
          displayEl.textContent = rawText;
          displayEl.classList.remove('placeholder-text');
        } else {
          displayEl.textContent = '';
          displayEl.classList.add('placeholder-text');
        }
      }

      // Update token callout
      const rawTokensEl = $('raw-tokens-display');
      if (rawTokensEl) {
        rawTokensEl.textContent = rawText ? `Tokens: ${rawText}` : 'Tokens: none';
      }

      const tokenCountBadge = $('token-count-badge');
      if (tokenCountBadge) {
        tokenCountBadge.textContent = `${tokenCount} token${tokenCount === 1 ? '' : 's'}`;
      }
    }

    // Update Ollama Model Tag
    const ollamaInfo = data.ollama || data.chatbot;
    if (ollamaInfo && ollamaInfo.model) {
      const ollamaBadgeText = $('ollama-badge-text');
      if (ollamaBadgeText) {
        ollamaBadgeText.textContent = ollamaInfo.model;
      }
    }

  } catch (err) {
    state.consecutiveErrorCount++;
    if (state.consecutiveErrorCount > 3) {
      const connPill = $('connection-pill');
      const connText = $('connection-text');
      if (connPill) {
        connPill.classList.remove('status-connected');
        connText.textContent = 'Connecting...';
      }
    }
  }
}

// ==========================================================================
// Transcript Actions
// ==========================================================================

async function clearTranscript() {
  try {
    const res = await fetch('/transcript/reset', { method: 'POST' });
    if (res.ok) {
      state.lastTranscriptRaw = '';
      state.lastTranscriptNormalized = '';
      state.transcriptEditing = false;
      state.transcriptEdited = false;
      const displayEl = $('transcript-display');
      if (displayEl) {
        displayEl.textContent = '';
        displayEl.classList.add('placeholder-text');
      }
      const rawTokensEl = $('raw-tokens-display');
      if (rawTokensEl) rawTokensEl.textContent = 'Tokens: none';
      const tokenCountBadge = $('token-count-badge');
      if (tokenCountBadge) tokenCountBadge.textContent = '0 tokens';
      const tokenValEl = $('rec-token-val');
      if (tokenValEl) tokenValEl.textContent = 'READY';
      showToast('Transcript cleared', '🗑️');
    }
  } catch (err) {
    showToast('Failed to clear transcript', '⚠️');
  }
}

function copyTranscript() {
  const text = getTranscriptText();
  if (!text) {
    showToast('Transcript is empty', 'ℹ️');
    return;
  }
  navigator.clipboard.writeText(text).then(() => {
    showToast('Copied transcript to clipboard', '📋');
  }).catch(() => {
    showToast('Clipboard copy failed', '⚠️');
  });
}

function speakTranscript() {
  const text = getTranscriptText();
  if (!text) {
    showToast('No text to speak', 'ℹ️');
    return;
  }
  speakText(text);
  showToast('Reading transcript aloud', '🔊');
}

function sendTranscriptToChat() {
  const text = getTranscriptText();
  if (!text) {
    showToast('No sign transcript available to send', 'ℹ️');
    return;
  }
  const inputEl = $('chat-input');
  if (inputEl) {
    inputEl.value = text;
    inputEl.focus();
  }
  sendChatMessage(text);
}

// ==========================================================================
// Ollama Chatbot Interaction
// ==========================================================================

function appendChatMessage(role, content, latencyMs = null) {
  const viewport = $('chat-messages');
  if (!viewport) return null;

  // Remove welcome banner on first message
  const welcome = viewport.querySelector('.chat-welcome');
  if (welcome) welcome.remove();

  const bubble = document.createElement('div');
  bubble.className = `chat-bubble ${role}`;

  const textNode = document.createElement('div');
  textNode.className = 'bubble-text';
  textNode.textContent = content;
  bubble.appendChild(textNode);

  if (latencyMs !== null) {
    const metaNode = document.createElement('div');
    metaNode.className = 'bubble-meta';
    metaNode.textContent = `⚡ ${(latencyMs / 1000).toFixed(2)}s`;
    bubble.appendChild(metaNode);
  }

  viewport.appendChild(bubble);
  viewport.scrollTop = viewport.scrollHeight;
  return bubble;
}

async function sendChatMessage(customText = null) {
  if (state.isSendingChat) return;

  const inputEl = $('chat-input');
  const text = (customText !== null ? customText : (inputEl ? inputEl.value : '')).trim();

  if (!text) {
    showToast('Please enter a message or accumulate signs', 'ℹ️');
    return;
  }

  if (inputEl) inputEl.value = '';

  // Append user bubble
  appendChatMessage('user', text);

  // Append loading placeholder
  const loadingBubble = appendChatMessage('assistant', 'Thinking...');
  state.isSendingChat = true;

  const sendBtn = $('btn-send-chat');
  if (sendBtn) sendBtn.disabled = true;

  try {
    const startTime = performance.now();
    const res = await fetch('/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ transcript: text }),
    });

    const elapsed = performance.now() - startTime;
    if (!res.ok) throw new Error(`HTTP ${res.status}`);

    const data = await res.json();
    if (loadingBubble) loadingBubble.remove();

    const responseText = data.text || 'No response returned from model.';
    const latency = data.latency_ms || elapsed;
    const displayedResponse = data.success
      ? responseText
      : `⚠️ ${data.status || 'Chat unavailable'} — ${responseText}`;
    appendChatMessage('assistant', displayedResponse, latency);

  } catch (err) {
    if (loadingBubble) loadingBubble.remove();
    appendChatMessage('assistant', `⚠️ Could not reach Ollama assistant: ${err.message}`);
    showToast('Chat request failed', '⚠️');
  } finally {
    state.isSendingChat = false;
    if (sendBtn) sendBtn.disabled = false;
  }
}

function clearChatHistory() {
  const viewport = $('chat-messages');
  if (viewport) {
    viewport.innerHTML = `
      <div class="chat-welcome">
        <span>👋</span>
        <div>
          <strong>Welcome to SIGNVISION Assistant.</strong>
          Recognized sign transcripts are formatted and answered using local Ollama (<code>qwen2.5:3b-instruct</code>). You can also type custom inquiries below.
        </div>
      </div>
    `;
    showToast('Chat history cleared', '🗑️');
  }
}

// ==========================================================================
// Video Feed & HUD Event Handlers
// ==========================================================================

function initVideoFeed() {
  const videoImg = $('video');
  const fallback = $('video-fallback');

  if (videoImg) {
    videoImg.onerror = () => {
      if (fallback) fallback.classList.remove('hidden');
      setTimeout(() => {
        videoImg.src = `/video_feed?t=${Date.now()}`;
      }, 1500);
    };
    videoImg.onload = () => {
      if (fallback) fallback.classList.add('hidden');
    };
  }

  const reloadBtn = $('btn-reload-stream');
  if (reloadBtn && videoImg) {
    reloadBtn.addEventListener('click', () => {
      videoImg.src = `/video_feed?t=${Date.now()}`;
      showToast('Reconnecting video feed...', '🔄');
    });
  }

  const snapshotBtn = $('btn-snapshot');
  if (snapshotBtn && videoImg) {
    snapshotBtn.addEventListener('click', () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = videoImg.naturalWidth || 640;
        canvas.height = videoImg.naturalHeight || 480;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(videoImg, 0, 0, canvas.width, canvas.height);
        const link = document.createElement('a');
        link.download = `signvision_snapshot_${Date.now()}.png`;
        link.href = canvas.toDataURL('image/png');
        link.click();
        showToast('Snapshot saved', '📸');
      } catch (e) {
        showToast('Snapshot requires active video feed', '⚠️');
      }
    });
  }
}

// ==========================================================================
// Initialization & Event Binding
// ==========================================================================

document.addEventListener('DOMContentLoaded', () => {
  initVideoFeed();

  // Transcript Button Handlers
  const clearBtn = $('btn-clear-transcript');
  if (clearBtn) clearBtn.addEventListener('click', clearTranscript);

  const copyBtn = $('btn-copy-transcript');
  if (copyBtn) copyBtn.addEventListener('click', copyTranscript);

  const speakBtn = $('btn-speak-transcript');
  if (speakBtn) speakBtn.addEventListener('click', speakTranscript);

  const sendToChatBtn = $('btn-send-to-chat');
  if (sendToChatBtn) sendToChatBtn.addEventListener('click', sendTranscriptToChat);

  const transcriptDisplay = $('transcript-display');
  if (transcriptDisplay) {
    transcriptDisplay.addEventListener('focus', () => {
      state.transcriptEditing = true;
    });
    transcriptDisplay.addEventListener('blur', () => {
      state.transcriptEditing = false;
    });
    transcriptDisplay.addEventListener('input', () => {
      state.transcriptEdited = true;
      transcriptDisplay.classList.toggle(
        'placeholder-text',
        transcriptDisplay.innerText.trim().length === 0,
      );
    });
  }

  // Chat Button Handlers
  const sendChatBtn = $('btn-send-chat');
  if (sendChatBtn) sendChatBtn.addEventListener('click', () => sendChatMessage());

  const chatInput = $('chat-input');
  if (chatInput) {
    chatInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        sendChatMessage();
      }
    });
  }

  const clearChatBtn = $('btn-clear-chat');
  if (clearChatBtn) clearChatBtn.addEventListener('click', clearChatHistory);

  // Start polling status
  pollSystemStatus();
  setInterval(pollSystemStatus, STATUS_POLL_INTERVAL_MS);
});
