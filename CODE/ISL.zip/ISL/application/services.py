"""SIGNVISION Application Layer - Service Implementations.

Coordinates camera capture, landmark extraction, recognition pipeline,
transcript accumulation, and downstream Ollama chatbot without duplicating logic.
"""

import asyncio
import logging
import threading
import time
from pathlib import Path
from typing import Any, AsyncIterator, Dict, List, Optional, Tuple, Union
import cv2
import numpy as np

logger = logging.getLogger("signvision.services")

from common.config import (
    AppConfig,
    CameraConfig,
    OllamaConfig,
    RecognitionConfig,
    TextProcessingConfig,
)
from common.exceptions import (
    CameraError,
    CameraUnavailableError,
    InvalidFrameError,
    ModelError,
    OllamaError,
)
from common.types import (
    ChatbotResponse,
    EngineType,
    FilteredToken,
    FrameData,
    GatedPrediction,
    LandmarkFrame,
    OllamaHealthStatus,
    RecognitionEvent,
    SignState,
    Transcript,
)
from detection.camera_stream import CameraStreamProtocol, OpenCVCameraStream
from detection.mediapipe_tracker import MediaPipeTracker
from detection.landmark_extractor import LandmarkExtractor
from recognition.pipeline import RecognitionPipeline
from text_processing.accumulator import TextAccumulator
from text_processing.syntax_rules import SyntaxNormalizer
from chatbot.ollama_client import OllamaClient
from chatbot.response_handler import ResponseHandler
from application.interfaces import (
    CameraServiceProtocol,
    RecognitionServiceProtocol,
    TranscriptServiceProtocol,
    ChatbotServiceProtocol,
)


class CameraService(CameraServiceProtocol):
    """Centralized camera manager ensuring a single active hardware capture instance."""

    def __init__(
        self,
        camera_stream: Optional[CameraStreamProtocol] = None,
        config: Optional[CameraConfig] = None,
    ) -> None:
        self.config = config or CameraConfig()
        self._stream: CameraStreamProtocol = camera_stream or OpenCVCameraStream(self.config)
        self._last_frame_data: Optional[FrameData] = None

    def start_camera(self) -> None:
        """Initialize and open the video capture hardware."""
        self._stream.start()

    def stop_camera(self) -> None:
        """Safely stop and release the camera stream."""
        self._stream.stop()
        self._last_frame_data = None

    def is_opened(self) -> bool:
        """Check if camera device is active and open."""
        return self._stream.is_opened()

    def get_latest_frame_data(self) -> Optional[FrameData]:
        """Capture and cache the latest FrameData safely."""
        if not self._stream.is_opened():
            return None
        try:
            frame_data = self._stream.read()
            self._last_frame_data = frame_data
            return frame_data
        except Exception as e:
            logger.warning(f"Camera frame capture failed: {e}")
            return None

    def get_latest_frame_jpeg(
        self,
        frame_data: Optional[FrameData] = None,
        hands_result: Any = None,
        landmark_frame: Optional[LandmarkFrame] = None,
        draw_landmarks: bool = True,
    ) -> bytes:
        """Encode the latest frame into JPEG bytes with visual landmark overlays."""
        target_frame = frame_data or self._last_frame_data or self.get_latest_frame_data()
        if target_frame is None or target_frame.frame is None:
            # Generate black placeholder frame (640x480)
            blank = np.zeros((480, 640, 3), dtype=np.uint8)
            cv2.putText(
                blank,
                "Camera Offline",
                (180, 240),
                cv2.FONT_HERSHEY_SIMPLEX,
                1.0,
                (0, 0, 255),
                2,
            )
            success, enc = cv2.imencode(".jpg", blank)
            return enc.tobytes() if success else b""

        # Convert RGB to BGR for OpenCV encoding
        if target_frame.frame.ndim == 3 and target_frame.frame.shape[2] == 3:
            frame_bgr = cv2.cvtColor(target_frame.frame, cv2.COLOR_RGB2BGR)
        else:
            frame_bgr = target_frame.frame.copy()

        # Visually render MediaPipe landmark overlay if hands detected
        if draw_landmarks and hands_result is not None and getattr(hands_result, "multi_hand_landmarks", None):
            try:
                import mediapipe as mp
                mp_drawing = mp.solutions.drawing_utils
                mp_hands = mp.solutions.hands

                for idx, hand_lms in enumerate(hands_result.multi_hand_landmarks):
                    # Emerald Green for right hand, Cyan/Blue for left hand
                    color = (0, 255, 128)
                    if getattr(hands_result, "multi_handedness", None) and idx < len(hands_result.multi_handedness):
                        label = hands_result.multi_handedness[idx].classification[0].label.lower()
                        if label == "left":
                            color = (255, 200, 0)

                    mp_drawing.draw_landmarks(
                        frame_bgr,
                        hand_lms,
                        mp_hands.HAND_CONNECTIONS,
                        mp_drawing.DrawingSpec(color=color, thickness=2, circle_radius=3),
                        mp_drawing.DrawingSpec(color=(255, 255, 255), thickness=1, circle_radius=1),
                    )
            except Exception as draw_err:
                logger.debug(f"Failed to draw landmark overlay: {draw_err}")

        success, enc = cv2.imencode(".jpg", frame_bgr)
        return enc.tobytes() if success else b""


class RecognitionService(RecognitionServiceProtocol):
    """Coordinates detection, landmark extraction, and recognition pipeline."""

    def __init__(
        self,
        pipeline: Optional[RecognitionPipeline] = None,
        tracker: Optional[MediaPipeTracker] = None,
        extractor: Optional[LandmarkExtractor] = None,
        config: Optional[RecognitionConfig] = None,
    ) -> None:
        self.config = config or RecognitionConfig()
        self.pipeline: RecognitionPipeline = pipeline or RecognitionPipeline.from_artifacts(config=self.config)
        self.tracker: MediaPipeTracker = tracker or MediaPipeTracker()
        self.extractor: LandmarkExtractor = extractor or LandmarkExtractor()

        self._last_timings: Dict[str, float] = {}
        self._last_event: Optional[RecognitionEvent] = None
        self._last_landmark_frame: Optional[LandmarkFrame] = None
        self._last_hands_result: Any = None
        self._last_pose_result: Any = None
        self._lock = threading.RLock()

    def process_frame_data(self, frame_data: FrameData) -> Optional[RecognitionEvent]:
        """Execute full detection -> tracking -> landmark extraction -> recognition."""
        with self._lock:
            t0 = time.perf_counter()
            hands_result, pose_result = self.tracker.process_frame(frame_data.frame)
            t1 = time.perf_counter()

            landmark_frame = self.extractor.extract(frame_data, hands_result, pose_result)
            t2 = time.perf_counter()

            # Cache perception artifacts for visualization without redundant inference
            self._last_hands_result = hands_result
            self._last_pose_result = pose_result
            self._last_landmark_frame = landmark_frame

            event = self.pipeline.process_frame(
                landmark_frame=landmark_frame,
                timestamp_ns=frame_data.timestamp_ns,
            )
            t3 = time.perf_counter()

            self._last_timings = {
                "tracking_ms": (t1 - t0) * 1000.0,
                "extraction_ms": (t2 - t1) * 1000.0,
                "recognition_ms": (t3 - t2) * 1000.0,
                "total_ms": (t3 - t0) * 1000.0,
            }
            self._last_event = event
            return event

    def process_landmarks(
        self, landmark_frame: LandmarkFrame, timestamp_ns: int
    ) -> Optional[RecognitionEvent]:
        """Directly process structured LandmarkFrame through the recognition pipeline."""
        with self._lock:
            t0 = time.perf_counter()
            self._last_landmark_frame = landmark_frame
            event = self.pipeline.process_frame(
                landmark_frame=landmark_frame,
                timestamp_ns=timestamp_ns,
            )
            t1 = time.perf_counter()
            self._last_timings = {
                "recognition_ms": (t1 - t0) * 1000.0,
                "total_ms": (t1 - t0) * 1000.0,
            }
            self._last_event = event
            return event

    def get_latest_landmark_frame(self) -> Optional[LandmarkFrame]:
        """Return the most recent structured LandmarkFrame or None if absent."""
        with self._lock:
            return self._last_landmark_frame

    def get_latest_hands_result(self) -> Any:
        """Return raw MediaPipe Hands result for rendering overlay."""
        with self._lock:
            return self._last_hands_result

    def process_latest_frame(self) -> Optional[FilteredToken]:
        """Legacy helper mapping RecognitionEvent to FilteredToken for protocol backwards compatibility."""
        with self._lock:
            if self._last_event is not None:
                return FilteredToken(
                    token=self._last_event.label,
                    engine=self._last_event.engine,
                    timestamp_ns=self._last_event.timestamp_ns,
                    confidence=self._last_event.confidence,
                )
            return None

    def get_current_state(self) -> SignState:
        """Return current recognition state machine state."""
        with self._lock:
            return self.pipeline.state_machine.get_state()

    def get_latest_prediction(self) -> Optional[GatedPrediction]:
        """Return the most recent gated prediction, or None if hands/body are not detected."""
        with self._lock:
            if self._last_landmark_frame is None or not (
                self._last_landmark_frame.has_any_hand or self._last_landmark_frame.has_pose
            ):
                return None
            return self.pipeline.confidence_gate.get_last_prediction()

    def get_latest_timings(self) -> Dict[str, float]:
        """Return detailed per-frame execution timings."""
        with self._lock:
            timings = dict(self._last_timings)
            timings.update(self.pipeline.get_last_timings())
            return timings

    def get_debug_telemetry(self) -> Dict[str, Any]:
        """Return diagnostic telemetry from the underlying recognition pipeline."""
        with self._lock:
            return self.pipeline.get_debug_telemetry()

    def reset(self) -> None:
        """Reset internal pipeline state machines and temporal buffers."""
        with self._lock:
            self.pipeline.reset()
            self._last_event = None
            self._last_landmark_frame = None
            self._last_hands_result = None
            self._last_pose_result = None
            self._last_timings.clear()


class TranscriptService(TranscriptServiceProtocol):
    """Manages transcript accumulation, character buffering, and syntax normalization."""

    def __init__(
        self,
        accumulator: Optional[TextAccumulator] = None,
        normalizer: Optional[SyntaxNormalizer] = None,
        config: Optional[TextProcessingConfig] = None,
    ) -> None:
        self.config = config or TextProcessingConfig()
        self.accumulator: TextAccumulator = accumulator or TextAccumulator.from_config(self.config)
        self.normalizer: SyntaxNormalizer = normalizer or SyntaxNormalizer()
        self._lock = threading.RLock()

    def consume_event(self, event: Optional[RecognitionEvent]) -> str:
        """Feed verified RecognitionEvent into transcript accumulator."""
        with self._lock:
            return self.accumulator.add_event(event)

    def append_token(self, token: str) -> str:
        """Append token string directly."""
        with self._lock:
            return self.accumulator.add_token(token)

    def commit_word(self) -> Optional[str]:
        """Commit currently buffered static characters."""
        with self._lock:
            return self.accumulator.commit_current_word()

    def backspace(self) -> str:
        """Remove last token or buffered character."""
        with self._lock:
            return self.accumulator.backspace()

    def clear(self) -> None:
        """Clear all transcript tokens and character buffers."""
        with self._lock:
            self.accumulator.clear_all()

    def get_transcript(self, include_partial: bool = False) -> str:
        """Get formatted transcript string."""
        with self._lock:
            return self.accumulator.get_transcript(include_partial=include_partial)

    def get_normalized_transcript(self) -> str:
        """Return clean English sentence with normalized casing."""
        with self._lock:
            raw_text = self.accumulator.get_transcript(include_partial=False)
            return self.normalizer.normalize_sentence(raw_text)

    def get_transcript_object(self) -> Transcript:
        """Return immutable consolidated Transcript dataclass."""
        with self._lock:
            return self.accumulator.get_transcript_object()

    def get_tokens(self) -> List[str]:
        """Return copy of accumulated individual tokens."""
        with self._lock:
            return self.accumulator.get_tokens()


class ChatbotService(ChatbotServiceProtocol):
    """Coordinates downstream Ollama interactions with graceful fallback recovery."""

    def __init__(
        self,
        response_handler: Optional[ResponseHandler] = None,
        client: Optional[OllamaClient] = None,
        config: Optional[OllamaConfig] = None,
    ) -> None:
        self.config = config or OllamaConfig()
        self.client: OllamaClient = client or OllamaClient(self.config)
        self.response_handler: ResponseHandler = response_handler or ResponseHandler(
            client=self.client, config=self.config
        )

    async def get_response(
        self, transcript_input: Union[str, Transcript]
    ) -> ChatbotResponse:
        """Generate conversational response using Ollama."""
        return await self.response_handler.process_transcript(transcript_input)

    async def translate_transcript(self, transcript: str) -> str:
        """Translate ISL transcript to fluent English."""
        resp = await self.get_response(transcript)
        return resp.text

    async def translate_transcript_stream(self, transcript: str) -> AsyncIterator[str]:
        """Stream translation tokens."""
        async for token in self.client.generate_stream(transcript):
            yield token

    async def get_system_status(self) -> Dict[str, Any]:
        """Check Ollama availability and model status."""
        health = await self.client.check_health()
        return {
            "health": health.value,
            "model": self.client.model_name,
            "base_url": self.client.base_url,
        }


class SignVisionApplication:
    """Master application coordinator tying all five stages into a cohesive runtime."""

    def __init__(
        self,
        config: Optional[AppConfig] = None,
        camera_service: Optional[CameraService] = None,
        recognition_service: Optional[RecognitionService] = None,
        transcript_service: Optional[TranscriptService] = None,
        chatbot_service: Optional[ChatbotService] = None,
    ) -> None:
        self.config = config or AppConfig()
        self.camera_service = camera_service or CameraService(config=self.config.camera)
        self.recognition_service = recognition_service or RecognitionService(
            config=self.config.recognition
        )
        self.transcript_service = transcript_service or TranscriptService(
            config=self.config.text_processing
        )
        self.chatbot_service = chatbot_service or ChatbotService(
            config=self.config.ollama
        )

        self._is_running: bool = False
        self._last_interaction_timings: Dict[str, float] = {}

        # Dedicated perception worker & bounded latest-frame buffer (Task 7 CRIT-01)
        self._perception_thread: Optional[threading.Thread] = None
        self._worker_running: bool = False
        self._worker_error: Optional[str] = None
        self._worker_frame_count: int = 0
        self._worker_fps: float = 0.0
        self._latest_frame_id: int = 0
        self._latest_jpeg: Optional[bytes] = None
        self._frame_lock = threading.Lock()
        self._app_lock = threading.RLock()

    def startup(self, start_worker: bool = True) -> None:
        """Initialize services and prepare runtime."""
        self._is_running = True
        try:
            if not self.camera_service.is_opened():
                self.camera_service.start_camera()
        except Exception as e:
            logger.error(f"Failed to initialize camera on startup: {e}")

        if start_worker:
            self.start_worker()

    def shutdown(self) -> None:
        """Release camera, tracker, and model resources cleanly."""
        self.stop_worker()
        with self._app_lock:
            self.camera_service.stop_camera()
            self.recognition_service.reset()

    def start_worker(self) -> None:
        """Start the dedicated perception worker thread if not already running."""
        if self._perception_thread is not None and self._perception_thread.is_alive():
            return
        self._is_running = True
        self._perception_thread = threading.Thread(
            target=self._perception_worker,
            name="SignVisionPerceptionWorker",
            daemon=True,
        )
        self._perception_thread.start()
        logger.info("SignVision dedicated perception worker started.")

    def stop_worker(self) -> None:
        """Stop the dedicated perception worker thread cleanly."""
        self._is_running = False
        if self._perception_thread is not None and self._perception_thread.is_alive():
            self._perception_thread.join(timeout=2.0)
            self._perception_thread = None
        self._worker_running = False
        logger.info("SignVision dedicated perception worker stopped.")

    def is_worker_running(self) -> bool:
        """Return whether the dedicated perception worker thread is alive."""
        return self._perception_thread is not None and self._perception_thread.is_alive()

    def get_latest_annotated_frame(self) -> Tuple[int, bytes]:
        """Return the newest (frame_id, jpeg_bytes) from the bounded latest-frame buffer."""
        with self._frame_lock:
            if self._latest_jpeg is not None:
                return self._latest_frame_id, self._latest_jpeg
        return 0, self.camera_service.get_latest_frame_jpeg()

    def get_latest_annotated_jpeg(self) -> bytes:
        """Return newest JPEG bytes from the bounded frame buffer."""
        with self._frame_lock:
            if self._latest_jpeg is not None:
                return self._latest_jpeg
        return self.camera_service.get_latest_frame_jpeg()

    def reset_transcript(self) -> None:
        """Thread-safe reset of transcript state."""
        with self._app_lock:
            self.transcript_service.clear()

    def _perception_worker(self) -> None:
        """Authoritative, dedicated perception loop.

        Owns camera acquisition and step_frame() execution.
        Encodes latest annotated frame once and publishes to bounded latest-frame buffer.
        """
        logger.info("SignVision perception worker loop entered.")
        self._worker_running = True
        self._worker_error = None
        fps_start = time.perf_counter()
        fps_count = 0

        while self._is_running:
            try:
                if not self.camera_service.is_opened():
                    time.sleep(0.05)
                    continue

                frame_data = self.camera_service.get_latest_frame_data()
                if frame_data is not None and frame_data.frame is not None:
                    # Authoritative perception step
                    self.step_frame(frame_data)

                    # Encode annotated frame once for all presentation consumers
                    latest_hands = self.recognition_service.get_latest_hands_result()
                    latest_lms = self.recognition_service.get_latest_landmark_frame()
                    jpeg_bytes = self.camera_service.get_latest_frame_jpeg(
                        frame_data,
                        hands_result=latest_hands,
                        landmark_frame=latest_lms,
                    )
                    with self._frame_lock:
                        self._latest_jpeg = jpeg_bytes
                        self._latest_frame_id += 1
                        self._worker_frame_count += 1
                        fps_count += 1

                    # Update worker FPS measurement
                    now = time.perf_counter()
                    elapsed = now - fps_start
                    if elapsed >= 1.0:
                        self._worker_fps = fps_count / elapsed
                        fps_start = now
                        fps_count = 0
                else:
                    time.sleep(0.01)
            except Exception as e:
                self._worker_error = str(e)
                logger.error(f"Perception worker loop error: {e}", exc_info=True)
                time.sleep(0.05)

        self._worker_running = False
        logger.info("SignVision perception worker loop terminated.")

    def step_frame(
        self, frame_data: Optional[FrameData] = None
    ) -> Tuple[Optional[RecognitionEvent], Transcript]:
        """Execute one per-frame cycle: capture -> detect -> recognize -> accumulate.

        NOTE: Does NOT call Ollama on per-frame execution (CPU/RAM preservation).
        """
        with self._app_lock:
            if frame_data is None:
                frame_data = self.camera_service.get_latest_frame_data()

            if frame_data is None:
                return None, self.transcript_service.get_transcript_object()

            # Execute recognition
            event = self.recognition_service.process_frame_data(frame_data)

            # Ingest into text processing if token produced
            if event is not None:
                self.transcript_service.consume_event(event)

            return event, self.transcript_service.get_transcript_object()

    async def trigger_chat(
        self, transcript_override: Optional[str] = None
    ) -> ChatbotResponse:
        """Trigger Ollama response generation on current or provided transcript."""
        if transcript_override is not None:
            target_transcript = transcript_override
        else:
            with self._app_lock:
                target_transcript = self.transcript_service.get_transcript(include_partial=False)

        t0 = time.perf_counter()
        # Non-blocking async call outside _app_lock so perception worker is never delayed
        response = await self.chatbot_service.get_response(target_transcript)
        t1 = time.perf_counter()

        with self._app_lock:
            self._last_interaction_timings = {
                "chatbot_ms": (t1 - t0) * 1000.0,
                "total_ms": (t1 - t0) * 1000.0,
            }
        return response

    async def get_system_status(self) -> Dict[str, Any]:
        """Return consolidated runtime system status across all modules."""
        # Query Ollama outside _app_lock to avoid blocking perception worker loop
        ollama_status = await self.chatbot_service.get_system_status()

        with self._app_lock:
            rec_timings = self.recognition_service.get_latest_timings()
            transcript_obj = self.transcript_service.get_transcript_object()
            norm_transcript = self.transcript_service.get_normalized_transcript()
            worker_running = self.is_worker_running()
            worker_frame_count = self._worker_frame_count
            worker_fps = self._worker_fps
            worker_error = self._worker_error
            cam_opened = self.camera_service.is_opened()
            cam_index = self.camera_service.config.camera_index
            app_running = self._is_running
            rec_state = self.recognition_service.get_current_state().value
            static_loaded = self.recognition_service.pipeline.static_classifier is not None
            dynamic_loaded = self.recognition_service.pipeline.dynamic_classifier is not None
            latest_pred = self.recognition_service.get_latest_prediction()
            latest_lms = self.recognition_service.get_latest_landmark_frame()
            hands_detected = bool(latest_lms.has_any_hand) if latest_lms is not None else False
            debug_telemetry = self.recognition_service.get_debug_telemetry()

        return {
            "app_status": "RUNNING" if app_running else "STOPPED",
            "camera": {
                "opened": cam_opened,
                "is_opened": cam_opened,
                "index": cam_index,
            },
            "perception_worker": {
                "running": worker_running,
                "frame_count": worker_frame_count,
                "fps": round(worker_fps, 2),
                "error": worker_error,
            },
            "recognition": {
                "state": rec_state,
                "hands_detected": hands_detected,
                "has_prediction": latest_pred is not None and latest_pred.is_accepted,
                "current_prediction": {
                    "sign_name": latest_pred.sign_name,
                    "confidence": round(float(latest_pred.confidence), 4),
                    "margin": round(float(latest_pred.margin), 4),
                    "engine": latest_pred.engine.value,
                    "is_accepted": latest_pred.is_accepted,
                    "status": latest_pred.status.value,
                } if (latest_pred is not None and (hands_detected or latest_pred.engine == EngineType.DYNAMIC)) else None,
                "static_model_loaded": static_loaded,
                "dynamic_model_loaded": dynamic_loaded,
                "timings_ms": rec_timings,
                "debug": debug_telemetry,
            },
            "transcript": {
                "text": transcript_obj.text,
                "raw": transcript_obj.text,
                "normalized": norm_transcript,
                "token_count": len(transcript_obj.tokens),
                "tokens": list(transcript_obj.tokens),
                "partial_word": transcript_obj.partial_word,
                "state": transcript_obj.state.value,
                "revision": transcript_obj.revision,
            },
            "ollama": ollama_status,
        }
