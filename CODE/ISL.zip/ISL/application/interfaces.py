"""SIGNVISION Application Layer - Service Interfaces Contract.

Defines high-level coordination protocols for application lifecycle,
video streaming, recognition orchestrator, transcript management, and chatbot.
The application layer coordinates modules but contains NO computer vision math
or model training algorithms.
"""

from abc import ABC, abstractmethod
from typing import AsyncIterator, Dict, List, Optional, Any, Union
import numpy as np
from common.types import (
    ChatbotResponse,
    FilteredToken,
    FrameData,
    GatedPrediction,
    LandmarkFrame,
    RecognitionEvent,
    SignState,
    Transcript,
)


class CameraServiceProtocol(ABC):
    """Coordinates webcam capture for the web backend."""

    @abstractmethod
    def start_camera(self) -> None:
        """Start camera capture."""
        pass

    @abstractmethod
    def stop_camera(self) -> None:
        """Stop camera capture."""
        pass

    @abstractmethod
    def get_latest_frame_jpeg(self) -> bytes:
        """Return the latest frame encoded as JPEG for MJPEG browser streaming."""
        pass

    @abstractmethod
    def get_latest_frame_data(self) -> Optional[FrameData]:
        """Return the latest raw FrameData object."""
        pass

    @abstractmethod
    def is_opened(self) -> bool:
        """Return whether camera is active and opened."""
        pass


class RecognitionServiceProtocol(ABC):
    """Coordinates detection, preprocessing, and classification engines."""

    @abstractmethod
    def process_latest_frame(self) -> Optional[FilteredToken]:
        """Execute one complete forward step: detect -> preprocess -> infer -> gate -> filter."""
        pass

    @abstractmethod
    def process_frame_data(self, frame_data: FrameData) -> Optional[RecognitionEvent]:
        """Process an acquired camera FrameData through tracking, extraction, and recognition."""
        pass

    @abstractmethod
    def process_landmarks(
        self, landmark_frame: LandmarkFrame, timestamp_ns: int
    ) -> Optional[RecognitionEvent]:
        """Directly process a structured LandmarkFrame through the recognition pipeline."""
        pass

    @abstractmethod
    def get_current_state(self) -> SignState:
        """Return current recognition state machine state."""
        pass

    @abstractmethod
    def get_latest_prediction(self) -> Optional[GatedPrediction]:
        """Return the most recent gated prediction."""
        pass

    @abstractmethod
    def reset(self) -> None:
        """Reset internal temporal buffers and state machines."""
        pass


class TranscriptServiceProtocol(ABC):
    """Coordinates transcript operations for the UI."""

    @abstractmethod
    def consume_event(self, event: Optional[RecognitionEvent]) -> str:
        """Ingest a RecognitionEvent into the transcript accumulator."""
        pass

    @abstractmethod
    def append_token(self, token: str) -> str:
        """Append token directly to transcript."""
        pass

    @abstractmethod
    def backspace(self) -> str:
        """Remove last token or buffered character."""
        pass

    @abstractmethod
    def clear(self) -> None:
        """Clear all transcript buffers."""
        pass

    @abstractmethod
    def get_transcript(self, include_partial: bool = False) -> str:
        """Get formatted transcript string."""
        pass

    @abstractmethod
    def get_transcript_object(self) -> Transcript:
        """Return immutable consolidated Transcript dataclass."""
        pass


class ChatbotServiceProtocol(ABC):
    """Coordinates local Ollama interactions for the UI."""

    @abstractmethod
    async def get_response(
        self, transcript_input: Union[str, Transcript]
    ) -> ChatbotResponse:
        """Generate conversational response using Ollama."""
        pass

    @abstractmethod
    async def translate_transcript(self, transcript: str) -> str:
        """Translate ISL transcript to fluent English."""
        pass

    @abstractmethod
    async def translate_transcript_stream(self, transcript: str) -> AsyncIterator[str]:
        """Stream translation tokens."""
        pass

    @abstractmethod
    async def get_system_status(self) -> Dict[str, Any]:
        """Return camera, model, and Ollama service health statuses."""
        pass
