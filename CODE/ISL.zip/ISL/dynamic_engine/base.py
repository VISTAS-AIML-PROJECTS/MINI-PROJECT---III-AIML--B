"""SIGNVISION Dynamic Engine - Base Classifier Contract & Shared Logic.

Defines the generic interface and BaseDynamicClassifier providing shared sequence
inference, margin computation, and prediction formatting for temporal classifiers.
"""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union
import numpy as np
from common.types import PredictionResult, EngineType
from common.exceptions import (
    ModelError,
    ModelInferenceError,
    ModelNotLoadedError,
    InvalidSequenceLengthError,
    InvalidFeatureShapeError,
)


class DynamicClassifierProtocol(ABC):
    """Abstract contract for dynamic word/phrase temporal sequence classifiers."""

    @abstractmethod
    def fit(self, X: np.ndarray, y: np.ndarray) -> "DynamicClassifierProtocol":
        pass

    @abstractmethod
    def predict(self, sequence: np.ndarray) -> int:
        pass

    @abstractmethod
    def predict_proba(self, sequence: np.ndarray) -> np.ndarray:
        pass

    @abstractmethod
    def infer(self, sequence: np.ndarray, class_names: List[str]) -> PredictionResult:
        pass

    @abstractmethod
    def save(self, filepath: Union[str, Path]) -> None:
        pass

    @abstractmethod
    def load(self, filepath: Union[str, Path]) -> "DynamicClassifierProtocol":
        pass

    @abstractmethod
    def metadata(self) -> Dict[str, Any]:
        pass


class BaseDynamicClassifier(DynamicClassifierProtocol):
    """Base implementation providing shared sequence probability parsing, confidence, and margin calculation."""

    def __init__(self) -> None:
        self.is_fitted: bool = False
        self.expected_seq_len: Optional[int] = None
        self.expected_dim: Optional[int] = None
        self.num_classes: Optional[int] = None

    def is_ready(self) -> bool:
        """Check if the classifier is loaded/fitted and ready for inference."""
        return self.is_fitted

    def infer(self, sequence: np.ndarray, class_names: List[str]) -> PredictionResult:
        """Execute full sequence inference, computing top class, confidence, and margin."""
        proba = self.predict_proba(sequence)
        if proba is None or len(proba) == 0:
            raise ModelInferenceError("Classifier returned empty probability array.")

        sorted_indices = np.argsort(proba)[::-1]
        top_idx = int(sorted_indices[0])
        top_conf = float(proba[top_idx])

        margin = (
            float(proba[top_idx] - proba[sorted_indices[1]])
            if len(proba) > 1
            else top_conf
        )

        name = class_names[top_idx] if top_idx < len(class_names) else f"class_{top_idx}"

        return PredictionResult(
            engine=EngineType.DYNAMIC,
            class_id=top_idx,
            class_name=name,
            confidence=top_conf,
            probabilities=proba,
            margin=margin,
        )


class SklearnDynamicClassifier(BaseDynamicClassifier):
    """Concrete dynamic classifier wrapping scikit-learn estimators on flattened sequences."""

    def __init__(
        self,
        estimator: Optional[Any] = None,
        scaler: Optional[Any] = None,
        temporal_slice: Optional[Tuple[int, int]] = None,
        expected_seq_len: int = 33,
        expected_dim: int = 45,
        num_classes: Optional[int] = None,
        class_names: Optional[List[str]] = None,
        metadata_dict: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__()
        self.estimator = estimator
        self.scaler = scaler
        self.temporal_slice = temporal_slice
        self.expected_seq_len = expected_seq_len
        self.expected_dim = expected_dim
        self.num_classes = num_classes
        self.class_names = list(class_names) if class_names is not None else None
        self._custom_metadata = metadata_dict or {}

        if estimator is not None and hasattr(estimator, "classes_"):
            self.is_fitted = True
            self.num_classes = len(estimator.classes_)

    def _prepare_input(self, sequence: np.ndarray) -> np.ndarray:
        """Convert input sequence into flattened, scaled feature vector."""
        if sequence is None or not isinstance(sequence, np.ndarray):
            raise InvalidFeatureShapeError("Input sequence must be a valid NumPy ndarray.")

        arr = np.asarray(sequence, dtype=np.float32)
        is_single = (arr.ndim == 2)
        if is_single:
            arr = np.expand_dims(arr, axis=0)  # (1, T, D)

        if arr.ndim != 3:
            raise InvalidFeatureShapeError(f"Expected 2D or 3D sequence array, got shape {sequence.shape}")

        if np.isnan(arr).any() or np.isinf(arr).any():
            raise InvalidFeatureShapeError("Input sequence contains NaN or Inf values.")

        N, T, D = arr.shape

        if self.expected_seq_len is not None and T != self.expected_seq_len:
            raise InvalidSequenceLengthError(
                f"Expected sequence length {self.expected_seq_len}, but got {T}."
            )

        if D not in (self.expected_dim, 168):
            raise InvalidFeatureShapeError(
                f"Expected feature dimension {self.expected_dim} (or 168 canonical), but got {D}."
            )

        # Convert 168-D canonical sequence to validated 45-D dynamic features if needed
        if D == 168:
            from preprocessing.canonicalizer import LandmarkPreprocessingPipeline
            arr = LandmarkPreprocessingPipeline.extract_45d_features(arr)
            D = 45

        # Optional temporal slicing (e.g. active window)
        if self.temporal_slice is not None:
            start_f, end_f = self.temporal_slice
            arr = arr[:, start_f:end_f, :]
            T = arr.shape[1]

        # Flatten (N, T, D) -> (N, T * D)
        flat = arr.reshape(N, T * D)

        if self.scaler is not None:
            flat = self.scaler.transform(flat)

        return flat[0] if is_single else flat

    def fit(self, X: np.ndarray, y: np.ndarray) -> "SklearnDynamicClassifier":
        """Fit the underlying estimator on training sequences."""
        if self.estimator is None:
            raise ModelInferenceError("Cannot fit: estimator is None.")

        # X can be (N, T, D) or already flattened
        if X.ndim == 3:
            X_in = self._prepare_input(X)
        else:
            X_in = X

        self.estimator.fit(X_in, y)
        self.is_fitted = True
        self.num_classes = len(self.estimator.classes_)
        return self

    def predict(self, sequence: np.ndarray) -> int:
        """Predict class index for an incoming temporal sequence."""
        if not self.is_fitted or self.estimator is None:
            raise ModelNotLoadedError("Model is not fitted or loaded.")

        X_in = self._prepare_input(sequence)
        if X_in.ndim == 1:
            X_in = X_in.reshape(1, -1)
        preds = self.estimator.predict(X_in)
        return int(preds[0])

    def predict_proba(self, sequence: np.ndarray) -> np.ndarray:
        """Predict class probabilities for an incoming temporal sequence."""
        if not self.is_fitted or self.estimator is None:
            raise ModelNotLoadedError("Model is not fitted or loaded.")

        X_in = self._prepare_input(sequence)
        if X_in.ndim == 1:
            X_in = X_in.reshape(1, -1)

        if hasattr(self.estimator, "predict_proba"):
            probs = self.estimator.predict_proba(X_in)
            return np.asarray(probs[0], dtype=np.float32)
        elif hasattr(self.estimator, "decision_function"):
            df = self.estimator.decision_function(X_in)[0]
            exp_df = np.exp(df - np.max(df))
            return (exp_df / np.sum(exp_df)).astype(np.float32)
        else:
            raise ModelInferenceError("Estimator has neither predict_proba nor decision_function.")

    def save(self, filepath: Union[str, Path]) -> None:
        """Serialize model and metadata to disk."""
        if not self.is_fitted or self.estimator is None:
            raise ModelNotLoadedError("Cannot save un-fitted model.")
        import joblib

        fp = Path(filepath)
        fp.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "estimator": self.estimator,
            "scaler": self.scaler,
            "temporal_slice": self.temporal_slice,
            "expected_seq_len": self.expected_seq_len,
            "expected_dim": self.expected_dim,
            "num_classes": self.num_classes,
            "class_names": self.class_names,
            "metadata": self.metadata(),
        }
        joblib.dump(payload, fp)

    def load(self, filepath: Union[str, Path]) -> "SklearnDynamicClassifier":
        """Deserialize model from disk."""
        import joblib

        fp = Path(filepath)
        if not fp.exists():
            raise FileNotFoundError(f"Model file not found: {fp}")
        try:
            payload = joblib.load(fp)
        except Exception as e:
            raise ModelError(f"Corrupted or invalid dynamic model file {fp}: {e}") from e
        if isinstance(payload, dict) and "estimator" in payload:
            self.estimator = payload["estimator"]
            self.scaler = payload.get("scaler")
            self.temporal_slice = payload.get("temporal_slice")
            self.expected_seq_len = payload.get("expected_seq_len", 33)
            self.expected_dim = payload.get("expected_dim", 45)
            self.num_classes = payload.get("num_classes")
            self.class_names = payload.get("class_names")
            self._custom_metadata = payload.get("metadata", {})
        else:
            self.estimator = payload
            self.num_classes = len(self.estimator.classes_) if hasattr(self.estimator, "classes_") else None
        self.is_fitted = True
        return self

    def metadata(self) -> Dict[str, Any]:
        """Return runtime metadata dictionary."""
        base_meta = {
            "estimator_type": self.estimator.__class__.__name__ if self.estimator else "None",
            "is_fitted": self.is_fitted,
            "expected_seq_len": self.expected_seq_len,
            "expected_dim": self.expected_dim,
            "temporal_slice": self.temporal_slice,
            "num_classes": self.num_classes,
            "has_scaler": self.scaler is not None,
        }
        base_meta.update(self._custom_metadata)
        return base_meta


class PyTorchDynamicClassifier(BaseDynamicClassifier):
    """Concrete dynamic classifier wrapping a PyTorch neural temporal model."""

    def __init__(
        self,
        module: Optional[Any] = None,
        temporal_slice: Optional[Tuple[int, int]] = None,
        expected_seq_len: int = 33,
        expected_dim: int = 45,
        num_classes: Optional[int] = None,
        class_names: Optional[List[str]] = None,
        metadata_dict: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__()
        self.module = module
        self.temporal_slice = temporal_slice
        self.expected_seq_len = expected_seq_len
        self.expected_dim = expected_dim
        self.num_classes = num_classes
        self.class_names = list(class_names) if class_names is not None else None
        self._custom_metadata = metadata_dict or {}

        if self.module is not None:
            self.is_fitted = True
            if hasattr(self.module, "num_classes"):
                self.num_classes = self.module.num_classes

    def _prepare_tensor(self, sequence: np.ndarray) -> Any:
        """Convert sequence into PyTorch tensor of shape (B, T, D)."""
        import torch

        if sequence is None or not isinstance(sequence, np.ndarray):
            raise InvalidFeatureShapeError("Input sequence must be a valid NumPy ndarray.")

        arr = np.asarray(sequence, dtype=np.float32)
        if arr.ndim == 2:
            arr = np.expand_dims(arr, axis=0)  # (1, T, D)

        if arr.ndim != 3:
            raise InvalidFeatureShapeError(f"Expected 2D or 3D sequence array, got shape {sequence.shape}")

        N, T, D = arr.shape
        if D == 168:
            from preprocessing.canonicalizer import LandmarkPreprocessingPipeline
            arr = LandmarkPreprocessingPipeline.extract_45d_features(arr)
            D = 45

        if self.temporal_slice is not None:
            start_f, end_f = self.temporal_slice
            arr = arr[:, start_f:end_f, :]

        return torch.from_numpy(arr).float()

    def fit(self, X: np.ndarray, y: np.ndarray) -> "PyTorchDynamicClassifier":
        """Marker fit method for dynamic contract compliance."""
        self.is_fitted = True
        return self

    def predict(self, sequence: np.ndarray) -> int:
        """Predict class index for an incoming temporal sequence."""
        proba = self.predict_proba(sequence)
        return int(np.argmax(proba))

    def predict_proba(self, sequence: np.ndarray) -> np.ndarray:
        """Predict class probabilities for an incoming temporal sequence."""
        import torch

        if not self.is_fitted or self.module is None:
            raise ModelNotLoadedError("Model is not fitted or loaded.")

        t_in = self._prepare_tensor(sequence)
        self.module.eval()
        with torch.no_grad():
            logits = self.module(t_in)
            probs = torch.softmax(logits, dim=-1).cpu().numpy()

        return probs[0].astype(np.float32)

    def save(self, filepath: Union[str, Path]) -> None:
        """Serialize PyTorch state dict and model configuration to disk."""
        import torch

        if not self.is_fitted or self.module is None:
            raise ModelNotLoadedError("Cannot save un-fitted model.")

        fp = Path(filepath)
        fp.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "state_dict": self.module.state_dict(),
            "module_class": self.module.__class__.__name__,
            "temporal_slice": self.temporal_slice,
            "expected_seq_len": self.expected_seq_len,
            "expected_dim": self.expected_dim,
            "num_classes": self.num_classes,
            "class_names": self.class_names,
            "metadata": self.metadata(),
        }
        torch.save(payload, fp)

    def load(self, filepath: Union[str, Path]) -> "PyTorchDynamicClassifier":
        """Deserialize PyTorch model state from disk."""
        import torch

        fp = Path(filepath)
        if not fp.exists():
            raise FileNotFoundError(f"Model file not found: {fp}")

        payload = torch.load(fp, map_location="cpu", weights_only=False)
        self.temporal_slice = payload.get("temporal_slice")
        self.expected_seq_len = payload.get("expected_seq_len", 33)
        self.expected_dim = payload.get("expected_dim", 45)
        self.num_classes = payload.get("num_classes", 76)
        self.class_names = payload.get("class_names")
        self._custom_metadata = payload.get("metadata", {})

        if self.module is not None:
            self.module.load_state_dict(payload["state_dict"])
            self.module.eval()

        self.is_fitted = True
        return self

    def metadata(self) -> Dict[str, Any]:
        """Return runtime metadata dictionary."""
        base_meta = {
            "module_type": self.module.__class__.__name__ if self.module else "None",
            "is_fitted": self.is_fitted,
            "expected_seq_len": self.expected_seq_len,
            "expected_dim": self.expected_dim,
            "temporal_slice": self.temporal_slice,
            "num_classes": self.num_classes,
        }
        base_meta.update(self._custom_metadata)
        return base_meta
