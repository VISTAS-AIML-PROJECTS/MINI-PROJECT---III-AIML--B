# TechPilot

**Navigate Your Skills. Build Your Future.**

TechPilot is a mobile-first, AI-guided learning and career app for students. It takes a learner from "I don't know what to learn" to job-ready skills through a personalised roadmap, practice, projects and career tracking.

Built with React 19, Vite, Tailwind CSS v4 and Capacitor (Android).

## Features

- **Onboarding**: basic details, interests, career goal, learning preferences, aptitude check
- **AI Skill Profile**: strengths, gaps and recommended domain
- **Home**: daily mission, overall progress, current roadmap, daily challenge, achievements
- **Learn**: personalised roadmap and lessons
- **Practice**: coding, UI/UX, IoT, cybersecurity and data science challenges
- **Projects**: project-based learning across domains
- **Career**: readiness score, missing skills, recommended actions, internship and job matching
- **AI Mentor** and **Profile** screens
- Gamification: XP, levels, progress rings, achievements
- Dark-first, glassmorphism UI

## Tech Stack

| Area | Tools |
|---|---|
| UI | React 19, TypeScript 5.7 |
| Styling | Tailwind CSS v4 |
| Build | Vite 8 |
| Mobile | Capacitor 8 (Android) |
| CI | GitHub Actions (debug APK) |

## Project Structure

```
src/
  App.tsx              App shell, auth and bottom navigation
  main.tsx             Entry point
  index.css            Global styles, Tailwind import
  components/          Home, Learn, Practice, Projects, Career,
                       Onboarding, SkillProfile, AIMentor, Profile
  imports/pasted_text/ Product brief
public/                Static assets
android/               Capacitor Android project
.github/workflows/     APK build workflow
capacitor.config.ts    appId: com.techpilot.app
```

## Getting Started

Requirements: Node.js 22, npm.

```bash
npm install
npm run dev        # dev server
npm run build      # production build to dist/
npm run preview    # preview the build
```

## Build the Android APK

Locally (Android SDK and JDK 21 required):

```bash
npm run build
npx cap sync android
cd android
./gradlew assembleDebug
```

Output: `android/app/build/outputs/apk/debug/app-debug.apk`

Via GitHub Actions: the **Build SkillPilot APK** workflow runs on every push to `main` (or manually from the Actions tab) and uploads the debug APK as an artifact.

## Notes

- `android/local.properties` is machine-specific and not committed. Android Studio generates it.
- Images are tracked with Git LFS (see `.gitattributes`). Run `git lfs install` before cloning or pushing.

## Product Brief

Full spec: [`src/imports/pasted_text/techpilot-product-brief.md`](src/imports/pasted_text/techpilot-product-brief.md)
