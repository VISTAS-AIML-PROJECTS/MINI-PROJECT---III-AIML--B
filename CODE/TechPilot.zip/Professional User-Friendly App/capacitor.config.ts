import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.techpilot.app',
  appName: 'TechPilot',
  webDir: 'dist'
};

export default config;
