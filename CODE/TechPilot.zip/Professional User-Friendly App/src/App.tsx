import { useState } from "react";
import Onboarding, { type OnboardingData } from "./components/Onboarding";
import SkillProfile from "./components/SkillProfile";
import Home from "./components/Home";
import Learn from "./components/Learn";
import Practice from "./components/Practice";
import Projects from "./components/Projects";
import Career from "./components/Career";
import AIMentor from "./components/AIMentor";
import Profile from "./components/Profile";

type AppScreen = "auth" | "onboarding" | "skillprofile" | "app";
type AppTab = "home" | "learn" | "practice" | "projects" | "career";
type AuthMode = "login" | "signup";

const navItems: { id: AppTab; label: string; icon: string }[] = [
  { id: "home", label: "Home", icon: "◫" },
  { id: "learn", label: "Learn", icon: "▣" },
  { id: "practice", label: "Practice", icon: "△" },
  { id: "projects", label: "Projects", icon: "◧" },
  { id: "career", label: "Career", icon: "✦" },
];

function AuthScreen({ onContinue }: { onContinue: () => void }) {
  const [mode, setMode] = useState<AuthMode>("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const isSignup = mode === "signup";

  return (
    <div className="size-full flex items-start justify-center px-5 pt-14 pb-6 orbit-bg" style={{ fontFamily: "var(--font-outfit)" }}>
      <div className="w-full max-w-md rounded-[30px] border border-white/10 bg-slate-950/55 px-6 py-5 shadow-2xl shadow-indigo-950/40 backdrop-blur-xl">
        <div className="flex flex-col items-center text-center">
          <div className="logo-orbit mb-3">
            <img src="/logo.jpeg" alt="TechPilot" className="relative z-10 h-14 w-14 rounded-2xl object-cover border border-indigo-400/50 shadow-lg shadow-indigo-500/30" />
          </div>
          <h1 className="text-3xl font-black tracking-tight text-white">TechPilot</h1>
          <p className="mt-2 text-sm text-white/60">Let’s build your personalized learning path</p>
        </div>

        <div className="mt-6 flex overflow-hidden rounded-2xl border border-white/10 bg-white/5 p-1">
          <button
            type="button"
            onClick={() => setMode("login")}
            className={`flex-1 rounded-xl px-4 py-2.5 text-sm font-semibold transition-all ${mode === "login" ? "bg-white text-slate-900 shadow-md" : "text-white/70"}`}
          >
            Log in
          </button>
          <button
            type="button"
            onClick={() => setMode("signup")}
            className={`flex-1 rounded-xl px-4 py-2.5 text-sm font-semibold transition-all ${mode === "signup" ? "bg-white text-slate-900 shadow-md" : "text-white/70"}`}
          >
            Sign up
          </button>
        </div>

        <div className="mt-6 space-y-4">
          {isSignup && (
            <div>
              <label className="mb-2 block text-sm font-medium text-white/70">Full Name</label>
              <input
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="Enter your name"
                className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3.5 text-sm text-white placeholder:text-white/30 outline-none transition-all focus:border-indigo-400 focus:bg-white/7"
              />
            </div>
          )}

          <div>
            <label className="mb-2 block text-sm font-medium text-white/70">Email</label>
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="name@example.com"
              className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3.5 text-sm text-white placeholder:text-white/30 outline-none transition-all focus:border-indigo-400 focus:bg-white/7"
            />
          </div>

          <div>
            <label className="mb-2 block text-sm font-medium text-white/70">Password</label>
            <input
              type="password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="Enter your password"
              className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3.5 text-sm text-white placeholder:text-white/30 outline-none transition-all focus:border-indigo-400 focus:bg-white/7"
            />
          </div>
        </div>

        <button
          type="button"
          onClick={onContinue}
          className="btn-primary mt-6 flex w-full items-center justify-center rounded-2xl px-4 py-3.5 text-base font-semibold shadow-lg shadow-indigo-500/30"
        >
          {isSignup ? "Create account" : "Log in"}
        </button>

        <div className="mt-5 flex items-center gap-3 text-white/30">
          <div className="h-px flex-1 bg-white/10" />
          <span className="text-[10px] uppercase tracking-[0.2em]">or</span>
          <div className="h-px flex-1 bg-white/10" />
        </div>

        <button
          type="button"
          onClick={onContinue}
          className="google-btn mt-5 flex w-full items-center justify-center gap-3 rounded-2xl border border-slate-200 bg-white px-4 py-3.5 text-base font-semibold text-slate-900 shadow-lg shadow-slate-900/15 transition-transform hover:scale-[1.01]"
        >
          <svg viewBox="0 0 24 24" aria-hidden="true" className="h-5 w-5">
            <path fill="#EA4335" d="M12 10.2v3.98h5.5c-.24 1.4-1.66 4.12-5.5 4.12-3.3 0-6-2.7-6-6s2.7-6 6-6c1.88 0 3.14.8 3.86 1.48l2.64-2.56C16.9 3.35 14.7 2.4 12 2.4 6.9 2.4 2.8 6.5 2.8 11.6s4.1 9.2 9.2 9.2c5.3 0 8.8-3.72 8.8-8.97 0-.6-.04-1.05-.1-1.5H12Z"/>
            <path fill="#34A853" d="M3.8 7.3l3.5 2.56c.95-1.8 2.88-3.06 4.7-3.06 1.88 0 3.14.8 3.86 1.48l2.64-2.56C16.9 3.35 14.7 2.4 12 2.4c-3.7 0-6.86 2.1-8.2 5.1Z"/>
            <path fill="#FBBC05" d="M12 21.8c2.72 0 5.02-.9 6.7-2.46l-3.09-2.67c-.86.6-1.96 1.03-3.61 1.03-3.3 0-5.26-2.18-5.5-4.12l-3.2 2.5A9.2 9.2 0 0 0 12 21.8Z"/>
            <path fill="#4285F4" d="M2.8 11.6c0-1.42.34-2.77 1-3.93l-3.22-2.5A9.2 9.2 0 0 0 2.8 11.6Zm9.2 9.2c1.76 0 3.28-.5 4.38-1.38l-3.1-2.66c-.62.4-1.4.64-2.28.64-1.6 0-2.95-.96-3.62-2.3l-3.2 2.5A9.2 9.2 0 0 0 12 20.8Z"/>
          </svg>
          <span>Continue with Google</span>
        </button>
      </div>
    </div>
  );
}

export default function App() {
  const [screen, setScreen] = useState<AppScreen>("auth");
  const [activeTab, setActiveTab] = useState<AppTab>("home");
  const [userData, setUserData] = useState<OnboardingData | null>(null);
  const [showMentor, setShowMentor] = useState(false);
  const [showProfile, setShowProfile] = useState(false);

  function handleOnboardingComplete(data: OnboardingData) {
    setUserData(data);
    setScreen("skillprofile");
  }

  function handleEnterApp() {
    setScreen("app");
  }

  function handleAuthContinue() {
    setScreen("onboarding");
  }

  if (screen === "auth") {
    return <AuthScreen onContinue={handleAuthContinue} />;
  }

  // Splash / Onboarding
  if (screen === "onboarding") {
    return (
      <div className="size-full overflow-y-auto">
        <Onboarding onComplete={handleOnboardingComplete} />
      </div>
    );
  }

  // Skill Profile
  if (screen === "skillprofile" && userData) {
    return (
      <div className="size-full overflow-y-auto">
        <SkillProfile data={userData} onEnterApp={handleEnterApp} />
      </div>
    );
  }

  // Main App
  return (
    <div className="size-full flex flex-col overflow-hidden orbit-bg" style={{ fontFamily: "var(--font-outfit)" }}>
      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto relative">
        {showProfile && userData ? (
          <div>
            <div className="px-5 pt-12 pb-4 flex items-center gap-4 glass-strong border-b" style={{ borderColor: "rgba(255,255,255,0.06)" }}>
              <button onClick={() => setShowProfile(false)}
                className="w-10 h-10 glass rounded-full flex items-center justify-center text-white/60">←</button>
              <h1 className="text-xl font-bold text-white">Profile</h1>
            </div>
            <Profile userData={userData} />
          </div>
        ) : (
          <>
            {activeTab === "home" && userData && (
              <Home userData={userData} onOpenMentor={() => setShowMentor(true)} />
            )}
            {activeTab === "learn" && <Learn />}
            {activeTab === "practice" && <Practice />}
            {activeTab === "projects" && <Projects />}
            {activeTab === "career" && <Career />}
          </>
        )}
      </div>

      {/* Bottom Navigation */}
      {!showProfile && (
        <div className="bottom-nav flex-shrink-0">
          <div className="flex items-center px-2 py-2">
            {navItems.map(({ id, label, icon }) => (
              <button
                key={id}
                onClick={() => setActiveTab(id)}
                className="flex-1 flex flex-col items-center gap-0.5 py-2 transition-all"
              >
                <span className={`text-xl transition-all ${activeTab === id ? "scale-110" : "scale-100 opacity-50"}`}>
                  {icon}
                </span>
                <span className={`text-xs font-semibold transition-all ${activeTab === id ? "text-indigo-400" : "text-white/30"}`}>
                  {label}
                </span>
                {activeTab === id && (
                  <div className="w-1 h-1 rounded-full bg-indigo-400 mt-0.5" />
                )}
              </button>
            ))}
            {/* Profile button */}
            <button
              onClick={() => setShowProfile(true)}
              className="flex-1 flex flex-col items-center gap-0.5 py-2 transition-all"
            >
              <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all ${showProfile ? "ring-2 ring-indigo-400" : "opacity-50"}`}
                style={{ background: "linear-gradient(135deg, #6366f1, #8b5cf6)" }}>
                {userData?.name?.[0]?.toUpperCase() || "U"}
              </div>
              <span className={`text-xs font-semibold ${showProfile ? "text-indigo-400" : "text-white/30"}`}>Profile</span>
            </button>
          </div>
        </div>
      )}

      {/* Floating AI Mentor Button */}
      {!showProfile && (
        <button
          onClick={() => setShowMentor(true)}
          className="fixed bottom-24 right-5 w-14 h-14 rounded-full flex items-center justify-center text-2xl z-40 glow-blue transition-all hover:scale-110 active:scale-95"
          style={{ background: "linear-gradient(135deg, #3d7bff, #5a7cff)", boxShadow: "0 8px 28px rgba(61,123,255,0.35)" }}
        >
          🤖
        </button>
      )}

      {/* AI Mentor Overlay */}
      {showMentor && <AIMentor onClose={() => setShowMentor(false)} />}
    </div>
  );
}
