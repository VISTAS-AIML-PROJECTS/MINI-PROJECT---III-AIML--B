import { useState, useRef, useEffect } from "react";

interface Message {
  role: "user" | "ai";
  content: string;
  followUp?: string;
  code?: string;
}

const suggestions = [
  "Explain this simply",
  "Give me an example",
  "Test my knowledge",
  "Give me a challenge",
  "Why is this useful?",
];

const responses: Record<string, Message> = {
  default: {
    role: "ai",
    content: "Great question! Let me break this down for you in a simple way.",
    followUp: "Try this yourself: What do you think would happen if you changed the value? Give it a try!",
  },
  "function": {
    role: "ai",
    content: "A **function** is like a mini-program inside your program. You define it once and can use it many times.\n\nThink of it like a coffee machine — you put in coffee beans (input), press a button, and get coffee (output). You don't need to know how it works inside!",
    code: "def make_coffee(beans):\n    result = brew(beans)\n    return result\n\n# Use it anywhere!\ncoffee = make_coffee('arabica')\nprint(coffee)  # Your coffee is ready!",
    followUp: "Try this: Write a function called greet() that takes a name and returns 'Hello, [name]!'. What would greet('Pilot') return?",
  },
  "explain": {
    role: "ai",
    content: "Sure! Let me explain the current concept in the simplest way possible.\n\nImagine you're learning to cook. A **variable** is like a container — you put something in it and can use it later. A function is like a recipe — a set of steps you follow to get a result.",
    followUp: "Does this analogy make sense? Try using variables and a function together in your next exercise!",
  },
  "example": {
    role: "ai",
    content: "Here's a real-world example! Let's say you're building a simple student grade calculator.",
    code: "def calculate_grade(marks):\n    if marks >= 90:\n        return 'A'\n    elif marks >= 75:\n        return 'B'\n    elif marks >= 60:\n        return 'C'\n    else:\n        return 'Fail'\n\n# Try it!\nprint(calculate_grade(85))  # B\nprint(calculate_grade(92))  # A",
    followUp: "What would calculate_grade(55) return? And can you modify it to include an 'A+' grade for 95+?",
  },
  "challenge": {
    role: "ai",
    content: "Time for a challenge.\n\nWrite a Python function that takes a list of numbers and returns:\n• The sum\n• The average\n• The maximum\n\nReturn all three as a dictionary.",
    code: "# Your challenge:\ndef analyze_numbers(numbers):\n    # Write your code here!\n    pass\n\n# Expected output:\n# analyze_numbers([10, 20, 30, 40])\n# → {'sum': 100, 'avg': 25.0, 'max': 40}",
    followUp: "Take your time! Hint: Python has built-in functions sum(), len(), and max() that will help you.",
  },
  "test": {
    role: "ai",
    content: "Let me test your knowledge.\n\nWhat is the output of this code?\n\n```python\nx = [1, 2, 3]\ny = x\ny.append(4)\nprint(len(x))\n```\n\nThink about it carefully — this is testing whether you understand how Python handles list references.",
    followUp: "Take your time. Hint: When you assign y = x, are you creating a copy or a reference?",
  },
};

function getAIResponse(input: string): Message {
  const lower = input.toLowerCase();
  if (lower.includes("function") || lower.includes("function na") || lower.includes("enna")) return responses["function"];
  if (lower.includes("explain") || lower.includes("simple")) return responses["explain"];
  if (lower.includes("example")) return responses["example"];
  if (lower.includes("challenge")) return responses["challenge"];
  if (lower.includes("test") || lower.includes("quiz")) return responses["test"];
  return responses["default"];
}

interface AIMentorProps {
  onClose: () => void;
}

export default function AIMentor({ onClose }: AIMentorProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "ai",
      content: "Hey! I'm your AI Mentor.\n\nI'm here to help you learn — not just give answers. I'll explain things simply, give examples, and ask questions to make sure it really sticks.\n\nWhat do you want to learn today?",
    }
  ]);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const [language, setLanguage] = useState<"en" | "ta" | "simple">("en");
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, typing]);

  function sendMessage(text: string) {
    if (!text.trim()) return;
    const userMsg: Message = { role: "user", content: text };
    setMessages(m => [...m, userMsg]);
    setInput("");
    setTyping(true);
    setTimeout(() => {
      const response = getAIResponse(text);
      setTyping(false);
      setMessages(m => [...m, response]);
    }, 1200 + Math.random() * 800);
  }

  return (
    <div className="fixed inset-0 z-50 flex flex-col" style={{ background: "#050714", fontFamily: "var(--font-outfit)" }}>
      {/* Header */}
      <div className="px-5 pt-12 pb-4 glass-strong border-b" style={{ borderColor: "rgba(255,255,255,0.06)" }}>
        <div className="flex items-center gap-4">
          <button onClick={onClose} className="w-10 h-10 glass rounded-full flex items-center justify-center text-white/60">←</button>
          <div className="flex items-center gap-3 flex-1">
            <div className="w-10 h-10 rounded-full relative flex-shrink-0">
              <img src="/logo.jpeg" alt="TechPilot AI" className="w-full h-full rounded-full object-cover border border-indigo-500/50" />
              <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-400 rounded-full border-2" style={{ borderColor: "#050714" }} />
            </div>
            <div>
              <div className="font-bold text-white text-sm">TechPilot AI Mentor</div>
              <div className="text-xs text-green-400 font-medium">● Online · Always available</div>
            </div>
          </div>
          <div className="flex gap-1">
            {(["en", "ta", "simple"] as const).map(l => (
              <button key={l} onClick={() => setLanguage(l)}
                className={`px-2 py-1 rounded-lg text-xs font-semibold transition-all ${language === l ? "bg-indigo-500 text-white" : "glass text-white/40"}`}>
                {l === "en" ? "EN" : l === "ta" ? "தமிழ்" : "Simple"}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-5 py-4 flex flex-col gap-4">
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"} fade-in-up`}>
            {msg.role === "ai" && (
              <img src="/logo.jpeg" alt="TechPilot AI" className="w-8 h-8 rounded-full object-cover border border-indigo-500/40 flex-shrink-0 mr-3 mt-0.5 shadow-sm" />
            )}
            <div className={`max-w-[82%] ${msg.role === "user"
              ? "bg-indigo-500 rounded-3xl rounded-br-lg px-4 py-3 text-white"
              : "flex flex-col gap-3"}`}>
              {msg.role === "ai" ? (
                <>
                  <div className="card px-4 py-3 rounded-3xl rounded-tl-lg">
                    <p className="text-white/85 text-sm leading-relaxed whitespace-pre-line">{msg.content}</p>
                  </div>
                  {msg.code && (
                    <div className="rounded-2xl overflow-hidden" style={{ border: "1px solid rgba(99,102,241,0.3)" }}>
                      <div className="px-4 py-2 flex items-center gap-2" style={{ background: "rgba(99,102,241,0.15)" }}>
                        <div className="flex gap-1.5">
                          <div className="w-2.5 h-2.5 rounded-full bg-red-500/60" />
                          <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/60" />
                          <div className="w-2.5 h-2.5 rounded-full bg-green-500/60" />
                        </div>
                        <span className="text-xs text-white/40 ml-1" style={{ fontFamily: "var(--font-jetbrains)" }}>python</span>
                      </div>
                      <div className="p-4 text-xs overflow-x-auto" style={{ background: "#0d1117", fontFamily: "var(--font-jetbrains)" }}>
                        {msg.code.split("\n").map((line, li) => (
                          <div key={li} className="flex gap-3 leading-relaxed">
                            <span className="text-white/20 select-none w-4 text-right flex-shrink-0">{li + 1}</span>
                            <span className={line.startsWith("#") ? "text-white/35" : line.includes("def ") || line.includes("return") || line.includes("if ") || line.includes("elif ") || line.includes("else") ? "text-purple-400" : "text-white/80"}>{line}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  {msg.followUp && (
                    <div className="card px-4 py-3 rounded-2xl" style={{ borderColor: "rgba(99,102,241,0.3)", background: "rgba(99,102,241,0.08)" }}>
                      <p className="text-indigo-300 text-xs leading-relaxed">{msg.followUp}</p>
                    </div>
                  )}
                </>
              ) : (
                <p className="text-sm leading-relaxed">{msg.content}</p>
              )}
            </div>
          </div>
        ))}

        {typing && (
          <div className="flex items-center gap-3 fade-in-up">
            <img src="/logo.jpeg" alt="TechPilot AI" className="w-8 h-8 rounded-full object-cover border border-indigo-500/40 flex-shrink-0 shadow-sm" />
            <div className="card px-4 py-3 rounded-3xl rounded-tl-lg flex gap-1.5 items-center">
              {[0, 1, 2].map(i => (
                <div key={i} className="w-2 h-2 rounded-full bg-indigo-400"
                  style={{ animation: `bounce 1s ease-in-out ${i * 0.2}s infinite` }} />
              ))}
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Suggestions */}
      <div className="px-5 pb-3">
        <div className="flex gap-2 overflow-x-auto pb-1" style={{ scrollbarWidth: "none" }}>
          {suggestions.map(s => (
            <button key={s} onClick={() => sendMessage(s)}
              className="flex-shrink-0 px-3 py-2 glass rounded-full text-xs font-medium text-indigo-300 border transition-all hover:border-indigo-500/50"
              style={{ borderColor: "rgba(99,102,241,0.25)" }}>
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Input */}
      <div className="px-5 pb-8 pt-2">
        <div className="flex gap-3 items-end">
          <input
            ref={inputRef}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && !e.shiftKey && (e.preventDefault(), sendMessage(input))}
            placeholder="Ask anything... (English or Tamil)"
            className="flex-1 glass rounded-2xl px-4 py-3.5 text-sm text-white placeholder-white/25 outline-none"
            style={{ border: "1px solid rgba(255,255,255,0.08)", transition: "border 0.2s" }}
            onFocus={e => e.target.style.border = "1px solid rgba(99,102,241,0.5)"}
            onBlur={e => e.target.style.border = "1px solid rgba(255,255,255,0.08)"}
          />
          <button onClick={() => sendMessage(input)}
            disabled={!input.trim()}
            className="w-12 h-12 rounded-2xl flex items-center justify-center text-white font-bold flex-shrink-0 disabled:opacity-30 transition-all"
            style={{ background: "linear-gradient(135deg, #6366f1, #8b5cf6)" }}>
            ↑
          </button>
        </div>
      </div>

      <style>{`
        @keyframes bounce {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-6px); }
        }
      `}</style>
    </div>
  );
}
