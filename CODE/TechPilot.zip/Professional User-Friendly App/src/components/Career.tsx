import { useState } from "react";

const skills = [
  { name: "Python", score: 85, color: "#10b981" },
  { name: "Machine Learning", score: 45, color: "#6366f1" },
  { name: "DSA", score: 60, color: "#8b5cf6" },
  { name: "SQL", score: 55, color: "#06b6d4" },
  { name: "Git/GitHub", score: 40, color: "#f59e0b" },
  { name: "Communication", score: 72, color: "#ec4899" },
];

const missingSkills = [
  { name: "React", priority: "High", action: "Complete Web Dev Level 2" },
  { name: "REST APIs", priority: "High", action: "Build a backend project" },
  { name: "System Design", priority: "Medium", action: "Start System Design track" },
  { name: "DSA Level 3", priority: "High", action: "Complete DSA Week 4" },
];

const internships = [
  {
    role: "ML Intern", company: "TechCorp AI", location: "Remote",
    match: 87, stipend: "₹15,000/month", duration: "3 months",
    missing: ["TensorFlow", "Model Deployment"],
    logo: "🤖", type: "Full-time Internship",
  },
  {
    role: "Python Developer Intern", company: "DataFlow Inc.", location: "Chennai",
    match: 82, stipend: "₹12,000/month", duration: "6 months",
    missing: ["REST APIs", "Django"],
    logo: "🐍", type: "Full-time Internship",
  },
  {
    role: "Data Analyst Intern", company: "Analytics Pro", location: "Bangalore",
    match: 74, stipend: "₹10,000/month", duration: "3 months",
    missing: ["Tableau", "Advanced SQL"],
    logo: "📊", type: "Part-time Available",
  },
];

const mockInterviewRoles = [
  { role: "Software Developer", icon: "💻" },
  { role: "AI/ML Engineer", icon: "🤖" },
  { role: "Data Scientist", icon: "📊" },
  { role: "UI/UX Designer", icon: "🎨" },
];

export default function Career() {
  const [tab, setTab] = useState<"overview" | "internships" | "interview">("overview");
  const [interviewRole, setInterviewRole] = useState("");
  const [interviewType, setInterviewType] = useState("");
  const [showScore, setShowScore] = useState(false);

  const careerReadiness = 78;

  return (
    <div className="min-h-full orbit-bg" style={{ fontFamily: "var(--font-outfit)" }}>
      <div className="px-5 pt-12 pb-4">
        <h1 className="text-2xl font-bold text-white mb-1">Career Hub</h1>
        <p className="text-white/50 text-sm">Your path to job readiness</p>
      </div>

      {/* Tabs */}
      <div className="px-5 pb-4">
        <div className="glass rounded-2xl p-1 flex gap-1">
          {[
            { id: "overview", label: "Overview" },
            { id: "internships", label: "Internships" },
            { id: "interview", label: "Mock Interview" },
          ].map(({ id, label }) => (
            <button key={id} onClick={() => setTab(id as typeof tab)}
              className={`flex-1 py-2.5 rounded-xl text-sm font-semibold transition-all ${tab === id ? "bg-indigo-500 text-white" : "text-white/50 hover:text-white"}`}>
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* Overview Tab */}
      {tab === "overview" && (
        <div className="px-5 pb-8 flex flex-col gap-5">
          {/* Readiness */}
          <div className="rounded-3xl p-5 relative overflow-hidden"
            style={{ background: "linear-gradient(135deg, rgba(99,102,241,0.2), rgba(139,92,246,0.2))", border: "1px solid rgba(99,102,241,0.35)" }}>
            <div className="flex items-center justify-between mb-3">
              <div>
                <div className="text-xs font-bold text-indigo-400 uppercase tracking-widest mb-1">Career Readiness</div>
                <div className="text-4xl font-black gradient-text">{careerReadiness}%</div>
                <div className="flex items-center gap-2 mt-1">
                  <div className="w-2 h-2 rounded-full bg-yellow-400" />
                  <span className="text-yellow-400 text-sm font-semibold">Almost Job Ready</span>
                </div>
              </div>
              <div className="w-20 h-20 rounded-full flex items-center justify-center relative"
                style={{ background: "conic-gradient(#6366f1 0deg, #8b5cf6 281deg, rgba(255,255,255,0.05) 281deg)", }}>
                <div className="w-14 h-14 rounded-full flex items-center justify-center"
                  style={{ background: "#050714" }}>
                  <span className="text-xl">💼</span>
                </div>
              </div>
            </div>
            <div className="progress-bar h-2">
              <div className="progress-fill" style={{ width: `${careerReadiness}%` }} />
            </div>
            <p className="text-white/50 text-xs mt-2">Complete 3 more milestones to unlock job applications</p>
          </div>

          {/* Skills */}
          <div>
            <h2 className="font-bold text-white mb-3">Skill Breakdown</h2>
            <div className="card p-5 flex flex-col gap-4">
              {skills.map(({ name, score, color }) => (
                <div key={name}>
                  <div className="flex justify-between text-sm mb-1.5">
                    <span className="font-medium text-white">{name}</span>
                    <span className="font-bold" style={{ color }}>{score}%</span>
                  </div>
                  <div className="progress-bar h-2">
                    <div className="h-full rounded-full transition-all duration-1000" style={{ width: `${score}%`, background: color }} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Missing Skills */}
          <div>
            <h2 className="font-bold text-white mb-3">Skills to Improve</h2>
            <div className="flex flex-col gap-2">
              {missingSkills.map(({ name, priority, action }) => (
                <div key={name} className="card p-4 flex items-center gap-4">
                  <div className={`w-2 h-2 rounded-full flex-shrink-0 ${priority === "High" ? "bg-red-400" : "bg-yellow-400"}`} />
                  <div className="flex-1">
                    <div className="font-semibold text-white text-sm">{name}</div>
                    <div className="text-xs text-white/40 mt-0.5">→ {action}</div>
                  </div>
                  <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${priority === "High" ? "bg-red-500/15 text-red-400" : "bg-yellow-500/15 text-yellow-400"}`}>
                    {priority}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Assessment Score */}
          <div className="card p-5">
            <div className="text-xs font-bold text-white/40 uppercase tracking-widest mb-4">Skill Assessment Score</div>
            <div className="flex items-center gap-4 mb-4">
              <div className="text-5xl font-black gradient-text">74</div>
              <div className="text-white/50 text-sm">/ 100</div>
            </div>
            {[
              { label: "Technical Knowledge", score: 80 },
              { label: "Problem Solving", score: 70 },
              { label: "Practical Skills", score: 82 },
              { label: "Projects", score: 60 },
              { label: "Communication", score: 72 },
            ].map(({ label, score }) => (
              <div key={label} className="mb-3">
                <div className="flex justify-between text-xs mb-1.5">
                  <span className="text-white/60">{label}</span>
                  <span className="text-white font-semibold">{score}%</span>
                </div>
                <div className="progress-bar h-1.5">
                  <div className="h-full rounded-full bg-indigo-500" style={{ width: `${score}%` }} />
                </div>
              </div>
            ))}
          </div>

          {/* Resume & Portfolio */}
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: "Resume Builder", icon: "📄", sub: "ATS-friendly", color: "#6366f1" },
              { label: "Portfolio", icon: "🌐", sub: "techpilot.app/u/jaison", color: "#8b5cf6" },
            ].map(({ label, icon, sub, color }) => (
              <div key={label} className="card card-hover p-4 text-center cursor-pointer">
                <div className="text-3xl mb-2">{icon}</div>
                <div className="font-bold text-white text-sm">{label}</div>
                <div className="text-xs text-white/40 mt-0.5">{sub}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Internships Tab */}
      {tab === "internships" && (
        <div className="px-5 pb-8 flex flex-col gap-4">
          <div className="card p-4 flex items-start gap-3">
            <p className="text-white/60 text-xs leading-relaxed">
              Opportunities are matched based on your current skills, domain, and progress. Skill match improves as you complete more lessons and projects.
            </p>
          </div>
          {internships.map((job, i) => (
            <div key={i} className="card card-hover p-5 cursor-pointer">
              <div className="flex items-start gap-4 mb-4">
                <div className="w-12 h-12 rounded-2xl glass flex items-center justify-center text-2xl flex-shrink-0">{job.logo}</div>
                <div className="flex-1">
                  <h3 className="font-bold text-white">{job.role}</h3>
                  <p className="text-white/50 text-sm">{job.company}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-xs text-white/40">{job.location}</span>
                    <span className="text-xs text-white/40">· {job.type}</span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-lg font-black" style={{ color: job.match >= 85 ? "#10b981" : job.match >= 75 ? "#f59e0b" : "#ef4444" }}>
                    {job.match}%
                  </div>
                  <div className="text-xs text-white/40">Match</div>
                </div>
              </div>
              <div className="progress-bar h-1.5 mb-3">
                <div className="h-full rounded-full" style={{ width: `${job.match}%`, background: job.match >= 85 ? "#10b981" : job.match >= 75 ? "#f59e0b" : "#ef4444" }} />
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-white/50">{job.stipend} · {job.duration}</span>
              </div>
              {job.missing.length > 0 && (
                <div className="mt-3 pt-3 border-t" style={{ borderColor: "rgba(255,255,255,0.06)" }}>
                  <p className="text-xs text-white/40 mb-2">Missing skills:</p>
                  <div className="flex flex-wrap gap-1.5">
                    {job.missing.map(s => (
                      <span key={s} className="text-xs px-2 py-1 rounded-full bg-red-500/10 text-red-400 border border-red-500/20">{s}</span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Interview Tab */}
      {tab === "interview" && (
        <div className="px-5 pb-8 flex flex-col gap-5">
          {!showScore ? (
            <>
              <div>
                <h2 className="font-bold text-white mb-3">Select Role</h2>
                <div className="grid grid-cols-2 gap-2">
                  {mockInterviewRoles.map(({ role, icon }) => (
                    <button key={role} onClick={() => setInterviewRole(role)}
                      className={`card py-4 px-3 text-center transition-all ${interviewRole === role ? "border-indigo-500 bg-indigo-500/15" : "hover:border-white/20"}`}>
                      <div className="text-2xl mb-1">{icon}</div>
                      <div className={`text-xs font-semibold ${interviewRole === role ? "text-white" : "text-white/60"}`}>{role}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h2 className="font-bold text-white mb-3">Interview Type</h2>
                <div className="grid grid-cols-2 gap-2">
                  {["Technical", "HR", "Behavioral", "Aptitude"].map(t => (
                    <button key={t} onClick={() => setInterviewType(t)}
                      className={`py-3 px-4 rounded-2xl text-sm font-semibold transition-all ${interviewType === t ? "bg-indigo-500 text-white" : "glass text-white/60 hover:text-white"}`}>
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h2 className="font-bold text-white mb-3">Difficulty</h2>
                <div className="grid grid-cols-3 gap-2">
                  {["Easy", "Medium", "Hard"].map(d => (
                    <button key={d} className="py-3 glass rounded-2xl text-sm font-semibold text-white/60 hover:text-white transition-all">{d}</button>
                  ))}
                </div>
              </div>

              <button
                onClick={() => { if (interviewRole && interviewType) setShowScore(true); }}
                disabled={!interviewRole || !interviewType}
                className="btn-primary w-full py-4 font-semibold disabled:opacity-30">
                Start Mock Interview
              </button>
            </>
          ) : (
            <div className="flex flex-col gap-5 fade-in-up">
              <div className="text-center py-6">
                <div className="text-3xl mb-3">🎙️</div>
                <h2 className="text-xl font-bold text-white mb-1">Interview Complete!</h2>
                <p className="text-white/50 text-sm">{interviewRole} · {interviewType}</p>
              </div>

              <div className="card p-5 text-center">
                <div className="text-6xl font-black gradient-text mb-1">76</div>
                <div className="text-white/50 text-sm">/ 100</div>
                <div className="mt-4 progress-bar h-3">
                  <div className="progress-fill" style={{ width: "76%" }} />
                </div>
              </div>

              {[
                { label: "Communication", score: 80, color: "#10b981" },
                { label: "Technical Knowledge", score: 72, color: "#6366f1" },
                { label: "Problem Solving", score: 78, color: "#8b5cf6" },
                { label: "Confidence", score: 70, color: "#06b6d4" },
                { label: "Answer Quality", score: 76, color: "#f59e0b" },
              ].map(({ label, score, color }) => (
                <div key={label} className="card p-4">
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-white font-medium">{label}</span>
                    <span className="font-bold" style={{ color }}>{score}%</span>
                  </div>
                  <div className="progress-bar h-1.5">
                    <div className="h-full rounded-full" style={{ width: `${score}%`, background: color }} />
                  </div>
                </div>
              ))}

              <div className="card p-4">
                <h3 className="font-bold text-white text-sm mb-2">Improvement Tips</h3>
                <ul className="text-white/60 text-xs space-y-1.5">
                  <li>• Use STAR method for behavioral questions</li>
                  <li>• Practice more system design problems</li>
                  <li>• Be more specific when explaining time complexity</li>
                  <li>• Slow down when explaining complex concepts</li>
                </ul>
              </div>

              <button onClick={() => { setShowScore(false); setInterviewRole(""); setInterviewType(""); }}
                className="btn-primary w-full py-4 font-semibold">
                Try Another Interview
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
