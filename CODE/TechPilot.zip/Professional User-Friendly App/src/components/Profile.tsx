import type { OnboardingData } from "./Onboarding";

interface ProfileProps {
  userData: OnboardingData;
}

const badges = [
  { icon: "◧", label: "7 Day Streak", color: "#f97316" },
  { icon: "✦", label: "First 100 XP", color: "#f59e0b" },
  { icon: "◈", label: "Python Explorer", color: "#10b981" },
  { icon: "▣", label: "Quiz Master", color: "#6366f1" },
  { icon: "△", label: "First Project", color: "#8b5cf6" },
  { icon: "◌", label: "Fast Learner", color: "#06b6d4" },
];

const certificates = [
  { name: "Python Fundamentals", issuer: "TechPilot", date: "Aug 2026", icon: "◈" },
  { name: "DSA Basics", issuer: "TechPilot", date: "Aug 2026", icon: "▣" },
];

const skillTags = ["Python", "Data Structures", "Algorithms", "NumPy", "Git", "SQL", "Statistics"];

export default function Profile({ userData }: ProfileProps) {
  const name = userData.name || "Learner";
  const xp = 1240;
  const level = Math.floor(xp / 200) + 1;
  const streak = 7;

  return (
    <div className="min-h-full orbit-bg" style={{ fontFamily: "var(--font-outfit)" }}>
      {/* Hero */}
      <div className="relative px-5 pt-12 pb-6">
        <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, rgba(99,102,241,0.12) 0%, transparent 100%)" }} />
        <div className="relative flex flex-col items-center text-center gap-3">
          <div className="relative">
            <div className="w-24 h-24 rounded-full flex items-center justify-center text-4xl font-black"
              style={{ background: "linear-gradient(135deg, #6366f1, #8b5cf6)", boxShadow: "0 0 40px rgba(99,102,241,0.5)" }}>
              {name[0]?.toUpperCase()}
            </div>
            <div className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold text-white"
              style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}>
              {level}
            </div>
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">{name}</h1>
            <p className="text-white/50 text-sm">{userData.careerGoal || "AI/ML Engineer"}</p>
            <p className="text-indigo-400 text-xs mt-0.5 font-medium">◍ {userData.degree} · {userData.college}</p>
          </div>
          <div className="flex items-center gap-1 text-sm">
            <span className="text-yellow-400">techpilot.app/u/{name.toLowerCase()}</span>
          </div>
        </div>
      </div>

      {/* Stats Row */}
      <div className="px-5 pb-5">
        <div className="grid grid-cols-4 gap-2">
          {[
            { icon: "✦", value: xp.toLocaleString(), label: "XP" },
            { icon: "◈", value: `Lv.${level}`, label: "Level" },
            { icon: "◧", value: `${streak}d`, label: "Streak" },
            { icon: "△", value: "3", label: "Projects" },
          ].map(({ icon, value, label }) => (
            <div key={label} className="card p-3 text-center">
              <div className="text-lg">{icon}</div>
              <div className="font-black text-white text-sm mt-0.5">{value}</div>
              <div className="text-xs text-white/40">{label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Domain Progress */}
      <div className="px-5 pb-5">
        <h2 className="font-bold text-white mb-3">Learning Domain</h2>
        <div className="rounded-3xl p-5 relative overflow-hidden"
          style={{ background: "linear-gradient(135deg, rgba(99,102,241,0.2), rgba(139,92,246,0.15))", border: "1px solid rgba(99,102,241,0.3)" }}>
          <div className="flex justify-between items-start mb-3">
            <div>
              <div className="text-xs text-indigo-400 font-bold uppercase tracking-widest mb-1">Primary Domain</div>
              <div className="text-xl font-bold text-white">◈ {userData.careerGoal || "AI/ML Engineer"}</div>
            </div>
            <div className="text-right">
              <div className="text-3xl font-black gradient-text">17%</div>
              <div className="text-xs text-white/40">Complete</div>
            </div>
          </div>
          <div className="progress-bar h-2">
            <div className="progress-fill" style={{ width: "17%" }} />
          </div>
          <div className="flex justify-between text-xs text-white/30 mt-1.5">
            <span>Week 2 of 12</span>
            <span>84 days left</span>
          </div>
        </div>
      </div>

      {/* Skills */}
      <div className="px-5 pb-5">
        <h2 className="font-bold text-white mb-3">Skills</h2>
        <div className="flex flex-wrap gap-2">
          {skillTags.map(s => (
            <span key={s} className="px-3 py-1.5 glass rounded-full text-sm text-indigo-300 font-medium border"
              style={{ borderColor: "rgba(99,102,241,0.3)" }}>{s}</span>
          ))}
        </div>
      </div>

      {/* Badges */}
      <div className="px-5 pb-5">
        <h2 className="font-bold text-white mb-3">Achievements</h2>
        <div className="grid grid-cols-3 gap-3">
          {badges.map(({ icon, label, color }) => (
            <div key={label} className="card p-4 flex flex-col items-center gap-2 text-center">
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl"
                style={{ background: `${color}18`, border: `1px solid ${color}35` }}>
                {icon}
              </div>
              <span className="text-xs text-white/60 font-medium leading-tight">{label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Certificates */}
      <div className="px-5 pb-5">
        <h2 className="font-bold text-white mb-3">Certificates</h2>
        <div className="flex flex-col gap-3">
          {certificates.map(({ name: cName, issuer, date, icon }) => (
            <div key={cName} className="card p-4 flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center relative flex-shrink-0"
                style={{ background: "rgba(245,158,11,0.15)", border: "1px solid rgba(245,158,11,0.3)" }}>
                <span className="text-2xl">{icon}</span>
                <img src="/logo.jpeg" alt="TechPilot" className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full border border-black object-cover shadow" />
              </div>
              <div className="flex-1">
                <div className="font-semibold text-white text-sm">{cName}</div>
                <div className="text-xs text-indigo-300 font-medium flex items-center gap-1 mt-0.5">
                  <span>✓ {issuer} Certified</span> · <span className="text-white/40">{date}</span>
                </div>
              </div>
              <button className="text-xs text-indigo-400 font-semibold border rounded-full px-3 py-1"
                style={{ borderColor: "rgba(99,102,241,0.3)" }}>
                View
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Actions */}
      <div className="px-5 pb-8">
        <div className="grid grid-cols-2 gap-3">
          {[
            { label: "Resume Builder", icon: "▣" },
            { label: "Portfolio", icon: "◬" },
            { label: "GitHub", icon: "◈" },
            { label: "Settings", icon: "◌" },
          ].map(({ label, icon }) => (
            <button key={label} className="card card-hover p-4 flex items-center gap-3 text-left">
              <span className="text-xl">{icon}</span>
              <span className="text-sm font-semibold text-white/80">{label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
