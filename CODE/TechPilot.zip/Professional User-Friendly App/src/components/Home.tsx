import { useState, useEffect } from "react";
import type { OnboardingData } from "./Onboarding";

interface HomeProps {
  userData: OnboardingData;
  onOpenMentor: () => void;
}

const roadmapProgress = [
  { name: "Python Fundamentals", progress: 100, color: "#10b981" },
  { name: "Data Structures & Algorithms", progress: 70, color: "#6366f1" },
  { name: "Machine Learning Basics", progress: 40, color: "#8b5cf6" },
  { name: "Deep Learning", progress: 15, color: "#06b6d4" },
];

const achievements = [
  { icon: "◧", label: "7 Day Streak", color: "#f97316" },
  { icon: "✦", label: "First 100 XP", color: "#f59e0b" },
  { icon: "◈", label: "Python Explorer", color: "#10b981" },
  { icon: "▣", label: "Quiz Master", color: "#6366f1" },
];

const notifications = [
  { icon: "◧", text: "Keep your streak alive! Complete today's mission", time: "Just now", unread: true },
  { icon: "✦", text: "Achievement unlocked: Python Explorer", time: "2h ago", unread: true },
  { icon: "◬", text: "New internship match: ML Intern at TechCorp", time: "5h ago", unread: false },
  { icon: "▣", text: "New lesson unlocked: NumPy Arrays", time: "Yesterday", unread: false },
];

export default function Home({ userData, onOpenMentor }: HomeProps) {
  const [xp] = useState(1240);
  const [showXPPop, setShowXPPop] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [greeting, setGreeting] = useState("");

  useEffect(() => {
    const h = new Date().getHours();
    if (h < 12) setGreeting("Good Morning");
    else if (h < 17) setGreeting("Good Afternoon");
    else if (h < 20) setGreeting("Good Evening");
    else setGreeting("Good Night");
  }, []);

  function handleStartMission() {
    setShowXPPop(true);
    setTimeout(() => setShowXPPop(false), 1500);
  }

  const name = userData.name || "Learner";
  const level = Math.floor(xp / 200) + 1;
  const levelProgress = ((xp % 200) / 200) * 100;

  return (
    <div className="flex flex-col min-h-full orbit-bg" style={{ fontFamily: "var(--font-outfit)" }}>
      {/* Header */}
      <div className="px-5 pt-12 pb-4 relative">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <img src="/logo.jpeg" alt="TechPilot" className="w-11 h-11 rounded-2xl object-cover border border-indigo-500/40 shadow-lg flex-shrink-0" />
            <div>
              <span className="text-xs font-bold text-indigo-400 uppercase tracking-wider block">TechPilot</span>
              <h1 className="text-xl font-bold text-white leading-tight">{greeting}, {name}</h1>
            </div>
          </div>
          <div className="flex items-center gap-2.5">
            <button onClick={() => setShowNotifications(!showNotifications)}
              className="relative w-10 h-10 glass rounded-full flex items-center justify-center">
              <span className="text-base text-indigo-300">◌</span>
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-indigo-500 rounded-full" />
            </button>
            <div className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm"
              style={{ background: "linear-gradient(135deg, #6366f1, #8b5cf6)" }}>
              {name[0]?.toUpperCase()}
            </div>
          </div>
        </div>

        {/* Notifications Dropdown */}
        {showNotifications && (
          <div className="absolute top-20 right-5 w-80 glass-strong rounded-2xl p-4 z-50 shadow-2xl">
            <h3 className="font-bold text-white mb-3 text-sm">Notifications</h3>
            {notifications.map((n, i) => (
              <div key={i} className={`flex gap-3 py-3 border-b last:border-0 ${n.unread ? "opacity-100" : "opacity-60"}`}
                style={{ borderColor: "rgba(255,255,255,0.06)" }}>
                <span className="text-lg flex-shrink-0">{n.icon}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-white text-xs leading-snug">{n.text}</p>
                  <p className="text-white/40 text-xs mt-0.5">{n.time}</p>
                </div>
                {n.unread && <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full flex-shrink-0 mt-1" />}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Streak + XP Row */}
      <div className="px-5 pb-4">
        <div className="grid grid-cols-3 gap-3">
          <div className="card p-3 text-center">
            <div className="text-2xl text-sky-300">◧</div>
            <div className="text-lg font-black text-white">7</div>
            <div className="text-xs text-white/40">Day Streak</div>
          </div>
          <div className="card p-3 text-center">
            <div className="text-2xl text-indigo-300">✦</div>
            <div className="text-lg font-black gradient-text">{xp.toLocaleString()}</div>
            <div className="text-xs text-white/40">Total XP</div>
          </div>
          <div className="card p-3 text-center">
            <div className="text-2xl text-blue-300">◈</div>
            <div className="text-lg font-black text-white">Lv.{level}</div>
            <div className="text-xs text-white/40">Level</div>
          </div>
        </div>
      </div>

      {/* Level Progress */}
      <div className="px-5 pb-5">
        <div className="card p-4">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-semibold text-white">Level {level} · Python Explorer</span>
            <span className="text-xs text-indigo-400 font-semibold">{Math.round(levelProgress)}%</span>
          </div>
          <div className="progress-bar h-2">
            <div className="progress-fill" style={{ width: `${levelProgress}%` }} />
          </div>
          <div className="flex justify-between text-xs text-white/30 mt-1.5">
            <span>{xp} XP</span>
            <span>Next: {(Math.ceil(xp / 200) * 200)} XP</span>
          </div>
        </div>
      </div>

      {/* Today's Mission */}
      <div className="px-5 pb-5 relative">
        {showXPPop && (
          <div className="absolute top-0 left-1/2 -translate-x-1/2 xp-pop z-50 text-2xl font-black gradient-text pointer-events-none">
            +50 XP
          </div>
        )}
        <div className="rounded-3xl p-5 relative overflow-hidden"
          style={{ background: "linear-gradient(135deg, #6366f1 0%, #8b5cf6 50%, #06b6d4 100%)" }}>
          <div className="absolute inset-0" style={{ background: "radial-gradient(circle at 80% 50%, rgba(255,255,255,0.1) 0%, transparent 60%)" }} />
          <div className="relative">
            <div className="flex items-start justify-between mb-4">
              <div>
                <span className="text-xs font-bold uppercase tracking-widest text-white/70">Today's Mission · Day 12</span>
                <h2 className="text-xl font-bold text-white mt-1">Python Functions</h2>
                <div className="flex items-center gap-3 mt-2">
                  <span className="text-sm text-white/80">⏱ 25 min</span>
                  <span className="xp-badge">+50 XP</span>
                </div>
              </div>
              <div className="w-14 h-14 rounded-2xl bg-white/10 flex items-center justify-center text-2xl">🐍</div>
            </div>
            <button onClick={handleStartMission}
              className="w-full py-3.5 rounded-2xl font-bold text-sm"
              style={{ background: "rgba(255,255,255,0.2)", backdropFilter: "blur(10px)", color: "#fff", border: "1px solid rgba(255,255,255,0.3)", transition: "all 0.2s" }}
              onMouseEnter={e => (e.currentTarget.style.background = "rgba(255,255,255,0.3)")}
              onMouseLeave={e => (e.currentTarget.style.background = "rgba(255,255,255,0.2)")}>
              ▶ Start Mission
            </button>
          </div>
        </div>
      </div>

      {/* Daily Challenge */}
      <div className="px-5 pb-5">
        <div className="card p-4 flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-lg font-bold"
            style={{ background: "rgba(61,123,255,0.12)", border: "1px solid rgba(61,123,255,0.3)", color: "#dfe9ff" }}>01</div>
          <div className="flex-1">
            <div className="text-xs font-bold text-red-400 uppercase tracking-wider mb-0.5">Daily Challenge</div>
            <div className="font-bold text-white text-sm">Debug This Code</div>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-xs text-white/40">Hard</span>
              <span className="xp-badge">+100 XP</span>
            </div>
          </div>
          <button className="btn-ghost px-4 py-2 text-xs font-semibold">Start</button>
        </div>
      </div>

      {/* Roadmap Progress */}
      <div className="px-5 pb-5">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-bold text-white">Roadmap Progress</h2>
          <span className="text-xs text-indigo-400 font-semibold">Week 3/12</span>
        </div>
        <div className="card p-4 flex flex-col gap-4">
          {roadmapProgress.map(({ name, progress, color }) => (
            <div key={name}>
              <div className="flex justify-between text-sm mb-2">
                <span className="font-medium text-white">{name}</span>
                <span className="font-bold" style={{ color }}>{progress}%</span>
              </div>
              <div className="progress-bar h-2">
                <div className="h-full rounded-full transition-all duration-1000"
                  style={{ width: `${progress}%`, background: color }} />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Achievements */}
      <div className="px-5 pb-5">
        <h2 className="font-bold text-white mb-3">Recent Achievements</h2>
        <div className="flex gap-3 overflow-x-auto pb-2" style={{ scrollbarWidth: "none" }}>
          {achievements.map(({ icon, label, color }) => (
            <div key={label} className="card p-4 flex-shrink-0 flex flex-col items-center gap-2 w-24">
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl"
                style={{ background: `${color}20`, border: `1px solid ${color}40` }}>
                {icon}
              </div>
              <span className="text-xs text-center text-white/70 font-medium leading-tight">{label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* AI Mentor CTA */}
      <div className="px-5 pb-8">
        <button onClick={onOpenMentor}
          className="w-full card card-hover p-4 flex items-center gap-4 text-left">
          <img src="/logo.jpeg" alt="TechPilot AI" className="w-12 h-12 rounded-2xl object-cover border border-indigo-500/40 shadow-lg flex-shrink-0" />
          <div className="flex-1">
            <div className="font-bold text-white text-sm flex items-center gap-2">
              TechPilot AI Mentor
              <span className="text-sm" aria-label="AI">🤖</span>
            </div>
            <div className="text-xs text-white/50 mt-0.5">Ask anything · Available 24/7</div>
          </div>
          <span className="text-white/30">›</span>
        </button>
      </div>
    </div>
  );
}
