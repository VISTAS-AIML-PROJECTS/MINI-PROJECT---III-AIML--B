import { useState } from "react";

const categories = [
  { id: "coding", label: "Coding", icon: "💻", count: 48 },
  { id: "ml", label: "ML & Data", icon: "🤖", count: 32 },
  { id: "design", label: "UI/UX", icon: "🎨", count: 24 },
  { id: "security", label: "Security", icon: "🔐", count: 20 },
];

const challenges = [
  {
    id: 1, cat: "coding", type: "MCQ", title: "Python List Slicing",
    difficulty: "Easy", xp: 30, time: "5 min",
    q: "What does myList[1:4] return if myList = [10, 20, 30, 40, 50]?",
    options: ["[10, 20, 30]", "[20, 30, 40]", "[20, 30, 40, 50]", "[10, 20, 30, 40]"],
    correct: 1, tag: "Python",
  },
  {
    id: 2, cat: "coding", type: "Debug", title: "Fix the Fibonacci",
    difficulty: "Medium", xp: 75, time: "15 min",
    q: "This function has a bug. Find and identify it:",
    code: `def fib(n):\n    if n <= 0:\n        return 0\n    if n == 1:\n        return 1\n    return fib(n-1) + fib(n-3)  # Bug here`,
    options: ["fib(n-1) should be fib(n+1)", "Should return fib(n-1) + fib(n-2)", "if n<=0 should be if n<0", "Missing base case"],
    correct: 1, tag: "Debug",
  },
  {
    id: 3, cat: "ml", type: "MCQ", title: "Overfitting vs Underfitting",
    difficulty: "Medium", xp: 60, time: "8 min",
    q: "A model with very high training accuracy but low test accuracy is most likely:",
    options: ["Underfitting", "Well-fitted", "Overfitting", "Biased"],
    correct: 2, tag: "ML",
  },
  {
    id: 4, cat: "coding", type: "Output", title: "Predict the Output",
    difficulty: "Easy", xp: 40, time: "5 min",
    q: "What will this code print?",
    code: `x = [1, 2, 3]\ny = x\ny.append(4)\nprint(len(x))`,
    options: ["3", "4", "Error", "None"],
    correct: 1, tag: "Python",
  },
  {
    id: 5, cat: "security", type: "Scenario", title: "SQL Injection Basics",
    difficulty: "Hard", xp: 100, time: "20 min",
    q: "An attacker types: ' OR '1'='1 into a login field. What are they attempting?",
    options: ["XSS Attack", "SQL Injection to bypass auth", "CSRF Attack", "Buffer Overflow"],
    correct: 1, tag: "Security",
  },
];

const diffColor: Record<string, string> = {
  Easy: "#10b981",
  Medium: "#f59e0b",
  Hard: "#ef4444",
};

export default function Practice() {
  const [activeCategory, setActiveCategory] = useState("coding");
  const [activeChallenge, setActiveChallenge] = useState<typeof challenges[0] | null>(null);
  const [selected, setSelected] = useState<number | null>(null);
  const [answered, setAnswered] = useState(false);
  const [totalXP, setTotalXP] = useState(0);
  const [solved, setSolved] = useState<Set<number>>(new Set());

  const filtered = challenges.filter(c => c.cat === activeCategory);

  function startChallenge(c: typeof challenges[0]) {
    setActiveChallenge(c);
    setSelected(null);
    setAnswered(false);
  }

  function submitAnswer(idx: number) {
    if (answered) return;
    setSelected(idx);
    setAnswered(true);
    if (idx === activeChallenge!.correct && !solved.has(activeChallenge!.id)) {
      setTotalXP(x => x + activeChallenge!.xp);
      setSolved(s => new Set(s).add(activeChallenge!.id));
    }
  }

  if (activeChallenge) {
    const correct = answered && selected === activeChallenge.correct;
    return (
      <div className="min-h-full orbit-bg flex flex-col" style={{ fontFamily: "var(--font-outfit)" }}>
        <div className="px-5 pt-12 pb-5">
          <div className="flex items-center justify-between mb-5">
            <button onClick={() => setActiveChallenge(null)}
              className="w-10 h-10 glass rounded-full flex items-center justify-center text-white/60">←</button>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold px-2 py-1 rounded-full" style={{ background: `${diffColor[activeChallenge.difficulty]}20`, color: diffColor[activeChallenge.difficulty], border: `1px solid ${diffColor[activeChallenge.difficulty]}40` }}>
                {activeChallenge.difficulty}
              </span>
              <span className="text-xs px-2 py-1 glass rounded-full text-white/60">{activeChallenge.type}</span>
            </div>
            <div className="xp-badge">+{activeChallenge.xp} XP</div>
          </div>
          <h1 className="text-xl font-bold text-white mb-1">{activeChallenge.title}</h1>
          <p className="text-white/40 text-xs">⏱ {activeChallenge.time}</p>
        </div>

        <div className="px-5 pb-8 flex flex-col gap-4 flex-1">
          <div className="card p-5">
            <p className="text-white font-medium text-sm leading-relaxed">{activeChallenge.q}</p>
            {activeChallenge.code && (
              <div className="mt-4 rounded-xl p-4 text-xs overflow-x-auto"
                style={{ background: "#0d1117", fontFamily: "var(--font-jetbrains)", border: "1px solid rgba(255,255,255,0.06)" }}>
                {activeChallenge.code.split("\n").map((line, i) => (
                  <div key={i} className="flex gap-3">
                    <span className="text-white/20 select-none w-4 text-right">{i + 1}</span>
                    <span className={line.includes("# Bug") ? "text-red-400" : "text-white/75"}>{line}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="flex flex-col gap-3">
            {activeChallenge.options.map((opt, idx) => {
              let cls = "card py-4 px-5 text-left text-sm font-medium transition-all ";
              if (answered) {
                if (idx === activeChallenge.correct) cls += "border-green-500 bg-green-500/15 text-green-300";
                else if (idx === selected) cls += "border-red-500 bg-red-500/15 text-red-300";
                else cls += "opacity-30 text-white/50";
              } else cls += "text-white/80 hover:text-white hover:border-indigo-500/40 hover:bg-indigo-500/10 cursor-pointer";
              return (
                <button key={idx} onClick={() => submitAnswer(idx)} className={cls}>
                  <div className="flex gap-3 items-start">
                    <span className="w-6 h-6 rounded-full border border-white/15 flex items-center justify-center text-xs flex-shrink-0 mt-0.5">
                      {answered && idx === activeChallenge.correct ? "✓" : answered && idx === selected ? "✗" : String.fromCharCode(65 + idx)}
                    </span>
                    {opt}
                  </div>
                </button>
              );
            })}
          </div>

          {answered && (
            <div className={`card p-5 fade-in-up ${correct ? "border-green-500/40" : "border-red-500/40"}`}>
              <div className="font-bold mb-2">{correct ? "Correct!" : "Good try!"}</div>
              <p className="text-white/60 text-sm leading-relaxed">
                {correct
                  ? `Great work! You earned +${activeChallenge.xp} XP. Keep going!`
                  : `The correct answer is "${activeChallenge.options[activeChallenge.correct]}". Review the concept and try again.`}
              </p>
            </div>
          )}

          {answered && (
            <button onClick={() => setActiveChallenge(null)} className="btn-primary w-full py-4 font-semibold">
              Back to Practice
            </button>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-full orbit-bg" style={{ fontFamily: "var(--font-outfit)" }}>
      <div className="px-5 pt-12 pb-4">
        <div className="flex items-start justify-between mb-1">
          <div>
            <h1 className="text-2xl font-bold text-white">Practice Arena</h1>
            <p className="text-white/50 text-sm">Sharpen your skills daily</p>
          </div>
          <div className="text-right">
            <div className="text-xl font-black gradient-text">+{totalXP}</div>
            <div className="text-xs text-white/40">XP Today</div>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="px-5 pb-5">
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: "Solved", value: solved.size.toString(), icon: "✅" },
            { label: "Accuracy", value: solved.size > 0 ? `${Math.round((solved.size / (solved.size + 0)) * 100)}%` : "—", icon: "🎯" },
            { label: "Streak", value: "7 days", icon: "🔥" },
          ].map(({ label, value, icon }) => (
            <div key={label} className="card p-3 text-center">
              <div className="text-lg mb-0.5">{icon}</div>
              <div className="font-bold text-white text-sm">{value}</div>
              <div className="text-xs text-white/40">{label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Categories */}
      <div className="px-5 pb-4">
        <div className="flex gap-2 overflow-x-auto pb-1" style={{ scrollbarWidth: "none" }}>
          {categories.map(({ id, label, icon, count }) => (
            <button key={id} onClick={() => setActiveCategory(id)}
              className={`flex-shrink-0 flex items-center gap-2 px-4 py-2.5 rounded-2xl text-sm font-semibold transition-all ${activeCategory === id ? "bg-indigo-500 text-white glow-blue" : "glass text-white/60 hover:text-white"}`}>
              <span>{icon}</span>
              <span>{label}</span>
              <span className={`text-xs px-1.5 py-0.5 rounded-full ${activeCategory === id ? "bg-white/20" : "bg-white/10"}`}>{count}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Challenges */}
      <div className="px-5 pb-8 flex flex-col gap-3">
        {filtered.map(c => (
          <button key={c.id} onClick={() => startChallenge(c)}
            className={`card card-hover p-4 text-left w-full ${solved.has(c.id) ? "opacity-60" : ""}`}>
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2">
                <span className="text-xs px-2 py-0.5 rounded-full glass text-white/60 font-medium">{c.type}</span>
                <span className="text-xs px-2 py-0.5 rounded-full font-semibold"
                  style={{ background: `${diffColor[c.difficulty]}15`, color: diffColor[c.difficulty], border: `1px solid ${diffColor[c.difficulty]}30` }}>
                  {c.difficulty}
                </span>
              </div>
              <div className="flex items-center gap-2">
                {solved.has(c.id) && <span className="text-green-400 text-xs font-bold">✓ Solved</span>}
                <span className="xp-badge">+{c.xp} XP</span>
              </div>
            </div>
            <h3 className="font-bold text-white text-sm mb-1">{c.title}</h3>
            <div className="flex items-center gap-3 text-xs text-white/40">
              <span>⏱ {c.time}</span>
              <span className="px-2 py-0.5 glass rounded-full">{c.tag}</span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
