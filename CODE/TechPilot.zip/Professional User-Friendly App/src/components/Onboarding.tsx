import { useState } from "react";

interface OnboardingProps {
  onComplete: (data: OnboardingData) => void;
}

export interface OnboardingData {
  name: string;
  degree: string;
  year: string;
  college: string;
  skillLevel: string;
  interests: string[];
  careerGoal: string;
  learningTime: string;
  dailyTime: string;
  learningStyle: string;
  language: string;
  assessmentScore: number;
}

const interests = [
  { id: "software", label: "Software Dev", icon: "💻" },
  { id: "ai", label: "AI / ML", icon: "🤖" },
  { id: "data", label: "Data Science", icon: "📊" },
  { id: "uiux", label: "UI/UX Design", icon: "🎨" },
  { id: "cyber", label: "Cybersecurity", icon: "🔐" },
  { id: "iot", label: "IoT", icon: "📡" },
  { id: "cloud", label: "Cloud Computing", icon: "☁️" },
  { id: "devops", label: "DevOps", icon: "⚙️" },
  { id: "mobile", label: "Mobile Dev", icon: "📱" },
  { id: "game", label: "Game Dev", icon: "🎮" },
  { id: "other", label: "Other", icon: "✨" },
];

const careers = [
  "Software Developer", "AI/ML Engineer", "Data Scientist",
  "UI/UX Designer", "Cybersecurity Analyst", "IoT Engineer",
  "Cloud Engineer", "DevOps Engineer", "Mobile Developer",
  "Freelancer", "Entrepreneur", "Not sure yet",
];

const aptitudeQuestions = [
  {
    q: "If a train travels 120 km in 2 hours, what is its speed?",
    options: ["50 km/h", "60 km/h", "70 km/h", "80 km/h"],
    correct: 1,
    type: "Numerical"
  },
  {
    q: "What comes next: 2, 4, 8, 16, __?",
    options: ["24", "28", "32", "36"],
    correct: 2,
    type: "Pattern"
  },
  {
    q: "Which data structure uses LIFO order?",
    options: ["Queue", "Stack", "Array", "LinkedList"],
    correct: 1,
    type: "Technical"
  },
  {
    q: "If A = B and B > C, then A is __ C?",
    options: ["Less than", "Equal to", "Greater than", "Cannot determine"],
    correct: 2,
    type: "Logical"
  },
  {
    q: "A password has 3 letters (A-Z) and 2 digits (0-9). How many combinations?",
    options: ["175,760", "1,757,600", "17,576,000", "1,000,000"],
    correct: 1,
    type: "Problem Solving"
  },
  {
    q: "What is the time complexity of binary search?",
    options: ["O(n)", "O(n²)", "O(log n)", "O(1)"],
    correct: 2,
    type: "Technical"
  },
  {
    q: "Complete the analogy: Book : Library :: Painting : ?",
    options: ["Canvas", "Gallery", "Museum", "Artist"],
    correct: 1,
    type: "Logical"
  },
  {
    q: "Which of these is NOT a Python data type?",
    options: ["int", "float", "char", "bool"],
    correct: 2,
    type: "Technical"
  },
  {
    q: "Find the odd one out: 121, 144, 169, 196, 225, 250",
    options: ["196", "225", "250", "169"],
    correct: 2,
    type: "Pattern"
  },
  {
    q: "A store gives 20% off a ₹500 item, then 10% extra off. Final price?",
    options: ["₹340", "₹360", "₹380", "₹300"],
    correct: 1,
    type: "Numerical"
  },
];

export default function Onboarding({ onComplete }: OnboardingProps) {
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({
    name: "", degree: "", year: "", college: "", skillLevel: "",
    interests: [] as string[], careerGoal: "",
    learningTime: "", dailyTime: "", learningStyle: "", language: "",
  });
  const [currentQ, setCurrentQ] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [answered, setAnswered] = useState(false);
  const [showingResult, setShowingResult] = useState(false);

  const totalSteps = 5;
  const progress = ((step) / totalSteps) * 100;

  function toggleInterest(id: string) {
    setForm(f => ({
      ...f,
      interests: f.interests.includes(id)
        ? f.interests.filter(i => i !== id)
        : [...f.interests, id]
    }));
  }

  function handleAnswer(idx: number) {
    if (answered) return;
    setSelectedAnswer(idx);
    setAnswered(true);
    setShowingResult(true);
    setTimeout(() => {
      const newAnswers = [...answers, idx];
      setAnswers(newAnswers);
      if (currentQ < aptitudeQuestions.length - 1) {
        setCurrentQ(q => q + 1);
        setSelectedAnswer(null);
        setAnswered(false);
        setShowingResult(false);
      } else {
        const score = newAnswers.filter((a, i) => a === aptitudeQuestions[i].correct).length;
        onComplete({
          ...form,
          assessmentScore: Math.round((score / aptitudeQuestions.length) * 100),
        });
      }
    }, 1000);
  }

  function nextStep() {
    setStep(s => s + 1);
  }

  return (
    <div className="min-h-full orbit-bg flex flex-col" style={{ fontFamily: "var(--font-outfit)" }}>
      {/* Progress Header */}
      <div className="px-6 pt-12 pb-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5">
            <img src="/logo.jpeg" alt="TechPilot" className="w-8 h-8 rounded-xl object-cover border border-white/20 shadow-md" />
            <span className="text-2xl font-black gradient-text">TechPilot</span>
          </div>
          <span className="text-sm text-white/40 font-medium">Step {step + 1} of {totalSteps}</span>
        </div>
        <div className="progress-bar h-1.5">
          <div className="progress-fill" style={{ width: `${progress + 20}%` }} />
        </div>
      </div>

      {/* Step 0: Basic Info */}
      {step === 0 && (
        <div className="flex-1 px-6 pb-8 flex flex-col gap-6 fade-in-up">
          <div className="flex items-center gap-3.5">
            <img src="/logo.jpeg" alt="TechPilot" className="w-14 h-14 rounded-2xl object-cover border border-indigo-500/40 shadow-xl flex-shrink-0" />
            <div>
              <h1 className="text-2xl font-bold text-white mb-0.5">Welcome to TechPilot</h1>
              <p className="text-white/50 text-sm">Let's build your personalized learning path</p>
            </div>
          </div>
          <div className="flex flex-col gap-4">
            {[
              { key: "name", label: "Your Name", placeholder: "e.g. afaf" },
              { key: "degree", label: "Degree", placeholder: "e.g. B.Tech CSE" },
              { key: "college", label: "College", placeholder: "e.g. Anna University" },
            ].map(({ key, label, placeholder }) => (
              <div key={key}>
                <label className="block text-sm font-semibold text-white/60 mb-2">{label}</label>
                <input
                  value={form[key as keyof typeof form] as string}
                  onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
                  placeholder={placeholder}
                  className="w-full glass rounded-2xl px-4 py-3.5 text-white placeholder-white/25 text-sm outline-none focus:border-indigo-500 border border-white/08 transition-all"
                  style={{ border: "1px solid rgba(255,255,255,0.08)" }}
                  onFocus={e => e.target.style.border = "1px solid rgba(99,102,241,0.6)"}
                  onBlur={e => e.target.style.border = "1px solid rgba(255,255,255,0.08)"}
                />
              </div>
            ))}
            <div>
              <label className="block text-sm font-semibold text-white/60 mb-2">Current Year</label>
              <div className="grid grid-cols-4 gap-2">
                {["1st", "2nd", "3rd", "4th"].map(y => (
                  <button key={y} onClick={() => setForm(f => ({ ...f, year: y }))}
                    className={`py-3 rounded-2xl text-sm font-semibold transition-all ${form.year === y ? "bg-indigo-500 text-white glow-blue" : "glass text-white/60 hover:text-white"}`}>
                    {y}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-sm font-semibold text-white/60 mb-2">Skill Level</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: "beginner", label: "Beginner", icon: "🌱" },
                  { id: "intermediate", label: "Intermediate", icon: "🔥" },
                  { id: "advanced", label: "Advanced", icon: "⚡" },
                ].map(({ id, label, icon }) => (
                  <button key={id} onClick={() => setForm(f => ({ ...f, skillLevel: id }))}
                    className={`py-3 px-2 rounded-2xl text-xs font-semibold transition-all flex flex-col items-center gap-1 ${form.skillLevel === id ? "bg-indigo-500 text-white glow-blue" : "glass text-white/60 hover:text-white"}`}>
                    <span className="text-lg">{icon}</span>
                    {label}
                  </button>
                ))}
              </div>
            </div>
          </div>
          <button onClick={nextStep}
            disabled={!form.name || !form.degree || !form.year || !form.skillLevel}
            className="btn-primary w-full py-4 text-base font-semibold disabled:opacity-30 disabled:cursor-not-allowed">
            Continue →
          </button>
        </div>
      )}

      {/* Step 1: Interests */}
      {step === 1 && (
        <div className="flex-1 px-6 pb-8 flex flex-col gap-6 fade-in-up">
          <div>
            <h1 className="text-3xl font-bold text-white mb-1">What excites you?</h1>
            <p className="text-white/50">Select all that interest you</p>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {interests.map(({ id, label, icon }) => (
              <button key={id} onClick={() => toggleInterest(id)}
                className={`card card-hover py-4 px-4 flex items-center gap-3 text-left transition-all ${form.interests.includes(id) ? "border-indigo-500 bg-indigo-500/15 glow-blue" : ""}`}>
                <span className="text-2xl">{icon}</span>
                <span className={`text-sm font-semibold ${form.interests.includes(id) ? "text-white" : "text-white/70"}`}>{label}</span>
              </button>
            ))}
          </div>
          <button onClick={nextStep}
            disabled={form.interests.length === 0}
            className="btn-primary w-full py-4 text-base font-semibold disabled:opacity-30">
            Continue ({form.interests.length} selected) →
          </button>
        </div>
      )}

      {/* Step 2: Career Goal */}
      {step === 2 && (
        <div className="flex-1 px-6 pb-8 flex flex-col gap-6 fade-in-up">
          <div>
            <h1 className="text-3xl font-bold text-white mb-1">What do you want to become?</h1>
            <p className="text-white/50">Choose your primary career goal</p>
          </div>
          <div className="flex flex-col gap-2">
            {careers.map(c => (
              <button key={c} onClick={() => setForm(f => ({ ...f, careerGoal: c }))}
                className={`card py-4 px-5 text-left text-sm font-semibold transition-all ${form.careerGoal === c ? "border-indigo-500 bg-indigo-500/15 text-white glow-blue" : "text-white/70 hover:text-white hover:border-white/20"}`}>
                <div className="flex items-center justify-between">
                  <span>{c}</span>
                  {form.careerGoal === c && <span className="text-indigo-400">✓</span>}
                </div>
              </button>
            ))}
          </div>
          <button onClick={nextStep}
            disabled={!form.careerGoal}
            className="btn-primary w-full py-4 text-base font-semibold disabled:opacity-30">
            Continue →
          </button>
        </div>
      )}

      {/* Step 3: Learning Prefs */}
      {step === 3 && (
        <div className="flex-1 px-6 pb-8 flex flex-col gap-6 fade-in-up">
          <div>
            <h1 className="text-3xl font-bold text-white mb-1">Your Learning Style</h1>
            <p className="text-white/50">Personalize your experience</p>
          </div>
          <div className="flex flex-col gap-5">
            <div>
              <label className="block text-sm font-semibold text-white/60 mb-3">Preferred learning time</label>
              <div className="grid grid-cols-2 gap-2">
                {[{l:"Morning",v:"morning"},{l:"Afternoon",v:"afternoon"},{l:"Evening",v:"evening"},{l:"Night",v:"night"}].map(({l,v}) => (
                  <button key={v} onClick={() => setForm(f => ({...f, learningTime: v}))}
                    className={`py-3 rounded-2xl text-sm font-semibold transition-all ${form.learningTime===v ? "bg-indigo-500 text-white" : "glass text-white/60 hover:text-white"}`}>
                    {l}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-sm font-semibold text-white/60 mb-3">Daily time available</label>
              <div className="grid grid-cols-2 gap-2">
                {[{l:"15 min",v:"15"},{l:"30 min",v:"30"},{l:"1 hour",v:"60"},{l:"2+ hours",v:"120"}].map(({l,v}) => (
                  <button key={v} onClick={() => setForm(f => ({...f, dailyTime: v}))}
                    className={`py-3 rounded-2xl text-sm font-semibold transition-all ${form.dailyTime===v ? "bg-indigo-500 text-white" : "glass text-white/60 hover:text-white"}`}>
                    {l}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-sm font-semibold text-white/60 mb-3">Learning style</label>
              <div className="grid grid-cols-2 gap-2">
                {[{l:"Visual",v:"visual"},{l:"Reading",v:"reading"},{l:"Hands-on",v:"handson"},{l:"Video",v:"video"}].map(({l,v}) => (
                  <button key={v} onClick={() => setForm(f => ({...f, learningStyle: v}))}
                    className={`py-3 rounded-2xl text-sm font-semibold transition-all ${form.learningStyle===v ? "bg-indigo-500 text-white" : "glass text-white/60 hover:text-white"}`}>
                    {l}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-sm font-semibold text-white/60 mb-3">Language preference</label>
              <div className="grid grid-cols-3 gap-2">
                {[{l:"English",v:"en"},{l:"Tamil",v:"ta"},{l:"Simple EN",v:"simple"}].map(({l,v}) => (
                  <button key={v} onClick={() => setForm(f => ({...f, language: v}))}
                    className={`py-3 rounded-2xl text-sm font-semibold transition-all ${form.language===v ? "bg-indigo-500 text-white" : "glass text-white/60 hover:text-white"}`}>
                    {l}
                  </button>
                ))}
              </div>
            </div>
          </div>
          <button onClick={nextStep}
            disabled={!form.learningTime || !form.dailyTime || !form.language}
            className="btn-primary w-full py-4 text-base font-semibold disabled:opacity-30">
            Continue →
          </button>
        </div>
      )}

      {/* Step 4: Aptitude Assessment */}
      {step === 4 && (
        <div className="flex-1 px-6 pb-8 flex flex-col gap-6 fade-in-up">
          <div>
            <div className="flex items-center justify-between mb-2">
              <h1 className="text-2xl font-bold text-white">Quick Assessment</h1>
              <span className="xp-badge">+200 XP</span>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-white/40 text-sm">Question {currentQ + 1} / {aptitudeQuestions.length}</span>
              <span className="text-xs px-2 py-0.5 rounded-full glass text-indigo-400 font-semibold">
                {aptitudeQuestions[currentQ].type}
              </span>
            </div>
            <div className="progress-bar h-1 mt-3">
              <div className="progress-fill" style={{ width: `${((currentQ + 1) / aptitudeQuestions.length) * 100}%` }} />
            </div>
          </div>

          <div className="card p-6">
            <p className="text-white font-semibold text-base leading-relaxed">
              {aptitudeQuestions[currentQ].q}
            </p>
          </div>

          <div className="flex flex-col gap-3">
            {aptitudeQuestions[currentQ].options.map((opt, idx) => {
              let cls = "card py-4 px-5 text-left text-sm font-semibold transition-all cursor-pointer ";
              if (showingResult) {
                if (idx === aptitudeQuestions[currentQ].correct) cls += "border-green-500 bg-green-500/15 text-green-400";
                else if (idx === selectedAnswer) cls += "border-red-500 bg-red-500/15 text-red-400";
                else cls += "text-white/40";
              } else {
                cls += "text-white/80 hover:text-white hover:border-indigo-500/50 hover:bg-indigo-500/10";
              }
              return (
                <button key={idx} onClick={() => handleAnswer(idx)} className={cls}>
                  <div className="flex items-center gap-3">
                    <span className="w-6 h-6 rounded-full border border-white/20 flex items-center justify-center text-xs font-bold">
                      {showingResult && idx === aptitudeQuestions[currentQ].correct ? "✓" :
                       showingResult && idx === selectedAnswer ? "✗" :
                       String.fromCharCode(65 + idx)}
                    </span>
                    {opt}
                  </div>
                </button>
              );
            })}
          </div>

          <div className="glass rounded-2xl p-4 text-center">
            <p className="text-white/40 text-xs">Your answers are used to build your personalized AI skill profile</p>
          </div>
        </div>
      )}
    </div>
  );
}
