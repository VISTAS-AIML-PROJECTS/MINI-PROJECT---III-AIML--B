import { useState } from "react";

const roadmapWeeks = [
  {
    week: 1, title: "Python Fundamentals", status: "completed",
    lessons: [
      { title: "Variables & Data Types", done: true, xp: 50 },
      { title: "Control Flow", done: true, xp: 50 },
      { title: "Functions", done: false, xp: 50, current: true },
      { title: "Modules & Packages", done: false, xp: 50 },
    ]
  },
  {
    week: 2, title: "Python for Data", status: "current",
    lessons: [
      { title: "Lists & Comprehensions", done: false, xp: 60 },
      { title: "Dictionaries & Sets", done: false, xp: 60 },
      { title: "File I/O", done: false, xp: 60 },
      { title: "NumPy Basics", done: false, xp: 80 },
    ]
  },
  {
    week: 3, title: "Mathematics for ML", status: "locked",
    lessons: [
      { title: "Linear Algebra", done: false, xp: 70 },
      { title: "Calculus Concepts", done: false, xp: 70 },
      { title: "Probability", done: false, xp: 70 },
      { title: "Statistics", done: false, xp: 80 },
    ]
  },
  {
    week: 4, title: "Machine Learning", status: "locked",
    lessons: [
      { title: "ML Fundamentals", done: false, xp: 100 },
      { title: "Supervised Learning", done: false, xp: 100 },
      { title: "Model Evaluation", done: false, xp: 80 },
      { title: "Mini Project", done: false, xp: 150 },
    ]
  },
];

const lessonContent = {
  concept: "A function is a reusable block of code that performs a specific task. Functions help you organize code and avoid repetition.",
  example: `def greet(name):\n    return f"Hello, {name}!"\n\nresult = greet("Jaison")\nprint(result)  # Hello, Jaison!`,
  question: "What will greet('Pilot') return?",
  options: ["Hello, Pilot!", "Hello, greet!", "None", "Error"],
  correct: 0,
};

export default function Learn() {
  const [activeLesson, setActiveLesson] = useState<null | { weekTitle: string; lessonTitle: string }>(null);
  const [lessonStep, setLessonStep] = useState(0); // 0=concept, 1=example, 2=quiz
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [answered, setAnswered] = useState(false);
  const [earnedXP, setEarnedXP] = useState(false);

  function startLesson(weekTitle: string, lessonTitle: string) {
    setActiveLesson({ weekTitle, lessonTitle });
    setLessonStep(0);
    setSelectedAnswer(null);
    setAnswered(false);
    setEarnedXP(false);
  }

  function handleAnswer(idx: number) {
    if (answered) return;
    setSelectedAnswer(idx);
    setAnswered(true);
    if (idx === lessonContent.correct) setEarnedXP(true);
  }

  if (activeLesson) {
    return (
      <div className="min-h-full orbit-bg flex flex-col" style={{ fontFamily: "var(--font-outfit)" }}>
        {/* Lesson Header */}
        <div className="px-5 pt-12 pb-4">
          <div className="flex items-center justify-between mb-6">
            <button onClick={() => setActiveLesson(null)}
              className="w-10 h-10 glass rounded-full flex items-center justify-center text-white/60">
              ←
            </button>
            <div className="flex gap-1.5">
              {[0, 1, 2].map(i => (
                <div key={i} className={`h-1 rounded-full transition-all duration-500 ${i <= lessonStep ? "w-10 bg-indigo-500" : "w-10 bg-white/10"}`} />
              ))}
            </div>
            <div className="xp-badge">+50 XP</div>
          </div>
          <div className="text-xs text-indigo-400 font-semibold uppercase tracking-widest mb-1">{activeLesson.weekTitle}</div>
          <h1 className="text-xl font-bold text-white">{activeLesson.lessonTitle}</h1>
        </div>

        {/* Step: Concept */}
        {lessonStep === 0 && (
          <div className="flex-1 px-5 pb-8 flex flex-col gap-5 fade-in-up">
            <div className="card p-5">
              <div className="text-xs font-bold text-white/40 uppercase tracking-widest mb-3">Concept</div>
              <p className="text-white/80 text-sm leading-relaxed">{lessonContent.concept}</p>
            </div>
            <div className="card p-5">
              <div className="text-xs font-bold text-white/40 uppercase tracking-widest mb-3">Real World Analogy</div>
              <p className="text-white/70 text-sm leading-relaxed">
                Think of a function like a coffee machine — you give it beans (input), press a button, and get coffee (output). The machine's inner workings are hidden; you just use it.
              </p>
            </div>
            <button onClick={() => setLessonStep(1)} className="btn-primary w-full py-4 font-semibold">
              See Example →
            </button>
          </div>
        )}

        {/* Step: Example */}
        {lessonStep === 1 && (
          <div className="flex-1 px-5 pb-8 flex flex-col gap-5 fade-in-up">
            <div className="card p-5">
              <div className="text-xs font-bold text-white/40 uppercase tracking-widest mb-3">Example</div>
              <div className="rounded-xl p-4 text-sm overflow-x-auto"
                style={{ background: "#0d1117", fontFamily: "var(--font-jetbrains)", border: "1px solid rgba(255,255,255,0.06)" }}>
                {lessonContent.example.split("\n").map((line, i) => (
                  <div key={i} className="flex gap-4">
                    <span className="text-white/20 select-none w-4 text-right flex-shrink-0">{i + 1}</span>
                    <span>
                      {line.startsWith("def ") ? (
                        <><span className="text-purple-400">def </span><span className="text-blue-400">{line.slice(4)}</span></>
                      ) : line.includes("return") ? (
                        <><span className="text-purple-400">    return </span><span className="text-green-400">{line.replace("    return ", "")}</span></>
                      ) : line.includes("#") ? (
                        <><span className="text-white/70">{line.split("#")[0]}</span><span className="text-white/30">#{line.split("#")[1]}</span></>
                      ) : (
                        <span className="text-white/80">{line}</span>
                      )}
                    </span>
                  </div>
                ))}
              </div>
            </div>
            <div className="card p-5">
              <div className="text-xs font-bold text-white/40 uppercase tracking-widest mb-3">Try It</div>
              <p className="text-white/70 text-sm">Try calling greet() with your own name. What does it return?</p>
              <div className="mt-3 rounded-xl p-3 text-xs" style={{ background: "#0d1117", fontFamily: "var(--font-jetbrains)", border: "1px solid rgba(99,102,241,0.3)" }}>
                <span className="text-indigo-400">greet(</span>
                <span className="text-green-400">"Your Name"</span>
                <span className="text-indigo-400">)</span>
                <span className="text-white/30"> → </span>
                <span className="text-yellow-400">?</span>
              </div>
            </div>
            <button onClick={() => setLessonStep(2)} className="btn-primary w-full py-4 font-semibold">
              Take Quiz →
            </button>
          </div>
        )}

        {/* Step: Quiz */}
        {lessonStep === 2 && (
          <div className="flex-1 px-5 pb-8 flex flex-col gap-5 fade-in-up">
            <div className="card p-5">
              <div className="text-xs font-bold text-white/40 uppercase tracking-widest mb-3">Quick Question</div>
              <p className="text-white font-semibold text-base leading-relaxed">{lessonContent.question}</p>
              <div className="mt-3 rounded-xl p-3 text-xs" style={{ background: "#0d1117", fontFamily: "var(--font-jetbrains)", border: "1px solid rgba(255,255,255,0.06)" }}>
                <span className="text-blue-400">greet</span>
                <span className="text-white/60">(</span>
                <span className="text-green-400">'Pilot'</span>
                <span className="text-white/60">)</span>
              </div>
            </div>
            <div className="flex flex-col gap-3">
              {lessonContent.options.map((opt, idx) => {
                let cls = "card py-4 px-5 text-left text-sm font-semibold transition-all ";
                if (answered) {
                  if (idx === lessonContent.correct) cls += "border-green-500 bg-green-500/15 text-green-400";
                  else if (idx === selectedAnswer) cls += "border-red-500 bg-red-500/15 text-red-400";
                  else cls += "opacity-30";
                } else {
                  cls += "text-white/80 hover:border-indigo-500/50 hover:bg-indigo-500/10 hover:text-white cursor-pointer";
                }
                return (
                  <button key={idx} onClick={() => handleAnswer(idx)} className={cls}>
                    <div className="flex items-center gap-3">
                      <span className="w-6 h-6 rounded-full border border-white/20 flex items-center justify-center text-xs">
                        {answered && idx === lessonContent.correct ? "✓" : answered && idx === selectedAnswer ? "✗" : String.fromCharCode(65 + idx)}
                      </span>
                      <span style={{ fontFamily: "var(--font-jetbrains)", fontSize: "0.85rem" }}>{opt}</span>
                    </div>
                  </button>
                );
              })}
            </div>
            {answered && (
              <div className={`card p-4 fade-in-up ${earnedXP ? "border-green-500/40" : "border-red-500/40"}`}>
                <div className="font-bold text-sm mb-1">{earnedXP ? "Correct!" : "Not quite"}</div>
                <p className="text-white/60 text-xs">
                  {earnedXP
                    ? "Great job! The function returns 'Hello, Pilot!' — it interpolates the argument into the f-string."
                    : "The function uses f\"Hello, {name}!\" which substitutes the argument, so it returns 'Hello, Pilot!'."}
                </p>
                {earnedXP && <div className="xp-badge inline-block mt-2">+50 XP earned!</div>}
              </div>
            )}
            {answered && (
              <button onClick={() => setActiveLesson(null)} className="btn-primary w-full py-4 font-semibold">
                {earnedXP ? "Complete & Continue" : "Try Again Tomorrow"}
              </button>
            )}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="min-h-full orbit-bg" style={{ fontFamily: "var(--font-outfit)" }}>
      <div className="px-5 pt-12 pb-4">
        <h1 className="text-2xl font-bold text-white mb-1">Learning Roadmap</h1>
        <p className="text-white/50 text-sm">AI/ML Engineer · 12-week path</p>
      </div>

      {/* Overall Progress */}
      <div className="px-5 pb-5">
        <div className="card p-4">
          <div className="flex justify-between mb-2">
            <span className="text-sm font-semibold text-white">Overall Progress</span>
            <span className="text-sm font-bold text-indigo-400">Week 2 / 12</span>
          </div>
          <div className="progress-bar h-3">
            <div className="progress-fill" style={{ width: "17%" }} />
          </div>
          <div className="flex justify-between text-xs text-white/30 mt-1.5">
            <span>Day 12</span>
            <span>84 days remaining</span>
          </div>
        </div>
      </div>

      {/* Weeks */}
      <div className="px-5 pb-8 flex flex-col gap-4">
        {roadmapWeeks.map(({ week, title, status, lessons }) => (
          <div key={week}>
            <div className="flex items-center gap-3 mb-3">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${
                status === "completed" ? "bg-green-500 text-white" :
                status === "current" ? "bg-indigo-500 text-white" :
                "bg-white/10 text-white/30"
              }`}>
                {status === "completed" ? "✓" : week}
              </div>
              <div className="flex-1">
                <h3 className={`font-bold text-sm ${status === "locked" ? "text-white/30" : "text-white"}`}>{title}</h3>
                <span className={`text-xs font-medium ${
                  status === "completed" ? "text-green-400" :
                  status === "current" ? "text-indigo-400" :
                  "text-white/25"
                }`}>
                  {status === "completed" ? "Completed" : status === "current" ? "In Progress" : "Locked"}
                </span>
              </div>
              <span className="text-xs text-white/30">{lessons.length} lessons</span>
            </div>
            {status !== "locked" && (
              <div className="ml-4 pl-7 border-l flex flex-col gap-2" style={{ borderColor: "rgba(255,255,255,0.06)" }}>
                {lessons.map(({ title: lTitle, done, xp, current }) => (
                  <button
                    key={lTitle}
                    onClick={() => !done && startLesson(title, lTitle)}
                    className={`card py-3 px-4 text-left flex items-center gap-3 transition-all ${current ? "border-indigo-500/50 bg-indigo-500/10" : done ? "opacity-60" : "card-hover"}`}>
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs flex-shrink-0 ${done ? "bg-green-500 text-white" : current ? "bg-indigo-500 text-white" : "border border-white/20 text-white/30"}`}>
                      {done ? "✓" : current ? "▶" : "○"}
                    </div>
                    <span className={`flex-1 text-sm font-medium ${done ? "text-white/50 line-through" : "text-white"}`}>{lTitle}</span>
                    <span className="xp-badge">{xp} XP</span>
                    {current && <span className="text-xs text-indigo-400 font-bold">START</span>}
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
