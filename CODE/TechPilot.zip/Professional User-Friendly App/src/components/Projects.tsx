import { useState } from "react";

const projects = [
  {
    id: 1, title: "Expense Tracker", domain: "Python · Data",
    description: "Build a CLI app to track personal expenses with categories and monthly summaries.",
    difficulty: "Beginner", xp: 500, duration: "3 days", status: "in_progress", progress: 45,
    emoji: "💰",
    milestones: [
      { title: "Create project structure", done: true, current: false },
      { title: "Build input interface", done: true, current: false },
      { title: "Add expense categories", done: false, current: true },
      { title: "Store & retrieve data", done: false, current: false },
      { title: "Create summary dashboard", done: false, current: false },
      { title: "Add data visualization", done: false, current: false },
      { title: "Write tests", done: false, current: false },
      { title: "Publish to GitHub", done: false, current: false },
    ],
    skills: ["Python", "File I/O", "Data Structures"],
  },
  {
    id: 2, title: "Student Performance Predictor", domain: "AI / ML",
    description: "Use machine learning to predict whether a student will pass or fail based on study habits and past scores.",
    difficulty: "Intermediate", xp: 1200, duration: "7 days", status: "locked", progress: 0,
    emoji: "🎓",
    milestones: [
      { title: "Data collection & cleaning", done: false, current: true },
      { title: "Exploratory Data Analysis", done: false, current: false },
      { title: "Feature engineering", done: false, current: false },
      { title: "Train ML model", done: false, current: false },
      { title: "Evaluate & tune model", done: false, current: false },
      { title: "Build prediction API", done: false, current: false },
      { title: "Deploy to cloud", done: false, current: false },
      { title: "Write project report", done: false, current: false },
    ],
    skills: ["Python", "Pandas", "Scikit-learn", "Flask"],
    requirement: "Complete Week 4: Machine Learning",
  },
  {
    id: 3, title: "Portfolio Website", domain: "Web Development",
    description: "Design and build a stunning personal portfolio site to showcase your projects and skills.",
    difficulty: "Beginner", xp: 600, duration: "4 days", status: "available", progress: 0,
    emoji: "🌐",
    milestones: [
      { title: "Design wireframes", done: false, current: true },
      { title: "Set up HTML/CSS structure", done: false, current: false },
      { title: "Build hero section", done: false, current: false },
      { title: "Add projects section", done: false, current: false },
      { title: "Add contact form", done: false, current: false },
      { title: "Make it responsive", done: false, current: false },
      { title: "Deploy to Vercel", done: false, current: false },
    ],
    skills: ["HTML", "CSS", "JavaScript"],
  },
  {
    id: 4, title: "Smart Temperature Monitor", domain: "IoT",
    description: "Build an IoT system using ESP32 and temperature sensors with a real-time dashboard.",
    difficulty: "Intermediate", xp: 900, duration: "5 days", status: "locked", progress: 0,
    emoji: "🌡️",
    milestones: [],
    skills: ["ESP32", "Arduino", "MQTT", "Dashboard"],
    requirement: "Complete IoT Domain basics",
  },
];

const diffColor: Record<string, string> = {
  Beginner: "#10b981",
  Intermediate: "#f59e0b",
  Advanced: "#ef4444",
};

export default function Projects() {
  const [activeProject, setActiveProject] = useState<typeof projects[0] | null>(null);

  if (activeProject) {
    const completed = activeProject.milestones.filter(m => m.done).length;
    return (
      <div className="min-h-full orbit-bg flex flex-col" style={{ fontFamily: "var(--font-outfit)" }}>
        <div className="px-5 pt-12 pb-5">
          <div className="flex items-center gap-4 mb-6">
            <button onClick={() => setActiveProject(null)}
              className="w-10 h-10 glass rounded-full flex items-center justify-center text-white/60">←</button>
          </div>
          <div className="flex items-start gap-4 mb-4">
            <div className="w-16 h-16 rounded-3xl flex items-center justify-center text-3xl flex-shrink-0"
              style={{ background: "linear-gradient(135deg, rgba(99,102,241,0.3), rgba(139,92,246,0.3))", border: "1px solid rgba(99,102,241,0.4)" }}>
              {activeProject.emoji}
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-bold px-2 py-0.5 rounded-full"
                  style={{ background: `${diffColor[activeProject.difficulty]}15`, color: diffColor[activeProject.difficulty] }}>
                  {activeProject.difficulty}
                </span>
                <span className="text-xs text-white/40">{activeProject.domain}</span>
              </div>
              <h1 className="text-xl font-bold text-white">{activeProject.title}</h1>
            </div>
          </div>
          <p className="text-white/60 text-sm leading-relaxed mb-4">{activeProject.description}</p>
          <div className="grid grid-cols-3 gap-3 mb-5">
            {[
              { label: "XP Reward", value: activeProject.xp.toLocaleString(), icon: "⭐" },
              { label: "Duration", value: activeProject.duration, icon: "⏱️" },
              { label: "Progress", value: `${completed}/${activeProject.milestones.length}`, icon: "📋" },
            ].map(({ label, value, icon }) => (
              <div key={label} className="card p-3 text-center">
                <div className="text-lg mb-0.5">{icon}</div>
                <div className="font-bold text-white text-sm">{value}</div>
                <div className="text-xs text-white/40">{label}</div>
              </div>
            ))}
          </div>
          {activeProject.milestones.length > 0 && (
            <div className="progress-bar h-2 mb-1">
              <div className="progress-fill" style={{ width: `${(completed / activeProject.milestones.length) * 100}%` }} />
            </div>
          )}
        </div>

        {activeProject.milestones.length > 0 && (
          <div className="px-5 pb-5">
            <h2 className="font-bold text-white mb-3">Milestones</h2>
            <div className="flex flex-col gap-2">
              {activeProject.milestones.map((m, i) => (
                <div key={i}
                  className={`card p-4 flex items-center gap-4 ${m.current ? "border-indigo-500/50 bg-indigo-500/10" : ""}`}>
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${m.done ? "bg-green-500 text-white" : m.current ? "bg-indigo-500 text-white" : "border border-white/15 text-white/30"}`}>
                    {m.done ? "✓" : i + 1}
                  </div>
                  <span className={`flex-1 text-sm font-medium ${m.done ? "line-through text-white/40" : m.current ? "text-white" : "text-white/60"}`}>
                    {m.title}
                  </span>
                  {m.current && <span className="text-xs text-indigo-400 font-bold">CURRENT</span>}
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="px-5 pb-5">
          <h2 className="font-bold text-white mb-3">Skills You'll Learn</h2>
          <div className="flex flex-wrap gap-2">
            {activeProject.skills.map(s => (
              <span key={s} className="px-3 py-1.5 glass rounded-full text-sm text-indigo-300 font-medium border"
                style={{ borderColor: "rgba(99,102,241,0.3)" }}>{s}</span>
            ))}
          </div>
        </div>

        <div className="px-5 pb-8">
          {activeProject.status === "in_progress" ? (
            <button className="btn-primary w-full py-4 font-semibold glow-blue">Continue Project</button>
          ) : activeProject.status === "available" ? (
            <button className="btn-primary w-full py-4 font-semibold">Start Project</button>
          ) : (
            <div className="card p-4 text-center">
              <div className="text-xl mb-2">🔒</div>
              <p className="text-white/50 text-sm">{activeProject.requirement}</p>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-full orbit-bg" style={{ fontFamily: "var(--font-outfit)" }}>
      <div className="px-5 pt-12 pb-4">
        <h1 className="text-2xl font-bold text-white mb-1">Projects</h1>
        <p className="text-white/50 text-sm">Build real things, earn real XP</p>
      </div>

      {/* In Progress */}
      {projects.filter(p => p.status === "in_progress").length > 0 && (
        <div className="px-5 pb-5">
          <h2 className="text-sm font-bold text-white/50 uppercase tracking-widest mb-3">In Progress</h2>
          {projects.filter(p => p.status === "in_progress").map(p => (
            <button key={p.id} onClick={() => setActiveProject(p)} className="w-full card card-hover p-5 text-left">
              <div className="flex items-start gap-4">
                <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0"
                  style={{ background: "linear-gradient(135deg, rgba(99,102,241,0.2), rgba(139,92,246,0.2))", border: "1px solid rgba(99,102,241,0.3)" }}>
                  {p.emoji}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-bold" style={{ color: diffColor[p.difficulty] }}>{p.difficulty}</span>
                    <span className="text-xs text-white/40">· {p.domain}</span>
                  </div>
                  <h3 className="font-bold text-white text-base mb-1">{p.title}</h3>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="flex-1 progress-bar h-1.5">
                      <div className="progress-fill" style={{ width: `${p.progress}%` }} />
                    </div>
                    <span className="text-xs text-indigo-400 font-semibold">{p.progress}%</span>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-white/40">
                    <span>⭐ {p.xp} XP</span>
                    <span>⏱ {p.duration}</span>
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>
      )}

      {/* Available */}
      <div className="px-5 pb-5">
        <h2 className="text-sm font-bold text-white/50 uppercase tracking-widest mb-3">Available</h2>
        <div className="flex flex-col gap-3">
          {projects.filter(p => p.status === "available").map(p => (
            <button key={p.id} onClick={() => setActiveProject(p)} className="card card-hover p-4 text-left w-full">
              <div className="flex items-center gap-4">
                <div className="text-3xl">{p.emoji}</div>
                <div className="flex-1">
                  <h3 className="font-bold text-white text-sm mb-0.5">{p.title}</h3>
                  <div className="flex items-center gap-2 text-xs">
                    <span style={{ color: diffColor[p.difficulty] }}>{p.difficulty}</span>
                    <span className="text-white/30">·</span>
                    <span className="xp-badge">+{p.xp} XP</span>
                    <span className="text-white/40">{p.duration}</span>
                  </div>
                </div>
                <span className="text-white/30">›</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Locked */}
      <div className="px-5 pb-8">
        <h2 className="text-sm font-bold text-white/50 uppercase tracking-widest mb-3">🔒 Locked</h2>
        <div className="flex flex-col gap-3">
          {projects.filter(p => p.status === "locked").map(p => (
            <button key={p.id} onClick={() => setActiveProject(p)} className="card p-4 text-left w-full opacity-50">
              <div className="flex items-center gap-4">
                <div className="text-3xl grayscale">{p.emoji}</div>
                <div className="flex-1">
                  <h3 className="font-bold text-white text-sm mb-0.5">{p.title}</h3>
                  <p className="text-xs text-white/40">{p.requirement}</p>
                </div>
                <span className="text-lg">🔒</span>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
