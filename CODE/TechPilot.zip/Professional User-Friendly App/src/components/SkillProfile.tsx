import { useState, useEffect } from "react";
import type { OnboardingData } from "./Onboarding";

interface SkillProfileProps {
  data: OnboardingData;
  onEnterApp: () => void;
}

function getDomainMatches(data: OnboardingData) {
  const base = data.assessmentScore;
  const interestMap: Record<string, string[]> = {
    "AI/ML Engineer": ["ai", "data", "software"],
    "Software Developer": ["software", "mobile", "game"],
    "Data Scientist": ["data", "ai", "software"],
    "UI/UX Designer": ["uiux", "mobile", "game"],
    "Cybersecurity Analyst": ["cyber", "cloud", "devops"],
    "IoT Engineer": ["iot", "cloud", "devops"],
    "Cloud Engineer": ["cloud", "devops", "software"],
    "DevOps Engineer": ["devops", "cloud", "software"],
    "Mobile Developer": ["mobile", "software", "game"],
  };
  const domainIcons: Record<string, string> = {
    "AI/ML Engineer": "🤖",
    "Software Developer": "💻",
    "Data Scientist": "📊",
    "UI/UX Designer": "🎨",
    "Cybersecurity Analyst": "🔐",
    "IoT Engineer": "📡",
    "Cloud Engineer": "☁️",
    "DevOps Engineer": "⚙️",
    "Mobile Developer": "📱",
  };

  const relevant = interestMap[data.careerGoal] || ["software", "ai", "data"];
  const interestBoost = relevant.filter(r => data.interests.includes(r)).length * 5;

  const allDomains = [
    { name: data.careerGoal || "AI/ML Engineer", score: Math.min(99, base + interestBoost + 15) },
    { name: "Software Developer", score: Math.min(95, base + 10) },
    { name: "Data Scientist", score: Math.min(90, base + 5) },
    { name: "UI/UX Designer", score: Math.min(85, base - 5) },
    { name: "Cybersecurity Analyst", score: Math.min(80, base - 10) },
    { name: "Cloud Engineer", score: Math.min(75, base - 15) },
  ].filter((d, i, arr) => arr.findIndex(x => x.name === d.name) === i)
    .sort((a, b) => b.score - a.score)
    .slice(0, 5);

  return { domains: allDomains, icons: domainIcons };
}

export default function SkillProfile({ data, onEnterApp }: SkillProfileProps) {
  const [loading, setLoading] = useState(true);
  const [phase, setPhase] = useState(0);

  useEffect(() => {
    const t1 = setTimeout(() => setPhase(1), 800);
    const t2 = setTimeout(() => setPhase(2), 1600);
    const t3 = setTimeout(() => { setPhase(3); setLoading(false); }, 2400);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, []);

  const { domains, icons } = getDomainMatches(data);
  const top = domains[0];

  if (loading) {
    return (
      <div className="min-h-full orbit-bg flex flex-col items-center justify-center px-6 gap-8">
        <div className="text-center flex flex-col items-center">
          <img src="/logo.jpeg" alt="TechPilot" className="w-16 h-16 rounded-3xl object-cover mb-4 shadow-2xl border border-indigo-500/40" />
          <h2 className="text-2xl font-bold gradient-text mb-2" style={{ fontFamily: "var(--font-outfit)" }}>
            Analyzing Your Profile
          </h2>
          <p className="text-white/40 text-sm">TechPilot AI is processing your results...</p>
        </div>
        <div className="w-full max-w-xs flex flex-col gap-4">
          {[
            { label: "Processing aptitude results", done: phase >= 1 },
            { label: "Matching career domains", done: phase >= 2 },
            { label: "Building your roadmap", done: phase >= 3 },
          ].map(({ label, done }, i) => (
            <div key={i} className="flex items-center gap-4">
              <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 transition-all duration-500 ${done ? "bg-indigo-500" : "border border-white/20"}`}>
                {done && <span className="text-white text-xs">✓</span>}
                {!done && <div className="w-2 h-2 rounded-full bg-white/20" />}
              </div>
              <span className={`text-sm font-medium transition-all duration-500 ${done ? "text-white" : "text-white/30"}`}>{label}</span>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-full orbit-bg flex flex-col pb-8" style={{ fontFamily: "var(--font-outfit)" }}>
      <div className="px-6 pt-12 pb-6 fade-in-up">
        <div className="text-center mb-8 flex flex-col items-center">
          <img src="/logo.jpeg" alt="TechPilot" className="w-14 h-14 rounded-2xl object-cover mb-3 shadow-xl border border-indigo-500/40" />
          <h1 className="text-2xl font-bold text-white mb-1">Skill Profile</h1>
          <p className="text-white/50 text-sm">Based on your assessment & interests</p>
        </div>

        {/* Top Match */}
        <div className="relative rounded-3xl p-6 mb-6 overflow-hidden" style={{ background: "linear-gradient(135deg, rgba(99,102,241,0.25), rgba(139,92,246,0.2))", border: "1px solid rgba(99,102,241,0.4)" }}>
          <div className="absolute top-0 right-0 w-32 h-32 rounded-full" style={{ background: "radial-gradient(circle, rgba(139,92,246,0.3) 0%, transparent 70%)", transform: "translate(30%, -30%)" }} />
          <div className="relative">
            <div className="flex items-start justify-between mb-4">
              <div>
                <span className="text-xs font-semibold text-indigo-400 uppercase tracking-widest">Top Match</span>
                <h2 className="text-2xl font-bold text-white mt-1">
                  {icons[top.name] || "◈"} {top.name}
                </h2>
              </div>
              <div className="text-right">
                <div className="text-4xl font-black gradient-text">{top.score}%</div>
                <div className="text-xs text-white/50">Match Score</div>
              </div>
            </div>
            <div className="progress-bar h-2 mb-3">
              <div className="progress-fill" style={{ width: `${top.score}%` }} />
            </div>
            <p className="text-white/60 text-sm leading-relaxed">
              Your problem-solving ability, technical interests, and learning preferences strongly match {top.name}.
            </p>
          </div>
        </div>

        {/* Score Breakdown */}
        <div className="card p-5 mb-6">
          <h3 className="text-sm font-semibold text-white/50 uppercase tracking-widest mb-4">Assessment Breakdown</h3>
          <div className="grid grid-cols-2 gap-4">
            {[
              { label: "Problem Solving", score: Math.min(100, data.assessmentScore + 5), color: "#6366f1" },
              { label: "Pattern Recognition", score: Math.min(100, data.assessmentScore - 5), color: "#8b5cf6" },
              { label: "Technical Knowledge", score: Math.min(100, data.assessmentScore + 10), color: "#06b6d4" },
              { label: "Numerical Reasoning", score: Math.min(100, data.assessmentScore - 8), color: "#10b981" },
            ].map(({ label, score, color }) => (
              <div key={label}>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-white/60">{label}</span>
                  <span className="text-white font-semibold">{score}%</span>
                </div>
                <div className="progress-bar h-1.5">
                  <div className="h-full rounded-full transition-all duration-1000" style={{ width: `${score}%`, background: color }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* All Domains */}
        <div className="mb-6">
          <h3 className="text-sm font-semibold text-white/50 uppercase tracking-widest mb-3">All Domain Matches</h3>
          <div className="flex flex-col gap-2">
            {domains.map(({ name, score }, i) => (
              <div key={name} className={`card p-4 flex items-center gap-4 ${i === 0 ? "border-indigo-500/40" : ""}`}>
                <span className="text-xl">{icons[name] || "✨"}</span>
                <div className="flex-1">
                  <div className="flex justify-between text-sm mb-1.5">
                    <span className="font-semibold text-white">{name}</span>
                    <span className="font-bold" style={{ color: i === 0 ? "#6366f1" : "#ffffff80" }}>{score}%</span>
                  </div>
                  <div className="progress-bar h-1">
                    <div className="h-full rounded-full" style={{ width: `${score}%`, background: i === 0 ? "linear-gradient(90deg, #6366f1, #8b5cf6)" : "rgba(255,255,255,0.2)" }} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3 mb-8">
          {[
            { label: "XP Earned", value: "200", icon: "⭐" },
            { label: "Skill Score", value: `${data.assessmentScore}%`, icon: "📊" },
            { label: "Days to Job Ready", value: "84", icon: "📅" },
          ].map(({ label, value, icon }) => (
            <div key={label} className="card p-4 text-center">
              <div className="text-xl mb-1">{icon}</div>
              <div className="text-xl font-bold gradient-text">{value}</div>
              <div className="text-xs text-white/40 mt-0.5">{label}</div>
            </div>
          ))}
        </div>

        <button onClick={onEnterApp}
          className="btn-primary w-full py-5 text-base font-bold glow-blue">
          Start My Journey
        </button>
        <p className="text-center text-white/30 text-xs mt-3">Your personalized roadmap is ready</p>
      </div>
    </div>
  );
}
