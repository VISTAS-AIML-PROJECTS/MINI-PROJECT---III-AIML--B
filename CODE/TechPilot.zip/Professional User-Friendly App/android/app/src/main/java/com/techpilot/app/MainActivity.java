package com.techpilot.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
}
