#!/usr/bin/env bash
set -euo pipefail

# Deploys all Supabase Edge Functions. Requires the Supabase CLI to be
# logged in and linked to the target project (`supabase link`).

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

for fn_dir in "$ROOT_DIR"/supabase/functions/*/; do
  fn_name="$(basename "$fn_dir")"
  if [ "$fn_name" = "_shared" ]; then continue; fi
  echo "Deploying function: $fn_name"
  supabase functions deploy "$fn_name" --no-verify-jwt
done

echo "All functions deployed."
echo "Remember to set secrets: supabase secrets set CRON_SECRET=<random-value>"
