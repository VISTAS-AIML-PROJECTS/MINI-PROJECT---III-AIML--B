#!/usr/bin/env bash
set -euo pipefail

# Applies supabase/migrations/*.sql in order against DATABASE_URL.
# Requires DATABASE_URL (a direct Postgres connection string to your
# Supabase project) to be set, or a .env file at the repo root providing it.

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if [ -f "$ROOT_DIR/.env" ]; then
  set -a
  # shellcheck disable=SC1091
  source "$ROOT_DIR/.env"
  set +a
fi

if [ -z "${DATABASE_URL:-}" ]; then
  echo "DATABASE_URL is not set. Set it in .env or the environment." >&2
  exit 1
fi

for migration in "$ROOT_DIR"/supabase/migrations/*.sql; do
  echo "Applying $(basename "$migration")..."
  psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f "$migration"
done

echo "All migrations applied."
