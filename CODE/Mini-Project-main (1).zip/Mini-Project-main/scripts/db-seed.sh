#!/usr/bin/env bash
set -euo pipefail

# Substitutes seed-only credential placeholders in supabase/seed.sql from
# environment variables, then applies it against DATABASE_URL. Never commit
# real passwords — these are development-only accounts.

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if [ -f "$ROOT_DIR/.env" ]; then
  set -a
  # shellcheck disable=SC1091
  source "$ROOT_DIR/.env"
  set +a
fi

: "${DATABASE_URL:?DATABASE_URL is not set}"
: "${ADMIN_SEED_PASSWORD:?ADMIN_SEED_PASSWORD is not set}"

TMP_FILE="$(mktemp)"
trap 'rm -f "$TMP_FILE"' EXIT

ADMIN_SEED_PASSWORD="$ADMIN_SEED_PASSWORD" \
envsubst '${ADMIN_SEED_PASSWORD}' \
  < "$ROOT_DIR/supabase/seed.sql" > "$TMP_FILE"

psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f "$TMP_FILE"

echo "Seed data applied."
