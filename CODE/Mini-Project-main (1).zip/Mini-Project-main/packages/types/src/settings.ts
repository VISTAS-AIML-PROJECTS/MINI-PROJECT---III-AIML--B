export interface SystemSetting<T = unknown> {
  id: string;
  key: string;
  value: T;
  updatedBy: string | null;
  updatedAt: string;
}

export interface MonitoringSettings {
  heartbeatIntervalSeconds: number;
  offlineThresholdSeconds: number;
  activityRetentionDays: number;
  auditRetentionDays: number;
  screenshotIntervalSeconds: number;
}
