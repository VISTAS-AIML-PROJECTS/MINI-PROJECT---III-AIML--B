export interface Session {
  id: string;
  computerId: string;
  username: string;
  startedAt: string;
  endedAt: string | null;
  isActive: boolean;
}
