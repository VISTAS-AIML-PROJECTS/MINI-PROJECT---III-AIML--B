import type { Role } from "./role";

export interface Profile {
  id: string;
  email: string;
  fullName: string | null;
  role: Role;
  isActive: boolean;
  lastLoginAt: string | null;
  createdAt: string;
  updatedAt: string;
}
