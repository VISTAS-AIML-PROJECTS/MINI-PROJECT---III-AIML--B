export const REMOTE_COMMAND_TYPES = ["LOCK", "LOGOUT", "RESTART", "SHUTDOWN"] as const;
export type RemoteCommandType = (typeof REMOTE_COMMAND_TYPES)[number];

export const REMOTE_COMMAND_STATUSES = [
  "PENDING",
  "SENT",
  "ACKNOWLEDGED",
  "SUCCEEDED",
  "FAILED",
  "TIMED_OUT",
] as const;
export type RemoteCommandStatus = (typeof REMOTE_COMMAND_STATUSES)[number];

export interface RemoteCommand {
  id: string;
  computerId: string;
  requestedBy: string;
  commandType: RemoteCommandType;
  status: RemoteCommandStatus;
  requestedAt: string;
  executedAt: string | null;
  result: Record<string, unknown> | null;
}
