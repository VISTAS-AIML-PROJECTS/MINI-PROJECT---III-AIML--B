export interface Application {
  id: string;
  name: string;
  executableName: string | null;
  publisher: string | null;
  createdAt: string;
}

export interface ApplicationActivity {
  id: string;
  computerId: string;
  sessionId: string | null;
  applicationId: string;
  applicationName?: string;
  windowTitle: string | null;
  startedAt: string;
  endedAt: string | null;
  durationSeconds: number | null;
  createdAt: string;
}

export interface ApplicationUsageSummary {
  applicationId: string;
  applicationName: string;
  totalUsageSeconds: number;
  computerCount: number;
  sessionCount: number;
  averageDurationSeconds: number;
}
