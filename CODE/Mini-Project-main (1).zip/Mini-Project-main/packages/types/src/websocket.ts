import type { ActivityEvent } from "./activity";
import type { ComputerStatus } from "./computer";
import type { RemoteCommandStatus, RemoteCommandType } from "./command";
import type { Session } from "./session";

export const WS_EVENTS = {
  COMPUTER_ONLINE: "computer:online",
  COMPUTER_OFFLINE: "computer:offline",
  COMPUTER_HEARTBEAT: "computer:heartbeat",
  COMPUTER_ACTIVITY: "computer:activity",
  COMPUTER_SESSION: "computer:session",
  COMPUTER_COMMAND: "computer:command",
  COMPUTER_COMMAND_RESULT: "computer:command-result",
} as const;

export type WsEventName = (typeof WS_EVENTS)[keyof typeof WS_EVENTS];

export interface WsComputerOnlinePayload {
  computerId: string;
  occurredAt: string;
}

export interface WsComputerOfflinePayload {
  computerId: string;
  occurredAt: string;
}

export interface WsComputerHeartbeatPayload {
  computerId: string;
  status: ComputerStatus;
  cpuUsage: number;
  memoryUsage: number;
  timestamp: string;
}

export interface WsComputerActivityPayload {
  computerId: string;
  event: ActivityEvent;
}

export interface WsComputerSessionPayload {
  computerId: string;
  session: Session;
}

export interface WsComputerCommandPayload {
  commandId: string;
  computerId: string;
  commandType: RemoteCommandType;
}

export interface WsComputerCommandResultPayload {
  commandId: string;
  computerId: string;
  status: RemoteCommandStatus;
  result: Record<string, unknown> | null;
}
