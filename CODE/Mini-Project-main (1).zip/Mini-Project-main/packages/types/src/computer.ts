export const COMPUTER_STATUSES = ["ONLINE", "OFFLINE", "DISABLED"] as const;
export type ComputerStatus = (typeof COMPUTER_STATUSES)[number];

export interface Computer {
  id: string;
  computerCode: string;
  name: string;
  labId: string | null;
  hostname: string | null;
  ipAddress: string | null;
  operatingSystem: string | null;
  agentVersion: string | null;
  status: ComputerStatus;
  lastSeenAt: string | null;
  cpuUsage: number | null;
  memoryUsage: number | null;
  lastScreenshotAt: string | null;
  isEnabled: boolean;
  registeredAt: string | null;
  updatedAt: string;
}

export interface ComputerLive extends Computer {
  labName: string | null;
  currentApplication: string | null;
  currentSessionUsername: string | null;
  currentSessionStartedAt: string | null;
}

export interface ComputerRegistrationRequest {
  name: string;
  labId?: string | null;
}

export interface ComputerRegistrationResponse {
  computerId: string;
  computerCode: string;
  registrationCode: string;
}

export interface AgentRegisterRequest {
  registrationCode: string;
  hostname: string;
  operatingSystem: string;
  agentVersion: string;
}

export interface AgentRegisterResponse {
  computerId: string;
  agentToken: string;
}
