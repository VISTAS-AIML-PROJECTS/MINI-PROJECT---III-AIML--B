export interface Lab {
  id: string;
  name: string;
  building: string | null;
  room: string | null;
  description: string | null;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface ViewerLabAssignment {
  viewerId: string;
  labId: string;
  createdAt: string;
}
