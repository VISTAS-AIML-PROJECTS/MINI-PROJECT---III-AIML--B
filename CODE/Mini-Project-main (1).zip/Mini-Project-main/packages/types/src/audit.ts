export interface AuditLog {
  id: string;
  adminId: string | null;
  adminEmail?: string;
  action: string;
  computerId: string | null;
  metadata: Record<string, unknown> | null;
  createdAt: string;
}
