export interface ReportFilters {
  dateFrom: string;
  dateTo: string;
  labId?: string;
  computerId?: string;
  applicationId?: string;
}

export interface ActivityReportPoint {
  date: string;
  eventCount: number;
  activeComputerCount: number;
}

export interface ApplicationReportPoint {
  applicationName: string;
  usageSeconds: number;
  sessionCount: number;
}

export interface ComputerUtilizationPoint {
  computerId: string;
  computerName: string;
  onlineSeconds: number;
  offlineSeconds: number;
  uptimePercentage: number;
}

export interface SessionStatisticsPoint {
  date: string;
  sessionCount: number;
  averageDurationSeconds: number;
}
