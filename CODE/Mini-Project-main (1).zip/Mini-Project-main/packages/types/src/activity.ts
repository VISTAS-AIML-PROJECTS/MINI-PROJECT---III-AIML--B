export const ACTIVITY_EVENT_TYPES = [
  "APP_OPEN",
  "APP_CLOSE",
  "APP_SWITCH",
  "SESSION_START",
  "SESSION_END",
  "PC_ONLINE",
  "PC_OFFLINE",
] as const;
export type ActivityEventType = (typeof ACTIVITY_EVENT_TYPES)[number];

export interface ActivityEvent {
  id: string;
  computerId: string;
  sessionId: string | null;
  eventType: ActivityEventType;
  applicationName: string | null;
  windowTitle: string | null;
  metadata: Record<string, unknown> | null;
  occurredAt: string;
}

export interface ActivityEventIngest {
  eventType: ActivityEventType;
  applicationName?: string;
  windowTitle?: string;
  previousApplicationName?: string;
  metadata?: Record<string, unknown>;
  occurredAt: string;
}

export interface ActivityFilters {
  computerId?: string;
  labId?: string;
  applicationName?: string;
  eventType?: ActivityEventType;
  dateFrom?: string;
  dateTo?: string;
}
