import { z } from "zod";

export const createLabSchema = z.object({
  name: z.string().min(1).max(120),
  building: z.string().max(120).optional(),
  room: z.string().max(60).optional(),
  description: z.string().max(500).optional(),
});
export type CreateLabInput = z.infer<typeof createLabSchema>;

export const updateLabSchema = createLabSchema.partial().extend({
  isActive: z.boolean().optional(),
});
export type UpdateLabInput = z.infer<typeof updateLabSchema>;
