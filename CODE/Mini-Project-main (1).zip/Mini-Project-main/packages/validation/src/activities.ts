import { z } from "zod";

export const activityFiltersSchema = z.object({
  computerId: z.string().uuid().optional(),
  labId: z.string().uuid().optional(),
  applicationName: z.string().max(255).optional(),
  eventType: z
    .enum([
      "APP_OPEN",
      "APP_CLOSE",
      "APP_SWITCH",
      "SESSION_START",
      "SESSION_END",
      "PC_ONLINE",
      "PC_OFFLINE",
    ])
    .optional(),
  dateFrom: z.string().datetime().optional(),
  dateTo: z.string().datetime().optional(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(200).default(50),
});
export type ActivityFiltersInput = z.infer<typeof activityFiltersSchema>;
