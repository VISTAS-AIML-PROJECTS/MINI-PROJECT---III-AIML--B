import { z } from "zod";

export const monitoringSettingsSchema = z.object({
  heartbeatIntervalSeconds: z.number().int().min(5).max(300),
  offlineThresholdSeconds: z.number().int().min(15).max(900),
  activityRetentionDays: z.number().int().min(7).max(3650),
  auditRetentionDays: z.number().int().min(365).max(3650),
  screenshotIntervalSeconds: z.number().int().min(30).max(3600),
});
export type MonitoringSettingsInput = z.infer<typeof monitoringSettingsSchema>;
