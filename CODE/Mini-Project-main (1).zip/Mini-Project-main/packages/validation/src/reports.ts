import { z } from "zod";

export const reportFiltersSchema = z.object({
  dateFrom: z.string().datetime(),
  dateTo: z.string().datetime(),
  labId: z.string().uuid().optional(),
  computerId: z.string().uuid().optional(),
  applicationId: z.string().uuid().optional(),
});
export type ReportFiltersInput = z.infer<typeof reportFiltersSchema>;
