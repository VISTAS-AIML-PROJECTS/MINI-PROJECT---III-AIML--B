import { z } from "zod";

export const commandTypeSchema = z.enum(["LOCK", "LOGOUT", "RESTART", "SHUTDOWN"]);
export type CommandTypeInput = z.infer<typeof commandTypeSchema>;

export const commandResultSchema = z.object({
  status: z.enum(["SUCCEEDED", "FAILED"]),
  result: z.record(z.unknown()).optional(),
});
export type CommandResultInput = z.infer<typeof commandResultSchema>;
