import { z } from "zod";

export const createComputerSchema = z.object({
  name: z.string().min(1).max(120),
  labId: z.string().uuid().optional(),
});
export type CreateComputerInput = z.infer<typeof createComputerSchema>;

export const updateComputerSchema = z.object({
  name: z.string().min(1).max(120).optional(),
  labId: z.string().uuid().nullable().optional(),
});
export type UpdateComputerInput = z.infer<typeof updateComputerSchema>;

export const agentRegisterSchema = z.object({
  registrationCode: z.string().min(6).max(64),
  hostname: z.string().min(1).max(255),
  operatingSystem: z.string().min(1).max(255),
  agentVersion: z.string().min(1).max(32),
});
export type AgentRegisterInput = z.infer<typeof agentRegisterSchema>;

export const agentHeartbeatSchema = z.object({
  status: z.enum(["ONLINE"]),
  cpuUsage: z.number().min(0).max(100),
  memoryUsage: z.number().min(0).max(100),
  ipAddress: z.string().max(64).optional(),
  agentVersion: z.string().max(32).optional(),
});
export type AgentHeartbeatInput = z.infer<typeof agentHeartbeatSchema>;

export const agentActivityEventSchema = z.object({
  eventType: z.enum([
    "APP_OPEN",
    "APP_CLOSE",
    "APP_SWITCH",
    "SESSION_START",
    "SESSION_END",
    "PC_ONLINE",
    "PC_OFFLINE",
  ]),
  applicationName: z.string().max(255).optional(),
  windowTitle: z.string().max(500).optional(),
  previousApplicationName: z.string().max(255).optional(),
  metadata: z.record(z.unknown()).optional(),
  occurredAt: z.string().datetime(),
});
export type AgentActivityEventInput = z.infer<typeof agentActivityEventSchema>;

export const agentActivityBatchSchema = z.object({
  events: z.array(agentActivityEventSchema).min(1).max(200),
});
export type AgentActivityBatchInput = z.infer<typeof agentActivityBatchSchema>;
