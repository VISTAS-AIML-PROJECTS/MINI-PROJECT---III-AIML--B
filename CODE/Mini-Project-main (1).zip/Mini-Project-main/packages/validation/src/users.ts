import { z } from "zod";

export const createViewerSchema = z.object({
  email: z.string().email(),
  fullName: z.string().min(1).max(120),
  password: z.string().min(8).max(200),
});
export type CreateViewerInput = z.infer<typeof createViewerSchema>;

export const updateUserSchema = z.object({
  fullName: z.string().min(1).max(120).optional(),
  isActive: z.boolean().optional(),
});
export type UpdateUserInput = z.infer<typeof updateUserSchema>;
