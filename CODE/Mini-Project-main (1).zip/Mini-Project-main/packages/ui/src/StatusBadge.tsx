import type { ComputerStatus } from "@college-monitor/types";
import { cn } from "./cn";

const STATUS_STYLES: Record<ComputerStatus, string> = {
  ONLINE: "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border-emerald-500/30",
  OFFLINE: "bg-red-500/15 text-red-600 dark:text-red-400 border-red-500/30",
  DISABLED: "bg-zinc-500/15 text-zinc-600 dark:text-zinc-400 border-zinc-500/30",
};

const STATUS_DOT: Record<ComputerStatus, string> = {
  ONLINE: "bg-emerald-500",
  OFFLINE: "bg-red-500",
  DISABLED: "bg-zinc-500",
};

export function StatusBadge({ status, className }: { status: ComputerStatus; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-medium",
        STATUS_STYLES[status],
        className,
      )}
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", STATUS_DOT[status])} />
      {status[0]}
      {status.slice(1).toLowerCase()}
    </span>
  );
}
