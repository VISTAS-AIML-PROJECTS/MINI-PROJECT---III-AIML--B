export const DEFAULT_HEARTBEAT_INTERVAL_SECONDS = 15;
export const DEFAULT_OFFLINE_THRESHOLD_SECONDS = 45;
export const DEFAULT_ACTIVITY_RETENTION_DAYS = 90;
export const DEFAULT_AUDIT_RETENTION_DAYS = 365;

// Periodic, not live: a fixed floor keeps this from ever becoming a
// continuous screen-recording feature.
export const DEFAULT_SCREENSHOT_INTERVAL_SECONDS = 60;
export const MIN_SCREENSHOT_INTERVAL_SECONDS = 30;

export const AGENT_OFFLINE_QUEUE_MAX_EVENTS = 500;
export const AGENT_RECONNECT_BASE_DELAY_MS = 1000;
export const AGENT_RECONNECT_MAX_DELAY_MS = 60_000;

export const ALLOWED_REMOTE_COMMANDS = ["LOCK", "LOGOUT", "RESTART", "SHUTDOWN"] as const;

export const APP_ROUTES = {
  DASHBOARD: "/",
  COMPUTERS: "/computers",
  LABS: "/labs",
  ACTIVITY: "/activity",
  APPLICATIONS: "/applications",
  SESSIONS: "/sessions",
  REPORTS: "/reports",
  AUDIT_LOGS: "/audit-logs",
  USERS: "/users",
  SETTINGS: "/settings",
  LOGIN: "/login",
} as const;
