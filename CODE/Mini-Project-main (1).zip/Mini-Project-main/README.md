# College PC Monitoring & Management System

A monitoring and management system for college-owned lab computers, built as two Electron desktop apps talking directly to Supabase — no custom backend server.

## Roles

Exactly two roles, enforced by Postgres Row Level Security (not just the UI):

- **ADMIN** — the only place any monitoring data is read: computers, labs, activity, applications, sessions, reports, screenshots, audit logs. Also manages computers, remote commands, Viewer accounts, and settings.
- **VIEWER** — no dashboard. A Viewer account exists to sign in on a lab PC and register that machine as a monitored agent (see below) — it does not read any data anywhere. RLS still scopes what a VIEWER session could read to only the labs an Admin assigned it (Users page), as a defense-in-depth boundary, even though the current UI never exercises that read path.

## Architecture

```
┌─────────────────────┐        ┌──────────────────────┐
│   College PC Admin   │        │  College PC Viewer    │
│  (Electron, ADMIN)   │        │ (Electron, VIEWER)     │
│  reads all data,     │        │  login + register/    │
│  sends commands      │        │  reset this computer  │
└──────────┬────────────┘        │  as a monitored agent  │
           │                     └──────────┬────────────┘
           │                                │
           ▼                                ▼
   ┌─────────────────────────────────────────────────┐
   │                Supabase project                 │
   │  Auth (email/password) · Postgres + RLS          │
   │  Realtime (postgres_changes) · Edge Functions     │
   │  Storage (private screenshots bucket)            │
   └─────────────────────────────────────────────────┘
```

There is no NestJS/Express backend. Both desktop apps use `@supabase/supabase-js` directly:

- **Auth** — Supabase Auth (email/password) issues the JWT; RLS policies key off `auth.uid()` and the caller's `profiles.role`.
- **Data** — every table has RLS: ADMIN gets full read/write; VIEWER gets no UI-exposed reads at all (the underlying SELECT policies are lab-scoped, not role-blanket, as defense in depth); audit logs, agent credentials, remote commands, and screenshots are ADMIN-only regardless of lab assignment.
- **Realtime** — Admin subscribes to `postgres_changes` on `computers`, `sessions`, `activity_events`, `application_activity`, and `remote_commands` for live updates, respecting the same RLS.
- **Edge Functions** (`supabase/functions/`) handle the handful of things the anon key legitimately can't do safely from a client: issuing/validating agent credentials, accepting heartbeats, ingesting activity, uploading screenshots, reporting command results, and provisioning/editing/deleting Viewer auth accounts (all of which need the service role key, which never leaves Supabase).

### The on-device agent

College PC Viewer is dual-purpose. When installed on a monitored lab PC, its one page lets it register itself with a one-time code an Admin generates (Admin's Computers → Register PC). Once registered, the app's main process runs the monitoring loop in the background regardless of who (if anyone) is logged into it:

- Heartbeat every ~15s (CPU%, RAM%) → `agent-heartbeat`
- Active-window polling → application open/switch/close events → `agent-activity`
- Periodic screenshot (default every 60s, never continuous/live) → `agent-screenshot`, viewable only from Admin's Computer Detail page via a short-lived signed URL
- Executes `LOCK` / `LOGOUT` / `RESTART` / `SHUTDOWN` commands an Admin sends, reports the result → `agent-command-result`
- Offline queue with exponential-backoff reconnect if the network drops
- Agent token stored via Electron `safeStorage` (OS-keychain-backed encryption), never in plain text
- If a computer is deleted or its credential revoked from Admin, the agent surfaces this and offers "Reset registration" to clear the stale local token and register again with a fresh code

`apps/pc-agent` also exists as a standalone Electron app with the same monitoring code, currently paused in favor of the merged approach above — see that folder if you want a dedicated agent-only binary instead.

## Tech stack

- **Desktop**: Electron, React, TypeScript, Vite, Tailwind CSS v4, shadcn/ui, Zustand, React Router, TanStack Query, Recharts
- **Backend-as-a-service**: Supabase (Postgres, Auth, Realtime, Edge Functions on Deno)
- **Monorepo**: pnpm workspaces + Turborepo

## Repository structure

```
apps/
  admin-desktop/     Electron app for ADMIN
  viewer-desktop/     Electron app for VIEWER (+ on-device agent)
  pc-agent/           Standalone agent-only Electron app (paused)
packages/
  types/              Shared TypeScript types
  validation/          Shared Zod schemas
  config/              Shared constants (routes, defaults)
  ui/                  Small cross-app components (StatusBadge, cn())
supabase/
  migrations/          SQL schema, RLS policies, reporting functions
  functions/            Edge Functions (Deno)
  seed.sql             Dev-only: creates the ADMIN account
.github/workflows/
  release.yml          Builds + publishes .exe / .dmg to GitHub Releases
```

## Prerequisites

- Node.js 20+, pnpm 10+
- A Supabase project (Postgres 15+)
- [Supabase CLI](https://supabase.com/docs/guides/cli) for migrations and Edge Function deployment

## Setup

1. **Install dependencies**

   ```bash
   pnpm install
   ```

2. **Configure environment** — copy `.env.example` to `.env` at the repo root and fill in your Supabase project's URL and anon key (Project Settings → API):

   ```
   VITE_SUPABASE_URL=
   VITE_SUPABASE_ANON_KEY=
   DATABASE_URL=            # Project Settings -> Database -> Connection string (direct, not pooled)
   ADMIN_SEED_PASSWORD=     # only needed to run pnpm db:seed
   ```

   This one `.env` is shared by every app (Vite's `envDir` points each app at the repo root) and by the migration/seed scripts. `DATABASE_URL` is never bundled into any app — only variables prefixed `VITE_` are.

3. **Run migrations**

   ```bash
   pnpm db:migrate
   ```

4. **Seed the Admin account** (creates exactly one ADMIN; no fake labs/computers)

   ```bash
   pnpm db:seed
   ```

5. **Deploy Edge Functions**

   ```bash
   supabase link --project-ref <your-project-ref>
   pnpm functions:deploy
   supabase secrets set CRON_SECRET=$(openssl rand -hex 32)
   ```

   `CRON_SECRET` guards `offline-sweep` (the function that marks a computer OFFLINE once its heartbeat expires) — see [docs/deployment.md](docs/deployment.md) for wiring it to a schedule.

## Development

```bash
pnpm dev:admin     # College PC Admin, http://localhost:5173
pnpm dev:viewer    # College PC Viewer, http://localhost:5174
```

Log in to Admin with the account created by `pnpm db:seed`. Create Viewer accounts from Admin's **Users** page — they're never seeded directly.

## Building & releasing

Each app builds with `pnpm --filter <app> build` and packages with `electron-builder` (config in each app's `electron-builder.yml`). `.github/workflows/release.yml` builds both apps for Windows (`.exe`) and macOS (`.dmg`) and publishes them to a GitHub Release whenever a `v*` tag is pushed. It needs two repository secrets: `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.

## Security notes

- The Supabase **service role key** only ever exists inside Edge Functions (Supabase injects it automatically) — it's never in any `.env` an Electron app reads, and never bundled into a build.
- RLS is the real authorization boundary, not just UI hiding: a Viewer's Supabase session literally cannot write to admin-only tables, confirmed by both the RLS policies in `supabase/migrations/0004_rls_policies.sql` and independent `curl` testing during development.
- Remote commands are limited to four fixed OS actions (lock/logout/restart/shutdown) — there is no arbitrary command execution path.
- Every admin action and command result is written to an append-only `audit_logs` table.

## Further reading

See `docs/` for architecture, database schema, and deployment details.
