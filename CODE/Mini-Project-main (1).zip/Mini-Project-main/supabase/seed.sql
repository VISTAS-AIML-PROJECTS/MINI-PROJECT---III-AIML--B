-- Bootstraps exactly one thing: the ADMIN account. No labs, computers, or
-- other demo/mock records are created — those are real operational data
-- and should only ever come from an admin actually registering them (Labs
-- page, Computers → Register PC) or from a real PC Agent reporting in.
-- Viewer accounts are likewise created through the Admin Desktop app's
-- Users page (backed by the admin-create-viewer Edge Function), not
-- seeded directly.
--
-- ${ADMIN_SEED_PASSWORD} is substituted by scripts/db-seed.sh from an
-- environment variable before being sent to psql. Never hard-code a real
-- password here.

do $$
declare
  admin_id uuid := gen_random_uuid();
begin
  -- Auth user. The profiles row is created automatically by the
  -- trg_on_auth_user_created trigger, which reads role from
  -- raw_user_meta_data.
  -- Every token column below must be '' rather than NULL: GoTrue scans
  -- them into non-nullable Go strings, and a NULL here surfaces at login
  -- as an opaque "Database error querying schema" instead of a clear
  -- error — easy to hit when inserting auth.users by hand like this.
  insert into auth.users (
    id, instance_id, aud, role, email, encrypted_password,
    email_confirmed_at, raw_app_meta_data, raw_user_meta_data,
    confirmation_token, recovery_token, email_change,
    email_change_token_new, email_change_token_current,
    phone_change, phone_change_token, reauthentication_token,
    created_at, updated_at
  ) values (
    admin_id, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
    'admin@admin.com', crypt('${ADMIN_SEED_PASSWORD}', gen_salt('bf')),
    now(), '{"provider":"email","providers":["email"]}',
    '{"full_name":"System Administrator","role":"ADMIN"}',
    '', '', '', '', '', '', '', '',
    now(), now()
  )
  on conflict (id) do nothing;

  -- GoTrue's password grant also requires a matching identities row for
  -- the email provider — without it, sign-in fails even though the user
  -- row itself looks complete.
  insert into auth.identities (
    id, user_id, provider_id, identity_data, provider, last_sign_in_at, created_at, updated_at
  )
  values (
    gen_random_uuid(), admin_id, admin_id::text,
    jsonb_build_object('sub', admin_id::text, 'email', 'admin@admin.com', 'email_verified', true),
    'email', now(), now(), now()
  )
  on conflict do nothing;

  insert into system_settings (key, value, updated_by)
  values (
    'monitoring',
    jsonb_build_object(
      'heartbeatIntervalSeconds', 15,
      'offlineThresholdSeconds', 45,
      'activityRetentionDays', 90,
      'auditRetentionDays', 365,
      'screenshotIntervalSeconds', 60
    ),
    admin_id
  )
  on conflict (key) do nothing;
end $$;
