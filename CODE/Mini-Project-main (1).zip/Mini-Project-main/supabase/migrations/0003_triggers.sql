-- updated_at maintenance triggers

create trigger trg_profiles_updated_at before update on profiles
  for each row execute function set_updated_at();

create trigger trg_labs_updated_at before update on labs
  for each row execute function set_updated_at();

create trigger trg_computers_updated_at before update on computers
  for each row execute function set_updated_at();

-- Auth -> profiles provisioning trigger
create trigger trg_on_auth_user_created
  after insert on auth.users
  for each row execute function handle_new_auth_user();
