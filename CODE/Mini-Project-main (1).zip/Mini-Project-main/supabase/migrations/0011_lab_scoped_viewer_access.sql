-- Restricts VIEWER visibility to computers in labs they're assigned to
-- (via viewer_lab_assignments), instead of every computer in the system.
-- ADMIN is unaffected. A Viewer with no assignments sees nothing until an
-- Admin assigns a lab from the Users page.

drop policy labs_viewer_select on labs;
create policy labs_viewer_select on labs
  for select using (
    auth_role() = 'VIEWER'
    and exists (
      select 1 from viewer_lab_assignments vla
      where vla.viewer_id = auth.uid() and vla.lab_id = labs.id
    )
  );

drop policy computers_viewer_select on computers;
create policy computers_viewer_select on computers
  for select using (
    auth_role() = 'VIEWER'
    and lab_id is not null
    and exists (
      select 1 from viewer_lab_assignments vla
      where vla.viewer_id = auth.uid() and vla.lab_id = computers.lab_id
    )
  );

drop policy sessions_viewer_select on sessions;
create policy sessions_viewer_select on sessions
  for select using (
    auth_role() = 'VIEWER'
    and exists (
      select 1 from computers c
      join viewer_lab_assignments vla on vla.lab_id = c.lab_id
      where c.id = sessions.computer_id and vla.viewer_id = auth.uid()
    )
  );

drop policy application_activity_viewer_select on application_activity;
create policy application_activity_viewer_select on application_activity
  for select using (
    auth_role() = 'VIEWER'
    and exists (
      select 1 from computers c
      join viewer_lab_assignments vla on vla.lab_id = c.lab_id
      where c.id = application_activity.computer_id and vla.viewer_id = auth.uid()
    )
  );

drop policy activity_events_viewer_select on activity_events;
create policy activity_events_viewer_select on activity_events
  for select using (
    auth_role() = 'VIEWER'
    and exists (
      select 1 from computers c
      join viewer_lab_assignments vla on vla.lab_id = c.lab_id
      where c.id = activity_events.computer_id and vla.viewer_id = auth.uid()
    )
  );

-- applications (the software catalog: name/executable/publisher) and
-- system_settings (monitoring interval/retention config) are not
-- lab-specific data, so they stay visible to every Viewer unchanged.
