-- Row Level Security.
--
-- There is no custom backend: the Admin and Viewer Electron apps talk to
-- Supabase directly (Auth + Postgres + Realtime) using the anon key, so
-- these policies ARE the authorization boundary. Privileged operations
-- that must not be forgeable by a client (issuing agent credentials,
-- accepting heartbeats, writing command results, provisioning Viewer
-- auth accounts) are handled by Supabase Edge Functions using the
-- service role key, which bypasses RLS entirely — see supabase/functions.
--
-- Convention: ADMIN = full read/write on operational data. VIEWER =
-- read-only (SELECT) on operational tables, zero access to admin-only
-- tables (audit logs, agent credentials/registration codes, remote
-- commands).

alter table profiles enable row level security;
alter table labs enable row level security;
alter table computers enable row level security;
alter table computer_registration_codes enable row level security;
alter table computer_credentials enable row level security;
alter table sessions enable row level security;
alter table applications enable row level security;
alter table application_activity enable row level security;
alter table activity_events enable row level security;
alter table audit_logs enable row level security;
alter table remote_commands enable row level security;
alter table system_settings enable row level security;

-- profiles ---------------------------------------------------------------

create policy profiles_admin_all on profiles
  for all using (is_admin()) with check (is_admin());

create policy profiles_self_select on profiles
  for select using (id = auth.uid());

-- labs ---------------------------------------------------------------------

create policy labs_admin_all on labs
  for all using (is_admin()) with check (is_admin());

create policy labs_viewer_select on labs
  for select using (auth_role() = 'VIEWER');

-- computers ------------------------------------------------------------------

create policy computers_admin_all on computers
  for all using (is_admin()) with check (is_admin());

create policy computers_viewer_select on computers
  for select using (auth_role() = 'VIEWER');

-- computer_registration_codes -----------------------------------------------
-- Admin issues/views/early-expires codes. Consumption (setting consumed_at)
-- happens inside the agent-register Edge Function via the service role.

create policy registration_codes_admin_select on computer_registration_codes
  for select using (is_admin());

create policy registration_codes_admin_insert on computer_registration_codes
  for insert with check (is_admin() and issued_by = auth.uid());

create policy registration_codes_admin_update on computer_registration_codes
  for update using (is_admin()) with check (is_admin());

-- computer_credentials ---------------------------------------------------
-- Issued only by the agent-register Edge Function (service role). Admin
-- may view metadata and revoke (set revoked_at) but never create one
-- directly, and the raw secret is never stored here (hash only, and even
-- the hash is not selectable from this policy's use case in the UI).

create policy credentials_admin_select on computer_credentials
  for select using (is_admin());

create policy credentials_admin_revoke on computer_credentials
  for update using (is_admin()) with check (is_admin());

-- sessions -----------------------------------------------------------------
-- Written by Edge Functions (service role) from agent activity ingestion.
-- Admin/Viewer only ever read.

create policy sessions_admin_select on sessions
  for select using (is_admin());

create policy sessions_viewer_select on sessions
  for select using (auth_role() = 'VIEWER');

-- applications ---------------------------------------------------------------
-- Catalog rows are written by Edge Functions as new executables are seen.

create policy applications_admin_select on applications
  for select using (is_admin());

create policy applications_viewer_select on applications
  for select using (auth_role() = 'VIEWER');

-- application_activity ---------------------------------------------------

create policy application_activity_admin_select on application_activity
  for select using (is_admin());

create policy application_activity_viewer_select on application_activity
  for select using (auth_role() = 'VIEWER');

-- activity_events ----------------------------------------------------------

create policy activity_events_admin_select on activity_events
  for select using (is_admin());

create policy activity_events_viewer_select on activity_events
  for select using (auth_role() = 'VIEWER');

-- audit_logs (append-only; no update/delete policy exists for anyone) -----
-- Admin actions taken directly against Supabase (rename/enable/disable a
-- PC, create/disable a Viewer, etc.) must self-report an audit row as the
-- acting admin. Command-execution audit rows are written by Edge
-- Functions via the service role.

create policy audit_logs_admin_select on audit_logs
  for select using (is_admin());

create policy audit_logs_admin_insert on audit_logs
  for insert with check (is_admin() and admin_id = auth.uid());

-- remote_commands (admin only, viewer has zero access) ---------------------
-- Admin may create a PENDING request for itself and read history. Status
-- transitions (SENT/ACKNOWLEDGED/SUCCEEDED/FAILED/TIMED_OUT) are only ever
-- written by Edge Functions via the service role, so a client can never
-- forge a command result.

create policy remote_commands_admin_select on remote_commands
  for select using (is_admin());

create policy remote_commands_admin_insert on remote_commands
  for insert
  with check (is_admin() and requested_by = auth.uid() and status = 'PENDING');

-- system_settings ------------------------------------------------------------

create policy system_settings_admin_all on system_settings
  for all using (is_admin()) with check (is_admin());

create policy system_settings_viewer_select on system_settings
  for select using (auth_role() = 'VIEWER');
