-- Reporting aggregation functions. application_activity and
-- activity_events are expected to grow into the millions of rows, so
-- reports are computed in Postgres (indexed, set-based) rather than by
-- pulling raw rows into the client. These run with the caller's own
-- privileges (SECURITY INVOKER, the default), so existing RLS policies on
-- the underlying tables apply exactly as they do to a plain SELECT —
-- an ADMIN or VIEWER can call them, anyone else gets no rows.

create or replace function application_usage_summary()
returns table (
  application_id uuid,
  application_name text,
  total_usage_seconds bigint,
  computer_count bigint,
  session_count bigint,
  average_duration_seconds numeric
)
language sql
stable
as $$
  select
    a.id,
    a.name,
    coalesce(sum(aa.duration_seconds), 0)::bigint,
    count(distinct aa.computer_id),
    count(distinct aa.session_id) filter (where aa.session_id is not null),
    coalesce(avg(aa.duration_seconds), 0)
  from applications a
  left join application_activity aa on aa.application_id = a.id
  group by a.id, a.name
  order by coalesce(sum(aa.duration_seconds), 0) desc;
$$;

create or replace function activity_report(
  date_from timestamptz,
  date_to timestamptz,
  p_lab_id uuid default null,
  p_computer_id uuid default null
)
returns table (day date, event_count bigint, active_computer_count bigint)
language sql
stable
as $$
  select
    date_trunc('day', e.occurred_at)::date as day,
    count(*)::bigint,
    count(distinct e.computer_id)::bigint
  from activity_events e
  join computers c on c.id = e.computer_id
  where e.occurred_at >= date_from
    and e.occurred_at <= date_to
    and (p_lab_id is null or c.lab_id = p_lab_id)
    and (p_computer_id is null or e.computer_id = p_computer_id)
  group by 1
  order by 1;
$$;

create or replace function application_usage_report(
  date_from timestamptz,
  date_to timestamptz,
  p_lab_id uuid default null,
  p_computer_id uuid default null
)
returns table (application_name text, usage_seconds bigint, session_count bigint)
language sql
stable
as $$
  select
    a.name,
    coalesce(sum(aa.duration_seconds), 0)::bigint,
    count(distinct aa.session_id) filter (where aa.session_id is not null)::bigint
  from application_activity aa
  join applications a on a.id = aa.application_id
  join computers c on c.id = aa.computer_id
  where aa.started_at >= date_from
    and aa.started_at <= date_to
    and (p_lab_id is null or c.lab_id = p_lab_id)
    and (p_computer_id is null or aa.computer_id = p_computer_id)
  group by a.name
  order by 2 desc
  limit 20;
$$;

create or replace function computer_utilization_report(
  date_from timestamptz,
  date_to timestamptz,
  p_lab_id uuid default null
)
returns table (
  computer_id uuid,
  computer_name text,
  online_seconds bigint,
  offline_seconds bigint,
  uptime_percentage numeric
)
language plpgsql
stable
as $$
declare
  window_seconds numeric := greatest(extract(epoch from (date_to - date_from)), 1);
begin
  return query
  with events as (
    select
      e.computer_id,
      e.event_type,
      e.occurred_at,
      lead(e.occurred_at) over (partition by e.computer_id order by e.occurred_at) as next_occurred_at
    from activity_events e
    join computers c on c.id = e.computer_id
    where e.event_type in ('PC_ONLINE', 'PC_OFFLINE')
      and e.occurred_at >= date_from
      and e.occurred_at <= date_to
      and (p_lab_id is null or c.lab_id = p_lab_id)
  ),
  online_spans as (
    select
      computer_id,
      sum(
        extract(epoch from (least(coalesce(next_occurred_at, date_to), date_to) - occurred_at))
      ) as online_seconds
    from events
    where event_type = 'PC_ONLINE'
    group by computer_id
  )
  select
    c.id,
    c.name,
    coalesce(round(o.online_seconds), 0)::bigint,
    greatest(0, round(window_seconds - coalesce(o.online_seconds, 0)))::bigint,
    round(least(100, greatest(0, coalesce(o.online_seconds, 0) / window_seconds * 100)), 1)
  from computers c
  left join online_spans o on o.computer_id = c.id
  where (p_lab_id is null or c.lab_id = p_lab_id)
  order by c.name;
end;
$$;

create or replace function session_statistics_report(date_from timestamptz, date_to timestamptz)
returns table (day date, session_count bigint, average_duration_seconds numeric)
language sql
stable
as $$
  select
    date_trunc('day', s.started_at)::date as day,
    count(*)::bigint,
    coalesce(
      avg(extract(epoch from (coalesce(s.ended_at, now()) - s.started_at))),
      0
    )
  from sessions s
  where s.started_at >= date_from and s.started_at <= date_to
  group by 1
  order by 1;
$$;

grant execute on function application_usage_summary() to authenticated;
grant execute on function activity_report(timestamptz, timestamptz, uuid, uuid) to authenticated;
grant execute on function application_usage_report(timestamptz, timestamptz, uuid, uuid) to authenticated;
grant execute on function computer_utilization_report(timestamptz, timestamptz, uuid) to authenticated;
grant execute on function session_statistics_report(timestamptz, timestamptz) to authenticated;
