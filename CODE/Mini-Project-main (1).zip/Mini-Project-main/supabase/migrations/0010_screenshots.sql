-- Periodic (not continuous/live) screen captures, admin-only. Only the
-- single most recent screenshot per computer is kept — this is a
-- proportionality choice, not a technical limit: keeping a rolling photo
-- history of someone's screen is a meaningfully bigger privacy footprint
-- than a "what does this PC look like right now" snapshot, and nothing
-- in this product needs the former.

alter table computers add column last_screenshot_at timestamptz;

insert into storage.buckets (id, name, public)
values ('screenshots', 'screenshots', false)
on conflict (id) do nothing;

-- Only ADMIN may ever read a screenshot. Uploads happen exclusively via
-- the agent-screenshot Edge Function using the service role (which
-- bypasses storage RLS entirely), so there is intentionally no INSERT
-- policy here for any client role — not even ADMIN.
create policy screenshots_admin_select on storage.objects
  for select using (bucket_id = 'screenshots' and is_admin());
