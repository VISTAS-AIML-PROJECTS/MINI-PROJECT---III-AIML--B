-- Scopes what a VIEWER can see to specific labs, rather than every
-- computer in the system. An Admin assigns one or more labs to each
-- Viewer from the Users page; a Viewer with no assignments sees nothing
-- until an Admin assigns one.

create table viewer_lab_assignments (
  viewer_id uuid not null references profiles (id) on delete cascade,
  lab_id uuid not null references labs (id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (viewer_id, lab_id)
);

create index idx_viewer_lab_assignments_lab_id on viewer_lab_assignments (lab_id);

alter table viewer_lab_assignments enable row level security;

create policy viewer_lab_assignments_admin_all on viewer_lab_assignments
  for all using (is_admin()) with check (is_admin());

create policy viewer_lab_assignments_self_select on viewer_lab_assignments
  for select using (viewer_id = auth.uid());
