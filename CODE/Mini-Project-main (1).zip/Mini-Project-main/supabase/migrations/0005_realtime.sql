-- Enable Postgres Changes (Realtime) for tables the Admin/Viewer desktop
-- apps subscribe to directly. Realtime respects each table's RLS policies
-- per connected (authenticated) client.

alter publication supabase_realtime add table computers;
alter publication supabase_realtime add table sessions;
alter publication supabase_realtime add table activity_events;
alter publication supabase_realtime add table application_activity;
alter publication supabase_realtime add table remote_commands;

-- Full row data on UPDATE (not just changed columns) so clients can render
-- the new computer status/heartbeat without a follow-up fetch.
alter table computers replica identity full;
alter table remote_commands replica identity full;
