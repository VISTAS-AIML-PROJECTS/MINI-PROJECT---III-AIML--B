-- College PC Monitoring & Management System
-- Initial schema: extensions, enums, tables, indexes.

create extension if not exists "pgcrypto";

-- ---------------------------------------------------------------------------
-- Enums
-- ---------------------------------------------------------------------------

create type user_role as enum ('ADMIN', 'VIEWER');
create type computer_status as enum ('ONLINE', 'OFFLINE', 'DISABLED');
create type activity_event_type as enum (
  'APP_OPEN',
  'APP_CLOSE',
  'APP_SWITCH',
  'SESSION_START',
  'SESSION_END',
  'PC_ONLINE',
  'PC_OFFLINE'
);
create type remote_command_type as enum ('LOCK', 'LOGOUT', 'RESTART', 'SHUTDOWN');
create type remote_command_status as enum (
  'PENDING',
  'SENT',
  'ACKNOWLEDGED',
  'SUCCEEDED',
  'FAILED',
  'TIMED_OUT'
);

-- ---------------------------------------------------------------------------
-- profiles (mirrors auth.users, one row per Admin/Viewer)
-- ---------------------------------------------------------------------------

create table profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  email text not null unique,
  full_name text,
  role user_role not null default 'VIEWER',
  is_active boolean not null default true,
  last_login_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_profiles_role on profiles (role);

-- ---------------------------------------------------------------------------
-- labs
-- ---------------------------------------------------------------------------

create table labs (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  building text,
  room text,
  description text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index idx_labs_name on labs (name);

-- ---------------------------------------------------------------------------
-- computers
-- ---------------------------------------------------------------------------

create table computers (
  id uuid primary key default gen_random_uuid(),
  computer_code text not null unique,
  name text not null,
  lab_id uuid references labs (id) on delete set null,
  hostname text,
  ip_address text,
  operating_system text,
  agent_version text,
  status computer_status not null default 'OFFLINE',
  last_seen_at timestamptz,
  is_enabled boolean not null default true,
  registered_at timestamptz,
  updated_at timestamptz not null default now()
);

create index idx_computers_status on computers (status);
create index idx_computers_last_seen_at on computers (last_seen_at);
create index idx_computers_lab_id on computers (lab_id);

-- ---------------------------------------------------------------------------
-- computer_registration_codes
-- One-time codes issued by an Admin, consumed by a PC Agent during setup.
-- ---------------------------------------------------------------------------

create table computer_registration_codes (
  id uuid primary key default gen_random_uuid(),
  computer_id uuid not null references computers (id) on delete cascade,
  code_hash text not null,
  issued_by uuid references profiles (id) on delete set null,
  expires_at timestamptz not null,
  consumed_at timestamptz,
  created_at timestamptz not null default now()
);

create index idx_registration_codes_computer_id on computer_registration_codes (computer_id);

-- ---------------------------------------------------------------------------
-- computer_credentials
-- Long-lived agent credential issued after successful registration.
-- Only a hash is ever stored; the raw token is shown to the agent once.
-- ---------------------------------------------------------------------------

create table computer_credentials (
  id uuid primary key default gen_random_uuid(),
  computer_id uuid not null references computers (id) on delete cascade,
  credential_hash text not null,
  created_at timestamptz not null default now(),
  revoked_at timestamptz
);

create index idx_computer_credentials_computer_id on computer_credentials (computer_id);
create index idx_computer_credentials_active on computer_credentials (computer_id) where revoked_at is null;

-- ---------------------------------------------------------------------------
-- sessions (OS login sessions on a monitored computer)
-- ---------------------------------------------------------------------------

create table sessions (
  id uuid primary key default gen_random_uuid(),
  computer_id uuid not null references computers (id) on delete cascade,
  username text not null,
  started_at timestamptz not null default now(),
  ended_at timestamptz,
  is_active boolean not null default true
);

create index idx_sessions_computer_id on sessions (computer_id);
create index idx_sessions_is_active on sessions (is_active);

-- ---------------------------------------------------------------------------
-- applications (catalog)
-- ---------------------------------------------------------------------------

create table applications (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  executable_name text,
  publisher text,
  created_at timestamptz not null default now()
);

create unique index idx_applications_executable_name on applications (executable_name)
  where executable_name is not null;

-- ---------------------------------------------------------------------------
-- application_activity (durations spent in a given application)
-- ---------------------------------------------------------------------------

create table application_activity (
  id uuid primary key default gen_random_uuid(),
  computer_id uuid not null references computers (id) on delete cascade,
  session_id uuid references sessions (id) on delete set null,
  application_id uuid not null references applications (id) on delete cascade,
  window_title text,
  started_at timestamptz not null,
  ended_at timestamptz,
  duration_seconds integer,
  created_at timestamptz not null default now()
);

create index idx_application_activity_computer_id on application_activity (computer_id);
create index idx_application_activity_started_at on application_activity (started_at);
create index idx_application_activity_application_id on application_activity (application_id);
create index idx_application_activity_session_id on application_activity (session_id);

-- ---------------------------------------------------------------------------
-- activity_events (raw event stream: app switches, session/pc lifecycle)
-- ---------------------------------------------------------------------------

create table activity_events (
  id uuid primary key default gen_random_uuid(),
  computer_id uuid not null references computers (id) on delete cascade,
  session_id uuid references sessions (id) on delete set null,
  event_type activity_event_type not null,
  application_name text,
  window_title text,
  metadata jsonb,
  occurred_at timestamptz not null default now()
);

create index idx_activity_events_computer_id on activity_events (computer_id);
create index idx_activity_events_occurred_at on activity_events (occurred_at);
create index idx_activity_events_event_type on activity_events (event_type);

-- ---------------------------------------------------------------------------
-- audit_logs (append-only)
-- ---------------------------------------------------------------------------

create table audit_logs (
  id uuid primary key default gen_random_uuid(),
  admin_id uuid references profiles (id) on delete set null,
  action text not null,
  computer_id uuid references computers (id) on delete set null,
  metadata jsonb,
  created_at timestamptz not null default now()
);

create index idx_audit_logs_admin_id on audit_logs (admin_id);
create index idx_audit_logs_created_at on audit_logs (created_at);

-- ---------------------------------------------------------------------------
-- remote_commands
-- ---------------------------------------------------------------------------

create table remote_commands (
  id uuid primary key default gen_random_uuid(),
  computer_id uuid not null references computers (id) on delete cascade,
  requested_by uuid not null references profiles (id) on delete restrict,
  command_type remote_command_type not null,
  status remote_command_status not null default 'PENDING',
  requested_at timestamptz not null default now(),
  executed_at timestamptz,
  result jsonb
);

create index idx_remote_commands_computer_id on remote_commands (computer_id);
create index idx_remote_commands_status on remote_commands (status);

-- ---------------------------------------------------------------------------
-- system_settings
-- ---------------------------------------------------------------------------

create table system_settings (
  id uuid primary key default gen_random_uuid(),
  key text not null unique,
  value jsonb not null,
  updated_by uuid references profiles (id) on delete set null,
  updated_at timestamptz not null default now()
);
