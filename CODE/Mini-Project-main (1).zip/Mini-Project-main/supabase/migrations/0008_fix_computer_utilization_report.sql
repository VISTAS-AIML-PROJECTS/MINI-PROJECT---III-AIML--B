-- Fixes "column reference \"computer_id\" is ambiguous" (42702). The
-- function's RETURNS TABLE(computer_id uuid, ...) implicitly creates a
-- PL/pgSQL OUT variable named computer_id, which collides with any bare
-- "computer_id" identifier used inside the function body's SQL (the CTEs
-- below). Internal CTE columns are renamed to avoid the collision.

create or replace function computer_utilization_report(
  date_from timestamptz,
  date_to timestamptz,
  p_lab_id uuid default null
)
returns table (
  computer_id uuid,
  computer_name text,
  online_seconds bigint,
  offline_seconds bigint,
  uptime_percentage numeric
)
language plpgsql
stable
as $$
declare
  window_seconds numeric := greatest(extract(epoch from (date_to - date_from)), 1);
begin
  return query
  with events as (
    select
      e.computer_id as ev_computer_id,
      e.event_type as ev_event_type,
      e.occurred_at as ev_occurred_at,
      lead(e.occurred_at) over (partition by e.computer_id order by e.occurred_at) as ev_next_occurred_at
    from activity_events e
    join computers c on c.id = e.computer_id
    where e.event_type in ('PC_ONLINE', 'PC_OFFLINE')
      and e.occurred_at >= date_from
      and e.occurred_at <= date_to
      and (p_lab_id is null or c.lab_id = p_lab_id)
  ),
  online_spans as (
    select
      ev.ev_computer_id as span_computer_id,
      sum(
        extract(epoch from (least(coalesce(ev.ev_next_occurred_at, date_to), date_to) - ev.ev_occurred_at))
      ) as span_online_seconds
    from events ev
    where ev.ev_event_type = 'PC_ONLINE'
    group by ev.ev_computer_id
  )
  select
    c.id,
    c.name,
    coalesce(round(o.span_online_seconds), 0)::bigint,
    greatest(0, round(window_seconds - coalesce(o.span_online_seconds, 0)))::bigint,
    round(least(100, greatest(0, coalesce(o.span_online_seconds, 0) / window_seconds * 100)), 1)
  from computers c
  left join online_spans o on o.span_computer_id = c.id
  where (p_lab_id is null or c.lab_id = p_lab_id)
  order by c.name;
end;
$$;

grant execute on function computer_utilization_report(timestamptz, timestamptz, uuid) to authenticated;
