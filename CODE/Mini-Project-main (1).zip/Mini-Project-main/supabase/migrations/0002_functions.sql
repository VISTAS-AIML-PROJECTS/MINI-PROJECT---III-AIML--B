-- Helper functions used by RLS policies and triggers.

create or replace function set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- Returns the role of the currently authenticated user (from profiles),
-- or null if there is no matching, active profile. security definer so it
-- can read profiles regardless of the caller's own row-level access.
create or replace function auth_role()
returns user_role
language sql
security definer
set search_path = public
stable
as $$
  select role from profiles where id = auth.uid() and is_active = true;
$$;

create or replace function is_admin()
returns boolean
language sql
security definer
set search_path = public
stable
as $$
  select coalesce(auth_role() = 'ADMIN', false);
$$;

-- Creates a profile row whenever a new Supabase Auth user is created.
-- Role defaults to VIEWER unless raw_user_meta_data->>'role' is 'ADMIN',
-- which only ever happens for accounts provisioned by the backend (using
-- the service role) — never from a client-facing sign-up flow.
create or replace function handle_new_auth_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into profiles (id, email, full_name, role)
  values (
    new.id,
    new.email,
    new.raw_user_meta_data ->> 'full_name',
    case
      when new.raw_user_meta_data ->> 'role' = 'ADMIN' then 'ADMIN'::user_role
      else 'VIEWER'::user_role
    end
  )
  on conflict (id) do nothing;
  return new;
end;
$$;
