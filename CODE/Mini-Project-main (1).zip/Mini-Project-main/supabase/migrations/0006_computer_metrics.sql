-- Latest heartbeat metrics, surfaced on the live dashboard/computer detail
-- page. Historical CPU/RAM trends are not required by the spec, so only
-- the most recent sample is retained (updated in place on every heartbeat).

alter table computers add column cpu_usage numeric(5, 2);
alter table computers add column memory_usage numeric(5, 2);
