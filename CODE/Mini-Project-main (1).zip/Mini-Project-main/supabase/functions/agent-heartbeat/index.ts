// Periodic PC Agent heartbeat. Updates online status + live metrics, and
// hands back any PENDING remote commands for this computer so the agent
// can execute them (marking them SENT here — the agent reports the final
// result via agent-command-result).
import { z } from "npm:zod@3.24.1";
import { createAdminClient } from "../_shared/supabase-admin.ts";
import { requireAgent } from "../_shared/agent-auth.ts";
import { jsonError, jsonSuccess, handleUnknownError } from "../_shared/response.ts";
import { handleCorsPreflight } from "../_shared/cors.ts";

const bodySchema = z.object({
  cpuUsage: z.number().min(0).max(100),
  memoryUsage: z.number().min(0).max(100),
  ipAddress: z.string().max(64).optional(),
  agentVersion: z.string().max(32).optional(),
});

Deno.serve(async (req) => {
  const preflight = handleCorsPreflight(req);
  if (preflight) return preflight;
  if (req.method !== "POST") return jsonError("NOT_FOUND", "Not found.", 404);

  try {
    const admin = createAdminClient();
    const agent = await requireAgent(req, admin);

    const parsed = bodySchema.safeParse(await req.json());
    if (!parsed.success) {
      return jsonError("VALIDATION_ERROR", "Invalid request body.", 422, parsed.error.flatten());
    }
    const { cpuUsage, memoryUsage, ipAddress, agentVersion } = parsed.data;

    const { data: existing } = await admin
      .from("computers")
      .select("status")
      .eq("id", agent.computerId)
      .maybeSingle();

    const wasOffline = !existing || existing.status !== "ONLINE";
    const now = new Date().toISOString();

    const update: Record<string, unknown> = {
      status: "ONLINE",
      last_seen_at: now,
      cpu_usage: cpuUsage,
      memory_usage: memoryUsage,
    };
    if (ipAddress) update.ip_address = ipAddress;
    if (agentVersion) update.agent_version = agentVersion;

    const { error: updateError } = await admin
      .from("computers")
      .update(update)
      .eq("id", agent.computerId);
    if (updateError) throw updateError;

    if (wasOffline) {
      await admin.from("activity_events").insert({
        computer_id: agent.computerId,
        event_type: "PC_ONLINE",
        occurred_at: now,
      });
    }

    const { data: pendingCommands } = await admin
      .from("remote_commands")
      .select("id, command_type")
      .eq("computer_id", agent.computerId)
      .eq("status", "PENDING");

    if (pendingCommands && pendingCommands.length > 0) {
      await admin
        .from("remote_commands")
        .update({ status: "SENT" })
        .in(
          "id",
          pendingCommands.map((c) => c.id),
        );
    }

    return jsonSuccess({
      heartbeatIntervalSeconds: 15,
      commands: (pendingCommands ?? []).map((c) => ({ commandId: c.id, commandType: c.command_type })),
    });
  } catch (error) {
    return handleUnknownError(error);
  }
});
