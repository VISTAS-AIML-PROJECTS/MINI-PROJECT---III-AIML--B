// Permanently deletes a VIEWER account. Requires the service role
// (auth.admin.deleteUser is not available to the anon key). ADMIN
// accounts can never be targeted here — this function only ever deletes
// accounts whose profile role is VIEWER, so it can't be used to remove
// the caller's own or any other admin account.
import { z } from "npm:zod@3.24.1";
import { createAdminClient } from "../_shared/supabase-admin.ts";
import { requireCaller } from "../_shared/auth.ts";
import { jsonError, jsonSuccess, handleUnknownError } from "../_shared/response.ts";
import { handleCorsPreflight } from "../_shared/cors.ts";

const bodySchema = z.object({ userId: z.string().uuid() });

Deno.serve(async (req) => {
  const preflight = handleCorsPreflight(req);
  if (preflight) return preflight;
  if (req.method !== "POST") return jsonError("NOT_FOUND", "Not found.", 404);

  try {
    const admin = createAdminClient();
    const caller = await requireCaller(req, admin, "ADMIN");

    const parsed = bodySchema.safeParse(await req.json());
    if (!parsed.success) {
      return jsonError("VALIDATION_ERROR", "Invalid request body.", 422, parsed.error.flatten());
    }
    const { userId } = parsed.data;

    const { data: target } = await admin
      .from("profiles")
      .select("id, role, email, full_name")
      .eq("id", userId)
      .maybeSingle();

    if (!target) return jsonError("NOT_FOUND", "User not found.", 404);
    if (target.role !== "VIEWER") {
      return jsonError("FORBIDDEN", "Only Viewer accounts can be deleted here.", 403);
    }

    const { error: deleteError } = await admin.auth.admin.deleteUser(userId);
    if (deleteError) throw deleteError;

    await admin.from("audit_logs").insert({
      admin_id: caller.id,
      action: "VIEWER_DELETED",
      metadata: { viewerId: userId, email: target.email, fullName: target.full_name },
    });

    return jsonSuccess({ id: userId });
  } catch (error) {
    return handleUnknownError(error);
  }
});
