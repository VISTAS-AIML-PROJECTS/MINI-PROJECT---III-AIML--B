// PC Agent reports the outcome of a remote command it executed. This is
// the only place remote_commands.status can move to SUCCEEDED/FAILED —
// clients (Admin app) can never write that themselves (see RLS policies),
// which keeps the audit trail trustworthy.
import { z } from "npm:zod@3.24.1";
import { createAdminClient } from "../_shared/supabase-admin.ts";
import { requireAgent } from "../_shared/agent-auth.ts";
import { jsonError, jsonSuccess, handleUnknownError } from "../_shared/response.ts";
import { handleCorsPreflight } from "../_shared/cors.ts";

const bodySchema = z.object({
  commandId: z.string().uuid(),
  status: z.enum(["SUCCEEDED", "FAILED"]),
  result: z.record(z.unknown()).optional(),
});

// These three command types end the OS session on the machine (or the
// machine itself) — the agent process dies or the network drops with it,
// so there is no further heartbeat to mark it OFFLINE on its own. Without
// this, a computer stays ONLINE until the offline-sweep cron happens to
// notice the stale heartbeat (or forever, if that cron was never
// scheduled). LOCK doesn't end anything, so it's excluded.
const OFFLINE_ON_SUCCESS = new Set(["SHUTDOWN", "RESTART", "LOGOUT"]);

Deno.serve(async (req) => {
  const preflight = handleCorsPreflight(req);
  if (preflight) return preflight;
  if (req.method !== "POST") return jsonError("NOT_FOUND", "Not found.", 404);

  try {
    const admin = createAdminClient();
    const agent = await requireAgent(req, admin);

    const parsed = bodySchema.safeParse(await req.json());
    if (!parsed.success) {
      return jsonError("VALIDATION_ERROR", "Invalid request body.", 422, parsed.error.flatten());
    }
    const { commandId, status, result } = parsed.data;

    const { data: command } = await admin
      .from("remote_commands")
      .select("id, computer_id, requested_by, command_type")
      .eq("id", commandId)
      .maybeSingle();

    if (!command || command.computer_id !== agent.computerId) {
      return jsonError("NOT_FOUND", "Command not found for this computer.", 404);
    }

    const now = new Date().toISOString();

    const { error: updateError } = await admin
      .from("remote_commands")
      .update({ status, executed_at: now, result: result ?? null })
      .eq("id", commandId);
    if (updateError) throw updateError;

    await admin.from("audit_logs").insert({
      admin_id: command.requested_by,
      action: `COMMAND_${command.command_type}_${status}`,
      computer_id: agent.computerId,
      metadata: { commandId, result: result ?? null },
    });

    if (status === "SUCCEEDED" && OFFLINE_ON_SUCCESS.has(command.command_type)) {
      await admin.from("computers").update({ status: "OFFLINE" }).eq("id", agent.computerId);

      await admin
        .from("activity_events")
        .insert({ computer_id: agent.computerId, event_type: "PC_OFFLINE", occurred_at: now });

      const { data: activeSession } = await admin
        .from("sessions")
        .select("id")
        .eq("computer_id", agent.computerId)
        .eq("is_active", true)
        .maybeSingle();
      if (activeSession) {
        await admin
          .from("sessions")
          .update({ ended_at: now, is_active: false })
          .eq("id", activeSession.id);
      }

      const { data: openActivity } = await admin
        .from("application_activity")
        .select("id, started_at")
        .eq("computer_id", agent.computerId)
        .is("ended_at", null)
        .maybeSingle();
      if (openActivity) {
        const durationSeconds = Math.max(
          0,
          Math.round((new Date(now).getTime() - new Date(openActivity.started_at).getTime()) / 1000),
        );
        await admin
          .from("application_activity")
          .update({ ended_at: now, duration_seconds: durationSeconds })
          .eq("id", openActivity.id);
      }
    }

    return jsonSuccess({ commandId, status });
  } catch (error) {
    return handleUnknownError(error);
  }
});
