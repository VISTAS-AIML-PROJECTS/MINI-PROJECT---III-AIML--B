import type { SupabaseClient } from "npm:@supabase/supabase-js@2.47.10";

export interface CallerProfile {
  id: string;
  email: string;
  role: "ADMIN" | "VIEWER";
  isActive: boolean;
}

export class AuthError extends Error {
  constructor(
    message: string,
    public readonly status: number,
  ) {
    super(message);
  }
}

function extractBearerToken(req: Request): string {
  const header = req.headers.get("Authorization") ?? req.headers.get("authorization");
  if (!header?.startsWith("Bearer ")) {
    throw new AuthError("Missing bearer token.", 401);
  }
  return header.slice("Bearer ".length).trim();
}

// Verifies the caller's Supabase Auth JWT and loads their profile. Throws
// AuthError(401) if the token is invalid, or AuthError(403) if a
// requiredRole is given and the caller doesn't have it / is disabled.
export async function requireCaller(
  req: Request,
  admin: SupabaseClient,
  requiredRole?: "ADMIN" | "VIEWER",
): Promise<CallerProfile> {
  const token = extractBearerToken(req);

  const { data: userResult, error: userError } = await admin.auth.getUser(token);
  if (userError || !userResult?.user) {
    throw new AuthError("Invalid or expired token.", 401);
  }

  const { data: profile, error: profileError } = await admin
    .from("profiles")
    .select("id, email, role, is_active")
    .eq("id", userResult.user.id)
    .maybeSingle();

  if (profileError || !profile) {
    throw new AuthError("No profile found for this account.", 401);
  }
  if (!profile.is_active) {
    throw new AuthError("This account has been disabled.", 403);
  }
  if (requiredRole && profile.role !== requiredRole) {
    throw new AuthError("You do not have permission to perform this action.", 403);
  }

  return { id: profile.id, email: profile.email, role: profile.role, isActive: profile.is_active };
}
