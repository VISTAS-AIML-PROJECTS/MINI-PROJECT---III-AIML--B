import { corsHeaders } from "./cors.ts";
import { AuthError } from "./auth.ts";

export function jsonSuccess(data: unknown, status = 200): Response {
  return new Response(JSON.stringify({ success: true, data }), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

export function jsonError(code: string, message: string, status: number, details?: unknown): Response {
  return new Response(
    JSON.stringify({ success: false, error: { code, message, ...(details ? { details } : {}) } }),
    { status, headers: { ...corsHeaders, "Content-Type": "application/json" } },
  );
}

export function handleUnknownError(error: unknown): Response {
  if (error instanceof AuthError) {
    return jsonError(error.status === 401 ? "UNAUTHORIZED" : "FORBIDDEN", error.message, error.status);
  }
  console.error("Unhandled edge function error:", error);
  return jsonError("INTERNAL_ERROR", "An unexpected error occurred.", 500);
}
