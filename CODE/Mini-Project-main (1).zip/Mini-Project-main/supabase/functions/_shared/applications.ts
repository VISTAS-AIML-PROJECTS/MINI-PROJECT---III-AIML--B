import type { SupabaseClient } from "npm:@supabase/supabase-js@2.47.10";

export async function findOrCreateApplication(
  admin: SupabaseClient,
  name: string,
  executableName?: string,
): Promise<string> {
  if (executableName) {
    const { data: existing } = await admin
      .from("applications")
      .select("id")
      .eq("executable_name", executableName)
      .maybeSingle();
    if (existing) return existing.id;
  } else {
    const { data: existing } = await admin
      .from("applications")
      .select("id")
      .eq("name", name)
      .is("executable_name", null)
      .maybeSingle();
    if (existing) return existing.id;
  }

  const { data: created, error } = await admin
    .from("applications")
    .insert({ name, executable_name: executableName ?? null })
    .select("id")
    .single();

  if (error) {
    // Unique-constraint race: another concurrent event created the same
    // executable in between our SELECT and INSERT — re-select it.
    if (executableName) {
      const { data: retry } = await admin
        .from("applications")
        .select("id")
        .eq("executable_name", executableName)
        .maybeSingle();
      if (retry) return retry.id;
    }
    throw error;
  }

  return created.id;
}
