import { createClient, type SupabaseClient } from "npm:@supabase/supabase-js@2.47.10";

// SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are reserved secrets that
// Supabase injects into every Edge Function automatically — they do not
// need to be set manually via `supabase secrets set`. This client
// bypasses Row Level Security, so it must never be exposed to a caller
// that hasn't been authenticated/authorized within the function body.
export function createAdminClient(): SupabaseClient {
  const url = Deno.env.get("SUPABASE_URL");
  const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

  if (!url || !serviceRoleKey) {
    throw new Error("SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY are not configured.");
  }

  return createClient(url, serviceRoleKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });
}
