import type { SupabaseClient } from "npm:@supabase/supabase-js@2.47.10";
import { verifySecret } from "./hash.ts";
import { AuthError } from "./auth.ts";

export interface AuthenticatedAgent {
  computerId: string;
  computerCode: string;
}

// The agent token has the form "<computerId>.<rawSecret>". The computerId
// prefix lets us look up the one active credential row for that computer
// without a full-table scan; the actual authentication is the bcrypt
// comparison against credential_hash below.
export async function requireAgent(req: Request, admin: SupabaseClient): Promise<AuthenticatedAgent> {
  const token = req.headers.get("x-agent-token") ?? req.headers.get("X-Agent-Token");
  if (!token || !token.includes(".")) {
    throw new AuthError("Missing or malformed agent token.", 401);
  }

  const separatorIndex = token.indexOf(".");
  const computerId = token.slice(0, separatorIndex);
  const rawSecret = token.slice(separatorIndex + 1);

  const { data: credential } = await admin
    .from("computer_credentials")
    .select("id, credential_hash, revoked_at")
    .eq("computer_id", computerId)
    .is("revoked_at", null)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (!credential) throw new AuthError("Invalid or revoked agent credential.", 401);

  const isValid = await verifySecret(rawSecret, credential.credential_hash);
  if (!isValid) throw new AuthError("Invalid or revoked agent credential.", 401);

  const { data: computer } = await admin
    .from("computers")
    .select("id, computer_code, is_enabled")
    .eq("id", computerId)
    .maybeSingle();

  if (!computer) throw new AuthError("Computer not found.", 401);
  if (!computer.is_enabled) throw new AuthError("This computer has been disabled by an administrator.", 403);

  return { computerId: computer.id, computerCode: computer.computer_code };
}
