import bcrypt from "npm:bcryptjs@2.4.3";

export async function hashSecret(rawValue: string): Promise<string> {
  const salt = await bcrypt.genSalt(10);
  return bcrypt.hash(rawValue, salt);
}

export async function verifySecret(rawValue: string, hash: string): Promise<boolean> {
  return bcrypt.compare(rawValue, hash);
}

export function generateRawSecret(byteLength = 32): string {
  const bytes = new Uint8Array(byteLength);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}
