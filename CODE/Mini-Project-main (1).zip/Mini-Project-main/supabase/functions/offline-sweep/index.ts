// Marks computers OFFLINE once their heartbeat has expired. Intended to be
// invoked on a schedule (pg_cron + pg_net, or an external scheduler) —
// never by the desktop apps. Guarded by a shared secret so it can't be
// triggered by an arbitrary caller. See docs/deployment.md for the pg_cron
// snippet that wires this up.
import { createAdminClient } from "../_shared/supabase-admin.ts";
import { jsonError, jsonSuccess, handleUnknownError } from "../_shared/response.ts";
import { handleCorsPreflight } from "../_shared/cors.ts";

const DEFAULT_OFFLINE_THRESHOLD_SECONDS = 45;

Deno.serve(async (req) => {
  const preflight = handleCorsPreflight(req);
  if (preflight) return preflight;
  if (req.method !== "POST") return jsonError("NOT_FOUND", "Not found.", 404);

  try {
    const cronSecret = Deno.env.get("CRON_SECRET");
    const providedSecret = req.headers.get("x-cron-secret");
    if (!cronSecret || providedSecret !== cronSecret) {
      return jsonError("UNAUTHORIZED", "Invalid cron secret.", 401);
    }

    const admin = createAdminClient();

    const { data: setting } = await admin
      .from("system_settings")
      .select("value")
      .eq("key", "monitoring")
      .maybeSingle();

    const thresholdSeconds =
      (setting?.value as { offlineThresholdSeconds?: number } | null)?.offlineThresholdSeconds ??
      DEFAULT_OFFLINE_THRESHOLD_SECONDS;

    const cutoff = new Date(Date.now() - thresholdSeconds * 1000).toISOString();
    const now = new Date().toISOString();

    const { data: staleComputers } = await admin
      .from("computers")
      .select("id")
      .eq("status", "ONLINE")
      .lt("last_seen_at", cutoff);

    if (!staleComputers || staleComputers.length === 0) {
      return jsonSuccess({ markedOffline: 0 });
    }

    const staleIds = staleComputers.map((c) => c.id);

    await admin.from("computers").update({ status: "OFFLINE" }).in("id", staleIds);

    await admin.from("activity_events").insert(
      staleIds.map((computerId) => ({
        computer_id: computerId,
        event_type: "PC_OFFLINE",
        occurred_at: now,
      })),
    );

    const { data: staleSessions } = await admin
      .from("sessions")
      .select("id")
      .in("computer_id", staleIds)
      .eq("is_active", true);

    if (staleSessions && staleSessions.length > 0) {
      await admin
        .from("sessions")
        .update({ ended_at: now, is_active: false })
        .in(
          "id",
          staleSessions.map((s) => s.id),
        );
    }

    const { data: openActivity } = await admin
      .from("application_activity")
      .select("id, started_at")
      .in("computer_id", staleIds)
      .is("ended_at", null);

    for (const activity of openActivity ?? []) {
      const durationSeconds = Math.max(
        0,
        Math.round((Date.now() - new Date(activity.started_at).getTime()) / 1000),
      );
      await admin
        .from("application_activity")
        .update({ ended_at: now, duration_seconds: durationSeconds })
        .eq("id", activity.id);
    }

    return jsonSuccess({ markedOffline: staleIds.length });
  } catch (error) {
    return handleUnknownError(error);
  }
});
