// Creates a new VIEWER auth account. Must run with the service role key
// (auth.admin.createUser is not available to the anon key), so this is an
// Edge Function rather than a direct client insert. Caller must be an
// active ADMIN.
import { z } from "npm:zod@3.24.1";
import { createAdminClient } from "../_shared/supabase-admin.ts";
import { requireCaller } from "../_shared/auth.ts";
import { jsonError, jsonSuccess, handleUnknownError } from "../_shared/response.ts";
import { handleCorsPreflight } from "../_shared/cors.ts";

const bodySchema = z.object({
  email: z.string().email(),
  fullName: z.string().min(1).max(120),
  password: z.string().min(8).max(200),
});

Deno.serve(async (req) => {
  const preflight = handleCorsPreflight(req);
  if (preflight) return preflight;
  if (req.method !== "POST") return jsonError("NOT_FOUND", "Not found.", 404);

  try {
    const admin = createAdminClient();
    const caller = await requireCaller(req, admin, "ADMIN");

    const parsed = bodySchema.safeParse(await req.json());
    if (!parsed.success) {
      return jsonError("VALIDATION_ERROR", "Invalid request body.", 422, parsed.error.flatten());
    }
    const { email, fullName, password } = parsed.data;

    const { data: created, error } = await admin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { full_name: fullName, role: "VIEWER" },
    });

    if (error || !created?.user) {
      if (error?.message?.toLowerCase().includes("already")) {
        return jsonError("CONFLICT", "A user with this email already exists.", 409);
      }
      throw error ?? new Error("Failed to create user.");
    }

    await admin.from("audit_logs").insert({
      admin_id: caller.id,
      action: "VIEWER_CREATED",
      computer_id: null,
      metadata: { email, fullName, viewerId: created.user.id },
    });

    return jsonSuccess({ id: created.user.id, email, fullName, role: "VIEWER" }, 201);
  } catch (error) {
    return handleUnknownError(error);
  }
});
