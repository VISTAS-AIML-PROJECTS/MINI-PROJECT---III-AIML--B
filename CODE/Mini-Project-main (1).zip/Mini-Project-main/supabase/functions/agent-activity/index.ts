// Ingests a batch of activity events from a PC Agent: OS session
// lifecycle, application open/switch/close. Builds the application_activity
// duration timeline and the raw activity_events stream used by the
// Activity page / application-switching timeline.
import { z } from "npm:zod@3.24.1";
import type { SupabaseClient } from "npm:@supabase/supabase-js@2.47.10";
import { createAdminClient } from "../_shared/supabase-admin.ts";
import { requireAgent } from "../_shared/agent-auth.ts";
import { findOrCreateApplication } from "../_shared/applications.ts";
import { jsonError, jsonSuccess, handleUnknownError } from "../_shared/response.ts";
import { handleCorsPreflight } from "../_shared/cors.ts";

const eventSchema = z.object({
  eventType: z.enum([
    "APP_OPEN",
    "APP_CLOSE",
    "APP_SWITCH",
    "SESSION_START",
    "SESSION_END",
    "PC_ONLINE",
    "PC_OFFLINE",
  ]),
  applicationName: z.string().max(255).optional(),
  executableName: z.string().max(255).optional(),
  windowTitle: z.string().max(500).optional(),
  previousApplicationName: z.string().max(255).optional(),
  username: z.string().max(255).optional(),
  metadata: z.record(z.unknown()).optional(),
  occurredAt: z.string().datetime(),
});

const bodySchema = z.object({ events: z.array(eventSchema).min(1).max(200) });
type ActivityEventInput = z.infer<typeof eventSchema>;

async function getActiveSessionId(admin: SupabaseClient, computerId: string): Promise<string | null> {
  const { data } = await admin
    .from("sessions")
    .select("id")
    .eq("computer_id", computerId)
    .eq("is_active", true)
    .order("started_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  return data?.id ?? null;
}

async function closeOpenApplicationActivity(
  admin: SupabaseClient,
  computerId: string,
  endedAt: string,
): Promise<void> {
  const { data: open } = await admin
    .from("application_activity")
    .select("id, started_at")
    .eq("computer_id", computerId)
    .is("ended_at", null)
    .order("started_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (!open) return;

  const durationSeconds = Math.max(
    0,
    Math.round((new Date(endedAt).getTime() - new Date(open.started_at).getTime()) / 1000),
  );

  await admin
    .from("application_activity")
    .update({ ended_at: endedAt, duration_seconds: durationSeconds })
    .eq("id", open.id);
}

async function processEvent(admin: SupabaseClient, computerId: string, event: ActivityEventInput) {
  const sessionId = await getActiveSessionId(admin, computerId);

  switch (event.eventType) {
    case "SESSION_START": {
      await admin.from("sessions").insert({
        computer_id: computerId,
        username: event.username ?? "unknown",
        started_at: event.occurredAt,
        is_active: true,
      });
      break;
    }
    case "SESSION_END": {
      if (sessionId) {
        await admin
          .from("sessions")
          .update({ ended_at: event.occurredAt, is_active: false })
          .eq("id", sessionId);
      }
      await closeOpenApplicationActivity(admin, computerId, event.occurredAt);
      break;
    }
    case "APP_OPEN":
    case "APP_SWITCH": {
      await closeOpenApplicationActivity(admin, computerId, event.occurredAt);
      if (event.applicationName) {
        const applicationId = await findOrCreateApplication(
          admin,
          event.applicationName,
          event.executableName,
        );
        await admin.from("application_activity").insert({
          computer_id: computerId,
          session_id: sessionId,
          application_id: applicationId,
          window_title: event.windowTitle ?? null,
          started_at: event.occurredAt,
          ended_at: null,
        });
      }
      break;
    }
    case "APP_CLOSE": {
      await closeOpenApplicationActivity(admin, computerId, event.occurredAt);
      break;
    }
    case "PC_ONLINE":
    case "PC_OFFLINE":
      // Derived from heartbeat/offline-sweep instead; ignore if an agent
      // ever sends these directly.
      break;
  }

  await admin.from("activity_events").insert({
    computer_id: computerId,
    session_id: sessionId,
    event_type: event.eventType,
    application_name: event.applicationName ?? null,
    window_title: event.windowTitle ?? null,
    metadata: {
      ...(event.metadata ?? {}),
      ...(event.previousApplicationName
        ? { previousApplicationName: event.previousApplicationName }
        : {}),
    },
    occurred_at: event.occurredAt,
  });
}

Deno.serve(async (req) => {
  const preflight = handleCorsPreflight(req);
  if (preflight) return preflight;
  if (req.method !== "POST") return jsonError("NOT_FOUND", "Not found.", 404);

  try {
    const admin = createAdminClient();
    const agent = await requireAgent(req, admin);

    const parsed = bodySchema.safeParse(await req.json());
    if (!parsed.success) {
      return jsonError("VALIDATION_ERROR", "Invalid request body.", 422, parsed.error.flatten());
    }

    const events = [...parsed.data.events].sort(
      (a, b) => new Date(a.occurredAt).getTime() - new Date(b.occurredAt).getTime(),
    );

    for (const event of events) {
      await processEvent(admin, agent.computerId, event);
    }

    return jsonSuccess({ processed: events.length });
  } catch (error) {
    return handleUnknownError(error);
  }
});
