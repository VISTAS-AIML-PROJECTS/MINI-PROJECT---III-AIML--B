// Accepts one periodic screenshot from a PC Agent and stores it as the
// single most-recent capture for that computer (overwritten each time —
// no history is kept). Admin-only to read, via a short-lived signed URL
// the Admin app requests directly from Supabase Storage; Viewers never
// have access, regardless of lab assignment.
import { z } from "npm:zod@3.24.1";
import { createAdminClient } from "../_shared/supabase-admin.ts";
import { requireAgent } from "../_shared/agent-auth.ts";
import { jsonError, jsonSuccess, handleUnknownError } from "../_shared/response.ts";
import { handleCorsPreflight } from "../_shared/cors.ts";

const MAX_BASE64_BYTES = 3_000_000; // ~2.2MB decoded, generous for a compressed JPEG snapshot

const bodySchema = z.object({
  imageBase64: z.string().min(1).max(MAX_BASE64_BYTES),
});

Deno.serve(async (req) => {
  const preflight = handleCorsPreflight(req);
  if (preflight) return preflight;
  if (req.method !== "POST") return jsonError("NOT_FOUND", "Not found.", 404);

  try {
    const admin = createAdminClient();
    const agent = await requireAgent(req, admin);

    const parsed = bodySchema.safeParse(await req.json());
    if (!parsed.success) {
      return jsonError("VALIDATION_ERROR", "Invalid request body.", 422, parsed.error.flatten());
    }

    const bytes = Uint8Array.from(atob(parsed.data.imageBase64), (c) => c.charCodeAt(0));
    const path = `${agent.computerId}/latest.jpg`;

    const { error: uploadError } = await admin.storage
      .from("screenshots")
      .upload(path, bytes, { contentType: "image/jpeg", upsert: true });
    if (uploadError) throw uploadError;

    const now = new Date().toISOString();
    await admin.from("computers").update({ last_screenshot_at: now }).eq("id", agent.computerId);

    return jsonSuccess({ capturedAt: now });
  } catch (error) {
    return handleUnknownError(error);
  }
});
