// Edits a VIEWER account's name and/or email. Email changes must go
// through the Supabase Auth admin API (not just the profiles table) so
// auth.users and profiles never drift apart — that requires the service
// role, hence this being an Edge Function rather than a direct client
// update. ADMIN accounts can never be targeted here.
import { z } from "npm:zod@3.24.1";
import { createAdminClient } from "../_shared/supabase-admin.ts";
import { requireCaller } from "../_shared/auth.ts";
import { jsonError, jsonSuccess, handleUnknownError } from "../_shared/response.ts";
import { handleCorsPreflight } from "../_shared/cors.ts";

const bodySchema = z.object({
  userId: z.string().uuid(),
  fullName: z.string().min(1).max(120).optional(),
  email: z.string().email().optional(),
  password: z.string().min(8).max(200).optional(),
});

Deno.serve(async (req) => {
  const preflight = handleCorsPreflight(req);
  if (preflight) return preflight;
  if (req.method !== "POST") return jsonError("NOT_FOUND", "Not found.", 404);

  try {
    const admin = createAdminClient();
    const caller = await requireCaller(req, admin, "ADMIN");

    const parsed = bodySchema.safeParse(await req.json());
    if (!parsed.success) {
      return jsonError("VALIDATION_ERROR", "Invalid request body.", 422, parsed.error.flatten());
    }
    const { userId, fullName, email, password } = parsed.data;

    if (!fullName && !email && !password) {
      return jsonError("VALIDATION_ERROR", "Nothing to update.", 422);
    }

    const { data: target } = await admin
      .from("profiles")
      .select("id, role, email, full_name, is_active")
      .eq("id", userId)
      .maybeSingle();

    if (!target) return jsonError("NOT_FOUND", "User not found.", 404);
    if (target.role !== "VIEWER") {
      return jsonError("FORBIDDEN", "Only Viewer accounts can be edited here.", 403);
    }

    if ((email && email !== target.email) || password) {
      const authUpdate: Record<string, unknown> = {};
      if (email && email !== target.email) {
        authUpdate.email = email;
        authUpdate.email_confirm = true;
      }
      if (password) authUpdate.password = password;

      const { error: authError } = await admin.auth.admin.updateUserById(userId, authUpdate);
      if (authError) {
        if (authError.message.toLowerCase().includes("already")) {
          return jsonError("CONFLICT", "A user with this email already exists.", 409);
        }
        throw authError;
      }
    }

    const patch: Record<string, unknown> = {};
    if (fullName) patch.full_name = fullName;
    if (email) patch.email = email;

    // profiles is only touched when full_name/email actually changed — an
    // empty .update({}) call is rejected by PostgREST, which matters here
    // because a password-only reset has nothing to change in this table.
    let updated = target;
    if (Object.keys(patch).length > 0) {
      const { data, error: updateError } = await admin
        .from("profiles")
        .update(patch)
        .eq("id", userId)
        .select()
        .single();
      if (updateError) throw updateError;
      updated = data;
    }

    await admin.from("audit_logs").insert({
      admin_id: caller.id,
      action: "VIEWER_UPDATED",
      metadata: { viewerId: userId, changes: patch, passwordReset: Boolean(password) },
    });

    return jsonSuccess({
      id: updated.id,
      email: updated.email,
      fullName: updated.full_name,
      role: updated.role,
      isActive: updated.is_active,
    });
  } catch (error) {
    return handleUnknownError(error);
  }
});
