// Consumes a one-time registration code (issued by an Admin from the
// Admin Desktop app) and issues a long-lived agent credential. Public
// endpoint — the registration code itself is the secret, and it can only
// be used once before/after its expiry window.
import { z } from "npm:zod@3.24.1";
import { createAdminClient } from "../_shared/supabase-admin.ts";
import { hashSecret, verifySecret, generateRawSecret } from "../_shared/hash.ts";
import { jsonError, jsonSuccess, handleUnknownError } from "../_shared/response.ts";
import { handleCorsPreflight } from "../_shared/cors.ts";

const bodySchema = z.object({
  registrationCode: z.string().min(10).max(200),
  hostname: z.string().min(1).max(255),
  operatingSystem: z.string().min(1).max(255),
  agentVersion: z.string().min(1).max(32),
});

Deno.serve(async (req) => {
  const preflight = handleCorsPreflight(req);
  if (preflight) return preflight;
  if (req.method !== "POST") return jsonError("NOT_FOUND", "Not found.", 404);

  try {
    const parsed = bodySchema.safeParse(await req.json());
    if (!parsed.success) {
      return jsonError("VALIDATION_ERROR", "Invalid request body.", 422, parsed.error.flatten());
    }
    const { registrationCode, hostname, operatingSystem, agentVersion } = parsed.data;

    const separatorIndex = registrationCode.indexOf(".");
    if (separatorIndex < 0) {
      return jsonError("VALIDATION_ERROR", "Malformed registration code.", 422);
    }
    const codeId = registrationCode.slice(0, separatorIndex);
    const rawCode = registrationCode.slice(separatorIndex + 1);

    const admin = createAdminClient();

    const { data: codeRow } = await admin
      .from("computer_registration_codes")
      .select("id, computer_id, code_hash, issued_by, expires_at, consumed_at")
      .eq("id", codeId)
      .maybeSingle();

    if (!codeRow) return jsonError("UNAUTHORIZED", "Invalid registration code.", 401);
    if (codeRow.consumed_at) return jsonError("UNAUTHORIZED", "Registration code already used.", 401);
    if (new Date(codeRow.expires_at).getTime() < Date.now()) {
      return jsonError("UNAUTHORIZED", "Registration code has expired.", 401);
    }

    const codeValid = await verifySecret(rawCode, codeRow.code_hash);
    if (!codeValid) return jsonError("UNAUTHORIZED", "Invalid registration code.", 401);

    const { data: computer } = await admin
      .from("computers")
      .select("id, computer_code, is_enabled")
      .eq("id", codeRow.computer_id)
      .maybeSingle();

    if (!computer) return jsonError("NOT_FOUND", "Computer record not found.", 404);
    if (!computer.is_enabled) {
      return jsonError("FORBIDDEN", "This computer has been disabled by an administrator.", 403);
    }

    const rawAgentSecret = generateRawSecret();
    const credentialHash = await hashSecret(rawAgentSecret);

    const { error: credentialError } = await admin.from("computer_credentials").insert({
      computer_id: computer.id,
      credential_hash: credentialHash,
    });
    if (credentialError) throw credentialError;

    await admin
      .from("computer_registration_codes")
      .update({ consumed_at: new Date().toISOString() })
      .eq("id", codeRow.id);

    await admin
      .from("computers")
      .update({
        hostname,
        operating_system: operatingSystem,
        agent_version: agentVersion,
        registered_at: new Date().toISOString(),
      })
      .eq("id", computer.id);

    await admin.from("audit_logs").insert({
      admin_id: codeRow.issued_by,
      action: "AGENT_REGISTERED",
      computer_id: computer.id,
      metadata: { hostname, operatingSystem, agentVersion },
    });

    return jsonSuccess(
      {
        computerId: computer.id,
        computerCode: computer.computer_code,
        agentToken: `${computer.id}.${rawAgentSecret}`,
      },
      201,
    );
  } catch (error) {
    return handleUnknownError(error);
  }
});
