import { app, dialog, ipcMain, type BrowserWindow } from "electron";
import { autoUpdater } from "electron-updater";

export type UpdaterState =
  | { status: "idle" }
  | { status: "checking" }
  | { status: "available"; version: string }
  | { status: "not-available" }
  | { status: "downloading"; percent: number }
  | { status: "downloaded"; version: string }
  | { status: "error"; message: string };

let currentState: UpdaterState = { status: "idle" };
let windowRef: BrowserWindow | null = null;

function setState(state: UpdaterState): void {
  currentState = state;
  windowRef?.webContents.send("updater:state-changed", state);
}

// Checks GitHub Releases (the same repo electron-builder publishes to,
// per electron-builder.yml `publish` config) for a newer version,
// downloads it in the background, and asks the user to restart once
// it's ready. Also exposes a manual "Check for updates" IPC action and
// broadcasts every state transition to the renderer so the UI can show
// real feedback instead of failing silently.
export function initAutoUpdater(mainWindow: BrowserWindow): void {
  windowRef = mainWindow;

  ipcMain.handle("updater:getState", () => currentState);
  ipcMain.handle("updater:check", () => {
    if (!app.isPackaged) {
      setState({ status: "error", message: "Updates only run in an installed build, not in development." });
      return;
    }
    void autoUpdater.checkForUpdates();
  });

  if (!app.isPackaged) return;

  autoUpdater.autoDownload = true;
  autoUpdater.autoInstallOnAppQuit = true;

  autoUpdater.on("checking-for-update", () => setState({ status: "checking" }));
  autoUpdater.on("update-available", (info) => setState({ status: "available", version: info.version }));
  autoUpdater.on("update-not-available", () => setState({ status: "not-available" }));
  autoUpdater.on("download-progress", (progress) =>
    setState({ status: "downloading", percent: Math.round(progress.percent) }),
  );

  autoUpdater.on("update-downloaded", (info) => {
    setState({ status: "downloaded", version: info.version });
    void dialog
      .showMessageBox({
        type: "info",
        title: "Update ready",
        message: `College PC Viewer ${info.version} has been downloaded.`,
        detail: "Restart now to install it, or it will install automatically the next time you quit.",
        buttons: ["Restart now", "Later"],
        defaultId: 0,
      })
      .then(({ response }) => {
        if (response === 0) autoUpdater.quitAndInstall();
      });
  });

  autoUpdater.on("error", (error) => {
    console.warn("[updater] Update check failed:", error);
    setState({ status: "error", message: error.message });
  });

  void autoUpdater.checkForUpdates();
}
