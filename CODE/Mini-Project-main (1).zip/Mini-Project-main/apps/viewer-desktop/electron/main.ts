import { app, BrowserWindow, shell, ipcMain, systemPreferences } from "electron";
import path from "node:path";
import { AgentController } from "./agent/controller";
import { initAutoUpdater } from "./updater";

const VITE_DEV_SERVER_URL = process.env.VITE_DEV_SERVER_URL;

let mainWindow: BrowserWindow | null = null;
let agentQuitReady = false;

// The agent identity (this machine's own registration/monitoring) is
// independent of whichever human is logged in as a Viewer in the
// renderer — it starts as soon as the app launches and keeps running
// regardless of the dashboard's auth state.
const agentController = new AgentController((state) => {
  mainWindow?.webContents.send("agent:state-changed", state);
});

function createWindow(): void {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1024,
    minHeight: 700,
    show: false,
    autoHideMenuBar: true,
    title: "College PC Viewer",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });

  mainWindow.once("ready-to-show", () => mainWindow?.show());

  // Never let the renderer navigate to or open arbitrary external
  // destinations inside the app window.
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith("https://")) void shell.openExternal(url);
    return { action: "deny" };
  });
  mainWindow.webContents.on("will-navigate", (event, url) => {
    if (VITE_DEV_SERVER_URL && url.startsWith(VITE_DEV_SERVER_URL)) return;
    if (url.startsWith("file://")) return;
    event.preventDefault();
  });

  if (VITE_DEV_SERVER_URL) {
    void mainWindow.loadURL(VITE_DEV_SERVER_URL);
    mainWindow.webContents.openDevTools({ mode: "detach" });
  } else {
    void mainWindow.loadFile(path.join(__dirname, "../dist/index.html"));
  }
}

ipcMain.handle("app:getVersion", () => app.getVersion());
ipcMain.handle("app:getPlatform", () => process.platform);
ipcMain.handle("window:minimize", () => mainWindow?.minimize());
ipcMain.handle("window:toggleMaximize", () => {
  if (!mainWindow) return;
  if (mainWindow.isMaximized()) mainWindow.unmaximize();
  else mainWindow.maximize();
});
ipcMain.handle("window:close", () => mainWindow?.close());
ipcMain.handle("window:isMaximized", () => mainWindow?.isMaximized() ?? false);
ipcMain.handle("shell:openExternal", (_event, url: string) => {
  if (typeof url === "string" && url.startsWith("https://")) {
    void shell.openExternal(url);
  }
});

ipcMain.handle("agent:getState", () => agentController.getState());
ipcMain.handle("agent:register", (_event, code: string) => agentController.register(code));
ipcMain.handle("agent:reset", () => agentController.reset());

// Screen Recording is a macOS-only concept: getMediaAccessStatus / the
// System Settings deep link are no-ops elsewhere, and Electron reports
// "granted" unconditionally on platforms without this permission model
// (Windows, Linux) — so the onboarding step in the renderer naturally
// skips itself there.
ipcMain.handle("permissions:getScreenAccessStatus", () => {
  if (process.platform !== "darwin") return "granted";
  return systemPreferences.getMediaAccessStatus("screen");
});
ipcMain.handle("permissions:openScreenSettings", () => {
  if (process.platform === "darwin") {
    void shell.openExternal("x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture");
  }
});

app.whenReady().then(() => {
  createWindow();
  agentController.start();
  if (mainWindow) initAutoUpdater(mainWindow);
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

app.on("activate", () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});

app.on("before-quit", (event) => {
  if (!agentQuitReady) {
    event.preventDefault();
    void agentController.stop().finally(() => {
      agentQuitReady = true;
      app.quit();
    });
  }
});
