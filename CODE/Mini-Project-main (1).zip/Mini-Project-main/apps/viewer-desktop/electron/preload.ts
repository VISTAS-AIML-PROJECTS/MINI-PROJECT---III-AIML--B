import { contextBridge, ipcRenderer } from "electron";

// Duplicated (not imported) from electron/agent/controller.ts on purpose:
// pulling that module in here would drag its whole implementation import
// graph (system-monitor, application-monitor, etc.) into the renderer's
// tsconfig "rootDir": "./src" program, which rejects any file outside
// src/ — even for a type-only import chain.
export type AgentStatus = "unregistered" | "connecting" | "online" | "offline" | "error";
export interface AgentState {
  status: AgentStatus;
  computerCode: string | null;
  computerId: string | null;
  lastHeartbeatAt: string | null;
  lastError: string | null;
  lastActivityError: string | null;
  lastScreenshotAt: string | null;
  lastScreenshotError: string | null;
}

// Duplicated (not imported) from electron/updater.ts for the same reason
// as AgentState above — keeps the renderer's tsconfig rootDir happy.
export type UpdaterState =
  | { status: "idle" }
  | { status: "checking" }
  | { status: "available"; version: string }
  | { status: "not-available" }
  | { status: "downloading"; percent: number }
  | { status: "downloaded"; version: string }
  | { status: "error"; message: string };

// Minimal, explicit bridge. The renderer has no direct Node.js or Electron
// API access (contextIsolation + sandbox + nodeIntegration:false) — it can
// only call the specific functions exposed here. All application data
// access (Supabase Auth/Postgres/Realtime) happens in the renderer via
// fetch/WebSocket, which sandboxed renderers can do natively — no IPC
// round-trip needed for that. The agent (this machine's own monitoring
// identity) is a separate concern from the logged-in Viewer user, wired
// up through its own small set of IPC calls below.
const bridge = {
  getVersion: (): Promise<string> => ipcRenderer.invoke("app:getVersion"),
  getPlatform: (): Promise<NodeJS.Platform> => ipcRenderer.invoke("app:getPlatform"),
  window: {
    minimize: (): Promise<void> => ipcRenderer.invoke("window:minimize"),
    toggleMaximize: (): Promise<void> => ipcRenderer.invoke("window:toggleMaximize"),
    close: (): Promise<void> => ipcRenderer.invoke("window:close"),
    isMaximized: (): Promise<boolean> => ipcRenderer.invoke("window:isMaximized"),
  },
  openExternal: (url: string): Promise<void> => ipcRenderer.invoke("shell:openExternal", url),
  agent: {
    getState: (): Promise<AgentState> => ipcRenderer.invoke("agent:getState"),
    register: (code: string): Promise<{ ok: true } | { ok: false; error: string }> =>
      ipcRenderer.invoke("agent:register", code),
    reset: (): Promise<void> => ipcRenderer.invoke("agent:reset"),
    onStateChange: (callback: (state: AgentState) => void): (() => void) => {
      const listener = (_event: Electron.IpcRendererEvent, state: AgentState) => callback(state);
      ipcRenderer.on("agent:state-changed", listener);
      return () => ipcRenderer.removeListener("agent:state-changed", listener);
    },
  },
  permissions: {
    getScreenAccessStatus: (): Promise<"not-determined" | "granted" | "denied" | "restricted" | "unknown"> =>
      ipcRenderer.invoke("permissions:getScreenAccessStatus"),
    openScreenSettings: (): Promise<void> => ipcRenderer.invoke("permissions:openScreenSettings"),
  },
  updater: {
    check: (): Promise<void> => ipcRenderer.invoke("updater:check"),
    getState: (): Promise<UpdaterState> => ipcRenderer.invoke("updater:getState"),
    onStateChange: (callback: (state: UpdaterState) => void): (() => void) => {
      const listener = (_event: Electron.IpcRendererEvent, state: UpdaterState) => callback(state);
      ipcRenderer.on("updater:state-changed", listener);
      return () => ipcRenderer.removeListener("updater:state-changed", listener);
    },
  },
};

export type Bridge = typeof bridge;

contextBridge.exposeInMainWorld("bridge", bridge);
