import { exec } from "node:child_process";
import path from "node:path";

// Resolved to an absolute path rather than the bare `powershell` command:
// on at least one real Windows install, spawning "powershell" by name
// failed with "'powershell' is not recognized" even though the binary was
// present — the packaged app's child_process environment didn't carry the
// System32 PATH entry that a normal interactive shell has. The Windows
// PowerShell binary always lives here on every supported Windows version,
// so resolving through %SystemRoot% sidesteps PATH entirely.
const POWERSHELL_PATH = path.join(
  process.env.SystemRoot || "C:\\Windows",
  "System32",
  "WindowsPowerShell",
  "v1.0",
  "powershell.exe",
);

export interface WindowsActiveWindow {
  title: string;
  processName: string;
  processPath: string | null;
}

// Win32 GetForegroundWindow() via a small inline C# type loaded into
// PowerShell — used instead of the `active-win` native N-API module on
// Windows, since that module was consistently returning no result on at
// least one real Windows install (see the diagnostic error surfaced in
// AgentState.lastActivityError) despite desktopCapturer working fine on
// the same machine. This has no native binary of its own to go stale or
// mismatch — PowerShell and user32.dll both ship with Windows.
const PS_SCRIPT = `
Add-Type @"
using System;
using System.Text;
using System.Runtime.InteropServices;
public class CpmWin32 {
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern int GetWindowThreadProcessId(IntPtr hWnd, out int processId);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowTextLength(IntPtr hWnd);
  [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);
}
"@
$hwnd = [CpmWin32]::GetForegroundWindow()
if ($hwnd -eq [IntPtr]::Zero) { Write-Output '{}'; exit }
$len = [CpmWin32]::GetWindowTextLength($hwnd)
$sb = New-Object System.Text.StringBuilder ($len + 1)
[CpmWin32]::GetWindowText($hwnd, $sb, $sb.Capacity) | Out-Null
$procId = 0
[CpmWin32]::GetWindowThreadProcessId($hwnd, [ref]$procId) | Out-Null
$proc = Get-Process -Id $procId -ErrorAction SilentlyContinue
$obj = [ordered]@{
  title = $sb.ToString()
  processName = if ($proc) { $proc.ProcessName } else { $null }
  processPath = if ($proc -and $proc.Path) { $proc.Path } else { $null }
}
$obj | ConvertTo-Json -Compress
`.trim();

function runPowerShell(script: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const encoded = Buffer.from(script, "utf16le").toString("base64");
    exec(
      `"${POWERSHELL_PATH}" -NoProfile -NonInteractive -EncodedCommand ${encoded}`,
      { timeout: 3000, windowsHide: true },
      (error, stdout, stderr) => {
        if (error) {
          reject(new Error(stderr?.trim() || error.message));
          return;
        }
        resolve(stdout.trim());
      },
    );
  });
}

export async function getWindowsActiveWindow(): Promise<WindowsActiveWindow | null> {
  const stdout = await runPowerShell(PS_SCRIPT);
  if (!stdout) return null;

  const parsed = JSON.parse(stdout) as {
    title?: string;
    processName?: string | null;
    processPath?: string | null;
  };
  if (!parsed.processName) return null;

  return {
    title: parsed.title ?? "",
    processName: parsed.processName,
    processPath: parsed.processPath ?? null,
  };
}

export function executableNameFromPath(processPath: string | null, fallback: string): string {
  if (!processPath) return fallback;
  return path.basename(processPath);
}
