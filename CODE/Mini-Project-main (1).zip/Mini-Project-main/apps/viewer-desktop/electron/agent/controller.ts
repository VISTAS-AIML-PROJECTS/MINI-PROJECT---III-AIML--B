import { app } from "electron";
import {
  AGENT_RECONNECT_BASE_DELAY_MS,
  AGENT_RECONNECT_MAX_DELAY_MS,
  DEFAULT_HEARTBEAT_INTERVAL_SECONDS,
  DEFAULT_SCREENSHOT_INTERVAL_SECONDS,
  MIN_SCREENSHOT_INTERVAL_SECONDS,
} from "@college-monitor/config";
import { clearAgentConfig, loadAgentConfig, saveAgentConfig, type AgentConfig } from "./config-store";
import {
  getCpuUsagePercent,
  getCurrentUsername,
  getHostname,
  getMemoryUsagePercent,
  getOperatingSystem,
} from "./system-monitor";
import { ApplicationMonitor } from "./application-monitor";
import { OfflineQueue } from "./offline-queue";
import { executeCommand } from "./command-handler";
import { captureScreenshotBase64 } from "./screenshot";
import {
  registerAgent,
  sendActivityBatch,
  sendCommandResult,
  sendHeartbeat,
  sendScreenshot,
  type ActivityEventPayload,
} from "./api-client";

export type AgentStatus = "unregistered" | "connecting" | "online" | "offline" | "error";

export interface AgentState {
  status: AgentStatus;
  computerCode: string | null;
  computerId: string | null;
  lastHeartbeatAt: string | null;
  lastError: string | null;
  lastActivityError: string | null;
  lastScreenshotAt: string | null;
  lastScreenshotError: string | null;
}

const AGENT_VERSION = app.getVersion();
const ACTIVITY_FLUSH_INTERVAL_MS = 5_000;

export class AgentController {
  private config: AgentConfig | null = null;
  private state: AgentState = {
    status: "unregistered",
    computerCode: null,
    computerId: null,
    lastHeartbeatAt: null,
    lastError: null,
    lastActivityError: null,
    lastScreenshotAt: null,
    lastScreenshotError: null,
  };

  private applicationMonitor: ApplicationMonitor;
  private offlineQueue = new OfflineQueue();
  private pendingEvents: ActivityEventPayload[] = [];

  private heartbeatTimer: ReturnType<typeof setTimeout> | null = null;
  private flushTimer: ReturnType<typeof setInterval> | null = null;
  private screenshotTimer: ReturnType<typeof setInterval> | null = null;
  private reconnectDelayMs = AGENT_RECONNECT_BASE_DELAY_MS;
  private sessionStarted = false;

  constructor(private readonly onStateChange: (state: AgentState) => void) {
    this.applicationMonitor = this.createApplicationMonitor();
  }

  private createApplicationMonitor(): ApplicationMonitor {
    return new ApplicationMonitor(
      (current, previous) => {
        if (this.state.lastActivityError) this.setState({ lastActivityError: null });
        this.pendingEvents.push({
          eventType: previous ? "APP_SWITCH" : "APP_OPEN",
          applicationName: current.applicationName,
          executableName: current.executableName ?? undefined,
          windowTitle: current.windowTitle ?? undefined,
          previousApplicationName: previous?.applicationName,
          occurredAt: new Date().toISOString(),
        });
        // Explicit choice: capture a screenshot on every application
        // switch, unconditionally (no minimum spacing from the periodic
        // timer) — the monitored user's own switching behavior directly
        // controls capture frequency here, by design.
        void this.captureAndSendScreenshot();
      },
      (message) => this.setState({ lastActivityError: message }),
    );
  }

  start(): void {
    this.config = loadAgentConfig();
    if (this.config) {
      this.setState({ status: "connecting", computerCode: this.config.computerCode, computerId: this.config.computerId });
      this.beginMonitoring();
    }
  }

  getState(): AgentState {
    return this.state;
  }

  async register(registrationCode: string): Promise<{ ok: true } | { ok: false; error: string }> {
    try {
      const result = await registerAgent({
        registrationCode,
        hostname: getHostname(),
        operatingSystem: getOperatingSystem(),
        agentVersion: AGENT_VERSION,
      });
      this.config = {
        computerId: result.computerId,
        computerCode: result.computerCode,
        agentToken: result.agentToken,
      };
      saveAgentConfig(this.config);
      this.setState({ status: "connecting", computerCode: this.config.computerCode, computerId: this.config.computerId, lastError: null });
      this.beginMonitoring();
      return { ok: true };
    } catch (error) {
      const message = error instanceof Error ? error.message : "Registration failed.";
      this.setState({ status: "error", lastError: message });
      return { ok: false, error: message };
    }
  }

  async stop(): Promise<void> {
    this.applicationMonitor.stop();
    if (this.heartbeatTimer) clearTimeout(this.heartbeatTimer);
    if (this.flushTimer) clearInterval(this.flushTimer);
    if (this.screenshotTimer) clearInterval(this.screenshotTimer);
    if (this.config && this.sessionStarted) {
      this.pendingEvents.push({
        eventType: "SESSION_END",
        username: getCurrentUsername(),
        occurredAt: new Date().toISOString(),
      });
      await this.flushActivity();
    }
  }

  // Clears the locally stored registration (e.g. after an Admin deletes
  // or revokes this computer's credential — heartbeats then fail forever
  // with no way to recover without this) and returns to the
  // registration screen. Does not affect anything server-side; if the
  // computer row still exists, an Admin can also generate a fresh
  // registration code for it from Manage PC.
  async reset(): Promise<void> {
    await this.stop();
    this.applicationMonitor = this.createApplicationMonitor();
    this.heartbeatTimer = null;
    this.flushTimer = null;
    this.screenshotTimer = null;
    this.reconnectDelayMs = AGENT_RECONNECT_BASE_DELAY_MS;
    this.sessionStarted = false;
    this.pendingEvents = [];
    this.config = null;
    clearAgentConfig();
    this.setState({
      status: "unregistered",
      computerCode: null,
      computerId: null,
      lastHeartbeatAt: null,
      lastError: null,
      lastActivityError: null,
      lastScreenshotAt: null,
      lastScreenshotError: null,
    });
  }

  private beginMonitoring(): void {
    if (!this.sessionStarted) {
      this.pendingEvents.push({
        eventType: "SESSION_START",
        username: getCurrentUsername(),
        occurredAt: new Date().toISOString(),
      });
      this.sessionStarted = true;
    }

    this.applicationMonitor.start();
    if (!this.flushTimer) {
      this.flushTimer = setInterval(() => void this.flushActivity(), ACTIVITY_FLUSH_INTERVAL_MS);
    }
    if (!this.screenshotTimer) {
      const intervalMs =
        Math.max(DEFAULT_SCREENSHOT_INTERVAL_SECONDS, MIN_SCREENSHOT_INTERVAL_SECONDS) * 1000;
      this.screenshotTimer = setInterval(() => void this.captureAndSendScreenshot(), intervalMs);
      void this.captureAndSendScreenshot();
    }
    this.scheduleHeartbeat(0);
  }

  private async captureAndSendScreenshot(): Promise<void> {
    if (!this.config) return;
    const captured = await captureScreenshotBase64();
    if (!captured.ok) {
      this.setState({ lastScreenshotError: captured.reason });
      return;
    }
    try {
      await sendScreenshot(this.config.agentToken, captured.imageBase64);
      this.setState({ lastScreenshotAt: new Date().toISOString(), lastScreenshotError: null });
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      console.warn("[agent] Failed to send screenshot:", error);
      this.setState({ lastScreenshotError: message });
    }
  }

  private scheduleHeartbeat(delayMs: number): void {
    if (this.heartbeatTimer) clearTimeout(this.heartbeatTimer);
    this.heartbeatTimer = setTimeout(() => void this.heartbeat(), delayMs);
  }

  private async heartbeat(): Promise<void> {
    if (!this.config) return;

    try {
      const [cpuUsage, memoryUsage] = await Promise.all([
        getCpuUsagePercent(),
        Promise.resolve(getMemoryUsagePercent()),
      ]);

      const result = await sendHeartbeat(this.config.agentToken, {
        cpuUsage,
        memoryUsage,
        agentVersion: AGENT_VERSION,
      });

      this.reconnectDelayMs = AGENT_RECONNECT_BASE_DELAY_MS;
      this.setState({
        status: "online",
        computerCode: this.config.computerCode,
        computerId: this.config.computerId,
        lastHeartbeatAt: new Date().toISOString(),
        lastError: null,
      });

      for (const command of result.commands) {
        void this.handleCommand(command.commandId, command.commandType);
      }

      this.scheduleHeartbeat(result.heartbeatIntervalSeconds * 1000);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Heartbeat failed.";
      this.setState({ status: "offline", lastError: message });
      this.scheduleHeartbeat(this.reconnectDelayMs);
      this.reconnectDelayMs = Math.min(this.reconnectDelayMs * 2, AGENT_RECONNECT_MAX_DELAY_MS);
    }
  }

  private async handleCommand(
    commandId: string,
    commandType: Parameters<typeof executeCommand>[0],
  ): Promise<void> {
    if (!this.config) return;
    const outcome = await executeCommand(commandType);
    try {
      await sendCommandResult(this.config.agentToken, {
        commandId,
        status: outcome.status,
        result: outcome.result,
      });
    } catch (error) {
      console.warn("[agent] Failed to report command result:", error);
    }
  }

  private async flushActivity(): Promise<void> {
    if (!this.config) return;
    const queued = this.offlineQueue.drain();
    const batch = [...queued, ...this.pendingEvents];
    if (batch.length === 0) return;
    this.pendingEvents = [];

    try {
      await sendActivityBatch(this.config.agentToken, batch);
    } catch (error) {
      console.warn("[agent] Failed to send activity batch, queuing offline:", error);
      this.offlineQueue.requeue(batch);
    }
  }

  private setState(patch: Partial<AgentState>): void {
    this.state = { ...this.state, ...patch };
    this.onStateChange(this.state);
  }
}
