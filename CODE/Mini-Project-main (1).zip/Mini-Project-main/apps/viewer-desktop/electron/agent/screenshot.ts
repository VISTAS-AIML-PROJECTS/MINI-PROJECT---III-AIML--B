import { desktopCapturer } from "electron";

export type ScreenshotResult =
  | { ok: true; imageBase64: string }
  | { ok: false; reason: string };

// Captures a single compressed still frame of the primary display. This
// is intentionally a one-shot snapshot, called on a timer by the agent
// controller (see MIN_SCREENSHOT_INTERVAL_SECONDS) — there is no
// continuous capture, video, or recording path anywhere in this module.
//
// macOS requires the user to grant this app "Screen Recording" access
// (System Settings -> Privacy & Security -> Screen Recording) — without
// it, getSources() returns no usable thumbnail. Returns a reason string
// on any failure instead of silently swallowing it, since a packaged app
// has no visible console to catch a console.warn.
export async function captureScreenshotBase64(): Promise<ScreenshotResult> {
  try {
    const sources = await desktopCapturer.getSources({
      types: ["screen"],
      thumbnailSize: { width: 1280, height: 800 },
    });

    if (sources.length === 0) {
      return { ok: false, reason: "No screen sources returned by the OS." };
    }

    const primary = sources[0];
    if (!primary || primary.thumbnail.isEmpty()) {
      return { ok: false, reason: "Screen source thumbnail was empty (permission not granted?)." };
    }

    const jpeg = primary.thumbnail.toJPEG(60);
    return { ok: true, imageBase64: jpeg.toString("base64") };
  } catch (error) {
    return { ok: false, reason: error instanceof Error ? error.message : String(error) };
  }
}
