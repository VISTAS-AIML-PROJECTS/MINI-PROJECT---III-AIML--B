import os from "node:os";
import activeWindow from "active-win";
import { executableNameFromPath, getWindowsActiveWindow } from "./active-window-windows";

export interface ActiveWindowInfo {
  applicationName: string;
  executableName: string | null;
  windowTitle: string | null;
}

export type ApplicationSwitchListener = (
  current: ActiveWindowInfo,
  previous: ActiveWindowInfo | null,
) => void;

async function readActiveWindow(): Promise<ActiveWindowInfo | null> {
  // On Windows, use a small Win32 call through PowerShell instead of the
  // `active-win` native module — that module was observed to reliably
  // return no result at all on a real Windows install even though
  // Electron's own desktopCapturer worked fine on the same machine,
  // pointing at a native-binary compatibility issue rather than "no
  // window focused". PowerShell + user32.dll ship with Windows, so this
  // has no native addon of its own to go stale.
  if (os.platform() === "win32") {
    const result = await getWindowsActiveWindow();
    if (!result) return null;
    return {
      applicationName: result.processName,
      executableName: executableNameFromPath(result.processPath, result.processName),
      windowTitle: result.title || null,
    };
  }

  const result = await activeWindow();
  if (!result) return null;
  return {
    applicationName: result.owner.name,
    executableName: result.owner.path?.split(/[\\/]/).pop() ?? null,
    windowTitle: result.title || null,
  };
}

// Polls the OS for the foreground window/application on an interval and
// reports changes only (not every poll) — this is the application
// switching signal the Activity page's timeline is built from. Only
// application name, executable name, and window title are read; no
// keystrokes, clipboard, or screen content are ever accessed.
export class ApplicationMonitor {
  private timer: ReturnType<typeof setInterval> | null = null;
  private current: ActiveWindowInfo | null = null;

  constructor(
    private readonly onSwitch: ApplicationSwitchListener,
    private readonly onError?: (message: string) => void,
    private readonly pollIntervalMs = 2000,
  ) {}

  start(): void {
    if (this.timer) return;
    this.timer = setInterval(() => void this.poll(), this.pollIntervalMs);
    void this.poll();
  }

  stop(): void {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  getCurrent(): ActiveWindowInfo | null {
    return this.current;
  }

  private async poll(): Promise<void> {
    let info: ActiveWindowInfo | null;
    try {
      info = await readActiveWindow();
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      console.warn("[agent] Failed to read active window:", error);
      this.onError?.(message);
      return;
    }
    if (!info) {
      this.onError?.("No focused window detected.");
      return;
    }

    const changed =
      !this.current ||
      this.current.applicationName !== info.applicationName ||
      this.current.windowTitle !== info.windowTitle;

    if (changed) {
      const previous = this.current;
      this.current = info;
      this.onSwitch(info, previous);
    }
  }
}
