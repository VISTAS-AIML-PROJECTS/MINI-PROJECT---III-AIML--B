import { useEffect, useState } from "react";
import { Cpu, MonitorCheck, ShieldCheck, ArrowRight } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";

type ScreenAccessStatus = "not-determined" | "granted" | "denied" | "restricted" | "unknown";

const WELCOME_SEEN_KEY = "cpm.onboarding.welcomeSeen";

// A short, one-time-ish setup flow: introduce what registering this
// computer does, then (macOS only) walk the user through granting Screen
// Recording access — required for the periodic screenshot feature, and
// the one permission macOS doesn't let an app request programmatically.
// Windows/Linux have no equivalent OS prompt for this, so that step
// simply never appears there. Returns null once there's nothing left to
// show, so the caller can render its normal content underneath.
export function Onboarding({ onDone }: { onDone: () => void }) {
  const [step, setStep] = useState<"welcome" | "permissions" | "done" | null>(null);
  const [screenStatus, setScreenStatus] = useState<ScreenAccessStatus | null>(null);
  const [platform, setPlatform] = useState<NodeJS.Platform | null>(null);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      const [plat, status] = await Promise.all([
        window.bridge.getPlatform(),
        window.bridge.permissions.getScreenAccessStatus(),
      ]);
      if (cancelled) return;
      setPlatform(plat);
      setScreenStatus(status);

      const welcomeSeen = localStorage.getItem(WELCOME_SEEN_KEY) === "true";
      if (!welcomeSeen) {
        setStep("welcome");
      } else if (plat === "darwin" && status !== "granted") {
        setStep("permissions");
      } else {
        setStep("done");
      }
    }
    void load();
    return () => {
      cancelled = true;
    };
  }, []);

  async function recheckPermission() {
    const status = await window.bridge.permissions.getScreenAccessStatus();
    setScreenStatus(status);
    if (status === "granted") setStep("done");
  }

  function handleWelcomeNext() {
    localStorage.setItem(WELCOME_SEEN_KEY, "true");
    if (platform === "darwin" && screenStatus !== "granted") {
      setStep("permissions");
    } else {
      setStep("done");
    }
  }

  useEffect(() => {
    if (step === "done") onDone();
  }, [step, onDone]);

  if (step === null || step === "done") return null;

  if (step === "welcome") {
    return (
      <div className="mx-auto max-w-md space-y-6 pt-12">
        <div className="flex flex-col items-center gap-3 text-center">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground">
            <Cpu className="h-7 w-7" />
          </div>
          <h1 className="text-xl font-semibold">Set up this computer</h1>
          <p className="text-sm text-muted-foreground">
            A quick, one-time setup. Once registered, this app reports basic status (online/offline,
            CPU/RAM), tracks which application is in focus, and takes an occasional screenshot — all
            visible only to your administrator in College PC Admin.
          </p>
        </div>
        <Button className="w-full" onClick={handleWelcomeNext}>
          Continue <ArrowRight className="h-4 w-4" />
        </Button>
      </div>
    );
  }

  // step === "permissions" (macOS only)
  return (
    <div className="mx-auto max-w-md space-y-6 pt-12">
      <div className="flex flex-col items-center gap-3 text-center">
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground">
          <ShieldCheck className="h-7 w-7" />
        </div>
        <h1 className="text-xl font-semibold">Allow Screen Recording</h1>
        <p className="text-sm text-muted-foreground">
          macOS requires explicit permission before any app can capture the screen. This is needed for
          the periodic screenshot feature — it captures one still frame at a time, never a continuous
          recording.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Status</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-sm">
            Current: <span className="font-medium">{screenStatus === "granted" ? "Granted" : "Not granted"}</span>
          </p>
          <ol className="list-inside list-decimal space-y-1 text-xs text-muted-foreground">
            <li>Click "Open System Settings" below</li>
            <li>Enable College PC Viewer under Screen Recording</li>
            <li>Come back here and click "I've granted access"</li>
          </ol>
          <div className="flex flex-wrap gap-2 pt-1">
            <Button size="sm" onClick={() => void window.bridge.permissions.openScreenSettings()}>
              <MonitorCheck className="h-3.5 w-3.5" /> Open System Settings
            </Button>
            <Button size="sm" variant="outline" onClick={() => void recheckPermission()}>
              I've granted access
            </Button>
          </div>
        </CardContent>
      </Card>

      <button
        className="w-full text-center text-xs text-muted-foreground underline"
        onClick={() => setStep("done")}
      >
        Skip for now (screenshots won't work until this is granted)
      </button>
    </div>
  );
}
