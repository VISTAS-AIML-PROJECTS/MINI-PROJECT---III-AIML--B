import { Outlet } from "react-router-dom";
import { LogOut, Monitor, RefreshCw } from "lucide-react";
import { useAuthStore } from "../stores/auth.store";
import { useUpdater } from "../hooks/useUpdater";
import { Tooltip, TooltipContent, TooltipTrigger } from "../components/ui/tooltip";
import { cn } from "@college-monitor/ui";

// Deliberately minimal: this app has exactly one page (register/status
// for the machine it's installed on), so there's no sidebar or nav —
// just a slim header and the page content. All monitoring data reading
// happens in College PC Admin.
export function AppLayout() {
  const profile = useAuthStore((s) => s.profile);
  const signOut = useAuthStore((s) => s.signOut);
  const { state: updaterState, check: checkForUpdates } = useUpdater();
  const isCheckingUpdate = updaterState.status === "checking" || updaterState.status === "downloading";

  return (
    <div className="flex h-screen w-screen flex-col overflow-hidden bg-background">
      <header className="flex h-14 shrink-0 items-center justify-between border-b border-border bg-card px-6">
        <div className="flex items-center gap-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-md bg-primary text-primary-foreground">
            <Monitor className="h-4 w-4" />
          </div>
          <span className="text-sm font-semibold">College PC Viewer</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-sm text-muted-foreground">{profile?.fullName ?? profile?.email}</span>
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                onClick={() => !isCheckingUpdate && checkForUpdates()}
                disabled={isCheckingUpdate}
                className="rounded-md p-2 text-muted-foreground hover:bg-accent hover:text-foreground disabled:opacity-50"
                title="Check for updates"
              >
                <RefreshCw className={cn("h-4 w-4", isCheckingUpdate && "animate-spin")} />
              </button>
            </TooltipTrigger>
            <TooltipContent>Check for updates</TooltipContent>
          </Tooltip>
          <button
            onClick={() => void signOut()}
            className="rounded-md p-2 text-muted-foreground hover:bg-accent hover:text-foreground"
            title="Sign out"
          >
            <LogOut className="h-4 w-4" />
          </button>
        </div>
      </header>
      <main className="flex-1 overflow-y-auto p-6">
        <Outlet />
      </main>
    </div>
  );
}
