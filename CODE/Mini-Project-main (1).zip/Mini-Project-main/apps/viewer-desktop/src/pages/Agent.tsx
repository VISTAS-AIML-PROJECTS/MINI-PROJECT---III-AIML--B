import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import { Cpu, Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Badge } from "../components/ui/badge";
import { Onboarding } from "../components/Onboarding";

type AgentStatus = "unregistered" | "connecting" | "online" | "offline" | "error";

interface AgentState {
  status: AgentStatus;
  computerCode: string | null;
  computerId: string | null;
  lastHeartbeatAt: string | null;
  lastError: string | null;
  lastActivityError: string | null;
  lastScreenshotAt: string | null;
  lastScreenshotError: string | null;
}

const STATUS_LABEL: Record<AgentStatus, string> = {
  unregistered: "Not registered",
  connecting: "Connecting",
  online: "Online",
  offline: "Offline",
  error: "Error",
};

const STATUS_VARIANT: Record<AgentStatus, "default" | "secondary" | "destructive"> = {
  unregistered: "secondary",
  connecting: "secondary",
  online: "default",
  offline: "destructive",
  error: "destructive",
};

// This page is about the machine the app is running ON, not the person
// logged in as a Viewer. If this install has been registered as a
// monitored computer (via a code an Admin generated in Computers ->
// Register PC), the main process runs the same heartbeat / system-usage
// / application-tracking / remote-command loop a dedicated PC Agent
// would — independent of whoever is signed into the dashboard above.
export function Agent() {
  const [state, setState] = useState<AgentState | null>(null);
  const [code, setCode] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [resetting, setResetting] = useState(false);
  const [onboardingDone, setOnboardingDone] = useState(false);
  const bridgeAvailable = typeof window !== "undefined" && Boolean(window.bridge);
  const handleOnboardingDone = useCallback(() => setOnboardingDone(true), []);

  useEffect(() => {
    if (!bridgeAvailable) return;
    void window.bridge.agent.getState().then(setState);
    return window.bridge.agent.onStateChange(setState);
  }, [bridgeAvailable]);

  if (!bridgeAvailable) {
    return (
      <p className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">
        Agent bridge is unavailable — this page only works inside the College PC Viewer desktop app,
        not a plain browser tab.
      </p>
    );
  }

  if (!onboardingDone) {
    return <Onboarding onDone={handleOnboardingDone} />;
  }

  async function handleRegister() {
    if (!code.trim()) return;
    setSubmitting(true);
    try {
      const result = await window.bridge.agent.register(code.trim());
      if (result.ok) {
        toast.success("This computer is now registered and reporting.");
        setCode("");
      } else {
        toast.error("Registration failed", { description: result.error });
      }
    } finally {
      setSubmitting(false);
    }
  }

  async function handleReset() {
    setResetting(true);
    try {
      await window.bridge.agent.reset();
      toast.success("Registration cleared. You can register this computer again below.");
    } finally {
      setResetting(false);
    }
  }

  if (!state) {
    return (
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Loader2 className="h-4 w-4 animate-spin" /> Loading agent status…
      </div>
    );
  }

  return (
    <div className="max-w-lg space-y-6">
      <div>
        <h1 className="text-xl font-semibold">This computer</h1>
        <p className="text-sm text-muted-foreground">
          Register this computer so it reports status, usage, and application activity to an
          administrator. Monitoring data itself is only ever viewed in College PC Admin.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Agent status</CardTitle>
          <Badge variant={STATUS_VARIANT[state.status]}>{STATUS_LABEL[state.status]}</Badge>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Computer code</span>
            <span className="font-medium">{state.computerCode ?? "—"}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Last heartbeat</span>
            <span className="font-medium">
              {state.lastHeartbeatAt ? new Date(state.lastHeartbeatAt).toLocaleTimeString() : "—"}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Last screenshot</span>
            <span className="font-medium">
              {state.lastScreenshotAt ? new Date(state.lastScreenshotAt).toLocaleTimeString() : "—"}
            </span>
          </div>
          {state.lastError && (
            <p className="rounded-md bg-destructive/10 px-3 py-2 text-xs text-destructive">
              {state.lastError}
            </p>
          )}
          {state.lastActivityError && (
            <p className="rounded-md bg-destructive/10 px-3 py-2 text-xs text-destructive">
              Activity tracking: {state.lastActivityError}
            </p>
          )}
          {state.lastScreenshotError && (
            <p className="rounded-md bg-destructive/10 px-3 py-2 text-xs text-destructive">
              Screenshot: {state.lastScreenshotError}
            </p>
          )}
          {(state.status === "error" || state.status === "offline") && (
            <Button variant="outline" size="sm" onClick={() => void handleReset()} disabled={resetting}>
              Reset registration
            </Button>
          )}
        </CardContent>
      </Card>
      {(state.status === "error" || state.status === "offline") && (
        <p className="text-xs text-muted-foreground">
          If this keeps failing (e.g. an Admin deleted or revoked this computer), use "Reset
          registration" above, then register again with a fresh code.
        </p>
      )}

      {state.status === "unregistered" && (
        <Card>
          <CardHeader>
            <CardTitle>Register this computer</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-1.5">
              <Label htmlFor="registration-code">Registration code</Label>
              <Input
                id="registration-code"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="Paste the code an Admin generated"
              />
            </div>
            <Button onClick={() => void handleRegister()} disabled={submitting || !code.trim()}>
              <Cpu className="h-4 w-4" /> Register
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
