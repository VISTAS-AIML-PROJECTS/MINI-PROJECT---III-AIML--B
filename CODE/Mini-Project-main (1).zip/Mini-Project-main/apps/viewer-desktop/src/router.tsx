import { createHashRouter } from "react-router-dom";
import { AppLayout } from "./layouts/AppLayout";
import { RequireAuth } from "./components/RequireAuth";
import { Login } from "./pages/Login";
import { Agent } from "./pages/Agent";
import { APP_ROUTES } from "@college-monitor/config";

export const router = createHashRouter([
  { path: APP_ROUTES.LOGIN, element: <Login /> },
  {
    element: <RequireAuth />,
    children: [
      {
        element: <AppLayout />,
        children: [{ path: APP_ROUTES.DASHBOARD, element: <Agent /> }],
      },
    ],
  },
]);
