import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { format, formatDistanceStrict } from "date-fns";
import { Users2 } from "lucide-react";
import { listSessions } from "../services/sessions";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table";
import { Badge } from "../components/ui/badge";
import { Button } from "../components/ui/button";
import { Skeleton } from "../components/ui/skeleton";
import { EmptyState } from "../components/ui/empty-state";

const PAGE_SIZE = 25;

export function Sessions() {
  const [page, setPage] = useState(1);
  const { data, isLoading } = useQuery({
    queryKey: ["sessions", page],
    queryFn: () => listSessions({ page, pageSize: PAGE_SIZE }),
  });

  const totalPages = data ? Math.max(1, Math.ceil(data.total / PAGE_SIZE)) : 1;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold">Sessions</h1>
        <p className="text-sm text-muted-foreground">OS login sessions across all computers.</p>
      </div>

      {isLoading ? (
        <Skeleton className="h-96 w-full" />
      ) : !data || data.items.length === 0 ? (
        <EmptyState icon={Users2} title="No sessions recorded yet" />
      ) : (
        <>
          <div className="rounded-lg border border-border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Computer</TableHead>
                  <TableHead>Username</TableHead>
                  <TableHead>Started</TableHead>
                  <TableHead>Duration</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.items.map((session) => (
                  <TableRow key={session.id}>
                    <TableCell className="font-medium">{session.computerName}</TableCell>
                    <TableCell>{session.username}</TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {format(new Date(session.startedAt), "PPp")}
                    </TableCell>
                    <TableCell>
                      {formatDistanceStrict(
                        session.endedAt ? new Date(session.endedAt) : new Date(),
                        new Date(session.startedAt),
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge variant={session.isActive ? "default" : "secondary"}>
                        {session.isActive ? "Active" : "Ended"}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          <div className="flex items-center justify-between">
            <p className="text-xs text-muted-foreground">
              Page {page} of {totalPages} · {data.total} sessions
            </p>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
                Previous
              </Button>
              <Button
                variant="outline"
                size="sm"
                disabled={page >= totalPages}
                onClick={() => setPage((p) => p + 1)}
              >
                Next
              </Button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
