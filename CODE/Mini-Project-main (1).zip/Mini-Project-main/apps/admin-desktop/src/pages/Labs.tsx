import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus, Building2 } from "lucide-react";
import type { Lab } from "@college-monitor/types";
import { listLabs, createLab, updateLab } from "../services/labs";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import { Switch } from "../components/ui/switch";
import { Skeleton } from "../components/ui/skeleton";
import { EmptyState } from "../components/ui/empty-state";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "../components/ui/dialog";

function LabDialog({ lab, open, onClose }: { lab: Lab | null; open: boolean; onClose: () => void }) {
  const [name, setName] = useState(lab?.name ?? "");
  const [building, setBuilding] = useState(lab?.building ?? "");
  const [room, setRoom] = useState(lab?.room ?? "");
  const [description, setDescription] = useState(lab?.description ?? "");
  const [submitting, setSubmitting] = useState(false);
  const queryClient = useQueryClient();

  async function handleSubmit() {
    if (!name.trim()) return;
    setSubmitting(true);
    try {
      if (lab) {
        await updateLab(lab.id, { name, building, room, description });
      } else {
        await createLab({ name, building, room, description });
      }
      void queryClient.invalidateQueries({ queryKey: ["labs"] });
      toast.success(lab ? "Lab updated" : "Lab created");
      onClose();
    } catch (err) {
      toast.error("Failed to save lab", { description: err instanceof Error ? err.message : undefined });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(next) => !next && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{lab ? "Edit lab" : "Add lab"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label>Name</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Computer Lab C" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Building</Label>
              <Input value={building} onChange={(e) => setBuilding(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Room</Label>
              <Input value={room} onChange={(e) => setRoom(e.target.value)} />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Description</Label>
            <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={3} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={() => void handleSubmit()} disabled={submitting || !name.trim()}>
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function Labs() {
  const { data: labs, isLoading } = useQuery({ queryKey: ["labs"], queryFn: listLabs });
  const queryClient = useQueryClient();
  const [dialogState, setDialogState] = useState<{ open: boolean; lab: Lab | null }>({
    open: false,
    lab: null,
  });

  async function handleToggleActive(lab: Lab) {
    try {
      await updateLab(lab.id, { isActive: !lab.isActive });
      void queryClient.invalidateQueries({ queryKey: ["labs"] });
    } catch (err) {
      toast.error("Failed to update lab", { description: err instanceof Error ? err.message : undefined });
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold">Labs</h1>
          <p className="text-sm text-muted-foreground">Organize computers into physical labs.</p>
        </div>
        <Button onClick={() => setDialogState({ open: true, lab: null })}>
          <Plus className="h-4 w-4" /> Add lab
        </Button>
      </div>

      {isLoading ? (
        <Skeleton className="h-64 w-full" />
      ) : !labs || labs.length === 0 ? (
        <EmptyState icon={Building2} title="No labs yet" description="Add a lab to start organizing computers." />
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {labs.map((lab) => (
            <Card key={lab.id}>
              <CardHeader>
                <CardTitle className="text-base font-semibold text-foreground">{lab.name}</CardTitle>
                <Switch checked={lab.isActive} onCheckedChange={() => void handleToggleActive(lab)} />
              </CardHeader>
              <CardContent className="space-y-2">
                <p className="text-xs text-muted-foreground">
                  {[lab.building, lab.room].filter(Boolean).join(" · ") || "No location set"}
                </p>
                {lab.description && <p className="text-sm">{lab.description}</p>}
                <Button variant="outline" size="sm" onClick={() => setDialogState({ open: true, lab })}>
                  Edit
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <LabDialog
        lab={dialogState.lab}
        open={dialogState.open}
        onClose={() => setDialogState({ open: false, lab: null })}
      />
    </div>
  );
}
