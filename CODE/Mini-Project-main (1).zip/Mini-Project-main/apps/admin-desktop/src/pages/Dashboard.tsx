import { useQuery } from "@tanstack/react-query";
import { Monitor, Wifi, WifiOff, Ban, Users2, Activity as ActivityIcon } from "lucide-react";
import { useComputers } from "../hooks/useComputers";
import { getTodayActivityCount } from "../services/activities";
import { Card, CardAction, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Skeleton } from "../components/ui/skeleton";
import { EmptyState } from "../components/ui/empty-state";
import { ComputerCard } from "../components/ComputerCard";

function StatCard({
  icon: Icon,
  label,
  value,
  loading,
}: {
  icon: typeof Monitor;
  label: string;
  value: number;
  loading: boolean;
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xs font-medium text-muted-foreground">{label}</CardTitle>
        <CardAction>
          <Icon className="h-4 w-4 text-muted-foreground" />
        </CardAction>
      </CardHeader>
      <CardContent>
        {loading ? <Skeleton className="h-7 w-12" /> : <p className="text-2xl font-semibold">{value}</p>}
      </CardContent>
    </Card>
  );
}

export function Dashboard() {
  const { data: computers, isLoading } = useComputers();
  const { data: todayActivity, isLoading: activityLoading } = useQuery({
    queryKey: ["today-activity-count"],
    queryFn: getTodayActivityCount,
    refetchInterval: 60_000,
  });

  const total = computers?.length ?? 0;
  const online = computers?.filter((c) => c.status === "ONLINE").length ?? 0;
  const offline = computers?.filter((c) => c.status === "OFFLINE").length ?? 0;
  const disabled = computers?.filter((c) => c.status === "DISABLED").length ?? 0;
  const activeSessions = computers?.filter((c) => c.currentSessionUsername).length ?? 0;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold">Dashboard</h1>
        <p className="text-sm text-muted-foreground">Live overview of every registered computer.</p>
      </div>

      <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-6">
        <StatCard icon={Monitor} label="Total Computers" value={total} loading={isLoading} />
        <StatCard icon={Wifi} label="Online" value={online} loading={isLoading} />
        <StatCard icon={WifiOff} label="Offline" value={offline} loading={isLoading} />
        <StatCard icon={Ban} label="Disabled" value={disabled} loading={isLoading} />
        <StatCard icon={Users2} label="Active Sessions" value={activeSessions} loading={isLoading} />
        <StatCard
          icon={ActivityIcon}
          label="Today's Activity"
          value={todayActivity ?? 0}
          loading={activityLoading}
        />
      </div>

      <div>
        <h2 className="mb-3 text-sm font-semibold text-muted-foreground">Computers</h2>
        {isLoading ? (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <Skeleton key={i} className="h-40" />
            ))}
          </div>
        ) : total === 0 ? (
          <EmptyState
            icon={Monitor}
            title="No computers registered yet"
            description="Go to Computers → Register PC to add your first computer and generate a registration code for its agent."
          />
        ) : (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {computers!.map((computer) => (
              <ComputerCard key={computer.id} computer={computer} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
