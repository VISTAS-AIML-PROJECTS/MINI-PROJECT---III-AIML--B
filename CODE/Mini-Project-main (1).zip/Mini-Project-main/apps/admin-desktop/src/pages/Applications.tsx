import { useQuery } from "@tanstack/react-query";
import { AppWindow } from "lucide-react";
import { listApplicationUsage } from "../services/applications";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table";
import { Skeleton } from "../components/ui/skeleton";
import { EmptyState } from "../components/ui/empty-state";

function formatDuration(seconds: number): string {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  if (hours === 0) return `${minutes}m`;
  return `${hours}h ${minutes}m`;
}

export function Applications() {
  const { data, isLoading } = useQuery({
    queryKey: ["applications-usage"],
    queryFn: listApplicationUsage,
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold">Applications</h1>
        <p className="text-sm text-muted-foreground">Usage across every registered computer.</p>
      </div>

      {isLoading ? (
        <Skeleton className="h-96 w-full" />
      ) : !data || data.length === 0 ? (
        <EmptyState
          icon={AppWindow}
          title="No application activity yet"
          description="Usage appears here once PC Agents start reporting application activity."
        />
      ) : (
        <div className="rounded-lg border border-border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Application</TableHead>
                <TableHead>Total usage</TableHead>
                <TableHead>Computers</TableHead>
                <TableHead>Sessions</TableHead>
                <TableHead>Average duration</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((app) => (
                <TableRow key={app.applicationId}>
                  <TableCell className="font-medium">{app.applicationName}</TableCell>
                  <TableCell>{formatDuration(app.totalUsageSeconds)}</TableCell>
                  <TableCell>{app.computerCount}</TableCell>
                  <TableCell>{app.sessionCount}</TableCell>
                  <TableCell>{formatDuration(Math.round(app.averageDurationSeconds))}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}
