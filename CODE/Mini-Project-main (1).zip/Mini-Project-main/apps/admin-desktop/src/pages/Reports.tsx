import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { subDays, format } from "date-fns";
import { Download, Printer } from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  getActivityReport,
  getApplicationUsageReport,
  getComputerUtilizationReport,
  getSessionStatisticsReport,
} from "../services/reports";
import { downloadCsv } from "../services/csv";
import { Card, CardAction, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Skeleton } from "../components/ui/skeleton";

export function Reports() {
  const [dateFrom, setDateFrom] = useState(format(subDays(new Date(), 7), "yyyy-MM-dd"));
  const [dateTo, setDateTo] = useState(format(new Date(), "yyyy-MM-dd"));

  const filters = {
    dateFrom: new Date(dateFrom).toISOString(),
    dateTo: new Date(new Date(dateTo).setHours(23, 59, 59, 999)).toISOString(),
  };

  const { data: activity, isLoading: activityLoading } = useQuery({
    queryKey: ["reports", "activity", filters],
    queryFn: () => getActivityReport(filters),
  });
  const { data: apps, isLoading: appsLoading } = useQuery({
    queryKey: ["reports", "applications", filters],
    queryFn: () => getApplicationUsageReport(filters),
  });
  const { data: utilization, isLoading: utilizationLoading } = useQuery({
    queryKey: ["reports", "utilization", filters],
    queryFn: () => getComputerUtilizationReport(filters),
  });
  const { data: sessionStats, isLoading: sessionLoading } = useQuery({
    queryKey: ["reports", "sessions", filters],
    queryFn: () => getSessionStatisticsReport(filters),
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold">Reports</h1>
          <p className="text-sm text-muted-foreground">Activity, application usage, and PC utilization.</p>
        </div>
        <Button variant="outline" onClick={() => window.print()}>
          <Printer className="h-4 w-4" /> Print / Save as PDF
        </Button>
      </div>

      <div className="flex flex-wrap items-end gap-3">
        <div className="space-y-1.5">
          <Label>From</Label>
          <Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
        </div>
        <div className="space-y-1.5">
          <Label>To</Label>
          <Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Daily activity</CardTitle>
          <CardAction><Button
            variant="ghost"
            size="sm"
            disabled={!activity?.length}
            onClick={() => downloadCsv("activity-report.csv", activity ?? [])}
          >
            <Download className="h-3.5 w-3.5" /> CSV
          </Button></CardAction>
        </CardHeader>
        <CardContent>
          {activityLoading ? (
            <Skeleton className="h-64 w-full" />
          ) : (
            <ResponsiveContainer width="100%" height={260}>
              <LineChart data={activity ?? []}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis dataKey="date" fontSize={12} />
                <YAxis fontSize={12} />
                <Tooltip />
                <Line type="monotone" dataKey="eventCount" name="Events" stroke="var(--color-chart-1)" strokeWidth={2} />
                <Line
                  type="monotone"
                  dataKey="activeComputerCount"
                  name="Active PCs"
                  stroke="var(--color-chart-2)"
                  strokeWidth={2}
                />
              </LineChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Top applications by usage</CardTitle>
          <CardAction><Button
            variant="ghost"
            size="sm"
            disabled={!apps?.length}
            onClick={() => downloadCsv("application-usage-report.csv", apps ?? [])}
          >
            <Download className="h-3.5 w-3.5" /> CSV
          </Button></CardAction>
        </CardHeader>
        <CardContent>
          {appsLoading ? (
            <Skeleton className="h-64 w-full" />
          ) : (
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={apps ?? []} layout="vertical" margin={{ left: 24 }}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis type="number" fontSize={12} />
                <YAxis type="category" dataKey="applicationName" fontSize={12} width={100} />
                <Tooltip />
                <Bar dataKey="usageSeconds" name="Usage (seconds)" fill="var(--color-chart-1)" radius={4} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Computer utilization</CardTitle>
          <CardAction><Button
            variant="ghost"
            size="sm"
            disabled={!utilization?.length}
            onClick={() => downloadCsv("computer-utilization-report.csv", utilization ?? [])}
          >
            <Download className="h-3.5 w-3.5" /> CSV
          </Button></CardAction>
        </CardHeader>
        <CardContent>
          {utilizationLoading ? (
            <Skeleton className="h-64 w-full" />
          ) : (
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={utilization ?? []}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis dataKey="computerName" fontSize={12} />
                <YAxis fontSize={12} unit="%" />
                <Tooltip />
                <Bar dataKey="uptimePercentage" name="Uptime %" fill="var(--color-chart-3)" radius={4} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Session statistics</CardTitle>
          <CardAction><Button
            variant="ghost"
            size="sm"
            disabled={!sessionStats?.length}
            onClick={() => downloadCsv("session-statistics-report.csv", sessionStats ?? [])}
          >
            <Download className="h-3.5 w-3.5" /> CSV
          </Button></CardAction>
        </CardHeader>
        <CardContent>
          {sessionLoading ? (
            <Skeleton className="h-64 w-full" />
          ) : (
            <ResponsiveContainer width="100%" height={260}>
              <LineChart data={sessionStats ?? []}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis dataKey="date" fontSize={12} />
                <YAxis fontSize={12} />
                <Tooltip />
                <Line type="monotone" dataKey="sessionCount" name="Sessions" stroke="var(--color-chart-4)" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
