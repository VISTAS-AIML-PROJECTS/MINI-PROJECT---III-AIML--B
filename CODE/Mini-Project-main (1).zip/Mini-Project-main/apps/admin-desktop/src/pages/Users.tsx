import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { format } from "date-fns";
import { Plus, UserCog, Pencil, Trash2 } from "lucide-react";
import type { Profile } from "@college-monitor/types";
import {
  listUsers,
  createViewer,
  updateUser,
  editViewer,
  deleteViewer,
  getViewerLabAssignments,
  setViewerLabAssignments,
} from "../services/users";
import { useAuthStore } from "../stores/auth.store";
import { useLabs } from "../hooks/useLabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table";
import { Badge } from "../components/ui/badge";
import { Switch } from "../components/ui/switch";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Checkbox } from "../components/ui/checkbox";
import { Skeleton } from "../components/ui/skeleton";
import { EmptyState } from "../components/ui/empty-state";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "../components/ui/dialog";
import { ConfirmDialog } from "../components/ConfirmDialog";

function LabAssignmentFields({
  selectedLabIds,
  onChange,
}: {
  selectedLabIds: string[];
  onChange: (labIds: string[]) => void;
}) {
  const { data: labs } = useLabs();

  function toggle(labId: string, checked: boolean) {
    onChange(checked ? [...selectedLabIds, labId] : selectedLabIds.filter((id) => id !== labId));
  }

  return (
    <div className="space-y-1.5">
      <Label>Assigned labs</Label>
      <p className="text-xs text-muted-foreground">
        This Viewer only sees computers (and their activity/sessions/reports) in the labs checked below.
      </p>
      {!labs || labs.length === 0 ? (
        <p className="text-xs text-muted-foreground">No labs created yet.</p>
      ) : (
        <div className="max-h-40 space-y-2 overflow-y-auto rounded-md border border-border p-3">
          {labs.map((lab) => (
            <label key={lab.id} className="flex items-center gap-2 text-sm">
              <Checkbox
                checked={selectedLabIds.includes(lab.id)}
                onCheckedChange={(checked) => toggle(lab.id, checked === true)}
              />
              {lab.name}
            </label>
          ))}
        </div>
      )}
    </div>
  );
}

function CreateViewerDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [email, setEmail] = useState("");
  const [fullName, setFullName] = useState("");
  const [password, setPassword] = useState("");
  const [labIds, setLabIds] = useState<string[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const profile = useAuthStore((s) => s.profile);
  const queryClient = useQueryClient();

  function reset() {
    setEmail("");
    setFullName("");
    setPassword("");
    setLabIds([]);
  }

  async function handleSubmit() {
    if (!profile) return;
    setSubmitting(true);
    try {
      const viewer = await createViewer({ email, fullName, password });
      if (labIds.length > 0) {
        await setViewerLabAssignments(viewer.id, labIds, profile.id);
      }
      void queryClient.invalidateQueries({ queryKey: ["users"] });
      toast.success("Viewer account created");
      reset();
      onClose();
    } catch (err) {
      toast.error("Failed to create viewer", { description: err instanceof Error ? err.message : undefined });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        if (!next) {
          reset();
          onClose();
        }
      }}
    >
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create viewer</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label>Full name</Label>
            <Input value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Jane Doe" />
          </div>
          <div className="space-y-1.5">
            <Label>Email</Label>
            <Input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="viewer@college.edu"
            />
          </div>
          <div className="space-y-1.5">
            <Label>Temporary password</Label>
            <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} minLength={8} />
          </div>
          <LabAssignmentFields selectedLabIds={labIds} onChange={setLabIds} />
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button
            onClick={() => void handleSubmit()}
            disabled={submitting || !email || !fullName || password.length < 8}
          >
            Create
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function EditViewerDialog({ user, onClose }: { user: Profile | null; onClose: () => void }) {
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [labIds, setLabIds] = useState<string[]>([]);
  const [initialLabIds, setInitialLabIds] = useState<string[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const adminProfile = useAuthStore((s) => s.profile);
  const queryClient = useQueryClient();

  useEffect(() => {
    if (user) {
      setFullName(user.fullName ?? "");
      setEmail(user.email);
      setPassword("");
      void getViewerLabAssignments(user.id).then((ids) => {
        setLabIds(ids);
        setInitialLabIds(ids);
      });
    }
  }, [user]);

  async function handleSubmit() {
    if (!user || !adminProfile) return;
    setSubmitting(true);
    try {
      const patch: { fullName?: string; email?: string; password?: string } = {};
      if (fullName !== (user.fullName ?? "")) patch.fullName = fullName;
      if (email !== user.email) patch.email = email;
      if (password.length > 0) patch.password = password;
      if (Object.keys(patch).length > 0) {
        await editViewer(user.id, patch);
      }
      const labsChanged =
        labIds.length !== initialLabIds.length || labIds.some((id) => !initialLabIds.includes(id));
      if (labsChanged) {
        await setViewerLabAssignments(user.id, labIds, adminProfile.id);
      }
      if (Object.keys(patch).length > 0 || labsChanged) {
        void queryClient.invalidateQueries({ queryKey: ["users"] });
        toast.success("Viewer updated");
      }
      onClose();
    } catch (err) {
      toast.error("Failed to update viewer", { description: err instanceof Error ? err.message : undefined });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog open={Boolean(user)} onOpenChange={(next) => !next && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Edit viewer</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label>Full name</Label>
            <Input value={fullName} onChange={(e) => setFullName(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>Email</Label>
            <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>New password</Label>
            <Input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Leave blank to keep current password"
              minLength={8}
            />
          </div>
          <LabAssignmentFields selectedLabIds={labIds} onChange={setLabIds} />
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={() => void handleSubmit()} disabled={submitting || !fullName || !email}>
            Save changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function Users() {
  const { data: users, isLoading } = useQuery({ queryKey: ["users"], queryFn: listUsers });
  const profile = useAuthStore((s) => s.profile);
  const queryClient = useQueryClient();
  const [createOpen, setCreateOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<Profile | null>(null);
  const [deletingUser, setDeletingUser] = useState<Profile | null>(null);

  async function handleToggleActive(userId: string, isActive: boolean) {
    if (!profile) return;
    try {
      await updateUser(userId, { isActive }, profile.id);
      void queryClient.invalidateQueries({ queryKey: ["users"] });
    } catch (err) {
      toast.error("Failed to update user", { description: err instanceof Error ? err.message : undefined });
    }
  }

  async function handleDelete(user: Profile) {
    try {
      await deleteViewer(user.id);
      void queryClient.invalidateQueries({ queryKey: ["users"] });
      toast.success("Viewer deleted");
    } catch (err) {
      toast.error("Failed to delete viewer", { description: err instanceof Error ? err.message : undefined });
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold">Users</h1>
          <p className="text-sm text-muted-foreground">Manage Viewer accounts. Admin accounts are provisioned separately.</p>
        </div>
        <Button onClick={() => setCreateOpen(true)}>
          <Plus className="h-4 w-4" /> Create viewer
        </Button>
      </div>

      {isLoading ? (
        <Skeleton className="h-64 w-full" />
      ) : !users || users.length === 0 ? (
        <EmptyState icon={UserCog} title="No users found" />
      ) : (
        <div className="rounded-lg border border-border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Last login</TableHead>
                <TableHead>Active</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.map((user) => (
                <TableRow key={user.id}>
                  <TableCell className="font-medium">{user.fullName ?? "—"}</TableCell>
                  <TableCell>{user.email}</TableCell>
                  <TableCell>
                    <Badge variant={user.role === "ADMIN" ? "default" : "secondary"}>{user.role}</Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant={user.isActive ? "default" : "destructive"}>
                      {user.isActive ? "Active" : "Disabled"}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {user.lastLoginAt ? format(new Date(user.lastLoginAt), "PPp") : "Never"}
                  </TableCell>
                  <TableCell>
                    <Switch
                      checked={user.isActive}
                      disabled={user.role === "ADMIN"}
                      onCheckedChange={(checked) => void handleToggleActive(user.id, checked)}
                    />
                  </TableCell>
                  <TableCell className="text-right">
                    {user.role === "VIEWER" && (
                      <div className="flex justify-end gap-1">
                        <Button variant="ghost" size="sm" onClick={() => setEditingUser(user)}>
                          <Pencil className="h-3.5 w-3.5" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-destructive hover:text-destructive"
                          onClick={() => setDeletingUser(user)}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <CreateViewerDialog open={createOpen} onClose={() => setCreateOpen(false)} />
      <EditViewerDialog user={editingUser} onClose={() => setEditingUser(null)} />
      <ConfirmDialog
        open={deletingUser !== null}
        onClose={() => setDeletingUser(null)}
        onConfirm={async () => {
          if (deletingUser) await handleDelete(deletingUser);
        }}
        title={`Delete ${deletingUser?.fullName ?? deletingUser?.email ?? "this viewer"}?`}
        description="This permanently deletes the Viewer's login and profile. This cannot be undone."
        confirmLabel="Delete"
        destructive
      />
    </div>
  );
}
