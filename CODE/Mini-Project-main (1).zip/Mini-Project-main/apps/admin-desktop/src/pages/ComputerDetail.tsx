import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { format, formatDistanceToNow } from "date-fns";
import { ArrowLeft, Lock, LogOut, RotateCcw, Power, Cpu, MemoryStick, RefreshCw, ImageOff } from "lucide-react";
import type { RemoteCommandType } from "@college-monitor/types";
import { StatusBadge } from "@college-monitor/ui";
import { useComputer } from "../hooks/useComputers";
import { useAuthStore } from "../stores/auth.store";
import { listActivityEvents } from "../services/activities";
import { listCommandsForComputer, requestCommand } from "../services/commands";
import { getScreenshotSignedUrl } from "../services/computers";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Skeleton } from "../components/ui/skeleton";
import { Badge } from "../components/ui/badge";
import { ConfirmDialog } from "../components/ConfirmDialog";

const COMMANDS: { type: RemoteCommandType; label: string; icon: typeof Lock; destructive?: boolean }[] = [
  { type: "LOCK", label: "Lock PC", icon: Lock },
  { type: "LOGOUT", label: "Logout", icon: LogOut },
  { type: "RESTART", label: "Restart", icon: RotateCcw, destructive: true },
  { type: "SHUTDOWN", label: "Shutdown", icon: Power, destructive: true },
];

function UsageMeter({ label, value, icon: Icon }: { label: string; value: number | null; icon: typeof Cpu }) {
  const pct = value ?? 0;
  return (
    <div>
      <div className="mb-1 flex items-center justify-between text-xs">
        <span className="flex items-center gap-1.5 text-muted-foreground">
          <Icon className="h-3.5 w-3.5" /> {label}
        </span>
        <span className="font-medium tabular-nums">{value === null ? "—" : `${Math.round(pct)}%`}</span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-muted">
        <div
          className={`h-full ${pct > 85 ? "bg-destructive" : pct > 60 ? "bg-amber-500" : "bg-emerald-500"}`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}

export function ComputerDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { data: computer, isLoading } = useComputer(id);
  const profile = useAuthStore((s) => s.profile);
  const queryClient = useQueryClient();
  const [pendingCommand, setPendingCommand] = useState<RemoteCommandType | null>(null);

  const { data: activity } = useQuery({
    queryKey: ["activities", "computer", id],
    queryFn: () => listActivityEvents({ computerId: id, page: 1, pageSize: 30 }),
    enabled: Boolean(id),
  });

  const { data: commands } = useQuery({
    queryKey: ["commands", id],
    queryFn: () => listCommandsForComputer(id as string),
    enabled: Boolean(id),
  });

  const {
    data: screenshotUrl,
    isFetching: screenshotLoading,
    refetch: refetchScreenshot,
  } = useQuery({
    queryKey: ["screenshot", id, computer?.lastScreenshotAt],
    queryFn: () => getScreenshotSignedUrl(id as string),
    enabled: Boolean(id) && Boolean(computer?.lastScreenshotAt),
  });

  if (isLoading || !computer) {
    return <Skeleton className="h-96 w-full" />;
  }

  async function handleCommand(type: RemoteCommandType) {
    if (!profile || !id) return;
    try {
      await requestCommand(id, type, profile.id);
      void queryClient.invalidateQueries({ queryKey: ["commands", id] });
      toast.success(`${type} command sent`, {
        description: "Delivered on the PC's next heartbeat (within ~15s).",
      });
    } catch (err) {
      toast.error("Failed to send command", { description: err instanceof Error ? err.message : undefined });
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => navigate("/computers")}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-semibold">{computer.name}</h1>
            <StatusBadge status={computer.status} />
          </div>
          <p className="text-sm text-muted-foreground">
            {computer.labName ?? "Unassigned"} · {computer.computerCode}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Computer information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <Row label="Hostname" value={computer.hostname ?? "—"} />
            <Row label="Operating system" value={computer.operatingSystem ?? "—"} />
            <Row label="IP address" value={computer.ipAddress ?? "—"} />
            <Row label="Agent version" value={computer.agentVersion ?? "—"} />
            <Row
              label="Last seen"
              value={
                computer.lastSeenAt
                  ? formatDistanceToNow(new Date(computer.lastSeenAt), { addSuffix: true })
                  : "Never"
              }
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>System usage</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <UsageMeter label="CPU" value={computer.cpuUsage} icon={Cpu} />
            <UsageMeter label="Memory" value={computer.memoryUsage} icon={MemoryStick} />
            <p className="text-[11px] text-muted-foreground">
              Disk and network usage are not collected by the current PC Agent.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Current session</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <Row label="Username" value={computer.currentSessionUsername ?? "No active session"} />
            <Row
              label="Started"
              value={
                computer.currentSessionStartedAt
                  ? format(new Date(computer.currentSessionStartedAt), "PPp")
                  : "—"
              }
            />
            <Row
              label="Duration"
              value={
                computer.currentSessionStartedAt
                  ? formatDistanceToNow(new Date(computer.currentSessionStartedAt))
                  : "—"
              }
            />
            <Row label="Current application" value={computer.currentApplication ?? "—"} />
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Screen</CardTitle>
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">
              {computer.lastScreenshotAt
                ? `Captured ${formatDistanceToNow(new Date(computer.lastScreenshotAt), { addSuffix: true })}`
                : "No screenshot yet"}
            </span>
            <Button variant="ghost" size="icon" onClick={() => void refetchScreenshot()}>
              <RefreshCw className="h-3.5 w-3.5" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {screenshotLoading ? (
            <Skeleton className="h-64 w-full" />
          ) : screenshotUrl ? (
            <img
              src={screenshotUrl}
              alt={`Latest screen capture of ${computer.name}`}
              className="w-full rounded-md border border-border"
            />
          ) : (
            <div className="flex h-48 flex-col items-center justify-center gap-2 rounded-md border border-dashed border-border text-muted-foreground">
              <ImageOff className="h-6 w-6" />
              <p className="text-xs">
                {computer.lastScreenshotAt ? "Screenshot expired or unavailable" : "No screenshot captured yet"}
              </p>
            </div>
          )}
          <p className="mt-2 text-[11px] text-muted-foreground">
            Captured periodically by the agent (not a live feed) — only the most recent capture is kept.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Remote actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {COMMANDS.map((cmd) => (
              <Button
                key={cmd.type}
                variant={cmd.destructive ? "destructive" : "outline"}
                size="sm"
                disabled={computer.status !== "ONLINE"}
                onClick={() => setPendingCommand(cmd.type)}
              >
                <cmd.icon className="h-3.5 w-3.5" /> {cmd.label}
              </Button>
            ))}
            {computer.status !== "ONLINE" && (
              <p className="flex items-center text-xs text-muted-foreground">
                Computer must be online to receive commands.
              </p>
            )}
          </div>

          {commands && commands.length > 0 && (
            <div className="mt-4 space-y-1.5 border-t border-border pt-3">
              {commands.map((c) => (
                <div key={c.id} className="flex items-center justify-between text-xs">
                  <span>
                    {c.commandType} — {format(new Date(c.requestedAt), "PPp")}
                  </span>
                  <Badge
                    variant={
                      c.status === "SUCCEEDED"
                        ? "default"
                        : c.status === "FAILED" || c.status === "TIMED_OUT"
                          ? "destructive"
                          : "secondary"
                    }
                  >
                    {c.status}
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Activity timeline</CardTitle>
        </CardHeader>
        <CardContent>
          {!activity || activity.items.length === 0 ? (
            <p className="text-sm text-muted-foreground">No activity recorded yet.</p>
          ) : (
            <ol className="space-y-3">
              {activity.items.map((event) => (
                <li key={event.id} className="flex gap-3 text-sm">
                  <span className="w-16 shrink-0 tabular-nums text-muted-foreground">
                    {format(new Date(event.occurredAt), "HH:mm:ss")}
                  </span>
                  <span className="flex-1">
                    <span className="font-medium">{event.eventType.replace(/_/g, " ")}</span>
                    {event.applicationName && <span className="text-muted-foreground"> — {event.applicationName}</span>}
                    {typeof event.metadata?.previousApplicationName === "string" && (
                      <span className="text-muted-foreground">
                        {" "}
                        ({event.metadata.previousApplicationName} → {event.applicationName})
                      </span>
                    )}
                  </span>
                </li>
              ))}
            </ol>
          )}
        </CardContent>
      </Card>

      <ConfirmDialog
        open={pendingCommand !== null}
        onClose={() => setPendingCommand(null)}
        onConfirm={async () => {
          if (pendingCommand) await handleCommand(pendingCommand);
        }}
        title={`${pendingCommand ?? ""} ${computer.name}?`}
        description={`This will send a ${pendingCommand?.toLowerCase()} command to the computer's PC Agent. It will be picked up on its next heartbeat.`}
        confirmLabel={pendingCommand ?? "Confirm"}
        destructive={pendingCommand === "RESTART" || pendingCommand === "SHUTDOWN"}
      />
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium">{value}</span>
    </div>
  );
}
