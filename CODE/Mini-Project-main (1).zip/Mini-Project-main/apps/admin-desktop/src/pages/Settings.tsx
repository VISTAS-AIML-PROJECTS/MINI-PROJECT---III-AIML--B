import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { getMonitoringSettings, updateMonitoringSettings } from "../services/settings";
import { useAuthStore } from "../stores/auth.store";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Button } from "../components/ui/button";
import { Skeleton } from "../components/ui/skeleton";

export function Settings() {
  const { data, isLoading } = useQuery({ queryKey: ["settings", "monitoring"], queryFn: getMonitoringSettings });
  const profile = useAuthStore((s) => s.profile);
  const queryClient = useQueryClient();
  const [form, setForm] = useState(data);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (data) setForm(data);
  }, [data]);

  async function handleSave() {
    if (!form || !profile) return;
    setSaving(true);
    try {
      await updateMonitoringSettings(form, profile.id);
      void queryClient.invalidateQueries({ queryKey: ["settings", "monitoring"] });
      toast.success("Settings saved");
    } catch (err) {
      toast.error("Failed to save settings", { description: err instanceof Error ? err.message : undefined });
    } finally {
      setSaving(false);
    }
  }

  if (isLoading || !form) return <Skeleton className="h-96 w-full" />;

  return (
    <div className="max-w-xl space-y-6">
      <div>
        <h1 className="text-xl font-semibold">Settings</h1>
        <p className="text-sm text-muted-foreground">Monitoring thresholds and data retention.</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Monitoring</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Field
            label="Heartbeat interval (seconds)"
            value={form.heartbeatIntervalSeconds}
            onChange={(v) => setForm({ ...form, heartbeatIntervalSeconds: v })}
          />
          <Field
            label="Offline threshold (seconds)"
            value={form.offlineThresholdSeconds}
            onChange={(v) => setForm({ ...form, offlineThresholdSeconds: v })}
          />
          <Field
            label="Activity retention (days)"
            value={form.activityRetentionDays}
            onChange={(v) => setForm({ ...form, activityRetentionDays: v })}
          />
          <Field
            label="Audit log retention (days)"
            value={form.auditRetentionDays}
            onChange={(v) => setForm({ ...form, auditRetentionDays: v })}
          />
          <p className="text-xs text-muted-foreground">
            Retention is configuration only — no dashboard control deletes audit logs. Cleanup, if enabled,
            runs as a controlled backend job (see docs/deployment.md).
          </p>
          <Button onClick={() => void handleSave()} disabled={saving}>
            Save changes
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
}: {
  label: string;
  value: number;
  onChange: (value: number) => void;
}) {
  return (
    <div className="space-y-1.5">
      <Label>{label}</Label>
      <Input
        type="number"
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
      />
    </div>
  );
}
