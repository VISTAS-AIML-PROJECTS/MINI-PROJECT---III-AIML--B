import { useMemo, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { Plus, Monitor, Settings2, Power } from "lucide-react";
import type { Computer, ComputerLive } from "@college-monitor/types";
import { StatusBadge } from "@college-monitor/ui";
import { useComputers } from "../hooks/useComputers";
import { useLabs } from "../hooks/useLabs";
import { useAuthStore } from "../stores/auth.store";
import { setComputerEnabled } from "../services/computers";
import { requestBulkCommand } from "../services/commands";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Switch } from "../components/ui/switch";
import { Skeleton } from "../components/ui/skeleton";
import { EmptyState } from "../components/ui/empty-state";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table";
import { RegisterComputerDialog } from "../components/RegisterComputerDialog";
import { ManageComputerDialog } from "../components/ManageComputerDialog";
import { ConfirmDialog } from "../components/ConfirmDialog";

const UNASSIGNED_KEY = "__unassigned__";

interface LabGroup {
  key: string;
  name: string;
  computers: ComputerLive[];
}

export function Computers() {
  const { data: computers, isLoading } = useComputers();
  const { data: labs } = useLabs();
  const [registerOpen, setRegisterOpen] = useState(false);
  const [managing, setManaging] = useState<Computer | null>(null);
  const [shutdownGroup, setShutdownGroup] = useState<LabGroup | null>(null);
  const profile = useAuthStore((s) => s.profile);
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const groups = useMemo<LabGroup[]>(() => {
    if (!computers) return [];
    const byLab = new Map<string, LabGroup>();

    for (const lab of labs ?? []) {
      byLab.set(lab.id, { key: lab.id, name: lab.name, computers: [] });
    }

    for (const computer of computers) {
      const key = computer.labId ?? UNASSIGNED_KEY;
      let group = byLab.get(key);
      if (!group) {
        group = { key, name: computer.labName ?? "Unassigned", computers: [] };
        byLab.set(key, group);
      }
      group.computers.push(computer);
    }

    const ordered = [...byLab.values()].filter((g) => g.computers.length > 0 || g.key !== UNASSIGNED_KEY);
    ordered.sort((a, b) => {
      if (a.key === UNASSIGNED_KEY) return 1;
      if (b.key === UNASSIGNED_KEY) return -1;
      return a.name.localeCompare(b.name);
    });
    return ordered;
  }, [computers, labs]);

  async function handleToggleEnabled(computer: Computer) {
    if (!profile) return;
    try {
      await setComputerEnabled(computer.id, !computer.isEnabled, profile.id);
      void queryClient.invalidateQueries({ queryKey: ["computers"] });
      toast.success(computer.isEnabled ? "Computer disabled" : "Computer enabled");
    } catch (err) {
      toast.error("Failed to update computer", { description: err instanceof Error ? err.message : undefined });
    }
  }

  async function handleShutdownLab(group: LabGroup) {
    if (!profile) return;
    const onlineIds = group.computers.filter((c) => c.status === "ONLINE").map((c) => c.id);
    if (onlineIds.length === 0) return;
    try {
      await requestBulkCommand(onlineIds, "SHUTDOWN", profile.id);
      void queryClient.invalidateQueries({ queryKey: ["commands"] });
      toast.success(`Shutdown sent to ${onlineIds.length} computer${onlineIds.length === 1 ? "" : "s"}`, {
        description: `${group.name} — delivered on each PC's next heartbeat (within ~15s).`,
      });
    } catch (err) {
      toast.error("Failed to shut down lab", { description: err instanceof Error ? err.message : undefined });
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold">Computers</h1>
          <p className="text-sm text-muted-foreground">Register, rename, and manage lab computers.</p>
        </div>
        <Button onClick={() => setRegisterOpen(true)}>
          <Plus className="h-4 w-4" /> Register PC
        </Button>
      </div>

      {isLoading ? (
        <Skeleton className="h-96 w-full" />
      ) : !computers || computers.length === 0 ? (
        <EmptyState
          icon={Monitor}
          title="No computers registered yet"
          description="Register your first computer to get a one-time code for its PC Agent."
          action={
            <Button size="sm" onClick={() => setRegisterOpen(true)}>
              Register PC
            </Button>
          }
        />
      ) : (
        <div className="space-y-6">
          {groups.map((group) => {
            const onlineCount = group.computers.filter((c) => c.status === "ONLINE").length;
            return (
              <div key={group.key} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <h2 className="text-sm font-semibold">{group.name}</h2>
                    <Badge variant="secondary">{group.computers.length} PC{group.computers.length === 1 ? "" : "s"}</Badge>
                    {onlineCount > 0 && (
                      <Badge className="bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
                        {onlineCount} online
                      </Badge>
                    )}
                  </div>
                  <Button
                    variant="destructive"
                    size="sm"
                    disabled={onlineCount === 0}
                    onClick={() => setShutdownGroup(group)}
                  >
                    <Power className="h-3.5 w-3.5" /> Shut down all
                  </Button>
                </div>

                <div className="rounded-lg border border-border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Code</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Agent Version</TableHead>
                        <TableHead>Enabled</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {group.computers.map((computer) => (
                        <TableRow
                          key={computer.id}
                          className="cursor-pointer"
                          onClick={() => navigate(`/computers/${computer.id}`)}
                        >
                          <TableCell className="font-medium">{computer.name}</TableCell>
                          <TableCell className="font-mono text-xs text-muted-foreground">
                            {computer.computerCode}
                          </TableCell>
                          <TableCell>
                            <StatusBadge status={computer.status} />
                          </TableCell>
                          <TableCell className="text-muted-foreground">{computer.agentVersion ?? "—"}</TableCell>
                          <TableCell onClick={(e) => e.stopPropagation()}>
                            <Switch
                              checked={computer.isEnabled}
                              onCheckedChange={() => void handleToggleEnabled(computer)}
                            />
                          </TableCell>
                          <TableCell className="text-right" onClick={(e) => e.stopPropagation()}>
                            <Button variant="ghost" size="sm" onClick={() => setManaging(computer)}>
                              <Settings2 className="h-3.5 w-3.5" /> Manage
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <RegisterComputerDialog open={registerOpen} onClose={() => setRegisterOpen(false)} />
      <ManageComputerDialog computer={managing} onClose={() => setManaging(null)} />

      <ConfirmDialog
        open={shutdownGroup !== null}
        onClose={() => setShutdownGroup(null)}
        onConfirm={async () => {
          if (shutdownGroup) await handleShutdownLab(shutdownGroup);
        }}
        title={`Shut down all computers in ${shutdownGroup?.name}?`}
        description={`This sends a shutdown command to every online computer in this lab (${
          shutdownGroup?.computers.filter((c) => c.status === "ONLINE").length ?? 0
        } PC${(shutdownGroup?.computers.filter((c) => c.status === "ONLINE").length ?? 0) === 1 ? "" : "s"}). Each will shut down on its next heartbeat, within ~15 seconds.`}
        confirmLabel="Shut down all"
        destructive
      />
    </div>
  );
}
