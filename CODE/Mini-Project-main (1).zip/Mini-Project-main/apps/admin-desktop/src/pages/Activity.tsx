import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import type { ActivityFiltersInput } from "@college-monitor/validation";
import { ACTIVITY_EVENT_TYPES } from "@college-monitor/types";
import { listActivityEvents } from "../services/activities";
import { useComputers } from "../hooks/useComputers";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Button } from "../components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../components/ui/table";
import { Skeleton } from "../components/ui/skeleton";
import { EmptyState } from "../components/ui/empty-state";
import { Activity as ActivityIcon } from "lucide-react";

const ALL = "__all__";
const PAGE_SIZE = 25;

export function ActivityPage() {
  const [computerId, setComputerId] = useState(ALL);
  const [eventType, setEventType] = useState(ALL);
  const [page, setPage] = useState(1);
  const { data: computers } = useComputers();

  const filters: ActivityFiltersInput = {
    page,
    pageSize: PAGE_SIZE,
    computerId: computerId === ALL ? undefined : computerId,
    eventType: eventType === ALL ? undefined : (eventType as ActivityFiltersInput["eventType"]),
  };

  const { data, isLoading } = useQuery({
    queryKey: ["activities", filters],
    queryFn: () => listActivityEvents(filters),
  });

  const totalPages = data ? Math.max(1, Math.ceil(data.total / PAGE_SIZE)) : 1;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold">Activity</h1>
        <p className="text-sm text-muted-foreground">Application switches, session and PC lifecycle events.</p>
      </div>

      <div className="flex flex-wrap gap-3">
        <Select
          value={computerId}
          onValueChange={(v) => {
            setComputerId(v);
            setPage(1);
          }}
        >
          <SelectTrigger className="w-48">
            <SelectValue placeholder="All computers" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL}>All computers</SelectItem>
            {computers?.map((c) => (
              <SelectItem key={c.id} value={c.id}>
                {c.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select
          value={eventType}
          onValueChange={(v) => {
            setEventType(v);
            setPage(1);
          }}
        >
          <SelectTrigger className="w-48">
            <SelectValue placeholder="All event types" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={ALL}>All event types</SelectItem>
            {ACTIVITY_EVENT_TYPES.map((type) => (
              <SelectItem key={type} value={type}>
                {type.replace(/_/g, " ")}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <Skeleton className="h-96 w-full" />
      ) : !data || data.items.length === 0 ? (
        <EmptyState icon={ActivityIcon} title="No activity found" description="Try adjusting your filters." />
      ) : (
        <>
          <div className="rounded-lg border border-border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Time</TableHead>
                  <TableHead>PC</TableHead>
                  <TableHead>Event</TableHead>
                  <TableHead>Application</TableHead>
                  <TableHead>Window</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.items.map((event) => (
                  <TableRow key={event.id}>
                    <TableCell className="whitespace-nowrap text-xs text-muted-foreground">
                      {format(new Date(event.occurredAt), "PP HH:mm:ss")}
                    </TableCell>
                    <TableCell>{event.computerName}</TableCell>
                    <TableCell>{event.eventType.replace(/_/g, " ")}</TableCell>
                    <TableCell>{event.applicationName ?? "—"}</TableCell>
                    <TableCell className="max-w-64 truncate text-xs text-muted-foreground">
                      {event.windowTitle ?? "—"}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          <div className="flex items-center justify-between">
            <p className="text-xs text-muted-foreground">
              Page {page} of {totalPages} · {data.total} events
            </p>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
                Previous
              </Button>
              <Button
                variant="outline"
                size="sm"
                disabled={page >= totalPages}
                onClick={() => setPage((p) => p + 1)}
              >
                Next
              </Button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
