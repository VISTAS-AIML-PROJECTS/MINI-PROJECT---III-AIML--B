import { createHashRouter } from "react-router-dom";
import { AppLayout } from "./layouts/AppLayout";
import { RequireAuth } from "./components/RequireAuth";
import { Login } from "./pages/Login";
import { Dashboard } from "./pages/Dashboard";
import { Computers } from "./pages/Computers";
import { ComputerDetail } from "./pages/ComputerDetail";
import { Labs } from "./pages/Labs";
import { ActivityPage } from "./pages/Activity";
import { Applications } from "./pages/Applications";
import { Sessions } from "./pages/Sessions";
import { Reports } from "./pages/Reports";
import { AuditLogs } from "./pages/AuditLogs";
import { Users } from "./pages/Users";
import { Settings } from "./pages/Settings";
import { APP_ROUTES } from "@college-monitor/config";

export const router = createHashRouter([
  { path: APP_ROUTES.LOGIN, element: <Login /> },
  {
    element: <RequireAuth />,
    children: [
      {
        element: <AppLayout />,
        children: [
          { path: APP_ROUTES.DASHBOARD, element: <Dashboard /> },
          { path: APP_ROUTES.COMPUTERS, element: <Computers /> },
          { path: "/computers/:id", element: <ComputerDetail /> },
          { path: APP_ROUTES.LABS, element: <Labs /> },
          { path: APP_ROUTES.ACTIVITY, element: <ActivityPage /> },
          { path: APP_ROUTES.APPLICATIONS, element: <Applications /> },
          { path: APP_ROUTES.SESSIONS, element: <Sessions /> },
          { path: APP_ROUTES.REPORTS, element: <Reports /> },
          { path: APP_ROUTES.AUDIT_LOGS, element: <AuditLogs /> },
          { path: APP_ROUTES.USERS, element: <Users /> },
          { path: APP_ROUTES.SETTINGS, element: <Settings /> },
        ],
      },
    ],
  },
]);
