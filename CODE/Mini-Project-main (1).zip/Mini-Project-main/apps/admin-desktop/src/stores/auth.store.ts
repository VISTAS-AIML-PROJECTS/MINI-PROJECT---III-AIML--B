import { create } from "zustand";
import type { Profile } from "@college-monitor/types";
import { supabase } from "../lib/supabase";

interface ProfileRow {
  id: string;
  email: string;
  full_name: string | null;
  role: Profile["role"];
  is_active: boolean;
  last_login_at: string | null;
  created_at: string;
  updated_at: string;
}

function toProfile(row: ProfileRow): Profile {
  return {
    id: row.id,
    email: row.email,
    fullName: row.full_name,
    role: row.role,
    isActive: row.is_active,
    lastLoginAt: row.last_login_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

interface AuthState {
  status: "loading" | "signed-out" | "signed-in" | "unauthorized";
  profile: Profile | null;
  error: string | null;
  initialize: () => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
}

async function loadProfileForCurrentSession(): Promise<Profile | null> {
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return null;

  const { data, error } = await supabase
    .from("profiles")
    .select("id, email, full_name, role, is_active, last_login_at, created_at, updated_at")
    .eq("id", user.id)
    .maybeSingle<ProfileRow>();

  if (error || !data) return null;
  return toProfile(data);
}

export const useAuthStore = create<AuthState>((set) => ({
  status: "loading",
  profile: null,
  error: null,

  initialize: async () => {
    const profile = await loadProfileForCurrentSession();
    if (!profile) {
      set({ status: "signed-out", profile: null });
    } else if (!profile.isActive) {
      await supabase.auth.signOut();
      set({ status: "unauthorized", profile: null, error: "This account has been disabled." });
    } else if (profile.role !== "ADMIN") {
      await supabase.auth.signOut();
      set({
        status: "unauthorized",
        profile: null,
        error: "This app is for Admin accounts only. Use College PC Viewer instead.",
      });
    } else {
      set({ status: "signed-in", profile });
    }

    supabase.auth.onAuthStateChange((event) => {
      if (event === "SIGNED_OUT") {
        set({ status: "signed-out", profile: null });
      }
    });
  },

  signIn: async (email: string, password: string) => {
    set({ error: null, status: "loading" });
    const { error: signInError } = await supabase.auth.signInWithPassword({ email, password });
    if (signInError) {
      set({ status: "signed-out", error: signInError.message });
      return;
    }

    const profile = await loadProfileForCurrentSession();
    if (!profile) {
      await supabase.auth.signOut();
      set({ status: "signed-out", error: "No profile found for this account." });
      return;
    }
    if (!profile.isActive) {
      await supabase.auth.signOut();
      set({ status: "unauthorized", error: "This account has been disabled." });
      return;
    }
    if (profile.role !== "ADMIN") {
      await supabase.auth.signOut();
      set({
        status: "unauthorized",
        error: "This app is for Admin accounts only. Use College PC Viewer instead.",
      });
      return;
    }

    set({ status: "signed-in", profile, error: null });
  },

  signOut: async () => {
    await supabase.auth.signOut();
    set({ status: "signed-out", profile: null });
  },
}));
