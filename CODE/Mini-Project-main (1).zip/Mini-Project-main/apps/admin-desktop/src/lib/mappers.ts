import type {
  Application,
  ApplicationActivity,
  Computer,
  Lab,
  Session,
  ActivityEvent,
  AuditLog,
  RemoteCommand,
} from "@college-monitor/types";

export function mapLab(row: any): Lab {
  return {
    id: row.id,
    name: row.name,
    building: row.building,
    room: row.room,
    description: row.description,
    isActive: row.is_active,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export function mapComputer(row: any): Computer {
  return {
    id: row.id,
    computerCode: row.computer_code,
    name: row.name,
    labId: row.lab_id,
    hostname: row.hostname,
    ipAddress: row.ip_address,
    operatingSystem: row.operating_system,
    agentVersion: row.agent_version,
    status: row.status,
    lastSeenAt: row.last_seen_at,
    cpuUsage: row.cpu_usage === null || row.cpu_usage === undefined ? null : Number(row.cpu_usage),
    memoryUsage:
      row.memory_usage === null || row.memory_usage === undefined ? null : Number(row.memory_usage),
    lastScreenshotAt: row.last_screenshot_at ?? null,
    isEnabled: row.is_enabled,
    registeredAt: row.registered_at,
    updatedAt: row.updated_at,
  };
}

export function mapSession(row: any): Session {
  return {
    id: row.id,
    computerId: row.computer_id,
    username: row.username,
    startedAt: row.started_at,
    endedAt: row.ended_at,
    isActive: row.is_active,
  };
}

export function mapApplication(row: any): Application {
  return {
    id: row.id,
    name: row.name,
    executableName: row.executable_name,
    publisher: row.publisher,
    createdAt: row.created_at,
  };
}

export function mapApplicationActivity(row: any): ApplicationActivity {
  return {
    id: row.id,
    computerId: row.computer_id,
    sessionId: row.session_id,
    applicationId: row.application_id,
    applicationName: row.applications?.name,
    windowTitle: row.window_title,
    startedAt: row.started_at,
    endedAt: row.ended_at,
    durationSeconds: row.duration_seconds,
    createdAt: row.created_at,
  };
}

export function mapActivityEvent(row: any): ActivityEvent {
  return {
    id: row.id,
    computerId: row.computer_id,
    sessionId: row.session_id,
    eventType: row.event_type,
    applicationName: row.application_name,
    windowTitle: row.window_title,
    metadata: row.metadata,
    occurredAt: row.occurred_at,
  };
}

export function mapAuditLog(row: any): AuditLog {
  return {
    id: row.id,
    adminId: row.admin_id,
    adminEmail: row.profiles?.email,
    action: row.action,
    computerId: row.computer_id,
    metadata: row.metadata,
    createdAt: row.created_at,
  };
}

export function mapRemoteCommand(row: any): RemoteCommand {
  return {
    id: row.id,
    computerId: row.computer_id,
    requestedBy: row.requested_by,
    commandType: row.command_type,
    status: row.status,
    requestedAt: row.requested_at,
    executedAt: row.executed_at,
    result: row.result,
  };
}
