import type { Lab } from "@college-monitor/types";
import type { CreateLabInput, UpdateLabInput } from "@college-monitor/validation";
import { supabase } from "../lib/supabase";
import { mapLab } from "../lib/mappers";

export async function listLabs(): Promise<Lab[]> {
  const { data, error } = await supabase.from("labs").select("*").order("name");
  if (error) throw error;
  return (data ?? []).map(mapLab);
}

export async function createLab(input: CreateLabInput): Promise<Lab> {
  const { data, error } = await supabase
    .from("labs")
    .insert({
      name: input.name,
      building: input.building ?? null,
      room: input.room ?? null,
      description: input.description ?? null,
    })
    .select()
    .single();
  if (error) throw error;
  return mapLab(data);
}

export async function updateLab(id: string, input: UpdateLabInput): Promise<Lab> {
  const patch: Record<string, unknown> = {};
  if (input.name !== undefined) patch.name = input.name;
  if (input.building !== undefined) patch.building = input.building;
  if (input.room !== undefined) patch.room = input.room;
  if (input.description !== undefined) patch.description = input.description;
  if (input.isActive !== undefined) patch.is_active = input.isActive;

  const { data, error } = await supabase.from("labs").update(patch).eq("id", id).select().single();
  if (error) throw error;
  return mapLab(data);
}
