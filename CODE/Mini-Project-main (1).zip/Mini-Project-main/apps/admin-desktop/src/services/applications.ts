import type { ApplicationUsageSummary } from "@college-monitor/types";
import { supabase } from "../lib/supabase";

// application_activity can grow into the millions, so usage is aggregated
// with a Postgres RPC rather than pulled client-side. See
// supabase/migrations/0007_reporting_functions.sql for
// application_usage_summary().
export async function listApplicationUsage(): Promise<ApplicationUsageSummary[]> {
  const { data, error } = await supabase.rpc("application_usage_summary");
  if (error) throw error;

  return (data ?? []).map((row: any) => ({
    applicationId: row.application_id,
    applicationName: row.application_name,
    totalUsageSeconds: Number(row.total_usage_seconds),
    computerCount: Number(row.computer_count),
    sessionCount: Number(row.session_count),
    averageDurationSeconds: Number(row.average_duration_seconds),
  }));
}
