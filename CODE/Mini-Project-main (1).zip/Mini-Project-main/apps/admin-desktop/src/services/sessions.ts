import type { Session } from "@college-monitor/types";
import { supabase } from "../lib/supabase";
import { mapSession } from "../lib/mappers";

export interface SessionWithComputer extends Session {
  computerName: string;
}

export async function listSessions(params: { page: number; pageSize: number }): Promise<{
  items: SessionWithComputer[];
  total: number;
}> {
  const from = (params.page - 1) * params.pageSize;
  const to = from + params.pageSize - 1;

  const { data, error, count } = await supabase
    .from("sessions")
    .select("*, computers(name)", { count: "exact" })
    .order("started_at", { ascending: false })
    .range(from, to);
  if (error) throw error;

  return {
    items: (data ?? []).map((row: any) => ({
      ...mapSession(row),
      computerName: row.computers?.name ?? "Unknown",
    })),
    total: count ?? 0,
  };
}
