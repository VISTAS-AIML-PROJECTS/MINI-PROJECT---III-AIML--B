import type { ActivityEvent } from "@college-monitor/types";
import type { ActivityFiltersInput } from "@college-monitor/validation";
import { supabase } from "../lib/supabase";
import { mapActivityEvent } from "../lib/mappers";

export interface ActivityEventWithComputer extends ActivityEvent {
  computerName: string;
}

export async function getTodayActivityCount(): Promise<number> {
  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);

  const { count, error } = await supabase
    .from("activity_events")
    .select("*", { count: "exact", head: true })
    .gte("occurred_at", startOfDay.toISOString());
  if (error) throw error;
  return count ?? 0;
}

export async function listActivityEvents(
  filters: ActivityFiltersInput,
): Promise<{ items: ActivityEventWithComputer[]; total: number }> {
  const from = (filters.page - 1) * filters.pageSize;
  const to = from + filters.pageSize - 1;

  let query = supabase
    .from("activity_events")
    .select("*, computers!inner(name, lab_id)", { count: "exact" })
    .order("occurred_at", { ascending: false })
    .range(from, to);

  if (filters.computerId) query = query.eq("computer_id", filters.computerId);
  if (filters.labId) query = query.eq("computers.lab_id", filters.labId);
  if (filters.applicationName) query = query.ilike("application_name", `%${filters.applicationName}%`);
  if (filters.eventType) query = query.eq("event_type", filters.eventType);
  if (filters.dateFrom) query = query.gte("occurred_at", filters.dateFrom);
  if (filters.dateTo) query = query.lte("occurred_at", filters.dateTo);

  const { data, error, count } = await query;
  if (error) throw error;

  return {
    items: (data ?? []).map((row: any) => ({
      ...mapActivityEvent(row),
      computerName: row.computers?.name ?? "Unknown",
    })),
    total: count ?? 0,
  };
}
