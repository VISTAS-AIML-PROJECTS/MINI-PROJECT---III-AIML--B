import type { MonitoringSettings } from "@college-monitor/types";
import type { MonitoringSettingsInput } from "@college-monitor/validation";
import { DEFAULT_SCREENSHOT_INTERVAL_SECONDS } from "@college-monitor/config";
import { supabase } from "../lib/supabase";
import { writeAuditLog } from "./audit";

const DEFAULTS: MonitoringSettings = {
  heartbeatIntervalSeconds: 15,
  offlineThresholdSeconds: 45,
  activityRetentionDays: 90,
  auditRetentionDays: 365,
  screenshotIntervalSeconds: DEFAULT_SCREENSHOT_INTERVAL_SECONDS,
};

export async function getMonitoringSettings(): Promise<MonitoringSettings> {
  const { data, error } = await supabase
    .from("system_settings")
    .select("value")
    .eq("key", "monitoring")
    .maybeSingle();
  if (error) throw error;
  return { ...DEFAULTS, ...(data?.value as Partial<MonitoringSettings> | undefined) };
}

export async function updateMonitoringSettings(
  input: MonitoringSettingsInput,
  adminId: string,
): Promise<MonitoringSettings> {
  const { error } = await supabase.from("system_settings").upsert(
    {
      key: "monitoring",
      value: input,
      updated_by: adminId,
      updated_at: new Date().toISOString(),
    },
    { onConflict: "key" },
  );
  if (error) throw error;

  await writeAuditLog({ adminId, action: "SETTINGS_UPDATED", metadata: input });
  return input;
}
