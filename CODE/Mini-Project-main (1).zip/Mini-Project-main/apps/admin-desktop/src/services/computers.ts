import bcrypt from "bcryptjs";
import type { Computer, ComputerLive } from "@college-monitor/types";
import type { CreateComputerInput, UpdateComputerInput } from "@college-monitor/validation";
import { supabase } from "../lib/supabase";
import { mapComputer } from "../lib/mappers";
import { writeAuditLog } from "./audit";

function generateComputerCode(name: string): string {
  const slug = name
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
  const suffix = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `${slug || "PC"}-${suffix}`;
}

function generateRawCode(): string {
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}

export async function listComputers(): Promise<ComputerLive[]> {
  const { data, error } = await supabase
    .from("computers")
    .select("*, labs(name), sessions(username, started_at, is_active), application_activity(started_at, ended_at, applications(name))")
    .order("name");
  if (error) throw error;

  return (data ?? []).map((row: any) => {
    const activeSession = (row.sessions ?? []).find((s: any) => s.is_active);
    const openActivity = (row.application_activity ?? []).find((a: any) => a.ended_at === null);
    return {
      ...mapComputer(row),
      labName: row.labs?.name ?? null,
      currentApplication: openActivity?.applications?.name ?? null,
      currentSessionUsername: activeSession?.username ?? null,
      currentSessionStartedAt: activeSession?.started_at ?? null,
    } satisfies ComputerLive;
  });
}

export async function getComputer(id: string): Promise<ComputerLive> {
  const { data, error } = await supabase
    .from("computers")
    .select(
      "*, labs(name), sessions(id, username, started_at, ended_at, is_active), application_activity(id, started_at, ended_at, window_title, applications(name))",
    )
    .eq("id", id)
    .single();
  if (error) throw error;

  const activeSession = (data.sessions ?? []).find((s: any) => s.is_active);
  const openActivity = (data.application_activity ?? []).find((a: any) => a.ended_at === null);

  return {
    ...mapComputer(data),
    labName: data.labs?.name ?? null,
    currentApplication: openActivity?.applications?.name ?? null,
    currentSessionUsername: activeSession?.username ?? null,
    currentSessionStartedAt: activeSession?.started_at ?? null,
  };
}

export async function createComputer(
  input: CreateComputerInput,
  adminId: string,
): Promise<{ computer: Computer; registrationCode: string; expiresAt: string }> {
  const computerCode = generateComputerCode(input.name);

  const { data: computer, error } = await supabase
    .from("computers")
    .insert({
      computer_code: computerCode,
      name: input.name,
      lab_id: input.labId ?? null,
      status: "OFFLINE",
      is_enabled: true,
    })
    .select()
    .single();
  if (error) throw error;

  const { registrationCode, expiresAt } = await issueRegistrationCode(computer.id, adminId);

  await writeAuditLog({
    adminId,
    action: "COMPUTER_REGISTERED",
    computerId: computer.id,
    metadata: { name: input.name, computerCode },
  });

  return { computer: mapComputer(computer), registrationCode, expiresAt };
}

export async function issueRegistrationCode(
  computerId: string,
  adminId: string,
): Promise<{ registrationCode: string; expiresAt: string }> {
  const rawCode = generateRawCode();
  const codeHash = await bcrypt.hash(rawCode, 10);
  const expiresAt = new Date(Date.now() + 30 * 60 * 1000).toISOString();

  const { data, error } = await supabase
    .from("computer_registration_codes")
    .insert({ computer_id: computerId, code_hash: codeHash, issued_by: adminId, expires_at: expiresAt })
    .select("id")
    .single();
  if (error) throw error;

  return { registrationCode: `${data.id}.${rawCode}`, expiresAt };
}

export async function updateComputer(
  id: string,
  input: UpdateComputerInput,
  adminId: string,
): Promise<Computer> {
  const patch: Record<string, unknown> = {};
  if (input.name !== undefined) patch.name = input.name;
  if (input.labId !== undefined) patch.lab_id = input.labId;

  const { data, error } = await supabase.from("computers").update(patch).eq("id", id).select().single();
  if (error) throw error;

  await writeAuditLog({ adminId, action: "COMPUTER_UPDATED", computerId: id, metadata: input });
  return mapComputer(data);
}

export async function setComputerEnabled(
  id: string,
  isEnabled: boolean,
  adminId: string,
): Promise<Computer> {
  const { data, error } = await supabase
    .from("computers")
    .update({ is_enabled: isEnabled, status: isEnabled ? "OFFLINE" : "DISABLED" })
    .eq("id", id)
    .select()
    .single();
  if (error) throw error;

  await writeAuditLog({
    adminId,
    action: isEnabled ? "COMPUTER_ENABLED" : "COMPUTER_DISABLED",
    computerId: id,
  });
  return mapComputer(data);
}

// Cascades to that computer's sessions, activity, credentials, and
// registration codes (see the FK constraints in
// supabase/migrations/0001_init_schema.sql). Audit log rows referencing
// it are kept — computer_id there is ON DELETE SET NULL, never CASCADE —
// so history of what happened isn't lost, even though the computer is.
export async function deleteComputer(
  computer: Pick<Computer, "id" | "name" | "computerCode">,
  adminId: string,
): Promise<void> {
  const { error } = await supabase.from("computers").delete().eq("id", computer.id);
  if (error) throw error;

  await writeAuditLog({
    adminId,
    action: "COMPUTER_DELETED",
    metadata: { computerId: computer.id, name: computer.name, computerCode: computer.computerCode },
  });
}

// Screenshots live in a private storage bucket — only a short-lived
// signed URL is ever handed to the renderer, never a public link.
export async function getScreenshotSignedUrl(computerId: string): Promise<string | null> {
  const { data, error } = await supabase.storage
    .from("screenshots")
    .createSignedUrl(`${computerId}/latest.jpg`, 60);
  if (error) return null;
  return data.signedUrl;
}

export async function revokeCredentials(computerId: string, adminId: string): Promise<void> {
  const { error } = await supabase
    .from("computer_credentials")
    .update({ revoked_at: new Date().toISOString() })
    .eq("computer_id", computerId)
    .is("revoked_at", null);
  if (error) throw error;

  await writeAuditLog({ adminId, action: "COMPUTER_CREDENTIAL_REVOKED", computerId });
}
