import type {
  ActivityReportPoint,
  ApplicationReportPoint,
  ComputerUtilizationPoint,
  ReportFilters,
  SessionStatisticsPoint,
} from "@college-monitor/types";
import { supabase } from "../lib/supabase";

export async function getActivityReport(filters: ReportFilters): Promise<ActivityReportPoint[]> {
  const { data, error } = await supabase.rpc("activity_report", {
    date_from: filters.dateFrom,
    date_to: filters.dateTo,
    p_lab_id: filters.labId ?? null,
    p_computer_id: filters.computerId ?? null,
  });
  if (error) throw error;
  return (data ?? []).map((row: any) => ({
    date: row.day,
    eventCount: Number(row.event_count),
    activeComputerCount: Number(row.active_computer_count),
  }));
}

export async function getApplicationUsageReport(
  filters: ReportFilters,
): Promise<ApplicationReportPoint[]> {
  const { data, error } = await supabase.rpc("application_usage_report", {
    date_from: filters.dateFrom,
    date_to: filters.dateTo,
    p_lab_id: filters.labId ?? null,
    p_computer_id: filters.computerId ?? null,
  });
  if (error) throw error;
  return (data ?? []).map((row: any) => ({
    applicationName: row.application_name,
    usageSeconds: Number(row.usage_seconds),
    sessionCount: Number(row.session_count),
  }));
}

export async function getComputerUtilizationReport(
  filters: ReportFilters,
): Promise<ComputerUtilizationPoint[]> {
  const { data, error } = await supabase.rpc("computer_utilization_report", {
    date_from: filters.dateFrom,
    date_to: filters.dateTo,
    p_lab_id: filters.labId ?? null,
  });
  if (error) throw error;
  return (data ?? []).map((row: any) => ({
    computerId: row.computer_id,
    computerName: row.computer_name,
    onlineSeconds: Number(row.online_seconds),
    offlineSeconds: Number(row.offline_seconds),
    uptimePercentage: Number(row.uptime_percentage),
  }));
}

export async function getSessionStatisticsReport(
  filters: ReportFilters,
): Promise<SessionStatisticsPoint[]> {
  const { data, error } = await supabase.rpc("session_statistics_report", {
    date_from: filters.dateFrom,
    date_to: filters.dateTo,
  });
  if (error) throw error;
  return (data ?? []).map((row: any) => ({
    date: row.day,
    sessionCount: Number(row.session_count),
    averageDurationSeconds: Number(row.average_duration_seconds),
  }));
}
