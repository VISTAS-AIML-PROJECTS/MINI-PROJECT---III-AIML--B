import type { Profile } from "@college-monitor/types";
import type { CreateViewerInput, UpdateUserInput } from "@college-monitor/validation";
import { supabase } from "../lib/supabase";
import { writeAuditLog } from "./audit";

interface ProfileRow {
  id: string;
  email: string;
  full_name: string | null;
  role: Profile["role"];
  is_active: boolean;
  last_login_at: string | null;
  created_at: string;
  updated_at: string;
}

function mapProfile(row: ProfileRow): Profile {
  return {
    id: row.id,
    email: row.email,
    fullName: row.full_name,
    role: row.role,
    isActive: row.is_active,
    lastLoginAt: row.last_login_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export async function listUsers(): Promise<Profile[]> {
  const { data, error } = await supabase
    .from("profiles")
    .select("*")
    .order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []).map(mapProfile);
}

export async function createViewer(input: CreateViewerInput): Promise<Profile> {
  const { data, error } = await supabase.functions.invoke("admin-create-viewer", {
    body: input,
  });
  if (error) throw error;
  if (!data?.success) throw new Error(data?.error?.message ?? "Failed to create viewer.");
  return {
    id: data.data.id,
    email: data.data.email,
    fullName: data.data.fullName,
    role: data.data.role,
    isActive: true,
    lastLoginAt: null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}

export async function updateUser(id: string, input: UpdateUserInput, adminId: string): Promise<Profile> {
  const patch: Record<string, unknown> = {};
  if (input.fullName !== undefined) patch.full_name = input.fullName;
  if (input.isActive !== undefined) patch.is_active = input.isActive;

  const { data, error } = await supabase.from("profiles").update(patch).eq("id", id).select().single();
  if (error) throw error;

  if (input.isActive !== undefined) {
    await writeAuditLog({
      adminId,
      action: input.isActive ? "VIEWER_ENABLED" : "VIEWER_DISABLED",
      metadata: { viewerId: id },
    });
  }

  return mapProfile(data);
}

// Editing a Viewer's email must keep auth.users and profiles in sync, and
// that requires the service role — routed through an Edge Function
// rather than a direct client update. Full-name-only edits could be done
// client-side, but going through the same function keeps this one
// consistent code path and lets the server enforce "never targets an
// ADMIN account".
export async function editViewer(
  userId: string,
  input: { fullName?: string; email?: string; password?: string },
): Promise<Profile> {
  const { data, error } = await supabase.functions.invoke("admin-update-viewer", {
    body: { userId, ...input },
  });
  if (error) throw error;
  if (!data?.success) throw new Error(data?.error?.message ?? "Failed to update viewer.");
  return {
    id: data.data.id,
    email: data.data.email,
    fullName: data.data.fullName,
    role: data.data.role,
    isActive: data.data.isActive,
    lastLoginAt: null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}

export async function deleteViewer(userId: string): Promise<void> {
  const { data, error } = await supabase.functions.invoke("admin-delete-viewer", {
    body: { userId },
  });
  if (error) throw error;
  if (!data?.success) throw new Error(data?.error?.message ?? "Failed to delete viewer.");
}

export async function getViewerLabAssignments(viewerId: string): Promise<string[]> {
  const { data, error } = await supabase
    .from("viewer_lab_assignments")
    .select("lab_id")
    .eq("viewer_id", viewerId);
  if (error) throw error;
  return (data ?? []).map((row) => row.lab_id);
}

// Replace-all rather than diffing: the assignment set for one Viewer is
// small (a handful of labs at most), so a delete-then-insert is simple
// and avoids the risk of drift from a partial diff.
export async function setViewerLabAssignments(
  viewerId: string,
  labIds: string[],
  adminId: string,
): Promise<void> {
  const { error: deleteError } = await supabase
    .from("viewer_lab_assignments")
    .delete()
    .eq("viewer_id", viewerId);
  if (deleteError) throw deleteError;

  if (labIds.length > 0) {
    const { error: insertError } = await supabase
      .from("viewer_lab_assignments")
      .insert(labIds.map((labId) => ({ viewer_id: viewerId, lab_id: labId })));
    if (insertError) throw insertError;
  }

  await writeAuditLog({ adminId, action: "VIEWER_LAB_ASSIGNMENTS_UPDATED", metadata: { viewerId, labIds } });
}
