import { supabase } from "../lib/supabase";

export async function writeAuditLog(params: {
  adminId: string;
  action: string;
  computerId?: string | null;
  metadata?: Record<string, unknown>;
}): Promise<void> {
  const { error } = await supabase.from("audit_logs").insert({
    admin_id: params.adminId,
    action: params.action,
    computer_id: params.computerId ?? null,
    metadata: params.metadata ?? null,
  });
  if (error) {
    // Audit logging failures shouldn't block the primary action, but they
    // must be visible — surface to the console for now.
    console.error(`Failed to write audit log for "${params.action}":`, error.message);
  }
}
