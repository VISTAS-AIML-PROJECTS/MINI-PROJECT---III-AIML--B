import type { AuditLog } from "@college-monitor/types";
import { supabase } from "../lib/supabase";
import { mapAuditLog } from "../lib/mappers";

export async function listAuditLogs(params: {
  page: number;
  pageSize: number;
}): Promise<{ items: AuditLog[]; total: number }> {
  const from = (params.page - 1) * params.pageSize;
  const to = from + params.pageSize - 1;

  const { data, error, count } = await supabase
    .from("audit_logs")
    .select("*, profiles(email)", { count: "exact" })
    .order("created_at", { ascending: false })
    .range(from, to);
  if (error) throw error;

  return { items: (data ?? []).map(mapAuditLog), total: count ?? 0 };
}
