import type { RemoteCommand, RemoteCommandType } from "@college-monitor/types";
import { supabase } from "../lib/supabase";
import { mapRemoteCommand } from "../lib/mappers";
import { writeAuditLog } from "./audit";

// Only ever creates a PENDING request — the RLS insert policy on
// remote_commands enforces that server-side too. The PC Agent picks this
// up on its next heartbeat and reports the result via the
// agent-command-result Edge Function, which is the only path that can
// move status to SUCCEEDED/FAILED.
export async function requestCommand(
  computerId: string,
  commandType: RemoteCommandType,
  adminId: string,
): Promise<RemoteCommand> {
  const { data, error } = await supabase
    .from("remote_commands")
    .insert({ computer_id: computerId, requested_by: adminId, command_type: commandType, status: "PENDING" })
    .select()
    .single();
  if (error) throw error;

  await writeAuditLog({
    adminId,
    action: `COMMAND_${commandType}_REQUESTED`,
    computerId,
    metadata: { commandId: data.id },
  });

  return mapRemoteCommand(data);
}

// One-click bulk action (e.g. "Shut down all PCs in this lab") — inserts
// a PENDING row per computer in a single request. Each PC's own agent
// still only ever picks up its own row on its next heartbeat, so this is
// exactly equivalent to clicking the single-computer action N times.
export async function requestBulkCommand(
  computerIds: string[],
  commandType: RemoteCommandType,
  adminId: string,
): Promise<RemoteCommand[]> {
  if (computerIds.length === 0) return [];

  const { data, error } = await supabase
    .from("remote_commands")
    .insert(
      computerIds.map((computerId) => ({
        computer_id: computerId,
        requested_by: adminId,
        command_type: commandType,
        status: "PENDING",
      })),
    )
    .select();
  if (error) throw error;

  await writeAuditLog({
    adminId,
    action: `COMMAND_${commandType}_BULK_REQUESTED`,
    metadata: { computerIds, count: computerIds.length },
  });

  return (data ?? []).map(mapRemoteCommand);
}

export async function listCommandsForComputer(computerId: string): Promise<RemoteCommand[]> {
  const { data, error } = await supabase
    .from("remote_commands")
    .select("*")
    .eq("computer_id", computerId)
    .order("requested_at", { ascending: false })
    .limit(20);
  if (error) throw error;
  return (data ?? []).map(mapRemoteCommand);
}
