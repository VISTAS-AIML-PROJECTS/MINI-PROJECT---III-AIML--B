import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";

// Duplicated (not imported) from electron/updater.ts — importing it here
// would drag the main-process module graph into the renderer's
// tsconfig "rootDir": "./src" program, which rejects any file outside src/.
type UpdaterState =
  | { status: "idle" }
  | { status: "checking" }
  | { status: "available"; version: string }
  | { status: "not-available" }
  | { status: "downloading"; percent: number }
  | { status: "downloaded"; version: string }
  | { status: "error"; message: string };

// Wraps the updater IPC bridge and only surfaces a toast for the outcome
// of a check the user explicitly triggered (the manualRef flag) — the
// silent startup check still updates `state` for any UI that wants it,
// but doesn't pop a toast on every launch.
export function useUpdater() {
  const [state, setState] = useState<UpdaterState>({ status: "idle" });
  const manual = useRef(false);

  useEffect(() => {
    void window.bridge.updater.getState().then(setState);
    return window.bridge.updater.onStateChange((next) => {
      setState(next);
      if (!manual.current) return;
      if (next.status === "available" || next.status === "not-available" || next.status === "error") {
        manual.current = false;
      }
      if (next.status === "available") {
        toast.info("Update available", { description: `Version ${next.version} is downloading now.` });
      } else if (next.status === "not-available") {
        toast.success("You're up to date.");
      } else if (next.status === "error") {
        toast.error("Update check failed", { description: next.message });
      }
    });
  }, []);

  const check = useCallback(() => {
    manual.current = true;
    void window.bridge.updater.check();
  }, []);

  return { state, check };
}
