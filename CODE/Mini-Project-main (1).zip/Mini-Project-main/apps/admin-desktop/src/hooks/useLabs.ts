import { useQuery } from "@tanstack/react-query";
import { listLabs } from "../services/labs";

export function useLabs() {
  return useQuery({ queryKey: ["labs"], queryFn: listLabs });
}
