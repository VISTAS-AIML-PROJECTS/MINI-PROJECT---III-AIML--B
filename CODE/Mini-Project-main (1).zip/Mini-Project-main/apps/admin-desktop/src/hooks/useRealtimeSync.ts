import { useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import type { ComputerLive } from "@college-monitor/types";
import { supabase } from "../lib/supabase";
import { useConnectionStore } from "../stores/connection.store";

interface ActivityEventRow {
  event_type: string;
  computer_id: string;
  application_name: string | null;
  metadata: Record<string, unknown> | null;
}

// One Realtime channel for the whole app, subscribed to every table the
// dashboard/detail pages care about. Postgres Changes only pushes rows
// this client's RLS policies allow it to see, so this is safe for both
// ADMIN and VIEWER builds. On any change we invalidate the relevant
// TanStack Query keys instead of patching cache by hand — the refetch is
// cheap and guarantees the UI matches the database.
export function useRealtimeSync(): void {
  const queryClient = useQueryClient();
  const setStatus = useConnectionStore((s) => s.setStatus);

  useEffect(() => {
    const channel = supabase
      .channel("app-realtime-sync")
      .on("postgres_changes", { event: "*", schema: "public", table: "computers" }, () => {
        void queryClient.invalidateQueries({ queryKey: ["computers"] });
        void queryClient.invalidateQueries({ queryKey: ["computer"] });
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "sessions" }, () => {
        void queryClient.invalidateQueries({ queryKey: ["computers"] });
        void queryClient.invalidateQueries({ queryKey: ["computer"] });
        void queryClient.invalidateQueries({ queryKey: ["sessions"] });
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "application_activity" }, () => {
        void queryClient.invalidateQueries({ queryKey: ["computers"] });
        void queryClient.invalidateQueries({ queryKey: ["computer"] });
        void queryClient.invalidateQueries({ queryKey: ["applications-usage"] });
      })
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "activity_events" }, (payload) => {
        void queryClient.invalidateQueries({ queryKey: ["activities"] });
        void queryClient.invalidateQueries({ queryKey: ["computer"] });

        const row = payload.new as ActivityEventRow;
        if (row.event_type === "APP_SWITCH" || row.event_type === "APP_OPEN") {
          const computers = queryClient.getQueryData<ComputerLive[]>(["computers"]);
          const computerName = computers?.find((c) => c.id === row.computer_id)?.name ?? "A computer";
          const previousApp =
            typeof row.metadata?.previousApplicationName === "string"
              ? row.metadata.previousApplicationName
              : null;
          const detail = previousApp
            ? `${previousApp} → ${row.application_name}`
            : `Opened ${row.application_name}`;
          toast.info(computerName, { description: detail });
        }
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "remote_commands" }, () => {
        void queryClient.invalidateQueries({ queryKey: ["commands"] });
      })
      .subscribe((status) => {
        if (status === "SUBSCRIBED") setStatus("connected");
        else if (status === "CHANNEL_ERROR" || status === "TIMED_OUT" || status === "CLOSED") {
          setStatus("disconnected");
        }
      });

    return () => {
      void supabase.removeChannel(channel);
    };
  }, [queryClient, setStatus]);
}
