import { useQuery } from "@tanstack/react-query";
import { getComputer, listComputers } from "../services/computers";

export function useComputers() {
  return useQuery({ queryKey: ["computers"], queryFn: listComputers });
}

export function useComputer(id: string | undefined) {
  return useQuery({
    queryKey: ["computer", id],
    queryFn: () => getComputer(id as string),
    enabled: Boolean(id),
    refetchInterval: 10_000,
  });
}
