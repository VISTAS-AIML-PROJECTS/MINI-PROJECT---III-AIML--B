import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Copy, Check } from "lucide-react";
import type { Computer } from "@college-monitor/types";
import {
  deleteComputer,
  issueRegistrationCode,
  revokeCredentials,
  updateComputer,
} from "../services/computers";
import { useAuthStore } from "../stores/auth.store";
import { useLabs } from "../hooks/useLabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Separator } from "./ui/separator";
import { ConfirmDialog } from "./ConfirmDialog";

const UNASSIGNED = "__unassigned__";

export function ManageComputerDialog({
  computer,
  onClose,
}: {
  computer: Computer | null;
  onClose: () => void;
}) {
  const [name, setName] = useState("");
  const [labId, setLabId] = useState(UNASSIGNED);
  const [savingDetails, setSavingDetails] = useState(false);
  const [newCode, setNewCode] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [confirmingDelete, setConfirmingDelete] = useState(false);

  const { data: labs } = useLabs();
  const profile = useAuthStore((s) => s.profile);
  const queryClient = useQueryClient();

  useEffect(() => {
    if (computer) {
      setName(computer.name);
      setLabId(computer.labId ?? UNASSIGNED);
      setNewCode(null);
    }
  }, [computer]);

  async function handleSaveDetails() {
    if (!computer || !profile) return;
    setSavingDetails(true);
    try {
      await updateComputer(computer.id, { name, labId: labId === UNASSIGNED ? null : labId }, profile.id);
      void queryClient.invalidateQueries({ queryKey: ["computers"] });
      toast.success("Computer updated");
    } catch (err) {
      toast.error("Failed to update computer", { description: err instanceof Error ? err.message : undefined });
    } finally {
      setSavingDetails(false);
    }
  }

  async function handleGenerateCode() {
    if (!computer || !profile) return;
    try {
      const { registrationCode } = await issueRegistrationCode(computer.id, profile.id);
      setNewCode(registrationCode);
    } catch (err) {
      toast.error("Failed to generate code", { description: err instanceof Error ? err.message : undefined });
    }
  }

  async function handleRevoke() {
    if (!computer || !profile) return;
    try {
      await revokeCredentials(computer.id, profile.id);
      toast.success("Agent credential revoked", {
        description: "The PC Agent must be re-registered to reconnect.",
      });
    } catch (err) {
      toast.error("Failed to revoke credential", { description: err instanceof Error ? err.message : undefined });
    }
  }

  function copyCode() {
    if (!newCode) return;
    void navigator.clipboard.writeText(newCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  async function handleDelete() {
    if (!computer || !profile) return;
    try {
      await deleteComputer(computer, profile.id);
      void queryClient.invalidateQueries({ queryKey: ["computers"] });
      toast.success("Computer deleted");
      onClose();
    } catch (err) {
      toast.error("Failed to delete computer", { description: err instanceof Error ? err.message : undefined });
    }
  }

  return (
    <Dialog open={Boolean(computer)} onOpenChange={(next) => !next && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Manage {computer?.name}</DialogTitle>
        </DialogHeader>
        {computer && profile && (
          <div className="space-y-5">
            <div className="space-y-3">
              <div className="space-y-1.5">
                <Label htmlFor="edit-name">Name</Label>
                <Input id="edit-name" value={name} onChange={(e) => setName(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="edit-lab">Lab</Label>
                <Select value={labId} onValueChange={setLabId}>
                  <SelectTrigger id="edit-lab" className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={UNASSIGNED}>Unassigned</SelectItem>
                    {labs?.map((lab) => (
                      <SelectItem key={lab.id} value={lab.id}>
                        {lab.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex justify-end">
                <Button size="sm" onClick={() => void handleSaveDetails()} disabled={savingDetails}>
                  Save changes
                </Button>
              </div>
            </div>

            <Separator />

            <div>
              <p className="mb-2 text-xs font-medium text-muted-foreground">Agent credential</p>
              {newCode ? (
                <div className="flex items-center gap-2 rounded-md border border-border bg-muted p-2">
                  <code className="flex-1 break-all text-xs">{newCode}</code>
                  <button onClick={copyCode} className="shrink-0 rounded p-1.5 hover:bg-accent">
                    {copied ? <Check className="h-4 w-4 text-emerald-500" /> : <Copy className="h-4 w-4" />}
                  </button>
                </div>
              ) : (
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => void handleGenerateCode()}>
                    Generate new registration code
                  </Button>
                  <Button size="sm" variant="destructive" onClick={() => void handleRevoke()}>
                    Revoke current credential
                  </Button>
                </div>
              )}
            </div>

            <Separator />

            <div>
              <p className="mb-2 text-xs font-medium text-muted-foreground">Danger zone</p>
              <Button size="sm" variant="destructive" onClick={() => setConfirmingDelete(true)}>
                Delete computer
              </Button>
            </div>
          </div>
        )}
      </DialogContent>

      <ConfirmDialog
        open={confirmingDelete}
        onClose={() => setConfirmingDelete(false)}
        onConfirm={handleDelete}
        title={`Delete ${computer?.name}?`}
        description="This permanently removes the computer, its sessions, activity, and agent credentials. Audit log entries are kept. This cannot be undone."
        confirmLabel="Delete"
        destructive
      />
    </Dialog>
  );
}
