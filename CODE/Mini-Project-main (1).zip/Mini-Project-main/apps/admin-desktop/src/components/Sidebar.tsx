import { NavLink } from "react-router-dom";
import {
  LayoutDashboard,
  Monitor,
  Building2,
  Activity,
  AppWindow,
  Users2,
  BarChart3,
  ShieldAlert,
  UserCog,
  Settings,
} from "lucide-react";
import { APP_ROUTES } from "@college-monitor/config";
import { cn } from "@college-monitor/ui";

const NAV_ITEMS = [
  { to: APP_ROUTES.DASHBOARD, label: "Dashboard", icon: LayoutDashboard, end: true },
  { to: APP_ROUTES.COMPUTERS, label: "Computers", icon: Monitor },
  { to: APP_ROUTES.LABS, label: "Labs", icon: Building2 },
  { to: APP_ROUTES.ACTIVITY, label: "Activity", icon: Activity },
  { to: APP_ROUTES.APPLICATIONS, label: "Applications", icon: AppWindow },
  { to: APP_ROUTES.SESSIONS, label: "Sessions", icon: Users2 },
  { to: APP_ROUTES.REPORTS, label: "Reports", icon: BarChart3 },
  { to: APP_ROUTES.AUDIT_LOGS, label: "Audit Logs", icon: ShieldAlert },
  { to: APP_ROUTES.USERS, label: "Users", icon: UserCog },
  { to: APP_ROUTES.SETTINGS, label: "Settings", icon: Settings },
];

export function Sidebar() {
  return (
    <aside className="flex h-full w-56 shrink-0 flex-col border-r border-border bg-card">
      <div className="flex h-14 items-center gap-2 border-b border-border px-4">
        <div className="flex h-7 w-7 items-center justify-center rounded-md bg-primary text-primary-foreground">
          <Monitor className="h-4 w-4" />
        </div>
        <div>
          <p className="text-sm font-semibold leading-tight">College PC</p>
          <p className="text-[10px] leading-tight text-muted-foreground">Admin Console</p>
        </div>
      </div>
      <nav className="flex-1 space-y-0.5 overflow-y-auto p-2">
        {NAV_ITEMS.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            className={({ isActive }) =>
              cn(
                "flex items-center gap-2.5 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                isActive
                  ? "bg-primary/10 text-primary"
                  : "text-muted-foreground hover:bg-accent hover:text-foreground",
              )
            }
          >
            <item.icon className="h-4 w-4" />
            {item.label}
          </NavLink>
        ))}
      </nav>
    </aside>
  );
}
