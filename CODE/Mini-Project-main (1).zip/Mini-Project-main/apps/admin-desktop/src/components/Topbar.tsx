import { useTheme } from "next-themes";
import { LogOut, Wifi, WifiOff, Loader2, RefreshCw, Sun, Moon, Monitor } from "lucide-react";
import { useAuthStore } from "../stores/auth.store";
import { useConnectionStore } from "../stores/connection.store";
import { useUpdater } from "../hooks/useUpdater";
import { Tooltip, TooltipContent, TooltipTrigger } from "./ui/tooltip";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { cn } from "@college-monitor/ui";

const THEME_ICONS = { light: Sun, dark: Moon, system: Monitor } as const;

export function Topbar() {
  const profile = useAuthStore((s) => s.profile);
  const signOut = useAuthStore((s) => s.signOut);
  const status = useConnectionStore((s) => s.status);
  const { state: updaterState, check: checkForUpdates } = useUpdater();
  const isCheckingUpdate = updaterState.status === "checking" || updaterState.status === "downloading";
  const { theme, setTheme } = useTheme();
  const ThemeIcon = THEME_ICONS[(theme as keyof typeof THEME_ICONS) ?? "system"] ?? Monitor;

  return (
    <header className="flex h-14 shrink-0 items-center justify-between border-b border-border bg-card px-6">
      <div />
      <div className="flex items-center gap-4">
        <DropdownMenu>
          <Tooltip>
            <TooltipTrigger asChild>
              <DropdownMenuTrigger asChild>
                <button
                  className="rounded-md p-2 text-muted-foreground hover:bg-accent hover:text-foreground"
                  title="Change theme"
                >
                  <ThemeIcon className="h-4 w-4" />
                </button>
              </DropdownMenuTrigger>
            </TooltipTrigger>
            <TooltipContent>Change theme</TooltipContent>
          </Tooltip>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => setTheme("light")}>
              <Sun className="h-4 w-4" /> Light
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setTheme("dark")}>
              <Moon className="h-4 w-4" /> Dark
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setTheme("system")}>
              <Monitor className="h-4 w-4" /> System
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              onClick={() => !isCheckingUpdate && checkForUpdates()}
              disabled={isCheckingUpdate}
              className="rounded-md p-2 text-muted-foreground hover:bg-accent hover:text-foreground disabled:opacity-50"
              title="Check for updates"
            >
              <RefreshCw className={cn("h-4 w-4", isCheckingUpdate && "animate-spin")} />
            </button>
          </TooltipTrigger>
          <TooltipContent>Check for updates</TooltipContent>
        </Tooltip>
        <div
          className={cn(
            "flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium",
            status === "connected" && "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400",
            status === "connecting" && "bg-amber-500/10 text-amber-600 dark:text-amber-400",
            status === "disconnected" && "bg-red-500/10 text-red-600 dark:text-red-400",
          )}
          title="Realtime connection status"
        >
          {status === "connected" && <Wifi className="h-3.5 w-3.5" />}
          {status === "connecting" && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
          {status === "disconnected" && <WifiOff className="h-3.5 w-3.5" />}
          {status === "connected" ? "Live" : status === "connecting" ? "Connecting" : "Offline"}
        </div>
        <div className="h-6 w-px bg-border" />
        <div className="text-right">
          <p className="text-sm font-medium leading-tight">{profile?.fullName ?? profile?.email}</p>
          <p className="text-[11px] leading-tight text-muted-foreground">Administrator</p>
        </div>
        <button
          onClick={() => void signOut()}
          className="rounded-md p-2 text-muted-foreground hover:bg-accent hover:text-foreground"
          title="Sign out"
        >
          <LogOut className="h-4 w-4" />
        </button>
      </div>
    </header>
  );
}
