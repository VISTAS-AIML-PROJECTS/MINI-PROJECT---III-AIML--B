import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Copy, Check } from "lucide-react";
import { createComputer } from "../services/computers";
import { useAuthStore } from "../stores/auth.store";
import { useLabs } from "../hooks/useLabs";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";

const UNASSIGNED = "__unassigned__";

export function RegisterComputerDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [name, setName] = useState("");
  const [labId, setLabId] = useState(UNASSIGNED);
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<{ registrationCode: string; expiresAt: string } | null>(null);
  const [copied, setCopied] = useState(false);

  const { data: labs } = useLabs();
  const profile = useAuthStore((s) => s.profile);
  const queryClient = useQueryClient();

  function handleClose() {
    setName("");
    setLabId(UNASSIGNED);
    setResult(null);
    setCopied(false);
    onClose();
  }

  async function handleSubmit() {
    if (!profile || !name.trim()) return;
    setSubmitting(true);
    try {
      const { registrationCode, expiresAt } = await createComputer(
        { name: name.trim(), labId: labId === UNASSIGNED ? undefined : labId },
        profile.id,
      );
      setResult({ registrationCode, expiresAt });
      void queryClient.invalidateQueries({ queryKey: ["computers"] });
      toast.success("Computer registered", { description: "Give the code below to the PC Agent installer." });
    } catch (err) {
      toast.error("Failed to register computer", { description: err instanceof Error ? err.message : undefined });
    } finally {
      setSubmitting(false);
    }
  }

  function copyCode() {
    if (!result) return;
    void navigator.clipboard.writeText(result.registrationCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <Dialog open={open} onOpenChange={(next) => !next && handleClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{result ? "Registration code" : "Register PC"}</DialogTitle>
        </DialogHeader>

        {result ? (
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">
              This one-time code is shown only once. Enter it in the PC Agent installer on the target
              computer within 30 minutes.
            </p>
            <div className="flex items-center gap-2 rounded-md border border-border bg-muted p-2">
              <code className="flex-1 break-all text-xs">{result.registrationCode}</code>
              <button onClick={copyCode} className="shrink-0 rounded p-1.5 hover:bg-accent">
                {copied ? <Check className="h-4 w-4 text-emerald-500" /> : <Copy className="h-4 w-4" />}
              </button>
            </div>
            <p className="text-xs text-muted-foreground">
              Expires {new Date(result.expiresAt).toLocaleTimeString()}
            </p>
            <DialogFooter>
              <Button onClick={handleClose}>Done</Button>
            </DialogFooter>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="pc-name">Computer name</Label>
              <Input
                id="pc-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="LAB-A-005"
                autoFocus
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="pc-lab">Lab</Label>
              <Select value={labId} onValueChange={setLabId}>
                <SelectTrigger id="pc-lab" className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={UNASSIGNED}>Unassigned</SelectItem>
                  {labs?.map((lab) => (
                    <SelectItem key={lab.id} value={lab.id}>
                      {lab.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={handleClose}>
                Cancel
              </Button>
              <Button onClick={() => void handleSubmit()} disabled={submitting || !name.trim()}>
                Register
              </Button>
            </DialogFooter>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
