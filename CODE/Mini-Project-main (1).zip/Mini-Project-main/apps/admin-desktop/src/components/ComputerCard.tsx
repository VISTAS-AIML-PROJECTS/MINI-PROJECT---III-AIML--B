import { useNavigate } from "react-router-dom";
import { formatDistanceToNow } from "date-fns";
import { Cpu, MemoryStick, User } from "lucide-react";
import type { ComputerLive } from "@college-monitor/types";
import { StatusBadge } from "@college-monitor/ui";
import { Card } from "./ui/card";

function UsageBar({ value, icon: Icon }: { value: number | null; icon: typeof Cpu }) {
  const pct = value ?? 0;
  const color = pct > 85 ? "bg-destructive" : pct > 60 ? "bg-amber-500" : "bg-emerald-500";
  return (
    <div className="flex items-center gap-1.5">
      <Icon className="h-3 w-3 text-muted-foreground" />
      <div className="h-1.5 w-14 overflow-hidden rounded-full bg-muted">
        <div className={`h-full ${color}`} style={{ width: `${pct}%` }} />
      </div>
      <span className="w-8 text-[11px] tabular-nums text-muted-foreground">
        {value === null ? "—" : `${Math.round(pct)}%`}
      </span>
    </div>
  );
}

export function ComputerCard({ computer }: { computer: ComputerLive }) {
  const navigate = useNavigate();

  return (
    <Card
      className="cursor-pointer p-4 transition-colors hover:border-primary/40"
      onClick={() => navigate(`/computers/${computer.id}`)}
    >
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm font-semibold">{computer.name}</p>
          <p className="text-[11px] text-muted-foreground">{computer.labName ?? "Unassigned"}</p>
        </div>
        <StatusBadge status={computer.status} />
      </div>

      <div className="mt-3 space-y-1.5">
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground">Application</span>
          <span className="font-medium">{computer.currentApplication ?? "—"}</span>
        </div>
        <div className="flex items-center justify-between text-xs">
          <span className="flex items-center gap-1 text-muted-foreground">
            <User className="h-3 w-3" /> Session
          </span>
          <span className="font-medium">{computer.currentSessionUsername ?? "—"}</span>
        </div>
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground">Last seen</span>
          <span className="font-medium">
            {computer.lastSeenAt
              ? formatDistanceToNow(new Date(computer.lastSeenAt), { addSuffix: true })
              : "Never"}
          </span>
        </div>
      </div>

      <div className="mt-3 flex items-center gap-3 border-t border-border pt-3">
        <UsageBar value={computer.cpuUsage} icon={Cpu} />
        <UsageBar value={computer.memoryUsage} icon={MemoryStick} />
      </div>
    </Card>
  );
}
