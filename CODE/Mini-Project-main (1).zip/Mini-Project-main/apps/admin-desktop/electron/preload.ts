import { contextBridge, ipcRenderer } from "electron";

// Duplicated (not imported) from electron/updater.ts on purpose, same
// reasoning as viewer-desktop's preload.ts: keeps this file free of any
// import chain into the main-process implementation graph.
export type UpdaterState =
  | { status: "idle" }
  | { status: "checking" }
  | { status: "available"; version: string }
  | { status: "not-available" }
  | { status: "downloading"; percent: number }
  | { status: "downloaded"; version: string }
  | { status: "error"; message: string };

// Minimal, explicit bridge. The renderer has no direct Node.js or Electron
// API access (contextIsolation + sandbox + nodeIntegration:false) — it can
// only call the specific functions exposed here. All application data
// access (Supabase Auth/Postgres/Realtime) happens in the renderer via
// fetch/WebSocket, which sandboxed renderers can do natively — no IPC
// round-trip needed for that.
const bridge = {
  getVersion: (): Promise<string> => ipcRenderer.invoke("app:getVersion"),
  getPlatform: (): Promise<NodeJS.Platform> => ipcRenderer.invoke("app:getPlatform"),
  window: {
    minimize: (): Promise<void> => ipcRenderer.invoke("window:minimize"),
    toggleMaximize: (): Promise<void> => ipcRenderer.invoke("window:toggleMaximize"),
    close: (): Promise<void> => ipcRenderer.invoke("window:close"),
    isMaximized: (): Promise<boolean> => ipcRenderer.invoke("window:isMaximized"),
  },
  openExternal: (url: string): Promise<void> => ipcRenderer.invoke("shell:openExternal", url),
  updater: {
    check: (): Promise<void> => ipcRenderer.invoke("updater:check"),
    getState: (): Promise<UpdaterState> => ipcRenderer.invoke("updater:getState"),
    onStateChange: (callback: (state: UpdaterState) => void): (() => void) => {
      const listener = (_event: Electron.IpcRendererEvent, state: UpdaterState) => callback(state);
      ipcRenderer.on("updater:state-changed", listener);
      return () => ipcRenderer.removeListener("updater:state-changed", listener);
    },
  },
};

export type Bridge = typeof bridge;

contextBridge.exposeInMainWorld("bridge", bridge);
