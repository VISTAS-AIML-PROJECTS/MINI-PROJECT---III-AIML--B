import os from "node:os";

interface CpuSample {
  idle: number;
  total: number;
}

function sampleCpus(): CpuSample {
  let idle = 0;
  let total = 0;
  for (const cpu of os.cpus()) {
    for (const type of Object.keys(cpu.times) as (keyof typeof cpu.times)[]) {
      total += cpu.times[type];
    }
    idle += cpu.times.idle;
  }
  return { idle, total };
}

// CPU usage requires two samples over an interval (instantaneous
// snapshots of os.cpus() are cumulative counters, not a point-in-time
// percentage).
export function getCpuUsagePercent(sampleWindowMs = 300): Promise<number> {
  const start = sampleCpus();
  return new Promise((resolve) => {
    setTimeout(() => {
      const end = sampleCpus();
      const idleDelta = end.idle - start.idle;
      const totalDelta = end.total - start.total;
      const usage = totalDelta === 0 ? 0 : 100 * (1 - idleDelta / totalDelta);
      resolve(Math.max(0, Math.min(100, Math.round(usage * 10) / 10)));
    }, sampleWindowMs);
  });
}

export function getMemoryUsagePercent(): number {
  const total = os.totalmem();
  const free = os.freemem();
  return Math.round(((total - free) / total) * 1000) / 10;
}

export function getHostname(): string {
  return os.hostname();
}

export function getOperatingSystem(): string {
  return `${os.type()} ${os.release()} (${os.arch()})`;
}

export function getCurrentUsername(): string {
  try {
    return os.userInfo().username;
  } catch {
    return "unknown";
  }
}
