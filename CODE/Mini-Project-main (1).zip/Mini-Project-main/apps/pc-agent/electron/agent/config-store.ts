import { app } from "electron";
import fs from "node:fs";
import path from "node:path";
import { encryptSecret, decryptSecret } from "../security/secure-storage";

export interface AgentConfig {
  computerId: string;
  computerCode: string;
  agentToken: string;
}

interface StoredConfig {
  computerId: string;
  computerCode: string;
  encryptedToken: string;
}

function configPath(): string {
  return path.join(app.getPath("userData"), "agent-config.json");
}

export function loadAgentConfig(): AgentConfig | null {
  try {
    const raw = fs.readFileSync(configPath(), "utf8");
    const stored = JSON.parse(raw) as StoredConfig;
    return {
      computerId: stored.computerId,
      computerCode: stored.computerCode,
      agentToken: decryptSecret(stored.encryptedToken),
    };
  } catch {
    return null;
  }
}

export function saveAgentConfig(config: AgentConfig): void {
  const stored: StoredConfig = {
    computerId: config.computerId,
    computerCode: config.computerCode,
    encryptedToken: encryptSecret(config.agentToken),
  };
  fs.mkdirSync(path.dirname(configPath()), { recursive: true });
  fs.writeFileSync(configPath(), JSON.stringify(stored), { mode: 0o600 });
}

export function clearAgentConfig(): void {
  try {
    fs.unlinkSync(configPath());
  } catch {
    // Nothing to clear.
  }
}
