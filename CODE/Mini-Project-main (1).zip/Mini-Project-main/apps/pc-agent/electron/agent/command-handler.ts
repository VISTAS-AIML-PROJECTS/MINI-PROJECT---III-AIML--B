import { exec } from "node:child_process";
import os from "node:os";
import type { RemoteCommandType } from "@college-monitor/types";

export interface CommandExecutionResult {
  status: "SUCCEEDED" | "FAILED";
  result: Record<string, unknown>;
}

// Only these four fixed, non-parameterized OS actions are ever executed —
// there is no arbitrary shell/command execution path anywhere in the
// agent. Each maps to a single hard-coded platform command.
const WINDOWS_COMMANDS: Record<RemoteCommandType, string> = {
  LOCK: "rundll32.exe user32.dll,LockWorkStation",
  LOGOUT: "shutdown /l",
  RESTART: "shutdown /r /t 5",
  SHUTDOWN: "shutdown /s /t 5",
};

const MACOS_COMMANDS: Record<RemoteCommandType, string> = {
  LOCK: "/System/Library/CoreServices/Menu\\ Extras/User.menu/Contents/Resources/CGSession -suspend",
  LOGOUT: "osascript -e 'tell application \"System Events\" to log out'",
  RESTART: "osascript -e 'tell application \"System Events\" to restart'",
  SHUTDOWN: "osascript -e 'tell application \"System Events\" to shut down'",
};

const LINUX_COMMANDS: Record<RemoteCommandType, string> = {
  LOCK: "loginctl lock-session",
  LOGOUT: "loginctl terminate-session $XDG_SESSION_ID",
  RESTART: "systemctl reboot",
  SHUTDOWN: "systemctl poweroff",
};

function commandsForPlatform(): Record<RemoteCommandType, string> {
  switch (os.platform()) {
    case "win32":
      return WINDOWS_COMMANDS;
    case "darwin":
      return MACOS_COMMANDS;
    default:
      return LINUX_COMMANDS;
  }
}

export function executeCommand(type: RemoteCommandType): Promise<CommandExecutionResult> {
  const command = commandsForPlatform()[type];

  return new Promise((resolve) => {
    exec(command, { timeout: 15_000 }, (error, stdout, stderr) => {
      if (error) {
        resolve({
          status: "FAILED",
          result: { error: error.message, stderr: stderr?.slice(0, 500) },
        });
        return;
      }
      resolve({ status: "SUCCEEDED", result: { stdout: stdout?.slice(0, 500) } });
    });
  });
}
