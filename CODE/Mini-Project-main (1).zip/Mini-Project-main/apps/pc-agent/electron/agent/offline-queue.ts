import { app } from "electron";
import fs from "node:fs";
import path from "node:path";
import { AGENT_OFFLINE_QUEUE_MAX_EVENTS } from "@college-monitor/config";
import type { ActivityEventPayload } from "./api-client";

// A small, capped, disk-backed queue of activity events collected while
// the backend is unreachable. Bounded so a prolonged outage can't grow
// this without limit — oldest events are dropped first once full, which
// is an acceptable tradeoff for a monitoring feed (recent activity is
// far more actionable than an unbounded backlog).
function queuePath(): string {
  return path.join(app.getPath("userData"), "offline-queue.json");
}

export class OfflineQueue {
  private events: ActivityEventPayload[] = [];

  constructor() {
    this.load();
  }

  push(event: ActivityEventPayload): void {
    this.events.push(event);
    if (this.events.length > AGENT_OFFLINE_QUEUE_MAX_EVENTS) {
      this.events.splice(0, this.events.length - AGENT_OFFLINE_QUEUE_MAX_EVENTS);
    }
    this.persist();
  }

  drain(): ActivityEventPayload[] {
    const drained = this.events;
    this.events = [];
    this.persist();
    return drained;
  }

  requeue(events: ActivityEventPayload[]): void {
    this.events = [...events, ...this.events].slice(-AGENT_OFFLINE_QUEUE_MAX_EVENTS);
    this.persist();
  }

  get size(): number {
    return this.events.length;
  }

  private load(): void {
    try {
      this.events = JSON.parse(fs.readFileSync(queuePath(), "utf8")) as ActivityEventPayload[];
    } catch {
      this.events = [];
    }
  }

  private persist(): void {
    try {
      fs.mkdirSync(path.dirname(queuePath()), { recursive: true });
      fs.writeFileSync(queuePath(), JSON.stringify(this.events));
    } catch (error) {
      console.warn("[agent] Failed to persist offline queue:", error);
    }
  }
}
