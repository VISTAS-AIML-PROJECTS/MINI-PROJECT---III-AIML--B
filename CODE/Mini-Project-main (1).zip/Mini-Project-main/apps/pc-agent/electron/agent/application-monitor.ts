import activeWindow from "active-win";

export interface ActiveWindowInfo {
  applicationName: string;
  executableName: string | null;
  windowTitle: string | null;
}

export type ApplicationSwitchListener = (
  current: ActiveWindowInfo,
  previous: ActiveWindowInfo | null,
) => void;

// Polls the OS for the foreground window/application on an interval and
// reports changes only (not every poll) — this is the application
// switching signal the Activity page's timeline is built from. Only
// application name, executable name, and window title are read; no
// keystrokes, clipboard, or screen content are ever accessed.
export class ApplicationMonitor {
  private timer: ReturnType<typeof setInterval> | null = null;
  private current: ActiveWindowInfo | null = null;

  constructor(
    private readonly onSwitch: ApplicationSwitchListener,
    private readonly pollIntervalMs = 2000,
  ) {}

  start(): void {
    if (this.timer) return;
    this.timer = setInterval(() => void this.poll(), this.pollIntervalMs);
    void this.poll();
  }

  stop(): void {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  getCurrent(): ActiveWindowInfo | null {
    return this.current;
  }

  private async poll(): Promise<void> {
    let result: Awaited<ReturnType<typeof activeWindow>>;
    try {
      result = await activeWindow();
    } catch (error) {
      console.warn("[agent] Failed to read active window:", error);
      return;
    }
    if (!result) return;

    const info: ActiveWindowInfo = {
      applicationName: result.owner.name,
      executableName: result.owner.path?.split(/[\\/]/).pop() ?? null,
      windowTitle: result.title || null,
    };

    const changed =
      !this.current ||
      this.current.applicationName !== info.applicationName ||
      this.current.windowTitle !== info.windowTitle;

    if (changed) {
      const previous = this.current;
      this.current = info;
      this.onSwitch(info, previous);
    }
  }
}
