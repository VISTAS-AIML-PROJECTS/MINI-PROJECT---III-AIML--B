import type { ActivityEventType, RemoteCommandType } from "@college-monitor/types";

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
  throw new Error(
    "VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY are not configured. Copy .env.example to .env at the repo root.",
  );
}

function functionsUrl(name: string): string {
  return `${SUPABASE_URL}/functions/v1/${name}`;
}

interface ApiSuccess<T> {
  success: true;
  data: T;
}
interface ApiError {
  success: false;
  error: { code: string; message: string };
}

async function callFunction<T>(
  name: string,
  body: unknown,
  agentToken?: string,
): Promise<T> {
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
  };
  if (agentToken) headers["x-agent-token"] = agentToken;

  const response = await fetch(functionsUrl(name), {
    method: "POST",
    headers,
    body: JSON.stringify(body),
  });

  const json = (await response.json()) as ApiSuccess<T> | ApiError;
  if (!json.success) {
    throw new Error(json.error.message || `${name} failed with status ${response.status}`);
  }
  return json.data;
}

export interface RegisterResult {
  computerId: string;
  computerCode: string;
  agentToken: string;
}

export function registerAgent(params: {
  registrationCode: string;
  hostname: string;
  operatingSystem: string;
  agentVersion: string;
}): Promise<RegisterResult> {
  return callFunction<RegisterResult>("agent-register", params);
}

export interface HeartbeatResult {
  heartbeatIntervalSeconds: number;
  commands: { commandId: string; commandType: RemoteCommandType }[];
}

export function sendHeartbeat(
  agentToken: string,
  params: { cpuUsage: number; memoryUsage: number; agentVersion: string },
): Promise<HeartbeatResult> {
  return callFunction<HeartbeatResult>("agent-heartbeat", params, agentToken);
}

export interface ActivityEventPayload {
  eventType: ActivityEventType;
  applicationName?: string;
  executableName?: string;
  windowTitle?: string;
  previousApplicationName?: string;
  username?: string;
  occurredAt: string;
}

export function sendActivityBatch(agentToken: string, events: ActivityEventPayload[]): Promise<{ processed: number }> {
  return callFunction<{ processed: number }>("agent-activity", { events }, agentToken);
}

export function sendCommandResult(
  agentToken: string,
  params: { commandId: string; status: "SUCCEEDED" | "FAILED"; result?: Record<string, unknown> },
): Promise<{ commandId: string; status: string }> {
  return callFunction<{ commandId: string; status: string }>("agent-command-result", params, agentToken);
}
