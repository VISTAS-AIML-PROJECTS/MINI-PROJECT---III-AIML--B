import { safeStorage } from "electron";

// Wraps Electron's safeStorage (OS keychain-backed encryption) so the
// agent token never touches disk in plain text. Falls back to storing the
// raw value (still file-permission protected, in the per-user userData
// directory) only on platforms/configurations where OS encryption isn't
// available — logged loudly so this is never silently the case.
export function encryptSecret(value: string): string {
  if (safeStorage.isEncryptionAvailable()) {
    return safeStorage.encryptString(value).toString("base64");
  }
  console.warn("[agent] OS-level credential encryption is not available on this machine.");
  return `plain:${Buffer.from(value, "utf8").toString("base64")}`;
}

export function decryptSecret(stored: string): string {
  if (stored.startsWith("plain:")) {
    return Buffer.from(stored.slice("plain:".length), "base64").toString("utf8");
  }
  return safeStorage.decryptString(Buffer.from(stored, "base64"));
}
