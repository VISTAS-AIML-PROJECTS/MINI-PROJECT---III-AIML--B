export function clamp(value, min, max) {
  return Math.min(
    Math.max(value, min),
    max
  );
}

function projectPointOnLine(
  point,
  start,
  end
) {
  const dx = end.x - start.x;
  const dy = end.y - start.y;

  const denominator =
    dx * dx + dy * dy;

  if (denominator < 1e-10) {
    return null;
  }

  const px = point.x - start.x;
  const py = point.y - start.y;

  return (
    (px * dx + py * dy) /
    denominator
  );
}

export function getRelativeIrisPosition(
  iris,
  eyeStart,
  eyeEnd
) {
  if (
    !iris ||
    !eyeStart ||
    !eyeEnd
  ) {
    return null;
  }

  const position =
    projectPointOnLine(
      iris,
      eyeStart,
      eyeEnd
    );

  if (position === null) {
    return null;
  }

  return clamp(position, 0, 1);
}

export function extractGazeFeature(
  landmarks
) {
  if (
    !landmarks ||
    landmarks.length < 478
  ) {
    return null;
  }

  /*
   * Iris centers.
   */
  const rightIris =
    landmarks[468];

  const leftIris =
    landmarks[473];

  /*
   * Horizontal eye references.
   */
  const rightOuter =
    landmarks[33];

  const rightInner =
    landmarks[133];

  const leftInner =
    landmarks[362];

  const leftOuter =
    landmarks[263];

  /*
   * Vertical eye references.
   *
   * These provide upper/lower
   * eyelid reference points.
   */
  const rightUpper =
    landmarks[159];

  const rightLower =
    landmarks[145];

  const leftUpper =
    landmarks[386];

  const leftLower =
    landmarks[374];

  /*
   * Horizontal gaze.
   */
  const rightX =
    getRelativeIrisPosition(
      rightIris,
      rightOuter,
      rightInner
    );

  const leftX =
    getRelativeIrisPosition(
      leftIris,
      leftInner,
      leftOuter
    );

  /*
   * Vertical gaze.
   */
  const rightY =
    getRelativeIrisPosition(
      rightIris,
      rightUpper,
      rightLower
    );

  const leftY =
    getRelativeIrisPosition(
      leftIris,
      leftUpper,
      leftLower
    );

  if (
    rightX === null ||
    leftX === null ||
    rightY === null ||
    leftY === null
  ) {
    return null;
  }

  const gazeX =
    (rightX + leftX) / 2;

  const gazeY =
    (rightY + leftY) / 2;

  return {
    gazeX,
    gazeY,

    rightEye: {
      x: rightX,
      y: rightY,
    },

    leftEye: {
      x: leftX,
      y: leftY,
    },

    symmetryDifference:
      Math.abs(
        rightX - leftX
      ),
  };
}

export function mean(values) {
  if (
    !values ||
    values.length === 0
  ) {
    return null;
  }

  return (
    values.reduce(
      (sum, value) =>
        sum + value,
      0
    ) / values.length
  );
}

export function standardDeviation(
  values,
  average
) {
  if (
    !values ||
    values.length < 2 ||
    average === null ||
    average === undefined
  ) {
    return null;
  }

  const variance =
    values.reduce(
      (sum, value) =>
        sum +
        (value - average) ** 2,
      0
    ) / values.length;

  return Math.sqrt(
    Math.max(variance, 0)
  );
}