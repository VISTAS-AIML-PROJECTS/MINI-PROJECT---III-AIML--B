import {
  useCallback,
  useEffect,
  useRef,
  useState,
} from "react";

import {
  VisionTracker,
} from "./visionTracker.js";

const TARGET_POSITIONS = {
  CENTER: {
    top: "50%",
    left: "50%",
  },

  TOP_LEFT: {
    top: "15%",
    left: "15%",
  },

  TOP: {
    top: "15%",
    left: "50%",
  },

  TOP_RIGHT: {
    top: "15%",
    left: "85%",
  },

  RIGHT: {
    top: "50%",
    left: "85%",
  },

  BOTTOM_RIGHT: {
    top: "85%",
    left: "85%",
  },

  BOTTOM: {
    top: "85%",
    left: "50%",
  },

  BOTTOM_LEFT: {
    top: "85%",
    left: "15%",
  },

  LEFT: {
    top: "50%",
    left: "15%",
  },
};

export default function VisionModule({
  onSignal = () => {},
  onUiState = () => {},
  baselineResetToken = 0,
}) {
  const videoRef = useRef(null);
  const trackerRef = useRef(null);

  const [
    calibrationState,
    setCalibrationState,
  ] = useState({
    phase: "IDLE",
    progress: 0,
    target: "CENTER",
    quality: 0,
    sampleCount: 0,
    targetIndex: 0,
    targetCount: 9,
  });

  const [status, setStatus] =
    useState(
      "Initializing camera..."
    );

  const [
    calibrating,
    setCalibrating,
  ] = useState(false);

  const [baseline, setBaseline] =
    useState(null);

  /*
   * Presentation-only: lets the dashboard show
   * whether the camera/model started, or why not.
   */
  const [trackerState, setTrackerState] =
    useState({
      phase: "INITIALIZING",
      errorName: null,
      errorMessage: null,
    });

  useEffect(() => {
    let mounted = true;

    const tracker =
      new VisionTracker({
        video:
          videoRef.current,

        onStatus: (message) => {
          if (mounted) {
            setStatus(message);
          }
        },

        onCalibrationUpdate:
          (update) => {
            if (!mounted) {
              return;
            }

            setCalibrationState(
              (previous) => ({
                ...previous,
                ...update,
              })
            );

            if (
              update.phase ===
              "COMPLETE"
            ) {
              setCalibrating(false);

              setBaseline(
                tracker.getBaseline()
              );
            }

            if (
              update.phase ===
              "IDLE"
            ) {
              setBaseline(null);
            }

            if (
              update.phase ===
              "FAILED"
            ) {
              setCalibrating(false);

              setBaseline(null);
            }
          },

        onSignal: (signal) => {
          if (mounted) {
            onSignal(signal);
          }
        },

        onCameraLost: () => {
          if (mounted) {
            setTrackerState({
              phase: "ERROR",
              errorName: "TrackEnded",
              errorMessage:
                "The camera stopped delivering frames.",
            });
          }
        },
      });

    trackerRef.current =
      tracker;

    tracker.start().then(
      () => {
        if (mounted) {
          setTrackerState({
            phase: "READY",
            errorName: null,
            errorMessage: null,
          });
        }
      }
    ).catch(
      (error) => {
        /*
         * A tracker torn down mid-start (React StrictMode's
         * dev-time double mount) rejects with AbortError.
         * That is expected and must not surface as a failure.
         */
        if (!mounted) {
          return;
        }

        /*
         * AbortError from video.play() means a newer load
         * superseded this one (another start() is in progress).
         * Real camera failures (NotAllowedError, NotFoundError,
         * NotReadableError, ...) are not AbortErrors and still
         * surface below.
         */
        if (error?.name === "AbortError") {
          console.warn(
            "GlassBox: video play() was superseded by a newer load (expected; not a failure)."
          );

          return;
        }

        console.error(
          "GlassBox vision initialization error:",
          error
        );

        if (mounted) {
          setStatus(
            "Camera/model initialization failed."
          );

          setTrackerState({
            phase: "ERROR",
            errorName:
              error?.name ?? null,
            errorMessage:
              error?.message ?? null,
          });
        }
      }
    );

    return () => {
      mounted = false;

      tracker.stop();

      trackerRef.current =
        null;
    };
  }, [onSignal]);

  useEffect(() => {
    onUiState({
      status,
      trackerState,
      calibrating,
      calibrationState,
      baseline,
    });
  }, [
    onUiState,
    status,
    trackerState,
    calibrating,
    calibrationState,
    baseline,
  ]);

  /*
   * App bumps the token when a session ends; the next session then
   * needs its own calibration. The first render is not a reset.
   */
  const lastResetToken = useRef(baselineResetToken);

  useEffect(() => {
    if (lastResetToken.current !== baselineResetToken) {
      lastResetToken.current = baselineResetToken;
      trackerRef.current?.clearBaseline();
    }
  }, [baselineResetToken]);

  const startCalibration = () => {
    const tracker =
      trackerRef.current;

    if (!tracker) {
      return;
    }

    setBaseline(null);

    setCalibrating(true);

    setCalibrationState({
      phase: "NATURAL_START",
      progress: 0,
      target: "CENTER",
      quality: 0,
      sampleCount: 0,
      targetIndex: 0,
      targetCount: 9,
    });

    try {
      tracker.beginCalibration();
    } catch (error) {
      console.error(error);

      setCalibrating(false);

      setStatus(
        "Unable to start calibration."
      );
    }
  };

  /*
   * Leave an unfinished calibration. The tracker discards every partial
   * sample, so nothing from it can reach a later calibration or session.
   */
  const cancelCalibration = useCallback(() => {
    const tracker = trackerRef.current;

    if (tracker && tracker.cancelCalibration()) {
      setCalibrating(false);
      setBaseline(null);

      setCalibrationState({
        phase: "IDLE",
        progress: 0,
        target: "CENTER",
        quality: 0,
        sampleCount: 0,
        targetIndex: 0,
        targetCount: 9,
      });
    }
  }, []);

  useEffect(() => {
    if (!calibrating) {
      return undefined;
    }

    const onKeyDown = (event) => {
      if (event.key === "Escape") {
        event.preventDefault();
        cancelCalibration();
      }
    };

    window.addEventListener("keydown", onKeyDown);

    return () =>
      window.removeEventListener("keydown", onKeyDown);
  }, [calibrating, cancelCalibration]);

  const target =
    TARGET_POSITIONS[
      calibrationState.target
    ] ??
    TARGET_POSITIONS.CENTER;

  const isGuided =
    calibrationState.phase ===
    "GUIDED";

  const progress =
    Math.round(
      Math.min(
        Math.max(
          calibrationState.progress ??
            0,
          0
        ),
        1
      ) * 100
    );

  const phaseLabel = {
    NATURAL_START: "Sit naturally",
    GUIDED: "Follow the dot",
    NATURAL_END: "Relax and hold still",
  }[calibrationState.phase];

  const isError =
    trackerState.phase === "ERROR";

  const isReady =
    trackerState.phase === "READY";

  const errorHint =
    trackerState.errorName ===
    "NotAllowedError"
      ? "Camera permission was denied. Allow camera access for this site and reload."
      : trackerState.errorName ===
          "NotFoundError"
        ? "No camera was found on this device."
        : trackerState.errorName ===
            "NotReadableError"
          ? "The camera is in use by another application."
          : trackerState.errorName ===
              "TrackEnded"
            ? "The camera was disconnected. Reconnect it and reload; the time without frames is marked as unobserved, not as low risk."
            : "The camera or the MediaPipe model could not be started.";

  return (
    <div
      className={`vision${calibrating ? " vision--calibrating" : ""}`}
      role={calibrating ? "dialog" : undefined}
      aria-modal={calibrating ? "true" : undefined}
      aria-label={calibrating ? "Personal calibration" : undefined}
    >
      <div className="vision__stage">
        <video
          ref={videoRef}
          autoPlay
          muted
          playsInline
          width="640"
          height="480"
          className="vision__video"
        />

        {!isReady && (
          <div
            className={`vision__overlay${
              isError
                ? " vision__overlay--error"
                : ""
            }`}
            role={
              isError ? "alert" : "status"
            }
          >
            {isError ? (
              <>
                <strong>
                  Camera unavailable
                </strong>
                <span>{errorHint}</span>
                {trackerState.errorMessage && (
                  <code>
                    {trackerState.errorName
                      ? `${trackerState.errorName}: `
                      : ""}
                    {trackerState.errorMessage}
                  </code>
                )}
                <button
                  className="btn"
                  onClick={() =>
                    window.location.reload()
                  }
                >
                  Reload page
                </button>
              </>
            ) : (
              <>
                <span className="spinner" />
                <strong>{status}</strong>
              </>
            )}
          </div>
        )}

        {isGuided && (
          <div
            className="vision__target"
            style={{
              top: target.top,
              left: target.left,
            }}
          />
        )}

        {isReady && (
          <span className="vision__tag">
            {calibrating
              ? "Calibrating"
              : "Camera live"}
          </span>
        )}
      </div>

      <div className="vision__controls">
        <p className="vision__status">
          {status}
        </p>

        {!calibrating && !baseline && (
          <button
            className="btn btn--primary"
            onClick={startCalibration}
            disabled={!isReady}
          >
            {calibrationState.phase ===
            "FAILED"
              ? "Retry calibration"
              : "Start calibration"}
          </button>
        )}

        {!calibrating && baseline && (
          <button
            className="btn"
            onClick={startCalibration}
          >
            Recalibrate
          </button>
        )}

        {calibrating && (
          <button
            className="btn"
            onClick={cancelCalibration}
            aria-keyshortcuts="Escape"
          >
            Cancel calibration
          </button>
        )}
      </div>

      {calibrating && (
        <div className="calibration">
          <div className="calibration__head">
            <strong>
              Personal calibration
              {phaseLabel
                ? ` · ${phaseLabel}`
                : ""}
            </strong>

            <span>{progress}%</span>
          </div>

          <progress
            value={progress}
            max="100"
          />

          <p>
            {calibrationState.phase ===
              "NATURAL_START" &&
              "Sit comfortably as you normally would during an online exam. Small natural movements are okay."}

            {calibrationState.phase ===
              "GUIDED" &&
              `Follow the dot naturally with your eyes. Point ${
                (calibrationState.targetIndex ??
                  0) + 1
              } of ${
                calibrationState.targetCount
              } (${calibrationState.target}).`}

            {calibrationState.phase ===
              "NATURAL_END" &&
              "Relax and continue sitting naturally. Small natural movements are okay."}
          </p>
        </div>
      )}

      {!calibrating &&
        calibrationState.phase ===
          "FAILED" && (
          <div
            className="notice notice--warn"
            role="alert"
          >
            Calibration quality was
            insufficient (
            {Math.round(
              (calibrationState.quality ??
                0) * 100
            )}
            % tracking quality,{" "}
            {calibrationState.sampleCount ??
              0}{" "}
            valid samples
            {Number.isFinite(calibrationState.faceCoverage)
              ? `, face usable in ${Math.round(calibrationState.faceCoverage * 100)}% of frames`
              : ""}
            ). Reposition so your face is
            clearly visible throughout, then
            try again.
          </div>
        )}
    </div>
  );
}
