import { mean, standardDeviation } from "./gazeMath.js";

/*
 * Personal-baseline construction, separated from the camera loop so it can be
 * tested without MediaPipe. Behaviour is identical to the block that used to
 * live inline in VisionTracker.finishCalibration().
 *
 * Inputs are the samples gathered during the 33 s calibration. The baseline
 * is the person's own mean and spread; later deviations are measured against
 * it. Spreads are floored so a very still person does not make every small
 * movement look like a huge deviation.
 */
/*
 * minFaceCoverage: if a usable face was missing in more than 40 % of calibration
 * frames the baseline is likely unrepresentative, so calibration fails instead
 * of silently accepting it.
 */
export const CALIBRATION_LIMITS = Object.freeze({
  minimumSamples: 100,
  qualityThreshold: 0.45,
  minFaceCoverage: 0.6,
});

export const BASELINE_FLOORS = Object.freeze({
  gazeStd: 0.001,
  hHatStd: 0.5,
  headStdDegrees: 0.1,
});

export function buildBaseline({
  gazeX,
  gazeY,
  hHat,
  head,
  quality,
  frames,
  durationMs,
  limits = CALIBRATION_LIMITS,
}) {
  const validSamples = gazeX.length;
  const averageQuality = mean(quality);
  const faceCoverage = frames > 0 ? validSamples / frames : 0;

  if (faceCoverage < limits.minFaceCoverage) {
    return { ok: false, reason: "FACE_COVERAGE", averageQuality, validSamples, faceCoverage };
  }

  if (validSamples < limits.minimumSamples) {
    return { ok: false, reason: "TOO_FEW_SAMPLES", averageQuality, validSamples };
  }

  if (averageQuality === null || averageQuality < limits.qualityThreshold) {
    return { ok: false, reason: "LOW_QUALITY", averageQuality, validSamples };
  }

  const gazeXMean = mean(gazeX);
  const gazeYMean = mean(gazeY);
  const gazeXStd = standardDeviation(gazeX, gazeXMean);
  const gazeYStd = standardDeviation(gazeY, gazeYMean);

  const axis = (key) => head.map((item) => item[key]);
  const headYaw = axis("yaw");
  const headPitch = axis("pitch");
  const headRoll = axis("roll");

  const headYawMean = mean(headYaw);
  const headPitchMean = mean(headPitch);
  const headRollMean = mean(headRoll);

  if (
    gazeXMean === null ||
    gazeYMean === null ||
    gazeXStd === null ||
    gazeYStd === null
  ) {
    return { ok: false, reason: "DEGENERATE_GAZE", averageQuality, validSamples };
  }

  const hHatValues = hHat.filter((value) => Number.isFinite(value));
  const hHatMean = mean(hHatValues);
  const hHatStd = standardDeviation(hHatValues, hHatMean);
  const floor = BASELINE_FLOORS;

  return {
    ok: true,
    baseline: {
      hHatMean: hHatMean ?? 0,
      hHatStd: Math.max(hHatStd ?? 0, floor.hHatStd),
      gazeMean: gazeXMean,
      gazeStd: Math.max(gazeXStd, floor.gazeStd),
      gazeXMean,
      gazeXStd: Math.max(gazeXStd, floor.gazeStd),
      gazeYMean,
      gazeYStd: Math.max(gazeYStd, floor.gazeStd),
      headYawMean: headYawMean ?? 0,
      headYawStd: Math.max(standardDeviation(headYaw, headYawMean) ?? 0, floor.headStdDegrees),
      headPitchMean: headPitchMean ?? 0,
      headPitchStd: Math.max(standardDeviation(headPitch, headPitchMean) ?? 0, floor.headStdDegrees),
      headRollMean: headRollMean ?? 0,
      headRollStd: Math.max(standardDeviation(headRoll, headRollMean) ?? 0, floor.headStdDegrees),
      sampleCount: validSamples,
      quality: averageQuality,
      faceCoverage,
      durationMs,
    },
  };
}
