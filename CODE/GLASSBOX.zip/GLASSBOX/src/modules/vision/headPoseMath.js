export function extractHeadPose(matrix) {
  if (!matrix || matrix.length < 16) {
    return null;
  }

  /*
   * MediaPipe provides a 4x4 facial transformation matrix.
   * We extract approximate Euler angles in degrees.
   */

  /*
   * Standard intrinsic decomposition R = Rz(roll) * Ry(yaw) * Rx(pitch)
   * of the column-major rotation block. Uniform scale in the matrix
   * cancels inside atan2. (Previously roll used atan2(r01, r11), which
   * is contaminated by yaw/pitch; see research/tests/test_headpose.py.)
   */
  const r00 = matrix[0];
  const r10 = matrix[1];
  const r20 = matrix[2];

  const r21 = matrix[6];
  const r22 = matrix[10];

  const yaw =
    Math.atan2(
      -r20,
      Math.sqrt(
        r00 * r00 +
        r10 * r10
      )
    );

  const pitch =
    Math.atan2(r21, r22);

  const roll =
    Math.atan2(r10, r00);

  return {
    yaw: yaw * (180 / Math.PI),
    pitch: pitch * (180 / Math.PI),
    roll: roll * (180 / Math.PI),
  };
}