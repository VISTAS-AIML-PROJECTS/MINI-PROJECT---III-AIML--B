import {
  FaceLandmarker,
  FilesetResolver,
} from "@mediapipe/tasks-vision";

import {
  createSignal,
  SIGNAL_TYPES,
  SIGNAL_SOURCES,
} from "../../core/signal.js";

import {
  extractGazeFeature,
} from "./gazeMath.js";

import {
  extractHeadPose,
} from "./headPoseMath.js";

import {
  estimateHorizontalGazeDeg,
} from "./linearGaze.js";

import { buildBaseline } from "./baselineMath.js";

/*
 * GAZE_DEVIATION estimator.
 *   "linear"     - z-score of the ridge gaze-angle estimate (research/results/exp09_linear_gaze.csv:
 *                  +0.06 AUROC over the iris-ratio z on MPIIFaceGaze, LOSO, both calibration protocols)
 *   "iris_ratio" - legacy horizontal iris-ratio z-score (kept for baseline comparison)
 * The other estimator is always logged in the signal metadata.
 */
const GAZE_ESTIMATOR = "linear";

/*
 * MediaPipe assets: local copies first (npm run setup:offline puts them in
 * public/mediapipe/), then the network. The CDN runtime is pinned to the
 * installed JS API version; "@latest" could silently pair this API with an
 * incompatible WASM build.
 */
const ASSET_SOURCES = [
  {
    wasm: "/mediapipe/wasm",
    model: "/mediapipe/face_landmarker.task",
  },
  {
    wasm: "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@1.0.1/wasm",
    model:
      "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task",
  },
];

const CALIBRATION_TARGETS = [
  "CENTER",
  "TOP_LEFT",
  "TOP",
  "TOP_RIGHT",
  "RIGHT",
  "BOTTOM_RIGHT",
  "BOTTOM",
  "BOTTOM_LEFT",
  "LEFT",
];

export class VisionTracker {
  constructor({
    video,
    onSignal = () => {},
    onStatus = () => {},
    onCalibrationUpdate = () => {},
    onCameraLost = () => {},

    calibrationNaturalDurationMs = 8000,

    calibrationGuidedDurationMs = 18000,

    calibrationFinalNaturalDurationMs = 7000,

    inferenceFps = 20,
  }) {
    this.video = video;

    this.onSignal = onSignal;
    this.onStatus = onStatus;
    this.onCalibrationUpdate =
      onCalibrationUpdate;

    this.onCameraLost = onCameraLost;
    this.calibrationFrames = 0;

    this.calibrationNaturalDurationMs =
      calibrationNaturalDurationMs;

    this.calibrationGuidedDurationMs =
      calibrationGuidedDurationMs;

    this.calibrationFinalNaturalDurationMs =
      calibrationFinalNaturalDurationMs;

    this.inferenceInterval =
      1000 / inferenceFps;

    this.landmarker = null;
    this.stream = null;

    this.running = false;

    this.frameId = null;
    this.lastInference = 0;
    this.lastVideoTime = -1;

    this.calibrating = false;

    this.calibrationPhase =
      "IDLE";

    this.calibrationStart = null;

    this.calibrationGazeX = [];
    this.calibrationGazeY = [];
    this.calibrationHHat = [];

    this.calibrationHead = [];
    this.calibrationQuality = [];

    this.baseline = null;

    this.predict =
      this.predict.bind(this);
  }

  emitSignal({
    type,
    value,
    confidence = 1,
    metadata = {},
  }) {
    this.onSignal(
      createSignal({
        type,
        source: SIGNAL_SOURCES.VISION,
        timestamp: Date.now(),
        value,
        confidence,
        metadata,
      })
    );
  }

  async initialize() {
    if (this.landmarker) {
      return;
    }

    this.onStatus(
      "Loading MediaPipe..."
    );

    let lastError = null;

    for (const source of ASSET_SOURCES) {
      try {
        this.landmarker =
          await this.createLandmarker(source);

        this.assetSource = source.wasm;

        return;
      } catch (error) {
        lastError = error;

        console.warn(
          `GlassBox: MediaPipe assets not available from ${source.wasm}; trying the next source.`
        );
      }
    }

    throw lastError;
  }

  async createLandmarker(source) {
    const vision =
      await FilesetResolver.forVisionTasks(
        source.wasm
      );

    return FaceLandmarker.createFromOptions(
        vision,
        {
          baseOptions: {
            modelAssetPath:
              source.model,
          },

          runningMode: "VIDEO",

          numFaces: 1,

          minFaceDetectionConfidence:
            0.5,

          minFacePresenceConfidence:
            0.5,

          minTrackingConfidence:
            0.5,

          outputFaceBlendshapes:
            false,

          outputFacialTransformationMatrixes:
            true,
        }
      );
  }

  async startCamera() {
    if (this.stream) {
      return;
    }

    this.stream =
      await navigator.mediaDevices.getUserMedia(
        {
          video: {
            facingMode: "user",

            width: {
              ideal: 640,
            },

            height: {
              ideal: 480,
            },

            frameRate: {
              ideal: 30,
              max: 30,
            },
          },

          audio: false,
        }
      );

    this.video.srcObject =
      this.stream;

    /*
     * Unplugged camera, revoked permission or another app taking
     * the device: the track ends and no further frames arrive.
     * Report it instead of silently freezing on the last frame.
     */
    for (const track of this.stream.getVideoTracks()) {
      track.addEventListener("ended", () => {
        if (this.running) {
          this.onStatus("Camera disconnected.");
          this.onCameraLost();
        }
      });
    }

    await this.video.play();
  }

  async start() {
    await this.initialize();
    await this.startCamera();

    if (this.running) {
      return;
    }

    this.running = true;

    this.onStatus(
      "Vision tracker ready."
    );

    this.frameId =
      requestAnimationFrame(
        this.predict
      );
  }

  beginCalibration() {
    if (!this.running) {
      throw new Error(
        "Vision tracker is not running."
      );
    }

    this.calibrating = true;

    this.calibrationPhase =
      "NATURAL_START";

    this.calibrationStart =
      performance.now();

    this.calibrationGazeX = [];
    this.calibrationGazeY = [];
    this.calibrationHHat = [];

    this.calibrationHead = [];
    this.calibrationQuality = [];
    this.calibrationFrames = 0;

    this.baseline = null;

    this.onCalibrationUpdate({
      phase: "NATURAL_START",
      progress: 0,
      target: "CENTER",
      targetIndex: 0,
      targetCount:
        CALIBRATION_TARGETS.length,
      remainingMs:
        this.calibrationNaturalDurationMs,
    });

    this.onStatus(
      "Calibration: sit comfortably and behave naturally."
    );
  }

  /*
   * Abandon a calibration that is running. Everything gathered so far is
   * thrown away and no baseline is produced, exactly as after a failed
   * calibration (beginCalibration() already discarded the previous baseline).
   * Does nothing, and never touches an existing baseline, when no
   * calibration is running. Calibration is driven by camera frames, not
   * timers, so there is nothing else to stop.
   */
  cancelCalibration() {
    if (!this.calibrating) {
      return false;
    }

    this.calibrating = false;
    this.calibrationPhase = "IDLE";
    this.calibrationStart = null;

    this.calibrationGazeX = [];
    this.calibrationGazeY = [];
    this.calibrationHHat = [];
    this.calibrationHead = [];
    this.calibrationQuality = [];
    this.calibrationFrames = 0;

    this.baseline = null;

    this.onCalibrationUpdate({
      phase: "IDLE",
      progress: 0,
      quality: 0,
      sampleCount: 0,
    });

    this.onStatus("Calibration cancelled.");

    return true;
  }

  updateCalibrationPhase(now) {
    if (!this.calibrating) {
      return;
    }

    const elapsed =
      now -
      this.calibrationStart;

    const naturalEnd =
      this.calibrationNaturalDurationMs;

    const guidedEnd =
      naturalEnd +
      this.calibrationGuidedDurationMs;

    const totalDuration =
      guidedEnd +
      this.calibrationFinalNaturalDurationMs;

    /*
     * Phase 1:
     * Natural personal baseline.
     */
    if (elapsed < naturalEnd) {
      this.calibrationPhase =
        "NATURAL_START";

      this.onCalibrationUpdate({
        phase: "NATURAL_START",

        progress:
          elapsed / naturalEnd,

        target: "CENTER",

        targetIndex: 0,

        targetCount:
          CALIBRATION_TARGETS.length,

        remainingMs:
          Math.max(
            naturalEnd - elapsed,
            0
          ),
      });

      return;
    }

    /*
     * Phase 2:
     * Nine-point guided calibration.
     *
     * 18 seconds / 9 targets
     * = 2 seconds per target.
     */
    if (elapsed < guidedEnd) {
      this.calibrationPhase =
        "GUIDED";

      const guidedElapsed =
        elapsed - naturalEnd;

      const targetDuration =
        this.calibrationGuidedDurationMs /
        CALIBRATION_TARGETS.length;

      const targetIndex =
        Math.min(
          Math.floor(
            guidedElapsed /
              targetDuration
          ),
          CALIBRATION_TARGETS.length - 1
        );

      this.onCalibrationUpdate({
        phase: "GUIDED",

        progress:
          guidedElapsed /
          this.calibrationGuidedDurationMs,

        target:
          CALIBRATION_TARGETS[
            targetIndex
          ],

        targetIndex,

        targetCount:
          CALIBRATION_TARGETS.length,

        remainingMs:
          Math.max(
            guidedEnd - elapsed,
            0
          ),
      });

      return;
    }

    /*
     * Phase 3:
     * Natural movement.
     */
    if (elapsed < totalDuration) {
      this.calibrationPhase =
        "NATURAL_END";

      this.onCalibrationUpdate({
        phase: "NATURAL_END",

        progress:
          (elapsed - guidedEnd) /
          this.calibrationFinalNaturalDurationMs,

        target: "CENTER",

        targetIndex:
          CALIBRATION_TARGETS.length - 1,

        targetCount:
          CALIBRATION_TARGETS.length,

        remainingMs:
          Math.max(
            totalDuration - elapsed,
            0
          ),
      });

      return;
    }

    this.finishCalibration();
  }

  /*
   * Forget the personal baseline once a session is over, so the next
   * session starts from a fresh calibration instead of inheriting this
   * one. Does nothing while a calibration is running.
   */
  clearBaseline() {
    if (this.calibrating) {
      return false;
    }

    this.baseline = null;
    this.calibrationGazeX = [];
    this.calibrationGazeY = [];
    this.calibrationHHat = [];
    this.calibrationHead = [];
    this.calibrationQuality = [];
    this.calibrationPhase = "IDLE";

    this.onCalibrationUpdate({
      phase: "IDLE",
      progress: 0,
      quality: 0,
      sampleCount: 0,
    });

    return true;
  }

  finishCalibration() {
    if (!this.calibrating) {
      return false;
    }

    this.calibrating = false;

    const built = buildBaseline({
      gazeX: this.calibrationGazeX,
      gazeY: this.calibrationGazeY,
      hHat: this.calibrationHHat,
      head: this.calibrationHead,
      quality: this.calibrationQuality,
      frames: this.calibrationFrames,
      durationMs:
        this.calibrationNaturalDurationMs +
        this.calibrationGuidedDurationMs +
        this.calibrationFinalNaturalDurationMs,
    });

    if (!built.ok) {
      return built.reason === "FACE_COVERAGE"
        ? this.failCalibration(
            built.averageQuality,
            built.validSamples,
            built.faceCoverage
          )
        : this.failCalibration(
            built.averageQuality,
            built.validSamples
          );
    }

    const averageQuality = built.baseline.quality;
    const validSamples = built.baseline.sampleCount;

    this.baseline = built.baseline;

    this.calibrationPhase =
      "COMPLETE";

    this.calibrationGazeX = [];
    this.calibrationGazeY = [];
    this.calibrationHHat = [];

    this.calibrationHead = [];
    this.calibrationQuality = [];

    this.onCalibrationUpdate({
      phase: "COMPLETE",

      progress: 1,

      quality:
        averageQuality,

      sampleCount:
        validSamples,
    });

    this.onStatus(
      "Calibration complete. Personal baseline established."
    );

    return true;
  }

  failCalibration(
    averageQuality,
    validSamples,
    faceCoverage = null
  ) {
    this.calibrating = false;

    this.calibrationPhase =
      "FAILED";

    this.onStatus(
      "Calibration quality insufficient. Please reposition yourself and try again."
    );

    this.onCalibrationUpdate({
      phase: "FAILED",

      progress: 1,

      quality:
        averageQuality ?? 0,

      sampleCount:
        validSamples,

      faceCoverage,
    });

    this.calibrationGazeX = [];
    this.calibrationGazeY = [];
    this.calibrationHHat = [];

    this.calibrationHead = [];
    this.calibrationQuality = [];

    return false;
  }

  calculateFaceQuality(
    landmarks
  ) {
    if (
      !landmarks ||
      landmarks.length === 0
    ) {
      return 0;
    }

    let minX = 1;
    let minY = 1;
    let maxX = 0;
    let maxY = 0;

    for (
      const landmark of landmarks
    ) {
      minX = Math.min(
        minX,
        landmark.x
      );

      minY = Math.min(
        minY,
        landmark.y
      );

      maxX = Math.max(
        maxX,
        landmark.x
      );

      maxY = Math.max(
        maxY,
        landmark.y
      );
    }

    const width =
      maxX - minX;

    const height =
      maxY - minY;

    const area =
      width * height;

    return Math.min(
      Math.max(
        area * 10,
        0
      ),
      1
    );
  }

  processResult(result) {
    if (this.calibrating) {
      this.calibrationFrames += 1;
    }

    if (
      !result ||
      !result.faceLandmarks ||
      result.faceLandmarks.length === 0
    ) {
      this.emitSignal({
        type:
          SIGNAL_TYPES.FACE_ABSENT,

        value: true,

        confidence: 1,

        metadata: {
          reason: "NO_FACE",
        },
      });

      /*
       * Keep the calibration clock running when no face is
       * visible, so calibration fails with "insufficient
       * samples" instead of hanging forever (observed with a
       * physical camera and nobody in view).
       */
      if (this.calibrating) {
        this.updateCalibrationPhase(
          performance.now()
        );
      }

      return;
    }

    const landmarks =
      result.faceLandmarks[0];

    const faceQuality =
      this.calculateFaceQuality(
        landmarks
      );

    this.emitSignal({
      type:
        SIGNAL_TYPES.FACE_PRESENT,

      value: true,

      confidence: 1,

      metadata: {
        landmarkCount:
          landmarks.length,
      },
    });

    this.emitSignal({
      type:
        SIGNAL_TYPES.FACE_QUALITY,

      value: faceQuality,

      confidence:
        faceQuality,

      metadata: {
        landmarkCount:
          landmarks.length,
      },
    });

    const gaze =
      extractGazeFeature(
        landmarks
      );

    const matrix =
      result
        .facialTransformationMatrixes?.[0]
        ?.data;

    const head =
      extractHeadPose(
        matrix
      );

    if (!gaze || !head) {
      if (this.calibrating) {
        this.updateCalibrationPhase(
          performance.now()
        );
      }

      return;
    }

    const hHat =
      estimateHorizontalGazeDeg(
        gaze,
        head
      );

    /*
     * Calibration.
     */
    if (this.calibrating) {
      if (faceQuality >= 0.35) {
        this.calibrationGazeX.push(
          gaze.gazeX
        );

        this.calibrationGazeY.push(
          gaze.gazeY
        );

        this.calibrationHHat.push(
          hHat
        );

        this.calibrationHead.push(
          head
        );

        this.calibrationQuality.push(
          faceQuality
        );
      }

      this.updateCalibrationPhase(
        performance.now()
      );

      return;
    }

    /*
     * No baseline yet.
     */
    if (!this.baseline) {
      return;
    }

    /*
     * Horizontal gaze deviation.
     */
    const gazeXDeviation =
      Math.abs(
        gaze.gazeX -
          this.baseline.gazeXMean
      );

    const normalizedGazeX =
      gazeXDeviation /
      this.baseline.gazeXStd;

    /*
     * Vertical gaze deviation.
     */
    const gazeYDeviation =
      Math.abs(
        gaze.gazeY -
          this.baseline.gazeYMean
      );

    const normalizedGazeY =
      gazeYDeviation /
      this.baseline.gazeYStd;

    /*
     * GAZE_DEVIATION is the HORIZONTAL z-score only.
     *
     * The vertical iris term (eyelid-referenced) carried no
     * usable signal on MPIIFaceGaze (AUROC ~0.5, Spearman < 0.1
     * with vertical gaze angle) and degraded the combined score
     * (AUROC 0.69 vs 0.77 horizontal-only; research/results/
     * exp07_vertical_term.csv). The vertical z-score is still
     * logged in metadata.
     */
    const normalizedGazeHHat =
      Number.isFinite(hHat)
        ? Math.abs(
            hHat -
              this.baseline.hHatMean
          ) /
          this.baseline.hHatStd
        : normalizedGazeX;

    const normalizedGazeDeviation =
      GAZE_ESTIMATOR === "linear"
        ? normalizedGazeHHat
        : normalizedGazeX;

    this.emitSignal({
      type:
        SIGNAL_TYPES.GAZE_DEVIATION,

      value:
        normalizedGazeDeviation,

      confidence:
        faceQuality,

      metadata: {
        estimator: GAZE_ESTIMATOR,
        zLinear: normalizedGazeHHat,
        zIrisRatio: normalizedGazeX,
        hHatDeg: hHat,

        rawDeviation: {
          x: gazeXDeviation,
          y: gazeYDeviation,
        },

        normalizedDeviation: {
          x: normalizedGazeX,
          y: normalizedGazeY,
        },

        gaze: {
          x: gaze.gazeX,
          y: gaze.gazeY,
        },

        baseline: {
          x:
            this.baseline.gazeXMean,

          y:
            this.baseline.gazeYMean,

          xStd:
            this.baseline.gazeXStd,

          yStd:
            this.baseline.gazeYStd,
        },
      },
    });

    /*
     * Head-pose deviation.
     */
    const yawDeviation =
      Math.abs(
        head.yaw -
          this.baseline.headYawMean
      );

    const pitchDeviation =
      Math.abs(
        head.pitch -
          this.baseline.headPitchMean
      );

    const rollDeviation =
      Math.abs(
        head.roll -
          this.baseline.headRollMean
      );

    const headDeviation = {
      yaw: yawDeviation,
      pitch: pitchDeviation,
      roll: rollDeviation,
    };

    this.emitSignal({
      type:
        SIGNAL_TYPES.HEAD_POSE_DEVIATION,

      value:
        headDeviation,

      confidence:
        faceQuality,

      metadata: {
        current: {
          yaw: head.yaw,
          pitch: head.pitch,
          roll: head.roll,
        },

        baseline: {
          yaw:
            this.baseline.headYawMean,

          pitch:
            this.baseline.headPitchMean,

          roll:
            this.baseline.headRollMean,
        },

        baselineStd: {
          yaw:
            this.baseline.headYawStd,

          pitch:
            this.baseline.headPitchStd,

          roll:
            this.baseline.headRollStd,
        },
      },
    });
  }

  predict(now) {
    if (!this.running) {
      return;
    }

    this.frameId =
      requestAnimationFrame(
        this.predict
      );

    if (
      !this.video ||
      !this.landmarker
    ) {
      return;
    }

    if (
      this.video.readyState <
      HTMLMediaElement.HAVE_CURRENT_DATA
    ) {
      return;
    }

    if (
      this.video.videoWidth === 0 ||
      this.video.videoHeight === 0
    ) {
      return;
    }

    if (
      now -
        this.lastInference <
      this.inferenceInterval
    ) {
      return;
    }

    if (
      this.video.currentTime ===
      this.lastVideoTime
    ) {
      return;
    }

    this.lastInference = now;

    this.lastVideoTime =
      this.video.currentTime;

    try {
      const result =
        this.landmarker.detectForVideo(
          this.video,
          now
        );

      this.processResult(
        result
      );
    } catch (error) {
      console.error(
        "GlassBox vision error:",
        error
      );
    }
  }

  getBaseline() {
    return this.baseline
      ? {
          ...this.baseline,
        }
      : null;
  }

  getCalibrationPhase() {
    return this.calibrationPhase;
  }

  stop() {
    this.running = false;

    if (
      this.frameId !== null
    ) {
      cancelAnimationFrame(
        this.frameId
      );

      this.frameId = null;
    }

    if (this.stream) {
      this.stream
        .getTracks()
        .forEach(
          (track) =>
            track.stop()
        );

      this.stream = null;
    }

    if (this.video) {
      this.video.pause();

      this.video.srcObject =
        null;
    }

    if (this.landmarker) {
      this.landmarker.close();

      this.landmarker = null;
    }

    this.calibrating = false;

    this.calibrationPhase =
      "IDLE";

    this.calibrationGazeX = [];
    this.calibrationGazeY = [];
    this.calibrationHHat = [];

    this.calibrationHead = [];
    this.calibrationQuality = [];

    this.baseline = null;
  }
}