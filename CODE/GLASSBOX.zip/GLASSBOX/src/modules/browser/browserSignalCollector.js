import {
  createSignal,
  SIGNAL_TYPES,
  SIGNAL_SOURCES,
} from "../../core/signal.js";

export function createBrowserSignalCollector(onSignal) {
  let focusLostAt = null;

  const emit = (signal) => {
    if (typeof onSignal === "function") {
      onSignal(signal);
    }
  };

  const handleVisibilityChange = () => {
    const isHidden = document.hidden;

    emit(
      createSignal({
        type: isHidden
          ? SIGNAL_TYPES.TAB_HIDDEN
          : SIGNAL_TYPES.TAB_VISIBLE,
        source: SIGNAL_SOURCES.BROWSER,
        value: isHidden,
        confidence: 1,
        metadata: {
          visibilityState: document.visibilityState,
        },
      })
    );

    /*
     * A hidden tab is a loss of focus even when the window
     * "blur" event does not fire (observed when the active
     * tab is switched programmatically). Both paths share
     * focusLostAt, so each loss/gain is emitted only once.
     */
    if (isHidden) {
      handleBlur();
    } else if (document.hasFocus()) {
      handleFocus();
    }
  };

  const handleBlur = () => {
    if (focusLostAt !== null) {
      return;
    }

    focusLostAt = Date.now();

    emit(
      createSignal({
        type: SIGNAL_TYPES.FOCUS_LOST,
        source: SIGNAL_SOURCES.BROWSER,
        value: true,
        confidence: 1,
      })
    );
  };

  const handleFocus = () => {
    if (focusLostAt === null) {
      return;
    }

    const now = Date.now();

    const duration =
      focusLostAt !== null
        ? now - focusLostAt
        : 0;

    emit(
      createSignal({
        type: SIGNAL_TYPES.FOCUS_GAINED,
        source: SIGNAL_SOURCES.BROWSER,
        value: true,
        confidence: 1,
        metadata: {
          previousFocusLossDurationMs: duration,
        },
      })
    );

    focusLostAt = null;
  };

  const handleCopy = () => {
    emit(
      createSignal({
        type: SIGNAL_TYPES.COPY,
        source: SIGNAL_SOURCES.BROWSER,
        value: true,
        confidence: 1,
      })
    );
  };

  const handlePaste = () => {
    emit(
      createSignal({
        type: SIGNAL_TYPES.PASTE,
        source: SIGNAL_SOURCES.BROWSER,
        value: true,
        confidence: 1,
      })
    );
  };

  const handleCut = () => {
    emit(
      createSignal({
        type: SIGNAL_TYPES.CUT,
        source: SIGNAL_SOURCES.BROWSER,
        value: true,
        confidence: 1,
      })
    );
  };

  const start = () => {
    document.addEventListener(
      "visibilitychange",
      handleVisibilityChange
    );

    window.addEventListener("blur", handleBlur);
    window.addEventListener("focus", handleFocus);

    document.addEventListener("copy", handleCopy);
    document.addEventListener("paste", handlePaste);
    document.addEventListener("cut", handleCut);
  };

  const stop = () => {
    document.removeEventListener(
      "visibilitychange",
      handleVisibilityChange
    );

    window.removeEventListener("blur", handleBlur);
    window.removeEventListener("focus", handleFocus);

    document.removeEventListener("copy", handleCopy);
    document.removeEventListener("paste", handlePaste);
    document.removeEventListener("cut", handleCut);
  };

  return {
    start,
    stop,
  };
}