import { useEffect, useRef } from "react";
import { createBrowserSignalCollector } from "./browserSignalCollector.js";

export function useBrowserSignals(onSignal) {
  const callbackRef = useRef(onSignal);

  useEffect(() => {
    callbackRef.current = onSignal;
  }, [onSignal]);

  useEffect(() => {
    const collector = createBrowserSignalCollector(
      (signal) => {
        callbackRef.current?.(signal);
      }
    );

    collector.start();

    return () => {
      collector.stop();
    };
  }, []);
}