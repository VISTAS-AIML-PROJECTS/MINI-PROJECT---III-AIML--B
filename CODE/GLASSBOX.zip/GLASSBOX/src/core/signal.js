// Common signal contract used by all GlassBox detection modules.

export const SIGNAL_TYPES = Object.freeze({
  // Browser signals
  TAB_HIDDEN: "TAB_HIDDEN",
  TAB_VISIBLE: "TAB_VISIBLE",
  FOCUS_LOST: "FOCUS_LOST",
  FOCUS_GAINED: "FOCUS_GAINED",
  COPY: "COPY",
  PASTE: "PASTE",
  CUT: "CUT",

  // Vision signals
  FACE_PRESENT: "FACE_PRESENT",
  FACE_ABSENT: "FACE_ABSENT",
  FACE_QUALITY: "FACE_QUALITY",
  GAZE_DEVIATION: "GAZE_DEVIATION",
  HEAD_POSE_DEVIATION: "HEAD_POSE_DEVIATION",
});

export const SIGNAL_SOURCES = Object.freeze({
  BROWSER: "browser",
  VISION: "vision",
});

export function createSignal({
  type,
  source,
  timestamp = Date.now(),
  value,
  confidence = 1,
  metadata = {},
}) {
  return {
    type,
    source,
    timestamp,
    value,
    confidence,
    metadata,
  };
}