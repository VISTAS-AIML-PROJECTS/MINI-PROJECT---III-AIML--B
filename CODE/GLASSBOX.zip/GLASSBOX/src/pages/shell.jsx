import "./pages.css";

/* ---------------------------------------------------------------
 * Navigation bar
 * ------------------------------------------------------------- */

const LINKS = [
  { to: "/", label: "Home" },
  { to: "/monitor", label: "Monitor" },
  { to: "/sessions", label: "Sessions" },
  { to: "/review", label: "Review queue" },
];

export function NavBar({ path }) {
  const isActive = (to) =>
    to === "/"
      ? path === "/"
      : path.startsWith(to) ||
        (to === "/sessions" &&
          path.startsWith("/session"));

  return (
    <header className="gb-nav">
      <a className="gb-nav__brand" href="#/">
        <span className="gb-nav__mark" aria-hidden="true" />
        GlassBox
      </a>

      <nav
        className="gb-nav__links"
        aria-label="Main"
      >
        {LINKS.map((link) => (
          <a
            key={link.to}
            href={`#${link.to}`}
            className={
              isActive(link.to)
                ? "gb-nav__link is-active"
                : "gb-nav__link"
            }
            aria-current={
              isActive(link.to)
                ? "page"
                : undefined
            }
          >
            {link.label}
          </a>
        ))}
      </nav>

    </header>
  );
}
