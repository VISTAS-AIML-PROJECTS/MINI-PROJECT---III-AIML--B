import {
  formatDateTime,
  formatDuration,
  labelFromEnum,
  levelPillClass,
  riskLevel,
  useApi,
} from "./useApi.js";

export default function Sessions() {
  const state = useApi("/sessions");

  const sessions =
    state.status === "ready"
      ? state.data.sessions ?? []
      : [];

  return (
    <main className="gb-page">
      <div className="gb-pagehead">
        <div>
          <h1>Session history</h1>

          <p className="gb-lead">
            Recorded monitoring sessions on this
            machine. The risk score is a rule-based
            evidence summary, not a probability of
            cheating.
          </p>
        </div>

        <a
          className="gb-btn gb-btn--primary"
          href="#/monitor"
        >
          New session
        </a>
      </div>

      {state.status === "loading" && (
        <div className="gb-empty" role="status">
          Loading sessions…
        </div>
      )}

      {state.status === "error" && (
        <div className="gb-empty gb-empty--bad" role="alert">
          <strong>Backend not reachable.</strong>
          <p>
            Start it with{" "}
            <code>node server/server.js</code> and
            reload. ({state.message})
          </p>
        </div>
      )}

      {state.status === "ready" &&
        sessions.length === 0 && (
          <div className="gb-empty">
            <strong>No sessions yet.</strong>

            <p>
              Start a session on the Monitor page;
              it will appear here when saved.
            </p>
          </div>
        )}

      {sessions.length > 0 && (
        <div className="gb-tablewrap">
          <table className="gb-table">
            <caption className="gb-sr">
              Recorded sessions
            </caption>

            <thead>
              <tr>
                <th scope="col">Session</th>
                <th scope="col">Started</th>
                <th scope="col">Duration</th>
                <th scope="col">Condition</th>
                <th scope="col">Status</th>
                <th scope="col" className="gb-num">
                  Signals
                </th>
                <th scope="col" className="gb-num">
                  Events
                </th>
                <th scope="col">Peak risk</th>
                <th scope="col">Final state</th>
                <th scope="col">
                  <span className="gb-sr">
                    Open
                  </span>
                </th>
              </tr>
            </thead>

            <tbody>
              {sessions.map((s) => {
                const level = riskLevel(
                  s.peak_risk
                );

                return (
                  <tr key={s.id}>
                    <th scope="row">#{s.id}</th>

                    <td>
                      {formatDateTime(
                        s.started_at
                      )}
                    </td>

                    <td>
                      {formatDuration(
                        s.started_at,
                        s.ended_at
                      )}
                    </td>

                    <td>
                      {s.condition ? labelFromEnum(s.condition) : "—"}
                    </td>

                    <td>{labelFromEnum(s.status)}</td>

                    <td className="gb-num">
                      {s.signal_count}
                    </td>

                    <td className="gb-num">
                      {s.evidence_count}
                    </td>

                    <td>
                      {level ? (
                        <span
                          className={levelPillClass(
                            level
                          )}
                        >
                          {Math.round(
                            s.peak_risk
                          )}{" "}
                          · {level}
                        </span>
                      ) : (
                        "—"
                      )}
                    </td>

                    <td>
                      {s.final_state ? labelFromEnum(s.final_state) : "—"}
                    </td>

                    <td>
                      <a
                        className="gb-link"
                        href={`#/session/${s.id}`}
                        aria-label={`Open session ${s.id}`}
                      >
                        Details →
                      </a>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </main>
  );
}
