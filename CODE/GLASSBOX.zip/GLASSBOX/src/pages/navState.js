import { useSyncExternalStore } from "react";

/* ---------------------------------------------------------------
 * Tiny hash router (no dependency). Routes:
 *   #/  #/login  #/sessions  #/session/:id  #/monitor
 * ------------------------------------------------------------- */

function subscribe(callback) {
  window.addEventListener("hashchange", callback);

  return () =>
    window.removeEventListener(
      "hashchange",
      callback
    );
}

function getHash() {
  return window.location.hash || "#/";
}

export function useRoute() {
  const hash = useSyncExternalStore(
    subscribe,
    getHash,
    () => "#/"
  );

  const path =
    hash.replace(/^#/, "") || "/";

  const parts = path
    .split("/")
    .filter(Boolean);

  return { path, parts };
}

export function go(path) {
  window.location.hash = path;
}

/* ---------------------------------------------------------------
 * DEMO sign-in. This is NOT authentication: there is no password,
 * nothing is verified or sent to a server, and every page works
 * without it. It only stores a display name in this browser.
 * ------------------------------------------------------------- */

const DEMO_KEY = "glassbox_demo_name";

function subscribeDemo(callback) {
  window.addEventListener("storage", callback);
  window.addEventListener("glassbox-demo", callback);

  return () => {
    window.removeEventListener("storage", callback);
    window.removeEventListener(
      "glassbox-demo",
      callback
    );
  };
}

function readDemo() {
  try {
    return (
      window.localStorage.getItem(
        DEMO_KEY
      ) || ""
    );
  } catch {
    return "";
  }
}

export function useDemoUser() {
  return useSyncExternalStore(
    subscribeDemo,
    readDemo,
    () => ""
  );
}

export function setDemoUser(name) {
  try {
    if (name) {
      window.localStorage.setItem(
        DEMO_KEY,
        name
      );
    } else {
      window.localStorage.removeItem(
        DEMO_KEY
      );
    }
  } catch {
    /* storage unavailable: ignore */
  }

  window.dispatchEvent(
    new Event("glassbox-demo")
  );
}
