import { useEffect, useState } from "react";

export const API_BASE = "http://localhost:5000/api";

/*
 * Minimal GET hook: { status: "loading" | "ready" | "error", data, message }.
 */
export function useApi(path) {
  const [state, setState] = useState({
    status: "loading",
  });

  useEffect(() => {
    let cancelled = false;

    fetch(`${API_BASE}${path}`)
      .then((response) =>
        response.ok
          ? response.json()
          : Promise.reject(
              new Error(
                `HTTP ${response.status}`
              )
            )
      )
      .then((data) => {
        if (!cancelled) {
          setState({ status: "ready", data });
        }
      })
      .catch((error) => {
        if (!cancelled) {
          setState({
            status: "error",
            message: String(
              error?.message ?? error
            ),
          });
        }
      });

    return () => {
      cancelled = true;
    };
  }, [path]);

  return state;
}

/* Same boundaries as the assessment level bands (30 / 60), without hysteresis. */
export function riskLevel(score) {
  if (score === null || score === undefined) {
    return null;
  }

  if (score < 30) return "LOW";
  if (score < 60) return "MEDIUM";

  return "HIGH";
}

export function levelPillClass(level) {
  if (level === "LOW") return "gb-pill gb-pill--ok";
  if (level === "MEDIUM") return "gb-pill gb-pill--warn";
  if (level === "HIGH") return "gb-pill gb-pill--bad";

  return "gb-pill gb-pill--idle";
}

export function formatDuration(startIso, endIso) {
  if (!startIso || !endIso) {
    return "—";
  }

  const seconds = Math.max(
    0,
    Math.round(
      (new Date(endIso) -
        new Date(startIso)) /
        1000
    )
  );

  const m = Math.floor(seconds / 60);
  const s = String(seconds % 60).padStart(2, "0");

  return `${m}:${s}`;
}

export function formatDateTime(iso) {
  if (!iso) {
    return "—";
  }

  return new Date(iso).toLocaleString();
}

/* Presentation only: "LOOK_AWAY" -> "Look away". Mirrors nothing in the pipeline. */
export function labelFromEnum(value) {
  if (!value) return value;
  return String(value)
    .replace(/_/g, " ")
    .toLowerCase()
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

export const EVIDENCE_LABELS = {
  FOCUS_LOSS_EPISODE: "Focus loss",
  FACE_ABSENCE_EPISODE: "Face absence",
  GAZE_DEVIATION_EPISODE: "Gaze deviation",
  HEAD_POSE_DEVIATION_EPISODE: "Head-pose deviation",
};
