import { useState } from "react";

import { go, setDemoUser } from "./navState.js";

export default function Login() {
  const [name, setName] = useState("");

  const submit = (event) => {
    event.preventDefault();

    const clean = name.trim();

    if (!clean) {
      return;
    }

    setDemoUser(clean);
    go("/sessions");
  };

  return (
    <main className="gb-page gb-page--narrow">
      <section className="gb-card">
        <span className="gb-pill gb-pill--warn">
          Demo only · not real authentication
        </span>

        <h1>Sign in</h1>

        <p className="gb-lead">
          This screen only stores a display name in
          this browser so the demo can show who is
          presenting. There is no password, no
          account, and nothing is sent to a server.
          Every page works without signing in.
        </p>

        <form onSubmit={submit}>
          <div className="gb-field">
            <label htmlFor="demo-name">
              Display name
            </label>

            <input
              id="demo-name"
              type="text"
              value={name}
              autoComplete="off"
              placeholder="e.g. Reviewer"
              onChange={(e) =>
                setName(e.target.value)
              }
            />
          </div>

          <div className="gb-actions">
            <button
              className="gb-btn gb-btn--primary"
              type="submit"
              disabled={!name.trim()}
            >
              Continue as demo user
            </button>

            <a className="gb-btn" href="#/">
              Back
            </a>
          </div>
        </form>
      </section>
    </main>
  );
}
