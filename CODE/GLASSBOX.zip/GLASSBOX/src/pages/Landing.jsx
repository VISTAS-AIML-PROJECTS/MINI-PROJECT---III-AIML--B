export default function Landing() {
  return (
    <main className="gb-page">
      <section className="gb-hero">
        <p className="gb-eyebrow">
          Explainable exam-monitoring research prototype
        </p>

        <h1>
          See what the evidence shows,
          <br />
          and why.
        </h1>

        <p className="gb-lead">
          GlassBox turns webcam signals and browser
          activity into transparent, reviewable
          evidence episodes with a plain-language
          explanation. It supports a human
          reviewer; it does not decide that anyone
          cheated.
        </p>

        <div className="gb-actions">
          <a
            className="gb-btn gb-btn--primary"
            href="#/monitor"
          >
            Start monitoring
          </a>

          <a className="gb-btn" href="#/sessions">
            View session history
          </a>
        </div>

        <p className="gb-note">
          Research prototype. Cheating detection has
          not been demonstrated.
        </p>
      </section>

      <section
        className="gb-grid gb-grid--3"
        aria-label="How it works"
      >
        <article className="gb-card">
          <h2>1 · Calibrate</h2>

          <p>
            A 33-second personal calibration records
            how you normally sit, look and move, so
            later deviations are measured against
            your own baseline.
          </p>
        </article>

        <article className="gb-card">
          <h2>2 · Observe</h2>

          <p>
            MediaPipe landmarks give gaze, head pose
            and face presence; the browser reports
            focus and tab changes. Short blips are
            filtered out.
          </p>
        </article>

        <article className="gb-card">
          <h2>3 · Explain</h2>

          <p>
            Episodes feed a rule-based risk summary
            with reasons. Nothing is hidden: every
            threshold is documented, and the score is
            not a probability.
          </p>
        </article>
      </section>

      <footer className="gb-footer">
        GlassBox · non-commercial research prototype ·
        data stays on this machine (SQLite, local
        server).
      </footer>
    </main>
  );
}
