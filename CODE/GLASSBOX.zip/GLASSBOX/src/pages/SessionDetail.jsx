import {
  EVIDENCE_LABELS,
  formatDateTime,
  formatDuration,
  labelFromEnum,
  levelPillClass,
  riskLevel,
  useApi,
} from "./useApi.js";
import {
  reviewFirst,
  segmentHeadDeviation,
} from "../review/reviewPriority.js";
import { summarizeRisk } from "../review/sessionSummary.js";
import { DEVIATION_CONFIG } from "../evidence/deviation.js";

const W = 720;
const H = 170;
const PAD = { l: 34, r: 10, t: 10, b: 22 };

const pct = (v) =>
  v === null || v === undefined ? "—" : `${Math.round(v * 100)}%`;

const offset = (t, startMs) =>
  `+${Math.max(0, (t - startMs) / 1000).toFixed(0)} s`;

function RiskTimeline({ risk, startMs, endMs, summary }) {
  if (!risk.length) {
    return (
      <div className="gb-empty">
        No risk samples were recorded.
      </div>
    );
  }

  const span = Math.max(endMs - startMs, 1);
  const step = Math.max(
    1,
    Math.floor(risk.length / 300)
  );

  const xAt = (t) =>
    PAD.l +
    ((t - startMs) / span) *
      (W - PAD.l - PAD.r);

  const yAt = (v) =>
    PAD.t +
    (1 - v / 100) * (H - PAD.t - PAD.b);

  const line = (pick) =>
    risk
      .filter((_, i) => i % step === 0)
      .filter((r) => Number.isFinite(pick(r)))
      .map((r) => `${xAt(r.timestamp).toFixed(1)},${yAt(pick(r)).toFixed(1)}`)
      .join(" ");

  const legacy = line((r) => r.details?.legacy?.score);

  const shade = (runs, cls) =>
    runs.map(([a, b]) => (
      <rect
        key={`${cls}-${a}`}
        x={xAt(a)}
        y={PAD.t}
        width={Math.max(xAt(b + 1000) - xAt(a), 2)}
        height={H - PAD.t - PAD.b}
        className={cls}
      />
    ));

  return (
    <figure className="gb-figure">
      <svg
        viewBox={`0 0 ${W} ${H}`}
        role="img"
        aria-label="Risk score over the session"
      >
        <rect
          x={PAD.l}
          y={yAt(30)}
          width={W - PAD.l - PAD.r}
          height={yAt(0) - yAt(30)}
          className="gb-band gb-band--low"
        />

        <rect
          x={PAD.l}
          y={yAt(60)}
          width={W - PAD.l - PAD.r}
          height={yAt(30) - yAt(60)}
          className="gb-band gb-band--mid"
        />

        <rect
          x={PAD.l}
          y={yAt(100)}
          width={W - PAD.l - PAD.r}
          height={yAt(60) - yAt(100)}
          className="gb-band gb-band--high"
        />

        {summary && shade(summary.degradedRuns, "gb-shade gb-shade--degraded")}
        {summary && shade(summary.insufficientRuns, "gb-shade gb-shade--insufficient")}

        {[0, 30, 60, 100].map((v) => (
          <text
            key={v}
            x={PAD.l - 6}
            y={yAt(v) + 4}
            textAnchor="end"
            className="gb-axis"
          >
            {v}
          </text>
        ))}

        {legacy && (
          <polyline
            points={legacy}
            fill="none"
            className="gb-line gb-line--legacy"
          />
        )}

        <polyline
          points={line((r) => Number(r.score))}
          fill="none"
          className="gb-line"
        />

        <text
          x={PAD.l}
          y={H - 5}
          className="gb-axis"
        >
          0 s
        </text>

        <text
          x={W - PAD.r}
          y={H - 5}
          textAnchor="end"
          className="gb-axis"
        >
          {Math.round(span / 1000)} s
        </text>
      </svg>

      <figcaption>
        Risk index over time (bands: LOW &lt; 30 ≤ MEDIUM &lt; 60 ≤
        HIGH). Grey: not enough could be observed; hatched:
        limited observation.
        {legacy && " Dashed: the previous (v1) engine, for comparison."}{" "}
        A rule-based review index, not a probability.
      </figcaption>
    </figure>
  );
}

export default function SessionDetail({ id }) {
  const state = useApi(`/sessions/${id}`);

  if (state.status === "loading") {
    return (
      <main className="gb-page">
        <div className="gb-empty" role="status">
          Loading session…
        </div>
      </main>
    );
  }

  if (state.status === "error") {
    return (
      <main className="gb-page">
        <div className="gb-empty gb-empty--bad" role="alert">
          <strong>Could not load session #{id}.</strong>

          <p>
            {state.message}. Is the backend running
            and does this session exist?
          </p>

          <a className="gb-link" href="#/sessions">
            ← Back to sessions
          </a>
        </div>
      </main>
    );
  }

  const { session, signals, evidence, risk } =
    state.data;

  const startMs = new Date(
    session.started_at
  ).getTime();

  // Cover every stored row even if it is stamped after ended_at.
  const endMs = Math.max(
    session.ended_at
      ? new Date(session.ended_at).getTime()
      : startMs + 1000,
    risk.length ? risk[risk.length - 1].timestamp : 0,
    signals.length ? signals[signals.length - 1].timestamp : 0
  );

  const summary = summarizeRisk(risk);

  const peakLevel = summary ? riskLevel(summary.peak) : null;
  const finalLevel = summary
    ? (summary.finalLevel ?? riskLevel(summary.final))
    : null;

  const segments = segmentHeadDeviation(signals, {
    startMs,
  });
  // Only segments past the engine's own head-pose gate are worth a look.
  const priority = reviewFirst(segments).filter(
    (s) => s.maxDeg >= DEVIATION_CONFIG.headMinDegrees
  );

  const counts = signals.reduce((acc, s) => {
    acc[s.type] = (acc[s.type] ?? 0) + 1;

    return acc;
  }, {});

  return (
    <main className="gb-page">
      <p>
        <a className="gb-link" href="#/sessions">
          ← All sessions
        </a>
      </p>

      <div className="gb-pagehead">
        <div>
          <h1>Session #{session.id}</h1>

          <p className="gb-lead">
            {formatDateTime(session.started_at)} ·{" "}
            {labelFromEnum(session.status)} ·{" "}
            {session.condition
              ? labelFromEnum(session.condition)
              : "No label"}
          </p>
        </div>
      </div>

      {session.status === "INTERRUPTED" && (
        <div className="gb-empty gb-empty--bad" role="note">
          This session was not ended normally (page closed or
          app stopped). Data after the last stored row is missing.
        </div>
      )}

      <section
        className="gb-grid gb-grid--4"
        aria-label="Summary"
      >
        <div className="gb-card gb-stat">
          <span>Duration</span>

          <strong>
            {formatDuration(
              session.started_at,
              session.ended_at
            )}
          </strong>
        </div>

        <div className="gb-card gb-stat">
          <span>Evidence events</span>
          <strong>{evidence.length}</strong>
        </div>

        <div className="gb-card gb-stat">
          <span>Peak risk</span>

          <strong>
            {summary ? Math.round(summary.peak) : "—"}{" "}
            {peakLevel && (
              <em className={levelPillClass(peakLevel)}>
                {peakLevel}
              </em>
            )}
          </strong>
        </div>

        <div className="gb-card gb-stat">
          <span>Final assessment</span>

          <strong>
            {summary
              ? finalLevel === "UNDETERMINED"
                ? "—"
                : Math.round(summary.final)
              : "—"}{" "}
            {finalLevel && (
              <em className={levelPillClass(finalLevel)}>
                {labelFromEnum(finalLevel)}
              </em>
            )}
          </strong>
        </div>
      </section>

      {summary?.finalState && (
        <section className="gb-card">
          <h2>Observation quality</h2>

          <p className="gb-muted">
            How much of the session could actually be observed.
            Low coverage means a low score is not evidence of
            low risk.
          </p>

          <ul className="gb-chips">
            <li className="gb-chip">
              Mean reliability <strong>{pct(summary.meanReliability)}</strong>
            </li>
            <li className="gb-chip">
              Fully observed <strong>{pct(summary.shareOk)}</strong>
            </li>
            <li className="gb-chip">
              Limited <strong>{pct(summary.shareDegraded)}</strong>
            </li>
            <li className="gb-chip">
              Insufficient <strong>{pct(summary.shareInsufficient)}</strong>
            </li>
            <li className="gb-chip">
              Time at MEDIUM or HIGH <strong>{pct(summary.shareMediumOrHigh)}</strong>
            </li>
            <li className="gb-chip">
              Engine <strong>{summary.engineVersion}</strong>
            </li>
          </ul>
        </section>
      )}

      <section className="gb-card">
        <h2>Risk timeline</h2>

        <RiskTimeline
          risk={risk}
          startMs={startMs}
          endMs={endMs}
          summary={summary}
        />
      </section>

      <section className="gb-card">
        <h2>Segments to review first</h2>

        <p className="gb-muted">
          10-second segments with the largest head turn away from
          the student&apos;s own calibrated position. Behavioural
          priority for human review – not evidence of misconduct.
          On the OEP dataset this ordering ranked annotated
          intervals modestly above chance (AUROC ≈ 0.59–0.60).
        </p>

        {priority.length === 0 ? (
          <div className="gb-empty">
            {segments.length === 0
              ? "No head-pose samples were stored (no calibration, or the face was never visible)."
              : `No 10-second segment had a head turn of ${DEVIATION_CONFIG.headMinDegrees}° or more from the calibrated position.`}
          </div>
        ) : (
          <div className="gb-tablewrap">
            <table className="gb-table">
              <caption className="gb-sr">
                Segments ordered by head-pose deviation
              </caption>

              <thead>
                <tr>
                  <th scope="col">Segment</th>
                  <th scope="col" className="gb-num">
                    Max deviation
                  </th>
                  <th scope="col">Axis</th>
                  <th scope="col" className="gb-num">
                    Samples
                  </th>
                </tr>
              </thead>

              <tbody>
                {priority.map((s) => (
                  <tr key={s.index}>
                    <td className="gb-mono">
                      {offset(s.start, startMs)} – {offset(s.end, startMs)}
                    </td>
                    <td className="gb-num">
                      {s.maxDeg.toFixed(1)}°
                    </td>
                    <td>{s.axis}</td>
                    <td className="gb-num">{s.samples}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <section className="gb-card">
        <h2>Evidence events</h2>

        {evidence.length === 0 ? (
          <div className="gb-empty">
            Nothing was flagged in this session.
          </div>
        ) : (
          <div className="gb-tablewrap">
            <table className="gb-table">
              <caption className="gb-sr">
                Evidence episodes
              </caption>

              <thead>
                <tr>
                  <th scope="col">At</th>
                  <th scope="col">Event</th>
                  <th scope="col" className="gb-num">
                    Duration
                  </th>
                  <th scope="col" className="gb-num">
                    Strength
                  </th>
                </tr>
              </thead>

              <tbody>
                {evidence.map((e) => (
                  <tr key={e.id}>
                    <td className="gb-mono">
                      +
                      {(
                        (e.timestamp - startMs) /
                        1000
                      ).toFixed(1)}{" "}
                      s
                    </td>

                    <td>
                      {EVIDENCE_LABELS[e.type] ??
                        e.type}
                      {e.metadata?.endedBy === "SESSION_END" && (
                        <span className="gb-muted"> (still ongoing at session end)</span>
                      )}
                    </td>

                    <td className="gb-num">
                      {e.duration_ms >= 1000
                        ? `${(e.duration_ms / 1000).toFixed(1)} s`
                        : `${Math.round(e.duration_ms)} ms`}
                    </td>

                    <td className="gb-num">
                      {Number(e.strength).toFixed(2)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <section className="gb-card">
        <h2>Recorded signals</h2>

        <p className="gb-muted">
          Counts of persisted raw signals (vision
          samples are stored about once per second).
        </p>

        <ul className="gb-chips">
          {Object.entries(counts).map(
            ([type, n]) => (
              <li key={type} className="gb-chip">
                {labelFromEnum(type)}
                <strong>{n}</strong>
              </li>
            )
          )}
        </ul>
      </section>
    </main>
  );
}
