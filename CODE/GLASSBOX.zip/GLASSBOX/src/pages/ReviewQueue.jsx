import { useMemo, useState } from "react";

import { addReviewDecision } from "../api/glassboxApi.js";
import {
  REVIEW_STATUS_TEXT,
  evidenceTimeline,
  peakBreakdown,
  queueStats,
  reviewStatus,
  sessionSpan,
  sortForReview,
} from "../review/reviewQueue.js";
import { summarizeRisk } from "../review/sessionSummary.js";
import {
  EVIDENCE_LABELS,
  formatDuration,
  levelPillClass,
  riskLevel,
  useApi,
} from "./useApi.js";

import "./review.css";

/*
 * Review queue (#/review): recorded sessions ordered for a person to review,
 * with the stored evidence of the selected session and an append-only record
 * of the reviewer's decision. Every number shown is read from the API; the
 * page computes no new score.
 */

const STATUS_CLASS = {
  PENDING: "rq-status rq-status--pending",
  CLEARED: "rq-status rq-status--cleared",
  FOLLOW_UP: "rq-status rq-status--followup",
  IN_PROGRESS: "rq-status rq-status--idle",
};

const BAND_TEXT = {
  HIGH: "High band (≥ 60)",
  MEDIUM: "Medium band (30–59)",
  LOW: "Low band (< 30)",
};

const EVIDENCE_CLASS = {
  FACE_ABSENCE_EPISODE: "rq-seg rq-seg--absence",
  FOCUS_LOSS_EPISODE: "rq-seg rq-seg--focus",
  HEAD_POSE_DEVIATION_EPISODE: "rq-seg rq-seg--head",
  GAZE_DEVIATION_EPISODE: "rq-seg rq-seg--gaze",
};

const titleCase = (s) => (s ? s.charAt(0) + s.slice(1).toLowerCase() : s);

const shortDateTime = (iso) =>
  iso
    ? new Date(iso).toLocaleString(undefined, {
        dateStyle: "medium",
        timeStyle: "short",
      })
    : "—";

const seconds = (ms) => `${Math.round(ms / 1000)} s`;

export default function ReviewQueue() {
  const [version, setVersion] = useState(0);
  const [selectedId, setSelectedId] = useState(null);
  const list = useApi(`/sessions?v=${version}`);

  const sessions = useMemo(
    () => (list.status === "ready" ? list.data.sessions ?? [] : []),
    [list]
  );
  const sorted = useMemo(() => sortForReview(sessions), [sessions]);
  const stats = queueStats(sessions);
  const current =
    sorted.find((s) => s.id === selectedId) ?? sorted[0] ?? null;

  return (
    <main className="gb-page gb-page--wide">
      <div className="gb-pagehead">
        <div>
          <h1>Review queue</h1>

          <p className="gb-lead">
            Recorded sessions ordered for human review, highest peak risk
            first. The risk score is a rule-based evidence summary produced
            automatically, not a probability of cheating; the review decision
            for each session is made by a person.
          </p>
        </div>
      </div>

      {list.status === "loading" && (
        <div className="gb-empty" role="status">
          Loading sessions…
        </div>
      )}

      {list.status === "error" && (
        <div className="gb-empty gb-empty--bad" role="alert">
          <strong>Backend not reachable.</strong>
          <p>
            Start it with <code>node server/server.js</code> and reload. (
            {list.message})
          </p>
        </div>
      )}

      {list.status === "ready" && (
        <>
          <section className="rq-stats" aria-label="Queue summary">
            <div className="rq-stat">
              <span>Sessions today</span>
              <strong>{stats.sessionsToday}</strong>
              <small>{stats.total} recorded in total</small>
            </div>

            <div className="rq-stat">
              <span>Pending review</span>
              <strong>{stats.pending}</strong>
              <small>finished, no decision yet</small>
            </div>

            <div className="rq-stat">
              <span>Flagged high risk</span>
              <strong>
                {stats.flaggedHigh} <em>of {stats.total}</em>
              </strong>
              <small>peak risk ≥ 60</small>
            </div>

            <div className="rq-stat">
              <span>Reviewed today</span>
              <strong>{stats.reviewedToday}</strong>
              <small>decisions recorded today</small>
            </div>
          </section>

          {sorted.length === 0 ? (
            <div className="gb-empty">
              <strong>No sessions yet.</strong>
              <p>
                Record a session on the Monitor page; it will appear here when
                saved.
              </p>
            </div>
          ) : (
            <div className="rq-layout">
              <section className="rq-card" aria-labelledby="rq-sessions">
                <h2 id="rq-sessions">Sessions</h2>

                <p className="rq-sub">
                  Sorted by peak risk score, highest first. Select a row to
                  inspect its evidence.
                </p>

                <div className="rq-tablewrap">
                  <table className="rq-table">
                    <caption className="gb-sr">
                      Sessions ordered for review
                    </caption>

                    <thead>
                      <tr>
                        <th scope="col">Session</th>
                        <th scope="col">Started</th>
                        <th scope="col" className="gb-num">
                          Duration
                        </th>
                        <th scope="col">Peak risk</th>
                        <th scope="col">Review status</th>
                      </tr>
                    </thead>

                    <tbody>
                      {sorted.map((s) => {
                        const peak =
                          s.peak_risk === null || s.peak_risk === undefined
                            ? null
                            : Math.round(Number(s.peak_risk));
                        const level = riskLevel(peak);
                        const status = reviewStatus(s);
                        const selected = current && s.id === current.id;

                        return (
                          <tr
                            key={s.id}
                            className={selected ? "is-selected" : undefined}
                            onClick={() => setSelectedId(s.id)}
                          >
                            <th scope="row">
                              <button
                                type="button"
                                className="rq-rowbtn"
                                aria-pressed={selected ? "true" : "false"}
                                onClick={(event) => {
                                  event.stopPropagation();
                                  setSelectedId(s.id);
                                }}
                              >
                                #{s.id}
                              </button>
                            </th>

                            <td>{shortDateTime(s.started_at)}</td>

                            <td className="gb-num">
                              {formatDuration(s.started_at, s.ended_at)}
                            </td>

                            <td>
                              {level ? (
                                <span className={levelPillClass(level)}>
                                  {peak} · {titleCase(level)}
                                </span>
                              ) : (
                                <span className="rq-muted">No assessment</span>
                              )}
                            </td>

                            <td>
                              <span className={STATUS_CLASS[status]}>
                                {REVIEW_STATUS_TEXT[status]}
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </section>

              {current && (
                <SessionReviewPanel
                  key={current.id}
                  session={current}
                  version={version}
                  onDecided={() => setVersion((v) => v + 1)}
                />
              )}
            </div>
          )}
        </>
      )}
    </main>
  );
}

function SessionReviewPanel({ session, version, onDecided }) {
  const detail = useApi(`/sessions/${session.id}?v=${version}`);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [noteOpen, setNoteOpen] = useState(false);
  const [note, setNote] = useState("");

  const data =
    detail.status === "ready" && detail.data?.session?.id === session.id
      ? detail.data
      : null;

  const status = reviewStatus(session);
  const summary = data ? summarizeRisk(data.risk) : null;
  const peak = data ? peakBreakdown(data.risk) : null;
  const span = data
    ? sessionSpan(data.session, data.risk, data.evidence, data.signals)
    : null;
  const timeline = data
    ? evidenceTimeline(data.evidence, span.start, span.end)
    : [];
  const reviews = data?.reviews ?? [];
  const lastDecision = [...reviews].reverse().find((r) => r.decision !== "NOTE");

  const decide = async (decision, text) => {
    setBusy(true);
    setError("");

    try {
      await addReviewDecision(session.id, decision, text);
      setNote("");
      setNoteOpen(false);
      onDecided();
    } catch (e) {
      setError(String(e?.message ?? e));
    } finally {
      setBusy(false);
    }
  };

  const level = peak ? riskLevel(peak.score) : null;
  const observed =
    summary && summary.shareOk !== null
      ? `fully observed ${Math.round(summary.shareOk * 100)}% of the time`
      : "observation quality not recorded (older session)";

  return (
    <section className="rq-card rq-panel" aria-labelledby="rq-selected">
      <div className="rq-panel__head">
        <h2 id="rq-selected">Session #{session.id}</h2>
        <span className={STATUS_CLASS[status]}>
          {status === "PENDING" ? "Pending review" : REVIEW_STATUS_TEXT[status]}
        </span>
      </div>

      <p className="rq-meta">
        {shortDateTime(session.started_at)} ·{" "}
        {formatDuration(session.started_at, session.ended_at)} ·{" "}
        {data ? observed : "…"}
      </p>

      {detail.status === "error" && (
        <div className="gb-empty gb-empty--bad" role="alert">
          Could not load this session ({detail.message}).
        </div>
      )}

      {!data && detail.status !== "error" && (
        <p className="rq-muted" role="status">
          Loading session evidence…
        </p>
      )}

      {data && (
        <>
          <div className="rq-peak">
            <strong>{peak ? Math.round(peak.score) : "—"}</strong>
            <div>
              <span className="rq-label">Peak risk</span>
              <span>{level ? BAND_TEXT[level] : "No stored assessment"}</span>
            </div>
          </div>

          <div className="rq-block">
            <h3 className="rq-label">
              {peak?.kind === "v1"
                ? "v1 engine components at the peak"
                : "Channel evidence at the peak"}
            </h3>

            {peak && peak.items.length ? (
              <ul className="rq-bars">
                {peak.items.map((item) => (
                  <li key={item.key}>
                    <span>{item.label}</span>
                    <span className="rq-meter" aria-hidden="true">
                      <span style={{ width: `${item.value * 100}%` }} />
                    </span>
                    <span className="rq-num">{item.value.toFixed(2)}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="rq-muted">No channel evidence was stored.</p>
            )}

            <p className="rq-caption">
              Stored per-channel evidence (0–1) of the assessment at its peak;
              not a probability.
            </p>
          </div>

          <div className="rq-block">
            <h3 className="rq-label">Evidence timeline</h3>

            {timeline.length ? (
              <>
                <div className="rq-track" role="img" aria-label={`${timeline.length} evidence episodes across the session`}>
                  {timeline.map((seg) => (
                    <span
                      key={seg.id}
                      className={EVIDENCE_CLASS[seg.type] ?? "rq-seg"}
                      style={{ left: `${seg.leftPct}%`, width: `${seg.widthPct}%` }}
                      title={`${EVIDENCE_LABELS[seg.type] ?? seg.type} · from +${seconds(seg.startOffsetMs)} for ${seconds(seg.durationMs)}${seg.strength !== null ? ` · strength ${seg.strength.toFixed(2)}` : ""}`}
                    />
                  ))}
                </div>

                <p className="rq-legend">
                  <span className="rq-key rq-seg--head" /> Head pose
                  <span className="rq-key rq-seg--gaze" /> Gaze
                  <span className="rq-key rq-seg--absence" /> Face absence
                  <span className="rq-key rq-seg--focus" /> Focus loss
                  <span className="rq-muted"> · {timeline.length} episodes</span>
                </p>
              </>
            ) : (
              <p className="rq-muted">
                No evidence episodes were stored for this session.
              </p>
            )}
          </div>

          <a className="gb-link" href={`#/session/${session.id}`}>
            Open full session details →
          </a>
        </>
      )}

      <div className="rq-decision">
        <h3 className="rq-label">Human review decision</h3>

        <p className="rq-note">
          The automated score prioritises this session for review; it is not a
          finding of misconduct.
        </p>

        {status === "IN_PROGRESS" ? (
          <p className="rq-muted">
            This session is still running; review it after it ends.
          </p>
        ) : (
          <>
            <div className="rq-buttons">
              <button
                type="button"
                className="gb-btn gb-btn--primary"
                disabled={busy}
                onClick={() => decide("CLEARED", note)}
              >
                Mark reviewed — cleared
              </button>

              <button
                type="button"
                className="gb-btn"
                disabled={busy}
                onClick={() => decide("FOLLOW_UP", note)}
              >
                Flag for follow-up
              </button>

              <button
                type="button"
                className="gb-btn"
                disabled={busy}
                aria-expanded={noteOpen ? "true" : "false"}
                onClick={() => setNoteOpen((open) => !open)}
              >
                Add note
              </button>
            </div>

            {noteOpen && (
              <div className="rq-notebox">
                <label htmlFor="rq-note-text" className="rq-label">
                  Note (saved with the next decision, or on its own)
                </label>

                <textarea
                  id="rq-note-text"
                  rows={3}
                  maxLength={2000}
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                />

                <button
                  type="button"
                  className="gb-btn"
                  disabled={busy || !note.trim()}
                  onClick={() => decide("NOTE", note)}
                >
                  Save note
                </button>
              </div>
            )}
          </>
        )}

        {error && (
          <p className="rq-error" role="alert">
            {error}
          </p>
        )}

        {lastDecision && (
          <p className="rq-muted">
            Last decision: {REVIEW_STATUS_TEXT[lastDecision.decision]} ·{" "}
            {shortDateTime(lastDecision.created_at)}
          </p>
        )}

        {reviews.length > 0 && (
          <ul className="rq-history" aria-label="Review history">
            {[...reviews]
              .reverse()
              .slice(0, 5)
              .map((r) => (
                <li key={r.id}>
                  <span>
                    {r.decision === "NOTE" ? "Note" : REVIEW_STATUS_TEXT[r.decision]}
                  </span>
                  <span className="rq-muted"> · {shortDateTime(r.created_at)}</span>
                  {r.note && <q>{r.note}</q>}
                </li>
              ))}
          </ul>
        )}

        <p className="rq-foot">
          <span className="rq-dot" aria-hidden="true" /> Automated risk score
          (rule-based) · decision recorded separately, by a reviewer · history
          is kept, never overwritten
        </p>
      </div>
    </section>
  );
}
