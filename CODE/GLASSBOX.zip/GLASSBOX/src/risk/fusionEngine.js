import { SIGNAL_TYPES } from "../core/signal.js";

import {
  gazeSampleStrength,
  headPoseSampleStrength,
} from "../evidence/deviation.js";

export class FusionEngine {
  constructor({
    onFusion = () => {},
    windowMs = 5000,
  } = {}) {
    this.onFusion = onFusion;
    this.windowMs = windowMs;
    this.recentSignals = [];
  }

  processSignal(signal) {
    if (!signal) return null;

    const timestamp =
      signal.timestamp ?? Date.now();

    this.recentSignals.push({
      ...signal,
      timestamp,
    });

    this.removeOldSignals(timestamp);

    const fusion = this.calculateFusion(timestamp);

    if (fusion) {
      this.emitFusion(fusion);
    }

    return fusion;
  }

  calculateFusion(timestamp) {
    const recent = this.recentSignals;

    const gazeLatest = this.getLatest(
      SIGNAL_TYPES.GAZE_DEVIATION
    );

    const headPoseLatest = this.getLatest(
      SIGNAL_TYPES.HEAD_POSE_DEVIATION
    );

    // Only samples above the deviation gate count as active signals.
    const gaze =
      gazeSampleStrength(gazeLatest) > 0
        ? gazeLatest
        : null;

    const headPose =
      headPoseSampleStrength(headPoseLatest) > 0
        ? headPoseLatest
        : null;

    const focusLoss = this.getLatest(
      SIGNAL_TYPES.FOCUS_LOST
    );

    const faceAbsent = this.getLatest(
      SIGNAL_TYPES.FACE_ABSENT
    );

    const components = {
      gazeDeviation: this.getSignalScore(gaze),
      headPoseDeviation:
        this.getHeadPoseScore(headPose),
      focusLoss:
        focusLoss ? 1 : 0,
      faceAbsence:
        faceAbsent ? 1 : 0,
    };

    const concurrence = [];

    // Vision + vision
    if (gaze && headPose) {
      concurrence.push(
        "GAZE_HEAD_POSE"
      );
    }

    // Browser + vision
    if (focusLoss && gaze) {
      concurrence.push(
        "FOCUS_LOSS_GAZE"
      );
    }

    if (focusLoss && headPose) {
      concurrence.push(
        "FOCUS_LOSS_HEAD_POSE"
      );
    }

    if (faceAbsent && focusLoss) {
      concurrence.push(
        "FACE_ABSENCE_FOCUS_LOSS"
      );
    }

    const activeComponents =
      Object.values(components).filter(
        (value) => value > 0
      ).length;

    if (activeComponents === 0) {
      return null;
    }

    const baseScore =
      components.gazeDeviation * 0.3 +
      components.headPoseDeviation * 0.3 +
      components.focusLoss * 0.2 +
      components.faceAbsence * 0.2;

    const concurrenceBonus =
      Math.min(
        concurrence.length * 0.1,
        0.3
      );

    const score = Math.min(
      baseScore + concurrenceBonus,
      1
    );

    const confidence =
      this.calculateConfidence({
        gaze,
        headPose,
        focusLoss,
        faceAbsent,
      });

    return {
      type: "MULTI_SIGNAL_FUSION",
      timestamp,
      score,
      confidence,
      components,
      concurrentSignals: concurrence,
      signalCount: recent.length,
      reasons:
        this.buildReasons(
          components,
          concurrence
        ),
    };
  }

  getLatest(type) {
    for (
      let index =
        this.recentSignals.length - 1;
      index >= 0;
      index--
    ) {
      if (
        this.recentSignals[index].type ===
        type
      ) {
        return this.recentSignals[index];
      }
    }

    return null;
  }

  getSignalScore(signal) {
    return gazeSampleStrength(signal);
  }

  getHeadPoseScore(signal) {
    return headPoseSampleStrength(signal);
  }

  calculateConfidence({
    gaze,
    headPose,
    focusLoss,
    faceAbsent,
  }) {
    const confidences = [];

    if (gaze) {
      confidences.push(
        gaze.confidence ?? 1
      );
    }

    if (headPose) {
      confidences.push(
        headPose.confidence ?? 1
      );
    }

    if (focusLoss) {
      confidences.push(
        focusLoss.confidence ?? 1
      );
    }

    if (faceAbsent) {
      confidences.push(
        faceAbsent.confidence ?? 1
      );
    }

    if (confidences.length === 0) {
      return 0;
    }

    return (
      confidences.reduce(
        (sum, value) =>
          sum + value,
        0
      ) / confidences.length
    );
  }

  buildReasons(
    components,
    concurrence
  ) {
    const reasons = [];

    if (components.gazeDeviation > 0.5) {
      reasons.push(
        "Notable gaze deviation observed."
      );
    }

    if (
      components.headPoseDeviation >
      0.5
    ) {
      reasons.push(
        "Notable head-pose deviation observed."
      );
    }

    if (components.focusLoss > 0) {
      reasons.push(
        "Browser focus-loss activity observed."
      );
    }

    if (components.faceAbsence > 0) {
      reasons.push(
        "Face absence observed."
      );
    }

    if (concurrence.length > 0) {
      reasons.push(
        "Multiple behavioral signals occurred within the same time window."
      );
    }

    return reasons;
  }

  removeOldSignals(currentTimestamp) {
    const cutoff =
      currentTimestamp - this.windowMs;

    this.recentSignals =
      this.recentSignals.filter(
        (signal) =>
          signal.timestamp >= cutoff
      );
  }

  emitFusion(fusion) {
    this.onFusion(fusion);
  }

  getRecentSignals() {
    return [...this.recentSignals];
  }

  reset() {
    this.recentSignals = [];
  }
}