export class RiskEngine {
  constructor({
    onRisk = () => {},
    decayMs = 120000,
  } = {}) {
    this.onRisk = onRisk;

    /*
     * Evidence older than a few multiples of decayMs
     * no longer contributes (exponential decay), so risk
     * reflects recent behaviour instead of growing with
     * exam length.
     */
    this.decayMs = decayMs;
    this.now = 0;

    /*
     * Equal baseline weights.
     *
     * v1 engine, frozen: kept unchanged so the
     * committed research replays reproduce. LR
     * learning these weights did not improve on
     * them (docs/results_2/EXPERIMENT_REPORT.md,
     * E3). The live score is now
     * src/assessment/ (v2); this engine runs
     * alongside it for comparison only.
     */
    this.weights = {
      focusLoss: 0.20,
      faceAbsence: 0.20,
      gazeDeviation: 0.20,
      headPoseDeviation: 0.20,
      multiSignalFusion: 0.20,
    };

    this.latestFusion = null;

    /*
     * Completed behavioral evidence.
     */
    this.evidenceHistory = [];
  }

  /*
   * ============================
   * RAW SIGNAL
   * ============================
   *
   * Risk is intentionally NOT calculated
   * directly from raw signals.
   *
   * EvidenceEngine interprets raw signals
   * first.
   */
  processSignal(signal) {
    if (!signal) return;

    /*
     * Intentionally left lightweight.
     *
     * Raw signals are handled by:
     * Signal → Evidence
     *
     * This prevents individual frames
     * from directly increasing risk.
     */
  }

  /*
   * ============================
   * FUSION
   * ============================
   */

  processFusion(fusion) {
    if (!fusion) return;

    this.latestFusion = fusion;
    this.now = Math.max(this.now, fusion.timestamp ?? Date.now());

    const risk =
      this.calculateRisk();

    this.emitRisk(risk);
  }

  /*
   * ============================
   * EVIDENCE
   * ============================
   */

  processEvidence(evidence) {
    if (!evidence) return;

    this.evidenceHistory.push(
      evidence
    );
    this.now = Math.max(
      this.now,
      evidence.timestamp ?? Date.now()
    );

    const risk =
      this.calculateRisk();

    this.emitRisk(risk);
  }

  /*
   * ============================
   * RISK CALCULATION
   * ============================
   */

  calculateRisk() {
    const focusScore =
      this.calculateEvidenceScore(
        "FOCUS_LOSS_EPISODE"
      );

    const faceScore =
      this.calculateEvidenceScore(
        "FACE_ABSENCE_EPISODE"
      );

    const gazeScore =
      this.calculateEvidenceScore(
        "GAZE_DEVIATION_EPISODE"
      );

    const headPoseScore =
      this.calculateEvidenceScore(
        "HEAD_POSE_DEVIATION_EPISODE"
      );

    const fusionScore =
      this.calculateFusionScore();

    /*
     * Weighted transparent baseline.
     */
    const score =
      focusScore *
        this.weights.focusLoss +
      faceScore *
        this.weights.faceAbsence +
      gazeScore *
        this.weights.gazeDeviation +
      headPoseScore *
        this.weights.headPoseDeviation +
      fusionScore *
        this.weights.multiSignalFusion;

    const normalizedScore =
      Math.round(
        Math.min(
          Math.max(score, 0),
          1
        ) * 100
      );

    return {
      score: normalizedScore,

      level:
        this.getRiskLevel(
          normalizedScore
        ),

      reasons:
        this.buildReasons({
          focusScore,
          faceScore,
          gazeScore,
          headPoseScore,
          fusionScore,
        }),

      components: {
        focusLoss: focusScore,
        faceAbsence: faceScore,
        gazeDeviation: gazeScore,
        headPoseDeviation:
          headPoseScore,
        multiSignalFusion:
          fusionScore,
      },

      fusion:
        this.latestFusion,

      timestamp: Date.now(),
    };
  }

  /*
   * ============================
   * EVIDENCE SCORE
   * ============================
   *
   * Uses episode strength rather
   * than individual raw frames.
   *
   * Multiple episodes increase the
   * score, but it is capped at 1.
   */
  calculateEvidenceScore(type) {
    const episodes =
      this.evidenceHistory.filter(
        (evidence) =>
          evidence.type === type
      );

    if (episodes.length === 0) {
      return 0;
    }

    /*
     * Sum episode strengths.
     *
     * Three strong episodes are enough
     * to reach the maximum baseline score.
     */
    const totalStrength =
      episodes.reduce(
        (sum, episode) =>
          sum +
          this.getEpisodeStrength(
            episode
          ) *
            this.getDecayWeight(
              episode
            ),
        0
      );

    return Math.min(
      totalStrength / 3,
      1
    );
  }

  /*
   * ============================
   * EPISODE STRENGTH
   * ============================
   */

  getDecayWeight(episode) {
    const timestamp = Number(episode?.timestamp);

    if (!Number.isFinite(timestamp) || this.now <= timestamp) {
      return 1;
    }

    return Math.exp(
      -(this.now - timestamp) / this.decayMs
    );
  }

  getEpisodeStrength(
    episode
  ) {
    const strength =
      Number(
        episode?.strength
      );

    if (
      Number.isFinite(strength)
    ) {
      return Math.min(
        Math.max(strength, 0),
        1
      );
    }

    return 0;
  }

  /*
   * ============================
   * FUSION SCORE
   * ============================
   */

  calculateFusionScore() {
    if (!this.latestFusion) {
      return 0;
    }

    const score =
      Number(
        this.latestFusion.score
      );

    const confidence =
      Number(
        this.latestFusion.confidence
      );

    if (
      !Number.isFinite(score)
    ) {
      return 0;
    }

    const normalizedScore =
      Math.min(
        Math.max(score, 0),
        1
      );

    if (
      !Number.isFinite(
        confidence
      )
    ) {
      return normalizedScore;
    }

    return (
      normalizedScore *
      Math.min(
        Math.max(
          confidence,
          0
        ),
        1
      )
    );
  }

  /*
   * ============================
   * RISK LEVEL
   * ============================
   */

  getRiskLevel(score) {
    if (score < 30) {
      return "LOW";
    }

    if (score < 60) {
      return "MEDIUM";
    }

    return "HIGH";
  }

  /*
   * ============================
   * EXPLANATIONS
   * ============================
   */

  buildReasons({
    focusScore,
    faceScore,
    gazeScore,
    headPoseScore,
    fusionScore,
  }) {
    const reasons = [];

    if (focusScore > 0) {
      reasons.push(
        "Focus-loss activity was observed."
      );
    }

    if (faceScore > 0) {
      reasons.push(
        "Periods without a detected face were observed."
      );
    }

    if (gazeScore >= 0.5) {
      reasons.push(
        "Gaze deviation was sustained at a notable level."
      );
    }

    if (
      headPoseScore >= 0.5
    ) {
      reasons.push(
        "Head-pose deviation was notable."
      );
    }

    if (fusionScore >= 0.5) {
      reasons.push(
        "Multiple behavioral signals showed strong concurrence."
      );
    }

    if (reasons.length === 0) {
      reasons.push(
        "No significant behavioral evidence observed."
      );
    }

    return reasons;
  }

  /*
   * ============================
   * EMIT RISK
   * ============================
   */

  emitRisk(risk) {
    this.onRisk(risk);
  }

  /*
   * ============================
   * RESET
   * ============================
   */

  reset() {
    this.latestFusion = null;
    this.evidenceHistory = [];
    this.now = 0;
  }
}