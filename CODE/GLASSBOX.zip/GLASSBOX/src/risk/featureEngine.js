
export class FeatureEngine {
  constructor({
    windowMs = 60000,
  } = {}) {
    this.windowMs = windowMs;

    // Kept for compatibility with existing pipeline
    this.signals = [];
    this.fusions = [];

    // New: completed evidence episodes
    this.evidence = [];
  }

  processSignal(signal) {
    if (!signal) return null;

    const timestamp =
      signal.timestamp ?? Date.now();

    this.signals.push({
      ...signal,
      timestamp,
    });

    this.removeOldSignals(timestamp);

    return this.calculateFeatures(timestamp);
  }

  processFusion(fusion) {
    if (!fusion) return null;

    const timestamp =
      fusion.timestamp ?? Date.now();

    this.fusions.push({
      ...fusion,
      timestamp,
    });

    this.removeOldFusions(timestamp);

    return this.calculateFeatures(timestamp);
  }

  // New: receive completed EvidenceEngine episodes
  processEvidence(evidence) {
    if (!evidence) return null;

    const timestamp =
      evidence.timestamp ??
      evidence.generatedAt ??
      Date.now();

    this.evidence.push({
      ...evidence,
      timestamp,
    });

    this.removeOldEvidence(timestamp);

    return this.calculateFeatures(timestamp);
  }

  calculateFeatures(timestamp = Date.now()) {
    const recentEvidence =
      this.evidence.filter(
        (item) =>
          timestamp - item.timestamp <=
          this.windowMs
      );

    const recentFusions =
      this.fusions.filter(
        (fusion) =>
          timestamp - fusion.timestamp <=
          this.windowMs
      );

    const gazeEpisodes =
      recentEvidence.filter(
        (item) =>
          item.type ===
          "GAZE_DEVIATION_EPISODE"
      );

    const headPoseEpisodes =
      recentEvidence.filter(
        (item) =>
          item.type ===
          "HEAD_POSE_DEVIATION_EPISODE"
      );

    const focusLossEpisodes =
      recentEvidence.filter(
        (item) =>
          item.type ===
          "FOCUS_LOSS_EPISODE"
      );

    const faceAbsenceEpisodes =
      recentEvidence.filter(
        (item) =>
          item.type ===
          "FACE_ABSENCE_EPISODE"
      );

    const latestFusion =
      recentFusions.length > 0
        ? recentFusions[
            recentFusions.length - 1
          ]
        : null;

    const gazeDuration =
      this.getTotalDuration(
        gazeEpisodes
      );

    const headPoseDuration =
      this.getTotalDuration(
        headPoseEpisodes
      );

    const focusLossDuration =
      this.getTotalDuration(
        focusLossEpisodes
      );

    const faceAbsenceDuration =
      this.getTotalDuration(
        faceAbsenceEpisodes
      );

    const gazeStrength =
      this.getAverageStrength(
        gazeEpisodes
      );

    const headPoseStrength =
      this.getAverageStrength(
        headPoseEpisodes
      );

    const focusLossStrength =
      this.getAverageStrength(
        focusLossEpisodes
      );

    const faceAbsenceStrength =
      this.getAverageStrength(
        faceAbsenceEpisodes
      );

    return {
      timestamp,

      // Episode frequency
      gazeFrequency:
        gazeEpisodes.length,

      headPoseFrequency:
        headPoseEpisodes.length,

      focusLossFrequency:
        focusLossEpisodes.length,

      faceAbsenceFrequency:
        faceAbsenceEpisodes.length,

      // Duration features
      gazeDurationMs:
        gazeDuration,

      headPoseDurationMs:
        headPoseDuration,

      focusLossDurationMs:
        focusLossDuration,

      faceAbsenceDurationMs:
        faceAbsenceDuration,

      // Evidence strength
      gazeStrength,

      headPoseStrength,

      focusLossStrength,

      faceAbsenceStrength,

      // Backward-compatible magnitude fields
      gazeMagnitude:
        gazeStrength,

      headPoseMagnitude:
        headPoseStrength,

      // Fusion features
      fusionScore:
        latestFusion?.score ?? 0,

      fusionConfidence:
        latestFusion?.confidence ?? 0,

      concurrenceCount:
        latestFusion
          ?.concurrentSignals
          ?.length ?? 0,

      // Combined behavioral feature
      behavioralActivity:
        this.calculateBehavioralActivity({
          gazeStrength,
          headPoseStrength,
          focusLossStrength,
          faceAbsenceStrength,
          gazeDuration,
          headPoseDuration,
          focusLossDuration,
          faceAbsenceDuration,
          fusionScore:
            latestFusion?.score ?? 0,
        }),
    };
  }

  getTotalDuration(episodes) {
    return episodes.reduce(
      (total, episode) =>
        total +
        Math.max(
          Number(
            episode.durationMs
          ) || 0,
          0
        ),
      0
    );
  }

  getAverageStrength(episodes) {
    if (episodes.length === 0) {
      return 0;
    }

    const values =
      episodes
        .map((episode) =>
          Number(episode.strength)
        )
        .filter((value) =>
          Number.isFinite(value)
        );

    if (values.length === 0) {
      return 0;
    }

    return (
      values.reduce(
        (sum, value) =>
          sum + value,
        0
      ) / values.length
    );
  }

  calculateBehavioralActivity({
    gazeStrength,
    headPoseStrength,
    focusLossStrength,
    faceAbsenceStrength,
    gazeDuration,
    headPoseDuration,
    focusLossDuration,
    faceAbsenceDuration,
    fusionScore,
  }) {
    const strengthScore =
      (
        gazeStrength +
        headPoseStrength +
        focusLossStrength +
        faceAbsenceStrength
      ) / 4;

    const totalDuration =
      gazeDuration +
      headPoseDuration +
      focusLossDuration +
      faceAbsenceDuration;

    const durationScore =
      Math.min(
        totalDuration / 60000,
        1
      );

    return (
      strengthScore * 0.4 +
      durationScore * 0.2 +
      fusionScore * 0.4
    );
  }

  removeOldSignals(
    currentTimestamp
  ) {
    const cutoff =
      currentTimestamp -
      this.windowMs;

    this.signals =
      this.signals.filter(
        (signal) =>
          signal.timestamp >= cutoff
      );
  }

  removeOldFusions(
    currentTimestamp
  ) {
    const cutoff =
      currentTimestamp -
      this.windowMs;

    this.fusions =
      this.fusions.filter(
        (fusion) =>
          fusion.timestamp >= cutoff
      );
  }

  removeOldEvidence(
    currentTimestamp
  ) {
    const cutoff =
      currentTimestamp -
      this.windowMs;

    this.evidence =
      this.evidence.filter(
        (item) =>
          item.timestamp >= cutoff
      );
  }

  getCurrentFeatures() {
    return this.calculateFeatures();
  }

  reset() {
    this.signals = [];
    this.fusions = [];
    this.evidence = [];
  }
}