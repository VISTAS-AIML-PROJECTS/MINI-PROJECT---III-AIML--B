import {
  SIGNAL_TYPES,
} from "../core/signal.js";

import {
  gazeSampleStrength,
  headPoseSampleStrength,
} from "./deviation.js";

export class EvidenceEngine {
  constructor({
    onEvidence = () => {},
    windowMs = 10000,
    decayMs = 30000,
    episodeGapMs = 1500,
    minEpisodeMs = 500,
    minEpisodeSamples = 3,
  } = {}) {
    this.onEvidence = onEvidence;

    this.windowMs = windowMs;
    this.decayMs = decayMs;
    this.episodeGapMs = episodeGapMs;
    this.minEpisodeMs = minEpisodeMs;
    this.minEpisodeSamples = minEpisodeSamples;

    this.signals = [];
    this.evidenceHistory = [];

    this.focusLossStart = null;
    this.faceAbsentStart = null;

    /*
     * Active behavioral episodes.
     */
    this.gazeEpisode = null;
    this.headPoseEpisode = null;

    this.lastGazeDeviation = null;
    this.lastHeadPoseDeviation = null;

    this.lastGazeTime = null;
    this.lastHeadPoseTime = null;
  }

  processSignal(signal) {
    if (!signal) return;

    const timestamp =
      signal.timestamp ?? Date.now();

    /*
     * Before processing the new signal,
     * close old behavioral episodes if
     * there has been a long enough gap.
     */
    this.closeExpiredEpisodes(timestamp);

    this.signals.push({
      ...signal,
      timestamp,
    });

    this.removeOldSignals(timestamp);

    switch (signal.type) {
      case SIGNAL_TYPES.FOCUS_LOST:
        this.handleFocusLost(signal);
        break;

      case SIGNAL_TYPES.FOCUS_GAINED:
        this.handleFocusGained(signal);
        break;

      case SIGNAL_TYPES.FACE_ABSENT:
        this.handleFaceAbsent(signal);
        break;

      case SIGNAL_TYPES.FACE_PRESENT:
        this.handleFacePresent(signal);
        break;

      case SIGNAL_TYPES.GAZE_DEVIATION:
        this.handleGazeDeviation(signal);
        break;

      case SIGNAL_TYPES.HEAD_POSE_DEVIATION:
        this.handleHeadPoseDeviation(signal);
        break;

      default:
        break;
    }
  }

  /*
   * ============================
   * BROWSER EPISODES
   * ============================
   */

  handleFocusLost(signal) {
    if (
      this.focusLossStart === null
    ) {
      this.focusLossStart =
        signal.timestamp;
    }
  }

  handleFocusGained(signal) {
    if (
      this.focusLossStart === null
    ) {
      return;
    }

    const durationMs =
      Math.max(
        signal.timestamp -
          this.focusLossStart,
        0
      );

    this.emitEvidence({
      type: "FOCUS_LOSS_EPISODE",
      timestamp: signal.timestamp,
      durationMs,
      persistenceMs: durationMs,
      frequency:
        this.getRecentSignalCount(
          SIGNAL_TYPES.FOCUS_LOST
        ),
      strength:
        this.calculateEpisodeStrength(
          durationMs
        ),
      decayWeight: 1,
    });

    this.focusLossStart = null;
  }

  /*
   * ============================
   * FACE ABSENCE
   * ============================
   */

  handleFaceAbsent(signal) {
    if (
      this.faceAbsentStart === null
    ) {
      this.faceAbsentStart =
        signal.timestamp;
    }
  }

  handleFacePresent(signal) {
    if (
      this.faceAbsentStart === null
    ) {
      return;
    }

    const durationMs =
      Math.max(
        signal.timestamp -
          this.faceAbsentStart,
        0
      );

    this.emitEvidence({
      type: "FACE_ABSENCE_EPISODE",
      timestamp: signal.timestamp,
      durationMs,
      persistenceMs: durationMs,
      frequency:
        this.getRecentSignalCount(
          SIGNAL_TYPES.FACE_ABSENT
        ),
      strength:
        this.calculateEpisodeStrength(
          durationMs
        ),
      decayWeight: 1,
    });

    this.faceAbsentStart = null;
  }

  /*
   * ============================
   * GAZE EPISODE
   * ============================
   */

  handleGazeDeviation(signal) {
    if (gazeSampleStrength(signal) === 0) {
      return;
    }

    this.lastGazeDeviation = signal;
    this.lastGazeTime =
      signal.timestamp;

    if (!this.gazeEpisode) {
      this.gazeEpisode = {
        start: signal.timestamp,
        last: signal.timestamp,
        samples: [],
      };
    }

    this.gazeEpisode.last =
      signal.timestamp;

    this.gazeEpisode.samples.push(
      signal
    );
  }

  /*
   * ============================
   * HEAD-POSE EPISODE
   * ============================
   */

  handleHeadPoseDeviation(signal) {
    if (headPoseSampleStrength(signal) === 0) {
      return;
    }

    this.lastHeadPoseDeviation =
      signal;

    this.lastHeadPoseTime =
      signal.timestamp;

    if (!this.headPoseEpisode) {
      this.headPoseEpisode = {
        start: signal.timestamp,
        last: signal.timestamp,
        samples: [],
      };
    }

    this.headPoseEpisode.last =
      signal.timestamp;

    this.headPoseEpisode.samples.push(
      signal
    );
  }

  /*
   * ============================
   * EPISODE MANAGEMENT
   * ============================
   */

  closeExpiredEpisodes(timestamp) {
    if (
      this.gazeEpisode &&
      timestamp -
        this.gazeEpisode.last >
        this.episodeGapMs
    ) {
      this.emitGazeEpisode();
    }

    if (
      this.headPoseEpisode &&
      timestamp -
        this.headPoseEpisode.last >
        this.episodeGapMs
    ) {
      this.emitHeadPoseEpisode();
    }
  }

  /*
   * Duration / sample-count / strength of a gated deviation
   * episode, or null while it is still below the minimum
   * episode size. Shared by the emitters and by
   * getOpenEpisodes(), so a provisional (ongoing) episode
   * is scored exactly like the one emitted when it closes.
   */
  summarizeDeviationEpisode(episode, averageStrengthOf) {
    if (
      !episode ||
      episode.samples.length < this.minEpisodeSamples ||
      episode.last - episode.start < this.minEpisodeMs
    ) {
      return null;
    }

    const durationMs =
      Math.max(
        episode.last -
          episode.start,
        0
      );

    const frequency =
      episode.samples.length;

    const averageStrength =
      averageStrengthOf(
        episode.samples
      );

    const persistenceScore =
      Math.min(
        durationMs / 5000,
        1
      );

    const frequencyScore =
      Math.min(
        frequency / 10,
        1
      );

    const strength =
      averageStrength * 0.5 +
      persistenceScore * 0.25 +
      frequencyScore * 0.25;

    return { durationMs, frequency, strength };
  }

  emitGazeEpisode() {
    const summary =
      this.summarizeDeviationEpisode(
        this.gazeEpisode,
        (samples) =>
          this.calculateAverageGazeStrength(samples)
      );

    if (summary) {
      this.emitEvidence({
        type: "GAZE_DEVIATION_EPISODE",
        timestamp: this.gazeEpisode.last,
        durationMs: summary.durationMs,
        persistenceMs: summary.durationMs,
        frequency: summary.frequency,
        strength: summary.strength,
        decayWeight: 1,
      });
    }

    this.gazeEpisode = null;
  }

  emitHeadPoseEpisode() {
    const summary =
      this.summarizeDeviationEpisode(
        this.headPoseEpisode,
        (samples) =>
          this.calculateAverageHeadPoseStrength(samples)
      );

    if (summary) {
      this.emitEvidence({
        type:
          "HEAD_POSE_DEVIATION_EPISODE",
        timestamp: this.headPoseEpisode.last,
        durationMs: summary.durationMs,
        persistenceMs: summary.durationMs,
        frequency: summary.frequency,
        strength: summary.strength,
        decayWeight: 1,
      });
    }

    this.headPoseEpisode = null;
  }

  /*
   * ============================
   * ONGOING EPISODES
   * ============================
   *
   * Focus-loss and face-absence episodes are only emitted
   * when they END (focus regained / face back). Without this
   * view a student who has been out of frame for two minutes
   * contributes nothing until they return. These provisional
   * episodes are NOT emitted or persisted; the assessment
   * layer scores them as if they closed at `now`.
   */
  getOpenEpisodes(now) {
    const open = [];

    const pushInterval = (type, start) => {
      if (start === null || !Number.isFinite(now)) {
        return;
      }

      const durationMs = Math.max(now - start, 0);

      open.push({
        type,
        timestamp: now,
        startedAt: start,
        durationMs,
        persistenceMs: durationMs,
        strength:
          this.calculateEpisodeStrength(durationMs),
        ongoing: true,
      });
    };

    pushInterval("FOCUS_LOSS_EPISODE", this.focusLossStart);
    pushInterval("FACE_ABSENCE_EPISODE", this.faceAbsentStart);

    const pushDeviation = (type, episode, averageStrengthOf) => {
      if (!episode || now - episode.last > this.episodeGapMs) {
        return;
      }

      const summary =
        this.summarizeDeviationEpisode(episode, averageStrengthOf);

      if (summary) {
        open.push({
          type,
          timestamp: episode.last,
          startedAt: episode.start,
          ...summary,
          persistenceMs: summary.durationMs,
          ongoing: true,
        });
      }
    };

    pushDeviation(
      "GAZE_DEVIATION_EPISODE",
      this.gazeEpisode,
      (samples) => this.calculateAverageGazeStrength(samples)
    );

    pushDeviation(
      "HEAD_POSE_DEVIATION_EPISODE",
      this.headPoseEpisode,
      (samples) => this.calculateAverageHeadPoseStrength(samples)
    );

    return open;
  }

  /*
   * Close gaze/head episodes whose gap has expired even when no
   * further signal arrives (e.g. the camera stopped). The app
   * calls this on its 1-Hz assessment tick; offline replays that
   * never call it behave exactly as before.
   */
  advanceTo(timestamp) {
    if (Number.isFinite(timestamp)) {
      this.closeExpiredEpisodes(timestamp);
    }
  }

  /*
   * End of session: emit EVERY open episode, including focus loss
   * and face absence still in progress (reset() only emits the
   * gaze/head ones), then clear all state. Episodes cut short by
   * the session end are flagged so a reviewer can tell them apart.
   */
  finalize(timestamp) {
    const now = Number.isFinite(timestamp)
      ? timestamp
      : Date.now();

    this.emitGazeEpisode();
    this.emitHeadPoseEpisode();

    for (const [type, start] of [
      ["FOCUS_LOSS_EPISODE", this.focusLossStart],
      ["FACE_ABSENCE_EPISODE", this.faceAbsentStart],
    ]) {
      if (start === null) {
        continue;
      }

      const durationMs = Math.max(now - start, 0);

      this.emitEvidence({
        type,
        timestamp: now,
        durationMs,
        persistenceMs: durationMs,
        frequency: 0,
        strength:
          this.calculateEpisodeStrength(durationMs),
        decayWeight: 1,
        metadata: { endedBy: "SESSION_END" },
      });
    }

    this.reset();
  }

  /*
   * ============================
   * STRENGTH CALCULATION
   * ============================
   */

  calculateAverageGazeStrength(
    samples
  ) {
    if (samples.length === 0) {
      return 0;
    }

    return (
      samples.reduce(
        (sum, signal) =>
          sum + gazeSampleStrength(signal),
        0
      ) / samples.length
    );
  }

  calculateAverageHeadPoseStrength(
    samples
  ) {
    if (samples.length === 0) {
      return 0;
    }

    return (
      samples.reduce(
        (sum, signal) =>
          sum + headPoseSampleStrength(signal),
        0
      ) / samples.length
    );
  }

  calculateEpisodeStrength(
    durationMs
  ) {
    return Math.min(
      durationMs / 5000,
      1
    );
  }

  /*
   * ============================
   * TEMPORAL WINDOW
   * ============================
   */

  removeOldSignals(
    currentTimestamp
  ) {
    const cutoff =
      currentTimestamp -
      this.windowMs;

    this.signals =
      this.signals.filter(
        (signal) =>
          signal.timestamp >= cutoff
      );
  }

  calculateDecay(timestamp) {
    const age =
      Date.now() - timestamp;

    if (age <= 0) {
      return 1;
    }

    return Math.exp(
      -age / this.decayMs
    );
  }

  countRecentSignals(type) {
    return this.signals.filter(
      (signal) =>
        signal.type === type
    ).length;
  }

  getRecentSignalCount(type) {
    return this.countRecentSignals(type);
  }

  /*
   * ============================
   * CURRENT CONTEXT
   * ============================
   */

  getCurrentContext() {
    return {
      recentSignalCount:
        this.signals.length,

      focusLossCount:
        this.getRecentSignalCount(
          SIGNAL_TYPES.FOCUS_LOST
        ),

      faceAbsentCount:
        this.getRecentSignalCount(
          SIGNAL_TYPES.FACE_ABSENT
        ),

      gazeDeviation:
        this.lastGazeDeviation,

      headPoseDeviation:
        this.lastHeadPoseDeviation,

      gazeDecay:
        this.lastGazeTime !== null
          ? this.calculateDecay(
              this.lastGazeTime
            )
          : 0,

      headPoseDecay:
        this.lastHeadPoseTime !== null
          ? this.calculateDecay(
              this.lastHeadPoseTime
            )
          : 0,

      gazeEpisodeActive:
        this.gazeEpisode !== null,

      headPoseEpisodeActive:
        this.headPoseEpisode !== null,
    };
  }

  /*
   * ============================
   * EVIDENCE OUTPUT
   * ============================
   */

  emitEvidence(evidence) {
    const generatedAt =
      Date.now();

    const completeEvidence = {
      ...evidence,
      source: "evidence",
      generatedAt,
    };

    this.evidenceHistory.push(
      completeEvidence
    );

    this.onEvidence(
      completeEvidence
    );
  }

  getRecentEvidence() {
    return [
      ...this.evidenceHistory,
    ];
  }

  /*
   * ============================
   * RESET
   * ============================
   */

  reset() {
    /*
     * Finalize active episodes before
     * clearing them.
     */
    this.emitGazeEpisode();
    this.emitHeadPoseEpisode();

    this.signals = [];
    this.evidenceHistory = [];

    this.focusLossStart = null;
    this.faceAbsentStart = null;

    this.gazeEpisode = null;
    this.headPoseEpisode = null;

    this.lastGazeDeviation = null;
    this.lastHeadPoseDeviation = null;

    this.lastGazeTime = null;
    this.lastHeadPoseTime = null;
  }
}