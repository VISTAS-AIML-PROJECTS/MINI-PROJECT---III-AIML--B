/*
 * Shared deviation gating for the evidence and fusion engines.
 *
 * The vision module emits a GAZE_DEVIATION / HEAD_POSE_DEVIATION sample on
 * every frame. Without a gate, every frame of a present user counts as part
 * of a "deviation episode" (see research/tests/evidence_calm_user.mjs), so
 * persistence/frequency saturate and a few seconds of looking away are
 * averaged into minutes of normal behaviour. A sample only counts as
 * deviating when it exceeds the user's own calibrated variability.
 */
export const DEVIATION_CONFIG = Object.freeze({
  // gaze value is sqrt(zx^2 + zy^2) in calibration standard deviations.
  // 3.0 is the 99th percentile of chi(2), i.e. ~1% exceedance for a
  // Gaussian calibration distribution.
  gazeZThreshold: 3,
  gazeZSaturation: 9,

  // head-pose value is |current - baseline| in degrees per axis.
  headSdThreshold: 3,
  headMinDegrees: 8,
  headSaturationDegrees: Object.freeze({ yaw: 45, pitch: 30, roll: 30 }),
});

const clamp01 = (v) => Math.min(Math.max(v, 0), 1);

export function gazeSampleStrength(
  signal,
  config = DEVIATION_CONFIG
) {
  const z = Number(signal?.value);

  if (!Number.isFinite(z) || z < config.gazeZThreshold) {
    return 0;
  }

  return clamp01(z / config.gazeZSaturation);
}

export function headPoseSampleStrength(
  signal,
  config = DEVIATION_CONFIG
) {
  const value = signal?.value;

  if (!value) {
    return 0;
  }

  const std = signal?.metadata?.baselineStd ?? {};
  let strength = 0;

  for (const axis of ["yaw", "pitch", "roll"]) {
    const deviation = Math.abs(Number(value[axis]));

    if (!Number.isFinite(deviation)) {
      continue;
    }

    const threshold = Math.max(
      config.headMinDegrees,
      config.headSdThreshold * (Number(std[axis]) || 0)
    );

    if (deviation >= threshold) {
      strength = Math.max(
        strength,
        clamp01(deviation / config.headSaturationDegrees[axis])
      );
    }
  }

  return strength;
}
