import Panel, { EmptyState } from "./Panel.jsx";
import {
  clamp01,
  eventLabel,
  formatClock,
  formatDuration,
  formatNumber,
} from "./format.js";
import {
  CHANNEL_LABELS,
  GROUP_LABELS,
} from "../assessment/assessmentConfig.js";

const LEVEL_TONE = {
  LOW: "ok",
  MEDIUM: "warn",
  HIGH: "bad",
  UNDETERMINED: "idle",
};

const STATE_TEXT = {
  DEGRADED: "Limited observation",
  INSUFFICIENT_EVIDENCE: "Insufficient evidence",
};

const pct = (v) =>
  Number.isFinite(v) ? `${Math.round(v * 100)}%` : "—";

function Section({ title, children }) {
  return (
    <section className="why__section">
      <h3>{title}</h3>
      {children}
    </section>
  );
}

export default function ExplanationPanel({
  sessionActive,
  latestEvent,
  eventCount,
  risk,
}) {
  const tone = risk ? (LEVEL_TONE[risk.level] ?? "idle") : "idle";

  /*
   * Every row below is read from the assessment object
   * (src/assessment/assessmentEngine.js); nothing is
   * recomputed or invented for display.
   */
  const contributions = risk?.contributions
    ? Object.entries(risk.contributions)
        .map(([group, c]) => ({
          group,
          points: c.points,
          weight: c.weight,
          driver: risk.groups?.[group]?.driver,
          ongoing:
            risk.channels?.[risk.groups?.[group]?.driver]?.ongoing,
        }))
        .sort((a, b) => b.points - a.points)
    : [];

  const coverage = risk?.coverage;

  return (
    <Panel
      className="panel--why"
      eyebrow="Why this assessment?"
      title={latestEvent ? eventLabel(latestEvent.type) : "GlassBox explanation"}
      aside={
        risk && (
          <div className="risk" data-tone={tone}>
            <span className="risk__score mono">
              {risk.level === "UNDETERMINED" ? "—" : risk.score}
            </span>
            <span className="risk__of">/100</span>
            <span className="risk__level">
              {risk.level === "UNDETERMINED" ? "Undetermined" : risk.level}
            </span>
          </div>
        )
      }
    >
      {!latestEvent && !risk ? (
        <EmptyState title="No assessment yet">
          {sessionActive
            ? "Recording. The assessment updates every second once the session starts."
            : "Start a session to record behaviour. The assessment and its reasons appear here."}
        </EmptyState>
      ) : (
        <div className="why">
          {risk && risk.state !== "OK" && risk.state && (
            <div
              className={`notice ${
                risk.state === "INSUFFICIENT_EVIDENCE"
                  ? "notice--bad"
                  : "notice--warn"
              }`}
              role="status"
            >
              <strong>{STATE_TEXT[risk.state]}.</strong>{" "}
              {risk.state === "INSUFFICIENT_EVIDENCE"
                ? "Too little of the recent period could be observed to call this session low risk."
                : "Part of the recent period could not be observed, so the score may understate behaviour."}
            </div>
          )}

          <Section title="Latest event">
            {latestEvent ? (
              <p>
                {eventLabel(latestEvent.type)} ·{" "}
                {formatDuration(latestEvent.durationMs)} · ended{" "}
                <span className="mono">
                  {formatClock(latestEvent.timestamp)}
                </span>
                .{eventCount > 1 && ` ${eventCount} events this session.`}
              </p>
            ) : (
              <p className="muted">
                No completed behaviour episode yet.
              </p>
            )}
          </Section>

          <Section title="What contributes to the score">
            {contributions.some((c) => c.points >= 0.5) ? (
              <ul className="bars">
                {contributions.map((c) => (
                  <li key={c.group}>
                    <span>
                      {GROUP_LABELS[c.group]}
                      {c.driver && (
                        <span className="muted">
                          {" "}
                          · {CHANNEL_LABELS[c.driver]}
                          {c.ongoing ? " (ongoing)" : ""}
                        </span>
                      )}
                    </span>
                    <span className="meter">
                      <span
                        style={{
                          width: `${clamp01(c.points / 50) * 100}%`,
                        }}
                      />
                    </span>
                    <span className="mono">
                      +{Math.round(c.points)}
                    </span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="muted">
                No behaviour group is contributing right now.
              </p>
            )}
          </Section>

          <Section title="Observation quality (last 60 s)">
            {coverage ? (
              <dl className="kv kv--tight">
                <div>
                  <dt>Reliability</dt>
                  <dd className="mono">{pct(risk.reliability)}</dd>
                </div>
                <div>
                  <dt>Camera frames</dt>
                  <dd className="mono">{pct(coverage.vision)}</dd>
                </div>
                <div>
                  <dt>Gaze / head measurable</dt>
                  <dd className="mono">{pct(coverage.measurable)}</dd>
                </div>
                <div>
                  <dt>Observed so far</dt>
                  <dd className="mono">
                    {formatNumber(coverage.seconds, 0)} s
                  </dd>
                </div>
              </dl>
            ) : (
              <p className="muted">—</p>
            )}
          </Section>

          <Section title="Interpretation">
            {risk ? (
              <ul className="plain">
                {risk.reasons.map((reason) => (
                  <li key={reason}>{reason}</li>
                ))}
              </ul>
            ) : (
              <p className="muted">Awaiting a risk assessment.</p>
            )}
          </Section>
        </div>
      )}

      <p className="footnote">
        Behavioural risk index: the strongest independent kind of
        behaviour counts most, and a second kind is needed to reach
        HIGH. Transparent and rule-based — not a trained model, and
        not a probability of cheating. A human reviewer decides.
      </p>
    </Panel>
  );
}
