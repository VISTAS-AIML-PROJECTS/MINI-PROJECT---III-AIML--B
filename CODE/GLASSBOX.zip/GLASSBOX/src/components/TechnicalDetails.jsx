/* Raw engine output, kept available for debugging and review. */
export default function TechnicalDetails({ evidence, fusion, features, risk }) {
  const blocks = [
    ["Evidence (last 10)", evidence.slice(-10), evidence.length > 0],
    ["Fusion", fusion, !!fusion],
    ["Features", features, !!features],
    ["Risk components", risk?.components, !!risk],
  ];

  return (
    <details className="tech">
      <summary>Technical details · raw engine output</summary>
      <div className="tech__grid">
        {blocks.map(([title, data, available]) => (
          <div key={title}>
            <h3>{title}</h3>
            {available ? (
              <pre>{JSON.stringify(data, null, 2)}</pre>
            ) : (
              <p className="muted">Not generated yet.</p>
            )}
          </div>
        ))}
      </div>
    </details>
  );
}
