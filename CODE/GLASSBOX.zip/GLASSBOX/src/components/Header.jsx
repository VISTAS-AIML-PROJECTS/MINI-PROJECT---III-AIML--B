/*
 * Page header: brand + one overall system state.
 * `state` is derived in App from real backend / tracker / session state.
 */
export default function Header({ state, detail, items }) {
  return (
    <header className="header">
      <div className="header__brand">
        <svg
          className="header__mark"
          viewBox="0 0 24 24"
          width="26"
          height="26"
          aria-hidden="true"
        >
          <rect
            x="3.5"
            y="3.5"
            width="17"
            height="17"
            rx="2.5"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.6"
          />
          <circle
            cx="12"
            cy="12"
            r="3.2"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.6"
          />
        </svg>

        <div>
          <h1>GlassBox</h1>
          <p>Explainable behaviour monitoring</p>
        </div>
      </div>

      <div className="header__status">
        <ul className="header__items">
          {items.map((item) => (
            <li key={item.label}>
              <span>{item.label}</span>
              <strong data-tone={item.tone}>{item.value}</strong>
            </li>
          ))}
        </ul>

        <div className="pill" data-tone={state.tone} role="status">
          <span className={`dot${state.pulse ? " dot--live" : ""}`} />
          {state.label}
        </div>
      </div>

      {detail && (
        <p
          className="header__detail"
          data-tone={detail.tone}
          role={detail.tone === "bad" ? "alert" : undefined}
        >
          {detail.text}
        </p>
      )}
    </header>
  );
}
