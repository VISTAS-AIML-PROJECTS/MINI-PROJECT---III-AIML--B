import { useEffect, useState } from "react";
import Panel from "./Panel.jsx";
import { formatElapsed } from "./format.js";

/*
 * Remounted per session (key = sessionId), so the start time is
 * simply the moment the component mounts.
 */
function Elapsed({ active }) {
  const [start] = useState(() => Date.now());
  const [now, setNow] = useState(start);

  useEffect(() => {
    if (!active) return undefined;
    const id = setInterval(() => setNow(Date.now()), 500);
    return () => clearInterval(id);
  }, [active]);

  return <>{formatElapsed(now - start)}</>;
}

/* Engine status strings are mixed-case; show them in sentence case. */
function sentenceCase(text) {
  return text === text.toUpperCase()
    ? text.charAt(0) + text.slice(1).toLowerCase()
    : text;
}

export default function SessionPanel({
  conditions,
  selectedCondition,
  onConditionChange,
  currentCondition,
  sessionActive,
  sessionId,
  sessionNumber,
  sessionStatus,
  backendReady,
  baselineReady,
  signalCount,
  eventCount,
  onStart,
  onEnd,
  onNew,
}) {
  const statusIsProblem = /fail|warning|not ready/i.test(sessionStatus);

  return (
    <Panel
      title="Session"
      aside={
        <span className="muted">
          {sessionNumber ? `#${sessionNumber}` : "No session yet"}
        </span>
      }
    >
      <div className="actions">
        {!sessionActive && (
          <button
            className="btn btn--primary"
            onClick={onStart}
            disabled={!backendReady}
            title={
              backendReady
                ? undefined
                : "Backend must be connected to record a session"
            }
          >
            Start session
          </button>
        )}
        {sessionActive && (
          <button className="btn btn--danger" onClick={onEnd}>
            End session
          </button>
        )}
        {!sessionActive && sessionId && (
          <button className="btn" onClick={onNew}>
            New session
          </button>
        )}
      </div>

      {statusIsProblem && (
        <div className="notice notice--bad" role="alert">
          {sessionStatus}
        </div>
      )}

      {!baselineReady && (
        <div className="notice notice--info">
          No personal baseline yet. Gaze and head-pose signals are not
          produced until calibration completes.
        </div>
      )}

      <details className="tech tech--inline">
        <summary>Data-collection label (optional)</summary>
        <div className="field field--inline">
          <label htmlFor="condition-select">
            Tag this session for research data collection
          </label>
          <select
            id="condition-select"
            value={selectedCondition}
            disabled={sessionActive}
            onChange={(e) => onConditionChange(e.target.value)}
          >
            {conditions.map((c) => (
              <option key={c.value} value={c.value}>
                {c.label}
              </option>
            ))}
          </select>
          {currentCondition && (
            <p className="field__hint">{currentCondition.description}</p>
          )}
        </div>
      </details>

      <dl className="kv">
        <div>
          <dt>Status</dt>
          <dd>{statusIsProblem ? "Error" : sentenceCase(sessionStatus)}</dd>
        </div>
        <div>
          <dt>Elapsed</dt>
          <dd className="mono">
            {sessionId ? (
              <Elapsed key={sessionId} active={sessionActive} />
            ) : (
              "—"
            )}
          </dd>
        </div>
        <div>
          <dt>Signals</dt>
          <dd className="mono">{signalCount}</dd>
        </div>
        <div>
          <dt>Events</dt>
          <dd className="mono">{eventCount}</dd>
        </div>
        <div className="kv__wide">
          <dt>Session ID</dt>
          <dd className="mono">{sessionId ?? "—"}</dd>
        </div>
      </dl>
    </Panel>
  );
}
