export default function Panel({
  title,
  eyebrow,
  aside,
  className = "",
  children,
}) {
  return (
    <section className={`panel ${className}`}>
      <header className="panel__head">
        <div>
          {eyebrow && <p className="eyebrow">{eyebrow}</p>}
          <h2>{title}</h2>
        </div>
        {aside && <div className="panel__aside">{aside}</div>}
      </header>
      {children}
    </section>
  );
}

export function EmptyState({ title, children }) {
  return (
    <div className="empty">
      <strong>{title}</strong>
      {children && <p>{children}</p>}
    </div>
  );
}
