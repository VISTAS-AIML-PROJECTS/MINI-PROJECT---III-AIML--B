import Panel, { EmptyState } from "./Panel.jsx";
import {
  clamp01,
  eventLabel,
  formatClock,
  formatDuration,
  formatNumber,
} from "./format.js";

export default function EventHistory({ evidence, sessionActive }) {
  const rows = [...evidence].reverse();

  return (
    <Panel
      title="Event history"
      aside={
        <span className="muted">
          {evidence.length} {evidence.length === 1 ? "event" : "events"}
        </span>
      }
    >
      {rows.length === 0 ? (
        <EmptyState title="No events yet">
          {sessionActive
            ? "Nothing has been flagged in this session."
            : "Events from the current session will be listed here."}
        </EmptyState>
      ) : (
        <div className="table-wrap table-wrap--scroll">
          <table className="table">
            <thead>
              <tr>
                <th>Time</th>
                <th>Event</th>
                <th>Duration</th>
                <th>Samples</th>
                <th>Strength</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((event, index) => (
                <tr key={`${event.generatedAt}-${index}`}>
                  <td className="mono">{formatClock(event.timestamp)}</td>
                  <td>{eventLabel(event.type)}</td>
                  <td className="mono">{formatDuration(event.durationMs)}</td>
                  <td className="mono">{event.frequency}</td>
                  <td>
                    <span className="strength">
                      <span className="meter">
                        <span
                          style={{
                            width: `${clamp01(event.strength) * 100}%`,
                          }}
                        />
                      </span>
                      <span className="mono">
                        {formatNumber(event.strength)}
                      </span>
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Panel>
  );
}
