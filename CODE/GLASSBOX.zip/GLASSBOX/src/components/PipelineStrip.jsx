/*
 * Visual summary of the existing processing flow.
 * Each stage only reports state/counts the app already produces.
 */
export default function PipelineStrip({ stages }) {
  return (
    <ol className="pipeline" aria-label="Processing pipeline">
      {stages.map((stage, index) => (
        <li
          key={stage.name}
          className="pipeline__stage"
          data-tone={stage.tone}
        >
          <span className="pipeline__name">
            <span className="dot" />
            {stage.name}
          </span>
          <span className="pipeline__meta">{stage.meta}</span>
          {index < stages.length - 1 && (
            <span className="pipeline__arrow" aria-hidden="true" />
          )}
        </li>
      ))}
    </ol>
  );
}
