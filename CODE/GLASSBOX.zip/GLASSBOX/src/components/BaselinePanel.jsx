import Panel, { EmptyState } from "./Panel.jsx";
import { formatNumber } from "./format.js";

function Row({ label, mean, std, unit = "", current, digits }) {
  const delta =
    Number.isFinite(current) && Number.isFinite(mean) ? current - mean : null;

  return (
    <tr>
      <th scope="row">{label}</th>
      <td className="mono">
        {formatNumber(mean, digits)}
        {unit}
        <span className="muted"> ± {formatNumber(std, digits)}</span>
      </td>
      <td className="mono">
        {Number.isFinite(current)
          ? `${formatNumber(current, digits)}${unit}`
          : "—"}
      </td>
      <td className="mono">
        {delta === null
          ? "—"
          : `${delta >= 0 ? "+" : ""}${formatNumber(delta, digits)}${unit}`}
      </td>
    </tr>
  );
}

export default function BaselinePanel({ baseline, gaze, head }) {
  const g = gaze?.metadata?.gaze;
  const h = head?.metadata?.current;

  return (
    <Panel
      title="Personal baseline"
      aside={
        baseline && (
          <span className="muted">
            {Math.round(baseline.quality * 100)}% tracking quality ·{" "}
            {baseline.sampleCount} samples
          </span>
        )
      }
    >
      {!baseline ? (
        <EmptyState title="Not calibrated">
          Run calibration in the live monitoring panel. The baseline is this
          person’s own gaze and head-pose range; deviations are measured
          against it.
        </EmptyState>
      ) : (
        <>
          <div className="table-wrap">
            <table className="table table--baseline">
              <thead>
                <tr>
                  <th />
                  <th>Baseline (mean ± SD)</th>
                  <th>Current</th>
                  <th>Δ</th>
                </tr>
              </thead>
              <tbody>
                <Row
                  label="Gaze X"
                  mean={baseline.gazeXMean}
                  std={baseline.gazeXStd}
                  current={g?.x}
                  digits={3}
                />
                <Row
                  label="Gaze Y"
                  mean={baseline.gazeYMean}
                  std={baseline.gazeYStd}
                  current={g?.y}
                  digits={3}
                />
                <Row
                  label="Head yaw"
                  mean={baseline.headYawMean}
                  std={baseline.headYawStd}
                  unit="°"
                  current={h?.yaw}
                  digits={1}
                />
                <Row
                  label="Head pitch"
                  mean={baseline.headPitchMean}
                  std={baseline.headPitchStd}
                  unit="°"
                  current={h?.pitch}
                  digits={1}
                />
                <Row
                  label="Head roll"
                  mean={baseline.headRollMean}
                  std={baseline.headRollStd}
                  unit="°"
                  current={h?.roll}
                  digits={1}
                />
              </tbody>
            </table>
          </div>
          {!g && !h && (
            <p className="footnote">
              Current values appear once a session is recording.
            </p>
          )}
        </>
      )}
    </Panel>
  );
}
