// Presentation helpers only. Nothing here feeds back into the processing pipeline.

export const EVENT_LABELS = {
  GAZE_DEVIATION_EPISODE: "Gaze deviation",
  HEAD_POSE_DEVIATION_EPISODE: "Head-pose deviation",
  FOCUS_LOSS_EPISODE: "Window focus loss",
  FACE_ABSENCE_EPISODE: "Face absence",
};

export function eventLabel(type) {
  return EVENT_LABELS[type] ?? type;
}

export function formatClock(timestamp) {
  if (!Number.isFinite(timestamp)) return "—";
  return new Date(timestamp).toLocaleTimeString([], {
    hour12: false,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}

export function formatDuration(ms) {
  if (!Number.isFinite(ms)) return "—";
  if (ms < 1000) return `${Math.round(ms)} ms`;
  const seconds = ms / 1000;
  if (seconds < 60) return `${seconds.toFixed(1)} s`;
  const minutes = Math.floor(seconds / 60);
  return `${minutes}m ${Math.round(seconds - minutes * 60)}s`;
}

export function formatElapsed(ms) {
  const total = Math.max(Math.floor(ms / 1000), 0);
  const m = String(Math.floor(total / 60)).padStart(2, "0");
  const s = String(total % 60).padStart(2, "0");
  return `${m}:${s}`;
}

export function formatNumber(value, digits = 2) {
  return Number.isFinite(value) ? value.toFixed(digits) : "—";
}

export function clamp01(value) {
  return Math.min(Math.max(Number(value) || 0, 0), 1);
}

/*
 * Display-only normalisation. These mirror the scaling EvidenceEngine
 * already applies (gaze: value / 3, head: per-axis / 45, 30, 30) so the
 * dashboard bars line up with the strengths the engines compute.
 */
export function gazeDisplayScore(deviation) {
  return clamp01(Number(deviation) / 3);
}

export function headDisplayScore(deviation) {
  if (!deviation) return 0;
  const { yaw = 0, pitch = 0, roll = 0 } = deviation;
  return (
    (Math.min(Math.abs(yaw) / 45, 1) +
      Math.min(Math.abs(pitch) / 30, 1) +
      Math.min(Math.abs(roll) / 30, 1)) /
    3
  );
}

/* RiskEngine labels component scores >= 0.5 as "notable". */
export const NOTABLE_THRESHOLD = 0.5;

/* Latest signal of the given type(s), scanning from the newest end. */
export function latestSignal(signals, types) {
  for (let i = signals.length - 1; i >= 0; i -= 1) {
    if (types.includes(signals[i].type)) return signals[i];
  }
  return null;
}
