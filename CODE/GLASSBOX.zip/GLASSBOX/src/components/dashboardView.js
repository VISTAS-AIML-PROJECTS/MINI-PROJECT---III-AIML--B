/*
 * Maps existing application state onto what the dashboard displays.
 * Read-only: it derives labels and tones, it never produces data.
 */
import {
  NOTABLE_THRESHOLD,
  formatNumber,
  gazeDisplayScore,
  headDisplayScore,
  latestSignal,
} from "./format.js";

const MEDIA_ERRORS = [
  "NotAllowedError",
  "NotFoundError",
  "NotReadableError",
  "OverconstrainedError",
  "SecurityError",
  "TrackEnded",
];

function cameraErrorText(tracker) {
  switch (tracker.errorName) {
    case "NotAllowedError":
      return "Camera permission was denied. Allow camera access for this site and reload.";
    case "NotFoundError":
      return "No camera was found on this device.";
    case "NotReadableError":
      return "The camera is in use by another application.";
    case "TrackEnded":
      return "The camera was disconnected during the session. Time without frames is marked as unobserved.";
    default:
      return (
        tracker.errorMessage ||
        "The camera or the MediaPipe model could not be started."
      );
  }
}

export function buildHeader({
  backendStatus,
  tracker,
  baseline,
  calibrating,
  sessionActive,
  sessionId,
  sessionStatus,
}) {
  const backend =
    backendStatus === "Backend connected"
      ? "ok"
      : backendStatus === "Backend unavailable"
        ? "bad"
        : "idle";

  let state;
  let detail = null;

  if (backend === "bad") {
    state = { label: "Backend unavailable", tone: "bad" };
    detail = {
      tone: "bad",
      text: "The GlassBox server did not respond. Sessions cannot be recorded until it is running (start it with node server/server.js).",
    };
  } else if (tracker.phase === "ERROR") {
    state = { label: "Camera unavailable", tone: "bad" };
    detail = { tone: "bad", text: cameraErrorText(tracker) };
  } else if (backend !== "ok" || tracker.phase === "INITIALIZING") {
    state = { label: "Initializing", tone: "warn", pulse: true };
  } else if (sessionActive) {
    state = { label: "Monitoring active", tone: "ok", pulse: true };
  } else if (/starting|finalizing/i.test(sessionStatus)) {
    state = { label: sessionStatus.replace(/\.+$/, ""), tone: "warn", pulse: true };
  } else if (sessionId) {
    state = { label: "Monitoring stopped", tone: "idle" };
  } else {
    state = { label: "Ready", tone: "idle" };
  }

  const items = [
    {
      label: "Backend",
      value:
        backend === "ok"
          ? "Connected"
          : backend === "bad"
            ? "Unavailable"
            : "Connecting",
      tone: backend,
    },
    {
      label: "Tracker",
      value:
        tracker.phase === "READY"
          ? "Ready"
          : tracker.phase === "ERROR"
            ? "Failed"
            : "Starting",
      tone:
        tracker.phase === "READY"
          ? "ok"
          : tracker.phase === "ERROR"
            ? "bad"
            : "idle",
    },
    {
      label: "Baseline",
      value: baseline
        ? "Calibrated"
        : calibrating
          ? "Calibrating"
          : "Not calibrated",
      tone: baseline ? "ok" : "idle",
    },
  ];

  return { state, detail, items };
}

/* Vision readings older than this mean frames stopped arriving. */
const STALE_VISION_MS = 2000;

export function buildIndicators({
  signals,
  sessionActive,
  sessionId,
  baseline,
  now = null,
}) {
  const idleLabel = sessionActive
    ? "Waiting"
    : sessionId
      ? "Session ended"
      : "Not recording";

  const face = latestSignal(signals, ["FACE_PRESENT", "FACE_ABSENT"]);
  const quality = latestSignal(signals, ["FACE_QUALITY"]);
  const gaze = latestSignal(signals, ["GAZE_DEVIATION"]);
  const head = latestSignal(signals, ["HEAD_POSE_DEVIATION"]);
  const focus = latestSignal(signals, [
    "FOCUS_LOST",
    "FOCUS_GAINED",
    "TAB_HIDDEN",
    "TAB_VISIBLE",
  ]);

  const live = sessionActive;
  const faceAbsent = live && face?.type === "FACE_ABSENT";
  const visionStale =
    live && face && now !== null && now - face.timestamp > STALE_VISION_MS;

  /* Face detection */
  let faceInd;
  if (visionStale) {
    faceInd = {
      state: { label: "No camera frames", tone: "bad" },
      value: "—",
      detail: `Last frame ${Math.round((now - face.timestamp) / 1000)} s ago`,
    };
  } else if (!live || !face) {
    faceInd = {
      state: { label: idleLabel, tone: "idle" },
      value: "—",
      detail: "MediaPipe face landmarks",
    };
  } else if (faceAbsent) {
    faceInd = {
      state: { label: "Not detected", tone: "bad" },
      value: "—",
      detail: "No face in frame",
    };
  } else {
    faceInd = {
      state: { label: "Detected", tone: "ok" },
      value: quality ? `${Math.round(quality.value * 100)}% quality` : "—",
      detail: "Landmarks tracked",
    };
  }

  /* Gaze */
  let gazeInd;
  if (!baseline) {
    gazeInd = {
      state: { label: "Needs calibration", tone: "idle" },
      value: "—",
      detail: "Deviation from baseline",
    };
  } else if (!live || !gaze) {
    gazeInd = {
      state: { label: idleLabel, tone: "idle" },
      value: "—",
      detail: "Deviation from baseline",
    };
  } else if (faceAbsent) {
    gazeInd = {
      state: { label: "No face", tone: "idle" },
      value: "—",
      detail: "Deviation from baseline",
    };
  } else {
    const score = gazeDisplayScore(gaze.value);
    gazeInd = {
      state: {
        label: score >= NOTABLE_THRESHOLD ? "Notable" : "Within baseline",
        tone: score >= NOTABLE_THRESHOLD ? "warn" : "ok",
      },
      value: `${formatNumber(gaze.value, 1)} σ`,
      detail: "Deviation from baseline",
      score,
    };
  }

  /* Head movement */
  let headInd;
  if (!baseline) {
    headInd = {
      state: { label: "Needs calibration", tone: "idle" },
      value: "—",
      detail: "Yaw / pitch / roll offset",
    };
  } else if (!live || !head) {
    headInd = {
      state: { label: idleLabel, tone: "idle" },
      value: "—",
      detail: "Yaw / pitch / roll offset",
    };
  } else if (faceAbsent) {
    headInd = {
      state: { label: "No face", tone: "idle" },
      value: "—",
      detail: "Yaw / pitch / roll offset",
    };
  } else {
    const score = headDisplayScore(head.value);
    const { yaw = 0, pitch = 0, roll = 0 } = head.value ?? {};
    headInd = {
      state: {
        label: score >= NOTABLE_THRESHOLD ? "Notable" : "Within baseline",
        tone: score >= NOTABLE_THRESHOLD ? "warn" : "ok",
      },
      value: `${yaw.toFixed(0)}° ${pitch.toFixed(0)}° ${roll.toFixed(0)}°`,
      detail: "Yaw / pitch / roll offset",
      score,
    };
  }

  /* Window focus (browser) */
  let focusInd;
  if (!live) {
    focusInd = {
      state: { label: idleLabel, tone: "idle" },
      value: "—",
      detail: "Browser window / tab",
    };
  } else if (!focus) {
    focusInd = {
      state: { label: "No change recorded", tone: "idle" },
      value: "—",
      detail: "Browser window / tab",
    };
  } else {
    const away = focus.type === "FOCUS_LOST" || focus.type === "TAB_HIDDEN";
    focusInd = {
      state: away
        ? { label: "Focus lost", tone: "warn" }
        : { label: "In focus", tone: "ok" },
      value: "—",
      detail: "Browser window / tab",
    };
  }

  return {
    indicators: [
      { label: "Face detection", ...faceInd },
      { label: "Gaze", ...gazeInd },
      { label: "Head movement", ...headInd },
      { label: "Window focus", ...focusInd },
    ],
    gaze,
    head,
  };
}

export function buildStages({
  tracker,
  signalCount = 0,
  evidence,
  features,
  risk,
  sessionActive,
}) {
  const cameraFailed =
    tracker.phase === "ERROR" && MEDIA_ERRORS.includes(tracker.errorName);
  const modelFailed = tracker.phase === "ERROR" && !cameraFailed;

  const trackerTone =
    tracker.phase === "READY"
      ? "ok"
      : tracker.phase === "ERROR"
        ? "bad"
        : "warn";

  return [
    {
      name: "Camera",
      tone: cameraFailed ? "bad" : modelFailed ? "idle" : trackerTone,
      meta: cameraFailed
        ? "Unavailable"
        : tracker.phase === "READY"
          ? "Live"
          : modelFailed
            ? "—"
            : "Starting",
    },
    {
      name: "Vision tracking",
      tone: modelFailed ? "bad" : cameraFailed ? "idle" : trackerTone,
      meta: modelFailed
        ? "Failed"
        : tracker.phase === "READY"
          ? "Model ready"
          : cameraFailed
            ? "—"
            : "Loading model",
    },
    {
      name: "Feature extraction",
      tone: features ? "ok" : "idle",
      meta: sessionActive || signalCount
        ? `${signalCount} signals`
        : "No signals",
    },
    {
      name: "Behaviour analysis",
      tone: evidence.length ? "ok" : "idle",
      meta: `${evidence.length} ${evidence.length === 1 ? "event" : "events"}`,
    },
    {
      name: "Explanation",
      tone: !risk
        ? "idle"
        : risk.state === "INSUFFICIENT_EVIDENCE"
          ? "bad"
          : risk.state === "DEGRADED"
            ? "warn"
            : "ok",
      meta: !risk
        ? "No assessment"
        : risk.state === "INSUFFICIENT_EVIDENCE"
          ? "Insufficient evidence"
          : `Risk ${risk.level.toLowerCase()}`,
    },
  ];
}
