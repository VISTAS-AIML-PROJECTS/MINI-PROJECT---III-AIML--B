import Panel from "./Panel.jsx";

const GLYPH = { ok: "✓", warn: "!", bad: "✕", idle: "–" };

function Indicator({ label, state, value, detail, score }) {
  return (
    <li className="indicator" data-tone={state.tone}>
      <span className="indicator__glyph" aria-hidden="true">
        {GLYPH[state.tone] ?? "–"}
      </span>
      <div className="indicator__body">
        <div className="indicator__row">
          <span className="indicator__label">{label}</span>
          <span className="indicator__state">{state.label}</span>
        </div>
        <div className="indicator__row indicator__row--sub">
          <span>{detail}</span>
          <span className="mono">{value}</span>
        </div>
        {score != null && (
          <div className="meter" aria-hidden="true">
            <span style={{ width: `${Math.round(score * 100)}%` }} />
          </div>
        )}
      </div>
    </li>
  );
}

export default function IndicatorGrid({ indicators }) {
  return (
    <Panel
      title="Behaviour indicators"
      aside={<span className="muted">Latest reading</span>}
    >
      <ul className="indicators">
        {indicators.map((item) => (
          <Indicator key={item.label} {...item} />
        ))}
      </ul>
      <p className="footnote">
        “Notable” uses the same 0.5 cut-off the risk engine applies to
        gaze and head-pose scores. Readings are instantaneous; the engines
        judge sustained episodes.
      </p>
    </Panel>
  );
}
