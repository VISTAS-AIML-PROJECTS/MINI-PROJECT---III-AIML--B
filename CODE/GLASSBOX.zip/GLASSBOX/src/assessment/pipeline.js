import { EvidenceEngine } from "../evidence/evidenceEngine.js";
import { FusionEngine } from "../risk/fusionEngine.js";
import { RiskEngine } from "../risk/riskEngine.js";
import { AssessmentEngine } from "./assessmentEngine.js";
import { ObservationMonitor } from "./observationMonitor.js";

/*
 * The complete signal → evidence → assessment chain as ONE object, so the live
 * app (src/App.jsx), the tests (research/tests/) and the offline experiments
 * (research/final/) all run exactly the same code.
 *
 *   processSignal(signal)  every raw signal (vision frames, browser events)
 *   tick(now)              once per second: closes expired episodes,
 *                          re-evaluates the assessment, returns it
 *   finalize(now)          session end: closes every open episode (focus
 *                          loss and face absence included) and returns the
 *                          final assessment
 *
 * The frozen v1 chain (FusionEngine + RiskEngine, unchanged since the
 * committed research) runs alongside for comparison; its score is attached
 * to each assessment as `legacy` and is never used for decisions.
 */
export class AssessmentPipeline {
  constructor({
    focusAvailable = true,
    legacy = true,
    onEvidence = () => {},
    onFusion = () => {},
    config,
  } = {}) {
    this.monitor = new ObservationMonitor({ focusAvailable, config });

    this.legacyRisk = legacy ? new RiskEngine() : null;
    this.legacyFusion = legacy
      ? new FusionEngine({
          onFusion: (fusion) => {
            this.legacyRisk.processFusion(fusion);
            this.latestFusion = fusion;
            onFusion(fusion);
          },
        })
      : null;

    this.evidenceEngine = new EvidenceEngine({
      onEvidence: (evidence) => {
        this.assessment.processEvidence(evidence);
        this.legacyRisk?.processEvidence(evidence);
        onEvidence(evidence);
      },
    });

    this.assessment = new AssessmentEngine({
      monitor: this.monitor,
      evidenceSource: this.evidenceEngine,
      config,
    });

    this.latestFusion = null;
  }

  start(timestamp) {
    this.evidenceEngine.reset();
    this.legacyFusion?.reset();
    this.legacyRisk?.reset();
    this.assessment.reset();
    this.monitor.start(timestamp);
    this.latestFusion = null;
  }

  setCalibrated(calibrated) {
    this.assessment.setCalibrated(calibrated);
  }

  processSignal(signal) {
    if (!signal) return;

    this.monitor.processSignal(signal);
    this.evidenceEngine.processSignal(signal);
    this.legacyFusion?.processSignal(signal);
  }

  tick(now) {
    this.evidenceEngine.advanceTo(now);

    const assessment = this.assessment.update(now);

    if (assessment && this.legacyRisk) {
      const legacy = this.legacyRisk.calculateRisk();

      assessment.legacy = {
        score: legacy.score,
        level: legacy.level,
        components: legacy.components,
      };
    }

    return assessment;
  }

  finalize(now) {
    this.evidenceEngine.finalize(now);
    return this.tick(now);
  }

  summary(now) {
    return this.monitor.totals(now);
  }
}
