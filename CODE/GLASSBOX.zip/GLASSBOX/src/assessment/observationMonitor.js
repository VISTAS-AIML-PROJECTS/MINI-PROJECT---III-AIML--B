import { SIGNAL_TYPES } from "../core/signal.js";
import { ASSESSMENT_CONFIG } from "./assessmentConfig.js";

/*
 * Observation monitor: what could the system actually SEE, second by second?
 *
 * The risk engines only ever see behaviour that was observed. Without this
 * record "nothing suspicious happened" and "nothing could be observed"
 * (camera stopped, tab throttled, face out of frame, no calibration) look
 * identical: both produce no evidence and a low score.
 *
 * Each signal is binned into 1-s slots relative to the session start:
 *   vision      >= 1 FACE_PRESENT / FACE_ABSENT frame (camera + tracker alive)
 *   face        >= 1 FACE_PRESENT frame
 *   measurable  >= 1 GAZE / HEAD_POSE sample with face quality >= minFaceQuality
 *               (requires a calibrated baseline; uncalibrated sessions emit none)
 *
 * Pure bookkeeping, driven only by signal timestamps: identical input gives
 * identical output.
 */
export class ObservationMonitor {
  constructor({
    config = ASSESSMENT_CONFIG,
    focusAvailable = true,
  } = {}) {
    this.config = config;
    this.focusAvailable = focusAvailable;
    this.reset();
  }

  reset() {
    this.startedAt = null;
    this.bins = new Map();
    this.lastQuality = null;
    this.lastVisionAt = null;
    this.latestAt = null;
  }

  start(timestamp) {
    this.reset();
    this.startedAt = timestamp;
  }

  bin(timestamp) {
    if (this.startedAt === null) {
      this.startedAt = timestamp;
    }

    const index = Math.floor((timestamp - this.startedAt) / 1000);
    let slot = this.bins.get(index);

    if (!slot) {
      slot = { vision: 0, face: 0, measurable: 0 };
      this.bins.set(index, slot);
    }

    return slot;
  }

  processSignal(signal) {
    const t = Number(signal?.timestamp);

    if (!Number.isFinite(t)) {
      return;
    }

    this.latestAt = Math.max(this.latestAt ?? t, t);

    switch (signal.type) {
      case SIGNAL_TYPES.FACE_PRESENT:
        this.bin(t).vision += 1;
        this.bin(t).face += 1;
        this.lastVisionAt = t;
        break;

      case SIGNAL_TYPES.FACE_ABSENT:
        this.bin(t).vision += 1;
        this.lastVisionAt = t;
        break;

      case SIGNAL_TYPES.FACE_QUALITY:
        this.lastQuality = Number(signal.value);
        break;

      case SIGNAL_TYPES.GAZE_DEVIATION:
      case SIGNAL_TYPES.HEAD_POSE_DEVIATION: {
        const q = Number(signal.confidence ?? this.lastQuality ?? 1);

        if (!Number.isFinite(q) || q >= this.config.minFaceQuality) {
          this.bin(t).measurable += 1;
        }

        break;
      }

      default:
        break;
    }
  }

  /*
   * Fractions of whole seconds in (now - windowMs, now] (clipped to the
   * session start) in which each kind of observation was possible.
   */
  coverage(now, windowMs = this.config.coverageWindowMs) {
    if (this.startedAt === null || !Number.isFinite(now)) {
      return {
        seconds: 0,
        vision: 0,
        face: 0,
        measurable: 0,
        focus: this.focusAvailable ? 1 : null,
      };
    }

    const last = Math.floor((now - this.startedAt) / 1000) - 1;
    const first = Math.max(0, last - Math.floor(windowMs / 1000) + 1);
    const seconds = Math.max(last - first + 1, 0);

    let vision = 0;
    let face = 0;
    let measurable = 0;

    for (let i = first; i <= last; i++) {
      const slot = this.bins.get(i);

      if (!slot) continue;
      if (slot.vision > 0) vision += 1;
      if (slot.face > 0) face += 1;
      if (slot.measurable > 0) measurable += 1;
    }

    const frac = (n) => (seconds > 0 ? n / seconds : 0);

    return {
      seconds,
      vision: frac(vision),
      face: frac(face),
      measurable: frac(measurable),
      focus: this.focusAvailable ? 1 : null,
    };
  }

  /*
   * Whole-session totals for the session summary.
   */
  totals(now) {
    const all = this.coverage(now, Number.MAX_SAFE_INTEGER);

    let longestGapS = 0;
    let gap = 0;

    for (let i = 0; i < all.seconds; i++) {
      if ((this.bins.get(i)?.vision ?? 0) > 0) {
        gap = 0;
      } else {
        gap += 1;
        longestGapS = Math.max(longestGapS, gap);
      }
    }

    return {
      sessionSeconds: all.seconds,
      observedSeconds: Math.round(all.vision * all.seconds),
      measurableSeconds: Math.round(all.measurable * all.seconds),
      longestCameraGapSeconds: longestGapS,
    };
  }

  observedMs(now) {
    const c = this.coverage(now, Number.MAX_SAFE_INTEGER);
    return c.vision * c.seconds * 1000;
  }
}
