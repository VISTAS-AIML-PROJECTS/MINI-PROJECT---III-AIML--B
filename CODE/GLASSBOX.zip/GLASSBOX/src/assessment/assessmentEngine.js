import {
  ASSESSMENT_CONFIG,
  ASSESSMENT_VERSION,
  CHANNEL_EVIDENCE_TYPES,
  CHANNEL_LABELS,
  GROUPS,
  GROUP_LABELS,
} from "./assessmentConfig.js";

/*
 * GlassBox assessment engine (v2): the session risk index.
 *
 *   evidence episodes (closed + ongoing)          observation coverage
 *            │                                             │
 *   per-channel evidence c_k(t) ∈ [0,1]           reliability r(t) ∈ [0,1]
 *            │                                             │
 *   groups: attention = max(gaze, head)           state: OK / DEGRADED /
 *           presence  = face absence                     INSUFFICIENT_EVIDENCE
 *           focus     = focus loss                         │
 *            │                                             │
 *   R = 0.5·g(1) + 0.3·g(2) + 0.2·g(3)  (groups sorted, strongest first)
 *   score = round(100·R); level with hysteresis; level is UNDETERMINED when
 *   the evidence is insufficient AND nothing notable was observed.
 *
 * c_k(t) = min(1, Σ_e strength_e · u_e · exp(-(t − t_e)/τ) / 3), τ = 120 s,
 * u_e = max(1, duration_e / 5 s). Without u_e this is v1's per-channel rule
 * (src/risk/riskEngine.js); u_e makes a long episode count like repeated
 * ones, and ongoing episodes are included at their current length.
 *
 * Differences from v1 and why (docs/final/RISK_SCORE_SPEC.md):
 *  - gaze and head pose measure overlapping behaviour (turning towards
 *    something), so they form ONE group scored by the stronger cue instead of
 *    being added (v1 adds both AND re-adds them in its fusion component);
 *  - corroboration comes from independent groups (camera vs browser,
 *    presence vs attention), not from a sticky "latest fusion" sample, which
 *    in v1 keeps its last non-zero value forever;
 *  - the score is evaluated on a clock (update(now)), so it decays during
 *    calm periods instead of freezing at its last value;
 *  - "nothing observed" is distinguished from "nothing suspicious".
 *
 * The score is a heuristic review-priority index on 0-100. It is NOT a
 * probability of cheating and has not been calibrated as one.
 */
export class AssessmentEngine {
  constructor({
    monitor,
    evidenceSource = null,
    config = ASSESSMENT_CONFIG,
    onAssessment = () => {},
  } = {}) {
    if (!monitor) {
      throw new Error("AssessmentEngine needs an ObservationMonitor.");
    }

    this.monitor = monitor;
    this.evidenceSource = evidenceSource;
    this.config = config;
    this.onAssessment = onAssessment;
    this.reset();
  }

  reset() {
    this.evidence = [];
    this.level = null;
    this.calibrated = null;
    this.latest = null;
  }

  setCalibrated(calibrated) {
    this.calibrated = Boolean(calibrated);
  }

  processEvidence(evidence) {
    if (evidence && CHANNEL_KEY_BY_TYPE[evidence.type]) {
      this.evidence.push(evidence);
    }
  }

  // Sub-threshold face absences are detector dropouts, not behaviour.
  isNoise(channel, episode) {
    return (
      channel === "faceAbsence" &&
      !(Number(episode.durationMs) >= (this.config.minAbsenceMs ?? 0))
    );
  }

  decay(age) {
    return age <= 0 ? 1 : Math.exp(-age / this.config.decayMs);
  }

  channelScores(now, open) {
    const channels = {};

    for (const [key, type] of Object.entries(CHANNEL_EVIDENCE_TYPES)) {
      let total = 0;
      let episodes = 0;
      let ongoing = null;
      let strongest = 0;

      const add = (episode) => {
        const strength = clamp01(Number(episode.strength));
        const t = Number(episode.timestamp);
        const w = Number.isFinite(t) ? this.decay(now - t) : 1;
        const durationMs = Number(episode.durationMs);
        const units = Number.isFinite(durationMs)
          ? Math.max(1, durationMs / this.config.persistenceUnitMs)
          : 1;

        total += strength * units * w;
        strongest = Math.max(strongest, strength);
      };

      for (const episode of this.evidence) {
        if (
          episode.type === type &&
          Number(episode.timestamp) <= now &&
          !this.isNoise(key, episode)
        ) {
          add(episode);
          episodes += 1;
        }
      }

      for (const episode of open) {
        if (episode.type === type && !this.isNoise(key, episode)) {
          add(episode);
          ongoing = {
            durationMs: episode.durationMs,
            strength: episode.strength,
            startedAt: episode.startedAt,
          };
        }
      }

      channels[key] = {
        score: Math.min(total / this.config.saturation, 1),
        episodes,
        ongoing,
        strongest,
      };
    }

    return channels;
  }

  reliability(coverage) {
    const parts = {
      presence: coverage.vision,
      attention: this.calibrated === false ? 0 : coverage.measurable,
    };

    if (coverage.focus !== null) {
      parts.focus = coverage.focus;
    }

    const values = Object.values(parts);

    return {
      value: values.reduce((a, b) => a + b, 0) / values.length,
      groups: parts,
    };
  }

  levelFor(score) {
    const { medium, high } = this.config.levels;
    const h = this.config.hysteresis;
    const previous = this.level;

    const rank = (level) =>
      level === "HIGH" ? 2 : level === "MEDIUM" ? 1 : 0;

    let raw = score >= high ? "HIGH" : score >= medium ? "MEDIUM" : "LOW";

    // Leaving a level requires dropping `h` points below its threshold.
    if (previous && rank(raw) < rank(previous)) {
      if (previous === "HIGH" && score >= high - h) raw = "HIGH";
      else if (previous === "HIGH" && score >= medium - h) raw = "MEDIUM";
      else if (previous === "MEDIUM" && score >= medium - h) raw = "MEDIUM";
    }

    this.level = raw;
    return raw;
  }

  update(now) {
    if (!Number.isFinite(now)) {
      return null;
    }

    const open = this.evidenceSource?.getOpenEpisodes?.(now) ?? [];
    const channels = this.channelScores(now, open);

    const groups = {};

    for (const [group, keys] of Object.entries(GROUPS)) {
      if (group === "focus" && this.monitor.focusAvailable === false) {
        continue;
      }

      let best = keys[0];

      for (const key of keys) {
        if (channels[key].score > channels[best].score) best = key;
      }

      groups[group] = {
        score: channels[best].score,
        driver: channels[best].score > 0 ? best : null,
      };
    }

    const ranked = Object.entries(groups).sort(
      (a, b) => b[1].score - a[1].score || a[0].localeCompare(b[0])
    );

    const contributions = {};
    let total = 0;

    ranked.forEach(([group, g], i) => {
      const weight = this.config.rankWeights[i] ?? 0;
      const points = 100 * weight * g.score;

      contributions[group] = { weight, points };
      total += points;
    });

    const score = Math.round(Math.min(Math.max(total, 0), 100));

    const coverage = this.monitor.coverage(now);
    const rel = this.reliability(coverage);
    const observedMs = this.monitor.observedMs(now);

    let state = "OK";
    const limitations = [];

    if (this.calibrated === false) {
      limitations.push("NOT_CALIBRATED");
    }

    if (coverage.vision < 1 && coverage.seconds > 0) {
      limitations.push("CAMERA_GAPS");
    }

    if (coverage.vision > 0 && coverage.measurable < coverage.vision) {
      limitations.push("GAZE_HEAD_PARTLY_UNMEASURABLE");
    }

    if (observedMs < this.config.minObservedMs) {
      state = "INSUFFICIENT_EVIDENCE";
      limitations.push("TOO_LITTLE_OBSERVATION");
    } else if (rel.value < this.config.insufficientBelow) {
      state = "INSUFFICIENT_EVIDENCE";
    } else if (rel.value < this.config.degradedBelow) {
      state = "DEGRADED";
    }

    let level = this.levelFor(score);

    // Unobserved time cannot certify "LOW"; observed evidence still stands.
    if (state === "INSUFFICIENT_EVIDENCE" && level === "LOW") {
      level = "UNDETERMINED";
    }

    const assessment = {
      version: ASSESSMENT_VERSION,
      timestamp: now,
      score,
      level,
      state,
      reliability: rel.value,
      reliabilityByGroup: rel.groups,
      coverage,
      limitations,
      channels,
      groups,
      contributions,
      components: Object.fromEntries(
        Object.entries(channels).map(([k, c]) => [k, c.score])
      ),
      reasons: this.buildReasons({ channels, groups, contributions, state, limitations }),
    };

    this.latest = assessment;
    this.onAssessment(assessment);

    return assessment;
  }

  buildReasons({ channels, groups, contributions, state, limitations }) {
    const reasons = [];

    const ordered = Object.entries(contributions)
      .filter(([, c]) => c.points >= 0.5)
      .sort((a, b) => b[1].points - a[1].points);

    for (const [group, c] of ordered) {
      const driver = groups[group].driver;
      const ch = channels[driver];
      const parts = [];

      if (ch.episodes > 0) {
        parts.push(`${ch.episodes} episode${ch.episodes === 1 ? "" : "s"}`);
      }

      if (ch.ongoing) {
        parts.push(`ongoing for ${Math.round(ch.ongoing.durationMs / 1000)} s`);
      }

      reasons.push(
        `${GROUP_LABELS[group]}: ${CHANNEL_LABELS[driver]}` +
          (parts.length ? ` (${parts.join(", ")})` : "") +
          ` adds ${Math.round(c.points)} points.`
      );

      if (group === "attention") {
        const other = GROUPS.attention.find((k) => k !== driver);

        if (channels[other].score > 0) {
          reasons.push(
            `${CHANNEL_LABELS[other]} overlaps with ${CHANNEL_LABELS[driver].toLowerCase()} and is not counted twice.`
          );
        }
      }
    }

    if (ordered.length >= 2) {
      reasons.push(
        "More than one independent kind of behaviour was observed recently."
      );
    }

    if (reasons.length === 0) {
      reasons.push("No notable behaviour was observed recently.");
    }

    if (state === "INSUFFICIENT_EVIDENCE") {
      reasons.push(
        limitations.includes("TOO_LITTLE_OBSERVATION")
          ? "Too little has been observed yet to assess this session."
          : "Most of the last minute could not be observed, so a low score here would not mean low risk."
      );
    } else if (state === "DEGRADED") {
      reasons.push(
        limitations.includes("NOT_CALIBRATED")
          ? "Gaze and head pose are not assessed because the session is not calibrated."
          : "Part of the last minute could not be observed (face out of view or camera gaps); the assessment is less reliable."
      );
    }

    return reasons;
  }
}

const CHANNEL_KEY_BY_TYPE = Object.fromEntries(
  Object.entries(CHANNEL_EVIDENCE_TYPES).map(([k, t]) => [t, k])
);

function clamp01(v) {
  return Number.isFinite(v) ? Math.min(Math.max(v, 0), 1) : 0;
}
