/*
 * GlassBox assessment (v2) configuration.
 *
 * Every value here was fixed by design BEFORE any v2 result was looked at
 * (docs/final/RISK_SCORE_SPEC.md records the rationale for each). None was
 * tuned on OEP or on any labelled data; the OEP replay (research/final/
 * f02_oep_v2_vs_v1.py) is a one-shot check against the frozen v1 engine.
 */
// 2.0 = configuration frozen for the pre-registered F02 check (commit 28b8bcd);
// 2.1 = adds the face-absence noise gate (minAbsenceMs) found by diagnosing F02.
export const ASSESSMENT_VERSION = "glassbox-assessment-2.1";

export const ASSESSMENT_CONFIG = Object.freeze({
  // Per-channel evidence: sum of episode strengths, exponentially decayed
  // with this time constant, saturating at `saturation` (same as v1, whose
  // per-channel behaviour is covered by research/tests/evidence_calm_user.mjs).
  decayMs: 120000,
  saturation: 3,

  // Duration-aware accumulation: an episode lasting k x persistenceUnitMs
  // counts as k episodes of its strength (minimum 1). v1 saturates episode
  // strength at 5 s, so a 2-minute absence weighed the same as a 5-second
  // one. 5 s is v1's own persistence saturation, not a tuned value.
  persistenceUnitMs: 5000,

  // v2.1 noise gate. FACE_ABSENT is a per-frame detector output, so a one-
  // or two-frame landmark dropout used to become an absence "episode" (OEP:
  // median 0.4-1.0 s, 4-10 per minute; research/final/results/
  // f02x_burden_diagnosis_v2.0.json). Gaze/head episodes already need >= 0.5 s
  // and 3 samples. Absences shorter than this are treated as tracking noise;
  // 1.5 s is the evidence engine's own gap-bridging constant (episodeGapMs),
  // not a value fitted to OEP. Focus events are exact browser events: no gate.
  minAbsenceMs: 1500,

  // Ordered weighted average over the INDEPENDENT behaviour groups
  // (attention = max(gaze, head), presence, focus), strongest first.
  // One group alone can reach at most 50 -> no single kind of behaviour
  // can produce HIGH; HIGH needs corroboration from a second group.
  rankWeights: Object.freeze([0.5, 0.3, 0.2]),

  // Level bands (unchanged from v1) and a hysteresis margin: a level is
  // entered at its threshold but only left once the score falls this many
  // points below it, so the label does not flicker around a boundary.
  levels: Object.freeze({ medium: 30, high: 60 }),
  hysteresis: 5,

  // Reliability = mean observability of the available groups over the last
  // `coverageWindowMs`. Below `degradedBelow` the assessment is DEGRADED,
  // below `insufficientBelow` (or with < minObservedMs of observation) it is
  // INSUFFICIENT_EVIDENCE.
  coverageWindowMs: 60000,
  degradedBelow: 0.8,
  insufficientBelow: 0.5,
  minObservedMs: 10000,

  // Vision frames below this face-quality value do not count as measurable.
  minFaceQuality: 0.35,
});

export const GROUPS = Object.freeze({
  attention: Object.freeze(["gazeDeviation", "headPoseDeviation"]),
  presence: Object.freeze(["faceAbsence"]),
  focus: Object.freeze(["focusLoss"]),
});

export const CHANNEL_EVIDENCE_TYPES = Object.freeze({
  focusLoss: "FOCUS_LOSS_EPISODE",
  faceAbsence: "FACE_ABSENCE_EPISODE",
  gazeDeviation: "GAZE_DEVIATION_EPISODE",
  headPoseDeviation: "HEAD_POSE_DEVIATION_EPISODE",
});

export const CHANNEL_LABELS = Object.freeze({
  focusLoss: "Window focus loss",
  faceAbsence: "Face absence",
  gazeDeviation: "Gaze deviation",
  headPoseDeviation: "Head-pose deviation",
});

export const GROUP_LABELS = Object.freeze({
  attention: "Looking away (gaze / head pose)",
  presence: "Face not visible",
  focus: "Exam window not in focus",
});
