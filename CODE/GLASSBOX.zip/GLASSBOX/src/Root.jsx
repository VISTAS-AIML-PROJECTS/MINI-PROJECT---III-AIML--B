import App from "./App.jsx";

import Landing from "./pages/Landing.jsx";
import Login from "./pages/Login.jsx";
import ReviewQueue from "./pages/ReviewQueue.jsx";
import Sessions from "./pages/Sessions.jsx";
import SessionDetail from "./pages/SessionDetail.jsx";
import { NavBar } from "./pages/shell.jsx";
import { useRoute } from "./pages/navState.js";

/*
 * Routes (hash based):
 *   #/                landing
 *   #/login           demo sign-in (not real authentication)
 *   #/monitor         the existing monitoring page (App)
 *   #/sessions        session history
 *   #/session/:id     session details
 *   #/review          review queue (human review decisions)
 */
export default function Root() {
  const { path, parts } = useRoute();

  let page;

  if (parts[0] === "monitor") {
    page = <App />;
  } else if (parts[0] === "sessions") {
    page = <Sessions />;
  } else if (parts[0] === "session" && parts[1]) {
    page = <SessionDetail id={parts[1]} />;
  } else if (parts[0] === "review") {
    page = <ReviewQueue />;
  } else if (parts[0] === "login") {
    page = <Login />;
  } else {
    page = <Landing />;
  }

  return (
    <>
      <a className="gb-skip" href="#main-content">
        Skip to content
      </a>

      <NavBar path={path} />

      <div id="main-content">{page}</div>
    </>
  );
}
