const API_BASE_URL = "http://localhost:5000/api";

async function request(endpoint, options = {}) {
  const response = await fetch(
    `${API_BASE_URL}${endpoint}`,
    {
      headers: {
        "Content-Type": "application/json",
        ...(options.headers || {}),
      },
      ...options,
    }
  );

  // A proxy or crashed server can answer with a non-JSON body.
  const data = await response
    .json()
    .catch(() => ({}));

  if (!response.ok) {
    throw new Error(
      data.message ||
        `API request failed: ${response.status}`
    );
  }

  return data;
}

/* =========================================================
   EXAM
   ========================================================= */

export async function createExam(title) {
  return request("/exams", {
    method: "POST",
    body: JSON.stringify({
      title,
    }),
  });
}

/* =========================================================
   STUDENT
   ========================================================= */

export async function createStudent(
  name,
  email
) {
  return request("/students", {
    method: "POST",
    body: JSON.stringify({
      name,
      email,
    }),
  });
}

/* =========================================================
   SESSION
   ========================================================= */

export async function createExamSession(
  examId,
  studentId,
  condition = "UNSPECIFIED"
) {
  return request("/sessions", {
    method: "POST",
    body: JSON.stringify({
      examId,
      studentId,
      condition,
    }),
  });
}

export async function endExamSession(
  sessionId
) {
  return request(
    `/sessions/${sessionId}/end`,
    {
      method: "POST",
    }
  );
}

export async function updateSessionReview(
  sessionId,
  quality,
  approved
) {
  return request(
    `/sessions/${sessionId}/review`,
    {
      method: "PATCH",
      body: JSON.stringify({
        quality,
        approved,
      }),
    }
  );
}

/* Human review decision for the Review queue: CLEARED, FOLLOW_UP or NOTE (append-only on the server). */
export async function addReviewDecision(sessionId, decision, note) {
  return request(`/sessions/${sessionId}/decisions`, {
    method: "POST",
    body: JSON.stringify({ decision, note }),
  });
}

export async function getSession(
  sessionId
) {
  return request(
    `/sessions/${sessionId}`
  );
}

/* =========================================================
   SIGNAL
   ========================================================= */

export async function sendSignal(
  sessionId,
  signal
) {
  return request("/signals", {
    method: "POST",
    body: JSON.stringify({
      sessionId,
      type: signal.type,
      source: signal.source,
      timestamp: signal.timestamp,
      value: signal.value,
      confidence: signal.confidence,
      metadata: signal.metadata,
    }),
  });
}

/* =========================================================
   EVIDENCE
   ========================================================= */

export async function sendEvidence(
  sessionId,
  evidence
) {
  return request("/evidence", {
    method: "POST",
    body: JSON.stringify({
      sessionId,
      type: evidence.type,
      timestamp: evidence.timestamp,
      durationMs: evidence.durationMs,
      persistenceMs:
        evidence.persistenceMs,
      frequency: evidence.frequency,
      strength: evidence.strength,
      decayWeight:
        evidence.decayWeight,
      metadata: evidence.metadata,
    }),
  });
}

/* =========================================================
   FEATURES
   ========================================================= */

export async function sendFeatures(
  sessionId,
  features
) {
  return request("/features", {
    method: "POST",
    body: JSON.stringify({
      sessionId,

      timestamp:
        features.timestamp,

      gazeFrequency:
        features.gazeFrequency,

      headPoseFrequency:
        features.headPoseFrequency,

      focusLossFrequency:
        features.focusLossFrequency,

      faceAbsenceFrequency:
        features.faceAbsenceFrequency,

      gazeDurationMs:
        features.gazeDurationMs,

      headPoseDurationMs:
        features.headPoseDurationMs,

      focusLossDurationMs:
        features.focusLossDurationMs,

      faceAbsenceDurationMs:
        features.faceAbsenceDurationMs,

      gazeStrength:
        features.gazeStrength,

      headPoseStrength:
        features.headPoseStrength,

      focusLossStrength:
        features.focusLossStrength,

      faceAbsenceStrength:
        features.faceAbsenceStrength,

      gazeMagnitude:
        features.gazeMagnitude,

      headPoseMagnitude:
        features.headPoseMagnitude,

      fusionScore:
        features.fusionScore,

      fusionConfidence:
        features.fusionConfidence,

      concurrenceCount:
        features.concurrenceCount,

      behavioralActivity:
        features.behavioralActivity,
    }),
  });
}

/* =========================================================
   FUSION
   ========================================================= */

export async function sendFusion(
  sessionId,
  fusion
) {
  return request("/fusion", {
    method: "POST",
    body: JSON.stringify({
      sessionId,
      timestamp: fusion.timestamp,
      score: fusion.score,
      confidence:
        fusion.confidence,
      signalCount:
        fusion.signalCount,
      concurrentSignals:
        fusion.concurrentSignals,
      components:
        fusion.components,
      reasons:
        fusion.reasons,
    }),
  });
}

/* =========================================================
   RISK
   ========================================================= */

export async function sendRisk(
  sessionId,
  risk
) {
  return request("/risk", {
    method: "POST",
    body: JSON.stringify({
      sessionId,
      timestamp: risk.timestamp,
      score: risk.score,
      level: risk.level,
      reasons: risk.reasons,
      components:
        risk.components,

      // Assessment v2 (src/assessment/); absent for v1 rows.
      state: risk.state,
      reliability: risk.reliability,
      engineVersion: risk.version,
      details: risk.version
        ? {
            coverage: risk.coverage,
            reliabilityByGroup:
              risk.reliabilityByGroup,
            limitations: risk.limitations,
            groups: risk.groups,
            contributions:
              risk.contributions,
            channels: risk.channels,
            legacy: risk.legacy ?? null,
          }
        : undefined,
    }),
  });
}

/*
 * Page is being closed mid-session: tell the server without
 * waiting (sendBeacon survives unload). The session is stored
 * as INTERRUPTED, not COMPLETED.
 */
export function endExamSessionOnUnload(sessionId) {
  if (!sessionId || !navigator.sendBeacon) {
    return false;
  }

  return navigator.sendBeacon(
    `${API_BASE_URL}/sessions/${sessionId}/end?reason=unload`
  );
}

/* =========================================================
   HEALTH
   ========================================================= */

export async function checkBackendHealth() {
  return request("/health");
}