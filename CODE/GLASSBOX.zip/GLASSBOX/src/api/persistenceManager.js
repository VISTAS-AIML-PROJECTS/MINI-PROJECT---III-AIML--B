import {
  sendSignal,
  sendEvidence,
  sendFeatures,
  sendFusion,
  sendRisk,
} from "./glassboxApi.js";

import { SIGNAL_TYPES } from "../core/signal.js";

export class PersistenceManager {
  constructor({
    sessionId = null,
    signalIntervalMs = 1000,
    flushIntervalMs = 2000,
  } = {}) {
    this.sessionId = sessionId;

    this.signalIntervalMs =
      signalIntervalMs;

    this.flushIntervalMs =
      flushIntervalMs;

    this.lastSignalTime = {};

    this.pendingSignals = [];
    this.evidenceQueue = [];

    // Every feature snapshot must be preserved
    this.featuresQueue = [];

    // Keep fusion/risk history too
    this.fusionQueue = [];
    this.riskQueue = [];

    this.flushTimer = null;
    this.running = false;
    this.flushInProgress = false;
    this.flushPromise = Promise.resolve();

    // Bumped by reset(); a flush started in an earlier session stops
    // as soon as it sees a different generation.
    this.generation = 0;
  }

  /* =======================================================
     SESSION
     ======================================================= */

  setSessionId(sessionId) {
    this.sessionId = sessionId;
  }

  start() {
    if (this.running) return;

    this.running = true;

    this.flushTimer = setInterval(
      () => {
        if (!this.flushInProgress) {
          this.flush();
        }
      },
      this.flushIntervalMs
    );
  }

  stop() {
    this.running = false;

    if (this.flushTimer !== null) {
      clearInterval(this.flushTimer);
      this.flushTimer = null;
    }

    // Final flush
    this.flush();
  }

  /* =======================================================
     SIGNALS
     ======================================================= */

  isImportantSignal(signal) {
    return [
      SIGNAL_TYPES.FOCUS_LOST,
      SIGNAL_TYPES.FOCUS_GAINED,
      SIGNAL_TYPES.TAB_HIDDEN,
      SIGNAL_TYPES.TAB_VISIBLE,
      SIGNAL_TYPES.COPY,
      SIGNAL_TYPES.PASTE,
      SIGNAL_TYPES.CUT,
      SIGNAL_TYPES.FACE_ABSENT,
    ].includes(signal.type);
  }

  isSampledSignal(signal) {
    return [
      SIGNAL_TYPES.GAZE_DEVIATION,
      SIGNAL_TYPES.HEAD_POSE_DEVIATION,
      SIGNAL_TYPES.FACE_QUALITY,
    ].includes(signal.type);
  }

  addSignal(signal) {
    if (!this.sessionId || !signal) {
      return;
    }

    /*
     * Important behavioral events are stored immediately.
     */
    if (this.isImportantSignal(signal)) {
      this.pendingSignals.push(signal);
      return;
    }

    /*
     * High-frequency vision samples are downsampled
     * before persistence to avoid unnecessarily huge
     * database files.
     */
    if (this.isSampledSignal(signal)) {
      /*
       * Throttle per signal type. A single shared clock let
       * FACE_QUALITY (emitted first in every frame) win each
       * interval, so gaze and head-pose samples were almost
       * never persisted.
       */
      const now = Date.now();

      const last =
        this.lastSignalTime[signal.type] ?? 0;

      if (
        now - last <
        this.signalIntervalMs
      ) {
        return;
      }

      this.lastSignalTime[signal.type] = now;

      this.pendingSignals.push(signal);
    }
  }

  /* =======================================================
     EVIDENCE
     ======================================================= */

  addEvidence(evidence) {
    if (!this.sessionId || !evidence) {
      return;
    }

    this.evidenceQueue.push(evidence);
  }

  /* =======================================================
     FEATURES
     ======================================================= */

  addFeatures(features) {
    if (!this.sessionId || !features) {
      return;
    }

    /*
     * IMPORTANT:
     * Do NOT overwrite the previous feature snapshot.
     *
     * Each feature snapshot becomes one potential
     * observation/window for the future ML dataset.
     */
    this.featuresQueue.push(features);
  }

  /* =======================================================
     FUSION
     ======================================================= */

  addFusion(fusion) {
    if (!this.sessionId || !fusion) {
      return;
    }

    this.fusionQueue.push(fusion);
  }

  /* =======================================================
     RISK
     ======================================================= */

  addRisk(risk) {
    if (!this.sessionId || !risk) {
      return;
    }

    this.riskQueue.push(risk);
  }

  /* =======================================================
     FLUSH
     ======================================================= */

  /*
   * A flush requested while another is running waits for it and then
   * runs again, so items queued in the meantime (for example the
   * episodes closed by finalize() at session end) are never left behind.
   */
  flush() {
    if (!this.sessionId) {
      return Promise.resolve();
    }

    if (this.flushInProgress) {
      return this.flushPromise.then(() => this.flush());
    }

    this.flushPromise = this.runFlush();

    return this.flushPromise;
  }

  async runFlush() {
    this.flushInProgress = true;

    const sessionId =
      this.sessionId;

    const generation =
      this.generation;

    // False once reset() has started a new session: the queues now
    // belong to it and this flush must not send or remove anything.
    const current = () =>
      this.generation === generation;

    try {
      /* ---------------------------------------------------
         SIGNALS
         --------------------------------------------------- */

      while (
        current() &&
        this.pendingSignals.length >
        0
      ) {
        const signal =
          this.pendingSignals[0];

        await sendSignal(
          sessionId,
          signal
        );

        if (!current()) {
          break;
        }

        this.pendingSignals.shift();
      }

      /* ---------------------------------------------------
         EVIDENCE
         --------------------------------------------------- */

      while (
        current() &&
        this.evidenceQueue.length >
        0
      ) {
        const evidence =
          this.evidenceQueue[0];

        await sendEvidence(
          sessionId,
          evidence
        );

        if (!current()) {
          break;
        }

        this.evidenceQueue.shift();
      }

      /* ---------------------------------------------------
         FEATURES
         --------------------------------------------------- */

      while (
        current() &&
        this.featuresQueue.length >
        0
      ) {
        const features =
          this.featuresQueue[0];

        await sendFeatures(
          sessionId,
          features
        );

        if (!current()) {
          break;
        }

        this.featuresQueue.shift();
      }

      /* ---------------------------------------------------
         FUSION
         --------------------------------------------------- */

      while (
        current() &&
        this.fusionQueue.length >
        0
      ) {
        const fusion =
          this.fusionQueue[0];

        await sendFusion(
          sessionId,
          fusion
        );

        if (!current()) {
          break;
        }

        this.fusionQueue.shift();
      }

      /* ---------------------------------------------------
         RISK
         --------------------------------------------------- */

      while (
        current() &&
        this.riskQueue.length >
        0
      ) {
        const risk =
          this.riskQueue[0];

        await sendRisk(
          sessionId,
          risk
        );

        if (!current()) {
          break;
        }

        this.riskQueue.shift();
      }
    } catch (error) {
      /*
       * IMPORTANT:
       * Failed items remain at the front of their
       * queues because we only remove them after
       * successful transmission.
       */
      console.error(
        "GlassBox persistence error:",
        error
      );
    } finally {
      this.flushInProgress = false;
    }
  }

  /* =======================================================
     RESET
     ======================================================= */

  reset() {
    this.generation += 1;

    this.pendingSignals = [];
    this.evidenceQueue = [];

    this.featuresQueue = [];

    this.fusionQueue = [];
    this.riskQueue = [];

    this.lastSignalTime = {};
  }
} 