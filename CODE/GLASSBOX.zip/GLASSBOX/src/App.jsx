import {
  useCallback,
  useEffect,
  useRef,
  useState,
} from "react";

import { useBrowserSignals } from "./modules/browser/useBrowserSignals.js";
import VisionModule from "./modules/vision/VisionModule.jsx";

import { AssessmentPipeline } from "./assessment/pipeline.js";
import { FeatureEngine } from "./risk/featureEngine.js";

import {
  createExam,
  createStudent,
  createExamSession,
  endExamSession,
  endExamSessionOnUnload,
} from "./api/glassboxApi.js";

import { PersistenceManager } from "./api/persistenceManager.js";

import Header from "./components/Header.jsx";
import PipelineStrip from "./components/PipelineStrip.jsx";
import SessionPanel from "./components/SessionPanel.jsx";
import IndicatorGrid from "./components/IndicatorGrid.jsx";
import ExplanationPanel from "./components/ExplanationPanel.jsx";
import BaselinePanel from "./components/BaselinePanel.jsx";
import EventHistory from "./components/EventHistory.jsx";
import TechnicalDetails from "./components/TechnicalDetails.jsx";
import Panel from "./components/Panel.jsx";
import {
  buildHeader,
  buildIndicators,
  buildStages,
} from "./components/dashboardView.js";

import "./App.css";

/*
 * =========================================================
 * DATA COLLECTION CONDITIONS
 * =========================================================
 */

const CONDITIONS = [
  {
    value: "NORMAL",
    label: "Normal",
    description:
      "Look at the screen normally and behave naturally.",
  },
  {
    value: "LOOK_AWAY",
    label: "Look Away",
    description:
      "Look away from the screen naturally.",
  },
  {
    value: "HEAD_TURN",
    label: "Head Turn",
    description:
      "Turn your head away from the screen.",
  },
  {
    value: "FACE_ABSENT",
    label: "Face Absent",
    description:
      "Move out of the camera view.",
  },
  {
    value: "FOCUS_LOSS",
    label: "Focus Loss",
    description:
      "Temporarily move focus away from the exam window.",
  },
  {
    value: "MULTI_SIGNAL",
    label: "Multi-Signal",
    description:
      "Perform a behavior that naturally produces multiple signals.",
  },
  {
    value: "OTHER",
    label: "Other",
    description:
      "Perform another controlled behavior.",
  },
];

const ASSESSMENT_TICK_MS = 1000;
const UI_REFRESH_MS = 250;

export default function App() {
  /*
   * =======================================================
   * UI STATE
   * =======================================================
   */

  /*
   * Live signal view, refreshed at UI_REFRESH_MS from refs.
   * Vision emits ~80 signals/s; keeping every one in React
   * state re-rendered the page per signal and grew without
   * bound over a long session.
   */
  const [liveSignals, setLiveSignals] = useState({
    latest: [],
    count: 0,
  });

  const [evidence, setEvidence] = useState([]);
  const [fusion, setFusion] = useState(null);
  const [features, setFeatures] = useState(null);
  const [risk, setRisk] = useState(null);

  const [sessionId, setSessionId] =
    useState(null);

  const [selectedCondition, setSelectedCondition] =
    useState("NORMAL");

  const [sessionActive, setSessionActive] =
    useState(false);

  const [sessionStatus, setSessionStatus] =
    useState("READY");

  const [backendStatus, setBackendStatus] =
    useState("Connecting...");

  const [baselineResetToken, setBaselineResetToken] =
    useState(0);

  const [sessionNumber, setSessionNumber] =
    useState(0);

  /*
   * Presentation-only mirror of the vision module's
   * camera / calibration state (reported via onUiState).
   */
  const [visionUi, setVisionUi] = useState({
    trackerState: {
      phase: "INITIALIZING",
      errorName: null,
      errorMessage: null,
    },
    calibrating: false,
    baseline: null,
  });

  /*
   * =======================================================
   * BACKEND REFERENCES
   * =======================================================
   */

  const examIdRef = useRef(null);
  const studentIdRef = useRef(null);
  const sessionIdRef = useRef(null);

  /*
   * =======================================================
   * ENGINE REFERENCES
   * =======================================================
   *
   * AssessmentPipeline = signal → evidence → assessment (v2),
   * with the frozen v1 fusion/risk chain alongside for
   * comparison. It is the same object the tests and offline
   * experiments run (research/final/).
   */

  const pipelineRef = useRef(null);
  const featureEngineRef = useRef(null);
  const persistenceRef = useRef(null);

  const signalCountRef = useRef(0);
  const latestByTypeRef = useRef({});
  const latestFusionRef = useRef(null);
  const persistedFusionRef = useRef(null);
  const calibratedRef = useRef(false);

  /*
   * =======================================================
   * SESSION ACTIVE REF
   * =======================================================
   *
   * Used inside callbacks so they always know
   * whether a collection session is active.
   */

  const sessionActiveRef =
    useRef(false);

  useEffect(() => {
    sessionActiveRef.current =
      sessionActive;
  }, [sessionActive]);

  /*
   * =======================================================
   * ENGINES
   * =======================================================
   *
   * Created once, in an effect (not during render). Every consumer reads
   * these refs with optional chaining inside callbacks, and the vision
   * module only emits signals after the (asynchronous) model load.
   */
  useEffect(() => {
    if (!persistenceRef.current) {
      persistenceRef.current =
        new PersistenceManager({
          signalIntervalMs: 1000,
          flushIntervalMs: 2000,
        });
    }

    if (!featureEngineRef.current) {
      featureEngineRef.current =
        new FeatureEngine({
          windowMs: 60000,
        });
    }

    if (!pipelineRef.current) {
      pipelineRef.current =
        new AssessmentPipeline({
          onEvidence: (newEvidence) => {
            setEvidence((previous) => [
              ...previous,
              newEvidence,
            ]);

            featureEngineRef.current?.processEvidence(
              newEvidence
            );

            if (sessionActiveRef.current) {
              persistenceRef.current?.addEvidence(
                newEvidence
              );
            }
          },

          /*
           * v1 fusion fires on nearly every frame; it is
           * kept for the technical view and persisted at
           * most once per assessment tick.
           */
          onFusion: (newFusion) => {
            latestFusionRef.current = newFusion;

            featureEngineRef.current?.processFusion(
              newFusion
            );
          },
        });
    }
  }, []);

  /*
   * =======================================================
   * CALIBRATION STATE → ASSESSMENT
   * =======================================================
   *
   * Without a baseline no gaze/head-pose signal exists, so
   * the assessment must report that as "not observable",
   * not as "no deviation".
   */
  const calibrated = !!visionUi.baseline;

  useEffect(() => {
    calibratedRef.current = calibrated;
    pipelineRef.current?.setCalibrated(calibrated);
  }, [calibrated]);

  /*
   * =======================================================
   * CREATE EXAM + STUDENT
   * =======================================================
   *
   * We create these once.
   *
   * Sessions are created separately whenever
   * the user clicks Start Session.
   */

  useEffect(() => {
    let cancelled = false;

    async function initializeBackend() {
      try {
        setBackendStatus(
          "Connecting to backend..."
        );

        const examResponse =
          await createExam(
            "GlassBox Behavioral Data Collection"
          );

        const studentResponse =
          await createStudent(
            "Data Collector",
            `collector-${Date.now()}@glassbox.local`
          );

        if (cancelled) return;

        examIdRef.current =
          examResponse.exam.id;

        studentIdRef.current =
          studentResponse.student.id;

        setBackendStatus(
          "Backend connected"
        );
      } catch (error) {
        console.error(
          "GlassBox backend initialization failed:",
          error
        );

        if (!cancelled) {
          setBackendStatus(
            "Backend unavailable"
          );
        }
      }
    }

    initializeBackend();

    return () => {
      cancelled = true;
    };
  }, []);

  /*
   * =======================================================
   * SIGNAL PIPELINE
   * =======================================================
   */

  const handleSignal = useCallback(
    (signal) => {
      /*
       * Do not collect data into a dataset
       * unless a session is active.
       */
      if (
        !sessionActiveRef.current
      ) {
        return;
      }

      signalCountRef.current += 1;
      latestByTypeRef.current[signal.type] =
        signal;

      /*
       * Signal → Persistence (vision samples throttled
       * to 1/s per type inside PersistenceManager)
       */
      persistenceRef.current?.addSignal(
        signal
      );

      /*
       * Signal → Observation monitor + Evidence (+ v1 fusion)
       *
       * Raw signals never change the score directly; they
       * become evidence episodes first.
       */
      pipelineRef.current?.processSignal(
        signal
      );
    },
    []
  );

  /*
   * Browser signal collector remains mounted,
   * but handleSignal ignores signals unless
   * a collection session is active.
   */
  useBrowserSignals(handleSignal);

  /*
   * =======================================================
   * ASSESSMENT CLOCK (1 Hz) AND UI REFRESH
   * =======================================================
   *
   * The assessment is evaluated on a clock, not only when
   * events arrive, so it decays during calm periods and
   * shows ongoing absences/focus loss while they last.
   * One risk, fusion and feature row is persisted per tick.
   */

  const runAssessmentTick = useCallback((now, assessment) => {
    const result =
      assessment ?? pipelineRef.current?.tick(now);

    if (!result) {
      return;
    }

    setRisk(result);

    const snapshot =
      featureEngineRef.current?.calculateFeatures(now);

    if (snapshot) {
      setFeatures(snapshot);
    }

    const latestFusion = latestFusionRef.current;

    if (latestFusion) {
      setFusion(latestFusion);
    }

    if (!sessionActiveRef.current) {
      return;
    }

    persistenceRef.current?.addRisk(result);

    if (snapshot) {
      persistenceRef.current?.addFeatures(snapshot);
    }

    if (
      latestFusion &&
      latestFusion !== persistedFusionRef.current
    ) {
      persistenceRef.current?.addFusion(latestFusion);
      persistedFusionRef.current = latestFusion;
    }
  }, []);

  useEffect(() => {
    if (!sessionActive) {
      return undefined;
    }

    const refreshUi = () => {
      setLiveSignals({
        latest: Object.values(latestByTypeRef.current)
          .sort((a, b) => a.timestamp - b.timestamp),
        count: signalCountRef.current,
        at: Date.now(),
      });
    };

    const tickId = setInterval(
      () => runAssessmentTick(Date.now()),
      ASSESSMENT_TICK_MS
    );

    const uiId = setInterval(refreshUi, UI_REFRESH_MS);

    return () => {
      clearInterval(tickId);
      clearInterval(uiId);
      refreshUi();
    };
  }, [sessionActive, runAssessmentTick]);

  /*
   * Closing the tab mid-session: mark the session
   * INTERRUPTED instead of leaving it ACTIVE forever.
   */
  useEffect(() => {
    const onPageHide = () => {
      if (sessionActiveRef.current) {
        endExamSessionOnUnload(sessionIdRef.current);
      }
    };

    window.addEventListener("pagehide", onPageHide);

    return () =>
      window.removeEventListener("pagehide", onPageHide);
  }, []);

  /*
   * =======================================================
   * START SESSION
   * =======================================================
   */

  const resetLocalState = () => {
    setLiveSignals({ latest: [], count: 0 });
    setEvidence([]);
    setFusion(null);
    setFeatures(null);
    setRisk(null);

    signalCountRef.current = 0;
    latestByTypeRef.current = {};
    latestFusionRef.current = null;
    persistedFusionRef.current = null;

    featureEngineRef.current?.reset();
    persistenceRef.current?.reset();
  };

  const handleStartSession =
    useCallback(async () => {
      if (sessionActiveRef.current) {
        return;
      }

      if (
        !examIdRef.current ||
        !studentIdRef.current
      ) {
        setSessionStatus(
          "Backend is not ready yet."
        );

        return;
      }

      try {
        setSessionStatus(
          "Starting session..."
        );

        /*
         * Clear UI and engines from the previous session.
         */
        resetLocalState();

        /*
         * Create a NEW database session.
         */
        const response =
          await createExamSession(
            examIdRef.current,
            studentIdRef.current,
            selectedCondition
          );

        const newSessionId =
          response.session.id;

        setSessionId(
          newSessionId
        );

        sessionIdRef.current =
          newSessionId;

        persistenceRef.current?.setSessionId(
          newSessionId
        );

        persistenceRef.current?.start();

        /*
         * Fresh pipeline state, clock starting now.
         */
        pipelineRef.current?.start(Date.now());
        pipelineRef.current?.setCalibrated(
          calibratedRef.current
        );

        /*
         * Mark collection active.
         */
        sessionActiveRef.current =
          true;

        setSessionActive(true);

        setSessionNumber(
          (previous) =>
            previous + 1
        );

        setSessionStatus(
          "SESSION ACTIVE"
        );
      } catch (error) {
        console.error(
          "Failed to start GlassBox session:",
          error
        );

        setSessionStatus(
          "Failed to start session."
        );
      }
    }, [selectedCondition]);

  /*
   * =======================================================
   * END SESSION
   * =======================================================
   */

  const handleEndSession =
    useCallback(async () => {
      if (
        !sessionActiveRef.current ||
        !sessionId
      ) {
        return;
      }

      try {
        setSessionStatus(
          "Finalizing session..."
        );

        /*
         * Finalize WHILE the session is still active, so
         * the episodes still open now (gaze, head pose,
         * face absence, focus loss) and the final
         * assessment are persisted. The previous order
         * cleared the active flag first and lost them
         * (docs/results_2/PIPELINE_STATUS.md, Stage 7).
         */
        const now = Date.now();

        runAssessmentTick(
          now,
          pipelineRef.current?.finalize(now)
        );

        /*
         * Only now stop accepting new signals.
         */
        sessionActiveRef.current =
          false;

        setSessionActive(false);

        /*
         * The personal baseline belongs to this session only.
         */
        setBaselineResetToken((token) => token + 1);

        persistenceRef.current?.stop();

        await persistenceRef.current?.flush();

        await endExamSession(
          sessionId
        );

        setSessionStatus(
          "SESSION COMPLETED"
        );
      } catch (error) {
        console.error(
          "Failed to end GlassBox session:",
          error
        );

        setSessionStatus(
          "Session ended with a persistence warning."
        );
      }
    }, [sessionId, runAssessmentTick]);

  /*
   * =======================================================
   * NEW SESSION
   * =======================================================
   */

  const handleNewSession =
    useCallback(() => {
      /*
       * We don't need a browser refresh.
       *
       * The next Start Session will create
       * a completely new database session.
       */

      setSessionId(null);
      sessionIdRef.current = null;

      resetLocalState();

      setSessionStatus(
        "READY"
      );
    }, []);

  /*
   * =======================================================
   * CURRENT CONDITION
   * =======================================================
   */

  const currentCondition =
    CONDITIONS.find(
      (condition) =>
        condition.value ===
        selectedCondition
    );

  /*
   * =======================================================
   * VIEW MODEL (display only)
   * =======================================================
   */

  const { trackerState, calibrating, baseline } =
    visionUi;

  const header = buildHeader({
    backendStatus,
    tracker: trackerState,
    baseline,
    calibrating,
    sessionActive,
    sessionId,
    sessionStatus,
  });

  const { indicators, gaze, head } =
    buildIndicators({
      signals: liveSignals.latest,
      now: liveSignals.at,
      sessionActive,
      sessionId,
      baseline,
    });

  const stages = buildStages({
    tracker: trackerState,
    signalCount: liveSignals.count,
    evidence,
    features,
    risk,
    sessionActive,
  });

  const latestEvent =
    evidence.length > 0
      ? evidence[evidence.length - 1]
      : null;

  /*
   * =======================================================
   * UI
   * =======================================================
   */

  return (
    <div className="app">
      <Header
        state={header.state}
        detail={header.detail}
        items={header.items}
      />

      <PipelineStrip stages={stages} />

      <main className="grid">
        <div className="col">
          <Panel
            title="Live monitoring"
            aside={
              <span className="muted">
                {sessionActive
                  ? "Recording"
                  : "Preview only — not recording"}
              </span>
            }
          >
            <VisionModule
              onSignal={handleSignal}
              onUiState={setVisionUi}
              baselineResetToken={baselineResetToken}
            />
          </Panel>

          <ExplanationPanel
            sessionActive={sessionActive}
            latestEvent={latestEvent}
            eventCount={evidence.length}
            risk={risk}
          />
        </div>

        <div className="col">
          <SessionPanel
            conditions={CONDITIONS}
            selectedCondition={selectedCondition}
            onConditionChange={
              setSelectedCondition
            }
            currentCondition={currentCondition}
            sessionActive={sessionActive}
            sessionId={sessionId}
            sessionNumber={sessionNumber}
            sessionStatus={sessionStatus}
            backendReady={
              backendStatus ===
              "Backend connected"
            }
            baselineReady={!!baseline}
            signalCount={liveSignals.count}
            eventCount={evidence.length}
            onStart={handleStartSession}
            onEnd={handleEndSession}
            onNew={handleNewSession}
          />

          <IndicatorGrid
            indicators={indicators}
          />

          <BaselinePanel
            baseline={baseline}
            gaze={gaze}
            head={head}
          />
        </div>

        <div className="wide">
          <EventHistory
            evidence={evidence}
            sessionActive={sessionActive}
          />

          <TechnicalDetails
            evidence={evidence}
            fusion={fusion}
            features={features}
            risk={risk}
          />
        </div>
      </main>

      <footer className="footer">
        GlassBox research prototype · behavioural
        evidence stays on this machine. Risk scores
        come from a transparent, rule-based engine —
        not a trained predictive model — and support a
        human reviewer rather than making a decision.
      </footer>
    </div>
  );
}
