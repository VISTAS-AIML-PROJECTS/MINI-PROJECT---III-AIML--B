/*
 * Review queue: pure functions over data the API already stores
 * (GET /api/sessions, GET /api/sessions/:id). Nothing here scores behaviour;
 * it orders sessions for a person to review and summarises stored evidence.
 */

export const CHANNEL_ORDER = Object.freeze([
  "headPoseDeviation",
  "faceAbsence",
  "gazeDeviation",
  "focusLoss",
]);

export const CHANNEL_NAMES = Object.freeze({
  headPoseDeviation: "Head-pose deviation",
  faceAbsence: "Face absence",
  gazeDeviation: "Gaze deviation",
  focusLoss: "Window focus loss",
  multiSignalFusion: "Multi-signal fusion (v1)",
});

/* PENDING | CLEARED | FOLLOW_UP | IN_PROGRESS (a running session cannot be reviewed yet). */
export function reviewStatus(session) {
  if (session?.status === "ACTIVE") return "IN_PROGRESS";
  if (session?.review_decision === "CLEARED") return "CLEARED";
  if (session?.review_decision === "FOLLOW_UP") return "FOLLOW_UP";
  return "PENDING";
}

export const REVIEW_STATUS_TEXT = Object.freeze({
  PENDING: "Pending",
  CLEARED: "Reviewed — cleared",
  FOLLOW_UP: "Flagged for follow-up",
  IN_PROGRESS: "In progress",
});

const peakOf = (s) => {
  const v = Number(s?.peak_risk);
  return s?.peak_risk === null || s?.peak_risk === undefined || !Number.isFinite(v) ? null : v;
};

/* Highest peak risk first; sessions without any risk row last; ties by newest id. */
export function sortForReview(sessions) {
  return [...(sessions ?? [])].sort((a, b) => {
    const pa = peakOf(a);
    const pb = peakOf(b);
    if (pa === null && pb !== null) return 1;
    if (pb === null && pa !== null) return -1;
    if (pa !== pb) return pb - pa;
    return Number(b.id) - Number(a.id);
  });
}

const sameLocalDay = (iso, now) => {
  if (!iso) return false;
  const d = new Date(iso);
  return (
    !Number.isNaN(d.getTime()) &&
    d.getFullYear() === now.getFullYear() &&
    d.getMonth() === now.getMonth() &&
    d.getDate() === now.getDate()
  );
};

export function queueStats(sessions, now = new Date()) {
  const list = sessions ?? [];
  return {
    total: list.length,
    sessionsToday: list.filter((s) => sameLocalDay(s.started_at, now)).length,
    pending: list.filter((s) => reviewStatus(s) === "PENDING").length,
    flaggedHigh: list.filter((s) => (peakOf(s) ?? -1) >= 60).length,
    reviewedToday: list.filter((s) => s.review_decision && sameLocalDay(s.reviewed_at, now)).length,
  };
}

/*
 * The stored assessment at the session's peak score and its per-channel
 * evidence (0-1). v2 rows carry details.channels; older v1 rows only have
 * their own components, which are labelled as such.
 */
export function peakBreakdown(risk) {
  const rows = (risk ?? []).filter((r) => Number.isFinite(Number(r.score)));
  if (!rows.length) return null;

  let peak = rows[0];
  for (const r of rows) if (Number(r.score) > Number(peak.score)) peak = r;

  const channels = peak.details?.channels;
  let kind;
  let items;

  if (channels && typeof channels === "object") {
    kind = "v2";
    items = CHANNEL_ORDER.filter((k) => channels[k]).map((k) => ({
      key: k,
      label: CHANNEL_NAMES[k],
      value: clamp01(Number(channels[k].score)),
    }));
  } else if (peak.components && typeof peak.components === "object") {
    kind = "v1";
    items = Object.entries(peak.components).map(([k, v]) => ({
      key: k,
      label: CHANNEL_NAMES[k] ?? k,
      value: clamp01(Number(v)),
    }));
  } else {
    kind = "none";
    items = [];
  }

  return {
    score: Number(peak.score),
    level: peak.level ?? null,
    timestamp: Number(peak.timestamp),
    state: peak.state ?? null,
    kind,
    items,
  };
}

/*
 * Evidence episodes laid out on the session's time axis, as percentages.
 * An episode's stored timestamp is when it ENDED (src/evidence/evidenceEngine.js),
 * so it started duration_ms earlier.
 */
export function evidenceTimeline(evidence, startMs, endMs) {
  const span = Number(endMs) - Number(startMs);
  if (!Number.isFinite(span) || span <= 0) return [];

  return (evidence ?? [])
    .map((e) => {
      const end = Number(e.timestamp);
      const duration = Math.max(0, Number(e.duration_ms) || 0);
      if (!Number.isFinite(end)) return null;
      const start = end - duration;
      const left = clamp01((start - startMs) / span);
      const right = clamp01((end - startMs) / span);
      return {
        id: e.id,
        type: e.type,
        startOffsetMs: Math.max(0, start - startMs),
        durationMs: duration,
        strength: Number.isFinite(Number(e.strength)) ? Number(e.strength) : null,
        leftPct: 100 * left,
        widthPct: Math.max(0.6, 100 * (right - left)),
      };
    })
    .filter(Boolean);
}

/* Session time span from what is stored: start time, end time, or the last stored row. */
export function sessionSpan(session, risk, evidence, signals) {
  const start = new Date(session?.started_at).getTime();
  const stored = [
    ...(risk ?? []).map((r) => Number(r.timestamp)),
    ...(evidence ?? []).map((e) => Number(e.timestamp)),
    ...(signals ?? []).map((s) => Number(s.timestamp)),
  ].filter(Number.isFinite);
  const ended = session?.ended_at ? new Date(session.ended_at).getTime() : NaN;
  const end = Number.isFinite(ended) ? ended : stored.length ? Math.max(...stored) : NaN;
  return { start, end };
}

function clamp01(v) {
  return Number.isFinite(v) ? Math.min(Math.max(v, 0), 1) : 0;
}
