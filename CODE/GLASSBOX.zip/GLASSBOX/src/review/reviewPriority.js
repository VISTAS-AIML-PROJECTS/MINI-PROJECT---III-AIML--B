/*
 * Review priority for a finished session: which 10-s segments should a human
 * reviewer look at first?
 *
 * Score per segment = the largest head-pose deviation (degrees from the
 * student's own calibrated baseline, any axis) among the stored
 * HEAD_POSE_DEVIATION samples in that segment (~1 per second, the persisted
 * rate). This is the scorer that blind, nested model selection preferred on
 * OEP (docs/results_2/INTEGRATION_PLAN.md: chosen in 20/24 folds, held-out
 * AUROC 0.602 [0.566, 0.645]; at the app's 1-Hz rate 0.594 [0.556, 0.643],
 * s14). That is modest, so it ORDERS review; it is not evidence of misconduct
 * and it does not change the risk score.
 *
 * Pure function; research/tests/review_priority.test.mjs checks it reproduces
 * s14's head_max_1hz on stored OEP windows.
 */
const AXES = ["yaw", "pitch", "roll"];

export function segmentHeadDeviation(signals, { startMs, windowMs = 10000 } = {}) {
  const samples = (signals ?? []).filter(
    (s) => s?.type === "HEAD_POSE_DEVIATION" && Number.isFinite(Number(s.timestamp))
  );

  if (samples.length === 0) {
    return [];
  }

  const origin = Number.isFinite(startMs)
    ? startMs
    : Math.min(...samples.map((s) => Number(s.timestamp)));

  const segments = new Map();

  for (const s of samples) {
    const value = s.value ?? {};
    let maxDeg = -Infinity;
    let axis = null;

    for (const a of AXES) {
      const v = Math.abs(Number(value[a]));

      if (Number.isFinite(v) && v > maxDeg) {
        maxDeg = v;
        axis = a;
      }
    }

    if (!Number.isFinite(maxDeg)) {
      continue;
    }

    const index = Math.floor((Number(s.timestamp) - origin) / windowMs);
    const seg = segments.get(index);

    if (!seg || maxDeg > seg.maxDeg) {
      segments.set(index, {
        index,
        start: origin + index * windowMs,
        end: origin + (index + 1) * windowMs,
        maxDeg,
        axis,
        samples: (seg?.samples ?? 0) + 1,
      });
    } else {
      seg.samples += 1;
    }
  }

  return [...segments.values()].sort((a, b) => a.index - b.index);
}

/*
 * The top `share` of segments by deviation (default: one third, the review
 * budget used throughout the OEP evaluation), highest first.
 */
export function reviewFirst(segments, share = 1 / 3) {
  const n = Math.ceil(segments.length * share);

  return [...segments]
    .sort((a, b) => b.maxDeg - a.maxDeg || a.index - b.index)
    .slice(0, n);
}
