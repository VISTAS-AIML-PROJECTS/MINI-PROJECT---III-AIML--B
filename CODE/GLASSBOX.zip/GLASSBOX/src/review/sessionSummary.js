/*
 * Session summary for review, computed only from stored risk rows
 * (GET /api/sessions/:id). Works for v2 rows (state/reliability present)
 * and for older v1 rows (state is null -> reported as "not recorded").
 */
export function summarizeRisk(risk) {
  const rows = (risk ?? []).filter((r) => Number.isFinite(Number(r.score)));

  if (rows.length === 0) {
    return null;
  }

  const scores = rows.map((r) => Number(r.score));
  const v2 = rows.filter((r) => r.state);
  const share = (pred) => (v2.length ? v2.filter(pred).length / v2.length : null);

  // Contiguous runs of a given state, as [start, end] timestamps.
  const runs = (state) => {
    const out = [];
    let open = null;

    for (const r of v2) {
      if (r.state === state) {
        open = open ? [open[0], r.timestamp] : [r.timestamp, r.timestamp];
      } else if (open) {
        out.push(open);
        open = null;
      }
    }

    if (open) out.push(open);

    return out;
  };

  const last = rows[rows.length - 1];
  const reliabilities = v2
    .map((r) => Number(r.reliability))
    .filter(Number.isFinite);

  return {
    rows: rows.length,
    engineVersion: last.engine_version ?? null,
    peak: Math.max(...scores),
    peakAt: rows[scores.indexOf(Math.max(...scores))].timestamp,
    final: Number(last.score),
    finalLevel: last.level ?? null,
    finalState: last.state ?? null,
    meanReliability: reliabilities.length
      ? reliabilities.reduce((a, b) => a + b, 0) / reliabilities.length
      : null,
    shareOk: share((r) => r.state === "OK"),
    shareDegraded: share((r) => r.state === "DEGRADED"),
    shareInsufficient: share((r) => r.state === "INSUFFICIENT_EVIDENCE"),
    shareMediumOrHigh: share((r) => r.level === "MEDIUM" || r.level === "HIGH"),
    insufficientRuns: runs("INSUFFICIENT_EVIDENCE"),
    degradedRuns: runs("DEGRADED"),
  };
}
