# GlassBox

An explainable, rule-based exam-monitoring **research prototype**. Webcam sensing (MediaPipe FaceLandmarker, running in the browser) and browser-focus events become gated evidence episodes. A transparent assessment engine summarises them as a 0–100 **review-priority score** with plain-language reasons, for a human reviewer to look at. Each session is scored independently.

> **Honest status.** GlassBox does **not** have a demonstrated ability to detect cheating. On the one suitable public dataset (OEP, 24 subjects, acted and proctor-induced cheating, webcam only) the rule engine and every learned model tested were near chance (window AUROC about 0.52–0.56, confidence intervals including 0.5). The score is **not a probability** and is never a verdict; only a person can judge a session. What *has* been validated are components: head pose against sensor ground truth (error 0.6–1.3°), a gaze-angle estimator on on-screen gaze, and face-detection reliability on still photos. Limitations and negative results: `docs/final/EVIDENCE_AND_LIMITATIONS.md` and `docs/paper.md`.

## Features
| Page (hash route) | What it does |
|---|---|
| `#/` Home | Overview of the pipeline and the research status. |
| `#/monitor` Monitor | Live webcam preview, 33-second personal calibration (full-screen workspace, **Cancel** button or **Esc**), session start/stop, live indicators, explanation panel and event history. |
| `#/sessions` Session history | All recorded sessions with peak risk and final state. |
| `#/session/<id>` Session details | Risk timeline, evidence events, recorded signals, observation quality and "segments to review first". |
| `#/review` Review queue | Sessions ordered by peak risk, the stored evidence of the selected session, and an append-only human decision (cleared / follow-up / note). |

How it works: webcam frames → MediaPipe landmarks (in the browser; video never leaves the browser) → gaze, head-pose and face-presence signals measured against a **personal baseline** from the 33 s calibration → gated evidence episodes → assessment engine v2.1 (fixed, documented rules; no machine-learned cheating classifier is deployed) → score, level (LOW / MEDIUM / HIGH), state and reasons → local SQLite database. The only learned component is a small ridge regression that estimates horizontal gaze angle (`research/models/linear_gaze_v1.json`). The original v1 engine is kept (`src/risk/`) for comparison only. Details: `docs/final/ARCHITECTURE.md`, `docs/final/RISK_SCORE_SPEC.md`.

## Prerequisites
* **Node.js 22 or newer** (developed and tested with Node 24.19 and npm 11) and npm.
* A **webcam** and a current Chrome or Edge (camera access works on `http://localhost`).
* Windows, macOS or Linux (x64 or arm64). `better-sqlite3` ships ready-made binaries for these; the included `.npmrc` (`ignore-scripts=true`) stops npm from trying to compile it, so no C++ build tools are needed.
* Python is **not** needed to run the application. It is only needed to reproduce the offline research (see below).

## Install and run
```bash
npm install
npm run setup:offline      # optional: copies the MediaPipe WASM runtime into public/mediapipe/ so the app works without internet
```

Open two terminals in the project folder.

**Terminal 1 – backend** (Express + SQLite, port **5000**):
```bash
node server/server.js          # or: npm run server
```
Expected output: `GlassBox database connected.` and `GlassBox server running on http://127.0.0.1:5000`.

**Terminal 2 – frontend** (Vite, port **5173**):
```bash
npm run dev
```
Open **http://localhost:5173/** (use `localhost` or `127.0.0.1`). Allow camera access when asked.

### Quick demo
1. Open **Monitor**, wait for "Camera live", click **Start calibration** and follow the dot with your eyes for 33 seconds (Esc cancels).
2. Click **Start session**, look away from the screen a few times, switch to another tab once, then **End session**.
3. Open **Sessions** for the stored timeline, and **Review queue** to record a review decision.

### Ports, data and configuration
* The API address `http://localhost:5000/api` is fixed in the front end (`src/api/api.js`, `src/api/glassboxApi.js`, `src/pages/useApi.js`), so keep the backend on port 5000.
* The backend listens on `127.0.0.1` only and accepts browser requests only from `localhost`/`127.0.0.1` on ports 5173 and 4173. Override with `GLASSBOX_HOST` and `GLASSBOX_ALLOWED_ORIGINS` (comma-separated origins).
* The database is created automatically as `glassbox.db` in the project folder on first start (git-ignored). Use `GLASSBOX_DB_PATH=/path/to/file.db node server/server.js` to use a different file, for example a throw-away one for testing. Delete the file to start empty.
* All data stays on your machine. The app stores a placeholder "Data Collector" student entry. There is **no authentication**.

## Verify the installation
```bash
npm run lint
npm run build
npm test            # a few research checks are skipped when their data is not present
```
`npm test` uses temporary databases only and never touches `glassbox.db`. `node research/final/e2e_headless.mjs` runs a headless end-to-end check against a real server (needs port 5000 free).

## Troubleshooting
| Problem | Fix |
|---|---|
| "Backend not reachable" on Sessions/Review queue | Start `node server/server.js` and reload. |
| Port 5000 or 5173 already in use | Stop the other process. The backend port is fixed; Vite will pick the next port, but the backend then rejects that origin unless you set `GLASSBOX_ALLOWED_ORIGINS`. |
| Monitor stays on "Loading MediaPipe…" | Known intermittent issue in development mode (React StrictMode starts the camera twice). Reload the page; a production build does not double-start. |
| "Camera unavailable" | Allow camera access for localhost, close other apps using the camera, then reload. |
| MediaPipe files cannot load offline | Run `npm run setup:offline` once (or connect to the internet; the app falls back to Google's CDN). |
| Calibration fails ("quality insufficient") | Face the camera in good light with your whole face visible, then retry. |
| `better-sqlite3` install error (`node-gyp`, Visual Studio) | Make sure the `.npmrc` file from this repository is present (it contains `ignore-scripts=true`), or run `npm install --ignore-scripts`. |

## Repository layout
```
src/            React front end: pages, components, vision (MediaPipe), evidence, assessment (v2.1), risk (v1), review
server/         Express API and SQLite schema (server.js, database.js)
public/         Icons and the MediaPipe face-landmarker model (public/mediapipe/)
scripts/        setup-offline.mjs
research/       Offline experiments, results and tests (research/tests is run by npm test)
docs/           Final report and technical documentation (see below)
```

## Documentation
* `docs/complete_report/GLASSBOX_COMPLETE_REPORT.pdf` (and `.docx`) – the full project report.
* `docs/final/` – `ARCHITECTURE.md`, `RISK_SCORE_SPEC.md` (the score, with equations), `EVIDENCE_AND_LIMITATIONS.md`, `DEMO_GUIDE.md`, `F02_PREREGISTRATION.md`, `REVIEW_QUEUE_NOTES.md`.
* `docs/METHODOLOGY.md`, `docs/paper.md` – earlier methodology and draft paper, written for the original (v1) engine; the current engine is specified in `docs/final/RISK_SCORE_SPEC.md`.
* `docs/results_2/` – the model-comparison study (logistic regression, random forest, gradient boosting, nested selection): reports, figures and summary files. Per-window tables derived from the OEP recordings are deliberately not included.
* `docs/DATASETS.md`, `docs/OEP_LICENCE_STATUS.md`, `docs/PILOT_PROTOCOL.md`, `docs/WEBCAM_SMOKE_TEST.md`.

## Reproducing the offline research
Not needed to run GlassBox. Python 3.13 and `pip install -r research/requirements.txt`; the experiments need datasets that are **not** distributed here and must be obtained from their owners under their terms (`docs/DATASETS.md`): MPIIFaceGaze, UPNA Head Pose and FairFace (CC BY-NC-SA 4.0 / CC BY 4.0, non-commercial research use, cite the original papers) and OEP (no licence stated; **permission to publish OEP-derived results is unconfirmed**, see `docs/OEP_LICENCE_STATUS.md`). Stored aggregate results are in `research/results/` and `research/final/results/`.

## Limitations
No validation on real examination sessions or real examinees; OEP is acted behaviour with undocumented annotation types and no browser events; the score and its thresholds are design choices, not fitted values; face detection is less reliable for some groups and in low light; the demo has no authentication; live-camera behaviour has been checked only by a developer on one machine.
