# Physical-webcam smoke test (2026-10-21) – observed outcomes only

**What this is:** a technical smoke test of the prototype with one person (the project owner) and the laptop's physical camera (HP True Vision HD Camera, 640×480). It is **not** a participant study and says nothing about cheating-detection accuracy. Chrome ran in a visible window; the person followed on-screen cue banners injected by the test script (`live_guided.mjs`, kept outside the repository). The scratch database was used, so `glassbox.db` was untouched. No screenshots or video were saved.

## Run 1 – camera covered (unintended)
The camera was physically covered. The camera opened and streamed (640×480, mean brightness 33/255; a single in-memory frame found no face). Calibration then **hung indefinitely with no message**, because the calibration clock only advanced on frames with a detected face. *Fix made:* the clock now also advances on face-less frames, so calibration fails cleanly after 33 s ("Retry calibration"); re-run with the covered camera: `calibration FAILED` as designed.

## Run 2 – person in front of the camera, guided cues (session 8 in the scratch DB)
| Item | Observed |
|---|---|
| Camera permission, stream, face detection | worked (calibration completed) |
| Calibration | COMPLETE in about 33 s, "Personal baseline established" |
| Session persistence | session COMPLETED; 115 signals, 3 evidence rows, 606 feature rows, 662 risk rows |
| First 16 s of the session (no cue) | no events; risk 0 |
| Cue `EYES_LEFT` (6 s, eyes only) | **no event**, risk 0 |
| Cue `HEAD_RIGHT` (6 s) | a gaze-deviation episode (strength 0.71); **no head-pose episode**; max risk 7 |
| Cue `LOOK_DOWN` (6 s) | **no event** (the system has no validated vertical-gaze cue; see paper §4.2) |
| Cue `TAB_SWITCH` (about 6 s, automated) | `FOCUS_LOST`, `TAB_HIDDEN`, `TAB_VISIBLE`, `FOCUS_GAINED` recorded; focus-loss episode (strength 1.0); max risk 15 |
| Cue `LEAVE_FRAME` (5 s) | 46 `FACE_ABSENT` signals; face-absence episode (strength 0.66); max risk 32 (just above the MEDIUM boundary at 30) |
| Final risk | 22 / LOW |

Interpretation (not a validation): the face-absence path behaved as designed, and browser-focus events were recorded here but not consistently in Run 3 (below); the gaze gate (z >= 3, about 27° of horizontal gaze change) is conservative, so a 6-s eyes-only glance and looking down were not flagged; the head turn registered as gaze rather than head pose. One person, one session, hand-timed cues.

## Bugs this test exposed (fixed afterwards, committed)
1. Calibration stalled forever without a face (above).
2. **Raw gaze and head-pose samples were almost never persisted:** the persistence throttle used one shared clock for all sampled signal types, and `FACE_QUALITY` (emitted first each frame) won every interval. Run 2 therefore stored no `GAZE_DEVIATION`/`HEAD_POSE_DEVIATION` rows, and the per-cue analysis above had to rely on evidence episodes. The throttle is now per signal type; a fake-camera re-run stored 58 gaze and 58 head-pose samples in one 70-s session.
3. A harmless-but-alarming `AbortError` ("The play() request was interrupted by a new load request") was logged as an initialization error during React's dev-time double mount. `AbortError` is now treated as non-fatal; real camera errors still surface.

## Run 3 – final guided run after the fixes (2026-10-21 16:22, fresh scratch DB, session 1)
Same set-up as Run 2 (visible Chrome window, physical camera, person following on-screen cue banners; no screenshots saved). All figures below are observed.

| Item | Observed |
|---|---|
| Calibration | COMPLETE in about 33 s |
| Console / page errors | none (the `AbortError` and calibration-stall issues did not recur) |
| Session persistence | session COMPLETED; 202 signals, 5 evidence rows, 679 feature rows, 679 risk rows |
| Persisted raw samples | 59 `GAZE_DEVIATION` and 59 `HEAD_POSE_DEVIATION` (about 1 per second) plus 21 `FACE_ABSENT` - **the sample-saving fix works** |
| Baseline (first 9 s, no cue) | max gaze z 2.9 and max head deviation 3.1° (both below the gates z 3 and 8°); no events |
| `EYES_LEFT` | max gaze z 2.1, head 2.5°; no episode; max risk 6 |
| `HEAD_RIGHT` | max gaze z 4.2 (above the gate), head deviation only 2.5°; a gaze-deviation episode (strength 0.67); max risk 10 |
| `LOOK_DOWN` | max gaze z 1.3, head deviation 7.2° (just below the 8° gate); no episode; max risk 0 |
| `TAB_SWITCH` | `TAB_HIDDEN`, `TAB_VISIBLE` and two `FOCUS_GAINED` recorded, **but no `FOCUS_LOST`**, so no focus-loss episode and risk stayed 0 (Run 2 did record a focus-loss episode for the same automated action; the difference is unexplained and the browser-focus path is therefore not shown to be reliable) |
| `LEAVE_FRAME` | 21 `FACE_ABSENT` signals; face-absence episodes (0.24, 0.01) and a head-pose episode (strength 0.58; head deviation 24.6° while leaving); max risk 19 |
| Final session risk | 15 / LOW |

Reading: the sensing, calibration, persistence and risk path work end to end and the gates behave as designed; the gates are conservative (a 6-s eyes-only glance and looking down were not flagged), the head turn was recorded as gaze, and the tab-switch behaviour was inconsistent between runs. One person, one session each, hand-timed cues, so none of this is a performance estimate.

## Run 4 – browser-focus fix, live check through the new UI (2026-10-21 ~17:20, headless Chrome, physical camera, session 3 in the scratch DB)
*Cause found:* `FOCUS_LOST` was emitted only from the window `blur` event, which does not always fire when the active tab is switched programmatically (Run 3 recorded `TAB_HIDDEN`/`TAB_VISIBLE`/`FOCUS_GAINED` but no `FOCUS_LOST`). *Fix:* a hidden tab is now also treated as a focus loss, de-duplicated with blur (`src/modules/browser/browserSignalCollector.js`), with three unit tests (`research/tests/browser_signals.test.mjs`).
*Observed live:* the automated tab switch (about 6 s) produced `TAB_HIDDEN`, `FOCUS_LOST`, `TAB_VISIBLE`, `FOCUS_GAINED` (one each) and a **focus-loss episode of 6.1 s, strength 1.0**; the session saved and appears in the session-history and session-detail pages. This confirms the fix for that automation path in one Chrome session. It does **not** show reliability across browsers, window managers, or real users alt-tabbing, which remain untested.

## Still pending (needs a person, not simulated)
- Different people, glasses, lighting, camera positions, laptops and browsers (Edge, Firefox, Safari).
- A consent-based participant study (`docs/PILOT_PROTOCOL.md`).
- Browser-focus behaviour with real alt-tab / window switching and other browsers (Edge, Firefox, Safari).
