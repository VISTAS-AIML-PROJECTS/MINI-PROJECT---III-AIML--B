# GlassBox – Methodology (as implemented on branch `ai-completion`)

This document is derived from the source code, not from a prior design document (none existed in the
repository). Every equation below corresponds to a specific file; file references are given so a reader can
check it. Parameters marked **[unvalidated]** are design choices that have *not* been tuned or validated
against labelled proctoring data.

## 1. Pipeline

```
webcam ──MediaPipe FaceLandmarker──► landmarks L (478×3), transform matrix M
browser events (focus/visibility) ───────────────┐
                                                  ▼
   vision signals: FACE_PRESENT/ABSENT, FACE_QUALITY, GAZE_DEVIATION (z), HEAD_POSE_DEVIATION (deg)
                                                  │
              ┌───────────────────────────────────┴──────────────┐
              ▼                                                  ▼
       EvidenceEngine (gated episodes)                     FusionEngine (5 s window)
              └──────────────► RiskEngine (decayed, weighted) ◄──┘
                                       │
                          score ∈ [0,100], level LOW/MEDIUM/HIGH + reasons
```
Persistence (SQLite) and the dashboard are downstream of the signals and do not affect scoring.

## 2. Sensing (`src/modules/vision/gazeMath.js`, `headPoseMath.js`)

**Iris-relative gaze.** For each eye, with iris centre *c* and eye-corner / eyelid reference points *a, b*:

  ρ(c; a, b) = clip₀¹ ( (c − a)·(b − a) / ‖b − a‖² )

Horizontal: right eye uses (33→133), left eye (362→263); vertical uses upper/lower lid landmarks
(159/145 and 386/374). The gaze feature is the mean over both eyes: **g = (g_x, g_y)**.
This measures the iris position *within the eye socket* (eye-in-head), not the gaze direction in camera
or screen coordinates. It is sensitive to blinks (the vertical reference collapses when the lids close).

**Head pose.** From the 3×3 rotation block *R* of MediaPipe's facial transformation matrix
(column-major, uniform scale cancels inside atan2), with R = R_z(roll) R_y(yaw) R_x(pitch):

  yaw = atan2(−R₂₀, √(R₀₀² + R₁₀²)),  pitch = atan2(R₂₁, R₂₂),  roll = atan2(R₁₀, R₀₀).

*Correction made during this work:* the original code used `atan2(R₂₀,·)`, `atan2(−R₂₁, R₂₂)` and
`atan2(R₀₁, R₁₁)`. Tested on known rotations (`research/tests/test_headpose.py`) yaw and pitch were
correct up to a global sign (harmless, because only |Δ| is used) but roll was coupled to yaw/pitch
(mean error 6.9°). The corrected form recovers all three exactly.

## 3. Personal calibration (`visionTracker.js`, `finishCalibration`)

A 33 s protocol (8 s natural, 18 s nine-point guided, 7 s natural) collects samples with face-quality ≥ 0.35.
Calibration is accepted if ≥ 100 samples and mean quality ≥ 0.45. The baseline is

  μ_x, μ_y = mean of g_x, g_y;  σ_x, σ_y = std (floored at 0.001);
  head baseline μ_yaw/pitch/roll, σ (floored at 0.1°).

Note the guided phase deliberately visits screen targets, so σ describes the user's *on-screen* gaze range,
not only fixation jitter. Face quality is the landmark bounding-box area × 10 clipped to [0,1] – a size proxy,
not an image-quality measure.

**Per-frame signals.**

  z_x = |g_x − μ_x| / σ_x,  z_y = |g_y − μ_y| / σ_y (logged in metadata only),  **GAZE_DEVIATION = z_h = |h_hat − μ_h| / σ_h**, where h_hat = b + w·[g_x, g_y, ρ_R,x, ρ_L,x, ρ_R,y, ρ_L,y, yaw, pitch, roll] is a ridge estimate of the camera-frame horizontal gaze angle in degrees (`src/modules/vision/linearGaze.js`, coefficients in `research/models/linear_gaze_v1.json`; μ_h, σ_h from the calibration frames, σ floored at 0.5°). The legacy signal z_x is logged in metadata (`GAZE_ESTIMATOR` in `visionTracker.js` switches back). See `docs/paper.md` §4.8 for the evidence (LOSO AUROC +0.06 over z_x in both protocols; surrogate task only).

*Change made during this work:* the original signal was √(z_x² + z_y²). On MPIIFaceGaze the vertical iris term had no usable
signal (AUROC 0.50–0.52 for vertical gaze deviation) and lowered total-deviation AUROC from 0.774 (horizontal only) to 0.693 (combined),
consistently in two disjoint subject halves (`research/results/exp07_*.csv`). Consequence: the system has **no validated vertical-gaze cue**
(looking down is only reflected through head pitch, whose validity is unmeasured).
  **HEAD_POSE_DEVIATION = (|yaw − μ_yaw|, |pitch − μ_pitch|, |roll − μ_roll|)** in degrees.

## 4. Deviation gate (`src/evidence/deviation.js`) – added in this work

The baseline code treated *every* frame as deviation evidence (no threshold). Consequently an episode lasted as
long as the face was visible, its persistence and frequency terms saturated within 5 s, and brief look-aways were
averaged into minutes of normal behaviour (`research/tests/engine_replay.mjs`, synthetic: legacy engines could not separate a
calm user from one with five 4 s look-aways – mean peak risk 7.5 vs 10.0; fixed engines 2.5 vs 38.8). A frame is now *deviating* only if

  gaze:  z_h ≥ τ_g = 3  (two-sided ≈ 0.27 % exceedance if calibration were Gaussian; on MPIIFaceGaze ≈ 24° of horizontal gaze change,
         a linear approximation – `exp06_z_to_degrees.json`) **[unvalidated for true off-screen gaze]**
  head:  ∃ axis i: |Δ_i| ≥ max(8°, 3σ_i) **[unvalidated]**

with sample strengths s_g = clip(z_h / 9), s_h = max_i clip(|Δ_i| / S_i), S = (45°, 30°, 30°) for (yaw, pitch, roll).
Episodes shorter than 500 ms or with < 3 deviating samples are discarded (blink / noise guard); gaps > 1.5 s end an episode.

## 5. Evidence episodes (`evidenceEngine.js`)

  strength(gaze/head episode) = 0.5·mean(s) + 0.25·min(duration/5 s, 1) + 0.25·min(n/10, 1)
  strength(focus-loss / face-absence episode) = min(duration / 5 s, 1)

## 6. Fusion (`fusionEngine.js`)

Over a 5 s window, with components c = the latest *gated* sample strengths (s_g, s_h) and 0/1 for focus-loss / face-absence:

  base = 0.3 c_gaze + 0.3 c_head + 0.2 c_focus + 0.2 c_face
  bonus = min(0.1·|concurrent pairs|, 0.3);  fusion = min(base + bonus, 1);  confidence = mean confidence of active signals.

Known limitation: the latest focus-loss / face-absence signal stays "active" for the 5 s window even after
focus is regained, because no FOCUS_GAINED / FACE_PRESENT clearing is implemented.

## 7. Risk (`riskEngine.js`)

  E_type(t) = min( (1/3) Σ_k strength_k · exp(−(t − t_k)/τ_d), 1 ),  τ_d = 120 s **[unvalidated]**
  risk = 100 · clip( 0.2 E_focus + 0.2 E_face + 0.2 E_gaze + 0.2 E_head + 0.2 · fusion · confidence )

LOW < 30 ≤ MEDIUM < 60 ≤ HIGH. Equal weights are placeholders ("later logistic regression will learn the weights").
The original code had no decay, so risk increased monotonically with exam length.

## 8. Evidence status of each component (see `docs/paper.md`)

| Component | Verified how | Status |
|---|---|---|
| Head-pose decomposition | 45 known rotations (exact) | math verified; accuracy on real faces **unvalidated** |
| Horizontal iris gaze z_x (legacy, logged) | MPIIFaceGaze, Spearman 0.83 with horizontal gaze angle | validated for on-screen gaze only |
| Linear gaze-angle estimator h_hat (**current GAZE_DEVIATION**) | LOSO on MPIIFaceGaze, +0.06 AUROC over z_x in both protocols; JS/sklearn parity test | validated on a surrogate task only; gate meaning in degrees untested with the app's calibration |
| Vertical iris gaze | MPIIFaceGaze, AUROC 0.50–0.52 | **removed** from the signal |
| Personal baseline | MPIIFaceGaze cross-session (+0.026 at K=100) and same-session (no gain at K≤30) | **mixed / unproven** |
| Deviation gate, episode minimums, decay | synthetic replay only | **unvalidated** thresholds |
| Fusion weights, risk weights, levels | none | **unvalidated** placeholders |
| FACE_ABSENT reliability | FairFace stills, group gaps and low-light interaction | disparities measured; real webcam fairness untested |
| End-to-end UI + persistence | headless Chrome with a fake camera | works; physical webcam not tested |

**Interpretation of the risk score.** The 0–100 score is a rule-based evidence summary. It is not a probability of cheating: on OEP the scores were near chance in discrimination (AUROC about 0.53) and a logistic model's probabilities were worse calibrated than a constant-prevalence predictor (`research/results/exp14_meta.json`). Present it only as "amount of recent flagged behaviour", never as a likelihood of misconduct.
