# GlassBox: Auditing a Personalised, Explainable Webcam-and-Browser Proctoring Pipeline

*Draft v0.7 – every number below is produced by a script in `research/` and stored in `research/results/` (a full `run_all.py` run exited 0 and regenerated the stored results byte-for-byte except where code was deliberately changed; see §6).
No result comes from labelled real-exam cheating data, and the draft makes no claim about cheating-detection accuracy (see §5).*

## Abstract

GlassBox is a transparent, rule-based proctoring prototype that fuses MediaPipe face-landmark signals (gaze, head pose, face presence) with browser focus events, using a per-user calibration baseline and an explainable risk score. We audited the prototype against public data.
(1) A code audit and synthetic replay found that the original evidence engine counted *every* frame as deviation evidence, so a calm user and a user with five 4-second look-aways were indistinguishable (mean peak risk 7.5 vs 10.0 of 100); after adding a deviation gate, minimum-duration episodes and risk decay they separate (2.5 vs 38.8).
(2) On MPIIFaceGaze (15 subjects, 37,595 usable frames) the horizontal iris signal tracks horizontal gaze angle (within-subject Spearman 0.83) but the vertical iris signal is uninformative (AUROC 0.50–0.52); removing it raised total-deviation AUROC from 0.693 to 0.774 (+0.080, 95 % CI 0.054–0.111; positive for 15/15 subjects and in two disjoint halves).
(3) Personalised calibration gave at most a small benefit: with a multi-day calibration set of 100 frames, +0.026 AUROC (0.009–0.045) over a leave-one-subject-out population baseline; with same-session calibration of 10–30 frames (the deployment-like setting we could test) it was *not* better (K = 30: −0.007, −0.026 to +0.014) and worse for K = 10. A learned regressor on the same features gained +0.079 over the population baseline with no calibration at all.
(4) On FairFace (10,954 images) MediaPipe's miss rate – which GlassBox turns into a FACE_ABSENT signal – differs by group, and the Black group degrades most under simulated low light (+3.2 to +4.8 points more misses than other groups; robust to Bonferroni correction).
(5) On a public proctoring-feature table, random k-fold inflates AUROC by 0.04–0.06 relative to a temporally blocked split, and several columns leak the label.
(6) A ridge gaze-angle estimator built from the nine MediaPipe features the app already computes beat the iris-ratio z-score under both calibration protocols (+0.062 [0.034, 0.093] cross-session, +0.059 [0.028, 0.093] same-session, leave-one-subject-out) and is now the app's default gaze signal, with the legacy signal logged for comparison; this is validated on a gaze-deviation surrogate task only. (7) On the full OEP dataset (24 subjects; annotated cheating intervals; acted and proctor-induced cheating; webcam only) the GlassBox engines and leave-one-subject-out learned models were near chance (window-level AUROC 0.52–0.53; primary comparison −0.009 [−0.099, 0.086]), so no learned classifier was integrated and no cheating-detection claim is made. A pre-specified set of improvements (temporal context, richer signals, inner-CV regularisation, forest and boosting models) did not change this (primary model minus engine +0.016 [−0.088, 0.121]; integration criterion not met). (8) Head pose matches sensor ground truth on UPNA (MAE 0.6–1.3°, r 0.98–1.00). Head-pose accuracy and true off-screen gaze could not be validated.

## 1. Introduction

Automated proctoring is contested on validity and fairness grounds. GlassBox takes a deliberately conservative design: it does not decide misconduct, it produces *evidence episodes* and an explainable risk level for a human reviewer. This paper asks narrow, testable questions about its components:

* **RQ1** Do its signals behave sensibly (calm vs. look-away) once wired into the evidence → risk chain?
* **RQ2** Does the MediaPipe iris/head-pose sensing carry the information the signals assume?
* **RQ3** Does per-user calibration beat a non-personalised baseline, and by how much?
* **RQ4** Is MediaPipe's face-presence reliability uniform across demographic groups?
* **RQ5** How much do common evaluation shortcuts (random splits, leaky columns) inflate reported accuracy on public proctoring data?

### 1.1 Related work
*Face landmarks and head pose.* GlassBox builds on MediaPipe's face-landmark model (Lugaresi et al., 2019, the framework; Kartynnik et al., 2019, the real-time 468-point face-mesh method behind the landmark network), whose iris landmarks and facial transformation matrix we use to derive gaze and head pose. We evaluate those derived quantities on public sensor- or annotation-grounded data: MPIIGaze/MPIIFaceGaze (Zhang et al., 2017; 2019) for gaze, and the UPNA Head Pose Database (Ariz et al., 2016) and I2Head (Martinikorena et al., 2018) for head pose.
*Automated proctoring.* The OEP dataset and system (Atoum et al., 2017) combine a monitor-mounted webcam with a wearable camera and audio; the dataset's own README documents those three streams, 24 subjects and annotated cheating intervals. Our evaluation uses only the webcam stream, which is a deliberately restricted setting and not a replication of the original system.
*Fairness of face analysis in proctoring.* Disparities in automated face analysis across demographic groups are well documented (Buolamwini and Gebru, 2018; FairFace, Kärkkäinen and Joo, 2021). Yoder-Himes et al. (2022) report that in one deployed proctoring product, darker-skinned and Black students were flagged for instructor review more often. Our face-detection results (§4.4) show a group-dependent miss rate and a larger low-light degradation for the Black group in FairFace stills; we did not test whether this reaches flag rates, and the two studies use different data and systems, so ours does not establish the mechanism behind theirs.
*What is new here.* This is an audit of a specific prototype: engine defects found by replay, component validation against ground truth (gaze, head pose, face detection), calibration protocols tested under cross- and same-session regimes, and a leave-one-subject-out test of whether the prototype's signals separate annotated OEP cheating intervals. We do not claim a new detection method.

## 2. System

See `docs/METHODOLOGY.md` for the equations tied to source files. In brief: MediaPipe FaceLandmarker (478 landmarks, transform matrix) → iris-relative gaze g = (g_x, g_y) and head pose (yaw, pitch, roll) → z-scores against a 33-s personal calibration baseline; GAZE_DEVIATION is the z-score of a linear horizontal gaze-angle estimate h_hat (§4.8; the legacy horizontal iris-ratio z_x is logged alongside) → gated deviation samples (§4.1) → episodes (strength = 0.5·mean sample strength + 0.25·duration term + 0.25·count term) → 5-s fusion with concurrence bonus → exponentially decayed weighted risk (equal weights 0.2, τ = 120 s) → LOW/MEDIUM/HIGH with reasons.

## 3. Data (details and verdicts: `docs/DATASETS.md`)

| Dataset | Use here | Size | Licence | Notes |
|---|---|---|---|---|
| Mendeley "Students suspicious behaviors detection" (doi:10.17632/39xs8th543.1) | Exp 01 leakage | 5,500 rows, 37 features | CC BY 4.0 | Simulated; **no subject IDs**; 1,620 missing values; 76 duplicate rows |
| MPIIFaceGaze (Zhang et al. 2017) | Exp 03–07 | 15 subjects, 37,667 images (37,595 with a MediaPipe face+iris) | CC BY-NC-SA 4.0 | Laptop use over 7–67 days per subject; gaze targets on screen only |
| FairFace validation (Kärkkäinen & Joo 2021), HF mirror | Exp 02 | 10,954 images, 2 crop variants | CC BY 4.0 | Race/gender/age labels; one face per image |
| OEP (Atoum et al.) | Exp 12 (primary), Exp 08 (per-subject signal AUROCs) | 24 subjects, 3.7 GB of webcam video + annotations used; 628,476 frames | **not stated by the authors** (permission to publish results unconfirmed) | See §4.6, §4.10 |
| UPNA Head Pose Database; I2Head users 01–02 | Exp 11, Exp 13 (head-pose validation) | 120 videos / 4,640 images | CC BY-NC-SA 4.0 (dataset pages) | See §4.9 |
| GlassBox's own database | audit only | 8 sessions, one person, self-declared labels | – | not evidence of performance |

SHA-256 hashes: `research/data_manifest.json`; `research/fetch_data.py` re-fetches and verifies (all 5 verified).

## 4. Experiments and results

### 4.1 Engine audit and fix (RQ1)
*Finding.* The vision tracker emits gaze/head samples on every frame and the evidence engine treated each as deviating; episodes lasted as long as a face was visible, persistence and frequency terms saturated after 5 s / 10 samples, and a 5-s glance was averaged into minutes of normal behaviour. The risk engine kept evidence forever, so risk could only increase with exam length. *Fix.* Shared gate (`src/evidence/deviation.js`): gaze z ≥ 3, head |Δ| ≥ max(8°, 3σ); ≥ 3 samples and ≥ 500 ms per episode; exponential decay τ = 120 s. *Test* (`research/tests/engine_replay.mjs`, 20 seeds × 180 s at 15 fps, synthetic Gaussian signals):

| | calm: peak risk, mean (range) | five 4-s look-aways: peak risk |
|---|---|---|
| Baseline commit 76ea544 | 7.5 (7–8) | 10.0 (10–10) |
| Fixed | 2.5 (2–3) | 38.8 (37–39) |

*Robustness to under-estimated calibration spread* (`engine_robustness.json`, same replay, fixed engines): if a calm user's natural variability is 1.5×, 2× or 3× the calibration SD, mean peak risk for the calm user rises to 23.1, 24.4 and 26.9 (vs 43.2, 42.6 and 31.9 for the look-away user). Calm users stay below the LOW/MEDIUM boundary (30) in this simulation, but the margin to a look-away user shrinks from ≈ 36 points to ≈ 5 points at 3×, so a calibration that under-states a user's natural spread (e.g. a short or unrepresentative calibration) would sharply degrade discrimination. This is synthetic and was not tested with real users.

This is a regression/sensitivity test, **not** validation; the thresholds (3, 8°, 3σ, 500 ms, 120 s) are unvalidated defaults. Separately, head pose extraction was tested on 45 known rotations: yaw/pitch were correct up to a global sign (harmless, only |Δ| is used) but roll had 6.9° mean error (coupled to yaw/pitch); it is corrected and now exact (`research/results/headpose_synthetic.txt`).

### 4.2 Sensing validity on MPIIFaceGaze (RQ2)
Using oracle gaze angles (target − face-centre, camera frame): horizontal iris position g_x correlates with the horizontal gaze angle (Spearman 0.82 pooled, 0.83 mean within-subject) and with eye-in-head horizontal angle (0.66). The vertical iris position g_y does not track vertical gaze (|ρ| ≤ 0.10). MediaPipe found a face+iris in 99.8 % of frames.
For total angular deviation, the previous combined z = √(z_x² + z_y²) gave AUROC 0.693 (own-SD baseline, K = 100) and z_x alone 0.774 (Δ = +0.080 [0.054, 0.111]); the gain is positive for all 15 subjects and in both subject halves (p00–p06: +0.076 [0.046, 0.110]; p07–p14: +0.085 [0.045, 0.133]; `exp07`). The decision to drop g_y followed exploratory analysis of the same subjects, hence the split-half check. The app now uses z_x only.
*Consequence:* the gaze signal cannot see looking down at a phone; head pitch is the only vertical cue and its validity is unmeasured (§5).

### 4.3 Personalised vs non-personalised calibration (RQ3)
Targets and positives: top 25 % of the oracle deviation from the subject's own mean gaze (horizontal ≥ 12.4°). Evaluation frames are identical across methods and calibration frames are never evaluated. CIs are subject-level bootstrap (15 subjects), paired for differences. *Disclosure:* the analysis was iterated once (a first version targeting total deviation showed all methods near AUROC 0.6; we then split by axis after exploratory correlations on the same data); no multiple-comparison correction is applied across the many rows below, so single intervals excluding 0 should be read as suggestive.

**(a) Cross-session calibration** (`exp04`): the calibration set is the subject's first K frames in file order, which is chronological and spans 2–12 *different days*; only 0.1–40 % of evaluation frames share a day with it. This is a stale baseline, unlike the app, which calibrates immediately before the exam.

| Horizontal deviation | within-subject AUROC | Δ vs population [95 % CI] |
|---|---|---|
| no baseline (iris-centred) | 0.805 | +0.003 [−0.001, 0.006] |
| population baseline (LOSO) | 0.803 | – |
| personal, K = 10 / 30 | 0.766 / 0.814 | −0.037 [−0.082, 0.005] / +0.012 [−0.014, 0.038] |
| personal, K = 100 | 0.829 | +0.026 [0.009, 0.045] |
| personal, K = 300 | 0.826 | +0.024 [0.009, 0.041] |
| learned (HistGB, 9 MediaPipe features), no calibration | 0.879 | +0.076 [0.042, 0.120] |
| learned + personal centring (K = 100) | 0.900 | +0.021 [0.011, 0.031] over learned without calibration |

**(b) Same-session calibration** (`exp04b`, 289 sessions of ≥ 50 frames; the first K frames of the *same* session calibrate, the rest from frame 30 on are evaluated):

| | within-subject AUROC | Δ vs population [95 % CI] |
|---|---|---|
| population baseline | 0.800 | – |
| personal, K = 10 / 20 / 30 | 0.736 / 0.776 / 0.793 | −0.064 [−0.092, −0.036] / −0.025 [−0.044, −0.003] / −0.007 [−0.026, 0.014] |
| learned, no calibration | 0.879 | +0.079 [0.045, 0.121] |
| learned + same-session centring (K = 30) | 0.885 | +0.006 [0.001, 0.010] over learned without calibration |

*Interpretation.* The rule-based personalised z-score was never reliably better than a population baseline in the setting we could test faithfully (same session, ≤ 30 sparse frames) and was worse with few frames. The +0.026 at K = 100 is from a multi-day calibration set, i.e. it estimates the subject's long-run mean better than any single session would; the app's 33-s calibration (≈ 100+ consecutive, highly autocorrelated frames) lies between these settings and could not be reproduced with MPIIFaceGaze's sparse frames. Where there is a gain, it comes from re-centring, not from the personal SD (a single-axis personal SD cannot change within-subject AUROC). Most of the available gain on this data is from the learned estimator, which also uses head pose and the eye-corner ratios (so that comparison mixes effects). MPIIFaceGaze has on-screen gaze only: this validates the sensing/normalisation stage, not off-screen detection.
*Operating point* (`exp06`): z_x ≥ 3 corresponds to ≈ 24° horizontal deviation (median calibration SD 0.040, 203°/unit, a linear approximation) – conservative: TPR 2–4 % for 12°+ on-screen deviations at FPR ≤ 0.1 %; z ≥ 2 (≈ 16°) gives TPR 20–25 % at FPR 0.4–1 %. Whether 3 is right for genuinely off-screen gaze could not be tested; the app's calibration includes a nine-point guided phase, so its SD differs from the natural-viewing SD used here.

### 4.4 MediaPipe reliability across groups (RQ4)
FaceLandmarker with the app's settings on FairFace validation, native and low-light (gamma 2.2 × 0.5) conditions. A miss is a false FACE_ABSENT. (A third "small face" condition collapses to ≈ 30 % on the 1.25-padded crops and is not interpretable.)

| 1.25-padding crop, detection rate | native | low light |
|---|---|---|
| overall | 91.8 % | 89.9 % |
| range over race groups | 89.3 % (Middle Eastern) – 95.1 % (Southeast Asian) | 87.7 % (Black) – 93.5 % (Southeast Asian) |
| female vs male | 93.0 vs 90.8 % | 91.4 vs 88.6 % |

(Tight 0.25-padding crops: 84.0 % native / 81.5 % low light; same ordering.) Adjusted logistic models (race + gender + age) are directionally consistent in both crop variants (native, ref. White: Southeast Asian OR 1.88–2.12, Indian 1.29–1.55; female OR 1.32–1.47; ages 3–9 OR 1.65–1.95): detection is lower for White and Middle-Eastern faces and for men and higher for young children. Under low light the Black group's detection fell 4.6–6.6 points (other groups 0.7–2.6), +3.2 to +4.8 points more than the rest; the Bonferroni-adjusted (×7) 95 % intervals are [2.4, 7.3] and [1.0, 5.2], still excluding 0.
*Setup details.* MediaPipe FaceLandmarker (`face_landmarker.task`, float16 v1; numFaces 1, detection/presence/tracking confidence 0.5, as in the app) was run in still-image mode (the app uses video mode, which can track across frames, so still-image miss rates are not frame-by-frame app miss rates). FairFace validation images are tightly cropped faces from web photos (two crop variants), one face each. The low-light condition applies gamma 2.2 and gain 0.5 to the pixels; it is a crude stand-in for real low light (no sensor noise or exposure change). Intervals are 95 % Wilson intervals; paired low-light comparisons use bootstrap intervals, Bonferroni-adjusted across the 7 race groups where stated.
Caveats: FairFace race labels are a perceived-category proxy and are **not** a measurement of skin tone, so we cannot say these gaps are caused by skin tone (they could reflect image sources, pose, accessories, age mix or crop framing); images differ in source quality, pose, accessories and expression; low light is synthetic darkening; webcam video, glasses and real exam rooms are not represented. The logistic-model p-values are not corrected for multiplicity. These are reliability disparities of one component measured on still photographs, not of the whole system, and they should not be generalised to real exam rooms, to webcam video, or to flag rates without testing there. The only deployed-system evidence we cite on flagging (Yoder-Himes et al., 2022) concerns a different product and data.

### 4.5 Evaluation pitfalls on a public proctoring-feature table (RQ5)
In the Mendeley table `phone_present = 1` occurs only for cheating rows (774 / 2,619), `face_present = 0` only for cheating (176), the head-pose category is "forward" for all non-cheating rows and 1,055 of the cheating rows, and missingness correlates with the label. There are no subject IDs, so even blocked splits cannot guarantee subject independence; rows are consecutive snapshots (mean adjacent-row |Δ face_x| 16.8 vs 63.0 for random pairs). Nearest-training-row distance (standardised strict features): median 0.133 under random 5-fold vs 0.202 under blocked 5-fold (90th percentile 0.360 vs 0.649), i.e. random folds place test rows markedly closer to training rows. Pooled out-of-fold AUROC (HistGB; block-bootstrap CI for blocked, 50-row purge):

| features | random | blocked [95 % CI] |
|---|---|---|
| all 37 columns | 1.000 | 0.997 [0.994, 0.999] |
| without phone/hand cues | 0.987 | 0.938 [0.917, 0.955] |
| face, head, gaze **incl. the dataset's scenario-aware gaze flags** (`gaze_on_script`, `gaze_direction`, `gazePoint`) | 0.979 | 0.935 [0.914, 0.953] |
| **strict**: face presence, head angles, pupil offset from eye point | 0.952 | 0.897 [0.871, 0.922] |
| strict, logistic regression | 0.718 | 0.626 [0.581, 0.674] |

The earlier label "GlassBox-compatible" for the third row was an overstatement: GlassBox cannot compute `gaze_on_script` (it has no notion of the script region); the strict set is the fair comparison. A temporally blocked error analysis of the strict-feature HistGB model (`exp10`, threshold 0.5) shows where it succeeds and fails: recall 99–100 % for head-turned or face-absent cheating rows, 72 % for rows whose only cue is off-script gaze, 46 % for rows whose cue is a visible phone (not in the strict features), 81 % for rows with no overt cue, and a false-positive rate of 12.8 % on non-cheating rows. An attempt to recover pseudo-subjects from face-geometry ratios for grouped CV failed (lag-1 autocorrelation 0.15–0.20; `exp10_pseudo_subject_attempt.json`). A hand-written rule (face absent ∨ gaze off-script ∨ head ≠ forward) scores AUROC 0.812, but it uses the same scenario-aware flags and was written after inspecting the data. Random splitting overstates AUROC by 0.044–0.055 for the realistic sets, and ≈ 1.0 depends on object cues GlassBox does not produce. Because the data are scripted and simulated with unknown subject structure, this is evidence about *evaluation practice*, not real-world accuracy.

### 4.6 OEP: access and suitability
OEP (MSU, Atoum et al., 24 subjects: 15 actors told to cheat, 9 real examinees whose cheating behaviours were invoked by the proctor) provides per-subject `gt.txt` files with `start end type` intervals (MMSS, verified against video durations; type codes 1, 2, 3, 5, 6 are undocumented), 640×480 webcam video, wearable-camera video and audio. The authors' host was unreachable from our network (and the Kaggle mirror requires a login); the full 11.85 GB archive was supplied by the project owner as a zip that passed integrity checks; its size matches the third-party Kaggle copy (uploader not an author, licence "Unknown") exactly, and the authors' own page asks only for citation (`docs/OEP_LICENCE_STATUS.md`). We used only `gt.txt` and the webcam video, commit no OEP media, and publish only aggregate numbers. **Neither the authors' page nor the Kaggle record states a licence or terms, and Kaggle hosting by a third party does not itself grant publication rights; permission to publish results derived from OEP is unconfirmed, and a final licence check (or removal of OEP-derived results) is required before submission.** An earlier single-subject feasibility run (subject 21 only: AUROC 0.633 gaze z, 0.594 head, 0.526 face-absent) was superseded by the 24-subject analysis in §4.10; `exp08` now reports the same per-subject signal AUROCs for all 24 subjects (`exp08_oep_per_subject.csv`). MediaPipe found a face in 61–100 % of frames per subject (§4.10).

### 4.7 Live UI check
With headless Chrome and a fake camera fed by that same OEP clip (a stand-in for a physical webcam), the web app loaded MediaPipe from its CDN, completed the 33-s calibration (505 samples, 87 % tracking quality), recorded a 70-s session and persisted it through the Express/SQLite backend (scratch database): 146 signals, 16 evidence rows, 1,601 feature and risk rows; the dashboard rendered baseline, event history, risk (LOW, 20/100) and explanation. One console error (an `AbortError` from React StrictMode's dev-time double mount) was found and silenced (3 of 3 subsequent loads clean). The run was repeated after integrating the linear gaze estimator (§4.8): calibration completed and a 70-s session persisted (147 signals, 22 evidence rows, 1,636 feature/risk rows; GAZE_DEVIATION metadata records `estimator: linear`, the legacy z and h_hat), with no application errors. After `src/App.jsx` was restructured to clear its lint errors (engines now created in an effect instead of during render), the same live test was repeated: 3 of 3 later runs completed calibration, recorded and persisted sessions; one earlier run timed out waiting for the camera to become ready while the full research pipeline was loading the CPU, and that single timeout was not diagnosed. The first physical-webcam smoke tests (one person, not a participant study; `docs/WEBCAM_SMOKE_TEST.md`) exposed three defects that were fixed (calibration stalling without a face, raw gaze/head samples not being persisted, a false initialization error), and a fourth: a tab switch recorded `TAB_HIDDEN` but not `FOCUS_LOST`; the collector now treats a hidden tab as a focus loss, verified by unit tests and in one live Chrome session (a 6.1-s focus-loss episode), not across browsers. The interface now also has a landing page, a clearly labelled demo-only sign-in (no authentication), session history and session-detail pages. Not tested: other browsers, multiple concurrent sessions, multi-person use.

### 4.8 A linear gaze-angle estimator, and its integration (RQ3 extension)
`exp09` fits a ridge regression (alpha = 10) from the nine features the app already computes (g_x, g_y, the four per-eye iris ratios, yaw, pitch, roll) to the camera-frame horizontal gaze angle. Evaluation is leave-one-subject-out (trained on 14 subjects, scored on the 15th) with the same targets, positives and bootstrap as §4.3. Score = |h_hat - mu|/sigma, with mu, sigma from calibration frames (same semantics as the app).

| within-subject AUROC, horizontal deviation | cross-session (K = 100) | same-session (K = 30) |
|---|---|---|
| iris-ratio z_x, population baseline | 0.803 | 0.800 |
| iris-ratio z_x, personal baseline (previous app signal) | 0.829 | 0.793 |
| **linear h_hat, population baseline (no calibration)** | 0.878 | 0.877 |
| **linear h_hat, personal baseline** | 0.891 | 0.852 |
| linear h_hat personal minus z_x personal [95 % CI] | +0.062 [0.034, 0.093] (14/15 subjects) | +0.059 [0.028, 0.093] (13/15) |

*Per-subject spread* (`exp09_per_subject_*.csv`; within-subject AUROC, min / median / max over the 15 subjects): cross-session z_x personal 0.651 / 0.836 / 0.921 vs linear personal 0.682 / 0.913 / 0.952 (linear better for 14 of 15 subjects); same-session z_x personal 0.620 / 0.814 / 0.878 vs linear personal 0.664 / 0.872 / 0.899 (13 of 15); uncalibrated linear estimator, median 0.894 (cross-session protocol) and 0.902 (same-session protocol). The weakest subject (p08, AUROC 0.68 / 0.66) is not improved by the linear model; MPIIFaceGaze provides no covariates (glasses, lighting) with which to explain it, so we do not know why.

The learned estimator therefore improves on the previous signal in both protocols, whereas personal calibration helps only in the cross-session case (+0.013 over the uncalibrated linear estimator) and *hurts* in the same-session case (-0.025); the best same-session score needs no calibration at all. The estimator includes head yaw, so it measures camera-frame gaze (iris + head), the quantity the target is defined on; the app's separate head-pose signal is unchanged. Operating point (`exp09b`, cross-session K = 100): z >= 3 corresponds to about 27 degrees (median calibration SD 9.2 degrees), TPR 1 % at FPR 0.1 %; z >= 2: TPR 18 % at FPR 0.2 % - a conservative gate like the previous one.
*Integration.* The model is exported to `src/modules/vision/linearGaze.js` (generated by `research/export_linear_gaze_js.py` from `research/models/linear_gaze_v1.json`; the artifact is fit on all 15 subjects, so its own training-set performance is not an evaluation) and parity-tested against sklearn on 200 real rows (max error 2e-14 degrees, `npm test`). `GAZE_ESTIMATOR = "linear"` in `visionTracker.js` selects it; `"iris_ratio"` restores the previous signal, and both z-scores are logged in every GAZE_DEVIATION signal's metadata for comparison. Caveats: the improvement is shown on the on-screen surrogate task, not on cheating; the app's calibration (which includes a guided phase) will yield a larger sigma than MPIIFaceGaze's natural-viewing frames, so the gate's meaning in degrees will differ and is untested; the 0.5-degree floor on sigma is an unvalidated choice; the model was trained on 15 laptop-camera subjects.

### 4.9 Head-pose component validation against sensor ground truth (UPNA, I2Head) – component, not cheating, validation
`exp11` (UPNA Head Pose Database: 10 users × 12 webcam videos, 36,000 frames, magnetic-sensor ground truth, CRC-verified archive): MediaPipe found a face in 100 % of frames. Because the sensor and MediaPipe frames differ, rotation *changes from the first frame* are compared; the GT→MediaPipe axis/sign correspondence is a fixed convention chosen once on the guided single-rotation videos (4–6) and frozen. Per-user mean absolute error (subject-bootstrap 95 % CI), current app decomposition:

| axis | guided single-axis (videos 4–6) | free movement (videos 7–12) | pooled r |
|---|---|---|---|
| roll | 0.58° [0.46, 0.69] | 0.65° [0.54, 0.82] | 0.99–1.00 |
| yaw | 0.81° [0.67, 0.95] | 1.27° [1.09, 1.44] | 0.98–0.99 |
| pitch | 1.05° [0.96, 1.15] | 1.00° [0.87, 1.15] | 0.98 |

(GT SD 6.5–10.4° per axis, i.e. errors are ~10 % of the movement.) The roll fix of §4.1 is confirmed on real video: in free movement, legacy-minus-fixed roll MAE = 0.25° [0.11, 0.42], 9/10 users improved (`exp11_roll_fix_paired.json`); in guided single-axis roll the legacy formula was marginally lower (0.50° vs 0.58°), as expected since its error arises only under combined rotations. This also resolves §5's MPIIFaceGaze head-pose disagreement in favour of MediaPipe. Caveats: rotations ≤ about 30° from a frontal start, one lab, 10 users; this is *relative* pose, which is what the app uses.
`exp13` (I2Head users 01–02, 4,640 images, face found 99.7–100 %; axis match cross-fitted on the other user): for the two angle columns with substantial movement (SD 2.5–6.0°) MAE 0.31–0.82°, r 0.91–1.00. The first angle column moves very little (SD 1.2–1.3°); its cross-fitted axis match was inconsistent between users (roll for user 01, r 0.84; yaw for user 02, MAE 2.56°), so that column is not interpretable with two users. I2Head gaze could not be evaluated: the mapping from `position_index` to the 81-point target grid is not documented in the archive.

### 4.10 OEP: does GlassBox detect annotated cheating intervals? (`exp12`, `exp12b`)
Setup (fixed before results): 24 subjects (15 actors, 9 real examinees), MediaPipe at 5 fps, label = inside the union of annotated intervals (any type; types undocumented), label-agnostic calibration on each video's first 120 s (excluded), non-overlapping 10-s windows (positive ≥ 50 % cheating, negative 0 %, ambiguous dropped): 1,956 windows, 646 positive (33 %). No browser signals exist in OEP. Learned models are leave-one-subject-out; CIs are subject-level bootstrap.

| score (window level) | AUROC [95 % CI] | PR-AUC |
|---|---|---|
| GlassBox engines (real JS replay), window-max risk | 0.532 [0.442, 0.629] | 0.364 |
| face-absent fraction | 0.564 [0.490, 0.633] | 0.364 |
| max gaze z (linear estimator) | 0.471 [0.410, 0.538] | 0.342 |
| max head deviation / 30° | 0.604 [0.521, 0.675] | 0.436 |
| logistic regression, all features, personal (LOSO) | 0.523 [0.421, 0.625] | 0.371 |
| HistGB, all features, personal (LOSO) | 0.532 [0.436, 0.620] | 0.383 |

**Pre-specified primary comparison:** logistic regression minus engine = −0.009 [−0.099, 0.086] – no improvement, so **no learned model was integrated**. Exploratory ablations were all near chance: feature groups 0.42–0.54; population or raw normalisation 0.53 / 0.52; 5-s and 20-s windows 0.53 / 0.50; transfer actors→real examinees 0.46–0.48 and real→actors 0.48–0.54. The only scores whose CIs exclude 0.5 are the two simple head-deviation heuristics (0.604, 0.600); they are two of many exploratory comparisons and are not claimed. Diagnostics (`exp12b`): every annotation ends within its video; shifting labels by −20…+20 s leaves frame-level AUROC flat (0.51–0.52), so there is no timing offset; effect sizes between cheating and normal windows are small (SMD 0.06–0.08 for gaze, 0.21–0.43 for head and face-absence); MediaPipe found a face in 61–100 % of frames per subject. **Conclusion: on OEP, GlassBox's webcam signals do not discriminate annotated cheating intervals meaningfully above chance, and supervised fusion of the same signals does not help.** Plausible reasons (not tested): many behaviours may not change face/head/gaze from the webcam's viewpoint, the type codes are undocumented, and the annotations mark episodes, not the visible cue.

### 4.11 Can justified improvements rescue OEP detection? (`exp14`, pre-specified)
Hypotheses fixed beforehand: **H1** causal temporal context (previous windows, EWMA), **H2** richer signals (face-box size change, gate-exceedance fractions and run lengths, motion energy), **H3** model class (regularised logistic regression with C chosen by *inner* subject-grouped CV on training subjects only, random forest, gradient boosting). The primary comparison (logistic regression, all three additions, vs the real-engine window-max risk) was declared in advance as the integration criterion: CI lower bound above 0 *and* a gain in both actor→real and real→actor transfer. Same 1,956 windows (646 positive, 33 %), same leave-one-subject-out splits, label-agnostic calibration, causal features, subject-bootstrap CIs. Window prevalence per subject ranges 0–80 % (median 33 %).

| score | AUROC [95 % CI] | PR-AUC | precision / recall / F1 at a 33 % review budget* |
|---|---|---|---|
| engine risk (real JS engines) | 0.532 [0.442, 0.629] | 0.364 | 0.353 / 0.351 / 0.352 |
| max head deviation / 30° (heuristic) | 0.604 [0.520, 0.675] | 0.436 | 0.420 / 0.418 / 0.419 |
| logistic regression, v1 features | 0.533 [0.424, 0.642] | 0.371 | 0.425 / 0.423 / 0.424 |
| + temporal context (H1) | 0.531 [0.422, 0.626] | 0.383 | 0.415 / 0.413 / 0.414 |
| + richer signals (H2) | 0.545 [0.422, 0.655] | 0.380 | 0.417 / 0.415 / 0.416 |
| **+ both (primary model)** | **0.548 [0.436, 0.648]** | 0.405 | 0.418 / 0.416 / 0.417 |
| random forest, same features | 0.562 [0.444, 0.669] | 0.382 | 0.411 / 0.409 / 0.410 |
| gradient boosting, same features | 0.524 [0.416, 0.613] | 0.365 | 0.392 / 0.390 / 0.391 |

\*Flag the top-33 % scoring windows of each test subject (33 % is the training prevalence), a label-free threshold; chance precision and recall are both ≈ 0.33. Confusion matrix of the primary model: TP 269, FP 374, FN 377, TN 936.
**Result:** the primary model minus the engine is **+0.016 [−0.088, 0.121]** (minus the v1 logistic regression: +0.015 [−0.041, 0.073]); transfer AUROC 0.525 (actors→real; engine 0.597) and 0.503 (real→actors; engine 0.457). **The integration criterion was not met, so no learned cheating detector was integrated.** Probabilities are also not calibrated for use as risk: for the unweighted logistic model Brier 0.240 vs 0.221 for a constant-prevalence predictor, ECE 0.111, AUROC 0.521. Hence the GlassBox risk score must not be read as a probability of cheating.
*Label audit (exploratory, small groups; `exp14_label_audit_by_type.csv`):* annotation types are unevenly informative. Type 1 (102 windows) coincides with face absence (standardised difference 0.91); type 6 (38 windows) with head-gate exceedance (1.20); type 2 (359 windows, the largest) shows modest head/motion differences (0.4–0.6); type 3 (136 windows) looks *calmer* than normal windows on most features (negative differences), as if its behaviours were not visible to the webcam; type 5 has 11 windows. Without the authors' definitions (§4.6) we cannot say which behaviours these are, and these within-type numbers are not corrected for multiplicity.
**Interpretation.** Using only the webcam signals GlassBox has, none of the justified additions detected OEP's annotated intervals meaningfully above chance. A reliable detector would need labels whose meaning is documented and visible to the sensors (likely including the wearable camera, audio, screen activity and the examination content, which the original OEP system used), more subjects per behaviour type, and possibly behaviour-specific rather than "any cheating" targets. We make no claim that better data would suffice.

## 5. Limitations and negative results

1. **Cheating detection is not supported.** On the only suitable public dataset (OEP, acted and proctor-induced cheating, no browser signals) the engine and learned models were near chance (§4.10). The risk score, weights, thresholds and decay remain unvalidated design choices, and the score is not a calibrated probability (§4.11).
2. **Gaze**: only horizontal gaze is usable; vertical iris signal null; off-screen gaze, glasses and occlusion not evaluated on MPIIFaceGaze; 15 subjects. In OEP, MediaPipe missed the face in up to 39 % of a subject's frames (face found in 61–100 % per subject).
3. **Personalisation** evidence is mixed (§4.3, §4.8); the deployment-like same-session regime could be tested only up to K = 30 sparse frames. The integrated linear estimator rests on the same 15-subject, on-screen data.
4. **Head pose**: validated against sensor ground truth on UPNA (10 users) and I2Head (2 users) for *relative* rotation within about 30° of a frontal start, in lab conditions (§4.9); not validated for large angles, other cameras or distances, or occlusion. MPIIFaceGaze's annotated head pose disagrees with MediaPipe (geodesic-angle r = 0.38), and the UPNA result supports MediaPipe as the more trustworthy of the two. The first I2Head angle column is not interpretable with two users.
5. **Fairness** covers face detection on still images only; no per-person gaze/pose fairness analysis was possible.
6. **Statistics**: exploratory analysis paths (disclosed in §4.2–4.3), many unadjusted comparisons, 15 subjects.
7. `npm run lint` now exits 0 (the 10 pre-existing React-compiler errors in `src/App.jsx` were fixed by creating the engines in an effect). The UI was verified only in headless Chrome with a fake camera.
8. **Component validation is not cheating validation.** Everything in §4.2–4.4 and §4.8 validates sensing components (gaze, head pose, face detection) on surrogate tasks; none of it shows that the risk score separates cheating from honest behaviour. The risk score is additionally fragile to an under-estimated calibration spread (§4.1).
9. **OEP permission and documentation**: the authors state no licence or terms and the cheat-type codes are undocumented; permission to publish OEP-derived results must be obtained before submission. **I2Head gaze** could not be evaluated (position-index to target mapping undocumented) and only 2 of 12 users were obtained.

## 6. Reproducibility
`python research/fetch_data.py && python research/run_all.py` was re-run in full after the final experiments (25 steps including OEP extraction and features, `exp08`, `exp11`–`exp13`) and exited 0 with no tracebacks and `npm test` 4/4. Every previously committed result regenerated identically except (i) the RandomForest rows of `exp01`, which differ at the 1e-16 to 1e-7 level (multi-threaded summation order), and (ii) `exp08`, which now covers all 24 OEP subjects instead of one. The OEP, UPNA and I2Head steps require the user-downloaded archives in `~/Downloads` and are skipped when absent. The earlier first full run exited 0 (several hours wall-clock on a CPU shared with other jobs) and regenerated `exp02`, `exp02c` (adjusted), `exp04`–`exp06` results byte-identically to the committed files; `exp01`, `exp02c_lowlight_drop`, `exp07` and the engine replay changed only through code changes made after the first commit. Steps added after that run was launched (`exp04b`, `exp08`, the replay runner, `exp09`, `exp09b`, `exp10`) were run via `python research/run_all.py <step names>`; `npm test` passes (3 tests). Seeds fixed (20261021); versions in `research/requirements.txt`. Outputs: `research/results/`, figures `docs/figures/`. The pilot proposal is `docs/PILOT_PROTOCOL.md`.

## References (those used)
* Ariz, Bengoechea, Villanueva, Cabeza. *A novel 2D/3D database with automatic face annotation for head tracking and pose estimation.* Computer Vision and Image Understanding 148:201–210, 2016 (UPNA Head Pose Database; CC BY-NC-SA 4.0 per the dataset page).
* Buolamwini, Gebru. *Gender Shades: Intersectional Accuracy Disparities in Commercial Gender Classification.* Proceedings of Machine Learning Research 81:77–91 (FAT* 2018).
* Kartynnik, Ablavatski, Grishchenko, Grundmann. *Real-time Facial Surface Geometry from Monocular Video on Mobile GPUs.* CVPR 2019 Workshop on Computer Vision for AR/VR; arXiv:1907.06724.
* Lugaresi et al. *MediaPipe: A Framework for Building Perception Pipelines.* arXiv:1906.08172, 2019.
* Martinikorena, Cabeza, Villanueva, Porta. *Introducing I2Head Database.* PETMEI '18, Warsaw, 2018 (CC BY-NC-SA 4.0 per the dataset page); see also Martinikorena et al., *Low cost gaze estimation: knowledge-based solutions*, IEEE Trans. Image Processing, 2019.
* Yoder-Himes et al. *Racial, skin tone, and sex disparities in automated proctoring software.* Frontiers in Education, 2022, doi:10.3389/feduc.2022.881449.
* Zhang, Sugano, Fritz, Bulling. *MPIIGaze: Real-World Dataset and Deep Appearance-Based Gaze Estimation.* IEEE TPAMI 41(1):162–175, 2019, doi:10.1109/TPAMI.2017.2778103.
* Zhang, Sugano, Fritz, Bulling. *It's Written All Over Your Face: Full-Face Appearance-Based Gaze Estimation* (MPIIFaceGaze). CVPRW 2017. CC BY-NC-SA 4.0.
* Kärkkäinen, Joo. *FairFace: Face Attribute Dataset for Balanced Race, Gender, and Age for Bias Measurement and Mitigation.* WACV 2021. CC BY 4.0.
* Atoum, Chen, Liu, Hsu, Liu. *Automated Online Exam Proctoring.* IEEE Transactions on Multimedia 19(7):1609–1624, 2017 (OEP dataset; author page lists Dec. 2015 acceptance).
* Mendeley Data, "Students suspicious behaviors detection dataset for AI-powered online exam proctoring", v1, 2025, doi:10.17632/39xs8th543.1.
* Google MediaPipe FaceLandmarker (`face_landmarker.task`, float16 v1).
* Not obtained (blockers only): Smith et al., *Gaze Locking*, UIST 2013 (Columbia Gaze); Fanelli et al., *Random Forests for Real Time 3D Face Analysis*, IJCV 2013 (BIWI).
