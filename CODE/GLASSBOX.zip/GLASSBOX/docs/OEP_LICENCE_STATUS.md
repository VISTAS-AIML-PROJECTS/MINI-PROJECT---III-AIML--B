# OEP dataset – provenance and licence status (evidence as of 2026-10-21)

**Bottom line: publication permission is UNCONFIRMED.** Nothing found grants or denies it. Development and paper preparation continue; **a final licence check is required before any submission**. This file records only what was verified.

## Evidence
| Item | What was verified | Source |
|---|---|---|
| Original source | MSU Computer Vision Lab "OEP Dataset" page: *"You can download the OEP dataset from here. If you use OEP dataset, please cite the paper"* (Atoum, Chen, Liu, Hsu, Liu, "Automated Online Exam Proctoring", IEEE Trans. Multimedia 19(7):1609–1624). **No licence, terms-of-use or consent statement** on that page or on the project page. | `cvlab.cse.msu.edu/oep-dataset.html`, `…/project-OEP.html` (fetched 2026-10-21) |
| Dataset README (inside the archive) | Describes 24 MSU students, 15 actors and 9 real examinees whose cheating was invoked by the proctor; file layout; contact address for questions. **No licence or usage terms.** | `READ_ME.txt` in the archive |
| The copy we analysed | `OEP database.zip` supplied by the project owner. Its total uncompressed size, 12,076,821,446 bytes, **equals to the byte** the Kaggle record `raajanwankhade/oep-dataset` reports (inference: same file set; not a cryptographic proof). | zip listing vs Kaggle API metadata |
| Kaggle record | Title "MSU Online Exam Proctoring Dataset"; uploader **Raajan Wankhade (not one of the authors)**; version 1 "Initial release", 2024-01-16; **licence: "Unknown"**; description copies the paper abstract; no source link, terms or attribution to the original distributors; 3,119 downloads. | Kaggle public API (`/api/v1/datasets/view/raajanwankhade/oep-dataset`) |
| Direct authors' archive | `cse.msu.edu/computervision/OEP_database.tar.gz`, 11,843,806,019 bytes (Last-Modified 2018-04-10) was reachable earlier in the session (partial download of ~3.0 GB inspected: same structure); the host later became unreachable from our network. | HTTP headers 2026-10-21 |

## What this means (assessment, not legal advice)
* Kaggle hosting by a third party with licence "Unknown" does **not** by itself grant redistribution or publication rights; the authors' own page asks only for citation and states nothing about derived results. The participants were MSU students; the consent terms for further use are not stated anywhere we can see.
* Using the data internally for research on one's own machine, with citation, is consistent with how the authors present the download. Publishing results derived from it is plausibly acceptable in the usual academic sense, but this was **not confirmed in writing**.

## Applied restrictions (what this repository does)
* Raw OEP video, audio, wearcam files and archives are **never committed** (`data/` is git-ignored; verified: no OEP media or archive in `git ls-files`).
* Original file names embed participant usernames; extraction renames files to fixed names and a word-boundary search of every tracked text file for the 24 participant-username strings found only the dataset author's own name (in the email draft, as the contact) and the ordinary English word "mark" (paper prose and UI code); no participant is identifiable.
* Committed OEP-derived files contain only **aggregate/per-subject numeric summaries** (AUROC tables, window counts, cheating-share and face-found rates, standardised effect sizes, per-type window counts). No frames, no images, no audio, no per-frame traces.
* No annotation meaning is invented: type codes 1, 2, 3, 5, 6 are reported as undocumented.
* The paper states the permission status and must not be submitted without the final check below.

## Final check required before submission (owner action)
1. Obtain written terms/permission from the authors (draft: `docs/DATASET_AUTHOR_EMAIL_DRAFTS.md`, **not sent**).
2. Or, if permission cannot be obtained, remove OEP-derived tables and figures from the manuscript (the engine audit, head-pose, gaze and fairness results do not depend on OEP).
3. Re-check this file against any reply, and update the paper's data section accordingly.

## Permission assessment by use (all UNCONFIRMED; nothing below is permission)
| Use | What the evidence says | Status |
|---|---|---|
| Research / analysis on one's own machine | Authors' page: download offered, "please cite". Kaggle licence "Unknown". Plausible but not stated. | Unconfirmed (likely acceptable for non-commercial research) |
| Conference/journal publication of aggregate results | Not addressed by any source we can see. | **Unconfirmed - must be checked before submission** |
| Derived metrics, tables, figures without participant images | Not addressed. | Unconfirmed |
| Redistribution of data, derived per-frame features, or video frames | Not addressed; participants are identifiable students; Kaggle uploader is not the owner. | **Do not redistribute** |

## What I need from you (the official page)
You said the official source may state terms. Please send me, as text or a screenshot:
1. **The Kaggle dataset page's "License" field and the "About Dataset" / Data card text** (the page `kaggle.com/datasets/raajanwankhade/oep-dataset`), including any "Provenance", "Source" or "Citation" lines and the "Usage" tab if present. I could not see these without signing in; the public API only reports licence "Unknown".
2. **Any terms on the original MSU source**: the full text of `cvlab.cse.msu.edu/oep-dataset.html` and `cvlab.cse.msu.edu/project-OEP.html` as shown in your browser (the pages I fetched show only "please cite"), plus any licence/agreement page they link to.
3. **Anything you saw when downloading** (a checkbox, a click-through agreement, or a README) that mentions permitted use.
Then I will quote the exact wording here and assess research use, publication, derived metrics and redistribution separately. Until then every OEP-derived result in the paper and slides stays flagged as publication-unconfirmed.
