# Best verified results — GlassBox

This file ranks the strongest, most defensible findings across the project's two independent research efforts, with the exact file that supports each one. It supplements `GLASSBOX_CONTENT_BANK.docx`/`.pdf` and does not replace it — use this as the quick-reference ranking; use the Content Bank for the full write-up of each item.

The two research efforts are:
- **The engine audit** (`docs/final/`, `research/final/`) — found and fixed seven defects in the original (v1) risk-scoring engine, and pre-registered a comparison of the corrected engine (v2) against it.
- **The pipeline/fusion study** (`docs/results_2/`) — evaluated whether a learned model (logistic regression, random forest, gradient boosting) should replace the rule-based fusion, across eight experiments (E1–E8), including a bias-removed ("nested") model-selection comparison.

Both efforts used the same dataset (OEP, 24 subjects, leave-one-subject-out validation, subject-level bootstrap 95% confidence intervals) but asked different questions, so their numbers are not direct substitutes for each other and should not be merged into a single table in the report.

## Ranked findings

### 1. Seven real software/temporal defects were found and fixed, and the fix was independently verified not to break anything
- **Source:** `docs/final/RISK_SCORE_SPEC.md` (defect table), `src/assessment/` (the fix), `research/final/scenarios.mjs` + `research/final/results/f01_scenarios_metrics.csv` (13 reproducing scenarios), `npm test` (40/40 passing).
- **What it shows:** the original engine's score could freeze, understate an ongoing problem, lose evidence at session end, double-count gaze and head signals, or read a camera failure as calm behaviour. Each defect has its own named, reproducible test scenario (S01–S13) showing the old and new behaviour side by side.
- **Use in the main report:** yes — this is the strongest engineering contribution. Use Table 6.1 (seven defects) and Figure "scenario_trajectories" together.

### 2. A pre-registered comparison shows the engine fix did not lose ranking ability
- **Source:** `docs/final/F02_PREREGISTRATION.md` (protocol, committed before the result), `research/final/results/f02_summary.json`.
- **Numbers:** ranked AUROC, v1 = 0.545 [0.485, 0.610], v2 = 0.536 [0.478, 0.596]; difference (v2 − v1) = −0.009 [−0.036, +0.017] — inside the pre-registered non-inferiority margin (−0.05), so v2 is judged **non-inferior**, not superior.
- **Why this matters for credibility:** the margin, dataset, and analysis plan were fixed in writing before this number was computed, so it cannot have been chosen after the fact to look good. This is the single most methodologically rigorous result in the project and should be described as such.
- **Use in the main report:** yes, prominently — this is what justifies keeping v2 as the deployed engine.

### 3. Across two independent studies, the same single signal — head-pose deviation from the personal baseline — is the one repeatedly flagged as the strongest available predictor
- **Source:** `docs/results_2/comparisons/s13_final_model_selection.csv`, `s13_selected_counts.csv`, `s14_head_deviation_app_rate.py` output.
- **Numbers:** in a bias-removed ("nested") model-selection procedure across 24 subjects, blind selection picked "max head-pose deviation" in 20 of 24 folds (vs. 4/24 for any logistic-regression variant). Its own AUROC is 0.604 [0.564, 0.650], ranked difference vs. the live rule engine +0.059 [+0.011, +0.111]. At the application's real 1-sample/s persistence rate (vs. the 5 fps used for training) it still holds at 0.594 [0.556, 0.643], difference +0.049 [−0.004, +0.106].
- **Caveat required whenever this is cited:** the headline "nested-selected final model" comparison against the engine is +0.057 [−0.002, +0.120] — this interval touches zero, so the improvement over the rule engine is not fully established at the selection level, even though the single candidate is picked very consistently. Report both numbers together; do not quote only the narrower, more flattering interval.
- **Use in the main report:** yes, as the project's one genuine positive lead for future work — not as a validated improvement.

### 4. Learned fusion (logistic regression replacing the rule engine) was tested fairly and does not win — a real, useful negative result
- **Source:** `docs/results_2/comparisons/s10_stage5_fusion.csv`, `docs/results_2/EXPERIMENT_REPORT.md` (§E3), `docs/results_2/comparisons/s13_final_model_selection.csv`.
- **Numbers:** LR on the engine's own components: AUROC difference vs. engine −0.002 [−0.084, +0.077]. LR on raw signal features: +0.016 to +0038 depending on variant, every interval spanning or bordering zero. Inner cross-validation chose the strongest regularisation (C = 0.01) in 16 of 24 folds — the model is being regularised almost to nothing, which is itself evidence it isn't finding a reliable signal.
- **Why this is worth reporting as a strength, not a weakness:** the project planned to use logistic regression for this exact purpose; testing it rigorously and reporting that it does not help, instead of integrating it anyway or quietly dropping the question, is a methodologically honest result and should be presented as a deliberate, evidence-based engineering decision.
- **Use in the main report:** yes — present as "tested, not adopted," with the exact numbers, not as a vague "future work" mention.

### 5. A confusion-matrix-level result quantifies exactly how unreliable any current scorer is in practice
- **Source:** `docs/results_2/figures/oep_confusion_matrices.png`, `docs/results_2/comparisons/oep_window_predictions.csv`.
- **Numbers:** at a one-third review-budget threshold, the rule engine flags 416 normal windows against 227 correctly flagged annotated ones (and similar ratios, 374–391 vs. 252–269, for the learned models); recall at this budget is 0.35–0.42 against a chance level of 0.33.
- **Use in the main report:** yes — this is the clearest, most concrete way to show a reader what "near-chance discrimination" actually means in review workload terms, and it is a real, already-generated figure (not something that needs to be created).

### 6. Two sensing components are independently, strongly validated against public ground truth
- **Source:** `research/results/exp09_linear_gaze.csv` (MPIIGaze/MPIIFaceGaze), `research/results/exp11_upna_headpose.csv` (UPNA Head Pose Database).
- **Numbers:** gaze estimation improves AUROC by +0.06 over the prior signal; head-pose mean absolute error is 0.58–1.27° depending on axis.
- **Use in the main report:** yes — this is implementation-level evidence that the sensing layer itself (independent of the scoring/fusion debate) is accurate, which supports the engineering-quality narrative even though end-to-end cheating detection is not established.

### 7. A fairness gap in face detection was measured, not merely flagged as a risk
- **Source:** `research/results/exp02_fairface_pad125_summary.csv`, figure `fairface_detection_by_group.png`.
- **Numbers:** detection rate by perceived-race group ranges 89.3%–95.1% under native lighting; under simulated low light, subjects perceived as Black lose an additional 3.17–4.75 percentage points of detection relative to the rest of the sample, with confidence intervals excluding zero.
- **Use in the main report:** yes, in the limitations/fairness chapter — a quantified, honestly reported limitation is more credible than an unqualified fairness claim in either direction.

### 8. Full explainability traceability on logged sessions, with one clearly scoped exception
- **Source:** `docs/results_2/comparisons/s11_logged_session_checks.csv`, `s12_persistence_check.py` output (headless replay).
- **Numbers:** in the current code's headless replay, 100% of 89,568 persisted risk rows trace back to stored evidence. On the seven existing logged (developer technical-test) sessions, every stored score/reason/level recomposes correctly (100% of 25,801 rows), but three of those seven sessions show only 46–100% of components traceable to a stored evidence episode — a data-completeness gap in those particular old log rows, not a scoring-logic defect (the current code's own replay is fully traceable).
- **Use in the main report:** yes, in the implementation/evaluation chapter — report the 100% current-code result as the headline, and the older-session exception as a dated, bounded caveat rather than omitting it.

## Metrics and visuals selected for the main report (and why)

| Include | Reason |
|---|---|
| Pre-registered v2-vs-v1 ranked AUROC + CI (Finding 2) | Only pre-registered result in the project; strongest methodological credibility |
| Seven-defect table + scenario figure (Finding 1) | Concrete, demonstrated engineering contribution, independent of any detection claim |
| Confusion matrix at review budget (Finding 5) | Already generated, publication-quality, makes "near chance" concrete for a non-technical reader |
| Nested model-selection figure (Finding 3) | Shows the project's one genuine lead, with its own uncertainty, not oversold |
| LR-vs-engine fusion comparison (Finding 4) | Supports the "tested, not adopted" narrative with real numbers |
| Gaze/head-pose validation numbers (Finding 6) | Shows the sensing layer is independently accurate |
| FairFace detection-gap figure (Finding 7) | Honest, quantified limitation |

## Results to keep in the appendix only, or exclude from any performance claim

- The raw (non-ranked) pooled AUROC figures for individual ablations (calibration duration, gate-threshold grid, frame-level smoothing) — these use simplified proxy scores, not the full engine, and are supporting methodology detail, not headline results (`docs/results_2/EXPERIMENT_REPORT.md`, E2).
- Random Forest and Gradient Boosting results from E1 — included in `oep_roc_pr_curves.png` for completeness, but they do not outperform logistic regression or the rule engine by any established margin and add little beyond what Findings 4–5 already establish; do not give them their own chapter subsection.
- The "max head-pose deviation alone" row's own non-adjusted confidence interval (+0.059 [+0.011, +0.111]) should never be quoted without also giving the selection-adjusted nested-model row (+0.057 [−0.002, +0.120]) from the same table — quoting only the former overstates how established the finding is (see Finding 3's caveat).

## Missing evidence that prevents a stronger conclusion

1. **No accuracy evaluation exists on real GlassBox application sessions with consenting examinees.** Every number above is from OEP (a third-party dataset) or from the application's own developer technical-test sessions, which have no cheating ground truth.
2. **OEP's publication permission is unconfirmed** (`docs/OEP_LICENCE_STATUS.md`). This affects every OEP-derived figure and number in this file and in the main report.
3. **24 subjects is a small sample for leave-one-subject-out validation**; every confidence interval above is correspondingly wide, and several findings (notably Finding 3's selection-level comparison) sit close enough to zero that they should be described as suggestive, not established.
4. **Live camera and calibration behaviour have not been re-verified** after the most recent engine changes — no number in this file speaks to real-time runtime performance or the on-device user experience.

## What this file deliberately does not do

It does not introduce any metric, chart, sample count, or result that is not already computed and saved somewhere in the repository (see the Source line under each finding). No accuracy/precision/recall/F1 value was invented, rounded favourably, or recomputed differently from its source file. Where a result is weak or inconclusive (Finding 3's selection-level CI, the E2 ablations), this file says so directly rather than omitting it or downplaying it through vaguer language.
