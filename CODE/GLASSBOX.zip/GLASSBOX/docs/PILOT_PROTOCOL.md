# GlassBox mock-exam pilot – protocol proposal (not yet run, not yet ethically approved)

**What this pilot can and cannot show.** Participants *act out* clearly defined observable behaviours on a cue. The pilot therefore measures
how well GlassBox's signals and risk score detect **cued, observable behaviours** (looking off-screen, turning the head, looking down,
leaving the frame, switching tabs) with ground truth that is exact. It does **not** show that GlassBox detects real cheating: acted behaviour is
more deliberate than furtive real behaviour, there is no incentive to hide it, and no cheating occurs. Any report must say so.

## 1. Why a pilot is needed
Public data accessible to us (see `docs/DATASETS.md`) cannot test GlassBox's own pipeline end to end: MPIIFaceGaze has on-screen gaze only; FairFace is stills;
the Mendeley table is pre-extracted features without subject IDs; OEP is promising but (a) our download is throttled to ≈0.17 MB/s, (b) its type codes are
undocumented, and (c) it has no browser-focus signals. A prospective pilot provides subject-level data with the exact signals GlassBox consumes
(webcam, calibration protocol, browser events).

## 2. Ethics, consent, data protection (preconditions)
* Institutional ethics (IRB/REC) approval **before any recruitment**; this document is a proposal for that application, not an approval.
* Written informed consent; participants may withdraw at any time, with their data deleted. No deception: participants are told they are acting out behaviours.
* Minimise data: store **derived signals only** (landmark-derived features, events, timestamps). Raw video is not retained unless a separate, optional consent is given, then encrypted at rest with a retention end date.
* Pseudonymous participant IDs (P01…); no usernames in file names (a lesson from OEP, whose archive embeds usernames in file names).
* Optional, voluntary self-reported attributes (e.g. glasses, hair covering the forehead, skin-tone category on a stated scale) for descriptive reporting only. **The pilot is not powered for fairness conclusions** and must not claim any.
* Participants are not graded, and no output of GlassBox is used to judge them.

## 3. Design
* **Participants:** target 24 (≥ 12 is the planning minimum, see §6). Adults, own or lab laptop, mixed glasses/no glasses, range of lighting recorded (not controlled).
* **Setup:** laptop webcam at normal height; GlassBox as shipped (its 33 s calibration protocol is part of each session); markers at left, right, lap and a side wall.
* **Session (20 min):** calibration → four 5-min blocks of a simple on-screen task (reading + multiple choice). Each block starts with 45 s cue-free behaviour, then six cued behaviours (one of each, random order, random times, ≥ 20 s apart, 2–8 s long): `OFFSCREEN_LEFT`, `OFFSCREEN_RIGHT`, `HEAD_TURN`, `LOOK_DOWN` (a lap marker, **no phone or notes**), `LEAVE_FRAME`, `TAB_SWITCH`. Block order is counter-balanced (Latin square). Schedules: `python research/pilot_schedule.py 24` (seeded, validated non-overlapping).
* **Ground truth:** the operator console logs the cue start/end timestamps against the same clock as the signals. The participant sees only "do X now". A post-hoc operator check flags cues not performed or performed late; labelling rules are fixed before analysis: a frame is positive from cue start + 1 s (reaction allowance) to cue end + 1 s.
* **Pre-registered analysis (write before data collection):**
  1. Primary: subject-level AUROC of the GlassBox risk-episode score for cued vs cue-free time (segment level), with a subject-level bootstrap CI; thresholds frozen from the existing public-data analyses, **not** tuned on the pilot.
  2. Secondary: per-behaviour sensitivity at the frozen operating point and false-alert rate per minute on cue-free time; personalised (own calibration) vs population baseline (leave-one-participant-out) on the same frames; effect of calibration length (K); `FACE_ABSENT` rate in cue-free time (false-absent) by glasses/no glasses.
  3. Splits: always by participant; calibration frames excluded from evaluation; nothing tuned on test participants. If any tuning is wanted, use a fixed development subset of participants (e.g. the first 8) that is excluded from the headline numbers.
  4. Report all pre-registered comparisons, including null or negative results.

## 4. Known limits to state up front
Acted behaviour; one task; short sessions; volunteer (likely young, technical) sample; lighting and camera vary; browser-event realism limited to a tab switch; no audio; no second person in the room.

## 5. Deliverables
Cue schedule + operator console log format; consent form and ethics application text; analysis scripts that read the pilot export (extend `research/exp08_oep.py`'s interval-labelling code); a de-identified derived-feature dataset.

## 6. Planning sample size (approximate, assumption-laden)
Exp 04's K = 100 comparison gave a paired subject-level difference of +0.026 AUROC with a bootstrap CI half-width of 0.018 over 15 subjects, implying a subject-level SD of ≈ 0.036.
Under that SD (and assuming new participants vary similarly), 80 % power at two-sided α = 0.05 needs ≈ 5 participants to detect a 0.05 AUROC difference, ≈ 12 for 0.03, ≈ 26 for 0.02.
24 participants therefore resolves differences of ≈ 0.02–0.03 for the personalised-vs-population contrast, if the variance assumption holds. The assumption comes from a different task and dataset and should be revisited after the first ~6 participants.
