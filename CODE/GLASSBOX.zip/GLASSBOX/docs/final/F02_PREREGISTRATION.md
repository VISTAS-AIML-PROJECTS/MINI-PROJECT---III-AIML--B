# F02 pre-registration: v2 assessment vs the frozen v1 engine on OEP

Written and committed **before** any v2 result on OEP was computed. The v2 code and configuration (`src/assessment/`, `ASSESSMENT_CONFIG`) are committed in the same commit and will not change in response to F02's results. If they are changed later, F02 must be reported as exploratory for the changed version.

## Why this experiment

v2 was designed to fix software and temporal defects found in the audit, not to improve discrimination:
- the fusion component never resets;
- the score freezes while nothing happens;
- ongoing absences are invisible;
- episodes open at session end are lost;
- gaze and head are double-counted;
- missing observations score as "no risk".

The question for OEP is therefore whether these fixes **cost** discrimination on real recordings, and how the new temporal behaviour looks on them.

## Data and protocol (same as s13 / exp12, unchanged)

- **Data:** OEP, 24 subjects (15 actors, 9 real examinees) at 5 fps. Each subject has a personal baseline from the first 120 s, which is label-agnostic and excluded from evaluation.
- **Signals:** face presence, gaze and head pose. There are no browser-focus events in OEP, so v2 runs with `focusAvailable = false`.
- **Windows:** non-overlapping 10-s windows. A window is positive if at least 50% of its frames fall in annotated cheating, negative if 0% do; mixed windows are dropped. These are exactly the windows of `docs/results_2/comparisons/s13_window_scores.csv`.
- **Scores per window:**
  - v1: the committed `Rule engine (app)` column of s13, the maximum of the per-frame score, unchanged.
  - v2: the maximum of the 1-Hz assessment scores whose tick time falls inside the window. v2 runs through `AssessmentPipeline`, exactly as the app does.

## Primary analysis (decides whether v2 is acceptable as the live score)

- **Metric:** paired difference in pooled AUROC on within-subject percentile ranks (the s13 primary metric), v2 − v1, with a 1000-resample subject-level bootstrap CI (seed 20261021).
- **Acceptance (non-inferiority):** the lower 95% bound of the difference is **> −0.05**. If it is not, v2 is reported as worse at discrimination, and its adoption must be justified on the other grounds or reverted.
- No superiority claim will be made unless the lower bound is > 0. Even then, OEP has been analysed extensively before (exp12, exp14, s01–s14), so it is not an untouched test set and the claim would be labelled as such.

## Secondary analyses (descriptive, no decisions)

1. Raw pooled AUROC (v2 and v1), mean within-subject AUROC, and precision/recall/F1 at the s13 label-free 33% review budget.
2. Score bands at the fixed thresholds (30/60, not tuned):
   - the share of negative and positive windows whose window score is ≥ MEDIUM;
   - the share of all 1-Hz ticks ≥ MEDIUM (the alert burden).
3. Stability: level changes per 10 minutes of recording (v1 per-second displayed level vs v2 level).
4. Delay: for annotated intervals of ≥ 10 s, the seconds from interval start to the first MEDIUM-or-higher tick inside the interval (or "not reached").
5. Reliability layer: the share of ticks in each state, and the Spearman correlation between per-subject face-detection rate and the share of DEGRADED/INSUFFICIENT ticks.
6. Per-subject AUROC for both engines.

## What would not be claimed

- That either score detects cheating. Both are review-priority indices; s13 found no scorer reliably better than chance by an established margin except simple head-pose deviation, and only modestly (≈0.60).
- That the v2 thresholds are calibrated probabilities.
