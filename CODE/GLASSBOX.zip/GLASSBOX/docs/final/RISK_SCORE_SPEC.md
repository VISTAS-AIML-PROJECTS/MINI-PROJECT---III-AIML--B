# GlassBox risk score specification (assessment v2)

Implementation: [`src/assessment/`](../../src/assessment/). Configuration: [`assessmentConfig.js`](../../src/assessment/assessmentConfig.js). Tests: [`research/tests/assessment.test.mjs`](../../research/tests/assessment.test.mjs).

## What the score is, and what it is not

- **It is** a bounded 0–100 *behavioural risk index* that ranks how much observed behaviour in the recent past deserves a human reviewer's attention. Every point traces back to recorded evidence episodes.
- **It is not** a probability of cheating, and has not been calibrated as one. No dataset with suitable labels exists for that (see [`EVIDENCE_AND_LIMITATIONS.md`](EVIDENCE_AND_LIMITATIONS.md)). Looking away, head movement, face absence and focus loss have innocent explanations, so the score never decides anything on its own.

Each assessment has three separate outputs:

| Output | Meaning |
|---|---|
| `score` (0–100) and `level` (LOW / MEDIUM / HIGH / UNDETERMINED) | How much notable behaviour was observed recently |
| `reliability` (0–1) | How much of the last minute could actually be observed |
| `state` (OK / DEGRADED / INSUFFICIENT_EVIDENCE) | Whether the score can be read at face value |

"Nothing suspicious was observed" and "nothing could be observed" are therefore different outputs.

## Pipeline

```
raw signals (20 fps vision + browser events)
  ├─► ObservationMonitor ── per-second: camera frames? face? measurable gaze/head?
  └─► EvidenceEngine ─────── gated episodes (closed) + ongoing episodes (provisional)
                                   │
                    AssessmentEngine.update(now), once per second
```

## Equations

**1. Episode evidence.** The episode definitions are unchanged from v1 (`src/evidence/evidenceEngine.js`):

- **Gaze and head pose:** a sample deviates only if it exceeds the personal-baseline gate (gaze z ≥ 3; head ≥ max(8°, 3 SD) on any axis). Consecutive deviating samples less than 1.5 s apart form an episode, which needs at least 3 samples and 0.5 s. Strength = 0.5 · mean sample strength + 0.25 · min(duration / 5 s, 1) + 0.25 · min(samples / 10, 1).
- **Face absence and focus loss:** an episode runs from the first FACE_ABSENT / FOCUS_LOST signal to the return. Strength = min(duration / 5 s, 1).
- **Ongoing episodes:** each one is scored as if it ended at `now` (new in v2).

**2. Channel evidence**, for channel k ∈ {gaze, head, faceAbsence, focusLoss}:

c_k(t) = min(1, Σ_e s_e · u_e · exp(−(t − t_e) / τ) / 3), with u_e = max(1, d_e / 5 s) and τ = 120 s

- s_e is the episode strength, d_e its duration and t_e its end time (or `now` if it is still ongoing).
- u_e is new in v2. A 60-s absence counts like twelve 5-s absences instead of one; in v1 it counted like a single 5-s absence.

**3. Groups.** The channels are combined into groups so that cues for the same behaviour are not double-counted:

| Group | Value | Why |
|---|---|---|
| attention | max(c_gaze, c_head) | Both measure "turned towards something else"; adding them counts one behaviour twice |
| presence | c_faceAbsence | Camera-based, but a different behaviour |
| focus | c_focusLoss | Browser-based, independent of the camera |

**4. Fusion.** This is an ordered weighted average. With g(1) ≥ g(2) ≥ g(3) the group values sorted in descending order:

R = 0.5 · g(1) + 0.3 · g(2) + 0.2 · g(3),  score = round(100 · R)

Consequences, all covered by tests:
- One kind of behaviour alone can reach at most 50, which is MEDIUM. **HIGH (≥ 60) requires a second, independent kind of behaviour.**
- The score is bounded in [0, 100], monotone in every channel, and symmetric: no channel is privileged, and no weights were fitted to data.
- Each group's contribution in points is reported, and the contributions sum to the score (±1 from rounding).

**5. Levels with hysteresis.**
- LOW < 30 ≤ MEDIUM < 60 ≤ HIGH. These are the v1 bands, unchanged.
- A level is entered at its threshold but left only once the score drops 5 points below it.

**6. Reliability and state.**
- Over the last 60 s, reliability is the mean of the available groups' coverage:
  - presence: the share of seconds with camera frames;
  - attention: the share of seconds with a measurable gaze/head sample (face visible, quality ≥ 0.35, calibrated);
  - focus: 1 when the browser collector runs (OEP has none, so it is excluded there).
- The state follows from reliability:

| Condition | State |
|---|---|
| reliability < 0.5, or under 10 s observed so far | INSUFFICIENT_EVIDENCE |
| reliability < 0.8 | DEGRADED |
| otherwise | OK |

- When the state is INSUFFICIENT_EVIDENCE and the score would be LOW, the level is reported as **UNDETERMINED**, because unobserved time cannot certify low risk. Evidence that *was* observed still counts.

## Fixed parameters and where they come from

| Parameter | Value | Origin |
|---|---|---|
| τ (decay) | 120 s | v1, kept; decay validated in `research/tests/evidence_calm_user.mjs` |
| saturation | 3 episode-equivalents | v1, kept |
| persistence unit | 5 s | v1's own persistence saturation |
| rank weights | 0.5 / 0.3 / 0.2 | Design choice: one group alone stays below the HIGH band; not fitted |
| level bands | 30 / 60 | v1, kept |
| hysteresis | 5 points | Design choice; scenario S11 shows its effect |
| coverage window | 60 s | Design choice |
| reliability bands | 0.8 / 0.5 | Design choice |
| minimum observation | 10 s | Design choice |
| minimum face quality | 0.35 | Calibration's own quality gate (`visionTracker.js`) |

None of these values were tuned on OEP or on any labelled data. F02 ([pre-registration](F02_PREREGISTRATION.md)) is a one-shot check against v1.

## How v2 differs from v1 (`src/risk/riskEngine.js`, kept unchanged for comparison)

| v1 defect (audit evidence) | v2 |
|---|---|
| The fusion component keeps its last non-zero value forever: the fusion engine returns `null` when nothing is active, so `latestFusion` never resets | No stateful fusion sample. Corroboration comes from independent groups |
| The score is recomputed only when events arrive, so it freezes during calm periods | Clock-driven `update(now)` once per second |
| Ongoing absence or focus loss scores nothing until it ends. Logged session 10: 41 s with no face scored LOW 4 | Ongoing episodes are scored at their current length |
| Episodes open at session end are lost (end-session order and `reset()` behaviour) | `finalize(now)` emits every open episode |
| Gaze and head are added separately and again inside fusion | One attention group, scored by the stronger cue |
| Long episodes count like 5-s ones | Duration-aware accumulation |
| Camera stopped, so no evidence, so "LOW" | INSUFFICIENT_EVIDENCE / UNDETERMINED |
| Risk timestamp = `Date.now()`, so not reproducible | Timestamp = evaluation time; identical inputs give identical outputs |
| A risk row on every frame (about 80/s; 27k rows in the logged data) | 1 row per second |
