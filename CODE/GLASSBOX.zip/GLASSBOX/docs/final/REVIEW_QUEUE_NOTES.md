# Review queue (branch `glassbox-review-queue`)

Built from the approved UI branch `glassbox-ui-refine` (`62758d7`) in the worktree `../glassbox-review-queue`. Reference design: `docs/final_report_kit/dashboard_mockup/dashboard_mockup.png`. Not merged; `glassbox-flagship` (`2954e9e`) is untouched.

## What the page shows (route `#/review`, nav link "Review queue")
| Area | Source |
|---|---|
| Sessions today / pending review / flagged high risk (peak ≥ 60) / reviewed today | counted from `GET /api/sessions` |
| Session table: id, start, duration, peak risk band, review status, highest peak first | `GET /api/sessions` |
| Selected session: peak score and band, per-channel evidence at the peak (v2 `details.channels`; older v1 sessions show their own components, labelled as v1), evidence timeline, observation quality | stored rows from `GET /api/sessions/:id` |
| Human review decision: Mark reviewed — cleared, Flag for follow-up, Add note, with history | new `POST /api/sessions/:id/decisions` |
| Link to the existing session detail page | `#/session/:id` |

The page computes no new score. The mockup's "proposed concept" banner and "illustrative data" tag are gone because the page shows real stored data.

## Why a new table for decisions
The only existing review fields, `exam_sessions.quality` and `approved`, came from the data-collection work and label dataset quality, not a reviewer's judgement of a session. They are not reused. Decisions go in a new table, `review_decisions` (`id, session_id, decision, note, created_at`), created with `CREATE TABLE IF NOT EXISTS`:
- No existing table, column or row is altered. A test pre-fills a database with an existing session and confirms it is unchanged after the server starts.
- **Append-only:** every decision or note is a new row; nothing is ever updated or deleted. The status shown is the latest `CLEARED` or `FOLLOW_UP`; a `NOTE` never changes it.
- Running sessions cannot be reviewed (409). Invalid decisions, empty notes and notes over 2,000 characters are rejected (400).
- The stable branch never reads this table. If you go back to stable, the table simply stays unused.

The table is created the first time this branch's server starts against a database. It is not created by viewing or by tests that use throw-away databases.

## Files changed
`server/server.js` (table, decision endpoint, three review fields on the session list, `reviews` on the session detail), `src/api/glassboxApi.js` (`addReviewDecision`), `src/review/reviewQueue.js` (new), `src/pages/ReviewQueue.jsx` (new), `src/pages/review.css` (new; only `rq-*` classes and `gb-page--wide`), `src/Root.jsx` (route), `src/pages/shell.jsx` (one nav link), `README.md`, tests `research/tests/review_queue.test.mjs` and `review_decisions_api.test.mjs` (new), this file.

## Verification
- `npm test`: 74 tests pass (62 existing + 12 new: 6 queue-logic, 6 decisions-API on throw-away databases). `npx eslint .` clean; `vite build` succeeds.
- Browser check (headless Chrome, isolated API on port 5001 using a **copy** of the database, Vite on 5176): all 11 recorded sessions listed, highest peak first; statistics match the data; recording "Mark reviewed — cleared" updates the row, panel, counts and history; a note is appended without changing the status; nav links and "Open full session details" work; no console errors. The live `glassbox.db` files were unchanged in size and timestamp before and after. Screenshots: `docs/final/review_queue_screenshots/` (taken on the database copy).
- Monitor screen versus the approved UI branch (`62758d7`): **pixel-identical below the nav bar at 1920x1080**, with identical layout boxes, computed styles and nine calibration targets. **Not verified at 1280x720, 1366x768 or 1440x900**, because the headless fake camera did not start in those runs (retries were stopped on request). Supporting but not equivalent evidence: no stylesheet outside the new `review.css` changed, `review.css` only adds new class names, and the nav bar keeps its pinned 60 px height (measured at all four sizes).

## Pre-existing issue found (not caused by this branch, not fixed)
Under `npm run dev`, the camera start-up can hang on "Loading MediaPipe…" even though the video is playing and the model has loaded. It reproduced intermittently on the stable branch (`2954e9e`), on `62758d7` and on this branch under identical conditions. Likely cause: React StrictMode starts the camera twice in development, and when the surviving start's `video.play()` is aborted, `VisionModule.jsx` (around lines 197-215) treats the `AbortError` as expected and returns without setting the ready state. A production build does not double-start effects, so it is probably dev-only, but that is unverified. A reload usually recovers.
