# Demo guide

## Start
```
npm install
npm run setup:offline      # one-time: local MediaPipe model (needs data/models or network)
node server/server.js      # API on http://127.0.0.1:5000 (loopback only)
npm run dev                # UI on http://localhost:5173/#/monitor
```
Open the UI at `localhost:5173` (or `127.0.0.1:5173`). Another origin, such as a LAN address, is refused by the API; set `GLASSBOX_ALLOWED_ORIGINS` if you must.

## Before presenting (needs a person and a camera; not verified by the automated checks)
1. Start a session after calibrating: look at the nine targets, then sit naturally.
2. Look away for about 4 s, three or four times, then switch tab once.
3. End the session and open *Sessions*: the score, reasons, evidence events and "segments to review first" should match what you did.
4. If the camera fails, use the fallback below.

## Script (about 5 minutes)
1. The problem: a single glance means nothing; a pattern may deserve a human look. The score is a review-priority index.
2. Calibration: the baseline is this person's own range, held in the browser.
3. Live monitor: indicators and the reasons panel. Point out that "ongoing" episodes already count.
4. Session detail: the risk timeline, observation quality, evidence events, and the dashed v1 line (the older engine, for comparison).
5. The honest result: on the one public dataset, no scorer detects cheating reliably; learned weights did not beat the rule engine, so none is deployed.

## Fallback without a camera
```
node research/final/run_scenarios.mjs     # 13 synthetic scenarios, v1 vs v2
node research/final/e2e_headless.mjs      # real server + client modules, 9 checks
```
Synthetic scenarios show how the engine behaves; they are not evidence of detection accuracy. Label them as synthetic when shown.

## Likely questions
- **Is it accurate?** Its components are validated (head pose MAE 0.6–1.3°). Cheating detection is not demonstrated; OEP results are near chance (AUROC 0.53–0.55).
- **Why not machine learning?** We tested it three ways (see `EVIDENCE_AND_LIMITATIONS.md`); none beat the rule engine, and the explainable rule engine is easier to audit.
- **What does 80 mean?** That more than one kind of behaviour was observed recently. It is not a probability.
- **Does video leave the browser?** No. Only derived numbers are sent to a local server.
- **Is it fair?** Face detection varies by group and lighting (FairFace, `docs/final_report_kit/BEST_VERIFIED_RESULTS.md`, finding 7). The score never decides anything alone.
- **Why is v2 not better at detection?** It fixes seven defects; it was pre-registered to be non-inferior, and it is.
