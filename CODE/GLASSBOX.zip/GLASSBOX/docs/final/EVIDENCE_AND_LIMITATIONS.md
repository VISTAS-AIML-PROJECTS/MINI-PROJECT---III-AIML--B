# Evidence and limitations

What GlassBox has and has not been shown to do, with the file that supports each statement. The score is a **review-priority index**, not a probability and not a verdict. Only a human reviewer can judge behaviour, and this prototype cannot establish misconduct.

## Objectives mapped to code and evidence

| Objective | Status | Code | Evidence |
|---|---|---|---|
| Webcam sensing in the browser (face, gaze, head pose) | Complete, component-validated | `src/modules/vision/` | Head-pose MAE 0.58–1.27° vs a magnetic sensor (UPNA, `research/results/exp11_upna_headpose.csv`); gaze estimator +0.06 AUROC over the previous signal, leave-one-subject-out (MPIIFaceGaze, `exp09_linear_gaze.csv`). Live camera path re-verified only in an earlier smoke test (`docs/WEBCAM_SMOKE_TEST.md`). |
| Personal baseline per person | Implemented, unit-tested; calibration length shown not to matter | `baselineMath.js`, `visionTracker.js` | `research/tests/baseline.test.mjs`; on OEP, 15–240 s baselines give overlapping AUROC (`docs/results_2/EXPERIMENT_REPORT.md`, E2a). Gap: baseline persists across sessions in one page load. |
| Client-side processing of video | Implemented | `src/` | No frame export in `src/`; the server receives derived numbers only. Server now loopback-only with restricted CORS (`research/tests/server_api.test.mjs`). |
| A pattern matters, not one glance | Complete, scenario-verified | `src/assessment/` | One 1.5 s glance scores 12; six repeated 4 s head turns score 48 (S02, S03 in `research/final/results/f01_scenarios_metrics.csv`). These are synthetic scenarios: they verify the mechanics, not detection. |
| Explainable score | Complete, verified | `assessmentEngine.js`, `ExplanationPanel.jsx` | Contributions recompose every stored score; 100% of 89,568 replayed risk rows trace to stored evidence (`docs/results_2/comparisons/s12_summary.json`). |
| Combine several signals into one 0–100 score | Complete (rule-based) | `src/assessment/` | See "Decision on learned fusion". |
| Logistic regression learns the weights | Tested; **not adopted** | `research/`, `docs/results_2/`, `research/final/f05_*` | See below. |
| Detect cheating | **Not demonstrated** | — | On OEP every scorer is near chance. |
| Session history and human review | Complete | `src/pages/`, `server/` | `research/final/e2e_headless.mjs` (9/9). |

## Decision on learned fusion

Three independent offline tests, all leave-one-subject-out on OEP (24 subjects, 1,956 ten-second windows, 646 positive), with the regularisation strength chosen by an inner subject-grouped loop:

1. **LR on the v1 engine's components** (`docs/results_2`, E3): AUROC difference vs the engine −0.002 [−0.084, +0.077]; strongest regularisation chosen in 16 of 24 folds.
2. **Nested, selection-adjusted comparison of every candidate** (E7): the selected model scores 0.602 [0.566, 0.645], but its difference from the rule engine is +0.057 [−0.002, +0.120], which includes zero. Blind selection picked a *rule* (maximum head-pose deviation) in 20 of 24 folds and an LR in 4.
3. **Non-negative LR over the live v2 groups** (`research/final/f05_learned_weights_v2.py`, specified and run in this branch): 0.454 [0.394, 0.515], difference vs the live v2.1 engine −0.078 [−0.155, −0.007]. The learner put its weight on face presence, whose direction is not consistent across people (above 0.5 in 11 subjects, below in 10), so it did not generalise to held-out subjects. A post-hoc check using within-subject ranks reached 0.494, again no gain. Attention is the more consistent group (above 0.5 in 17 of 23 subjects).

**Conclusion.** Learned weights do not improve on the rule-based engine on the data available, so the live score stays rule-based and no model artefact is shipped. A learned model would need labelled sessions from the system's own signals, which do not exist yet. Nothing here shows that learned fusion cannot work; it shows that this dataset cannot support it. LR scores were never calibrated and must not be read as probabilities.

## One final score: why it stays the v2.1 rule engine

A combined rule + logistic-regression score was considered and **not built**. Blockers, in order:
1. No valid model exists. Nothing was saved because no model beat the rule engine, and the only compatible training data (OEP) cannot be redistributed and has unconfirmed publication terms, so an exported artefact would be an OEP-derived file.
2. Three participant-independent tests show no gain from learned weights, so a combination has nothing to add; any mixing weight would be invented.
3. The two scores are on different scales (v2 is a 0–100 index; an LR output is an uncalibrated logit), and the LR inputs are the rule engine's own groups, so a sum would double-count the same evidence.
A combination can be revisited when labelled sessions from GlassBox's own signals exist and a pre-registered participant-independent comparison against v2.1 has a lower confidence bound above zero.

Note on the weights: 0.5 / 0.3 / 0.2 are **rank** weights applied to the groups sorted by strength (strongest group 0.5, next 0.3, weakest 0.2). They are not fixed to attention, presence and focus respectively.

## What the numbers say about cheating detection

- Pre-registered comparison (`docs/final/F02_PREREGISTRATION.md`, `research/final/results/f02_summary.json`): v2.0 − v1 ranked AUROC = −0.009 [−0.036, +0.017]. v2 is non-inferior to v1 (margin −0.05) and not better. v2 is a correctness improvement (seven defects), not a detection improvement.
- Both engines are near chance on OEP (0.53–0.55). The operating-point table (`f02c_operating_points.csv`) shows that at the MEDIUM threshold (30) v2.1 scores 68.0% of normal windows and 68.9% of annotated windows at or above it. The level carries essentially no information about the annotations on this dataset.
- Alert burden: the live v2.1 engine spends 69.8% of OEP ticks at MEDIUM or above (v2.0: 73.5%), against 33.8% for v1 (`f02_summary.json`, `f02b_summary.json`). The thresholds were deliberately not retuned on OEP.
- Head-pose deviation from the personal baseline is the single most consistent signal (ranked AUROC 0.604 [0.564, 0.650], 0.594 at the app's 1 sample/s rate), but its selection-adjusted advantage over the engine is not established. It is offered only as a review-priority aid.

## Datasets and their limits

| Dataset | Used for | Limit |
|---|---|---|
| OEP (24 subjects; 15 actors, 9 examinees; cheating acted or proctor-induced) | The only cheating-interval evaluation | Annotation types 1, 2, 3, 5, 6 are undocumented; no browser signals, so focus loss is untested; 24 subjects give wide intervals; **publication permission unconfirmed** (`docs/OEP_LICENCE_STATUS.md`). |
| MPIIFaceGaze, UPNA Head Pose | Component validation | On-screen gaze and sensor head pose only; no cheating labels. |
| FairFace | Face-detection reliability by group | Stills, not video. Detection rates 89.3–95.1% by perceived-race group; under simulated low light one group loses a further 3.2–4.8 points. |
| Mendeley suspicious-behaviours table | Leakage analysis only | No subject structure; label-leaking columns. |

No real pilot-session data exists. Synthetic scenarios are used for tests and demonstrations and are never used as evidence of predictive performance.

## Known limitations

- No validation on real GlassBox sessions or real examinees; no estimate of real-world false-alarm rate.
- The score is heuristic. Weights, gates and thresholds are design choices, fixed before any v2 result was seen, not fitted.
- Looking away, head movement, leaving the frame and losing focus have innocent causes (thinking, notes allowed, a technical fault, a disability, an interruption). A high score is a reason to look, not a finding.
- Face detection is less reliable for some groups and in low light; an undetected face cannot be calibrated or scored. A personal baseline reduces individual differences in posture but does not correct that gap.
- Domain shift: OEP is 640×480 webcam video of acted behaviour; real exams, lighting, cameras and screens differ.
- No authentication; the demo sign-in is not a security control. Stored data (student name, e-mail, signals, episodes, scores) has no retention limit or delete endpoint.
- Browser compatibility, calibration usability and live frame rate have not been measured.

## Open items that need a person or new data

1. A consented pilot (`docs/PILOT_PROTOCOL.md`), after ethics approval. It is the only route to evidence on GlassBox's own signals and to any learned weights.
2. A live camera run-through after these changes (calibrate, look away, tab away, end, review).
3. Check with a camera that the baseline now clears at session end and that recalibrating for the next session works (`ARCHITECTURE.md`).
4. Confirm OEP terms, or remove OEP-derived results from anything shared externally.
5. Add a retention rule and a delete-session function before real participants are involved.
