# GlassBox architecture and data flow

This describes what the code on branch `glassbox-flagship` actually does. Statements about what is validated live in [`EVIDENCE_AND_LIMITATIONS.md`](EVIDENCE_AND_LIMITATIONS.md). The score definition is in [`RISK_SCORE_SPEC.md`](RISK_SCORE_SPEC.md).

## What is deployed, and what is offline

| Part | Status | Where |
|---|---|---|
| Webcam sensing (face, iris, head pose) with MediaPipe FaceLandmarker | Live, in the browser | `src/modules/vision/` |
| One learned component: a ridge gaze-angle estimator (9 fixed coefficients plus an intercept, trained on MPIIFaceGaze) | Live, in the browser | `src/modules/vision/linearGaze.js`, `research/models/linear_gaze_v1.json` |
| Personal baseline from a 33 s calibration | Live, in the browser | `src/modules/vision/baselineMath.js`, `visionTracker.js` |
| Evidence episodes (gated, temporal) | Live | `src/evidence/` |
| **Risk index v2** (the score the user sees) | Live, **rule-based, fixed weights** | `src/assessment/` |
| Risk engine v1 (frozen) | Live, computed alongside only for comparison; never used for a decision | `src/risk/` |
| Head-pose review priority ("segments to review first") | Live, in session review | `src/review/reviewPriority.js` |
| Session storage (SQLite) and review pages | Live, local | `server/`, `src/pages/` |
| Logistic regression, random forest, gradient boosting, nested model selection, learned weights over v2 groups | **Offline experiments only; not deployed; nothing saved for inference** | `research/`, `docs/results_2/`, `research/final/f05_*` |

No machine-learned cheating classifier exists in the application.

## Data flow

```
webcam ─► MediaPipe (browser) ─► landmarks ─► gaze z, head-pose deviation, face present/absent
browser events (focus, tab) ──────────────────────────────┐
                                                           ▼
   signals (type, value, timestamp) ─► EvidenceEngine ─► episodes (closed + ongoing)
                                                           │
   ObservationMonitor (what could be observed) ────────────┤
                                                           ▼
                              AssessmentEngine.update(now), once per second
                       channels ─► groups (attention / presence / focus)
                       ─► ordered weighted average 0.5 / 0.3 / 0.2 ─► score 0–100
                       + reliability, state, level (with hysteresis), reasons
                                                           │
                          PersistenceManager (throttled) ──► Express API ──► SQLite
                                                           │
                              Session history / detail pages (human review)
```

Raw video never leaves the browser. A search of `src/` finds no frame export (no canvas readback, `toBlob`, `MediaRecorder` or upload of image data); the server receives only derived numbers: signal values, evidence episodes and risk rows. The database also holds the student name and e-mail entered in the demo sign-in.

## Per-session independence

`AssessmentPipeline.start()` resets the evidence engine, both risk engines and the assessment, and starts a new observation clock. Nothing from an earlier session carries over into the score (`research/tests/assessment.test.mjs`, "restarting a session does not leak state").

**Baseline.** The personal baseline lives in the vision tracker, which keeps running between sessions in one page load. When a session ends, App bumps a token and `VisionModule` calls `VisionTracker.clearBaseline()` (a no-op during a running calibration), so the next session must be calibrated again; the existing "not calibrated" state and Calibrate button apply, and nothing visual changed. This path is covered by unit tests but has **not been run with a real camera**.

**Persistence.** `PersistenceManager.reset()` starts a new generation: an upload still in flight from the previous session stops instead of sending or removing the new session's data, and `flush()` waits for an in-flight flush and then runs again, so the final episodes queued by `finalize()` are stored. Both were real defects, reproduced by tests before the fix (`research/tests/session_isolation.test.mjs`).

## Network boundary

The Express API (`server/server.js`) listens on `127.0.0.1:5000` only and answers browser requests only from the local front end (`http://localhost:5173` and `:4173`, and their `127.0.0.1` forms). Both can be changed with `GLASSBOX_HOST` and `GLASSBOX_ALLOWED_ORIGINS`. Before this branch the API allowed any origin on all interfaces, so any web page open in the student's browser could have read or written sessions. There is still no authentication: the demo sign-in stores only a display name.

## Defects found in the original (v1) engine

The v1 engine is kept unchanged as a comparison baseline. The audit found seven defects, each with a reproducing scenario in `research/final/scenarios.mjs`; v2 fixes all seven. Details and the full comparison are in `RISK_SCORE_SPEC.md`.

1. The fusion component never clears: it keeps its last non-zero value.
2. The score freezes between evidence events instead of decaying with time.
3. An ongoing absence or focus loss scores nothing until it ends.
4. Episodes still open at session end were lost.
5. Gaze and head pose were counted twice (separately and again in fusion).
6. Episode strength saturated at 5 s, so a two-minute absence weighed the same as a five-second one.
7. A dead camera read as calm behaviour; v2 reports `INSUFFICIENT_EVIDENCE` instead.

## Tests and checks

`npm test` (48 tests): risk computation and explanation consistency, session isolation, baseline construction, evidence gating, persistence throttling, review priority (parity with the offline experiment), browser-signal handling, the API (including validation and the CORS policy). `research/final/e2e_headless.mjs` runs the real server and client modules without a browser (9 checks). None of this exercises a real camera, MediaPipe in a browser, or browser compatibility.
