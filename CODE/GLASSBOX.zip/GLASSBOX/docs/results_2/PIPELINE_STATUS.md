# GlassBox pipeline status

Audit of the seven-stage design against the code on branch `pipeline-completion` (created from `ai-completion` at `50fcc15`; baseline `76ea544` untouched). Status is based on reading the source, running the tests (`npm test`: 7/7 pass; `npx eslint .`: exit 0) and the experiments in this folder. No source file was modified.

![Pipeline status](figures/pipeline_stage_status.png)

| Stage | Where it lives | Status | Evidence |
|---|---|---|---|
| 1 Input and signal collection | `src/modules/vision/VisionModule.jsx`, `src/modules/browser/browserSignalCollector.js`, `server/server.js` | Implemented | Browser-signal unit test passes. The camera path was not re-run in this audit (no webcam use); earlier records are in `docs/WEBCAM_SMOKE_TEST.md`. |
| 2 Vision features (MediaPipe) | `src/modules/vision/visionTracker.js`, `linearGaze.js`, `headPoseMath.js` | Implemented, validated | Gaze estimator +0.062 / +0.059 AUROC vs the previous signal (MPIIFaceGaze, LOSO; `research/results/exp09_linear_gaze.csv`). Head-pose MAE 0.58–1.27° vs a magnetic sensor (UPNA; `exp11_upna_headpose.csv`). JS/Python parity tests pass. |
| 3 Individual calibration | `visionTracker.js` (8 s natural + 18 s guided + 7 s natural), `src/evidence/deviation.js` | Implemented, validated | On OEP, baseline length 15–240 s leaves AUROC unchanged within CIs ([ablation](figures/ablation_calibration_duration.png)), which supports the app's short calibration. |
| 4 Temporal analysis | `src/evidence/evidenceEngine.js` (gated episodes), `src/risk/fusionEngine.js` (5-s window), `src/risk/riskEngine.js` (120-s decay) | Implemented; more smoothing gives no gain | Extra causal smoothing lowers the engine's AUROC slightly; smoothing the LR output gives no gain ([figure](figures/stage4_output_smoothing.png)). |
| 5 Fusion and classification | `riskEngine.js` (equal 0.20 weights); LR in `research/exp12/14` and `docs/results_2/scripts/s10`/`s13` | Rule engine in the app; LR is research only | Engine AUROC 0.532 [0.442, 0.629]. LR learning the engine's weights: −0.002 [−0.084, +0.077] ([figure](figures/stage5_learned_fusion_vs_rule_engine.png)). A fair, selection-adjusted comparison of every candidate (E7) scores 0.602 [0.566, 0.645], a gain over the engine that is **not established** (+0.057 [−0.002, +0.120]); blind selection favours head-pose deviation over LR in 20/24 folds ([figure](figures/final_model_selection.png)). No model shows reliable cheating discrimination, so none is integrated. See [INTEGRATION_PLAN.md](INTEGRATION_PLAN.md) for the two options awaiting approval. |
| 6 Explainable risk output | `riskEngine.js` (`components`, `buildReasons`), `src/components/ExplanationPanel.jsx` | Implemented, traceable | Logged sessions: score, reasons and level consistent with stored components in 7/7 sessions. Current code: 100% of 89,568 replayed risk rows traceable to persisted evidence ([figure](figures/explainability_logged_traceability.png)). |
| 7 Session history and human review | `src/pages/Sessions.jsx`, `SessionDetail.jsx`, `GET /api/sessions`, `src/api/persistenceManager.js` | Implemented; one defect found | 2,366/2,366 in-session evidence episodes persisted in the headless replay. **Defect:** episodes still open at session end are emitted after the session is marked inactive, so they are not stored (5/24 replays, all head-pose episodes). |

## Changes proposed for approval (not applied)

1. **Persist the final open episodes (Stage 7).** In `src/App.jsx` `handleEndSession`, `sessionActiveRef.current = false` (line 627) runs before `evidenceEngineRef.current?.reset()` (line 640). The reset emits the open gaze and head-pose episodes, but the `onEvidence` callback only persists while the session is active (line 284), so those episodes are dropped.
   - **Proposed fix:** call `evidenceEngineRef.current?.reset()` immediately before setting `sessionActiveRef.current = false`. Both steps are synchronous, so no new signal can arrive between them.
   - **How to verify:** rerun `scripts/s12_persistence_check.py`. `open_episodes_emitted_at_end` should then be persisted.
2. **Update a stale comment (documentation only).** `src/risk/riskEngine.js` lines 18–22 say "Later Logistic Regression will learn the weights from data." The evidence now says LR does not improve on equal weights for OEP. The proposal is to reword the comment to point to `docs/results_2/EXPERIMENT_REPORT.md`; behaviour would not change.

Neither change has been made. Both need your approval.

## What remains

- **Live validation:** a pilot with consenting participants under `docs/PILOT_PROTOCOL.md` is the only way to measure detection on GlassBox's own sessions. It needs the camera and people, so it is out of scope here.
- **Exploratory hypothesis:** simple head-pose deviation is the only signal whose interval excludes chance on OEP (exp14 heuristic 0.604 [0.520, 0.675]; head gate ≥12° 0.581 [0.519, 0.645]). It was selected after many comparisons, so it should be pre-registered and tested on new data before any change to the engine.
- **Dataset permission:** OEP publication permission is still unconfirmed (`docs/OEP_LICENCE_STATUS.md`). Every OEP-derived figure carries that caveat.
- **Not done:** browser runtime/throughput, because measuring it needs the live app with the camera.
