# Final report: GlassBox pipeline completion and evaluation (results_2)

Branch `pipeline-completion`, created from `ai-completion` at `50fcc15`; baseline `76ea544` untouched. No application source file was modified at any point in this work. Nothing has been committed, merged, reset or pushed. All deliverables live under `docs/results_2/`.

## 1. What was asked and what was delivered

The task was to evaluate GlassBox's complete intended seven-stage pipeline — not just audit the current app — including the planned Logistic Regression fusion, using participant-independent validation and honest reporting, and to recommend a final model backed by evidence.

Delivered:
- An audit of all seven stages against the actual code and test suite (`npm test`: 7/7 pass; `npx eslint .`: exit 0).
- Eight experiments (E1–E8), all executed, all leave-one-subject-out on the OEP dataset (24 subjects), with subject-level bootstrap 95% CIs.
- 15 figures, a figure index, two reusable scripts (`run_all_results2.py`, `verify_results2.py`), and five reports (`README.md`, `RESULTS_SUMMARY.md`, `EXPERIMENT_REPORT.md`, `PIPELINE_STATUS.md`, `INTEGRATION_PLAN.md`) plus this one.

## 2. Pipeline status, stage by stage

| Stage | In the live app | Evaluated in research | Status |
|---|---|---|---|
| 1 Input & signals | Yes (webcam, tab/focus events, session records) | — | Implemented; camera path not re-run in this audit |
| 2 MediaPipe vision features | Yes | Gaze +0.062/+0.059 AUROC vs prior signal (MPII); head-pose MAE 0.58–1.27° (UPNA) | Implemented, validated |
| 3 Personal calibration | Yes (33 s) | 15–240 s baseline: AUROC unchanged within CIs | Implemented, validated |
| 4 Temporal analysis | Yes (gated episodes, 5-s fusion, 120-s decay) | Extra smoothing: no gain (E4); E7/E8 below | Implemented; no gain from more |
| 5 Fusion & classification | **Rule engine only, equal 0.20 weights** | LR (components / signals / both), RF, GB, and a fair selection-adjusted comparison (E7) | **LR not integrated** — see §3 |
| 6 Explainable risk output | Yes | 100% of logged and replayed risk rows traceable to stored components/evidence | Implemented, verified |
| 7 Session history & review | Yes | Persistence verified headless; one defect found | Implemented; 1 fix proposed, not applied |

## 3. Is Logistic Regression fusion integrated? No — and here is the full, fair evaluation

This is the central question from your original request, evaluated as completely as the data allows.

**E3 (direct Stage-5 substitution).** LR learning the engine's own component weights: AUROC difference vs the engine is **−0.002 [−0.084, +0.077]**. LR combined with signal features: **−0.023 [−0.122, +0.083]**. Every option sits at 0.51–0.55 AUROC. No gain.

**E7 (fair, selection-adjusted comparison of the whole pipeline).** Rather than compare LR to the engine alone, every plausible final-model candidate — the rule engine, two simple rule-based scores, and three LR variants — was compared using **nested leave-one-subject-out**: for each of the 24 held-out subjects, the best candidate is chosen using only the other 23 subjects (with its own inner leave-one-subject-out for the LR variants), then applied once to the held-out subject. This removes the optimism of picking the best-looking model after seeing all the results.

| Model | AUROC (within-subject ranks) [95% CI] | vs rule engine [95% CI] |
|---|---|---|
| Rule engine (live app) | 0.545 [0.485, 0.610] | — |
| LR on engine components | 0.552 [0.497, 0.610] | +0.007 [−0.056, +0.071] |
| LR on signal features | 0.583 [0.545, 0.626] | +0.038 [−0.022, +0.098] |
| LR combined | 0.563 [0.517, 0.608] | +0.018 [−0.049, +0.082] |
| Max head-pose deviation (rule-based) | 0.604 [0.564, 0.650] | +0.059 [+0.011, +0.111]* |
| **Nested-selected final model** | **0.602 [0.566, 0.645]** | **+0.057 [−0.002, +0.120]** |

\*Not selection-adjusted — this candidate was identified from an earlier experiment (exp14) before E7, so this interval is optimistic. The nested row is the fair estimate.

**Result of the fair comparison:** blind selection chose **max head-pose deviation in 20 of the 24 folds** and LR in only 4. The selection-adjusted final model scores above chance (0.602), but its improvement over the live rule engine is **not statistically established** — the confidence interval on the difference runs from −0.002 to +0.120, touching zero.

**Conclusion, stated plainly:** Logistic Regression fusion, as originally planned for Stage 5, does not reliably outperform the rule engine on this dataset and was not favoured by a fair, unbiased selection procedure. **It is not integrated into the live application, and that decision is the evidence-based one, not a shortcut.** The live app still uses the rule engine exclusively.

**E8** checked whether the one candidate that *is* favoured (head-pose deviation) survives the live app's actual 1-sample/s persistence rate (vs the 5 fps used in training): it does, with only a small drop (ranked AUROC 0.604 → 0.594), though at that rate its own gap to the engine also touches zero (+0.049 [−0.004, +0.106]).

## 4. Recommendation

- **Keep the rule engine as the live risk score.** Nothing tested beats it by an established margin.
- **Do not integrate LR fusion as designed.** The evidence does not support it; forcing it in would not make the app better, only more complex and harder to explain.
- **Optional, pending your approval:** add head-pose deviation as a *review-priority* aid (not a replacement risk score) — Option A in `INTEGRATION_PLAN.md`. It is simple, explainable, and is what unbiased selection favours. Option B (an experimental LR shadow score, clearly labelled, off by default) is available if you want to preserve the original Stage-5 design intent for future retraining on real GlassBox data — it is not a recommendation that it will perform better.
- **Separately, a one-line fix is proposed** for a Stage-7 defect: episodes still open when a session ends are not persisted (`PIPELINE_STATUS.md`). Not applied.

No source code changes have been made for any of this. All are described precisely in `INTEGRATION_PLAN.md` and `PIPELINE_STATUS.md` and await your approval.

## 5. Verification

```
python -X utf8 docs/results_2/scripts/verify_results2.py <path-to-a-copy-of-glassbox.db>
```

independently re-reads the underlying CSVs/JSON (not the generating scripts) and checks: s01 reproduces committed `exp14` results exactly; every s10/s13 AUROC recomputes from saved per-window scores; the engine's five components recompose to its emitted score in every frame; the s13 nested selection never used the held-out subject's own data (checked fold-by-fold) and its chosen candidate matches the inner-CV argmax; s14's head-pose scores agree with s13 and the underlying window features; the logged-session checks (E5) recompute from the database when a copy is supplied; every figure opens and is at least 2,000 px wide; every figure is listed in the README and the figure index; every relative link in all six documents resolves.

**Result of this session's run: `273/273` checks passed, with no failures**, including the fold-by-fold check that the nested selection in E7 never saw the held-out subject's own data, that its chosen candidate always matches the inner-CV argmax, and that E8's scores agree with E7 and the underlying window features.

## 6. Limitations carried through every result

- OEP publication permission is unconfirmed (`docs/OEP_LICENCE_STATUS.md`). All of E1–E4, E7, E8 are OEP-derived.
- 24 subjects give wide confidence intervals; several reported effects (notably the non-adjusted head-deviation-vs-engine gap) straddle or sit close to the boundary of significance and should not be over-read.
- The logged-session checks (E5) use developer technical-test sessions with no ground truth; they demonstrate traceability, not detection accuracy.
- No experiment here used the webcam or live GlassBox sessions with real examinees; that validation requires a consented pilot (`docs/PILOT_PROTOCOL.md`).
- Gate-threshold (E2b) and frame-level smoothing (E2c) use simplified proxy scores, not the full engine; E3/E4/E7/E8 use the real engine or its real components.

## 7. Live-demo readiness

Ready now: the full pipeline runs end-to-end (input → vision → calibration → temporal → rule-based fusion → explainable score → session history/review), with tests and lint passing.

Before a live demo:
1. Decide on the two pending approvals (persistence fix; Option A/B in the integration plan).
2. One live run-through with the camera (start session → calibrate → generate a look-away/tab-switch → end session → check Session History/Detail shows it correctly) — needs you present, since no camera use has occurred in this audit.
3. Start the server and front end (`npm run dev` + the Express server) and confirm the new session appears via `GET /api/sessions`.
4. Present the risk score accurately: a prompt for human review, not a cheating probability, with the OEP permission caveat visible if OEP-derived charts are shown.

Not required for a demo, but still open: browser runtime/frame-rate measurement, and any accuracy claim about real GlassBox users (both need live camera sessions, out of scope here).
