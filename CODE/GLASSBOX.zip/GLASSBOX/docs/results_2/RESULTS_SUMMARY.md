# Results summary (results_2)

**In one sentence:** GlassBox's sensing, calibration, explanation and review stages work and are verified, but no tested method — the rule engine, logistic regression learning its weights, extra smoothing, or other models — detects cheating intervals on OEP reliably better than chance. The architecture is therefore kept as designed, with the human reviewer making every decision.

## What is supported by evidence

1. **Learned fusion does not beat the rule engine (Stage 5).** When logistic regression learns the weights of the engine's own components, AUROC changes by −0.002 [−0.084, +0.077]. With all signal features combined, the change is −0.023 [−0.122, +0.083]. Every option is near chance (0.51–0.55). → [figure](figures/stage5_learned_fusion_vs_rule_engine.png)
2. **The learned weights are small and unstable.** Inner CV chose maximum regularisation in 16 of 24 folds. Only the multi-signal-fusion component gets a consistently positive weight. → [figure](figures/stage5_learned_component_weights.png)
3. **More smoothing does not help (Stage 4).** Extra causal smoothing lowers the engine's AUROC by 0.015–0.022, and smoothing the LR output gives no gain. → [figure](figures/stage4_output_smoothing.png)
4. **Calibration length does not matter in the 15–240 s range (Stage 3).** All intervals overlap. This supports the app's 33-s calibration. → [figure](figures/ablation_calibration_duration.png)
5. **Head pose carries what signal exists; gaze alone does not.** Gaze-gate scores are 0.44–0.51; head-gate scores reach 0.58. These are exploratory and selected from a grid. → [figure](figures/ablation_gate_thresholds.png)
6. **Performance varies widely between people.** Within-subject AUROC runs from about 0.3 to 0.87 for every scorer, unrelated to face-detection rate. → [figure](figures/oep_participant_variability.png)
7. **Most flags are false alarms at a one-third review budget.** The engine flags 416 normal windows against 227 annotated ones, so flags need human review. → [figure](figures/oep_confusion_matrices.png)
8. **Explanations are traceable (Stage 6).** In the logged sessions, every stored score, reason and level is consistent with its stored components. In the current code, 100% of 89,568 replayed risk rows trace back to persisted evidence. → [figure](figures/explainability_logged_traceability.png)
9. **One persistence defect (Stage 7).** Episodes still open when a session ends are not stored (5 of 24 replays). A one-line fix is proposed in [PIPELINE_STATUS.md](PIPELINE_STATUS.md), pending approval.
10. **A fair, selection-adjusted comparison of the whole pipeline finds no established winner (Stages 4–5).** Choosing the best candidate blind on 23 subjects and testing on the 24th scores 0.602 [0.566, 0.645] — above chance — but its gain over the live rule engine is not established: +0.057 [−0.002, +0.120], an interval that touches zero. Blind selection favours **head-pose deviation from the personal baseline** (chosen in 20/24 folds) over LR fusion (chosen in 4/24). That scorer still works, only slightly weaker, at the app's actual 1-sample/s data rate (ranked AUROC 0.594 vs 0.604 at full rate). → [figure](figures/final_model_selection.png)

## Recommendation

- **Keep the rule engine as the live risk score.** No tested alternative beats it by an established margin.
- **Consider head-pose deviation as a review-priority aid, not a replacement.** It is what unbiased selection favours, it holds up at the app's real sampling rate, and it is simple to explain to a reviewer. See Option A in [INTEGRATION_PLAN.md](INTEGRATION_PLAN.md) — not yet approved or applied.
- **Do not integrate LR fusion as designed in Stage 5.** It is not favoured by blind selection (4/24 folds) and its own improvement over the engine is not established (+0.018 [−0.049, +0.082] combined). Option B in the integration plan keeps it available as an optional, clearly-labelled shadow score if you want to preserve that part of the original design for future retraining — it is not a recommendation to rely on it.

## What is not shown

- **Cheating detection:** not demonstrated on any dataset. GlassBox's risk score is a prompt for review, not a probability or a verdict.
- **Real GlassBox users:** no ground-truth evaluation exists. The logged sessions are developer technical tests.
- **Browser runtime:** not measured, because that needs the camera.

## Caveats for any presentation

- OEP publication permission is unconfirmed. Results E1–E4 are OEP-derived.
- The 95% intervals are subject-level bootstrap intervals over 24 people, so they are wide.
- The gate-threshold grid and the frame-level smoothing ablation use simplified scores, not the full engine. The engine-level versions are E3/E4.
