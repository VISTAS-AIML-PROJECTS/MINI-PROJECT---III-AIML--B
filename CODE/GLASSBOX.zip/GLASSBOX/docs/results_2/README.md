# GlassBox results 2: pipeline completion and deeper evaluation

This folder adds new experiments and figures. It does not duplicate [docs/results](../results/README.md). Every experiment here was executed on existing project data: cached OEP features, committed experiment outputs, and a read-only copy of the app database. No webcam was used, no data was downloaded, and no source file was modified.

- [PIPELINE_STATUS.md](PIPELINE_STATUS.md): status of the seven pipeline stages, plus code changes proposed for approval.
- [RESULTS_SUMMARY.md](RESULTS_SUMMARY.md): what the evidence supports, in one page.
- [EXPERIMENT_REPORT.md](EXPERIMENT_REPORT.md): configuration, data, protocol, metrics and limitations for experiments E1–E6.
- [FIGURE_INDEX.md](FIGURE_INDEX.md): every figure with its purpose, data source and takeaway (generated).
- `figures/`: 14 PNG figures (2,100–3,200 px wide).
- `comparisons/`: tables, per-window predictions and scores, check files, run logs.
- `scripts/`: generators, Node replay harnesses, the runner and the verifier.

## Figures

| Figure | Stage | Experiment |
|---|---|---|
| `pipeline_stage_status.png` | All | Status and evidence for each stage |
| `oep_roc_pr_curves.png` | 5 | E1: ROC and precision–recall curves, four scorers |
| `oep_confusion_matrices.png` | 5 | E1: confusion matrices at a 33% review budget |
| `oep_participant_variability.png` | 5 | E1: per-participant AUROC; detection rate vs AUROC |
| `oep_error_analysis.png` | 5 | E1: recall by annotation type; false-positive drivers; actors vs real examinees |
| `ablation_calibration_duration.png` | 3 | E2a: calibration length 15–240 s |
| `ablation_gate_thresholds.png` | 4 | E2b: gaze/head gate grid (label-free proxy score) |
| `ablation_temporal_vs_instantaneous.png` | 4 | E2c: frame-level smoothing of a combined score |
| `ablation_feature_groups.png` | 5 | E2d: leave-one-group-out and single-group LR |
| `final_model_selection.png` | 4–5 | E7: selection-adjusted comparison of every final-model candidate vs the rule engine |
| `stage5_learned_fusion_vs_rule_engine.png` | 5 | E3: LR learning the fusion weights vs the rule engine |
| `stage5_learned_component_weights.png` | 5 | E3: fold-by-fold learned weights |
| `stage4_output_smoothing.png` | 4 | E4: smoothing the engine score and the LR output |
| `explainability_logged_traceability.png` | 6 | E5: consistency checks on the logged sessions |
| `explainability_logged_session_timeline.png` | 6–7 | E5: a logged session with its evidence and reasons |

## Reproduce and verify

```
# copy the database first; the scripts never open the live file
cp glassbox.db* <scratch>/
python -X utf8 docs/results_2/scripts/run_all_results2.py <scratch>/glassbox.db
python -X utf8 docs/results_2/scripts/verify_results2.py  <scratch>/glassbox.db
```

`verify_results2.py` re-reads the underlying files and checks the following:
- s01 reproduces `research/results/exp14_oep_improvements.csv`.
- Every Stage-5 AUROC recomputes from the saved window scores.
- The engine's components recompose to its score.
- The logged-session checks recompute from the database.
- Every figure opens and is registered.
- Every link in these documents resolves.

The verifier also requires this README to list every figure. Requirements: Python 3.13 with numpy, pandas, scikit-learn and matplotlib, plus Node (for the replays).

## Reading these results honestly

- E1–E4 use OEP, whose publication permission is unconfirmed (`docs/OEP_LICENCE_STATUS.md`).
- The logged sessions are developer technical tests with no ground truth. They show traceability, not accuracy.
- Gate-grid (E2b) and frame-smoothing (E2c) scores are simplified proxies. E3/E4 use the real engine.
