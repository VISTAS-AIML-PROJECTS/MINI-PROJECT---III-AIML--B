# Experiment report (results_2)

Every experiment below was executed in this workspace and its outputs were checked by `scripts/verify_results2.py`. Nothing here used a webcam or downloaded data. Nothing here is simulated, except where a section says so.

## Common protocol (OEP experiments: E1–E4)

| Item | Setting |
|---|---|
| Data | OEP online-exam dataset, 24 subjects (15 actors, 9 real examinees), per-frame MediaPipe features cached in `data/processed` by `research/oep_extract_features.py`. Licence "Unknown"; publication permission **unconfirmed** (`docs/OEP_LICENCE_STATUS.md`). |
| Calibration | Personal baseline from the first 120 s (label-agnostic), exactly as `research/exp12_oep_models.py`. Exception: E2a varies this length. |
| Windows | 10-s windows after calibration. Positive: ≥50% of frames annotated. Negative: 0% annotated. Mixed windows are dropped. Result: 1,956 windows, 646 positive (33%). |
| Engine | The real `src/` Evidence → Fusion → Risk engines, replayed per frame with Node. Window score = maximum risk in the window. |
| Learned models | Leave-one-subject-out. LR's C is chosen by inner subject-grouped 5-fold CV on training subjects only (`exp14.loso(..., "lr_cv")`). Features are causal: lags and EWMA use past windows only. |
| Metrics | Pooled window-level AUROC; average precision; review-budget precision/recall/F1 (flag the top 33% of each subject's windows). |
| Uncertainty | Subject-level bootstrap (resample subjects, recompute pooled AUROC). Paired differences use the same resamples. 95% percentile intervals. s01 quotes the committed exp14 intervals (2,000 resamples); s02/s10 use their own resamples (300–1,000), so bounds can differ in the third decimal for the same model (e.g. engine upper bound 0.629 vs 0.633). |
| Limitations | Annotation types 1/2/3/5/6 are undocumented. Actors and real examinees are pooled. 24 subjects give wide intervals. Results apply to OEP's recording setup, not to GlassBox's own users. |

## E1 – Model comparison, error analysis and participant variability (`s01_oep_predictions.py`)

- **Question:** Beyond a single AUROC, how do the rule engine and LR/RF/GB behave?
- **Outputs:** [ROC/PR curves](figures/oep_roc_pr_curves.png), [confusion matrices](figures/oep_confusion_matrices.png), [per-participant spread](figures/oep_participant_variability.png), [error analysis](figures/oep_error_analysis.png), `comparisons/oep_window_predictions.csv`, `oep_error_analysis.csv`, `oep_per_subject_auroc.csv`.
- **Check:** The predictions reproduce `research/results/exp14_oep_improvements.csv` exactly (all four AUROCs to 1e-9; engine confusion counts 227/416/419/894).
- **Results:**

  | Model | AUROC [95% CI] | AP | Recall @33% |
  |---|---|---|---|
  | Rule engine | 0.532 [0.442, 0.629] | 0.364 | 0.35 |
  | LR | 0.548 [0.436, 0.648] | 0.405 | 0.42 |
  | RF | 0.562 [0.444, 0.669] | 0.382 | 0.41 |
  | GB | 0.524 [0.416, 0.613] | 0.365 | 0.39 |

  - Prevalence is 0.33, so chance AP is 0.33.
  - Within-subject AUROC ranges from about 0.3 to 0.87 (medians 0.58–0.61). The spread is unrelated to face-detection rate (Spearman +0.06, n = 23). Subject 20 has no positive windows; subject 22 has one.
  - The learned models flag annotation types 1 and 6 above chance (0.42–0.67). Type 3 is flagged below chance by every scorer.
  - False positives are only slightly enriched for face-missing windows: 12–18% vs 11% of all normal windows.
- **Limitation:** Type-level recall uses small groups (type 5: n = 11).

## E2 – Ablations (`s02_oep_ablations.py`)

- **a) Calibration duration.** Baseline from the first 15/30/60/120/240 s. Evaluation is fixed to t ≥ 240 s (1,692 windows), so every setting scores the same windows.
  - Max head deviation: 0.587–0.614.
  - LR: 0.520–0.557.
  - Max gaze z: 0.481–0.521.
  - All intervals overlap; there is no trend.
- **b) Gate thresholds.** The score is the fraction of frames above the gaze gate (z ∈ {1.5, 2, 3, 4, 5}) and/or the head gate (4–16°). This is a label-free proxy for the engine's gating, **not** the engine: varying the real gates would require editing `src/evidence/deviation.js`.
  - At the app defaults (z ≥ 3, 8°): 0.568 [0.483, 0.658].
  - Best cell (z ≥ 5, 12°): 0.581 [0.520, 0.646].
  - Gaze gate alone: 0.44–0.51.
  - The head gate carries the signal.
- **c) Temporal vs instantaneous (frame level).** Score = max(gaze z/9, head/30°, face absent), with a trailing mean over 0.2–20 s, evaluated on 111,306 frames. AUROC is 0.589 per frame, 0.590 at 1–2 s, and falls to 0.558 at 20 s.
- **d) Feature groups.** LR on 49 features (v1 + extras + temporal) gives 0.536 [0.428, 0.640].
  - Leave-one-group-out changes are −0.016 to +0.012, with intervals spanning zero. The exception is face-box size: removing it gives +0.005 [+0.001, +0.010].
  - Single-group models score 0.49–0.55.
- **Limitations:**
  - (b) and (c) use simplified scores rather than the full engine. E4 repeats (c) on the real engine.
  - The grid in (b) involves 35 comparisons, so the best cell is an optimistic estimate.

## E3 – Learned fusion, Stage 5 (`s10_stage5_fusion.py`, `replay_components.mjs`)

- **Question:** The design plans to have LR learn the fusion weights that the engine currently fixes at 0.20 each. Does that help?
- **Method:**
  1. Replay the real engines and record the five risk components per frame (111,306 frames).
  2. Parity check: the components recompose to the emitted score in every frame. Focus loss is structurally zero, because OEP has no browser events.
  3. Build window features: max/mean/end of each component, plus causal lags/EWMA.
  4. Fit LR leave-one-subject-out (as above), and compute paired bootstrap differences vs the engine (1,000 resamples).
- **Results** (AUROC; difference vs engine):
  - LR on engine components: 0.530; −0.002 [−0.084, +0.077].
  - LR on components + temporal context: 0.536; +0.004 [−0.086, +0.085].
  - LR on signal features: 0.548; +0.016 [−0.082, +0.124].
  - LR on components + signal features: 0.509; −0.023 [−0.122, +0.083].
- **Learned weights:** Inner CV chose the strongest regularisation (C = 0.01) in 16 of 24 folds. Median standardised coefficients:
  - multi-signal fusion +0.19 (positive in every fold);
  - gaze −0.09;
  - face absence −0.02;
  - head pose 0.00.
- **Conclusion:** OEP does not support replacing the equal weights. The rule engine is retained.

## E4 – Smoothing the risk outputs, Stage 4 (`s10_stage5_fusion.py`)

- **Method:** Causal EWMA on the engine's per-frame score (half-life 5/10/30/60 s; window max), and on the LR window outputs (α = 0.5, 0.25).
- **Results:**
  - Engine: −0.015 [−0.025, −0.006] at 5 s, −0.018 at 10 s, −0.022 at 30 s; intervals exclude zero up to 30 s.
  - LR output: 0.548 → 0.548 / 0.543.
- **Conclusion:** The engine's existing gating and 120-s decay are not improved by more smoothing.

## E5 – Explainability on logged sessions, Stage 6 (`s11_logged_explainability.py`)

- **Data:** The application's own database, read from a copy in read-only mode. It holds 8 sessions logged on 2026-10-01 by the developer as technical tests (7 with risk rows). They were logged with the engine of `76ea544` (same weights and reason rules as now, but no evidence decay). There is no ground truth, and no names or e-mails were read.
- **Checks per stored risk row:**
  1. The score recomposes from its components.
  2. The reasons match the engine rules.
  3. The level band matches the score.
  4. Every non-zero component has a stored evidence episode of that type at or before the row.
- **Results:**
  - Checks 1–3 pass for 100% of rows in all 7 sessions (25,801 rows).
  - Check 4 passes 100% in S1–S4, but only 95.4% in S5, 55.4% in S7 and 46.5% in S8. Those three sessions have 0–1 stored evidence rows and 2–13 stored signal rows.
  - Every session starts with zero evidence components, so the gap is not carry-over between sessions. The cause cannot be recovered from the stored data.
- **Figures:** [traceability](figures/explainability_logged_traceability.png), [annotated timeline of S4](figures/explainability_logged_session_timeline.png).

## E6 – Persistence path of the current code, Stage 7 (`s12_persistence_check.py`, `persistence_harness.mjs`)

- **Method:** The real engines and `PersistenceManager` are wired exactly as in `src/App.jsx`, with `fetch` replaced by an in-memory recorder. There is no camera, server or database. Each OEP subject's signal stream is replayed, then the App's end-of-session sequence runs.
- **Results:**
  - All 2,366 in-session evidence episodes were persisted.
  - All 89,568 persisted risk rows recompose and are traceable.
  - 55,022 of 111,306 sampled signals were stored, as designed by the per-type 1-s throttle.
  - 5 episodes still open at session end (all head-pose, subjects 2, 16, 19, 21, 24) were emitted after deactivation and not stored. The proposed fix is in `PIPELINE_STATUS.md`.
- **Limitation:** React state, the vision module and the HTTP server are not exercised.

## E7 – Selection-adjusted final model, the complete pipeline (`s13_final_model_selection.py`)

- **Question:** If we fairly let the data choose the best candidate for every pipeline stage (rule-based scores, and LR on engine components / signal features / both), what does the held-out performance look like once the optimism of "pick the best after seeing all results" is removed?
- **Method — nested leave-one-subject-out.** For each of the 24 outer folds, the held-out subject is set aside completely. The candidates are ranked on the other 23 subjects only (the learned candidates via an *inner* leave-one-subject-out over those 23, with C ∈ {0.01, 0.1, 1}); the best-ranked candidate is refit on all 23 and applied once to the held-out subject. The held-out subject never influences which candidate is chosen. Because the candidates' scores live on different scales, each subject's scores are converted to within-subject percentile ranks before pooling (approximating how a reviewer reads one person's session); raw pooled AUROC is also reported for the fixed candidates.
- **Results:**

  | Model | AUROC, within-subject ranks [95% CI] | Diff vs rule engine [95% CI] |
  |---|---|---|
  | Rule engine (app) | 0.545 [0.485, 0.610] | — |
  | Max head deviation | 0.604 [0.564, 0.650] | +0.059 [+0.011, +0.111] |
  | Face-absent fraction | 0.555 [0.498, 0.618] | +0.010 [−0.060, +0.086] |
  | LR on engine components | 0.552 [0.497, 0.610] | +0.007 [−0.056, +0.071] |
  | LR on signal features | 0.583 [0.545, 0.626] | +0.038 [−0.022, +0.098] |
  | LR combined (components + signals) | 0.563 [0.517, 0.608] | +0.018 [−0.049, +0.082] |
  | **Nested-selected final model** | **0.602 [0.566, 0.645]** | **+0.057 [−0.002, +0.120]** |

  Blind selection picked max head deviation in 20/24 outer folds and "LR on signal features, C=0.01" in 4/24 (`s13_selected_counts.csv`).
- **Interpretation:** The selection-adjusted estimate (0.602, above chance) is the honest answer to "how well would the best-performing candidate do on a new person if chosen without looking at them first." Its improvement over the live rule engine is **not established** — the 95% interval on the difference runs from −0.002 to +0.120, touching zero. The row for "max head deviation" alone shows a CI that excludes zero (+0.011 to +0.111), but that candidate was *not* chosen blind — it was singled out from exp14 before this analysis — so that interval is optimistic and the nested row is the correct one to quote. LR fusion (the original Stage-5 design) is not what selection favours most of the time, and on its own does not improve reliably (combined: +0.018 [−0.049, +0.082]).
- **Limitation:** 24 subjects give wide intervals on every row; the nested procedure is conservative but does not create statistical power the dataset doesn't have.

## E8 – Does the recommended scorer survive the app's real data rate? (`s14_head_deviation_app_rate.py`)

- **Question:** E7's best rule-based candidate, max head-pose deviation from the personal baseline, is computed here from all 5 fps of OEP frames. The live app persists `HEAD_POSE_DEVIATION` samples at most once per second (`persistenceManager.js`, `signalIntervalMs = 1000`). Does the scorer still work at that rate?
- **Method:** Re-score the same 1,956 windows using (a) all frames and (b) one frame per second (every 5th frame), no training (it is a fixed rule, so no cross-validation), subject-level bootstrap CIs.
- **Results:**

  | Scorer | Raw pooled AUROC | Ranked AUROC | Diff vs engine (ranked) |
  |---|---|---|---|
  | Rule engine (app) | 0.532 [0.442, 0.633] | 0.545 [0.485, 0.610] | — |
  | Max head deviation, all frames (5 fps) | 0.604 [0.525, 0.674] | 0.604 [0.564, 0.650] | +0.059 [+0.011, +0.111] |
  | Max head deviation, 1 sample/s (app rate) | 0.589 [0.513, 0.661] | 0.594 [0.556, 0.643] | +0.049 [−0.004, +0.106] |

- **Conclusion:** The scorer degrades only slightly at the app's persisted rate (0.604 → 0.594 ranked AUROC) and its interval still sits just above or at chance difference from the engine. This supports Option A in `INTEGRATION_PLAN.md` (a review-priority aid, not a replacement for the risk score), but the engine-vs-head-deviation gap at 1 Hz is no longer clearly distinguishable from zero.

## Not completed, and why

| Planned item | Reason |
|---|---|
| Browser runtime / frame-rate measurement | Needs the live app with a camera. |
| Detection accuracy on GlassBox's own sessions | Needs a consented pilot (`docs/PILOT_PROTOCOL.md`); the logged sessions have no ground truth. |
| Further MPIIFaceGaze / UPNA / FairFace breakdowns | Already covered by `docs/results` (exp02, exp09, exp11). Further splits would not change any pipeline decision, so they were deprioritised. |
| Varying the real engine's gate thresholds | Would require editing frozen source (`src/evidence/deviation.js`); E2b uses a labelled proxy instead. |
| Integrating any model into the live app | Evidence does not establish a reliable improvement (E7); `INTEGRATION_PLAN.md` describes the change needed if approved, but nothing was applied. |
