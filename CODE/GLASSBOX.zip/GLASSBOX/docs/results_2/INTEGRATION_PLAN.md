# Integration plan for the evidence-supported final model (awaiting approval; nothing applied)

## The recommendation, from the measurements

| Candidate (OEP, 24 subjects, leave-one-subject-out) | AUROC, within-subject ranks [95% CI] | vs live rule engine [paired 95% CI] | Source |
|---|---|---|---|
| Live rule engine (equal weights) | 0.545 [0.485, 0.610] | — | s13 |
| **Selection-adjusted final model** (chosen blind on 23 subjects per fold) | **0.602 [0.566, 0.645]** | +0.057 [−0.002, +0.120] | s13 |
| Max head-pose deviation, all frames | 0.604 [0.564, 0.650] | +0.059 [+0.011, +0.111]* | s13/s14 |
| Max head-pose deviation, 1 sample/s (app's persisted rate) | 0.594 [0.556, 0.643] | +0.049 [−0.004, +0.106] | s14 |
| LR on signal features (planned Stage-5 fusion) | 0.583 [0.545, 0.626] | +0.038 [−0.022, +0.098] | s13 |
| LR combined (engine components + signals) | 0.563 [0.517, 0.608] | +0.018 [−0.049, +0.082] | s13 |

\* This row is not selection-adjusted: head-pose deviation was singled out after earlier results (exp14). The honest estimate of "pick the best model" is the nested row. That procedure chose max head-pose deviation in 20 of 24 folds and LR on signal features in 4.

**What this supports:**
- Keep the transparent rule engine as the live risk score; nothing beats it by an established margin.
- Add **personal-baseline head-pose deviation per 10-s segment** as a *review-priority* aid. It is the scorer that blind selection picks, its held-out AUROC interval lies above chance, it keeps that performance at the app's own data rate, and it is simple enough to explain to a reviewer ("the student's head was turned up to N° from their own baseline").
- Logistic Regression fusion (the original Stage-5 plan) does not improve reliably and should **not** replace the engine.

These are modest effects (AUROC around 0.6) on one dataset of actors and examinees. They justify prioritising what a human reviews first. They do **not** justify any automatic judgement.

## Option A (recommended): head-pose review priority in session review

| Step | File | Change |
|---|---|---|
| 0 | `src/App.jsx` | Apply the approved end-of-session fix first (`PIPELINE_STATUS.md`, change 1), so the last episodes are stored. |
| 1 | **new** `src/review/reviewPriority.js` | `segmentHeadDeviation(signals, windowMs = 10000)` returns one row per 10-s segment: `{ start, end, maxDeg, axis }`, where `maxDeg` is the maximum over stored `HEAD_POSE_DEVIATION` samples of max(yaw, pitch, roll). The values already are absolute degrees from the personal baseline (`visionTracker.js` lines 985–1006). This is a pure function with no state. |
| 2 | `src/pages/SessionDetail.jsx` | Add a "Segments to review first" list: the top third of segments by `maxDeg`, with timestamps, the axis and the degrees, labelled *"Behavioural priority for human review – not evidence of misconduct."* The existing risk view stays unchanged. |
| 3 | server | No change. `GET /api/sessions/:id` already returns the stored signals. |
| 4 | **new** `research/tests/review_priority.test.mjs` | Parity test: on stored OEP windows, the JS function reproduces `s14` `head_max_1hz` exactly. Plus unit tests for empty, absent-face and single-sample segments. |
| 5 | docs | Note the change and its evidence (s13/s14) in `docs/METHODOLOGY.md`. |

- **Effort:** about 1–2 hours plus tests.
- **Risk:** low. The change is additive, the live risk score is untouched, and it can be removed by deleting one component.

## Option B (optional, for design fidelity): LR as a shadow scorer

This keeps Stage 5's learned fusion in the running system, so it can be retrained on GlassBox's own pilot data, without claiming it performs better.

| Step | File | Change |
|---|---|---|
| 1 | **new** `research/export_lr_fusion.py` → `research/models/lr_fusion_v1.json` | Fit LR (signal features, C = 0.01, the configuration selected in 4/24 folds) on all 24 OEP subjects. Export the scaler means/SDs, coefficients, intercept and feature list. This follows the existing `export_linear_gaze_js.py` pattern. |
| 2 | **new** `src/risk/learnedFusion.js` (generated) | Compute the same window features from the live signal stream and output a 0–1 shadow score. |
| 3 | `src/App.jsx`, `src/components/TechnicalDetails.jsx` | Show the shadow score only in Technical Details, behind an "experimental" flag that is off by default, and log it with the risk record. |
| 4 | **new** parity test | JS reproduces the Python predictions on stored windows to 1e-9. |

- **Effort:** about half a day.
- **Risk:** moderate. The JS window features must match the Python ones exactly, and the score must never be presented as a probability of cheating.

## What I will not do without your approval

- Edit any file under `src/`, `server/` or `research/`.
- Apply either option.
- Change the engine's weights or thresholds.
- Commit, merge or push.

Reply with "approve A", "approve A and B", or changes, and I will implement, test and report.
