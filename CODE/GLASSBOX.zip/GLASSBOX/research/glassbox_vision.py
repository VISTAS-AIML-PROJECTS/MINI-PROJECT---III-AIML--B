"""Line-for-line Python port of src/modules/vision/gazeMath.js and headPoseMath.js, plus a
MediaPipe FaceLandmarker wrapper configured identically to the web app (visionTracker.js).
Parity with the JS implementation is checked by tests/test_parity.py."""
import numpy as np
import mediapipe as mp
from mediapipe.tasks import python as mpt
from mediapipe.tasks.python import vision as mpv
from common import DATA

MODEL = DATA / "models" / "face_landmarker.task"


def _rel(iris, a, b):
    d = b - a
    den = float(d @ d)
    if den < 1e-10:
        return None
    return float(np.clip(((iris - a) @ d) / den, 0.0, 1.0))


def extract_gaze_feature(lm):
    """lm: (478,2+) normalized landmarks. Returns dict or None (mirrors extractGazeFeature)."""
    if lm is None or len(lm) < 478:
        return None
    p = lambda i: np.asarray(lm[i][:2], dtype=float)
    rx = _rel(p(468), p(33), p(133)); lx = _rel(p(473), p(362), p(263))
    ry = _rel(p(468), p(159), p(145)); ly = _rel(p(473), p(386), p(374))
    if None in (rx, lx, ry, ly):
        return None
    return dict(gazeX=(rx + lx) / 2, gazeY=(ry + ly) / 2, rx=rx, lx=lx, ry=ry, ly=ly)


def extract_head_pose_legacy(m):
    """Pre-fix app formula (parity with the old JS verified to 4e-15 deg before the fix; kept for ablation)."""
    m = np.asarray(m, dtype=float).ravel()
    r00, r10, r20, r21, r22, r01, r11 = m[0], m[1], m[2], m[6], m[10], m[4], m[5]
    yaw = np.arctan2(r20, np.sqrt(r00 * r00 + r10 * r10))
    pitch = np.arctan2(-r21, r22)
    roll = np.arctan2(r01, r11)
    return dict(yaw=np.degrees(yaw), pitch=np.degrees(pitch), roll=np.degrees(roll))


def extract_head_pose(m):
    """Port of the corrected extractHeadPose(): R = Rz(roll) Ry(yaw) Rx(pitch), column-major input."""
    m = np.asarray(m, dtype=float).ravel()
    R = np.array([[m[0], m[4], m[8]], [m[1], m[5], m[9]], [m[2], m[6], m[10]]])
    pitch = np.arctan2(R[2, 1], R[2, 2])
    yaw = np.arctan2(-R[2, 0], np.hypot(R[0, 0], R[1, 0]))
    roll = np.arctan2(R[1, 0], R[0, 0])
    return dict(yaw=np.degrees(yaw), pitch=np.degrees(pitch), roll=np.degrees(roll), R=R)


class Landmarker:
    """Same options as visionTracker.js: numFaces=1, 0.5/0.5/0.5 thresholds, transform matrix on."""

    def __init__(self, running_mode="IMAGE"):
        opts = mpv.FaceLandmarkerOptions(
            base_options=mpt.BaseOptions(model_asset_path=str(MODEL)),
            running_mode=mpv.RunningMode.IMAGE if running_mode == "IMAGE" else mpv.RunningMode.VIDEO,
            num_faces=1, min_face_detection_confidence=0.5, min_face_presence_confidence=0.5,
            min_tracking_confidence=0.5, output_face_blendshapes=False,
            output_facial_transformation_matrixes=True)
        self.lm = mpv.FaceLandmarker.create_from_options(opts)

    def detect_rgb(self, rgb):
        img = mp.Image(image_format=mp.ImageFormat.SRGB, data=np.ascontiguousarray(rgb))
        res = self.lm.detect(img)
        if not res.face_landmarks:
            return None
        lm = np.array([[l.x, l.y, l.z] for l in res.face_landmarks[0]])
        mat = None
        if res.facial_transformation_matrixes:
            # Python returns a (4,4) row-major numpy; JS `.data` is the column-major flatten.
            mat = np.asarray(res.facial_transformation_matrixes[0]).T.ravel()
        return dict(landmarks=lm, matrix=mat)
