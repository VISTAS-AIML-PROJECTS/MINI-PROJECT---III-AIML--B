"""Exp 14 - Can justified improvements make GlassBox's signals detect OEP's annotated cheating intervals? (window level, 24 subjects)

PRE-SPECIFIED (written before running; any model is judged only by held-out leave-one-subject-out evidence):
  Candidate improvements, each tied to a specific hypothesis:
   H1 temporal context   - cheating episodes last seconds-minutes, so causal context (previous windows, EWMA) should help
   H2 richer signals     - leaning/moving (face-box size change), gate-exceedance fractions and run lengths, motion energy
   H3 model class        - regularised logistic regression (C chosen by INNER subject-grouped CV) vs random forest vs gradient boosting
  PRIMARY comparison (decides integration): M3 = logistic regression on v1+extras+temporal vs the real JS engine's window-max risk,
  subject-bootstrap CI on the AUROC difference. Integration requires the CI lower bound > 0 AND the same sign in both
  actor->real and real->actor transfer. All other rows are exploratory.
Leakage controls: leave-one-subject-out (outer); inner grouped CV for C uses TRAINING subjects only; scalers inside pipelines; calibration window
(first 120 s, label-agnostic) excluded; all features causal (past/current windows only); labels never used for features or thresholds.
Thresholded metrics use a label-free review budget: flag the top-33 % scoring windows of each test subject (33 % = training prevalence),
so no threshold is tuned on test labels. Calibration: unweighted logistic probabilities (Brier, ECE) vs a constant-prevalence predictor."""
import json, warnings
import numpy as np, pandas as pd
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.model_selection import GroupKFold
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss
from common import RESULTS, SEED
import exp12_oep_models as E
warnings.filterwarnings("ignore")
rng = np.random.default_rng(SEED)
WIN, FPS = 10, E.FPS; SIZE = int(round(WIN * FPS)); BUDGET = 0.33

# ---------------------------------------------------------------- extra + temporal features (all causal)
def run_len(mask):
    best = cur = 0
    for m in mask:
        cur = cur + 1 if m else 0; best = max(best, cur)
    return best / FPS

def extras():
    out = {}
    for n in E.SUBJECTS:
        f = E.frames[n]; ev = f[f.t >= E.CAL_S].reset_index(drop=True); d = E.deviations(ev, n, "personal").reset_index(drop=True)
        cal = E.CAL[n]; mu_a, sd_a = float(cal.face_area.mean()), max(float(cal.face_area.std()), 0.005)
        area_z = ((ev.face_area - mu_a).abs() / sd_a)
        head_dev = d[[f"h_{a}" for a in E.HEAD]].max(axis=1)
        rows = []
        for k in range(len(ev) // SIZE):
            sl = slice(k * SIZE, (k + 1) * SIZE); a = area_z.iloc[sl].dropna(); hd = head_dev.iloc[sl]; zh = d.z_h.iloc[sl]
            yaw = ev.yaw.iloc[sl].dropna().diff().abs(); pit = ev.pitch.iloc[sl].dropna().diff().abs(); hh = ev.hhat.iloc[sl].dropna().diff().abs()
            rows.append(dict(subject=n, t0=float(ev.t.iloc[sl.start]),
                             area_z_mean=float(a.mean()) if len(a) else 0.0, area_z_max=float(a.max()) if len(a) else 0.0,
                             gate_gaze_frac=float((zh >= 3).mean()), gate_head_frac=float((hd >= 8).mean()),
                             gate_gaze_run_s=run_len((zh >= 3).fillna(False).values), gate_head_run_s=run_len((hd >= 8).fillna(False).values),
                             absent_run_s=run_len(d.absent.iloc[sl].values == 1),
                             motion_yaw=float(yaw.mean()) if len(yaw) else 0.0, motion_pitch=float(pit.mean()) if len(pit) else 0.0, motion_hhat=float(hh.mean()) if len(hh) else 0.0))
        df = pd.DataFrame(rows)
        out[n] = df
    return out

base_cols = ["absent_frac", "z_h_max", "h_yaw_max", "h_pitch_max", "h_roll_max"]
EXTRA = ["area_z_mean", "area_z_max", "gate_gaze_frac", "gate_head_frac", "gate_gaze_run_s", "gate_head_run_s", "absent_run_s", "motion_yaw", "motion_pitch", "motion_hhat"]
CTX_SRC = base_cols + ["area_z_max", "motion_yaw"]

def build(ENG):
    Wb = E.window_table(WIN, "personal", with_engine=ENG)
    # all windows (including ambiguous ones, for causal context) -> base columns by recomputing through the same window_table logic without the filter
    ex = extras(); X = pd.concat(ex.values(), ignore_index=True)
    # recompute base columns for ALL windows (unfiltered) for the context features
    allrows = []
    for n in E.SUBJECTS:
        f = E.frames[n]; ev = f[f.t >= E.CAL_S].reset_index(drop=True); d = E.deviations(ev, n, "personal").reset_index(drop=True)
        for k in range(len(ev) // SIZE):
            sl = slice(k * SIZE, (k + 1) * SIZE)
            r = dict(subject=n, t0=float(ev.t.iloc[sl.start]), absent_frac=float(d.absent.iloc[sl].mean()))
            for c, col in (("z_h_max", "z_h"), ("h_yaw_max", "h_yaw"), ("h_pitch_max", "h_pitch"), ("h_roll_max", "h_roll")):
                v = d[col].iloc[sl].dropna(); r[c] = float(v.max()) if len(v) else 0.0
            allrows.append(r)
    A = pd.DataFrame(allrows).merge(X, on=["subject", "t0"])
    ctx = []
    for n, g in A.groupby("subject", sort=False):
        g = g.sort_values("t0").copy()
        for c in CTX_SRC:
            g[f"{c}_lag1"] = g[c].shift(1).fillna(0.0); g[f"{c}_lag2"] = g[c].shift(2).fillna(0.0)
            g[f"{c}_ewma"] = g[c].shift(1).ewm(alpha=0.5, adjust=False).mean().fillna(0.0)     # previous windows only (causal)
        ctx.append(g)
    A = pd.concat(ctx)
    W = Wb.merge(A[["subject", "t0"] + EXTRA + [f"{c}_{s}" for c in CTX_SRC for s in ("lag1", "lag2", "ewma")]], on=["subject", "t0"], how="left").fillna(0.0)
    return W

# ---------------------------------------------------------------- models
V1 = E.FEATS["all"]
TEMP = [f"{c}_{s}" for c in CTX_SRC for s in ("lag1", "lag2", "ewma")]
SETS = {"v1": V1, "v1+temporal": V1 + TEMP, "v1+extras": V1 + EXTRA, "v1+extras+temporal": V1 + EXTRA + TEMP}

def lr(C, weighted=True): return make_pipeline(StandardScaler(), LogisticRegression(C=C, class_weight="balanced" if weighted else None, max_iter=3000))
def pick_C(Wtr, cols):
    """Inner subject-grouped 5-fold CV on TRAINING subjects only."""
    best, bestC = -1, 0.1; groups = Wtr.subject.values
    for C in (0.01, 0.1, 1.0):
        oof = np.zeros(len(Wtr))
        for tr, te in GroupKFold(5).split(Wtr, Wtr.y, groups):
            oof[te] = lr(C).fit(Wtr.iloc[tr][cols], Wtr.y.iloc[tr]).predict_proba(Wtr.iloc[te][cols])[:, 1]
        a = roc_auc_score(Wtr.y, oof)
        if a > best: best, bestC = a, C
    return bestC

def loso(W, cols, kind):
    sc = np.full(len(W), np.nan); chosen = []
    for s in sorted(W.subject.unique()):
        te = (W.subject == s).values; tr = ~te; Wtr = W[tr]
        if kind == "lr_cv": C = pick_C(Wtr, cols); chosen.append(C); m = lr(C).fit(Wtr[cols], Wtr.y)
        elif kind == "lr_cal": m = lr(1.0, weighted=False).fit(Wtr[cols], Wtr.y)
        elif kind == "rf": m = RandomForestClassifier(300, max_depth=5, min_samples_leaf=10, class_weight="balanced", n_jobs=-1, random_state=SEED).fit(Wtr[cols], Wtr.y)
        else: m = HistGradientBoostingClassifier(max_iter=100, learning_rate=0.05, max_depth=3, random_state=SEED).fit(Wtr[cols], Wtr.y)
        sc[te] = m.predict_proba(W.loc[te, cols])[:, 1]
    return sc, chosen

def pooled(W, sc): return roc_auc_score(W.y, sc)
def by_subject(W, sc): return {s: sc[(W.subject == s).values] for s in sorted(W.subject.unique())}, {s: W.y.values[(W.subject == s).values] for s in sorted(W.subject.unique())}

def budget_metrics(W, sc):
    tp = fp = fn = tn = 0; per = []
    for s in sorted(W.subject.unique()):
        m = (W.subject == s).values; x = sc[m]; y = W.y.values[m]; k = max(1, int(round(BUDGET * len(x)))); flag = np.zeros(len(x), bool); flag[np.argsort(-x)[:k]] = True
        tp += int((flag & (y == 1)).sum()); fp += int((flag & (y == 0)).sum()); fn += int((~flag & (y == 1)).sum()); tn += int((~flag & (y == 0)).sum())
    P = tp / max(tp + fp, 1); R = tp / max(tp + fn, 1); return dict(precision=P, recall=R, f1=2 * P * R / max(P + R, 1e-9), tp=tp, fp=fp, fn=fn, tn=tn)

def ece(y, p, bins=10):
    edges = np.linspace(0, 1, bins + 1); idx = np.clip(np.digitize(p, edges) - 1, 0, bins - 1); e = 0.0
    for b in range(bins):
        m = idx == b
        if m.any(): e += m.mean() * abs(y[m].mean() - p[m].mean())
    return float(e)

if __name__ == "__main__":
    ENG = E.engine_risk("personal"); W = build(ENG)
    prev = float(W.y.mean()); print("windows", len(W), "pos", int(W.y.sum()), "prevalence", round(prev, 3))
    # ---- label / class-balance audit
    aud = W.groupby("subject").agg(n_windows=("y", "size"), prevalence=("y", "mean"), actor=("actor", "first")).reset_index(); aud.to_csv(RESULTS / "exp14_class_balance.csv", index=False)
    feat_audit = []
    for t in sorted(W.ctype.unique()):
        if t == 0: continue
        pos, neg = W[W.ctype == t], W[W.y == 0]
        for c in ["absent_frac", "z_h_max", "h_yaw_max", "h_pitch_max", "h_roll_max", "area_z_max", "motion_yaw", "gate_head_frac"]:
            s = np.sqrt((pos[c].var() + neg[c].var()) / 2); feat_audit.append(dict(ctype=int(t), n_windows=len(pos), feature=c, smd=float((pos[c].mean() - neg[c].mean()) / s) if s > 0 else np.nan))
    pd.DataFrame(feat_audit).to_csv(RESULTS / "exp14_label_audit_by_type.csv", index=False)
    rows, S = [], {}
    def add(name, group, sc, extra=None):
        bm = budget_metrics(W, sc); scs, ys = by_subject(W, sc); lo, hi = E.boot_ci(scs, ys)
        per = [roc_auc_score(ys[s], scs[s]) for s in scs if len(np.unique(ys[s])) == 2]
        r = dict(name=name, group=group, auroc=pooled(W, sc), auroc_lo=lo, auroc_hi=hi, pr_auc=float(average_precision_score(W.y, sc)),
                 per_subject_auc_median=float(np.median(per)), **{f"budget33_{k}": v for k, v in bm.items()}); r.update(extra or {}); rows.append(r); S[name] = (sc, scs, ys); return r
    add("engine risk (window max, real JS engines)", "baseline", W.engine_max.values)
    add("heuristic: max head deviation / 30deg", "baseline", W[[f"h_{a}_max" for a in E.HEAD]].max(axis=1).values / 30)
    add("heuristic: face-absent fraction", "baseline", W.absent_frac.values)
    chosenC = {}
    for sname, cols in SETS.items():
        sc, ch = loso(W, cols, "lr_cv"); chosenC[sname] = ch; add(f"LR (C by inner CV) | {sname}", "learned", sc, dict(features=sname, model="logreg"))
    for model, label in (("rf", "random forest"), ("hgb", "gradient boosting")):
        sc, _ = loso(W, SETS["v1+extras+temporal"], model); add(f"{label} | v1+extras+temporal", "learned", sc, dict(features="v1+extras+temporal", model=model))
    # ---- primary comparison + transfer
    P = "LR (C by inner CV) | v1+extras+temporal"; Eng = "engine risk (window max, real JS engines)"; M0 = "LR (C by inner CV) | v1"
    prim = {}
    for ref_name, ref in (("engine", Eng), ("v1_logreg", M0)):
        lo, hi = E.boot_ci(S[P][1], S[P][2], ref_by_subj=S[ref][1]); prim[f"vs_{ref_name}"] = dict(diff=float(pooled(W, S[P][0]) - pooled(W, S[ref][0])), lo=lo, hi=hi)
    tr = {}
    for nm, trs, tes in (("train actors -> test real", E.ACTORS, E.REAL), ("train real -> test actors", E.REAL, E.ACTORS)):
        trm = W.subject.isin(trs).values; tem = W.subject.isin(tes).values; C = float(np.median(chosenC["v1+extras+temporal"]))
        m = lr(C).fit(W.loc[trm, SETS["v1+extras+temporal"]], W.y[trm]); p = m.predict_proba(W.loc[tem, SETS["v1+extras+temporal"]])[:, 1]
        tr[nm] = dict(auroc_learned=float(roc_auc_score(W.y[tem], p)), auroc_engine=float(roc_auc_score(W.y[tem], W.engine_max[tem])))
    # ---- calibration of probabilities (unweighted logistic, v1+extras+temporal)
    cal_sc, _ = loso(W, SETS["v1+extras+temporal"], "lr_cal"); y = W.y.values
    cal = dict(brier_model=float(brier_score_loss(y, cal_sc)), brier_constant_prevalence=float(brier_score_loss(y, np.full(len(y), prev))), ece=ece(y, cal_sc),
               mean_pred=float(cal_sc.mean()), prevalence=prev, auroc=float(roc_auc_score(y, cal_sc)))
    R = pd.DataFrame(rows); R.to_csv(RESULTS / "exp14_oep_improvements.csv", index=False)
    integrate = bool(prim["vs_engine"]["lo"] > 0 and all(v["auroc_learned"] > v["auroc_engine"] for v in tr.values()))
    meta = dict(n_windows=len(W), n_pos=int(W.y.sum()), prevalence=prev, budget=BUDGET, primary=prim, transfer=tr, calibration=cal,
                inner_cv_C_chosen={k: v for k, v in chosenC.items()}, integration_criterion_met=integrate)
    json.dump(meta, open(RESULTS / "exp14_meta.json", "w"), indent=1)
    pd.set_option("display.width", 250); print(R[["name", "auroc", "auroc_lo", "auroc_hi", "pr_auc", "budget33_precision", "budget33_recall", "budget33_f1"]].round(3).to_string(index=False))
    print(json.dumps(meta, indent=1))
