"""Re-runs every experiment end to end (about 40-60 min on CPU, dominated by MediaPipe over 37.7k + 22k images).
    python research/fetch_data.py && python research/run_all.py            # everything, then npm test
    python research/run_all.py exp04b exp07                                  # a subset by step name"""
import subprocess, sys
from pathlib import Path
here = Path(__file__).parent
steps = {
    "exp01": ["exp01_susp_classification.py"],
    "exp02a": ["exp02_fairface_detection.py", "100000", "pad025"],
    "exp02b": ["exp02_fairface_detection.py", "100000", "pad125"],
    "exp02c": ["exp02c_adjusted.py"],
    "exp03a": ["exp03_extract_mpii.py"],
    "exp03b": ["exp03_extract_mpii.py", "100000", "5"],
    "exp04": ["exp04_personalization.py"],
    "exp04b": ["exp04b_same_session.py"],
    "exp05": ["exp05_headpose_validation.py"],
    "exp06": ["exp06_operating_point.py"],
    "exp07": ["exp07_vertical_term.py"],
    "exp09": ["exp09_linear_gaze.py"],
    "exp09b": ["exp09b_linear_operating_point.py"],
    "exp10": ["exp10_susp_error_analysis.py"],
    "export_js": ["export_linear_gaze_js.py"],
    "replay": ["run_engine_replay.py"],
    "figures": ["make_figures.py"],
}
# OEP / UPNA steps run only if the (user-downloaded) archives are present at the paths below.
OEP_ZIP = Path.home() / "Downloads" / "OEP database.zip"
OEP_TAR = here.parent / "data" / "raw" / "oep" / "OEP_database.tar.gz"
UPNA_ZIP = Path.home() / "Downloads" / "Head_Pose_Database_UPNA.zip"
oep_src = OEP_ZIP if OEP_ZIP.exists() else (OEP_TAR if OEP_TAR.exists() else None)
if oep_src is not None:
    steps["oep_extract"] = ["oep_extract.py", str(oep_src), str(here.parent / "data" / "raw" / "oep_extract")]
    steps["oep_features"] = ["oep_extract_features.py"] + [str(n) for n in range(1, 25)]
    steps["exp08"] = ["exp08_oep.py"]
    steps["exp12"] = ["exp12_oep_models.py"]
    steps["exp12b"] = ["exp12b_oep_diagnostics.py"]
    steps["exp14"] = ["exp14_oep_improvements.py"]
if UPNA_ZIP.exists() or (here.parent / "data" / "raw" / "upna_hpdb").exists():
    steps["exp11"] = ["exp11_upna_headpose.py"]
if list(Path.home().joinpath("Downloads").glob("user_[0-9][0-9].zip")):
    steps["exp13"] = ["exp13_i2head_headpose.py"]
only = sys.argv[1:] or list(steps)
for name in only:
    s = steps[name]; print(">>", name, *s, flush=True)
    flags = ["-I"] if name == "oep_extract" else []     # archive is untrusted data: isolated interpreter
    subprocess.run([sys.executable, *flags, str(here / s[0]), *s[1:]], check=True, cwd=here)
if not sys.argv[1:]:
    print(">> node tests"); subprocess.run(["npm", "test"], check=True, cwd=here.parent, shell=True)
