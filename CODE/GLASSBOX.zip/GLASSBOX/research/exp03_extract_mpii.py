"""Exp 03a - run the GlassBox MediaPipe pipeline over MPIIFaceGaze and cache per-frame features.

MPIIFaceGaze/pXX/pXX.txt columns (README): 1 image path; 2-3 on-screen gaze target (px);
4-15 six face landmarks; 16-18 head rotation vector (rvec); 19-21 head translation; 22-24 face
centre (camera coords, mm); 25-27 3-D gaze target (camera coords, mm); 28 evaluation eye.
Output: data/processed/mpii_features.parquet  (one row per image, NaN where MediaPipe found no face)."""
import sys, zipfile, io
import numpy as np, pandas as pd, cv2
from common import RAW, PROC
from glassbox_vision import Landmarker, extract_gaze_feature, extract_head_pose

ZIP = RAW / "mpiifacegaze" / "MPIIFaceGaze.zip"
LIMIT = int(sys.argv[1]) if len(sys.argv) > 1 else None
EVERY = int(sys.argv[2]) if len(sys.argv) > 2 else 1   # subsample stride (chronological order kept)

lmk = Landmarker("IMAGE")
zf = zipfile.ZipFile(ZIP)
names = zf.namelist()
subjects = sorted({n.split("/")[1] for n in names if n.startswith("MPIIFaceGaze/p") and n.count("/") >= 2})
rows = []
for sid in subjects:
    txt = [n for n in names if n.endswith(f"{sid}/{sid}.txt")][0]
    ann = pd.read_csv(io.StringIO(zf.read(txt).decode()), sep=" ", header=None)
    ann = ann.iloc[::EVERY]
    if LIMIT: ann = ann.iloc[:LIMIT]
    for k, a in enumerate(ann.itertuples(index=False)):
        img_name = a[0]
        data = zf.read(f"MPIIFaceGaze/{sid}/{img_name}")
        bgr = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        out = lmk.detect_rgb(rgb)
        r = dict(subject=sid, frame=img_name, order=k,
                 scr_x=a[1], scr_y=a[2],
                 rvec=tuple(a[15:18]), fc=tuple(a[21:24]), gt=tuple(a[24:27]))
        if out is not None:
            g = extract_gaze_feature(out["landmarks"])
            h = extract_head_pose(out["matrix"]) if out["matrix"] is not None else None
            lm = out["landmarks"]
            xs, ys = lm[:, 0], lm[:, 1]
            r.update(det=1, gx=g["gazeX"] if g else np.nan, gy=g["gazeY"] if g else np.nan,
                     rx=g["rx"] if g else np.nan, lx=g["lx"] if g else np.nan,
                     ry=g["ry"] if g else np.nan, ly=g["ly"] if g else np.nan,
                     yaw=h["yaw"] if h else np.nan, pitch=h["pitch"] if h else np.nan, roll=h["roll"] if h else np.nan,
                     face_area=float((xs.max() - xs.min()) * (ys.max() - ys.min())))
            if out["matrix"] is not None:
                for j, v in enumerate(out["matrix"]): r[f"m{j}"] = float(v)
        else:
            r["det"] = 0
        rows.append(r)
    print(sid, len(rows), flush=True)
df = pd.DataFrame(rows)
for c, n in (("rvec", 3), ("fc", 3), ("gt", 3)):
    for i, ax in enumerate("xyz"):
        df[f"{c}_{ax}"] = df[c].map(lambda t: t[i])
    df = df.drop(columns=c)
tag = "" if not LIMIT and EVERY == 1 else f"_lim{LIMIT}_every{EVERY}"
df.to_parquet(PROC / f"mpii_features{tag}.parquet")
print(df.groupby("subject").det.mean().round(3).to_dict())
