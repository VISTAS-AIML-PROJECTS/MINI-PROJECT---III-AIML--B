"""Downloads the public datasets/model used by the experiments into data/ and verifies SHA-256 against
data_manifest.json. Licences: MPIIFaceGaze CC BY-NC-SA 4.0 (non-commercial scientific use); FairFace CC BY 4.0;
Mendeley suspicious-behaviours dataset CC BY 4.0; face_landmarker.task Apache-2.0 (Google)."""
import hashlib, json, urllib.request
from pathlib import Path
from common import DATA
SRC = {
 "mendeley_susp/susp.csv": "https://data.mendeley.com/public-files/datasets/39xs8th543/files/e27dd7c5-d672-4849-a41e-83cc3be681c2/file_downloaded",
 "mpiifacegaze/MPIIFaceGaze.zip": "https://datasets.d2.mpi-inf.mpg.de/MPIIGaze/MPIIFaceGaze.zip",
 "fairface/val_pad025.parquet": "https://huggingface.co/api/datasets/HuggingFaceM4/FairFace/parquet/0.25/validation/0.parquet",
 "fairface/val_pad125.parquet": "https://huggingface.co/api/datasets/HuggingFaceM4/FairFace/parquet/1.25/validation/0.parquet",
 "models/face_landmarker.task": "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task",
}
man = json.load(open(Path(__file__).parent / "data_manifest.json"))
for rel, url in SRC.items():
    dest = (DATA / "models" / Path(rel).name) if rel.startswith("models/") else (DATA / "raw" / rel)
    dest.parent.mkdir(parents=True, exist_ok=True)
    if not dest.exists():
        print("downloading", rel); urllib.request.urlretrieve(url, dest)
    h = hashlib.sha256()
    with open(dest, "rb") as f:
        for c in iter(lambda: f.read(1 << 24), b""): h.update(c)
    print(("OK       " if h.hexdigest() == man[rel]["sha256"] else "MISMATCH "), rel)
