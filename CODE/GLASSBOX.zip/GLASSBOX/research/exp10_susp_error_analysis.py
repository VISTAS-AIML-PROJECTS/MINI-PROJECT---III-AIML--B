"""Exp 10 - Error analysis of the strict-feature model on the Mendeley table (temporally blocked 5-fold, 50-row purge; same
pipeline/seed as exp01). Which cheating rows does a model restricted to GlassBox-derivable features miss? Threshold 0.5.
Also attempts (and records the failure of) recovering pseudo-subjects from face-geometry ratios."""
import json, warnings
import numpy as np, pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from common import RAW, RESULTS, SEED
warnings.filterwarnings("ignore")
d = pd.read_csv(RAW / "mendeley_susp" / "susp.csv"); y = d.label.values; n = len(d)
X = d.copy()
for side in ("left", "right"):
    k = side[0]; X[f"pupil_off_{k}x"] = X[f"pupil_{side}_x"] - X[f"{side}_eye_x"]; X[f"pupil_off_{k}y"] = X[f"pupil_{side}_y"] - X[f"{side}_eye_y"]
cols = ["face_present", "no_of_face", "head_pitch", "head_yaw", "head_roll", "pupil_off_lx", "pupil_off_ly", "pupil_off_rx", "pupil_off_ry"]
oof = np.full(n, np.nan); edges = np.linspace(0, n, 6).astype(int)
for a, b in zip(edges[:-1], edges[1:]):
    te = np.arange(a, b); tr = np.r_[np.arange(0, max(a - 50, 0)), np.arange(min(b + 50, n), n)]
    m = HistGradientBoostingClassifier(max_iter=200, learning_rate=0.05, random_state=SEED).fit(X.iloc[tr][cols], y[tr]); oof[te] = m.predict_proba(X.iloc[te][cols])[:, 1]
pred = (oof >= 0.5).astype(int)
d["pred"] = pred
def grp(r):
    if r.label == 0: return "non-cheating"
    if r.face_present == 0: return "cheat: face absent"
    if r.phone_present == 1: return "cheat: phone visible"
    if isinstance(r.head_pose, str) and r.head_pose != "forward": return f"cheat: head {r.head_pose}"
    if r.gaze_on_script == 0: return "cheat: gaze off-script only"
    return "cheat: no overt cue (other)"
d["group"] = d.apply(grp, axis=1)
S = d.groupby("group").apply(lambda g: pd.Series(dict(n=len(g), flagged_rate=g.pred.mean()))).reset_index()
S["note"] = np.where(S.group == "non-cheating", "= false-positive rate", "= recall")
S.to_csv(RESULTS / "exp10_error_analysis.csv", index=False)
pd.set_option("display.width", 160); print(S.round(3).to_string(index=False))
# pseudo-subject recovery attempt: do face-geometry ratios persist between adjacent rows (a prerequisite)?
f = d[(d.face_present == 1) & (d.face_w > 20)]
ie = np.hypot(f.right_eye_x - f.left_eye_x, f.right_eye_y - f.left_eye_y)
r = pd.DataFrame(dict(nose=np.hypot(f.nose_tip_x - (f.left_eye_x + f.right_eye_x) / 2, f.nose_tip_y - (f.left_eye_y + f.right_eye_y) / 2) / ie,
                      mouth=np.hypot(f.mouth_x - f.nose_tip_x, f.mouth_y - f.nose_tip_y) / ie, width=f.face_w / ie)).replace([np.inf, -np.inf], np.nan).dropna()
ac = {c: float(r[c].autocorr(1)) for c in r}; print("lag-1 autocorrelation of face-geometry ratios:", ac)
json.dump(dict(lag1_autocorr=ac, conclusion="ratios too noisy to recover subject identity; pseudo-subject grouped CV not attempted"), open(RESULTS / "exp10_pseudo_subject_attempt.json", "w"), indent=1)
