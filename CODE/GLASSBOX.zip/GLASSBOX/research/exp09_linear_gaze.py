"""Exp 09 - Linear (ridge) gaze-angle estimator vs the app's z_x baseline for horizontal gaze deviation (MPIIFaceGaze, LOSO).

Model: h_hat = ridge(standardised [gx, gy, rx, lx, ry, ly, yaw, pitch, roll]) trained on the OTHER 14 subjects' frames
(target = camera-frame horizontal gaze angle). Deviation score for the held-out subject = |h_hat - mean(h_hat over calibration)|
/ sd(h_hat over calibration)  (same z-score semantics as the app; calibration frames never evaluated).
Protocols (as exp04/exp04b): cross-session (first K=100 frames, eval rank>=300) and same-session (first K=30 of each session,
eval day_rank>=30, sessions >= 50 frames). Target/positives: top-25 % pooled |h - subject mean h| over evaluation frames.
Statistics: subject-level bootstrap (2000), paired vs z_x (personal) and vs population z_x."""
import json, warnings
import numpy as np, pandas as pd
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import roc_auc_score
from common import RESULTS, ROOT, SEED
from mpii_common import load, KMAX
warnings.filterwarnings("ignore")
FEAT = ["gx", "gy", "rx", "lx", "ry", "ly", "yaw", "pitch", "roll"]
df = load(); subjects = sorted(df.subject.unique()); rng = np.random.default_rng(SEED)

def fit(frame): return make_pipeline(StandardScaler(), Ridge(alpha=10.0)).fit(frame[FEAT], frame.h)

def run(protocol):
    if protocol == "cross":
        d = df.copy(); ev_mask = d["rank"] >= KMAX; K = 100
    else:
        n = df.groupby(["subject", "day"]).day_rank.transform("max") + 1
        d = df[n >= 50].copy(); ev_mask = d.day_rank >= 30; K = 30
    thr = d[ev_mask].T_H.quantile(0.75); per = {}
    for s in subjects:
        sub = d[d.subject == s]; oth = df[df.subject != s]; m = fit(oth)
        sub = sub.assign(hh=m.predict(sub[FEAT])); ev = sub[ev_mask.loc[sub.index]]; y = (ev.T_H > thr).astype(int).values
        if y.min() == y.max(): continue
        oth_hh = m.predict(oth[FEAT]); sc = {}
        sc["zx_population"] = np.abs(ev.gx.values - oth.gx.mean()) / oth.gx.std()
        sc["lin_population"] = np.abs(ev.hh.values - oth_hh.mean()) / oth_hh.std()
        if protocol == "cross":
            cal = sub.iloc[:K]
            sc["zx_personal"] = np.abs(ev.gx.values - cal.gx.mean()) / max(cal.gx.std(), 1e-3)
            sc["lin_personal"] = np.abs(ev.hh.values - cal.hh.mean()) / max(cal.hh.std(), 1e-3)
            sc["lin_personal_meanonly"] = np.abs(ev.hh.values - cal.hh.mean()) / oth_hh.std()
        else:
            a, b, c, e = [], [], [], []
            for _, g in sub.groupby("day", sort=False):
                cal = g.iloc[:K]; t = g[g.day_rank >= 30]
                a.append(np.abs(t.gx.values - cal.gx.mean()) / max(cal.gx.std(), 1e-3))
                b.append(np.abs(t.hh.values - cal.hh.mean()) / max(cal.hh.std(), 1e-3))
                c.append(np.abs(t.hh.values - cal.hh.mean()) / oth_hh.std())
            sc["zx_personal"] = np.concatenate(a); sc["lin_personal"] = np.concatenate(b); sc["lin_personal_meanonly"] = np.concatenate(c)
        for k, v in sc.items(): per.setdefault(k, {})[s] = roc_auc_score(y, v)
    pd.DataFrame(per).rename_axis("subject").reset_index().assign(protocol=protocol).to_csv(RESULTS / f"exp09_per_subject_{protocol}.csv", index=False)
    ids = sorted(per["zx_population"]); B = []
    for _ in range(2000):
        pick = rng.choice(ids, len(ids)); B.append({k: np.mean([per[k][i] for i in pick]) for k in per})
    B = pd.DataFrame(B); rows = []
    for k in per:
        wa = np.mean([per[k][i] for i in ids])
        for ref in ("zx_population", "zx_personal"):
            dlt = B[k] - B[ref]
            rows.append(dict(protocol=protocol, method=k, ref=ref, within_subject_auc=wa, auc_lo=B[k].quantile(.025), auc_hi=B[k].quantile(.975),
                             diff=wa - np.mean([per[ref][i] for i in ids]), diff_lo=dlt.quantile(.025), diff_hi=dlt.quantile(.975),
                             subjects_better=int(sum(per[k][i] > per[ref][i] for i in ids))))
    return rows
T = pd.DataFrame(run("cross") + run("same")); T.to_csv(RESULTS / "exp09_linear_gaze.csv", index=False)
pd.set_option("display.width", 220); print(T[T.ref == "zx_population"].round(3).to_string(index=False)); print(T[(T.ref == "zx_personal") & T.method.str.startswith("lin")].round(3).to_string(index=False))
# final artifact: ridge fit on all 15 subjects (for portability); coefficients in raw-feature units
m = fit(df); sc_, rg = m.named_steps["standardscaler"], m.named_steps["ridge"]
coef = rg.coef_ / sc_.scale_; icpt = float(rg.intercept_ - np.sum(rg.coef_ * sc_.mean_ / sc_.scale_))
out = dict(name="linear_gaze_v1", features=FEAT, coef=[float(c) for c in coef], intercept=icpt, target="camera-frame horizontal gaze angle (deg)",
           trained_on="MPIIFaceGaze, all 15 subjects (37,595 frames); evaluation numbers above are leave-one-subject-out, not from this fit",
           seed=SEED, alpha=10.0)
(ROOT / "research" / "models").mkdir(exist_ok=True); json.dump(out, open(ROOT / "research" / "models" / "linear_gaze_v1.json", "w"), indent=1)
print(out["coef"], out["intercept"])
