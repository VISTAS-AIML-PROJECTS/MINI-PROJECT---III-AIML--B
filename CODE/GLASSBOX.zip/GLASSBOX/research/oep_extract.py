"""Extracts, from the OEP archive (tar.gz, possibly truncated, or the zip repackaging), only each subject's gt.txt and webcam video (<username>1.avi) to
data/raw/oep_extract/subjectN/{gt.txt,webcam.avi}. Wearcam (<username>2.avi) and audio are skipped, and original file
names (which embed participant usernames) are NOT preserved. Only complete members are written. Run with `python -I`.
Usage: python -I research/oep_extract.py data/raw/oep/OEP_database.tar.gz data/raw/oep_extract"""
import re, sys, tarfile, zlib
from pathlib import Path
src, dst = Path(sys.argv[1]), Path(sys.argv[2])
done = []

if src.suffix.lower() == ".zip":
    # zip repackaging of the OEP archive (top-level folders subjectN/). zipfile verifies CRC-32 when each member is read to the end.
    import zipfile
    with zipfile.ZipFile(src) as z:
        for info in z.infolist():
            parts = info.filename.split("/")
            if len(parts) != 2 or not re.fullmatch(r"subject\d{1,2}", parts[0]): continue
            fn = parts[1]
            if fn == "gt.txt": out = "gt.txt"
            elif re.fullmatch(r"[A-Za-z0-9_\-]+1\.avi", fn): out = "webcam.avi"
            else: continue
            d = dst / parts[0]; d.mkdir(parents=True, exist_ok=True); target = d / out
            if target.exists() and target.stat().st_size == info.file_size: done.append((parts[0], out)); continue
            tmp = target.with_suffix(".part")
            with z.open(info) as f, open(tmp, "wb") as o:
                while True:
                    b = f.read(1 << 22)
                    if not b: break
                    o.write(b)
            tmp.replace(target); done.append((parts[0], out)); print("ok (CRC verified)", parts[0], out, flush=True)
    subs = sorted({s for s, _ in done}, key=lambda x: int(x[7:]))
    print("complete members:", len(done)); print("subjects with webcam+gt:", [s for s in subs if (s, "gt.txt") in done and (s, "webcam.avi") in done])
    sys.exit(0)
try:
    with tarfile.open(src, mode="r|gz") as tf:
        for m in tf:
            if not m.isfile(): continue
            parts = m.name.split("/")
            if len(parts) != 3 or not re.fullmatch(r"subject\d{1,2}", parts[1]): continue
            fn = parts[2]
            if fn == "gt.txt": out = "gt.txt"
            elif re.fullmatch(r"[A-Za-z0-9_\-]+1\.avi", fn): out = "webcam.avi"
            else: continue
            d = dst / parts[1]; d.mkdir(parents=True, exist_ok=True); target = d / out
            if target.exists() and target.stat().st_size == m.size: done.append((parts[1], out)); continue
            f = tf.extractfile(m); tmp = target.with_suffix(".part")
            with open(tmp, "wb") as o:
                n = 0
                while True:
                    b = f.read(1 << 22)
                    if not b: break
                    o.write(b); n += len(b)
            if n == m.size: tmp.replace(target); done.append((parts[1], out))
            else: tmp.unlink()
except (EOFError, tarfile.ReadError, zlib.error) as e:
    print("stream ended early (archive incomplete):", type(e).__name__)
subs = sorted({s for s, _ in done}, key=lambda x: int(x[7:]))
print("complete members:", len(done)); print("subjects with webcam+gt:", [s for s in subs if (s, "gt.txt") in done and (s, "webcam.avi") in done])
