"""F05 - Exploratory, specified BEFORE it was run: would weights learned from data beat v2's fixed ordered weights (0.5/0.3/0.2)?
    python -X utf8 research/final/f05_learned_weights_v2.py
Why: the earlier learned-fusion study (docs/results_2, E3/E7) fitted logistic regression to the v1 components. The live engine is v2, whose
transparent form is an ordered weighted average over independent behaviour GROUPS. This asks the same question of v2, with an explainable
learner: non-negative logistic regression on the window-maximum group scores (attention, presence). Focus is structurally zero on OEP (no
browser events), so it cannot be learned here.
Protocol (fixed in advance): same 1,956 OEP windows as F02/s13; leave-one-subject-out; the L2 strength C in {0.01,0.1,1,10} is chosen by an
inner leave-one-subject-out on the 23 training subjects only (criterion: pooled within-subject-ranked AUROC); coefficients >= 0 (bounds);
metric = ranked AUROC with subject-level bootstrap CIs, paired difference vs v2 (1000 resamples, seed 20261021).
Decision rule: a learned weighting is considered an improvement only if the lower CI bound of its paired difference vs v2 is > 0.
Nothing here is deployed; this writes research/final/results/f05_*."""
import json, subprocess, sys
from pathlib import Path
import numpy as np, pandas as pd
from scipy.optimize import minimize
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from oep_frames import frames_for, E, ROOT
sys.path.insert(0, str(ROOT / "docs" / "results_2" / "scripts"))
from r2common import boot_pooled_auc
import exp14_oep_improvements as X14

HERE = Path(__file__).resolve().parent; OUT = HERE / "results"
W = pd.read_csv(HERE / "results" / "f02b_window_scores.csv")          # subject, t0, y, v1, v2 (v2.1 = the live engine; f02_ is the frozen v2.0 run)
REPLAY = HERE / "replay_v2_groups.mjs"
GROUPS = ["attention", "presence"]

ticks = {}
for n in E.SUBJECTS:
    r = json.loads(subprocess.run(["node", str(REPLAY), "--no-focus"], input=frames_for(n).read_text(encoding="utf-8"), capture_output=True, text=True, check=True).stdout)
    T = pd.DataFrame(r); T["sec"] = (T.t - 1_000_000) / 1000.0; ticks[n] = T
def win(n, t0, col):
    T = ticks[n]; m = (T.sec.values > t0) & (T.sec.values <= t0 + 10.0); return float(T[col].values[m].max()) if m.any() else 0.0
for g in GROUPS: W[g] = [win(r.subject, r.t0, g) for r in W.itertuples()]
# sanity: the replay used here must reproduce the committed v2.1 scores (f02b) (score is a pure function of the two group scores
# only when focus is absent, so check the replayed score column itself)
W["v2_replay"] = [win(r.subject, r.t0, "score") for r in W.itertuples()]
assert np.allclose(W.v2_replay, W.v2), "replayed v2 must equal the committed f02b window scores"

subj = W.subject.values; y = W.y.values; SUBJ = sorted(W.subject.unique()); X = W[GROUPS].values
rank = lambda s, idx=None: pd.Series(s).groupby(subj if idx is None else subj[idx]).rank(pct=True).values

def fit_nn_lr(Xtr, ytr, C):
    """Non-negative L2 logistic regression (intercept free), L-BFGS-B with bounds. Explainable: logit = b + w . groups, w >= 0."""
    d = Xtr.shape[1]
    def f(p):
        w, b = p[:d], p[d]; z = Xtr @ w + b
        ll = np.logaddexp(0, z) - ytr * z
        reg = 0.5 / C * np.sum(w * w) / len(ytr)
        g = (1 / (1 + np.exp(-z))) - ytr
        return ll.mean() + reg, np.concatenate([Xtr.T @ g / len(ytr) + w / (C * len(ytr)), [g.mean()]])
    r = minimize(f, np.zeros(d + 1), jac=True, method="L-BFGS-B", bounds=[(0, None)] * d + [(None, None)])
    return r.x[:d], r.x[d]

def ranked_auc(score, idx): return roc_auc_score(y[idx], rank(score, idx)) if len(np.unique(y[idx])) == 2 else np.nan
Cs = [0.01, 0.1, 1.0, 10.0]
pred_nn = np.zeros(len(W)); pred_lr = np.zeros(len(W)); chosen, coefs = {}, {}
for s in SUBJ:
    te = subj == s; tr = ~te; trs = [u for u in SUBJ if u != s]
    best, bestC = -1, Cs[0]
    for C in Cs:                                                     # inner LOSO on training subjects only
        inner = np.zeros(tr.sum()); sub_tr = subj[tr]; Xt, yt = X[tr], y[tr]
        for u in trs:
            ite = sub_tr == u; w, b = fit_nn_lr(Xt[~ite], yt[~ite], C); inner[ite] = Xt[ite] @ w + b
        a = roc_auc_score(yt, pd.Series(inner).groupby(sub_tr).rank(pct=True).values)
        if a > best: best, bestC = a, C
    w, b = fit_nn_lr(X[tr], y[tr], bestC); pred_nn[te] = X[te] @ w + b; chosen[int(s)] = bestC; coefs[int(s)] = [float(v) for v in w]
    lr = LogisticRegression(C=bestC, max_iter=1000).fit(X[tr], y[tr]); pred_lr[te] = lr.decision_function(X[te])
    print("fold", s, "C", bestC, "w", np.round(w, 3), flush=True)

# Post-hoc diagnostic (added after the first run, NOT part of the decision rule and NOT causal/deployable: it needs the whole session):
# the same learner on within-subject percentile ranks of the group scores, to test whether the failure is a between-subject artefact.
Xr = np.column_stack([pd.Series(W[g].values).groupby(subj).rank(pct=True).values for g in GROUPS]); pred_rk = np.zeros(len(W))
for s in SUBJ:
    te = subj == s; tr = ~te; trs = [u for u in SUBJ if u != s]; best, bestC = -1, Cs[0]
    for C in Cs:
        inner = np.zeros(tr.sum()); sub_tr = subj[tr]; Xt, yt = Xr[tr], y[tr]
        for u in trs:
            ite = sub_tr == u; w, b = fit_nn_lr(Xt[~ite], yt[~ite], C); inner[ite] = Xt[ite] @ w + b
        a = roc_auc_score(yt, pd.Series(inner).groupby(sub_tr).rank(pct=True).values)
        if a > best: best, bestC = a, C
    w, b = fit_nn_lr(Xr[tr], y[tr], bestC); pred_rk[te] = Xr[te] @ w + b

bys = lambda v: {s: v[subj == s] for s in SUBJ}; ys = bys(y)
cands = {"v2.1 fixed weights (live)": W.v2.values, "v1 (frozen baseline)": W.v1.values, "Non-negative LR on v2 groups": pred_nn, "Unconstrained LR on v2 groups": pred_lr,
         "Attention group alone": W.attention.values,
         "DIAGNOSTIC non-negative LR on within-subject ranks": pred_rk}
res = {}
for k, v in cands.items():
    pt, lo, hi = boot_pooled_auc(bys(rank(v)), ys, n_boot=1000)
    b = X14.budget_metrics(W, v)
    d, dlo, dhi = boot_pooled_auc(bys(rank(v)), ys, n_boot=1000, ref=bys(rank(W.v2.values))) if k != "v2.1 fixed weights (live)" else (0.0, 0.0, 0.0)
    res[k] = dict(ranked_auroc=pt, lo=lo, hi=hi, diff_vs_v2=d, diff_lo=dlo, diff_hi=dhi, budget33_precision=b["precision"], budget33_recall=b["recall"], budget33_f1=b["f1"])
    print(f"{k:34s} {pt:.3f} [{lo:.3f},{hi:.3f}]  vs v2 {d:+.3f} [{dlo:+.3f},{dhi:+.3f}]  P/R/F1@33% {b['precision']:.3f}/{b['recall']:.3f}/{b['f1']:.3f}")
mean_w = np.mean(list(coefs.values()), axis=0)
summary = dict(n_windows=int(len(W)), n_positive=int(y.sum()), n_subjects=len(SUBJ), groups=GROUPS, candidates=res,
               selected_C_counts={str(c): sum(1 for v in chosen.values() if v == c) for c in Cs}, mean_nonneg_coefficients=dict(zip(GROUPS, map(float, mean_w))),
               per_fold_coefficients=coefs, decision_rule="adopt only if lower CI of paired difference vs v2 > 0",
               adopt=bool(res["Non-negative LR on v2 groups"]["diff_lo"] > 0))
json.dump(summary, open(OUT / "f05_summary.json", "w"), indent=1)
W.assign(nn_lr=pred_nn, lr=pred_lr, nn_lr_rank_diag=pred_rk).drop(columns=["v2_replay"]).to_csv(OUT / "f05_window_scores.csv", index=False)
print("adopt:", summary["adopt"], "| mean coefficients:", summary["mean_nonneg_coefficients"])
