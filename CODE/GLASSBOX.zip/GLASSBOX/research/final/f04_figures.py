"""F04 - Figures for docs/final from saved results only (f01 scenario time series, f02/f02b summaries, f02c operating points).
    python -X utf8 research/final/f04_figures.py"""
import json, sys
from pathlib import Path
import numpy as np, pandas as pd
HERE = Path(__file__).resolve().parent; ROOT = HERE.parents[1]; RES = HERE / "results"; FIG = ROOT / "docs" / "final" / "figures"; FIG.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(ROOT / "docs" / "results_2" / "scripts")); sys.dont_write_bytecode = True
from r2common import plt, NAVY, TEAL, GREY, ORANGE, MUTED, RED, BLUE

def frame(fig, title, subtitle, source):
    fig.text(0.03, 0.965, title, fontsize=16, fontweight="bold", color=NAVY, va="top")
    fig.text(0.03, 0.918, subtitle, fontsize=10.5, color=MUTED, va="top")
    fig.text(0.03, 0.012, "Source: " + source, fontsize=8.5, color=MUTED, va="bottom")

# 1. scenario trajectories
TS = json.load(open(RES / "f01_scenarios_timeseries.json", encoding="utf-8"))
show = ["S03_repeated_lookaways", "S04_sustained_absence", "S05_camera_interrupted", "S06_focus_and_absence", "S11_flicker_boundary", "S13_detector_dropouts"]
fig, axes = plt.subplots(2, 3, figsize=(16, 8.2)); fig.subplots_adjust(top=0.84, bottom=0.09, hspace=0.42, wspace=0.18, left=0.05, right=0.98)
for ax, name in zip(axes.flat, show):
    d = TS[name]; t = np.arange(len(d["v2"]))
    ax.axhspan(0, 30, color="#E6F2EC", zorder=0); ax.axhspan(30, 60, color="#FBF0DC", zorder=0); ax.axhspan(60, 100, color="#F8E3E3", zorder=0)
    st = np.array(d["v2_state"])
    for s, a in (("INSUFFICIENT_EVIDENCE", 0.30), ("DEGRADED", 0.13)):
        m = st == s
        if m.any(): ax.fill_between(t, 0, 100, where=m, color=GREY, alpha=a, step="mid", lw=0)
    for key in ("away", "absent", "focusLost", "cameraOff"):
        for a, b in d["behaviour"][key]: ax.axvspan(a, min(b, len(t)), ymin=0.0, ymax=0.03, color={"away": BLUE, "absent": ORANGE, "focusLost": RED, "cameraOff": NAVY}[key])
    ax.plot(t, d["v1"], color=GREY, lw=1.4, ls="--", label="v1 (old app)"); ax.plot(t, d["v2"], color=TEAL, lw=2, label="v2 assessment")
    ax.set_ylim(0, 100); ax.set_xlim(0, len(t)); ax.set_title(name.split("_", 1)[1].replace("_", " "), loc="left"); ax.set_xlabel("seconds")
axes[0, 0].legend(loc="upper right", fontsize=9)
frame(fig, "Controlled scenarios: what the old and new scores do", "Synthetic, seeded inputs (software behaviour, not accuracy) · grey = INSUFFICIENT_EVIDENCE, light grey = DEGRADED · ticks at the bottom mark when the behaviour happens",
      "research/final/results/f01_scenarios_timeseries.json, f01_scenarios_metrics.csv")
fig.savefig(FIG / "scenario_trajectories.png", dpi=170); plt.close(fig)

# 2. OEP evidence
f02 = json.load(open(RES / "f02_summary.json")); f2b = json.load(open(RES / "f02b_summary.json")); OP = pd.read_csv(RES / "f02c_operating_points.csv")
fig = plt.figure(figsize=(16, 6.4)); a1 = fig.add_axes([0.06, 0.14, 0.26, 0.66]); a2 = fig.add_axes([0.40, 0.14, 0.26, 0.66]); a3 = fig.add_axes([0.73, 0.14, 0.25, 0.66])
rows = [("v1 (frozen)", f02["engines"]["v1"]), ("v2.0 (pre-registered)", f02["engines"]["v2"]), ("v2.1 (exploratory)", f2b["engines"]["v2"])]
for i, (lab, e) in enumerate(rows):
    a1.errorbar(e["ranked_auroc"], i, xerr=[[e["ranked_auroc"] - e["lo"]], [e["hi"] - e["ranked_auroc"]]], fmt="o", ms=9, capsize=4, lw=2, color=[GREY, TEAL, BLUE][i]); a1.text(e["hi"] + 0.005, i, f"{e['ranked_auroc']:.3f}", va="center", fontsize=9.5)
a1.axvline(0.5, color=MUTED, ls="--"); a1.set_yticks(range(3), [r[0] for r in rows]); a1.invert_yaxis(); a1.set_xlim(0.44, 0.66); a1.set_xlabel("AUROC, within-subject ranks (95% CI)"); a1.set_title("Ranking of annotated windows")
for i, (lab, d) in enumerate((("v2.0 − v1", f02["primary"]), ("v2.1 − v1", f2b["primary"]))):
    p = d["diff_v2_minus_v1"]; a2.errorbar(p, i, xerr=[[p - d["lo"]], [d["hi"] - p]], fmt="o", ms=9, capsize=4, lw=2, color=[TEAL, BLUE][i]); a2.text(p, i - 0.25, f"{p:+.3f} [{d['lo']:+.3f}, {d['hi']:+.3f}]", ha="center", fontsize=9)
a2.axvline(0, color=MUTED, ls="--"); a2.axvline(-0.05, color=RED, ls=":"); a2.text(-0.049, 1.45, "non-inferiority\nmargin −0.05", color=RED, fontsize=8.5); a2.set_yticks(range(2), ["v2.0 − v1", "v2.1 − v1"]); a2.set_ylim(1.7, -0.6); a2.set_xlim(-0.08, 0.05); a2.set_xlabel("paired difference (95% CI)"); a2.set_title("Primary comparison")
for k, c, lab in (("v1", GREY, "v1"), ("v2", BLUE, "v2.1")):
    a3.plot(OP.threshold, OP[f"{k}_neg_share"], color=c, lw=2, label=f"{lab}: normal windows"); a3.plot(OP.threshold, OP[f"{k}_pos_share"], color=c, lw=2, ls="--", label=f"{lab}: annotated cheating")
a3.axvline(30, color=MUTED, lw=1); a3.axvline(60, color=MUTED, lw=1); a3.set_xlabel("window score threshold"); a3.set_ylabel("share of windows at or above"); a3.set_title("Burden vs threshold"); a3.legend(fontsize=8.5)
frame(fig, "OEP (24 subjects): the new score keeps ranking performance; neither score separates cheating windows", "Same 1,956 windows as the earlier s13 analysis · subject-level bootstrap · solid and dashed lines nearly coincide: thresholds set review burden, not detection",
      "research/final/results/f02_summary.json, f02b_summary.json, f02c_operating_points.csv")
fig.savefig(FIG / "oep_v2_vs_v1.png", dpi=170); plt.close(fig)
print("saved", sorted(p.name for p in FIG.glob("*.png")))
