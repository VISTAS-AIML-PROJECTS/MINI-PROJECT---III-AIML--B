"""F05 diagnostic: per-subject direction of the attention / presence group scores and of v2 (reads f05_window_scores.csv).
    python -X utf8 research/final/f05_diagnostic.py   ->  research/final/results/f05_diagnostic.json"""
import json
from pathlib import Path
import numpy as np, pandas as pd
from sklearn.metrics import roc_auc_score
R = Path(__file__).resolve().parent / "results"
W = pd.read_csv(R / "f05_window_scores.csv"); rows = []
for s, g in W.groupby("subject"):
    if g.y.nunique() < 2: continue
    rows.append({"subject": int(s), **{c: (roc_auc_score(g.y, g[c]) if g[c].nunique() > 1 else np.nan) for c in ["attention", "presence", "v2"]}})
D = pd.DataFrame(rows); C = ["attention", "presence", "v2"]
json.dump({"per_subject_auroc_median": {c: float(D[c].median()) for c in C}, "subjects_above_half": {c: int((D[c] > 0.5).sum()) for c in C},
           "subjects_below_half": {c: int((D[c] < 0.5).sum()) for c in C}, "n_subjects_with_both_classes": int(len(D))}, open(R / "f05_diagnostic.json", "w"), indent=1)
