// Replays a recorded signal stream through the v2 AssessmentPipeline (src/assessment/pipeline.js), ticking once per second
// of signal time exactly as the app does. Input (stdin): {"frames":[{"t":<ms>,"signals":[...]}, ...]} (research/final/oep_frames.py).
// Output: JSON {"t":[...], "score":[...], "level":[...], "state":[...], "reliability":[...], "legacy":[...]} one entry per tick.
// Usage: node replay_v2.mjs [--no-focus]
import { AssessmentPipeline } from "../../src/assessment/pipeline.js";

const chunks = []; for await (const c of process.stdin) chunks.push(c);
const { frames } = JSON.parse(Buffer.concat(chunks).toString("utf8"));
const focusAvailable = !process.argv.includes("--no-focus");
const p = new AssessmentPipeline({ focusAvailable });
const out = { t: [], score: [], level: [], state: [], reliability: [], legacy: [] };
const push = (a) => { out.t.push(a.timestamp); out.score.push(a.score); out.level.push(a.level); out.state.push(a.state); out.reliability.push(+a.reliability.toFixed(4)); out.legacy.push(a.legacy?.score ?? null); };
if (frames.length) {
  const t0 = frames[0].t; p.start(t0); p.setCalibrated(true);
  let next = t0 + 1000;
  for (const fr of frames) {
    while (fr.t >= next) { push(p.tick(next)); next += 1000; }
    for (const s of fr.signals) p.processSignal({ type: s.type, source: "vision", timestamp: fr.t, value: s.value, confidence: s.confidence ?? 1, metadata: s.metadata ?? {} });
  }
  push(p.tick(next));
}
console.log(JSON.stringify(out));
