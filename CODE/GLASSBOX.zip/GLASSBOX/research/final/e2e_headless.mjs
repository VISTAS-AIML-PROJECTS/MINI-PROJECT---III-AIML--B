// End-to-end check without a camera: the app's own client modules (AssessmentPipeline -> PersistenceManager -> glassboxApi)
// drive the REAL Express server (spawned on a throw-away database) with a scripted session, then the session is read back
// through GET /api/sessions/:id and summarised exactly as the history page does. Writes research/final/results/e2e_headless.json.
//   node research/final/e2e_headless.mjs
// Requires port 5000 to be free (the frontend API client is fixed to localhost:5000).
// E2E_DB=<path> keeps the database afterwards (used to produce the screenshots in docs/final/screenshots/).
import { spawn } from "child_process";
import fs from "fs";
import os from "os";
import path from "path";
import { fileURLToPath } from "url";
import { SCENARIOS } from "./scenarios.mjs";
import { AssessmentPipeline } from "../../src/assessment/pipeline.js";
import { PersistenceManager } from "../../src/api/persistenceManager.js";
import { createExam, createStudent, createExamSession, endExamSession, getSession } from "../../src/api/glassboxApi.js";
import { summarizeRisk } from "../../src/review/sessionSummary.js";
import { segmentHeadDeviation, reviewFirst } from "../../src/review/reviewPriority.js";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../..");
const dir = fs.mkdtempSync(path.join(os.tmpdir(), "glassbox-e2e-"));
const dbPath = process.env.E2E_DB || path.join(dir, "e2e.db");
const server = spawn(process.execPath, [path.join(ROOT, "server", "server.js")], { env: { ...process.env, GLASSBOX_DB_PATH: dbPath }, stdio: ["ignore", "pipe", "pipe"] });
await new Promise((resolve, reject) => {
  server.stdout.on("data", (d) => String(d).includes("running") && resolve());
  server.on("exit", (c) => reject(new Error(`server exited ${c}`)));
  setTimeout(() => reject(new Error("server did not start")), 15000);
});

const checks = []; const check = (name, ok, detail = "") => { checks.push({ name, ok: Boolean(ok), detail }); console.log(`${ok ? "PASS" : "FAIL"} ${name} ${detail}`); };
const realNow = Date.now;
try {
  // Scenario S06 (focus loss + face absence) followed by the end-during-absence case, played as one session.
  const sc = SCENARIOS.find((s) => s.name === "S06_focus_and_absence");
  const exam = await createExam("e2e"); const student = await createStudent("e2e", `e2e-${realNow()}@x`);
  const { session } = await createExamSession(exam.exam.id, student.student.id, "MULTI_SIGNAL");
  const t0 = new Date(session.started_at).getTime();
  let clock = t0; Date.now = () => clock;                          // PersistenceManager throttles on Date.now: drive it with signal time
  const pm = new PersistenceManager({ sessionId: session.id });
  const p = new AssessmentPipeline({ onEvidence: (e) => pm.addEvidence(e) });
  p.start(t0); p.setCalibrated(true);
  let next = t0 + 1000; let ticks = 0; const shift = t0 - sc.frames[0].t;
  for (const fr of sc.frames) {
    const t = fr.t + shift; clock = t;
    while (t >= next) { pm.addRisk(p.tick(next)); next += 1000; ticks++; if (ticks % 20 === 0) await pm.flush(); }
    for (const s of fr.signals) { const sig = { ...s, timestamp: t, confidence: s.confidence ?? 1, metadata: s.metadata ?? {} }; pm.addSignal(sig); p.processSignal(sig); }
  }
  pm.addRisk(p.finalize(next)); ticks++;
  Date.now = realNow;
  await pm.flush(); await endExamSession(session.id);

  const back = await getSession(session.id);
  const summary = summarizeRisk(back.risk);
  const priority = reviewFirst(segmentHeadDeviation(back.signals, { startMs: t0 }));
  check("session completed", back.session.status === "COMPLETED", back.session.status);
  check("one risk row per tick (no per-frame writes)", back.risk.length === ticks, `${back.risk.length} rows / ${ticks} ticks`);
  check("every risk row carries v2 state, reliability and version", back.risk.every((r) => r.state && Number.isFinite(r.reliability) && r.engine_version === "glassbox-assessment-2.1"));
  check("stored contributions recompose every stored score", back.risk.every((r) => Math.abs(Math.round(Object.values(r.details.contributions).reduce((a, c) => a + c.points, 0)) - r.score) <= 1));
  check("corroborated focus loss + absence reached HIGH", summary.peak >= 60, `peak ${summary.peak}`);
  check("face-absence and focus-loss episodes persisted", ["FACE_ABSENCE_EPISODE", "FOCUS_LOSS_EPISODE"].every((t) => back.evidence.some((e) => e.type === t)));
  check("vision samples stored ~1/s per type", back.signals.filter((s) => s.type === "HEAD_POSE_DEVIATION").length <= sc.end + 2);
  check("review priority computed from stored signals", priority.length > 0, `${priority.length} segments`);
  check("legacy v1 score kept for comparison", back.risk.every((r) => Number.isFinite(r.details.legacy?.score)));
  fs.writeFileSync(path.join(ROOT, "research", "final", "results", "e2e_headless.json"), JSON.stringify({ scenario: sc.name, session_id: session.id, risk_rows: back.risk.length, evidence: back.evidence.length, signals: back.signals.length, summary, checks }, null, 1));
} finally {
  Date.now = realNow; server.kill(); await new Promise((r) => setTimeout(r, 500)); fs.rmSync(dir, { recursive: true, force: true });
}
const failed = checks.filter((c) => !c.ok).length; console.log(`${checks.length - failed}/${checks.length} checks passed`); process.exit(failed ? 1 : 0);
