// Shared replay runners for scenarios (research/final/scenarios.mjs format), used by run_scenarios.mjs and the tests.
import { T0 } from "./scenarios.mjs";
import { EvidenceEngine } from "../../src/evidence/evidenceEngine.js";
import { FusionEngine } from "../../src/risk/fusionEngine.js";
import { RiskEngine } from "../../src/risk/riskEngine.js";
import { AssessmentPipeline } from "../../src/assessment/pipeline.js";

// v1 exactly as wired in the pre-v2 App.jsx: every signal -> evidence + fusion; the
// risk shown is the last one EMITTED (on fusion or evidence). Persisted episodes are
// those emitted while the session flag is still true (the old end-of-session order
// cleared the flag BEFORE evidenceEngine.reset()).
export function runV1(sc) {
  let now = 0; const origNow = Date.now; Date.now = () => now;
  let shown = null; const persistedEvidence = []; let active = true; let riskRows = 0;
  const risk = new RiskEngine({ onRisk: (r) => { shown = r; if (active) riskRows++; } });
  const ee = new EvidenceEngine({ onEvidence: (e) => { risk.processEvidence(e); if (active) persistedEvidence.push(e); } });
  const fe = new FusionEngine({ onFusion: (f) => risk.processFusion(f) });
  const perSecond = [];
  try {
    let nextTick = T0 + 1000;
    for (const fr of sc.frames) {
      while (fr.t >= nextTick) { perSecond.push(shown ? shown.score : 0); nextTick += 1000; }
      now = fr.t;
      for (const s of fr.signals) { const sig = { ...s, timestamp: fr.t, confidence: s.confidence ?? 1, metadata: s.metadata ?? {} }; ee.processSignal(sig); fe.processSignal(sig); }
    }
    while (perSecond.length < sc.end) { perSecond.push(shown ? shown.score : 0); nextTick += 1000; }
    // old handleEndSession: active=false, then reset() (emits only gaze/head episodes)
    now = T0 + sc.end * 1000; active = false; ee.reset();
  } finally { Date.now = origNow; }
  return { perSecond, persistedEvidence, riskRows };
}

// v2: the same AssessmentPipeline the app runs, ticked once per second of signal time.
export function runV2(sc, { pipeline } = {}) {
  const persistedEvidence = [];
  const p = pipeline ?? new AssessmentPipeline({ focusAvailable: sc.focusAvailable, onEvidence: (e) => persistedEvidence.push(e) });
  p.start(T0);
  p.setCalibrated(sc.calibrated);
  const rows = []; let nextTick = T0 + 1000;
  for (const fr of sc.frames) {
    while (fr.t >= nextTick) { rows.push(p.tick(nextTick)); nextTick += 1000; }
    for (const s of fr.signals) p.processSignal({ ...s, timestamp: fr.t, confidence: s.confidence ?? 1, metadata: s.metadata ?? {} });
  }
  while (rows.length < sc.end) { rows.push(p.tick(nextTick)); nextTick += 1000; }
  const final = p.finalize(T0 + sc.end * 1000);
  return { rows, final, persistedEvidence };
}
