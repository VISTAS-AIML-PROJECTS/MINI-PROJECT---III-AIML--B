// F01 - Controlled scenario comparison: frozen v1 chain (as the old app displayed it) vs the v2 assessment pipeline.
// Usage: node research/final/run_scenarios.mjs [outDir]
// Writes f01_scenarios_timeseries.json and f01_scenarios_metrics.csv (synthetic, seeded, deterministic).
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { SCENARIOS } from "./scenarios.mjs";
import { runV1, runV2 } from "./runners.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const OUT = path.resolve(process.argv[2] ?? path.join(HERE, "results"));
fs.mkdirSync(OUT, { recursive: true });

const levelOf = (s) => (s >= 60 ? "HIGH" : s >= 30 ? "MEDIUM" : "LOW");
function transitions(levels) { const l = levels.filter((x) => x !== "UNDETERMINED"); let n = 0; for (let i = 1; i < l.length; i++) if (l[i] !== l[i - 1]) n++; return n; }
const firstOnset = (sc) => Math.min(...[...sc.behaviour.away, ...sc.behaviour.absent, ...sc.behaviour.focusLost].map(([a]) => a), Infinity);
const lastOffset = (sc) => Math.max(...[...sc.behaviour.away, ...sc.behaviour.absent, ...sc.behaviour.focusLost].map(([, b]) => Math.min(b, sc.end)), -Infinity);
function firstAtLeast(series, thr, from) { for (let i = Math.max(0, Math.ceil(from)); i < series.length; i++) if (series[i] >= thr) return i - from; return null; }
function backBelow(series, thr, from) { if (!Number.isFinite(from)) return null; for (let i = Math.ceil(from); i < series.length; i++) if (series[i] < thr) return i - from; return null; }

const metrics = []; const ts = {};
for (const sc of SCENARIOS) {
  const v1 = runV1(sc); const v2 = runV2(sc);
  const s1 = v1.perSecond; const s2 = v2.rows.map((r) => r.score);
  const on = firstOnset(sc); const off = lastOffset(sc);
  const absentTotal = sc.behaviour.absent.reduce((a, [x, y]) => a + Math.max(0, Math.min(y, sc.end) - x), 0);
  const persistedAbsence = (ev) => ev.filter((e) => e.type === "FACE_ABSENCE_EPISODE").reduce((a, e) => a + e.durationMs / 1000, 0);
  const persistedFocus = (ev) => ev.filter((e) => e.type === "FOCUS_LOSS_EPISODE").reduce((a, e) => a + e.durationMs / 1000, 0);
  const mid = (arr, a, b) => { const v = arr.slice(Math.max(0, a), Math.min(arr.length, b)); return v.length ? Math.max(...v) : null; };
  metrics.push({
    scenario: sc.name, description: sc.description, duration_s: sc.end,
    v1_max: Math.max(...s1), v2_max: Math.max(...s2),
    v1_final_shown: s1.at(-1), v2_final: v2.final.score, v2_final_level: v2.final.level, v2_final_state: v2.final.state,
    v1_level_changes: transitions(s1.map(levelOf)), v2_level_changes: transitions(v2.rows.map((r) => r.level)),
    v1_s_to_medium_after_onset: Number.isFinite(on) ? firstAtLeast(s1, 30, on) : null,
    v2_s_to_medium_after_onset: Number.isFinite(on) ? firstAtLeast(s2, 30, on) : null,
    v1_s_back_below_10_after_offset: backBelow(s1, 10, off), v2_s_back_below_10_after_offset: backBelow(s2, 10, off),
    v1_max_during_first_absence: sc.behaviour.absent.length ? mid(s1, sc.behaviour.absent[0][0], sc.behaviour.absent[0][1]) : null,
    v2_max_during_first_absence: sc.behaviour.absent.length ? mid(s2, sc.behaviour.absent[0][0], sc.behaviour.absent[0][1]) : null,
    v2_min_reliability: Math.min(...v2.rows.map((r) => r.reliability)),
    v2_seconds_insufficient: v2.rows.filter((r) => r.state === "INSUFFICIENT_EVIDENCE").length,
    v2_seconds_degraded: v2.rows.filter((r) => r.state === "DEGRADED").length,
    absent_s_true: absentTotal, v1_absent_s_persisted: persistedAbsence(v1.persistedEvidence), v2_absent_s_persisted: persistedAbsence(v2.persistedEvidence),
    v1_focus_s_persisted: persistedFocus(v1.persistedEvidence), v2_focus_s_persisted: persistedFocus(v2.persistedEvidence),
    v1_risk_rows_written: v1.riskRows, v2_risk_rows_written: v2.rows.length + 1,
  });
  ts[sc.name] = { description: sc.description, behaviour: sc.behaviour, v1: s1, v2: s2, v2_state: v2.rows.map((r) => r.state), v2_reliability: v2.rows.map((r) => +r.reliability.toFixed(3)), v2_level: v2.rows.map((r) => r.level) };
}

fs.writeFileSync(path.join(OUT, "f01_scenarios_timeseries.json"), JSON.stringify(ts));
const cols = Object.keys(metrics[0]);
const esc = (v) => (v === null || v === undefined ? "" : typeof v === "string" && /[",]/.test(v) ? `"${v.replace(/"/g, '""')}"` : typeof v === "number" ? +v.toFixed(4) : v);
fs.writeFileSync(path.join(OUT, "f01_scenarios_metrics.csv"), [cols.join(","), ...metrics.map((m) => cols.map((c) => esc(m[c])).join(","))].join("\n") + "\n");
console.table(metrics.map((m) => ({ s: m.scenario, v1max: m.v1_max, v2max: m.v2_max, v1fin: m.v1_final_shown, v2fin: m.v2_final, lvl: m.v2_final_level, state: m.v2_final_state, chg1: m.v1_level_changes, chg2: m.v2_level_changes, abs1: m.v1_max_during_first_absence, abs2: m.v2_max_during_first_absence, rows1: m.v1_risk_rows_written })));
