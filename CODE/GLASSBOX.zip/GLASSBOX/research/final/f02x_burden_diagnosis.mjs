// F02x - EXPLORATORY diagnosis of the v2.0 alert burden seen in F02 (8 subjects inspected: 1,5,8,10,11,13,18,22). Prints, per subject,
// the share of ticks >= MEDIUM, which channel drives them, and episode rates / median durations. Run: node research/final/f02x_burden_diagnosis.mjs
import { AssessmentPipeline } from "../../src/assessment/pipeline.js";
import fs from "fs";
const res = {};
for (const n of [1,5,8,10,11,13,18,22]) {
  const { frames } = JSON.parse(fs.readFileSync(new URL(`../../data/processed/final_frames/subject${n}.json`, import.meta.url), "utf8"));
  const p = new AssessmentPipeline({ focusAvailable: false }); p.start(frames[0].t); p.setCalibrated(true);
  let next = frames[0].t + 1000; const rows = []; const ev = [];
  p.evidenceEngine.onEvidence = ((orig) => (e) => { ev.push(e); orig(e); })(p.evidenceEngine.onEvidence);
  for (const fr of frames) { while (fr.t >= next) { rows.push(p.tick(next)); next += 1000; } for (const s of fr.signals) p.processSignal({ ...s, source: "vision", timestamp: fr.t, confidence: 1, metadata: s.metadata ?? {} }); }
  const med = rows.filter(r => r.score >= 30);
  const drv = {}; for (const r of med) { const top = Object.entries(r.contributions).sort((a,b)=>b[1].points-a[1].points)[0][0]; const d = r.groups[top].driver; drv[d] = (drv[d]||0)+1; }
  const mins = rows.length/60; const cnt = {}; const dur = {};
  for (const e of ev) { cnt[e.type]=(cnt[e.type]||0)+1; dur[e.type]=(dur[e.type]||[]).concat(e.durationMs/1000); }
  const med_ = a => { const s=[...a].sort((x,y)=>x-y); return s[Math.floor(s.length/2)]; };
  res[n] = { minutes: +mins.toFixed(1), geMedium: +(med.length/rows.length).toFixed(2), drivers: drv,
    perMin: Object.fromEntries(Object.entries(cnt).map(([k,v])=>[k.replace("_EPISODE",""), +(v/mins).toFixed(2)])),
    medianDurS: Object.fromEntries(Object.entries(dur).map(([k,v])=>[k.replace("_EPISODE",""), +med_(v).toFixed(1)])),
    meanAttention: +(rows.reduce((a,r)=>a+r.groups.attention.score,0)/rows.length).toFixed(2), meanPresence: +(rows.reduce((a,r)=>a+r.groups.presence.score,0)/rows.length).toFixed(2) };
}
console.log(JSON.stringify(res, null, 1));
