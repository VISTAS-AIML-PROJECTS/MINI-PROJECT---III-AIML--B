"""F00 - Regression guard: the v1 chain (Evidence -> Fusion -> Risk) must give IDENTICAL per-frame scores before and after the v2 work.
Replays every OEP subject through research/tests/replay_signals.mjs twice: once against the src/ tree of a reference commit
(default b6f1669, the last commit before any engine change) and once against the working tree. Any difference fails.
    python -X utf8 research/final/f00_v1_parity.py [ref-commit]"""
import json, subprocess, sys, tempfile, tarfile, io
from pathlib import Path
from oep_frames import frames_for, E, ROOT

ref = sys.argv[1] if len(sys.argv) > 1 else "b6f1669"
tmp = Path(tempfile.mkdtemp(prefix="gb_ref_src_"))
tar = subprocess.run(["git", "archive", ref, "src"], cwd=ROOT, capture_output=True, check=True).stdout
tarfile.open(fileobj=io.BytesIO(tar)).extractall(tmp)
REPLAY = ROOT / "research" / "tests" / "replay_signals.mjs"
rows, ok = [], True
for n in E.SUBJECTS:
    inp = frames_for(n).read_text(encoding="utf-8")
    old = json.loads(subprocess.run(["node", str(REPLAY), str(tmp / "src")], input=inp, capture_output=True, text=True, check=True).stdout)
    new = json.loads(subprocess.run(["node", str(REPLAY), str(ROOT / "src")], input=inp, capture_output=True, text=True, check=True).stdout)
    same = old == new; ok &= same; rows.append((n, len(old), same))
    print(f"subject {n:2d}: {len(old):5d} frames  identical={same}", flush=True)
out = ROOT / "research" / "final" / "results"; out.mkdir(parents=True, exist_ok=True)
(out / "f00_v1_parity.json").write_text(json.dumps(dict(reference_commit=ref, subjects=len(rows), frames=sum(r[1] for r in rows), all_identical=bool(ok),
                                                       per_subject=[dict(subject=n, frames=k, identical=s) for n, k, s in rows]), indent=1), encoding="utf-8")
print("ALL IDENTICAL" if ok else "DIFFERENCES FOUND"); sys.exit(0 if ok else 1)
