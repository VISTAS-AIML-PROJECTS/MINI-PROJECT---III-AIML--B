// Like replay_v2.mjs but also emits the v2 group scores (attention, presence, focus) and per-channel scores each tick,
// so offline experiments can ask whether other weights over the SAME groups would rank better. Read-only import of src/.
// Usage: node replay_v2_groups.mjs [--no-focus]   (stdin: {"frames":[...]} as in research/final/oep_frames.py)
import { AssessmentPipeline } from "../../src/assessment/pipeline.js";

const chunks = []; for await (const c of process.stdin) chunks.push(c);
const { frames } = JSON.parse(Buffer.concat(chunks).toString("utf8"));
const p = new AssessmentPipeline({ focusAvailable: !process.argv.includes("--no-focus") });
const out = { t: [], score: [], attention: [], presence: [], focus: [] };
const push = (a) => {
  out.t.push(a.timestamp); out.score.push(a.score);
  for (const g of ["attention", "presence", "focus"]) out[g].push(a.groups[g] ? +a.groups[g].score.toFixed(6) : 0);
};
if (frames.length) {
  const t0 = frames[0].t; p.start(t0); p.setCalibrated(true);
  let next = t0 + 1000;
  for (const fr of frames) {
    while (fr.t >= next) { push(p.tick(next)); next += 1000; }
    for (const s of fr.signals) p.processSignal({ type: s.type, source: "vision", timestamp: fr.t, value: s.value, confidence: s.confidence ?? 1, metadata: s.metadata ?? {} });
  }
  push(p.tick(next));
}
console.log(JSON.stringify(out));
