"""F02c - Operating-point table (descriptive, no threshold is chosen from it): for each window-score threshold, the share of OEP
negative and positive windows at or above it, for v1 and v2.1 (research/final/results/f02b_window_scores.csv). Shows what any band
would cost in review burden on OEP; OEP is not a deployment-calibration set (dense, acted cheating; see docs/final/EVIDENCE_AND_LIMITATIONS.md)."""
from pathlib import Path
import numpy as np, pandas as pd
HERE = Path(__file__).resolve().parent
W = pd.read_csv(HERE / "results" / "f02b_window_scores.csv"); rows = []
for thr in range(10, 95, 5):
    r = dict(threshold=thr)
    for k in ("v1", "v2"):
        r[f"{k}_neg_share"] = float((W[k][W.y == 0] >= thr).mean()); r[f"{k}_pos_share"] = float((W[k][W.y == 1] >= thr).mean())
    rows.append(r)
T = pd.DataFrame(rows); T.to_csv(HERE / "results" / "f02c_operating_points.csv", index=False); print(T.round(3).to_string(index=False))
