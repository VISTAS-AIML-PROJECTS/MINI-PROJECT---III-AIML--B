// Seeded synthetic signal streams for controlled SOFTWARE tests of the scoring chain.
// They exercise timing, persistence, missing data and boundary behaviour. They are NOT
// evidence of real-world accuracy: the behaviour amplitudes are chosen to be clearly
// above/below the deviation gates (src/evidence/deviation.js), not measured from people.
//
// A scenario is { name, description, durationS, focusAvailable, calibrated, events, end }
// where each vision frame (20 fps) is produced by frameAt(t) and browser events are listed.

export function rng(seed) {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function gauss(r) {
  const u = Math.max(r(), 1e-12);
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * r());
}

export const T0 = 1_000_000;
const FPS = 20;
const BASE_STD = { yaw: 2.0, pitch: 2.0, roll: 1.5 };

// Calm behaviour: gaze z ~ |N(0,1)|, head deviation per axis ~ |N(0, baseline sd)|.
// Look-away: gaze z 6, head yaw 30 deg (well above the 8 deg / 3 sd gate).
function visionFrame(t, r, state, calibrated) {
  if (state.absent) {
    return [{ type: "FACE_ABSENT", value: true }];
  }
  const out = [
    { type: "FACE_PRESENT", value: true },
    { type: "FACE_QUALITY", value: 0.6, confidence: 0.6 },
  ];
  if (!calibrated) return out;
  const away = state.away;
  out.push({
    type: "GAZE_DEVIATION",
    value: away ? 6 + Math.abs(gauss(r)) : Math.abs(gauss(r)),
    confidence: 0.6,
  });
  out.push({
    type: "HEAD_POSE_DEVIATION",
    value: {
      yaw: away ? 30 + 2 * gauss(r) : Math.abs(BASE_STD.yaw * gauss(r)),
      pitch: Math.abs(BASE_STD.pitch * gauss(r)),
      roll: Math.abs(BASE_STD.roll * gauss(r)),
    },
    confidence: 0.6,
    metadata: { baselineStd: BASE_STD },
  });
  return out;
}

const within = (t, iv) => iv.some(([a, b]) => t >= a && t < b);

function build({ name, description, durationS, away = [], absent = [], cameraOff = [], focusLost = [], calibrated = true, focusAvailable = true, seed = 1, endEarlyS = null }) {
  const r = rng(seed);
  const frames = [];
  const end = endEarlyS ?? durationS;
  for (let k = 0; k < end * FPS; k++) {
    const ts = k / FPS;
    const t = T0 + Math.round(ts * 1000);
    const sig = [];
    if (!within(ts, cameraOff)) {
      for (const s of visionFrame(t, r, { away: within(ts, away), absent: within(ts, absent) }, calibrated)) sig.push({ ...s, source: "vision" });
    }
    for (const [a, b] of focusLost) {
      if (Math.abs(ts - a) < 1e-9) sig.push({ type: "FOCUS_LOST", source: "browser", value: true });
      if (Math.abs(ts - b) < 1e-9) sig.push({ type: "FOCUS_GAINED", source: "browser", value: true });
    }
    frames.push({ t, signals: sig });
  }
  return {
    name, description, durationS, end, calibrated, focusAvailable, frames,
    behaviour: { away, absent, cameraOff, focusLost },
  };
}

const repeated = (start, n, every, len) => Array.from({ length: n }, (_, i) => [start + i * every, start + i * every + len]);

export const SCENARIOS = [
  build({ name: "S01_calm", description: "5 min of calm, calibrated behaviour", durationS: 300, seed: 11 }),
  build({ name: "S02_isolated_glance", description: "Calm with one 1.5 s look-away at 60 s", durationS: 300, away: [[60, 61.5]], seed: 12 }),
  build({ name: "S03_repeated_lookaways", description: "Six 4 s head turns every 30 s from 60 s, then calm", durationS: 600, away: repeated(60, 6, 30, 4), seed: 13 }),
  build({ name: "S04_sustained_absence", description: "Face out of frame 60-180 s (2 min), then back", durationS: 300, absent: [[60, 180]], seed: 14 }),
  build({ name: "S05_camera_interrupted", description: "Camera delivers no frames 60-240 s (disconnect / tab throttled)", durationS: 300, cameraOff: [[60, 240]], seed: 15 }),
  build({ name: "S06_focus_and_absence", description: "Focus lost 100-120 s while the face is also out of frame", durationS: 300, absent: [[100, 120]], focusLost: [[100, 120]], seed: 16 }),
  build({ name: "S07_lookaways_then_calm", description: "Look-aways 30-150 s then 7.5 min calm (recovery)", durationS: 600, away: repeated(30, 5, 25, 5), seed: 17 }),
  build({ name: "S08_uncalibrated", description: "Face present for 5 min, no calibration (no gaze/head samples)", durationS: 300, calibrated: false, seed: 18 }),
  build({ name: "S09_end_during_absence", description: "Session ends at 150 s while the face has been absent since 90 s", durationS: 150, absent: [[90, 150]], seed: 19 }),
  build({ name: "S10_end_during_focus_loss", description: "Session ends at 150 s while focus has been lost since 120 s", durationS: 150, focusLost: [[120, 1e9]], seed: 20 }),
  build({ name: "S11_flicker_boundary", description: "Look-aways spaced to hold the score near the MEDIUM boundary", durationS: 600, away: repeated(30, 14, 40, 3), seed: 21 }),
  build({ name: "S12_short_session", description: "Session of only 8 s", durationS: 8, seed: 22 }),
  build({ name: "S13_detector_dropouts", description: "Calm, but the face detector drops 1-3 frames about 6 times a minute (OEP-like blips)", durationS: 300,
          absent: Array.from({ length: 30 }, (_, i) => [10 + i * 9.7, 10 + i * 9.7 + 0.05 * (1 + (i % 3))]), seed: 23 }),
];
