"""Build (and cache) the per-subject OEP signal streams exactly as research/exp12_oep_models.py:engine_risk feeds the JS engines:
frames after the 120-s label-agnostic calibration, personal baseline, FACE_PRESENT / GAZE_DEVIATION / HEAD_POSE_DEVIATION or FACE_ABSENT.
Cached JSON goes to data/processed/final_frames/ (data/ is gitignored; OEP must not be redistributed)."""
import json, sys
from pathlib import Path
import numpy as np
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "research")); sys.dont_write_bytecode = True
import exp12_oep_models as E

CACHE = ROOT / "data" / "processed" / "final_frames"; CACHE.mkdir(parents=True, exist_ok=True)

def frames_for(n):
    p = CACHE / f"subject{n}.json"
    if p.exists():
        return p
    f = E.frames[n]; ev = f[f.t >= E.CAL_S].reset_index(drop=True); mu, sd = E.baseline(n, "personal"); fr = []
    for r in ev.itertuples():
        sig = []
        if r.det == 1:
            sig.append(dict(type="FACE_PRESENT", value=True))
            if not np.isnan(r.hhat):
                sig.append(dict(type="GAZE_DEVIATION", value=abs(r.hhat - mu["hhat"]) / max(sd["hhat"], 0.5)))
                sig.append(dict(type="HEAD_POSE_DEVIATION", value={a: abs(getattr(r, a) - mu[a]) for a in E.HEAD},
                                metadata=dict(baselineStd={a: max(sd[a], 0.1) for a in E.HEAD})))
        else:
            sig.append(dict(type="FACE_ABSENT", value=True))
        fr.append(dict(t=int(1_000_000 + r.t * 1000), signals=sig))
    p.write_text(json.dumps(dict(frames=fr)), encoding="utf-8")
    return p
