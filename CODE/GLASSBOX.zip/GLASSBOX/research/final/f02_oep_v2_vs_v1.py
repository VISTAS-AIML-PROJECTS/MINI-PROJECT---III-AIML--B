"""F02 - Pre-registered (docs/final/F02_PREREGISTRATION.md): v2 assessment vs the frozen v1 engine on OEP, same windows as s13.
    python -X utf8 research/final/f02_oep_v2_vs_v1.py
Primary: paired ranked-AUROC difference v2 - v1 (subject bootstrap, 1000 resamples, seed 20261021); non-inferiority if lower bound > -0.05.
Secondary (descriptive): raw/within-subject AUROC, 33% review-budget metrics, fixed-threshold bands, alert burden, level changes,
delay to MEDIUM inside annotated intervals, reliability states vs face-detection rate. Writes research/final/results/f02_*."""
import json, subprocess, sys
from pathlib import Path
import numpy as np, pandas as pd
from scipy.stats import spearmanr
from sklearn.metrics import roc_auc_score
from oep_frames import frames_for, E, ROOT
sys.path.insert(0, str(ROOT / "docs" / "results_2" / "scripts"))
from r2common import boot_pooled_auc
import exp14_oep_improvements as X14
from oep_common import EX, load_gt

HERE = Path(__file__).resolve().parent; OUT = HERE / "results"; OUT.mkdir(exist_ok=True)
TAG = sys.argv[1] if len(sys.argv) > 1 else "f02"          # f02 = pre-registered v2.0 run; f02b = exploratory rerun after the v2.1 change
INSPECTED = {1, 5, 8, 10, 11, 13, 18, 22}                     # subjects looked at in the f02x diagnosis
S13 = ROOT / "docs" / "results_2" / "comparisons" / "s13_window_scores.csv"
W = pd.read_csv(S13)[["subject", "t0", "y", "Rule engine (app)"]].rename(columns={"Rule engine (app)": "v1"})
REPLAY_V1 = ROOT / "research" / "tests" / "replay_signals.mjs"; REPLAY_V2 = HERE / "replay_v2.mjs"
lvl = lambda s: np.where(s >= 60, 2, np.where(s >= 30, 1, 0))

ticks, v1_sec, per_subject_meta = {}, {}, {}
for n in E.SUBJECTS:
    inp = frames_for(n).read_text(encoding="utf-8"); fr = json.loads(inp)["frames"]
    r2 = json.loads(subprocess.run(["node", str(REPLAY_V2), "--no-focus"], input=inp, capture_output=True, text=True, check=True).stdout)
    r1 = np.array(json.loads(subprocess.run(["node", str(REPLAY_V1)], input=inp, capture_output=True, text=True, check=True).stdout))
    T = pd.DataFrame(r2); T["sec"] = (T.t - 1_000_000) / 1000.0; ticks[n] = T
    ft = np.array([f["t"] for f in fr]); idx = np.searchsorted(ft, T.t.values, side="left") - 1   # last frame strictly before each tick
    v1_sec[n] = np.where(idx >= 0, r1[np.clip(idx, 0, None)], 0)
    per_subject_meta[n] = dict(face_rate=float(E.frames[n][E.frames[n].t >= E.CAL_S].det.mean()))
    print(f"subject {n:2d}: {len(T)} ticks", flush=True)

# window score = max over ticks in (t0, t0+10]
def win_max(n, t0, arr): T = ticks[n]; m = (T.sec.values > t0) & (T.sec.values <= t0 + 10.0); return float(np.max(arr[m])) if m.any() else 0.0
W["v2"] = [win_max(r.subject, r.t0, ticks[r.subject].score.values) for r in W.itertuples()]
W.to_csv(OUT / f"{TAG}_window_scores.csv", index=False)

subj = W.subject.values; y = W.y.values; SUBJ = sorted(W.subject.unique())
rank = lambda s: pd.Series(s).groupby(subj).rank(pct=True).values
bys = lambda v: {s: v[subj == s] for s in SUBJ}; ys = bys(y)
res = {}
for k in ("v1", "v2"):
    pt, lo, hi = boot_pooled_auc(bys(rank(W[k].values)), ys, n_boot=1000)
    per = [roc_auc_score(ys[s], W[k].values[subj == s]) for s in SUBJ if len(np.unique(ys[s])) == 2]
    b = X14.budget_metrics(W, W[k].values)
    res[k] = dict(ranked_auroc=pt, lo=lo, hi=hi, raw_auroc=float(roc_auc_score(y, W[k])), mean_within_subject_auroc=float(np.mean(per)),
                  budget33_precision=b["precision"], budget33_recall=b["recall"], budget33_f1=b["f1"],
                  neg_windows_ge_medium=float((W[k][y == 0] >= 30).mean()), pos_windows_ge_medium=float((W[k][y == 1] >= 30).mean()),
                  neg_windows_ge_high=float((W[k][y == 0] >= 60).mean()), pos_windows_ge_high=float((W[k][y == 1] >= 60).mean()))
d, dlo, dhi = boot_pooled_auc(bys(rank(W.v2.values)), ys, n_boot=1000, ref=bys(rank(W.v1.values)))
assert abs(res["v1"]["ranked_auroc"] - 0.5451) < 0.002, "v1 must reproduce the committed s13 rule-engine result"
primary = dict(diff_v2_minus_v1=d, lo=dlo, hi=dhi, margin=-0.05, non_inferior=bool(dlo > -0.05), superior=bool(dlo > 0))

# temporal + reliability (all ticks, all subjects)
tot_min = sum(len(ticks[n]) for n in SUBJ) / 60.0
def changes(levels): return int(np.sum(levels[1:] != levels[:-1]))
v2_lvl = {n: ticks[n].level.replace({"UNDETERMINED": "LOW"}).map({"LOW": 0, "MEDIUM": 1, "HIGH": 2}).values for n in SUBJ}
temporal = dict(minutes=tot_min,
                v1_level_changes_per_10min=10 * sum(changes(lvl(v1_sec[n])) for n in SUBJ) / tot_min,
                v2_level_changes_per_10min=10 * sum(changes(v2_lvl[n]) for n in SUBJ) / tot_min,
                v1_ticks_ge_medium=float(np.mean(np.concatenate([lvl(v1_sec[n]) >= 1 for n in SUBJ]))),
                v2_ticks_ge_medium=float(np.mean(np.concatenate([v2_lvl[n] >= 1 for n in SUBJ]))))
# delay inside annotated intervals >= 10 s (after calibration)
delays = []
for n in SUBJ:
    T = ticks[n]
    for a, b, ty in load_gt(EX / f"subject{n}" / "gt.txt"):
        if b - a < 10 or a < E.CAL_S: continue
        m = (T.sec.values >= a) & (T.sec.values <= b); i1 = np.where(lvl(v1_sec[n])[m] >= 1)[0]; i2 = np.where(v2_lvl[n][m] >= 1)[0]
        delays.append(dict(subject=n, start=a, length_s=b - a, type=ty, v1_delay_s=float(T.sec.values[m][i1[0]] - a) if len(i1) else np.nan,
                           v2_delay_s=float(T.sec.values[m][i2[0]] - a) if len(i2) else np.nan, v1_start_level=int(lvl(v1_sec[n])[m][0]) if m.any() else -1,
                           v2_start_level=int(v2_lvl[n][m][0]) if m.any() else -1))
D = pd.DataFrame(delays); D.to_csv(OUT / f"{TAG}_interval_delays.csv", index=False)
delay = dict(n_intervals=len(D), v1_reached=float(D.v1_delay_s.notna().mean()), v2_reached=float(D.v2_delay_s.notna().mean()),
             v1_median_delay_s=float(D.v1_delay_s.median()), v2_median_delay_s=float(D.v2_delay_s.median()),
             v1_already_medium_at_start=float((D.v1_start_level >= 1).mean()), v2_already_medium_at_start=float((D.v2_start_level >= 1).mean()))
states = pd.concat([ticks[n].state for n in SUBJ]).value_counts(normalize=True).to_dict()
deg = {n: float(ticks[n].state.isin(["DEGRADED", "INSUFFICIENT_EVIDENCE"]).mean()) for n in SUBJ}
rho, prho = spearmanr([per_subject_meta[n]["face_rate"] for n in SUBJ], [deg[n] for n in SUBJ])
reliability = dict(state_share=states, spearman_face_rate_vs_degraded_share=float(rho), p=float(prho))
pd.DataFrame([dict(subject=n, face_rate=per_subject_meta[n]["face_rate"], degraded_or_insufficient_share=deg[n],
                   v1_auroc=roc_auc_score(ys[n], W.v1.values[subj == n]) if len(np.unique(ys[n])) == 2 else np.nan,
                   v2_auroc=roc_auc_score(ys[n], W.v2.values[subj == n]) if len(np.unique(ys[n])) == 2 else np.nan) for n in SUBJ]).to_csv(OUT / f"{TAG}_per_subject.csv", index=False)
uninsp = [s for s in SUBJ if s not in INSPECTED]; mU = np.isin(subj, uninsp)
bU = lambda v: {s: v[subj == s] for s in uninsp}; rU = lambda s_: pd.Series(s_[mU]).groupby(subj[mU]).rank(pct=True).values
dU = boot_pooled_auc({s: rank(W.v2.values)[subj == s] for s in uninsp}, {s: ys[s] for s in uninsp}, n_boot=1000, ref={s: rank(W.v1.values)[subj == s] for s in uninsp})
uninspected = dict(subjects=uninsp, diff_v2_minus_v1=dU[0], lo=dU[1], hi=dU[2],
                   v1_ticks_ge_medium=float(np.mean(np.concatenate([lvl(v1_sec[n]) >= 1 for n in uninsp]))), v2_ticks_ge_medium=float(np.mean(np.concatenate([v2_lvl[n] >= 1 for n in uninsp]))),
                   v1_neg_windows_ge_medium=float((W.v1[mU & (y == 0)] >= 30).mean()), v2_neg_windows_ge_medium=float((W.v2[mU & (y == 0)] >= 30).mean()))
summary = dict(tag=TAG, uninspected_subjects=uninspected, n_windows=len(W), n_pos=int(y.sum()), n_subjects=len(SUBJ), engines=res, primary=primary, temporal=temporal, delay=delay, reliability=reliability)
(OUT / f"{TAG}_summary.json").write_text(json.dumps(summary, indent=1, default=float), encoding="utf-8")
print(json.dumps(summary, indent=1, default=float))
