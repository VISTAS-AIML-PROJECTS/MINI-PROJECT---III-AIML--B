"""Exp 05 - MediaPipe head pose vs MPIIFaceGaze head-pose ground truth, convention-free.
MediaPipe (OpenGL camera frame, canonical face) and MPII (OpenCV camera frame, 6-point face model) use different
frames, so Euler angles are not directly comparable. We compare, per frame, the geodesic angle of the head
rotation relative to the subject's reference pose, dR = R_i R_ref^T. Left-conjugation by a fixed camera-frame
change and right-multiplication by a fixed model-frame change leave this rotation angle unchanged.
Reference pose = chordal mean of the subject's rotations (same for both estimators).
Also compares axis-wise deviation |Euler - subject median| after the fixed decomposition (the quantity GlassBox uses).
Subsample: every 5th frame (7.5k)."""
import numpy as np, pandas as pd, cv2
from scipy.stats import spearmanr, pearsonr
from common import PROC, RESULTS
df = pd.read_parquet(PROC / "mpii_features_lim100000_every5.parquet"); df = df[(df.det == 1) & df.m0.notna()].reset_index(drop=True)
M = df[[f"m{i}" for i in range(16)]].values.reshape(-1, 4, 4)       # data was the column-major flatten
Rmp = np.transpose(M[:, :3, :3], (0, 2, 1)) if False else np.stack([np.array(m).reshape(4, 4).T[:3, :3] for m in M])
# NOTE: m = column-major flatten of the 4x4 -> reshape(4,4) gives M^T; transpose back.
Rmp = np.stack([m.T[:3, :3] for m in M])
Rmp = Rmp / np.cbrt(np.abs(np.linalg.det(Rmp)))[:, None, None]       # remove uniform scale
Rgt = np.stack([cv2.Rodrigues(r)[0] for r in df[["rvec_x", "rvec_y", "rvec_z"]].values.astype(float)])

def chordal_mean(Rs):
    U, _, Vt = np.linalg.svd(Rs.mean(0)); return U @ Vt
def geodesic(Rs, Rref):
    d = Rs @ Rref.T
    return np.degrees(np.arccos(np.clip((np.trace(d, axis1=1, axis2=2) - 1) / 2, -1, 1)))
a_mp = np.zeros(len(df)); a_gt = np.zeros(len(df))
for s, idx in df.groupby("subject").indices.items():
    a_mp[idx] = geodesic(Rmp[idx], chordal_mean(Rmp[idx])); a_gt[idx] = geodesic(Rgt[idx], chordal_mean(Rgt[idx]))
df["a_mp"], df["a_gt"] = a_mp, a_gt
rows = [dict(metric="geodesic angle from subject mean pose", pearson_r=pearsonr(a_mp, a_gt).statistic,
             spearman_rho=spearmanr(a_mp, a_gt).statistic, mae_deg=float(np.mean(np.abs(a_mp - a_gt))),
             bias_deg=float(np.mean(a_mp - a_gt)), gt_mean_deg=float(a_gt.mean()), n=len(df))]
# per-subject spearman
ps = df.groupby("subject").apply(lambda g: spearmanr(g.a_mp, g.a_gt).statistic)
rows.append(dict(metric="per-subject spearman (mean / min / max)", pearson_r=np.nan, spearman_rho=float(ps.mean()),
                 mae_deg=float(ps.min()), bias_deg=float(ps.max()), gt_mean_deg=np.nan, n=len(ps)))
# 'large head turn' detection: gt geodesic > 20 deg
for thr in (15, 25):
    from sklearn.metrics import roc_auc_score
    rows.append(dict(metric=f"AUROC mediapipe angle -> gt turn>{thr}deg", pearson_r=np.nan, spearman_rho=float(roc_auc_score(a_gt > thr, a_mp)),
                     mae_deg=np.nan, bias_deg=np.nan, gt_mean_deg=float((a_gt > thr).mean()), n=len(df)))
T = pd.DataFrame(rows); T.to_csv(RESULTS / "exp05_headpose_validation.csv", index=False)
pd.set_option("display.width", 220); print(T.round(3).to_string(index=False))

# ---- sanity check on the GT itself: does the annotated head yaw/pitch track where the person looks?
unit = lambda v: v / np.linalg.norm(v, axis=1, keepdims=True)
g = unit(df[["gt_x", "gt_y", "gt_z"]].values - df[["fc_x", "fc_y", "fc_z"]].values)
h = np.degrees(np.arctan2(g[:, 0], -g[:, 2])); v = np.degrees(np.arcsin(np.clip(g[:, 1], -1, 1)))
gt_yaw = np.degrees(np.arctan2(-Rgt[:, 2, 0], np.hypot(Rgt[:, 0, 0], Rgt[:, 1, 0])))
chk = pd.DataFrame([
    dict(check="spearman(MediaPipe yaw, horizontal gaze angle)", rho=spearmanr(df.yaw, h).statistic),
    dict(check="spearman(MPII annotated yaw, horizontal gaze angle)", rho=spearmanr(gt_yaw, h).statistic),
    dict(check="spearman(MediaPipe pitch, vertical gaze angle)", rho=spearmanr(df.pitch, v).statistic)])
chk.to_csv(RESULTS / "exp05_gt_sanity.csv", index=False); print(chk.round(3).to_string(index=False))
