"""Generates the randomised, seeded cue schedule for the consent-based mock-exam pilot (docs/PILOT_PROTOCOL.md).
Each participant gets 4 blocks (A-D, order counter-balanced by Latin square) of 5 min; inside a block, cues are drawn
without replacement at random times with a minimum 20 s spacing. Output: JSON with exact cue start/end seconds that the
operator console will display and log as ground truth (the participant never sees the label, only 'do X now').
    python research/pilot_schedule.py 24 > pilot_schedule.json"""
import json, sys
import numpy as np
BEHAVIOURS = {
    "OFFSCREEN_LEFT":  "Turn your eyes (not head) to the left marker for the cue duration, then return to the exam.",
    "OFFSCREEN_RIGHT": "Turn your eyes (not head) to the right marker for the cue duration, then return.",
    "HEAD_TURN":       "Turn your head to look at the side marker.",
    "LOOK_DOWN":       "Look down at the lap marker (stand-in for a phone/notes; no real device or notes are used).",
    "LEAVE_FRAME":     "Lean/stand so your face leaves the camera view, then return.",
    "TAB_SWITCH":      "Switch to the other browser tab, then return.",
}
DUR = {"OFFSCREEN_LEFT": (3, 8), "OFFSCREEN_RIGHT": (3, 8), "HEAD_TURN": (3, 8), "LOOK_DOWN": (3, 8), "LEAVE_FRAME": (3, 6), "TAB_SWITCH": (2, 5)}
BLOCK_S, CUES_PER_BLOCK, MIN_GAP = 300, 6, 20
LATIN = [[0, 1, 2, 3], [1, 2, 3, 0], [2, 3, 0, 1], [3, 0, 1, 2]]   # block-order counter-balancing

def schedule(n, seed=20261021):
    rng = np.random.default_rng(seed); out = []
    for p in range(n):
        order = LATIN[p % 4]; cues = []
        for bi, b in enumerate(order):
            base = bi * BLOCK_S + 45                       # first 45 s of each block are cue-free ("natural" reference)
            kinds = list(BEHAVIOURS); rng.shuffle(kinds); kinds = kinds[:CUES_PER_BLOCK]
            while True:                                     # rejection-sample start times with min spacing
                starts = np.sort(rng.uniform(0, BLOCK_S - 45 - 10, CUES_PER_BLOCK)) + base
                if np.all(np.diff(starts) >= MIN_GAP): break
            for k, s in zip(kinds, starts):
                d = float(rng.integers(*DUR[k]) + rng.random())
                cues.append(dict(block=int(b), behaviour=k, start_s=round(float(s), 2), end_s=round(float(s) + d, 2)))
        out.append(dict(participant=f"P{p + 1:02d}", block_order=order, total_s=4 * BLOCK_S, cues=cues))
    return out

if __name__ == "__main__":
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 24
    s = schedule(n)
    for p in s:                                            # sanity: cues inside the session, non-overlapping
        c = sorted(p["cues"], key=lambda x: x["start_s"]); assert all(a["end_s"] < b["start_s"] for a, b in zip(c, c[1:]))
        assert all(0 <= x["start_s"] and x["end_s"] <= p["total_s"] for x in c)
    print(json.dumps(dict(seed=20261021, behaviours=BEHAVIOURS, participants=s), indent=1))
