"""Exp 12 - OEP (24 subjects): GlassBox engine vs learned models for window-level detection of annotated cheating intervals.

PRE-SPECIFIED PRIMARY COMPARISON (fixed before looking at any OEP result): leave-one-subject-out logistic regression on all
GlassBox-derivable window features (personal baseline, 10 s windows) vs the real JS Evidence/Fusion/Risk engines' window-max risk,
AUROC difference with a subject-level bootstrap CI. Everything else below is EXPLORATORY and labelled as such.

Data: webcam video of 24 subjects (15 actors told to cheat + 9 real examinees with proctor-induced behaviour), MediaPipe features
at 5 fps (oep_extract_features.py). Label = inside the UNION of annotated cheating intervals (any type; type codes undocumented).
Calibration: the first CAL_S seconds of each video (LABEL-AGNOSTIC; the examinee is assumed to behave naturally), excluded from evaluation.
Windows: non-overlapping WIN_S-second windows after calibration; positive = >= 50 % of frames cheating, negative = 0 %, others dropped.
Signals available here: face presence, gaze (linear estimator and legacy iris ratio), head pose. NOT available: browser focus events
(none in OEP). No feature uses labels; scalers/models are fit on training subjects only (sklearn pipelines inside the LOSO loop).
"""
import json, subprocess, warnings
from pathlib import Path
import numpy as np, pandas as pd
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import roc_auc_score, average_precision_score
from common import ROOT, RESULTS, SEED
from oep_common import EX, cache_path, load_gt, STEP
warnings.filterwarnings("ignore")

SUBJECTS = list(range(1, 25)); REAL = {10, 11, 12, 13, 14, 15, 16, 18, 19}; ACTORS = set(SUBJECTS) - REAL
CAL_S = 120; FPS = 25 / STEP
LIN = json.load(open(ROOT / "research" / "models" / "linear_gaze_v1.json"))
rng = np.random.default_rng(SEED)

# ---------------------------------------------------------------- per-frame table
def load_subject(n):
    f = pd.read_parquet(cache_path(f"subject{n}")); iv = load_gt(EX / f"subject{n}" / "gt.txt")
    f["cheat"] = 0; f["ctype"] = 0
    for a, b, ty in iv:
        m = (f.t >= a) & (f.t <= b); f.loc[m, "cheat"] = 1; f.loc[m & (f.ctype == 0), "ctype"] = ty
    X = np.column_stack([f[c] for c in LIN["features"]]) if all(c in f for c in LIN["features"]) else None
    f["hhat"] = X @ np.array(LIN["coef"]) + LIN["intercept"] if X is not None else np.nan
    f["subject"] = n; return f

frames = {n: load_subject(n) for n in SUBJECTS}
print({n: (len(f), round(f.cheat.mean(), 3), round(f.det.mean(), 3)) for n, f in frames.items()})

def calib(f): return f[(f.t < CAL_S) & f.hhat.notna()]
CAL = {n: calib(f) for n, f in frames.items()}
HEAD = ["yaw", "pitch", "roll"]

def baseline(n, mode):
    """(mu, sd) dicts for the gaze/head quantities. personal = own calibration; population = pooled over the OTHER subjects' calibration; raw = no baseline."""
    keys = ["hhat", "gx"] + HEAD
    if mode == "personal": src = CAL[n]
    elif mode == "population": src = pd.concat([CAL[m] for m in SUBJECTS if m != n])
    else: return {k: 0.0 for k in keys}, {k: 1.0 for k in keys}
    mu = {k: float(src[k].mean()) for k in keys}; sd = {k: float(src[k].std()) for k in keys}
    return mu, sd

def deviations(f, n, mode):
    mu, sd = baseline(n, mode); d = pd.DataFrame(index=f.index)
    d["z_h"] = (f.hhat - mu["hhat"]).abs() / max(sd["hhat"], 0.5) if mode != "raw" else f.hhat.abs() / 10.0
    d["z_x"] = (f.gx - mu["gx"]).abs() / max(sd["gx"], 1e-3) if mode != "raw" else (f.gx - 0.5).abs() / 0.04
    for a in HEAD: d[f"h_{a}"] = (f[a] - mu[a]).abs()
    d["absent"] = 1 - f.det
    return d

# ---------------------------------------------------------------- windows + features
def window_table(win_s, mode, with_engine=None):
    W = []; size = int(round(win_s * FPS))
    for n in SUBJECTS:
        f = frames[n]; ev = f[f.t >= CAL_S].reset_index(drop=True); d = deviations(ev, n, mode).reset_index(drop=True)
        for k in range(len(ev) // size):
            sl = slice(k * size, (k + 1) * size); share = ev.cheat.iloc[sl].mean()
            if 0 < share < 0.5: continue
            row = dict(subject=n, y=int(share >= 0.5), t0=float(ev.t.iloc[sl.start]), actor=int(n in ACTORS),
                       ctype=int(ev.ctype.iloc[sl][ev.cheat.iloc[sl] == 1].mode().iloc[0]) if share >= 0.5 else 0, absent_frac=float(d.absent.iloc[sl].mean()))
            for c in ["z_h", "z_x", "h_yaw", "h_pitch", "h_roll"]:
                v = d[c].iloc[sl].dropna()
                row[f"{c}_mean"] = float(v.mean()) if len(v) else 0.0; row[f"{c}_max"] = float(v.max()) if len(v) else 0.0
                row[f"{c}_p90"] = float(v.quantile(0.9)) if len(v) else 0.0
            row["hhat_std"] = float(ev.hhat.iloc[sl].std()) if ev.hhat.iloc[sl].notna().sum() > 1 else 0.0
            row["gx_std"] = float(ev.gx.iloc[sl].std()) if ev.gx.iloc[sl].notna().sum() > 1 else 0.0
            if with_engine is not None:
                r = with_engine[n][sl]; row["engine_max"] = float(np.max(r)); row["engine_mean"] = float(np.mean(r))
            W.append(row)
    return pd.DataFrame(W).fillna(0.0)

def engine_risk(mode="personal"):
    """Real JS engines on the per-frame signal stream (frames after calibration only), as the app would see it."""
    out = {}
    for n in SUBJECTS:
        f = frames[n]; ev = f[f.t >= CAL_S].reset_index(drop=True); mu, sd = baseline(n, mode)
        fr = []
        for r in ev.itertuples():
            sig = []
            if r.det == 1:
                sig.append(dict(type="FACE_PRESENT", value=True))
                if not np.isnan(r.hhat):
                    sig.append(dict(type="GAZE_DEVIATION", value=abs(r.hhat - mu["hhat"]) / max(sd["hhat"], 0.5)))
                    sig.append(dict(type="HEAD_POSE_DEVIATION", value={a: abs(getattr(r, a) - mu[a]) for a in HEAD},
                                    metadata=dict(baselineStd={a: max(sd[a], 0.1) for a in HEAD})))
            else: sig.append(dict(type="FACE_ABSENT", value=True))
            fr.append(dict(t=int(1_000_000 + r.t * 1000), signals=sig))
        res = subprocess.run(["node", str(ROOT / "research" / "tests" / "replay_signals.mjs")], input=json.dumps(dict(frames=fr)), capture_output=True, text=True, check=True)
        out[n] = np.array(json.loads(res.stdout)); print("engine replay", n, len(fr), flush=True)
    return out

# ---------------------------------------------------------------- evaluation helpers
def boot_ci(score_by_subj, y_by_subj, ref_by_subj=None, n_boot=2000):
    ids = np.array(sorted(score_by_subj)); vals = []
    def pooled(sel, d):
        y = np.concatenate([y_by_subj[i] for i in sel]); s = np.concatenate([d[i] for i in sel])
        return roc_auc_score(y, s) if len(np.unique(y)) == 2 else np.nan
    for _ in range(n_boot):
        sel = rng.choice(ids, len(ids)); a = pooled(sel, score_by_subj)
        vals.append(a - pooled(sel, ref_by_subj) if ref_by_subj is not None else a)
    vals = np.array(vals); vals = vals[~np.isnan(vals)]
    return float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5))

def summarise(name, W, score, group, extra=None):
    y = W.y.values; sc = {s: score[W.subject.values == s] for s in sorted(W.subject.unique())}; ys = {s: y[W.subject.values == s] for s in sc}
    per = {s: roc_auc_score(ys[s], sc[s]) for s in sc if len(np.unique(ys[s])) == 2}
    lo, hi = boot_ci(sc, ys)
    r = dict(name=name, group=group, n_windows=len(W), prevalence=float(y.mean()), auroc=float(roc_auc_score(y, score)), auroc_lo=lo, auroc_hi=hi,
             pr_auc=float(average_precision_score(y, score)), per_subject_auc_median=float(np.median(list(per.values()))),
             per_subject_auc_min=float(np.min(list(per.values()))), per_subject_auc_max=float(np.max(list(per.values()))), n_subjects_scored=len(per))
    r.update(extra or {}); return r, sc, ys, per

FEATS = {
    "face": ["absent_frac"],
    "gaze": ["z_h_mean", "z_h_max", "z_h_p90", "z_x_mean", "z_x_max", "z_x_p90", "hhat_std", "gx_std"],
    "head": [f"h_{a}_{s}" for a in HEAD for s in ("mean", "max", "p90")],
}
FEATS["gaze+head"] = FEATS["gaze"] + FEATS["head"]; FEATS["all"] = FEATS["face"] + FEATS["gaze"] + FEATS["head"]

def make(model):
    if model == "logreg": return make_pipeline(StandardScaler(), LogisticRegression(C=1.0, class_weight="balanced", max_iter=2000))
    return HistGradientBoostingClassifier(max_iter=100, learning_rate=0.05, max_depth=3, random_state=SEED)

def loso(W, cols, model, train_mask=None, test_mask=None):
    sc = np.full(len(W), np.nan)
    for s in sorted(W.subject.unique()):
        te = (W.subject == s).values
        if test_mask is not None and not test_mask[te].all(): continue
        tr = (~te) if train_mask is None else ((~te) & train_mask)
        if len(np.unique(W.y[tr])) < 2: continue
        m = make(model).fit(W.loc[tr, cols], W.y[tr]); sc[te] = m.predict_proba(W.loc[te, cols])[:, 1]
    return sc

if __name__ == "__main__":
    ENG = engine_risk("personal")
    rows = []; per_all = {}
    W10 = window_table(10, "personal", with_engine=ENG)
    print("windows", len(W10), "positives", int(W10.y.sum()), "subjects", W10.subject.nunique())
    # --- baselines (no training)
    base = {"engine risk (window max) [real JS engines]": W10.engine_max.values, "engine risk (window mean)": W10.engine_mean.values,
            "heuristic: face-absent fraction": W10.absent_frac.values, "heuristic: max gaze z": W10.z_h_max.values,
            "heuristic: max head deviation / 30deg": W10[[f"h_{a}_max" for a in HEAD]].max(axis=1).values / 30,
            "heuristic: max(gaze z/9, head/30, absent)": np.maximum.reduce([W10.z_h_max.values / 9, W10[[f"h_{a}_max" for a in HEAD]].max(axis=1).values / 30, W10.absent_frac.values])}
    S = {}
    for k, v in base.items():
        r, sc, ys, per = summarise(k, W10, v, "baseline (no training)"); rows.append(r); S[k] = (v, sc, ys)
    # --- learned, personal baseline (primary + ablations over feature groups)
    for model in ("logreg", "hist_gb"):
        for g, cols in FEATS.items():
            sc_ = loso(W10, cols, model); name = f"{model} | {g} | personal"
            r, sc, ys, per = summarise(name, W10, sc_, "learned LOSO", dict(model=model, features=g, normalisation="personal")); rows.append(r); S[name] = (sc_, sc, ys)
            per_all[name] = per
    # --- baseline-normalisation ablation (logreg, all features)
    for mode in ("population", "raw"):
        Wm = window_table(10, mode); sc_ = loso(Wm, FEATS["all"], "logreg"); name = f"logreg | all | {mode}"
        r, *_ = summarise(name, Wm, sc_, "normalisation ablation", dict(model="logreg", features="all", normalisation=mode)); rows.append(r)
    # --- window-length ablation
    for ws in (5, 20):
        Ww = window_table(ws, "personal"); sc_ = loso(Ww, FEATS["all"], "logreg"); name = f"logreg | all | personal | {ws}s windows"
        r, *_ = summarise(name, Ww, sc_, f"window ablation", dict(model="logreg", features="all", normalisation="personal", window_s=ws)); rows.append(r)
    # --- subject-type transfer (actors -> real examinees and back)
    for tr_name, tr_set, te_set in (("train actors -> test real", ACTORS, REAL), ("train real -> test actors", REAL, ACTORS)):
        for model in ("logreg", "hist_gb"):
            trm = W10.subject.isin(tr_set).values; tem = W10.subject.isin(te_set).values; sc_ = np.full(len(W10), np.nan)
            m = make(model).fit(W10.loc[trm, FEATS["all"]], W10.y[trm]); sc_[tem] = m.predict_proba(W10.loc[tem, FEATS["all"]])[:, 1]
            Wt = W10[tem]; r, *_ = summarise(f"{model} | {tr_name}", Wt, sc_[tem], "transfer", dict(model=model));
            e = roc_auc_score(Wt.y, Wt.engine_max); r["engine_auroc_same_windows"] = float(e); rows.append(r)
    R = pd.DataFrame(rows); R.to_csv(RESULTS / "exp12_oep_summary.csv", index=False)
    # --- primary comparison with paired subject bootstrap
    prim_name = "logreg | all | personal"; eng_name = "engine risk (window max) [real JS engines]"
    ys = S[prim_name][2]; lo, hi = boot_ci(S[prim_name][1], ys, ref_by_subj=S[eng_name][1])
    a_p = roc_auc_score(W10.y, S[prim_name][0]); a_e = roc_auc_score(W10.y, S[eng_name][0])
    prim = dict(primary="LOSO logreg(all, personal) minus engine window-max risk", auroc_learned=float(a_p), auroc_engine=float(a_e), diff=float(a_p - a_e), diff_lo=lo, diff_hi=hi)
    # also vs the best simple heuristic (face-absent fraction) -- exploratory
    lo2, hi2 = boot_ci(S[prim_name][1], ys, ref_by_subj=S["heuristic: face-absent fraction"][1])
    prim["vs_face_absent_diff"] = float(a_p - roc_auc_score(W10.y, S["heuristic: face-absent fraction"][0])); prim["vs_face_absent_lo"] = lo2; prim["vs_face_absent_hi"] = hi2
    # per-type recall of the primary model at the threshold giving 10 % FPR on pooled LOSO negatives (descriptive)
    sc_ = S[prim_name][0]; thr = np.quantile(sc_[W10.y.values == 0], 0.90)
    tr = pd.DataFrame([dict(ctype=int(t), n_windows=int((W10.ctype == t).sum()), recall_at_10pct_fpr=float((sc_[(W10.ctype == t).values] >= thr).mean()),
                            engine_recall_same_fpr=float((S[eng_name][0][(W10.ctype == t).values] >= np.quantile(S[eng_name][0][W10.y.values == 0], 0.90)).mean()))
                       for t in sorted(W10.ctype.unique()) if t != 0])
    tr.to_csv(RESULTS / "exp12_oep_by_type.csv", index=False)
    pd.DataFrame({k: pd.Series(v) for k, v in per_all[prim_name].items()}.items(), columns=["subject", "auroc_logreg_all_personal"]).to_csv(RESULTS / "exp12_oep_per_subject.csv", index=False)
    meta = dict(n_subjects=len(SUBJECTS), actors=sorted(ACTORS), real=sorted(REAL), cal_s=CAL_S, window_s=10, n_windows=len(W10), n_pos=int(W10.y.sum()), prevalence=float(W10.y.mean()), **prim)
    json.dump(meta, open(RESULTS / "exp12_oep_meta.json", "w"), indent=1)
    pd.set_option("display.width", 250); pd.set_option("display.max_colwidth", 60)
    print(R[["name", "group", "n_windows", "prevalence", "auroc", "auroc_lo", "auroc_hi", "pr_auc", "per_subject_auc_median"]].round(3).to_string(index=False))
    print(json.dumps(prim, indent=1)); print(tr.round(3).to_string(index=False))
