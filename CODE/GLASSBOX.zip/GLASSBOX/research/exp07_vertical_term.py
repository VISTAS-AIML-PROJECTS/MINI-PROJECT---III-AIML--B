"""Exp 07 - Is the vertical iris term (g_y) worth including in the GAZE_DEVIATION magnitude?
Compares z = hypot(zx, w*zy) for w in {0 (horizontal only), 0.25, 1 (current app)} on the total-deviation target T_A,
personal baseline K=100 with own sd, and with population sd. Within-subject AUROC, subject-bootstrap CI, paired vs w=1."""
import numpy as np, pandas as pd
from sklearn.metrics import roc_auc_score
from common import RESULTS, SEED
from mpii_common import load, KMAX
df = load(); subjects = sorted(df.subject.unique()); ev_all = df[df["rank"] >= KMAX]
thr = ev_all.T_A.quantile(0.75); rng = np.random.default_rng(SEED)
per = {}
for s in subjects:
    sub = df[df.subject == s]; ev = sub[sub["rank"] >= KMAX]; oth = df[df.subject != s]; cal = sub.iloc[:100]
    y = (ev.T_A > thr).astype(int).values
    ps = (oth.gx.std(), oth.gy.std()); sd = (max(cal.gx.std(), 1e-3), max(cal.gy.std(), 1e-3)); mu = (cal.gx.mean(), cal.gy.mean())
    for sdname, S in (("own_sd", sd), ("population_sd", ps)):
        zx = np.abs(ev.gx.values - mu[0]) / S[0]; zy = np.abs(ev.gy.values - mu[1]) / S[1]
        for w in (0.0, 0.25, 1.0):
            per.setdefault((sdname, w), {})[s] = roc_auc_score(y, np.hypot(zx, w * zy))
rows = []
for (sdname, w), d in per.items():
    base = per[(sdname, 1.0)]; v = np.array([d[s] for s in subjects]); b = np.array([base[s] for s in subjects])
    bs = [ (v[i] - b[i]).mean() for i in (rng.integers(0, len(subjects), len(subjects)) for _ in range(2000))]
    rows.append(dict(scale=sdname, w_vertical=w, auc=v.mean(), diff_vs_w1=(v - b).mean(), lo=np.percentile(bs, 2.5), hi=np.percentile(bs, 97.5)))
T = pd.DataFrame(rows); T.to_csv(RESULTS / "exp07_vertical_term.csv", index=False); print(f"T_A positive > {thr:.1f} deg"); print(T.round(3).to_string(index=False))

# ---- split-half robustness: the decision to drop g_y was made after exploratory analysis on these same 15 subjects,
# so check the effect separately in two disjoint halves of subjects (alphabetical: p00-p06 / p07-p14).
halves = {"p00-p06": subjects[:7], "p07-p14": subjects[7:]}
rows = []
for hn, ids_h in halves.items():
    for sdname in ("own_sd", "population_sd"):
        v = np.array([per[(sdname, 0.0)][s] for s in ids_h]); b = np.array([per[(sdname, 1.0)][s] for s in ids_h])
        bs = [(v[i] - b[i]).mean() for i in (rng.integers(0, len(ids_h), len(ids_h)) for _ in range(2000))]
        rows.append(dict(half=hn, n_subjects=len(ids_h), scale=sdname, auc_horizontal_only=v.mean(), auc_combined=b.mean(), diff=(v - b).mean(),
                         lo=np.percentile(bs, 2.5), hi=np.percentile(bs, 97.5), subjects_improved=int((v > b).sum())))
H = pd.DataFrame(rows); H.to_csv(RESULTS / "exp07_split_half.csv", index=False); print(H.round(3).to_string(index=False))
