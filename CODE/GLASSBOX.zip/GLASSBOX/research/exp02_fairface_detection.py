"""Exp 02 - MediaPipe FaceLandmarker reliability across demographic groups (FairFace val, CC BY 4.0).
GlassBox raises FACE_ABSENT when no face is returned, so per-group detection failure == per-group
false 'face absent' rate. Three capture conditions probe differential degradation:
  native  : FairFace 224px padded crop as distributed
  dark    : gamma/gain darkening (low-light webcam proxy)
  small   : face placed at ~35% of a 640x480 grey frame (typical webcam framing)
Every image in FairFace contains exactly one face, so detection failure is a false negative."""
import io, json, sys
import numpy as np, pandas as pd
from PIL import Image
from common import RAW, RESULTS, SEED, block_bootstrap_ci
from glassbox_vision import Landmarker, extract_gaze_feature

RACE = ["East Asian", "Indian", "Black", "White", "Middle Eastern", "Latino_Hispanic", "Southeast Asian"]
GENDER = ["Male", "Female"]
AGE = ["0-2", "3-9", "10-19", "20-29", "30-39", "40-49", "50-59", "60-69", "70+"]

VARIANT = sys.argv[2] if len(sys.argv) > 2 else "pad025"   # pad025 = tight crop, pad125 = crop with head/background context
df = pd.read_parquet(RAW / "fairface" / f"val_{VARIANT}.parquet")
N = int(sys.argv[1]) if len(sys.argv) > 1 else len(df)
df = df.iloc[:N].reset_index(drop=True)

def cond_native(a): return a
def cond_dark(a):
    x = (a / 255.0) ** 2.2 * 0.5
    return (x * 255).astype(np.uint8)
def cond_small(a):
    canvas = np.full((480, 640, 3), 127, np.uint8)
    h = int(480 * 0.35)
    im = np.asarray(Image.fromarray(a).resize((h, h), Image.BILINEAR))
    y0, x0 = (480 - h) // 2, (640 - h) // 2
    canvas[y0:y0 + h, x0:x0 + h] = im
    return canvas
CONDS = dict(native=cond_native, dark=cond_dark, small=cond_small)

lmk = Landmarker("IMAGE")
rec = []
for i, r in df.iterrows():
    arr = np.asarray(Image.open(io.BytesIO(r["image"]["bytes"])).convert("RGB"))
    row = dict(idx=i, age=AGE[r["age"]], gender=GENDER[r["gender"]], race=RACE[r["race"]])
    for cn, fn in CONDS.items():
        out = lmk.detect_rgb(fn(arr))
        row[f"{cn}_det"] = int(out is not None)
        row[f"{cn}_gaze_ok"] = int(out is not None and extract_gaze_feature(out["landmarks"]) is not None
                                   and out["matrix"] is not None)
    rec.append(row)
    if i % 1000 == 0: print(i, flush=True)
res = pd.DataFrame(rec)
res.to_csv(RESULTS / f"exp02_fairface_{VARIANT}_per_image.csv", index=False)

summ = []
for cn in CONDS:
    for attr in ("race", "gender", "age"):
        for g, sub in res.groupby(attr):
            k = int(sub[f"{cn}_det"].sum()); n = len(sub)
            # Wilson 95% interval
            p = k / n; z = 1.96
            den = 1 + z * z / n; c = (p + z * z / (2 * n)) / den
            h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
            summ.append(dict(condition=cn, attribute=attr, group=g, n=n, detected=k, det_rate=p,
                             wilson_lo=c - h, wilson_hi=c + h))
S = pd.DataFrame(summ); S.to_csv(RESULTS / f"exp02_fairface_{VARIANT}_summary.csv", index=False)
print(S.to_string())
