"""Exp 06 - Operating-point behaviour of the horizontal gaze gate (z_x >= tau) used by the evidence/fusion engines.
Positive = top-25% horizontal deviation T_H (as exp04). Normal = bottom 50% of T_H (clearly on-task).
Methods: population (LOSO mean/sd), personal-K (own first K frames), and personal-quantile (tau_s = 99th pct of the
subject's own calibration z_x, i.e. a per-user false-alarm budget of ~1 %). Evaluation frames: rank >= 300."""
import numpy as np, pandas as pd
from common import RESULTS
from mpii_common import load, KMAX
df = load(); subjects = sorted(df.subject.unique())
ev_all = df[df["rank"] >= KMAX]
pos_thr = ev_all.T_H.quantile(0.75); neg_thr = ev_all.T_H.quantile(0.50)
rows = []
def add(method, tau, tp, fn, fp, tn, per):
    rows.append(dict(method=method, tau=tau, tpr=tp / (tp + fn), fpr=fp / (fp + tn), precision=tp / max(tp + fp, 1),
                     fpr_subject_min=min(per), fpr_subject_max=max(per)))
for tau in (2.0, 3.0, 4.0, "q99"):
    for meth in ("population", "personal_K100", "personal_K300"):
        TP = FN = FP = TN = 0; per_fpr = []
        for s in subjects:
            sub = df[df.subject == s]; ev = sub[sub["rank"] >= KMAX]; oth = df[df.subject != s]
            if meth == "population": mu, sd = oth.gx.mean(), oth.gx.std(); cal_z = None
            else:
                k = int(meth.split("K")[1]); cal = sub.iloc[:k]; mu, sd = cal.gx.mean(), max(cal.gx.std(), 1e-3)
                cal_z = np.abs(cal.gx - mu) / sd
            z = np.abs(ev.gx.values - mu) / sd
            if tau == "q99":
                if cal_z is None: continue
                t = float(np.quantile(cal_z, 0.99))
            else: t = tau
            flag = z >= t; pos = ev.T_H.values > pos_thr; neg = ev.T_H.values <= neg_thr
            TP += (flag & pos).sum(); FN += (~flag & pos).sum(); FP += (flag & neg).sum(); TN += (~flag & neg).sum()
            per_fpr.append((flag & neg).sum() / max(neg.sum(), 1))
        if per_fpr: add(meth, tau, TP, FN, FP, TN, per_fpr)
T = pd.DataFrame(rows); T.to_csv(RESULTS / "exp06_operating_point.csv", index=False)
pd.set_option("display.width", 200); print(f"positive T_H > {pos_thr:.1f} deg, normal T_H <= {neg_thr:.1f} deg"); print(T.round(3).to_string(index=False))

# degrees of horizontal gaze angle per unit of g_x (within-subject OLS), and what z = 2/3/4 means in degrees
sl = []; sds = []
for s in subjects:
    sub = df[df.subject == s].iloc[:KMAX]
    sl.append(np.polyfit(sub.gx, sub.h, 1)[0]); sds.append(sub.gx.std())
deg_per_unit = float(np.median(np.abs(sl))); sd_med = float(np.median(sds))
conv = dict(median_abs_deg_per_gx_unit=deg_per_unit, median_calibration_sd_gx=sd_med,
            z_to_deg={str(z): z * sd_med * deg_per_unit for z in (2, 3, 4)})
import json; json.dump(conv, open(RESULTS / "exp06_z_to_degrees.json", "w"), indent=1); print(conv)
