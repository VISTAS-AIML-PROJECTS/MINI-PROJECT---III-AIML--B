"""Shared paths, seeds and statistics helpers for the GlassBox research pipeline."""
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
RAW = DATA / "raw"
PROC = DATA / "processed"
RESULTS = ROOT / "research" / "results"
SEED = 20261021

for p in (PROC, RESULTS):
    p.mkdir(parents=True, exist_ok=True)


def block_bootstrap_ci(metric_fn, y, p, block, n_boot=1000, seed=SEED, alpha=0.05):
    """Percentile CI where contiguous `block`-sized chunks (or group labels in `block`
    if an array is given) are resampled, preserving within-block dependence."""
    rng = np.random.default_rng(seed)
    y = np.asarray(y); p = np.asarray(p)
    if np.ndim(block) == 0:
        groups = np.arange(len(y)) // int(block)
    else:
        groups = np.asarray(block)
    ids = np.unique(groups)
    idx_by = {g: np.flatnonzero(groups == g) for g in ids}
    vals = []
    for _ in range(n_boot):
        pick = rng.choice(ids, size=len(ids), replace=True)
        idx = np.concatenate([idx_by[g] for g in pick])
        if len(np.unique(y[idx])) < 2:
            continue
        vals.append(metric_fn(y[idx], p[idx]))
    lo, hi = np.percentile(vals, [100 * alpha / 2, 100 * (1 - alpha / 2)])
    return float(lo), float(hi)
