"""Exp 11 - MediaPipe head pose vs UPNA Head Pose Database sensor ground truth (component validation; NOT cheating validation).

Data: Head_Pose_Database_UPNA (10 users x 12 webcam videos, 300 frames, 1280x720; magnetic-sensor pose; CC BY-NC-SA 4.0).
GT columns (readme): Tx Ty Tz Roll Yaw Pitch (mm, degrees); '_zeroed' files are the pose relative to the first frame.
Because the sensor frame and MediaPipe's canonical frame differ, we compare ROTATION CHANGES relative to frame 0:
  mp_k(t) = angle_k(t) - angle_k(0) for the app's decomposition (and for the legacy formula, to test the roll fix on real video)
  gt_j(t) = zeroed ground-truth angle j.
Each GT axis is matched to the MediaPipe axis with the highest |Pearson r| on the training users only? -> no: the axis match is a
fixed convention, so it is chosen on the GUIDED single-rotation videos of ALL users and then frozen (documented below); sign by r.
Metrics per GT axis: Pearson r, OLS slope, MAE (deg) after the frozen sign (no per-video refit), MAE of the raw
sign-corrected change; reported on guided single-axis videos (clean) and free-movement videos separately. Subject-level bootstrap CI."""
import re, json
from pathlib import Path
import numpy as np, pandas as pd, cv2
from common import DATA, RESULTS, SEED, PROC
from glassbox_vision import Landmarker, extract_head_pose, extract_head_pose_legacy
ROOT = DATA / "raw" / "upna_hpdb" / "Head_Pose_Database_UPNA"
CACHE = PROC / "upna_mediapipe.parquet"
AX = ["roll", "yaw", "pitch"]

def run_video(lmk, path):
    cap = cv2.VideoCapture(str(path)); rows = []; i = 0
    while True:
        ok, bgr = cap.read()
        if not ok: break
        out = lmk.detect_rgb(cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)); r = dict(frame=i, det=int(out is not None))
        if out is not None and out["matrix"] is not None:
            h = extract_head_pose(out["matrix"]); L = extract_head_pose_legacy(out["matrix"])
            r.update({f"mp_{k}": h[k] for k in AX}); r.update({f"leg_{k}": L[k] for k in AX})
        rows.append(r); i += 1
    return pd.DataFrame(rows)

if CACHE.exists(): df = pd.read_parquet(CACHE)
else:
    lmk = Landmarker("IMAGE"); parts = []
    for u in range(1, 11):
        for v in range(1, 13):
            stem = f"user_{u:02d}_video_{v:02d}"; p = ROOT / f"User_{u:02d}" / f"{stem}.mp4"
            f = run_video(lmk, p)
            gt = np.loadtxt(ROOT / f"User_{u:02d}" / f"{stem}_groundtruth3D_zeroed.txt")
            n = min(len(f), len(gt)); f = f.iloc[:n].copy()
            for j, k in enumerate(["Tx", "Ty", "Tz", "roll", "yaw", "pitch"]): f[f"gt_{k}"] = gt[:n, j]
            f["user"] = u; f["video"] = v; parts.append(f); print(stem, n, "det", round(f.det.mean(), 3), flush=True)
    df = pd.concat(parts, ignore_index=True); df.to_parquet(CACHE)

d = df[df.det == 1].dropna(subset=[f"mp_{a}" for a in AX]).copy()
for pre in ("mp", "leg"):
    for a in AX:
        d[f"{pre}_{a}_rel"] = d[f"{pre}_{a}"] - d.groupby(["user", "video"])[f"{pre}_{a}"].transform("first")
# which GT axis dominates each video? (verifies the guided-sequence layout empirically)
var = d.groupby(["user", "video"])[[f"gt_{a}" for a in AX]].std()
dom = var.idxmax(axis=1).str.replace("gt_", "")
layout = pd.DataFrame({"dominant_gt_axis": dom}).reset_index().groupby("video").dominant_gt_axis.agg(lambda s: s.value_counts().to_dict())
print("dominant rotation axis per video number:\n", layout.to_string())
guided = [v for v in range(1, 7)]; rot_guided = [4, 5, 6]

def corr(x, y): return float(np.corrcoef(x, y)[0, 1])
# freeze axis match + sign on guided rotation videos (4-6), pooled over users
G = d[d.video.isin(rot_guided)]
match = {}
for pre in ("mp", "leg"):
    for a in AX:
        best = max(AX, key=lambda b: abs(corr(G[f"gt_{a}"], G[f"{pre}_{b}_rel"])))
        match[(pre, a)] = (best, int(np.sign(corr(G[f"gt_{a}"], G[f"{pre}_{best}_rel"]))))
print("frozen axis/sign match (pre, gt_axis) -> (mp_axis, sign):", match)
rng = np.random.default_rng(SEED); rows = []
for pre, name in (("mp", "fixed (current app)"), ("leg", "legacy (pre-fix)")):
    for a in AX:
        b, sg = match[(pre, a)]
        for scope, vids in (("guided rotation 4-6", rot_guided), ("free movement 7-12", range(7, 13))):
            S = d[d.video.isin(vids)]; S = S.assign(err=sg * S[f"{pre}_{b}_rel"] - S[f"gt_{a}"])
            per_user = S.groupby("user")[S.columns.tolist()].apply(lambda g: pd.Series(dict(mae=g.err.abs().mean(), r=corr(g[f"gt_{a}"], sg * g[f"{pre}_{b}_rel"]),
                                                                       gt_sd=g[f"gt_{a}"].std())))
            ids = per_user.index.values
            bs = [per_user.loc[rng.choice(ids, len(ids))].mae.mean() for _ in range(2000)]
            rows.append(dict(estimator=name, gt_axis=a, mp_axis=b, sign=sg, scope=scope, mae_deg=per_user.mae.mean(), mae_lo=np.percentile(bs, 2.5),
                             mae_hi=np.percentile(bs, 97.5), pooled_r=corr(S[f"gt_{a}"], sg * S[f"{pre}_{b}_rel"]), gt_sd_deg=S[f"gt_{a}"].std(), n=len(S)))
T = pd.DataFrame(rows); T.to_csv(RESULTS / "exp11_upna_headpose.csv", index=False)
det = df.groupby("user").det.mean(); json.dump(dict(face_found_overall=float(df.det.mean()), face_found_by_user=det.round(4).to_dict(), n_frames=int(len(df)), match={f"{k[0]}:{k[1]}": v for k, v in match.items()}),
                                                open(RESULTS / "exp11_upna_meta.json", "w"), indent=1)
pd.set_option("display.width", 220); print(T.round(3).to_string(index=False)); print("face found overall", round(df.det.mean(), 4))

# ---- paired test of the roll-decomposition fix on real video: per-user MAE(legacy) - MAE(fixed), free-movement videos
b_f, s_f = match[("mp", "roll")]; b_l, s_l = match[("leg", "roll")]
F = d[d.video.isin(range(7, 13))]
pu = F.groupby("user").apply(lambda g: pd.Series(dict(
    fixed=(s_f * g[f"mp_{b_f}_rel"] - g.gt_roll).abs().mean(), legacy=(s_l * g[f"leg_{b_l}_rel"] - g.gt_roll).abs().mean())), include_groups=False)
pu["diff"] = pu.legacy - pu.fixed; ids = pu.index.values
bs = [pu.loc[rng.choice(ids, len(ids))]["diff"].mean() for _ in range(2000)]
fix = dict(scope="free movement 7-12, roll", mae_fixed=float(pu.fixed.mean()), mae_legacy=float(pu.legacy.mean()), diff_legacy_minus_fixed=float(pu["diff"].mean()),
           lo=float(np.percentile(bs, 2.5)), hi=float(np.percentile(bs, 97.5)), users_improved=int((pu["diff"] > 0).sum()), n_users=len(pu))
json.dump(fix, open(RESULTS / "exp11_roll_fix_paired.json", "w"), indent=1); print(fix)
