"""Builds docs/figures/*.png from research/results/*.csv. Palette: reference categorical slots 1-2 (blue, orange), light surface."""
import numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from common import RESULTS, ROOT
OUT = ROOT / "docs" / "figures"; OUT.mkdir(parents=True, exist_ok=True)
BLUE, ORANGE, INK, MUTED, SURF = "#2a78d6", "#eb6834", "#0b0b0b", "#52514e", "#fcfcfb"
plt.rcParams.update({"figure.facecolor": SURF, "axes.facecolor": SURF, "savefig.facecolor": SURF, "text.color": INK,
                     "axes.labelcolor": MUTED, "xtick.color": MUTED, "ytick.color": MUTED, "font.size": 10,
                     "axes.spines.top": False, "axes.spines.right": False, "axes.edgecolor": "#c3c2b7"})

# ---- Fig 1: leakage (exp01)
d = pd.read_csv(RESULTS / "exp01_susp_classification.csv"); d = d[d.model == "hist_gb"]
names = {"all_37": "All 37 columns (incl. phone/hand cues)", "no_object_cues": "No phone/hand cues", "gaze_incl_script_flags": "Face, head, gaze incl. scenario-aware gaze flags", "glassbox_strict": "Strict: face presence, head angles, pupil offset only"}
fig, ax = plt.subplots(figsize=(7.4, 3.8)); keys = list(names)
for i, k in enumerate(keys):
    r_ = d[(d.split == "random") & (d.features == k)].auroc.iloc[0]; b_ = d[(d.split == "blocked") & (d.features == k)].auroc.iloc[0]
    ax.plot([r_, b_], [i, i], color="#c3c2b7", lw=3, zorder=1)
    ax.scatter([r_], [i], color=BLUE, s=70, zorder=2, label="random 5-fold" if i == 0 else None)
    ax.scatter([b_], [i], color=ORANGE, s=70, zorder=2, label="temporally blocked 5-fold" if i == 0 else None)
    lo_, hi_ = min(r_, b_), max(r_, b_)
    ax.text(lo_ - .003, i, f"{lo_:.3f}", ha="right", va="center", fontsize=8.5); ax.text(hi_ + .003, i, f"{hi_:.3f}", ha="left", va="center", fontsize=8.5)
ax.set_yticks(range(len(keys)), [names[k].replace(chr(10), " ") for k in keys]); ax.invert_yaxis(); ax.set_xlim(0.88, 1.005)
ax.set_xlabel("AUROC (HistGradientBoosting, pooled out-of-fold)")
fig.suptitle("Optimism from random splitting is largest where the signal is weakest", x=0.01, ha="left", fontsize=10.5, color=INK)
ax.legend(frameon=False, loc="upper left", bbox_to_anchor=(0, -0.2), ncol=2, fontsize=8.5); fig.tight_layout(rect=(0, 0, 1, 0.94)); fig.savefig(OUT / "fig1_leakage.png", dpi=170); plt.close(fig)

# ---- Fig 2: personalisation (exp04, horizontal target)
t = pd.read_csv(RESULTS / "exp04_personalization.csv"); t = t[(t.target == "T_H")].set_index("method")
Ks = [10, 30, 100, 300]
fig, ax = plt.subplots(figsize=(7, 3.8))
y = [t.loc[f"personal_K{k}", "within_subject_auc"] for k in Ks]
lo = [t.loc[f"personal_K{k}", "auc_lo"] for k in Ks]; hi = [t.loc[f"personal_K{k}", "auc_hi"] for k in Ks]
ax.errorbar(range(4), y, yerr=[np.array(y) - lo, np.array(hi) - y], color=BLUE, marker="o", lw=2, capsize=3, label="personal baseline (K calibration frames)")
ax.axhline(t.loc["population", "within_subject_auc"], color=MUTED, ls="--", lw=1.5)
ax.text(0.05, t.loc["population", "within_subject_auc"] - 0.013, "population baseline (leave-one-subject-out)", ha="left", fontsize=8.5, color=MUTED)
ax.axhline(t.loc["gbm_personal", "within_subject_auc"], color=ORANGE, lw=1.5)
ax.text(-0.05, t.loc["gbm_personal", "within_subject_auc"] + 0.004, "learned model + personal centring (K=100)", fontsize=8.5, color=INK)
ax.axhline(t.loc["gbm_population", "within_subject_auc"], color=ORANGE, lw=1.5, ls=":")
ax.text(-0.05, t.loc["gbm_population", "within_subject_auc"] - 0.014, "learned model, no calibration", fontsize=8.5, color=INK)
ax.set_xticks(range(4), [str(k) for k in Ks]); ax.set_xlabel("calibration frames K"); ax.set_ylabel("within-subject AUROC")
ax.set_ylim(0.70, 0.93); fig.suptitle("Horizontal gaze deviation: personal baseline helps only with K ≥ 100, and little", x=0.01, ha="left", fontsize=10.5, color=INK)
ax.legend(frameon=False, loc="lower right", fontsize=8.5); fig.tight_layout(rect=(0, 0, 1, 0.94)); fig.savefig(OUT / "fig2_personalization.png", dpi=170); plt.close(fig)

# ---- Fig 3: FairFace detection by race (pad125)
s = pd.read_csv(RESULTS / "exp02_fairface_pad125_summary.csv"); s = s[(s.attribute == "race")]
order = s[s.condition == "native"].sort_values("det_rate").group.tolist()
fig, ax = plt.subplots(figsize=(7, 3.8))
for cond, col, dy in (("native", BLUE, .12), ("dark", ORANGE, -.12)):
    q = s[s.condition == cond].set_index("group").loc[order]
    ax.errorbar(q.det_rate * 100, np.arange(len(order)) + dy, xerr=[(q.det_rate - q.wilson_lo) * 100, (q.wilson_hi - q.det_rate) * 100],
                fmt="o", color=col, capsize=2, label={"native": "native lighting", "dark": "low-light (gamma 2.2, gain 0.5)"}[cond])
ax.set_yticks(range(len(order)), [o.replace("_", "/") for o in order]); ax.set_xlabel("face detected by MediaPipe FaceLandmarker (%) – 95 % Wilson CI")
fig.suptitle("A missed face becomes a FACE_ABSENT signal; miss rates differ by group", x=0.01, ha="left", fontsize=10.5, color=INK)
ax.legend(frameon=False, loc="lower right", fontsize=8.5); fig.tight_layout(rect=(0, 0, 1, 0.94)); fig.savefig(OUT / "fig3_fairface.png", dpi=170); plt.close(fig)
# ---- Fig 4: same-session calibration (exp04b) vs cross-session (exp04)
b = pd.read_csv(RESULTS / "exp04b_same_session.csv").set_index("method")
rows = [("population baseline", b.loc["population"], MUTED)] + [(f"personal, same session, K={k}", b.loc[f"personal_session_K{k}"], BLUE) for k in (10, 20, 30)] +        [("learned, no calibration", b.loc["gbm_population"], ORANGE), ("learned + same-session centring (K=30)", b.loc["gbm_session_centred_K30"], ORANGE)]
fig, ax = plt.subplots(figsize=(7, 3.6))
for i, (lab, r_, col) in enumerate(rows):
    ax.errorbar(r_.within_subject_auc, i, xerr=[[r_.within_subject_auc - r_.auc_lo], [r_.auc_hi - r_.within_subject_auc]], fmt="o", color=col, capsize=3)
    ax.text(r_.auc_hi + 0.004, i, f"{r_.within_subject_auc:.3f}", va="center", fontsize=8.5)
ax.set_yticks(range(len(rows)), [r_[0] for r_ in rows]); ax.invert_yaxis(); ax.set_xlabel("within-subject AUROC, horizontal deviation (95 % CI)")
ax.set_xlim(0.66, 0.93); fig.suptitle("Same-session calibration with ≤ 30 frames does not beat a population baseline", x=0.01, ha="left", fontsize=10.5, color=INK)
fig.tight_layout(rect=(0, 0, 1, 0.94)); fig.savefig(OUT / "fig4_same_session.png", dpi=170); plt.close(fig)
print("ok")
