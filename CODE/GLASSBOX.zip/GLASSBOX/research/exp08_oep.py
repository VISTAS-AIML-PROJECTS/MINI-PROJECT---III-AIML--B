"""Exp 08 - OEP (MSU Online Exam Proctoring) evaluation of GlassBox's signals against annotated cheating intervals.

Per subject (webcam.avi + gt.txt, times in MMSS): MediaPipe (app settings, VIDEO mode) is run at ~5 fps; per frame we keep
face presence, horizontal iris position g_x and head pose. Label = frame inside the UNION of annotated cheating intervals
(any type; type codes are not documented in the README). Calibration baseline = the subject's first CAL_S seconds of
non-cheating frames (an oracle choice: it assumes the examinee behaved naturally while 'calibrating'); those frames are
excluded from evaluation. Scores: z_x (own baseline), head deviation = max_i |Delta_i|/S_i, face-absent flag.
Population baseline (leave-one-subject-out) is computed only when >= 3 subjects are available.
Statistics are subject-level; with few subjects NOTHING here is a validation claim."""
import sys, json
from pathlib import Path
import numpy as np, pandas as pd, cv2
from sklearn.metrics import roc_auc_score
from common import DATA, PROC, RESULTS, SEED
from glassbox_vision import Landmarker, extract_gaze_feature, extract_head_pose
EX = DATA / "raw" / "oep_extract"; CAL_S = 120; STEP = 5
HEAD_S = dict(yaw=45, pitch=30, roll=30)

def mmss(t): t = int(t); return (t // 100) * 60 + t % 100
def load_gt(p):
    iv = []
    for line in Path(p).read_text().splitlines():
        a = line.split()
        if len(a) >= 3: iv.append((mmss(a[0]), mmss(a[1]), int(a[2])))
    return iv

def extract(sub_dir):
    cap = cv2.VideoCapture(str(sub_dir / "webcam.avi")); fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    lmk = Landmarker("IMAGE"); rows = []; i = 0
    while True:
        ok, bgr = cap.read()
        if not ok: break
        if i % STEP == 0:
            out = lmk.detect_rgb(cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)); r = dict(t=i / fps, det=int(out is not None))
            if out is not None:
                g = extract_gaze_feature(out["landmarks"]); h = extract_head_pose(out["matrix"]) if out["matrix"] is not None else None
                if g and h: r.update(gx=g["gazeX"], gy=g["gazeY"], yaw=h["yaw"], pitch=h["pitch"], roll=h["roll"])
            rows.append(r)
        i += 1
    return pd.DataFrame(rows)

frames = []
for d in sorted(EX.glob("subject*"), key=lambda p: int(p.name[7:])):
    if not ((d / "webcam.avi").exists() and (d / "gt.txt").exists()): continue
    cache = PROC / f"oep_{d.name}.parquet"
    f = pd.read_parquet(cache) if cache.exists() else extract(d)
    if not cache.exists(): f.to_parquet(cache)
    iv = load_gt(d / "gt.txt"); f["subject"] = d.name
    f["cheat"] = [int(any(a <= t <= b for a, b, _ in iv)) for t in f.t]
    frames.append(f); print(d.name, len(f), "frames, cheating share", round(f.cheat.mean(), 3), "face found", round(f.det.mean(), 3), flush=True)
df = pd.concat(frames, ignore_index=True)
subjects = sorted(df.subject.unique())
def calib_mask(s):
    sub = df[df.subject == s]; ok = sub[(sub.cheat == 0) & sub.gx.notna()]
    return ok.index[ok.t <= ok.t.iloc[0] + CAL_S]
rows = []
for s in subjects:
    sub = df[df.subject == s]; ci = calib_mask(s)
    cal = df.loc[ci]; ev = sub.drop(ci)
    y = ev.cheat.values
    mu, sd = cal.gx.mean(), max(cal.gx.std(), 1e-3)
    zx = np.where(ev.gx.notna(), np.abs(ev.gx - mu) / sd, np.nan)
    head = np.nanmax(np.vstack([np.abs(ev[a] - cal[a].mean()) / HEAD_S[a] for a in HEAD_S]), axis=0)
    absent = 1 - ev.det.values
    res = dict(subject=s, n_eval=len(ev), cheat_share=float(y.mean()), n_cal=len(cal))
    if 0 < y.sum() < len(y):
        for name, v in (("auc_zx_personal", zx), ("auc_head_personal", head), ("auc_face_absent", absent)):
            m = ~np.isnan(v)
            res[name] = float(roc_auc_score(y[m], v[m])) if len(np.unique(y[m])) == 2 and len(np.unique(v[m])) > 1 else np.nan
        # simple combination: max of normalised gaze (z/9) and head (already /S) and absent
        comb = np.nanmax(np.vstack([np.nan_to_num(np.clip(zx / 9, 0, 1)), np.nan_to_num(np.clip(head, 0, 1)), absent]), axis=0)
        res["auc_combined_personal"] = float(roc_auc_score(y, comb))
    if len(subjects) >= 3:
        oth = df[(df.subject != s) & df.gx.notna()]
        zp = np.where(ev.gx.notna(), np.abs(ev.gx - oth.gx.mean()) / oth.gx.std(), np.nan); m = ~np.isnan(zp)
        if 0 < y.sum() < len(y): res["auc_zx_population"] = float(roc_auc_score(y[m], zp[m]))
    rows.append(res)
T = pd.DataFrame(rows); T.to_csv(RESULTS / "exp08_oep_per_subject.csv", index=False)
pd.set_option("display.width", 220); print(T.round(3).to_string(index=False))
json.dump(dict(n_subjects=len(subjects), subjects=subjects, cal_s=CAL_S, fps_step=STEP,
               note="feasibility only unless n_subjects >= ~10; no population baseline unless >= 3"), open(RESULTS / "exp08_oep_meta.json", "w"), indent=1)
