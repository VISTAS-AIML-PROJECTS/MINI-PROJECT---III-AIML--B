"""Exp 09b - operating point of the personalised linear-gaze z-score (cross-session K=100, as exp06) at tau in {2,3,4}.
Positive = top-25 % horizontal deviation T_H; Normal = bottom 50 %. LOSO ridge as exp09. Also reports what z=3 means in degrees."""
import warnings, json
import numpy as np, pandas as pd
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from common import RESULTS
from mpii_common import load, KMAX
warnings.filterwarnings("ignore")
FEAT = ["gx", "gy", "rx", "lx", "ry", "ly", "yaw", "pitch", "roll"]
df = load(); subjects = sorted(df.subject.unique())
ev_all = df[df["rank"] >= KMAX]; pos_thr = ev_all.T_H.quantile(.75); neg_thr = ev_all.T_H.quantile(.5)
acc = {t: [0, 0, 0, 0] for t in (2.0, 3.0, 4.0)}; perfpr = {t: [] for t in acc}; sds = []
for s in subjects:
    sub = df[df.subject == s]; oth = df[df.subject != s]
    m = make_pipeline(StandardScaler(), Ridge(alpha=10.0)).fit(oth[FEAT], oth.h)
    hh = m.predict(sub[FEAT]); cal = hh[:100]; sd = max(cal.std(), 1e-3); sds.append(sd)
    ev = sub[sub["rank"] >= KMAX]; z = np.abs(hh[KMAX:KMAX + len(ev)] - cal.mean()) / sd
    pos = ev.T_H.values > pos_thr; neg = ev.T_H.values <= neg_thr
    for t in acc:
        f = z >= t; a = acc[t]; a[0] += (f & pos).sum(); a[1] += (~f & pos).sum(); a[2] += (f & neg).sum(); a[3] += (~f & neg).sum()
        perfpr[t].append((f & neg).sum() / max(neg.sum(), 1))
rows = [dict(tau=t, tpr=a[0] / (a[0] + a[1]), fpr=a[2] / (a[2] + a[3]), precision=a[0] / max(a[0] + a[2], 1),
             fpr_subject_max=max(perfpr[t])) for t, a in acc.items()]
T = pd.DataFrame(rows); T.to_csv(RESULTS / "exp09b_linear_operating_point.csv", index=False)
json.dump(dict(median_calibration_sd_deg=float(np.median(sds)), z3_deg=float(3 * np.median(sds))), open(RESULTS / "exp09b_meta.json", "w"))
print(T.round(3).to_string(index=False)); print("median calib SD (deg)", round(float(np.median(sds)), 2), "-> z=3 =", round(3 * float(np.median(sds)), 1), "deg")
