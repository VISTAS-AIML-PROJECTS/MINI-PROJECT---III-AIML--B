// Software tests for the v2 assessment chain (src/assessment/). Synthetic, seeded inputs:
// these check behaviour and boundary conditions, not real-world accuracy.
import test from "node:test";
import assert from "node:assert/strict";
import { SCENARIOS, T0 } from "../final/scenarios.mjs";
import { runV2 } from "../final/runners.mjs";
import { AssessmentEngine } from "../../src/assessment/assessmentEngine.js";
import { ObservationMonitor } from "../../src/assessment/observationMonitor.js";
import { AssessmentPipeline } from "../../src/assessment/pipeline.js";
import { EvidenceEngine } from "../../src/evidence/evidenceEngine.js";

const sc = (name) => SCENARIOS.find((s) => s.name.startsWith(name));
const scores = (run) => run.rows.map((r) => r.score);
const between = (run, a, b) => run.rows.slice(a, b);
const levels = (rows) => rows.map((r) => r.level).filter((l) => l !== "UNDETERMINED");
const changes = (ls) => ls.slice(1).filter((l, i) => l !== ls[i]).length;

test("identical input gives identical output (reproducibility)", () => {
  const a = runV2(sc("S03"));
  const b = runV2(sc("S03"));
  assert.deepEqual(JSON.parse(JSON.stringify(a.rows)), JSON.parse(JSON.stringify(b.rows)));
  assert.deepEqual(a.final, b.final);
});

test("calm, calibrated user stays LOW with no level changes", () => {
  const r = runV2(sc("S01"));
  assert.ok(Math.max(...scores(r)) < 30);
  assert.equal(changes(levels(r.rows)), 0);
  assert.equal(r.final.state, "OK");
});

test("a single short glance does not raise the level", () => {
  const r = runV2(sc("S02"));
  assert.ok(Math.max(...scores(r)) < 30);
});

test("repeated look-aways raise the score; it decays back after they stop", () => {
  const r = runV2(sc("S07"));
  const s = scores(r);
  assert.ok(Math.max(...s.slice(30, 160)) >= 30, "should reach MEDIUM during look-aways");
  assert.ok(s.at(-1) < 10, "should decay once behaviour stops");
  for (let i = 260; i < s.length; i++) assert.ok(s[i] <= s[i - 1], `non-increasing during calm (t=${i})`);
});

test("an ongoing face absence counts before the face returns", () => {
  const r = runV2(sc("S04"));
  const during = between(r, 60, 180);
  assert.ok(Math.max(...during.map((x) => x.score)) >= 30, "absence must be visible while it lasts");
  assert.ok(during.some((x) => x.state === "DEGRADED"), "gaze/head unobservable while the face is absent");
  assert.ok(during.some((x) => x.channels.faceAbsence.ongoing), "ongoing episode is reported");
});

test("brief face-detector dropouts are treated as noise, not absence evidence", () => {
  const r = runV2(sc("S13"));
  assert.ok(r.persistedEvidence.filter((e) => e.type === "FACE_ABSENCE_EPISODE").length >= 25, "blips are still recorded as observations");
  assert.ok(Math.max(...scores(r)) < 10);
  assert.equal(r.final.channels.faceAbsence.score, 0);
});

test("one behaviour group alone cannot reach HIGH; two independent groups can", () => {
  assert.ok(Math.max(...scores(runV2(sc("S04")))) <= 50);
  assert.ok(Math.max(...scores(runV2(sc("S03")))) <= 50);
  assert.ok(Math.max(...scores(runV2(sc("S06")))) >= 60);
});

test("camera interruption gives INSUFFICIENT_EVIDENCE, never a certified LOW", () => {
  const r = runV2(sc("S05"));
  const gap = between(r, 125, 240);
  assert.ok(gap.every((x) => x.state === "INSUFFICIENT_EVIDENCE"));
  assert.ok(gap.every((x) => x.level !== "LOW"));
  assert.ok(gap.every((x) => x.limitations.includes("CAMERA_GAPS")));
  assert.equal(r.final.state, "OK", "recovers once frames return");
});

test("an uncalibrated session is DEGRADED and says why", () => {
  const r = runV2(sc("S08"));
  assert.equal(r.final.state, "DEGRADED");
  assert.ok(r.final.limitations.includes("NOT_CALIBRATED"));
  assert.ok(r.final.reasons.some((x) => /not calibrated/.test(x)));
});

test("a session shorter than the minimum observation is INSUFFICIENT_EVIDENCE", () => {
  const r = runV2(sc("S12"));
  assert.equal(r.final.state, "INSUFFICIENT_EVIDENCE");
  assert.equal(r.final.level, "UNDETERMINED");
});

test("episodes still open at session end are emitted (face absence and focus loss)", () => {
  const a = runV2(sc("S09"));
  const abs = a.persistedEvidence.filter((e) => e.type === "FACE_ABSENCE_EPISODE");
  assert.equal(abs.length, 1);
  assert.equal(abs[0].durationMs, 60000);
  assert.equal(abs[0].metadata.endedBy, "SESSION_END");
  const f = runV2(sc("S10"));
  assert.equal(f.persistedEvidence.filter((e) => e.type === "FOCUS_LOSS_EPISODE")[0].durationMs, 30000);
});

test("hysteresis keeps the level from flickering near a boundary", () => {
  const r = runV2(sc("S11"));
  assert.ok(changes(levels(r.rows)) <= 2);
});

test("gaze and head pose are not double-counted", () => {
  const r = runV2(sc("S03"));
  const peak = r.rows.reduce((a, b) => (b.score > a.score ? b : a));
  assert.ok(peak.channels.gazeDeviation.score > 0 && peak.channels.headPoseDeviation.score > 0);
  assert.equal(peak.groups.attention.score, Math.max(peak.channels.gazeDeviation.score, peak.channels.headPoseDeviation.score));
  assert.ok(peak.reasons.some((x) => /not counted twice/.test(x)));
});

test("score is traceable: contributions add up to it", () => {
  for (const name of ["S03", "S04", "S06", "S07"]) {
    for (const row of runV2(sc(name)).rows) {
      const sum = Object.values(row.contributions).reduce((a, c) => a + c.points, 0);
      assert.ok(Math.abs(Math.round(sum) - row.score) <= 1, `${name} t=${row.timestamp}`);
    }
  }
});

test("restarting a session does not leak state from the previous one", () => {
  const p = new AssessmentPipeline({});
  runV2(sc("S06"), { pipeline: p });
  const r = runV2(sc("S01"), { pipeline: p });
  assert.ok(Math.max(...scores(r)) < 30);
  assert.equal(r.rows[20].channels.faceAbsence.episodes, 0);
});

test("invalid and out-of-range values never produce NaN or out-of-range scores", () => {
  const monitor = new ObservationMonitor({});
  const engine = new AssessmentEngine({ monitor });
  monitor.start(T0);
  for (let k = 0; k < 400; k++) monitor.processSignal({ type: "FACE_PRESENT", timestamp: T0 + k * 50 });
  for (const strength of [NaN, Infinity, -5, 7, "x", null, undefined]) {
    engine.processEvidence({ type: "FACE_ABSENCE_EPISODE", timestamp: T0 + 1000, strength, durationMs: Infinity });
    engine.processEvidence({ type: "GAZE_DEVIATION_EPISODE", timestamp: "bad", strength, durationMs: -10 });
  }
  engine.processEvidence({ type: "UNKNOWN_EPISODE", timestamp: T0, strength: 1 });
  engine.processEvidence(null);
  const a = engine.update(T0 + 20000);
  assert.ok(Number.isFinite(a.score) && a.score >= 0 && a.score <= 100);
  assert.ok(Number.isFinite(a.reliability) && a.reliability >= 0 && a.reliability <= 1);
  assert.equal(engine.update(NaN), null);
});

test("evidence engine: ongoing episodes are provisional and not emitted", () => {
  const emitted = [];
  const ee = new EvidenceEngine({ onEvidence: (e) => emitted.push(e) });
  ee.processSignal({ type: "FOCUS_LOST", timestamp: T0 });
  ee.processSignal({ type: "FACE_ABSENT", timestamp: T0 + 1000 });
  const open = ee.getOpenEpisodes(T0 + 11000);
  assert.deepEqual(open.map((e) => [e.type, e.durationMs]).sort(), [["FACE_ABSENCE_EPISODE", 10000], ["FOCUS_LOSS_EPISODE", 11000]]);
  assert.equal(emitted.length, 0);
  ee.finalize(T0 + 12000);
  assert.deepEqual(emitted.map((e) => [e.type, e.durationMs]).sort(), [["FACE_ABSENCE_EPISODE", 11000], ["FOCUS_LOSS_EPISODE", 12000]]);
  assert.equal(ee.getOpenEpisodes(T0 + 13000).length, 0);
});

test("observation monitor: coverage reflects what was seen", () => {
  const m = new ObservationMonitor({});
  m.start(T0);
  for (let k = 0; k < 20 * 30; k++) {
    const t = T0 + k * 50;
    if (k < 20 * 10) { m.processSignal({ type: "FACE_PRESENT", timestamp: t }); m.processSignal({ type: "GAZE_DEVIATION", timestamp: t, confidence: 0.6 }); }
    else if (k < 20 * 20) m.processSignal({ type: "FACE_ABSENT", timestamp: t });
  }
  const c = m.coverage(T0 + 30000);
  assert.equal(c.seconds, 30);
  assert.ok(Math.abs(c.vision - 20 / 30) < 1e-9);
  assert.ok(Math.abs(c.face - 10 / 30) < 1e-9);
  assert.ok(Math.abs(c.measurable - 10 / 30) < 1e-9);
  assert.equal(m.totals(T0 + 30000).longestCameraGapSeconds, 10);
});
