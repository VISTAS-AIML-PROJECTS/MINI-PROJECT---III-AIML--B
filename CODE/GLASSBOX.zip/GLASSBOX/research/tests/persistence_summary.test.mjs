// PersistenceManager (src/api/persistenceManager.js) with a mocked fetch, and the session summary (src/review/sessionSummary.js).
import test from "node:test";
import assert from "node:assert/strict";
import { PersistenceManager } from "../../src/api/persistenceManager.js";
import { summarizeRisk } from "../../src/review/sessionSummary.js";

function mockFetch({ failFirst = 0 } = {}) {
  const sent = [];
  let failures = failFirst;
  globalThis.fetch = async (url, opts) => {
    if (failures > 0) { failures -= 1; throw new Error("backend down"); }
    sent.push({ url, body: JSON.parse(opts.body) });
    return { ok: true, status: 201, json: async () => ({ success: true }) };
  };
  return sent;
}

const quiet = (fn) => async () => { const e = console.error; console.error = () => {}; try { await fn(); } finally { console.error = e; } };

test("vision samples are throttled per type; browser events are always kept", async () => {
  const sent = mockFetch();
  const pm = new PersistenceManager({ sessionId: 7 });
  const realNow = Date.now; let t = 1000; Date.now = () => t;
  try {
    for (let k = 0; k < 40; k++) {
      t = 1000 + k * 50;
      pm.addSignal({ type: "FACE_QUALITY", timestamp: t });
      pm.addSignal({ type: "GAZE_DEVIATION", timestamp: t });
      pm.addSignal({ type: "HEAD_POSE_DEVIATION", timestamp: t });
      pm.addSignal({ type: "FACE_PRESENT", timestamp: t });
    }
    pm.addSignal({ type: "FOCUS_LOST", timestamp: t });
  } finally { Date.now = realNow; }
  await pm.flush();
  const types = sent.map((s) => s.body.type);
  for (const ty of ["FACE_QUALITY", "GAZE_DEVIATION", "HEAD_POSE_DEVIATION"]) assert.equal(types.filter((x) => x === ty).length, 2, ty);
  assert.equal(types.filter((x) => x === "FOCUS_LOST").length, 1);
  assert.equal(types.filter((x) => x === "FACE_PRESENT").length, 0);
});

test("a failed send keeps the item queued and it is sent once, in order, on the next flush", quiet(async () => {
  const sent = mockFetch({ failFirst: 1 });
  const pm = new PersistenceManager({ sessionId: 3 });
  pm.addEvidence({ type: "FACE_ABSENCE_EPISODE", timestamp: 1, durationMs: 2000, strength: 0.4 });
  pm.addRisk({ timestamp: 1, score: 10, level: "LOW", reasons: [], components: {}, state: "OK", reliability: 1, version: "glassbox-assessment-2.1" });
  await pm.flush();
  assert.equal(sent.length, 0);
  await pm.flush();
  assert.deepEqual(sent.map((s) => s.url.split("/api")[1]), ["/evidence", "/risk"]);
  assert.equal(sent[1].body.engineVersion, "glassbox-assessment-2.1");
  assert.equal(sent[1].body.state, "OK");
  await pm.flush();
  assert.equal(sent.length, 2, "no duplicates");
}));

test("nothing is sent without a session, and reset() drops queued items", async () => {
  const sent = mockFetch();
  const none = new PersistenceManager();
  none.addRisk({ score: 1 }); await none.flush();
  const pm = new PersistenceManager({ sessionId: 1 });
  pm.addRisk({ score: 1 }); pm.reset(); await pm.flush();
  assert.equal(sent.length, 0);
});

test("session summary: peak, final, state shares and unobserved runs", () => {
  const r = (t, score, state, level, reliability) => ({ timestamp: t, score, state, level, reliability, engine_version: "glassbox-assessment-2.1" });
  const s = summarizeRisk([r(1000, 5, "INSUFFICIENT_EVIDENCE", "UNDETERMINED", 0.3), r(2000, 20, "OK", "LOW", 1), r(3000, 45, "DEGRADED", "MEDIUM", 0.7), r(4000, 30, "DEGRADED", "MEDIUM", 0.7), r(5000, 12, "OK", "LOW", 1)]);
  assert.equal(s.peak, 45); assert.equal(s.peakAt, 3000); assert.equal(s.final, 12); assert.equal(s.finalState, "OK");
  assert.equal(s.shareOk, 0.4); assert.equal(s.shareMediumOrHigh, 0.4);
  assert.deepEqual(s.insufficientRuns, [[1000, 1000]]); assert.deepEqual(s.degradedRuns, [[3000, 4000]]);
  assert.ok(Math.abs(s.meanReliability - 0.74) < 1e-9);
  assert.equal(summarizeRisk([]), null);
  const v1 = summarizeRisk([{ timestamp: 1, score: 40, level: "MEDIUM" }]);
  assert.equal(v1.finalState, null); assert.equal(v1.shareOk, null);
});
