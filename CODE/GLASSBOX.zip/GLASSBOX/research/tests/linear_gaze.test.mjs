import test from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import path from "node:path";
import { fileURLToPath } from "node:url";
import fs from "node:fs";
const here = path.dirname(fileURLToPath(import.meta.url));
// This check needs Python with the research requirements and the MPIIFaceGaze feature file (data/processed/mpii_features.parquet),
// which is not part of the repository; without them it is skipped rather than failed.
const haveData = fs.existsSync(path.join(here, "..", "..", "data", "processed", "mpii_features.parquet"));
test("JS linear gaze estimator matches the sklearn model on real rows", { skip: !haveData && "needs data/processed/mpii_features.parquet (MPIIFaceGaze features, not distributed)" }, () => {
  const out = execFileSync("python", [path.join(here, "test_linear_gaze_parity.py")], { encoding: "utf8" });
  assert.match(out, /max \|JS - sklearn\|/);
});
