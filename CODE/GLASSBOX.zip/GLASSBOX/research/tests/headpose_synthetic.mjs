// Feed known rotations (R = Rz(roll) Ry(yaw) Rx(pitch), column-major flatten like MediaPipe JS `.data`)
// through the app's extractHeadPose() and report the error.
import { extractHeadPose } from "../../src/modules/vision/headPoseMath.js";
const d2r = Math.PI / 180;
const Rx = a => [[1,0,0],[0,Math.cos(a),-Math.sin(a)],[0,Math.sin(a),Math.cos(a)]];
const Ry = a => [[Math.cos(a),0,Math.sin(a)],[0,1,0],[-Math.sin(a),0,Math.cos(a)]];
const Rz = a => [[Math.cos(a),-Math.sin(a),0],[Math.sin(a),Math.cos(a),0],[0,0,1]];
const mul = (A,B) => A.map((r,i)=>B[0].map((_,j)=>r.reduce((s,_,k)=>s+A[i][k]*B[k][j],0)));
const colMajor4 = R => [R[0][0],R[1][0],R[2][0],0, R[0][1],R[1][1],R[2][1],0, R[0][2],R[1][2],R[2][2],0, 0,0,0,1];
const cases = [];
for (const yaw of [-40,-20,0,20,40]) for (const pitch of [-25,0,25]) for (const roll of [-20,0,20])
  cases.push({yaw,pitch,roll});
const out = cases.map(c => {
  const R = mul(Rz(c.roll*d2r), mul(Ry(c.yaw*d2r), Rx(c.pitch*d2r)));
  const e = extractHeadPose(colMajor4(R));
  return {...c, yaw_hat:e.yaw, pitch_hat:e.pitch, roll_hat:e.roll};
});
console.log(JSON.stringify(out));
