// Personal-baseline construction (src/modules/vision/baselineMath.js): reference calculation, spread floors,
// rejection of unusable calibrations, and what a baseline does to the evidence gate. No camera or MediaPipe needed.
import test from "node:test";
import assert from "node:assert/strict";
import { buildBaseline, BASELINE_FLOORS } from "../../src/modules/vision/baselineMath.js";
import { gazeSampleStrength, headPoseSampleStrength } from "../../src/evidence/deviation.js";

// deterministic pseudo-random sequence (no Math.random in tests)
const lcg = (seed) => () => ((seed = (seed * 1664525 + 1013904223) % 4294967296) / 4294967296);
const popMean = (v) => v.reduce((a, b) => a + b, 0) / v.length;
const popStd = (v) => Math.sqrt(v.reduce((a, b) => a + (b - popMean(v)) ** 2, 0) / v.length);

function samples(n, { gx = 0.5, gy = 0.5, sd = 0.05, yaw = 2, pitch = -3, roll = 1, headSd = 1.5, q = 0.8, seed = 7 } = {}) {
  const r = lcg(seed), u = () => r() * 2 - 1;
  return {
    gazeX: Array.from({ length: n }, () => gx + sd * u()),
    gazeY: Array.from({ length: n }, () => gy + sd * u()),
    hHat: Array.from({ length: n }, () => 3 + 4 * u()),
    head: Array.from({ length: n }, () => ({ yaw: yaw + headSd * u(), pitch: pitch + headSd * u(), roll: roll + headSd * u() })),
    quality: Array.from({ length: n }, () => q),
    frames: n,
    durationMs: 33000,
  };
}

test("baseline equals the mean and population spread of the person's own calibration samples", () => {
  const s = samples(400);
  const { ok, baseline: b } = buildBaseline(s);
  assert.equal(ok, true);
  assert.ok(Math.abs(b.gazeXMean - popMean(s.gazeX)) < 1e-12);
  assert.ok(Math.abs(b.gazeXStd - popStd(s.gazeX)) < 1e-12);
  assert.ok(Math.abs(b.gazeYStd - popStd(s.gazeY)) < 1e-12);
  assert.ok(Math.abs(b.headYawMean - popMean(s.head.map((h) => h.yaw))) < 1e-12);
  assert.ok(Math.abs(b.headPitchStd - popStd(s.head.map((h) => h.pitch))) < 1e-12);
  assert.ok(Math.abs(b.hHatMean - popMean(s.hHat)) < 1e-12);
  assert.equal(b.sampleCount, 400);
  assert.equal(b.faceCoverage, 1);
});

test("two people get different baselines (nothing is shared between calibrations)", () => {
  const a = buildBaseline(samples(300, { yaw: 0, seed: 1 })).baseline;
  const b = buildBaseline(samples(300, { yaw: 12, seed: 2 })).baseline;
  assert.ok(Math.abs(b.headYawMean - a.headYawMean) > 10);
  // the same head angle is a large deviation for one person and none for the other
  const angle = 12;
  assert.ok(Math.abs(angle - a.headYawMean) > 8 && Math.abs(angle - b.headYawMean) < 3);
});

test("a perfectly still person gets floored spreads, so tiny movements are not huge z-scores", () => {
  const s = samples(200, { sd: 0, headSd: 0 });
  s.hHat = s.hHat.map(() => 3);
  const b = buildBaseline(s).baseline;
  assert.equal(b.gazeXStd, BASELINE_FLOORS.gazeStd);
  assert.equal(b.gazeYStd, BASELINE_FLOORS.gazeStd);
  assert.equal(b.hHatStd, BASELINE_FLOORS.hHatStd);
  assert.equal(b.headYawStd, BASELINE_FLOORS.headStdDegrees);
  assert.equal(b.headRollStd, BASELINE_FLOORS.headStdDegrees);
});

test("unusable calibrations are rejected with a reason, never silently accepted", () => {
  assert.equal(buildBaseline({ ...samples(99) }).reason, "TOO_FEW_SAMPLES");
  assert.equal(buildBaseline({ ...samples(300, { q: 0.3 }) }).reason, "LOW_QUALITY");
  assert.equal(buildBaseline({ ...samples(300), frames: 600 }).reason, "FACE_COVERAGE"); // face found in 50 % of frames
  assert.equal(buildBaseline({ ...samples(300), frames: 0 }).reason, "FACE_COVERAGE");
  const flat = samples(300); flat.gazeX = [];
  assert.equal(buildBaseline({ ...flat }).ok, false);
});

test("boundary: exactly 100 samples and exactly 60 % coverage are accepted", () => {
  assert.equal(buildBaseline({ ...samples(100) }).ok, true);
  const s = samples(300); s.frames = 500; // 0.6
  assert.equal(buildBaseline(s).ok, true);
});

test("non-finite regression outputs are ignored rather than poisoning the baseline", () => {
  const s = samples(300);
  s.hHat = [...s.hHat, NaN, Infinity, undefined];
  const b = buildBaseline(s).baseline;
  assert.ok(Number.isFinite(b.hHatMean) && Number.isFinite(b.hHatStd));
});

test("a person's own calibrated range is not a deviation; a clear turn away from it is", () => {
  const b = buildBaseline(samples(500, { yaw: 0, headSd: 1.5 })).baseline;
  const within = headPoseSampleStrength({ value: { yaw: 3, pitch: 2, roll: 1 }, metadata: { baselineStd: { yaw: b.headYawStd, pitch: b.headPitchStd, roll: b.headRollStd } } });
  const turned = headPoseSampleStrength({ value: { yaw: 25, pitch: 2, roll: 1 }, metadata: { baselineStd: { yaw: b.headYawStd, pitch: b.headPitchStd, roll: b.headRollStd } } });
  assert.equal(within, 0);
  assert.ok(turned > 0.5);
  assert.equal(gazeSampleStrength({ value: 1.2 }), 0);
  assert.ok(gazeSampleStrength({ value: 6 }) > 0.5);
});
