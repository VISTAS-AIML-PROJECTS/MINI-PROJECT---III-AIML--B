// Replays a recorded signal stream through the REAL Evidence -> Fusion -> Risk chain (src/) and prints the risk score after
// each frame. Input (stdin): {"frames":[{"t":<ms>,"signals":[{type,value,metadata?}, ...]}, ...]}. Output: JSON array of scores.
import path from "path";
import { pathToFileURL } from "url";
const root = path.resolve(process.argv[2] ?? new URL("../../src", import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, "$1"));
const imp = p => import(pathToFileURL(path.join(root, p)).href);
const { EvidenceEngine } = await imp("evidence/evidenceEngine.js");
const { FusionEngine } = await imp("risk/fusionEngine.js");
const { RiskEngine } = await imp("risk/riskEngine.js");
const chunks = []; for await (const c of process.stdin) chunks.push(c);
const { frames } = JSON.parse(Buffer.concat(chunks).toString("utf8"));
let t = 0; const origNow = Date.now; Date.now = () => t;
const risk = new RiskEngine();
const ee = new EvidenceEngine({ onEvidence: e => risk.processEvidence(e) });
const fe = new FusionEngine({ onFusion: f => risk.processFusion(f) });
const out = [];
try {
  for (const fr of frames) {
    t = fr.t;
    for (const s of fr.signals) { const sig = { type: s.type, source: "vision", timestamp: t, value: s.value, confidence: 1, metadata: s.metadata ?? {} }; ee.processSignal(sig); fe.processSignal(sig); }
    out.push(risk.calculateRisk().score);
  }
} finally { Date.now = origNow; }
console.log(JSON.stringify(out));
