// Unit test of src/modules/browser/browserSignalCollector.js with a minimal DOM stub (no browser needed).
import test from "node:test";
import assert from "node:assert/strict";

function makeEnv() {
  const listeners = { document: {}, window: {} };
  const add = (bucket) => (type, fn) => { (listeners[bucket][type] ??= []).push(fn); };
  const remove = (bucket) => (type, fn) => { listeners[bucket][type] = (listeners[bucket][type] ?? []).filter((f) => f !== fn); };
  globalThis.document = { hidden: false, visibilityState: "visible", addEventListener: add("document"), removeEventListener: remove("document") };
  globalThis.window = { addEventListener: add("window"), removeEventListener: remove("window") };
  let focused = true;
  document.hasFocus = () => focused;
  const fire = (bucket, type) => (listeners[bucket][type] ?? []).forEach((f) => f());
  return { fire, setFocused: (v) => { focused = v; } };
}

const { createBrowserSignalCollector } = await import("../../src/modules/browser/browserSignalCollector.js");
const types = (log) => log.map((s) => s.type);

test("tab hidden without a window blur still yields exactly one FOCUS_LOST and one FOCUS_GAINED", () => {
  const env = makeEnv(); const log = []; const c = createBrowserSignalCollector((s) => log.push(s)); c.start();
  document.hidden = true; document.visibilityState = "hidden"; env.setFocused(false); env.fire("document", "visibilitychange");
  document.hidden = false; document.visibilityState = "visible"; env.setFocused(true); env.fire("document", "visibilitychange");
  c.stop();
  assert.deepEqual(types(log), ["TAB_HIDDEN", "FOCUS_LOST", "TAB_VISIBLE", "FOCUS_GAINED"]);
});

test("normal blur/focus and tab hide/show together are not double-counted", () => {
  const env = makeEnv(); const log = []; const c = createBrowserSignalCollector((s) => log.push(s)); c.start();
  env.setFocused(false); env.fire("window", "blur");
  document.hidden = true; env.fire("document", "visibilitychange");
  document.hidden = false; env.setFocused(true); env.fire("document", "visibilitychange"); env.fire("window", "focus");
  c.stop();
  assert.equal(types(log).filter((x) => x === "FOCUS_LOST").length, 1);
  assert.equal(types(log).filter((x) => x === "FOCUS_GAINED").length, 1);
});

test("plain window blur then focus yields one FOCUS_LOST and one FOCUS_GAINED; initial focus emits nothing", () => {
  const env = makeEnv(); const log = []; const c = createBrowserSignalCollector((s) => log.push(s)); c.start();
  env.fire("window", "focus");
  env.setFocused(false); env.fire("window", "blur"); env.setFocused(true); env.fire("window", "focus");
  c.stop();
  assert.deepEqual(types(log), ["FOCUS_LOST", "FOCUS_GAINED"]);
});
