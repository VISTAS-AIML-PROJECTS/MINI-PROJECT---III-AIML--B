"""Validate head-pose decomposition: JS app formula (ported), vs. the standard decomposition, on known rotations.
Also checks Python port == JS output (parity) by calling node."""
import json, subprocess, sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from glassbox_vision import extract_head_pose_legacy, extract_head_pose

d = np.pi / 180
Rx = lambda a: np.array([[1,0,0],[0,np.cos(a),-np.sin(a)],[0,np.sin(a),np.cos(a)]])
Ry = lambda a: np.array([[np.cos(a),0,np.sin(a)],[0,1,0],[-np.sin(a),0,np.cos(a)]])
Rz = lambda a: np.array([[np.cos(a),-np.sin(a),0],[np.sin(a),np.cos(a),0],[0,0,1]])

js = json.loads(subprocess.check_output(["node", str(Path(__file__).parent / "headpose_synthetic.mjs")], text=True))
errs = {"js_port_vs_js": 0.0}
mae = {"js": {k: [] for k in ("yaw","pitch","roll")}, "fixed": {k: [] for k in ("yaw","pitch","roll")}}
sgn = {k: [] for k in ("yaw","pitch","roll")}
for c in js:
    R = Rz(c["roll"]*d) @ Ry(c["yaw"]*d) @ Rx(c["pitch"]*d)
    m = np.eye(4); m[:3,:3] = R; flat = m.T.ravel()
    p = extract_head_pose(flat); f = extract_head_pose(flat); L = extract_head_pose_legacy(flat)
    errs["js_port_vs_js"] = max(errs["js_port_vs_js"], abs(p["yaw"]-c["yaw_hat"]), abs(p["pitch"]-c["pitch_hat"]), abs(p["roll"]-c["roll_hat"]))
    for k in ("yaw","pitch","roll"):
        mae["fixed"][k].append(abs(f[k]-c[k]))
        # error of the JS formula allowing for a global sign flip (the app only uses |x-baseline|)
        mae["js"][k].append(min(abs(L[k]-c[k]), abs(-L[k]-c[k])))
print("max |python port - JS| (deg):", errs["js_port_vs_js"])
for m_ in mae: print({"js":"legacy (sign-flip tolerated)","fixed":"fixed"}[m_], {k: round(float(np.mean(v)),3) for k,v in mae[m_].items()})
assert errs["js_port_vs_js"] < 1e-6
assert max(np.mean(v) for v in mae["fixed"].values()) < 1e-6
