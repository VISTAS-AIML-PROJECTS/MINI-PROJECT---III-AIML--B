// Session isolation in the persistence layer: an upload still in flight when a session ends must neither
// leak into, nor swallow data from, the next session; and the end-of-session flush must wait for it.
import test from "node:test";
import assert from "node:assert/strict";
import { PersistenceManager } from "../../src/api/persistenceManager.js";

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function slowBackend(delayMs) {
  const sent = [];
  globalThis.fetch = async (url, opts) => {
    await sleep(delayMs);
    sent.push({ path: url.split("/api")[1], body: JSON.parse(opts.body) });
    return { ok: true, status: 201, json: async () => ({ success: true }) };
  };
  return sent;
}
const sig = (id) => ({ type: "FOCUS_LOST", source: "browser", timestamp: id, value: id });

test("data queued after a new session starts is sent under the new session id, even if the old flush was in flight", async () => {
  const sent = slowBackend(30);
  const pm = new PersistenceManager({ sessionId: 1 });
  pm.addSignal(sig(1)); pm.addSignal(sig(2));
  const inFlight = pm.flush();              // session 1 upload running
  await sleep(10);
  pm.reset(); pm.setSessionId(2);           // user starts session 2 (App.handleStartSession order)
  pm.addSignal(sig(100));
  await inFlight; await pm.flush();
  const forB = sent.filter((s) => s.body.sessionId === 2).map((s) => s.body.value);
  assert.deepEqual(forB, [100], "session 2's signal must be stored once, under session 2");
  assert.equal(sent.filter((s) => s.body.sessionId === 1 && s.body.value === 100).length, 0, "no session 2 data under session 1");
});

test("end-of-session flush waits for an in-flight flush and then sends what was queued meanwhile", async () => {
  const sent = slowBackend(30);
  const pm = new PersistenceManager({ sessionId: 5 });
  pm.addRisk({ timestamp: 1, score: 10, level: "LOW", reasons: [], components: {}, state: "OK", reliability: 1 });
  const inFlight = pm.flush();              // periodic upload, already in the last (risk) stage
  await sleep(10);
  pm.addEvidence({ type: "FACE_ABSENCE_EPISODE", timestamp: 2, durationMs: 4000, strength: 0.8 }); // episode closed by finalize()
  await pm.flush();                         // what handleEndSession awaits
  assert.ok(sent.some((s) => s.path === "/evidence"), "the final evidence episode must be stored before the session is closed");
  await inFlight;
});

test("reset() does not touch the sessions already stored: a later flush sends nothing for the old session", async () => {
  const sent = slowBackend(1);
  const pm = new PersistenceManager({ sessionId: 8 });
  pm.addSignal(sig(1)); await pm.flush();
  const before = sent.length;
  pm.reset(); await pm.flush();
  assert.equal(sent.length, before);
});

// ---- scoring state ---------------------------------------------------------------------------------------------
import { SCENARIOS } from "../final/scenarios.mjs";
import { runV2 } from "../final/runners.mjs";
import { AssessmentPipeline } from "../../src/assessment/pipeline.js";
import { VisionTracker } from "../../src/modules/vision/visionTracker.js";

const scn = (name) => SCENARIOS.find((s) => s.name.startsWith(name));
const plain = (x) => JSON.parse(JSON.stringify(x));

test("session B on a reused pipeline is identical to session B on a fresh one (score, level, state, reasons, v1 score)", () => {
  const reused = new AssessmentPipeline({});
  runV2(scn("S06"), { pipeline: reused });              // session A: focus loss + face absence, ends HIGH-ish
  const afterA = runV2(scn("S03"), { pipeline: reused }); // session B on the same objects
  const fresh = runV2(scn("S03"));
  assert.deepEqual(plain(afterA.rows), plain(fresh.rows));
  assert.deepEqual(plain(afterA.final), plain(fresh.final));
});

test("an interrupted session (never finalized) does not leak into the next one", () => {
  const p = new AssessmentPipeline({});
  const t0 = 1_000_000;
  p.start(t0); p.setCalibrated(true);
  for (let s = 0; s < 40; s++) {                          // face absent from 10 s on, then the tab closes: no finalize()
    const t = t0 + s * 1000;
    p.processSignal({ type: s < 10 ? "FACE_PRESENT" : "FACE_ABSENT", source: "vision", timestamp: t, value: true });
    p.tick(t + 500);
  }
  const reusedB = runV2(scn("S01"), { pipeline: p });
  const freshB = runV2(scn("S01"));
  assert.deepEqual(plain(reusedB.rows), plain(freshB.rows));
});

// ---- personal baseline -----------------------------------------------------------------------------------------
test("the personal baseline is cleared after a session and cannot be cleared mid-calibration", () => {
  const updates = [];
  const t = new VisionTracker({ video: null, onCalibrationUpdate: (u) => updates.push(u) });
  t.baseline = { gazeXMean: 0.5, headYawMean: 3 };
  t.calibrationGazeX = [1, 2, 3];
  assert.equal(t.clearBaseline(), true);
  assert.equal(t.baseline, null);
  assert.deepEqual(t.calibrationGazeX, []);
  assert.equal(updates.at(-1).phase, "IDLE");

  t.baseline = { gazeXMean: 0.5 };
  t.calibrating = true;                                   // a calibration is running: must not be disturbed
  assert.equal(t.clearBaseline(), false);
  assert.deepEqual(t.baseline, { gazeXMean: 0.5 });
});
