// Replay synthetic users through the real Evidence -> Fusion -> Risk chain.
//   node engine_replay.mjs <srcRoot>      (srcRoot defaults to ../../src ; pass an extracted old commit to compare)
// Scenarios (15 fps, 180 s, 20 seeds each):
//   calm   : horizontal gaze z = |N(0,1)| (the app's GAZE_DEVIATION is horizontal-only), head deviation |N(0,sd)|
//   glance : calm + five 4 s look-aways (gaze z = |7 + N(0,1)|, yaw deviation ~ 30 deg)
// Output: risk statistics. Synthetic and idealised -- a regression/sensitivity test, NOT validation evidence.
import path from "path";
import { pathToFileURL } from "url";
const root = path.resolve(process.argv[2] ?? new URL("../../src", import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, "$1"));
const imp = p => import(pathToFileURL(path.join(root, p)).href);
const { EvidenceEngine } = await imp("evidence/evidenceEngine.js");
const { FusionEngine } = await imp("risk/fusionEngine.js");
const { RiskEngine } = await imp("risk/riskEngine.js");
const { SIGNAL_TYPES: T } = await imp("core/signal.js");

const CALM_SD = Number(process.env.CALM_SD ?? 1);   // >1 simulates a calibration SD that under-estimates the user's natural variability
const rng = seed => { let s = seed >>> 0; return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296); };
const gauss = r => Math.sqrt(-2 * Math.log(1 - r())) * Math.cos(2 * Math.PI * r());

function run(scenario, seed) {
  const r = rng(seed);
  let t = 1_000_000;
  const t0 = t;
  const risk = new RiskEngine();
  let lastRisk = null; const riskTrace = [];
  const risk_cb = x => { lastRisk = x; };
  risk.onRisk = risk_cb;
  const ee = new EvidenceEngine({ onEvidence: e => risk.processEvidence(e) });
  // The legacy/fixed EvidenceEngine both call this.onEvidence(...) from emitEvidence; stamp timestamps from the sim clock.
  const fe = new FusionEngine({ onFusion: f => risk.processFusion(f) });
  const std = { yaw: 1.5, pitch: 1.5, roll: 1.0 };
  const glances = scenario === "glance" ? [20, 50, 80, 110, 140].map(s => [s * 1000, s * 1000 + 4000]) : [];
  const origNow = Date.now; Date.now = () => t;   // engines stamp with Date.now(); drive it from the sim clock
  try {
    const feed = s => { ee.processSignal(s); fe.processSignal(s); };
    const mk = (type, value, metadata = {}) => ({ type, source: "vision", timestamp: t, value, confidence: 1, metadata });
    feed(mk(T.FACE_PRESENT, true));
    for (let k = 0; k * 66 < 180_000; k++, t = t0 + k * 66) {
      const el = t - t0; const away = glances.some(([a, b]) => el >= a && el < b);
      const z = away ? Math.abs(7 + gauss(r)) : Math.abs(gauss(r)) * CALM_SD;
      const yaw = away ? 30 + gauss(r) * 2 : Math.abs(gauss(r)) * std.yaw * CALM_SD;
      feed(mk(T.GAZE_DEVIATION, z));
      feed(mk(T.HEAD_POSE_DEVIATION, { yaw, pitch: Math.abs(gauss(r)) * std.pitch, roll: Math.abs(gauss(r)) * std.roll }, { baselineStd: std }));
      if (k % 15 === 0 && lastRisk) riskTrace.push(lastRisk.score);
    }
    // close any open episodes
    t += 3000; feed(mk(T.FACE_ABSENT, true)); t += 100; feed(mk(T.FACE_PRESENT, true));
  } finally { Date.now = origNow; }
  const fin = risk.calculateRisk();
  return { final: fin.score, max: Math.max(0, ...riskTrace), mean: riskTrace.length ? riskTrace.reduce((a, b) => a + b, 0) / riskTrace.length : 0 };
}
const stat = a => ({ mean: +(a.reduce((x, y) => x + y, 0) / a.length).toFixed(1), min: Math.min(...a), max: Math.max(...a) });
const out = {};
for (const sc of ["calm", "glance"]) {
  const rs = Array.from({ length: 20 }, (_, i) => run(sc, 100 + i));
  out[sc] = { mean_risk: stat(rs.map(x => x.mean)), max_risk: stat(rs.map(x => x.max)), final_risk: stat(rs.map(x => x.final)) };
}
console.log(JSON.stringify(out));
