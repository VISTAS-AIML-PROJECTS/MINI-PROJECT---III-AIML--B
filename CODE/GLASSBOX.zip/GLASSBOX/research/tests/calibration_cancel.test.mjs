// Calibration cancellation (VisionTracker.cancelCalibration) and the CSS scope guard for the full-viewport calibration layout.
// No camera or browser: the tracker's state machine is driven directly with synthetic samples.
import test from "node:test";
import assert from "node:assert/strict";
import crypto from "crypto";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { VisionTracker } from "../../src/modules/vision/visionTracker.js";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "..");

function tracker() {
  const updates = [];
  const statuses = [];
  const t = new VisionTracker({
    video: null,
    onCalibrationUpdate: (u) => updates.push(u),
    onStatus: (m) => statuses.push(m),
  });
  t.running = true;
  return { t, updates, statuses };
}

function addSamples(t, n, { gaze = 0.5, yaw = 2, q = 0.8 } = {}) {
  for (let i = 0; i < n; i++) {
    const wobble = ((i * 37) % 11) / 100;
    t.calibrationGazeX.push(gaze + wobble);
    t.calibrationGazeY.push(gaze + wobble / 2);
    t.calibrationHHat.push(3 + wobble * 10);
    t.calibrationHead.push({ yaw: yaw + wobble * 10, pitch: -3 + wobble * 5, roll: 1 + wobble });
    t.calibrationQuality.push(q);
  }
  t.calibrationFrames = n;
}

test("cancel discards every partial sample, leaves no baseline and reports an IDLE state", () => {
  const { t, updates, statuses } = tracker();
  t.beginCalibration();
  addSamples(t, 250);
  t.calibrationPhase = "GUIDED";

  assert.equal(t.cancelCalibration(), true);
  assert.equal(t.calibrating, false);
  assert.equal(t.calibrationPhase, "IDLE");
  assert.equal(t.baseline, null);
  for (const key of ["calibrationGazeX", "calibrationGazeY", "calibrationHHat", "calibrationHead", "calibrationQuality"]) {
    assert.deepEqual(t[key], [], key);
  }
  assert.equal(t.calibrationFrames, 0);
  assert.equal(updates.at(-1).phase, "IDLE");
  assert.equal(statuses.at(-1), "Calibration cancelled.");
});

test("after a cancel no late frame or timer can finish or extend the calibration", () => {
  const { t } = tracker();
  t.beginCalibration();
  addSamples(t, 250);
  t.cancelCalibration();

  t.updateCalibrationPhase(performance.now() + 60_000); // would have finished it
  assert.equal(t.finishCalibration(), false);
  assert.equal(t.baseline, null);
  assert.equal(t.calibrationGazeX.length, 0);
});

test("nothing from a cancelled calibration leaks into the next one", () => {
  const { t } = tracker();
  t.beginCalibration();
  addSamples(t, 300, { gaze: 0.9, yaw: 25 });             // person A, far from the later values
  t.cancelCalibration();

  t.beginCalibration();
  assert.equal(t.calibrationGazeX.length, 0);
  addSamples(t, 150, { gaze: 0.4, yaw: 1 });              // the real calibration
  assert.equal(t.finishCalibration(), true);

  assert.ok(Math.abs(t.baseline.gazeXMean - 0.45) < 0.1, `gazeXMean ${t.baseline.gazeXMean}`);
  assert.ok(Math.abs(t.baseline.headYawMean - 1) < 3, `yaw mean ${t.baseline.headYawMean}`);
  assert.equal(t.baseline.sampleCount, 150);
});

test("cancel does nothing, and never erases a finished baseline, when no calibration is running", () => {
  const { t, updates } = tracker();
  t.beginCalibration();
  addSamples(t, 200);
  assert.equal(t.finishCalibration(), true);
  const baseline = t.baseline;
  const seen = updates.length;

  assert.equal(t.cancelCalibration(), false);
  assert.equal(t.baseline, baseline);
  assert.equal(updates.length, seen);
});

test("a session ending after a cancelled calibration still clears cleanly and a new calibration can start", () => {
  const { t } = tracker();
  t.beginCalibration();
  t.cancelCalibration();
  assert.equal(t.clearBaseline(), true);
  t.beginCalibration();
  assert.equal(t.calibrating, true);
  assert.equal(t.calibrationPhase, "NATURAL_START");
});

// ---- CSS scope guard -----------------------------------------------------------------------------------------------
const css = fs.readFileSync(path.join(ROOT, "src/App.css"), "utf8").replace(/\r\n/g, "\n");
const START = "/*\n * Full-viewport calibration.";
const END = ".vision__status {\n  min-width: 0;";

test("CSS outside the calibration block is byte-identical to the stable stylesheet (normal monitoring layout untouched)", () => {
  const a = css.indexOf(START);
  const b = css.indexOf(END);
  assert.ok(a > 0 && b > a);
  const rest = css.slice(0, a) + css.slice(b);
  // sha256 of the same text taken from stable commit 2954e9e
  assert.equal(crypto.createHash("sha256").update(rest).digest("hex"), "31956686c5e663cc9a501101bf437e229cd07a9f991731db29614b81cd990b42");
});

test("every selector inside the calibration block is scoped to .vision--calibrating", () => {
  const block = css.slice(css.indexOf(START), css.indexOf(END)).replace(/\/\*[\s\S]*?\*\//g, "");
  const selectors = [...block.matchAll(/([^{}]+)\{/g)].map((m) => m[1].trim()).filter((s) => !s.startsWith("@media"));
  assert.ok(selectors.length >= 8);

  for (const group of selectors) {
    for (const sel of group.split(",").map((s) => s.trim())) {
      assert.ok(sel.startsWith(".vision--calibrating"), `unscoped selector: ${sel}`);
    }
  }
});
