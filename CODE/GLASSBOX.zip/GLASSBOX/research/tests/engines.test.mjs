// `npm test` – regression tests for the sensing math and the gated Evidence/Fusion/Risk chain.
import test from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import path from "node:path";
import { fileURLToPath } from "node:url";
const here = path.dirname(fileURLToPath(import.meta.url));
const run = f => JSON.parse(execFileSync("node", [path.join(here, f)], { encoding: "utf8" }));

test("extractHeadPose recovers known yaw/pitch/roll", () => {
  for (const r of run("headpose_synthetic.mjs")) {
    for (const k of ["yaw", "pitch", "roll"]) assert.ok(Math.abs(r[k] - r[k + "_hat"]) < 1e-6, `${k} ${r[k]} vs ${r[k + "_hat"]}`);
  }
});

test("calm user stays low risk; repeated 4 s look-aways are clearly separated", () => {
  const out = run("engine_replay.mjs");
  assert.ok(out.calm.max_risk.max < 15, `calm max risk ${out.calm.max_risk.max}`);
  assert.ok(out.glance.max_risk.min > out.calm.max_risk.max + 15, `glance min ${out.glance.max_risk.min}`);
});

test("risk does not grow with exam length for a calm user (decay)", () => {
  const out = run("engine_replay.mjs");
  assert.ok(out.calm.final_risk.max < 15);
});
