// Replay a perfectly *calm* user (no off-task behaviour) through the real EvidenceEngine + RiskEngine.
// Per-frame values are drawn from the calibration distribution itself: gaze z ~ hypot(N(0,1),N(0,1)),
// head deviation ~ |N(0, 1 sd)| with the sds measured at calibration (yaw/pitch/roll in degrees).
// A 2 s face-absent gap closes the open episodes (as it would in any real session).
import { EvidenceEngine } from "../../src/evidence/evidenceEngine.js";
import { RiskEngine } from "../../src/risk/riskEngine.js";
import { SIGNAL_TYPES as T } from "../../src/core/signal.js";

function rng(seed){ let s=seed>>>0; return ()=>{ s=(s*1664525+1013904223)>>>0; return s/4294967296; }; }
function gauss(r){ return Math.sqrt(-2*Math.log(1-r()))*Math.cos(2*Math.PI*r()); }

const out = [];
for (const dur of [10, 30, 60, 180]) {
  const r = rng(1234 + dur);
  const evidence = [];
  const ee = new EvidenceEngine({ onEvidence: e => evidence.push(e) });
  // EvidenceEngine emits via this.emitEvidence -> onEvidence
  const risk = new RiskEngine();
  let t = 0; const dt = 66; // ~15 fps
  const send = (type, value) => ee.processSignal({ type, timestamp: t, value, confidence: 1, source: "vision" });
  send(T.FACE_PRESENT, true);
  for (; t < dur * 1000; t += dt) {
    send(T.GAZE_DEVIATION, Math.hypot(gauss(r), gauss(r)));
    send(T.HEAD_POSE_DEVIATION, { yaw: Math.abs(gauss(r)) * 2.0, pitch: Math.abs(gauss(r)) * 2.0, roll: Math.abs(gauss(r)) * 1.0 });
  }
  t += 2000; send(T.FACE_ABSENT, true); t += 200; send(T.FACE_PRESENT, true); t += 2000;
  send(T.FACE_ABSENT, true); // force close of open gaze/head episodes via gap
  const eps = evidence.filter(e => e.type.includes("GAZE") || e.type.includes("HEAD"));
  eps.forEach(e => risk.processEvidence(e));
  const rr = risk.calculateRisk();
  out.push({ calm_seconds: dur, episodes: eps.map(e => ({ type: e.type, strength: +e.strength.toFixed(3), durationMs: e.durationMs })), risk_score: rr.score, level: rr.level });
}
console.log(JSON.stringify(out, null, 1));
