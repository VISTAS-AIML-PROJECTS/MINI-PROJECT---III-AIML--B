"""Parity: JS estimateHorizontalGazeDeg (src/modules/vision/linearGaze.js) == the sklearn ridge pipeline it was exported from,
on 200 real MPIIFaceGaze rows. Requires data/processed/mpii_features.parquet."""
import json, subprocess, sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from mpii_common import load
FEAT = ["gx", "gy", "rx", "lx", "ry", "ly", "yaw", "pitch", "roll"]
df = load(); m = make_pipeline(StandardScaler(), Ridge(alpha=10.0)).fit(df[FEAT], df.h)
rows = df.sample(200, random_state=1)
py = m.predict(rows[FEAT])
js_in = [dict(gaze=dict(gazeX=r.gx, gazeY=r.gy, rightEye=dict(x=r.rx, y=r.ry), leftEye=dict(x=r.lx, y=r.ly)), head=dict(yaw=r.yaw, pitch=r.pitch, roll=r.roll)) for r in rows.itertuples()]
script = "import {estimateHorizontalGazeDeg as f} from '../../src/modules/vision/linearGaze.js';import fs from 'fs';const d=JSON.parse(fs.readFileSync(0,'utf8'));console.log(JSON.stringify(d.map(x=>f(x.gaze,x.head))))"
tmp = Path(__file__).parent / "_parity_tmp.mjs"; tmp.write_text(script)
try:
    out = subprocess.run(["node", str(tmp)], input=json.dumps(js_in), capture_output=True, text=True, check=True).stdout
finally:
    tmp.unlink()
js = np.array(json.loads(out)); err = np.max(np.abs(js - py))
print("max |JS - sklearn| (deg):", err); assert err < 1e-6
