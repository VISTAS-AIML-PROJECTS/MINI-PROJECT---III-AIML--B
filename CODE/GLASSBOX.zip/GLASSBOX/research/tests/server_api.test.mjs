// Backend API tests against a throw-away SQLite file (GLASSBOX_DB_PATH). The real glassbox.db is never opened.
import test, { after, before } from "node:test";
import assert from "node:assert/strict";
import fs from "fs";
import os from "os";
import path from "path";

const dir = fs.mkdtempSync(path.join(os.tmpdir(), "glassbox-api-"));
process.env.GLASSBOX_DB_PATH = path.join(dir, "test.db");
const { default: app } = await import("../../server/server.js");
const { default: db } = await import("../../server/database.js");

let server;
let base;

before(async () => {
  server = app.listen(0);
  await new Promise((r) => server.once("listening", r));
  base = `http://127.0.0.1:${server.address().port}/api`;
});

after(() => {
  server.close();
  db.close();
  fs.rmSync(dir, { recursive: true, force: true });
});

const call = async (method, url, body) => {
  const res = await fetch(base + url, { method, headers: { "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
  return { status: res.status, body: await res.json() };
};

async function newSession() {
  const exam = await call("POST", "/exams", { title: "t" });
  const student = await call("POST", "/students", { name: "s", email: `s${Math.random()}@x` });
  const s = await call("POST", "/sessions", { examId: exam.body.exam.id, studentId: student.body.student.id, condition: "NORMAL" });
  return s.body.session.id;
}

test("health endpoint responds", async () => {
  const r = await call("GET", "/health");
  assert.equal(r.status, 200);
  assert.equal(r.body.status, "ok");
});

test("v2 risk rows round-trip with state, reliability, version and details", async () => {
  const id = await newSession();
  const details = { coverage: { vision: 1, measurable: 0.5 }, contributions: { attention: { weight: 0.5, points: 20 } } };
  const r = await call("POST", "/risk", { sessionId: id, timestamp: 123, score: 20, level: "UNDETERMINED", reasons: ["x"], components: { gazeDeviation: 0.4 }, state: "INSUFFICIENT_EVIDENCE", reliability: 0.4, engineVersion: "glassbox-assessment-2.1", details });
  assert.equal(r.status, 201);
  const s = await call("GET", `/sessions/${id}`);
  const row = s.body.risk[0];
  assert.equal(row.state, "INSUFFICIENT_EVIDENCE");
  assert.equal(row.reliability, 0.4);
  assert.equal(row.engine_version, "glassbox-assessment-2.1");
  assert.deepEqual(row.details, details);
  assert.equal(row.level, "UNDETERMINED");
});

test("risk input is validated (no NaN, out-of-range or unknown level stored)", async () => {
  const id = await newSession();
  for (const bad of [{ score: "NaN" }, { score: 101 }, { score: -1 }, { score: null }, { score: 10, reliability: 2 }, { score: 10, level: "SEVERE" }]) {
    const r = await call("POST", "/risk", { sessionId: id, ...bad });
    assert.equal(r.status, 400, JSON.stringify(bad));
  }
  assert.equal((await call("GET", `/sessions/${id}`)).body.risk.length, 0);
  assert.equal((await call("POST", "/risk", { sessionId: 999999, score: 5 })).status, 404);
});

test("legacy v1 risk rows (no v2 fields) are still accepted", async () => {
  const id = await newSession();
  assert.equal((await call("POST", "/risk", { sessionId: id, timestamp: 1, score: 12, level: "LOW", reasons: [], components: {} })).status, 201);
  const row = (await call("GET", `/sessions/${id}`)).body.risk[0];
  assert.equal(row.state, null);
  assert.equal(row.engine_version, null);
});

test("ending a session: normal end is COMPLETED, unload beacon is INTERRUPTED, repeat end is a no-op", async () => {
  const a = await newSession();
  assert.equal((await call("POST", `/sessions/${a}/end`)).body.session.status, "COMPLETED");
  const b = await newSession();
  assert.equal((await call("POST", `/sessions/${b}/end?reason=unload`)).body.session.status, "INTERRUPTED");
  const again = await call("POST", `/sessions/${a}/end?reason=unload`);
  assert.equal(again.body.session.status, "COMPLETED");
  assert.equal((await call("POST", "/sessions/999999/end")).status, 404);
});

test("a stale ACTIVE session is reported INTERRUPTED without modifying the stored row", async () => {
  const id = await newSession();
  db.prepare("UPDATE exam_sessions SET started_at = ? WHERE id = ?").run(new Date(Date.now() - 3600_000).toISOString(), id);
  const list = (await call("GET", "/sessions")).body.sessions.find((s) => s.id === id);
  assert.equal(list.status, "INTERRUPTED");
  assert.equal((await call("GET", `/sessions/${id}`)).body.session.status, "INTERRUPTED");
  assert.equal(db.prepare("SELECT status FROM exam_sessions WHERE id = ?").get(id).status, "ACTIVE");
});

test("session list reports final state and engine version; evidence metadata round-trips", async () => {
  const id = await newSession();
  await call("POST", "/risk", { sessionId: id, timestamp: 1, score: 40, level: "MEDIUM", state: "OK", reliability: 1, engineVersion: "glassbox-assessment-2.1" });
  await call("POST", "/risk", { sessionId: id, timestamp: 2, score: 10, level: "LOW", state: "DEGRADED", reliability: 0.7, engineVersion: "glassbox-assessment-2.1" });
  await call("POST", "/evidence", { sessionId: id, type: "FACE_ABSENCE_EPISODE", timestamp: 2, durationMs: 60000, strength: 1, metadata: { endedBy: "SESSION_END" } });
  const row = (await call("GET", "/sessions")).body.sessions.find((s) => s.id === id);
  assert.equal(row.peak_risk, 40);
  assert.equal(row.final_risk, 10);
  assert.equal(row.final_state, "DEGRADED");
  assert.equal(row.engine_version, "glassbox-assessment-2.1");
  assert.deepEqual((await call("GET", `/sessions/${id}`)).body.evidence[0].metadata, { endedBy: "SESSION_END" });
});

test("unknown session returns 404 and server keeps serving", async () => {
  assert.equal((await call("GET", "/sessions/424242")).status, 404);
  assert.equal((await call("GET", "/health")).status, 200);
});

test("CORS: the local front end is allowed, other web origins are not", async () => {
  const allowed = await fetch(base + "/health", { headers: { Origin: "http://localhost:5173" } });
  assert.equal(allowed.headers.get("access-control-allow-origin"), "http://localhost:5173");

  const foreign = await fetch(base + "/sessions", { headers: { Origin: "https://evil.example" } });
  assert.equal(foreign.headers.get("access-control-allow-origin"), null);

  const none = await fetch(base + "/health");
  assert.equal(none.status, 200);
});

test("sessions are independent in storage: history of session A is unchanged by session B, and events go to the right session", async () => {
  const a = await newSession();
  await call("POST", "/signals", { sessionId: a, type: "FOCUS_LOST", source: "browser", timestamp: 1, value: true });
  await call("POST", "/risk", { sessionId: a, timestamp: 2, score: 55, level: "MEDIUM", reasons: ["a"], components: {} });
  await call("POST", `/sessions/${a}/end`);
  const before = JSON.stringify((await call("GET", `/sessions/${a}`)).body);

  const b = await newSession();
  assert.notEqual(a, b);
  await call("POST", "/signals", { sessionId: b, type: "FACE_ABSENT", source: "vision", timestamp: 3, value: true });
  await call("POST", "/risk", { sessionId: b, timestamp: 4, score: 5, level: "LOW", reasons: ["b"], components: {} });

  assert.equal(JSON.stringify((await call("GET", `/sessions/${a}`)).body), before, "session A history must not change");
  const gb = (await call("GET", `/sessions/${b}`)).body;
  assert.equal(gb.signals.length, 1);
  assert.equal(gb.signals[0].type, "FACE_ABSENT");
  assert.equal(gb.risk.length, 1);
  assert.equal(gb.risk[0].score, 5);
});
