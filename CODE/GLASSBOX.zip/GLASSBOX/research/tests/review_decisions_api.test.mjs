// Review decisions API (append-only) against a THROW-AWAY database (GLASSBOX_DB_PATH). The real glassbox.db is never opened.
// The database is pre-filled with an older-schema session before the server loads, to check that existing rows survive.
import test, { after, before } from "node:test";
import assert from "node:assert/strict";
import fs from "fs";
import os from "os";
import path from "path";
import Database from "better-sqlite3";

const dir = fs.mkdtempSync(path.join(os.tmpdir(), "glassbox-review-"));
const dbFile = path.join(dir, "existing.db");
process.env.GLASSBOX_DB_PATH = dbFile;

// An "existing" database as the stable branch leaves it, with data in it.
{
  const pre = new Database(dbFile);
  pre.exec(`
    CREATE TABLE exams (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, created_at TEXT NOT NULL);
    CREATE TABLE students (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT UNIQUE, created_at TEXT NOT NULL);
    CREATE TABLE exam_sessions (id INTEGER PRIMARY KEY AUTOINCREMENT, exam_id INTEGER NOT NULL, student_id INTEGER NOT NULL,
      condition TEXT NOT NULL DEFAULT 'UNSPECIFIED', quality TEXT NOT NULL DEFAULT 'PENDING', approved INTEGER NOT NULL DEFAULT 0,
      started_at TEXT NOT NULL, ended_at TEXT, status TEXT NOT NULL DEFAULT 'ACTIVE');
    INSERT INTO exams (title, created_at) VALUES ('old exam', '2026-10-01T08:00:00.000Z');
    INSERT INTO students (name, email, created_at) VALUES ('old', 'old@x', '2026-10-01T08:00:00.000Z');
    INSERT INTO exam_sessions (exam_id, student_id, condition, quality, approved, started_at, ended_at, status)
      VALUES (1, 1, 'NORMAL', 'GOOD', 1, '2026-10-01T08:00:00.000Z', '2026-10-01T08:30:00.000Z', 'COMPLETED');
  `);
  pre.close();
}

const { default: app } = await import("../../server/server.js");
const { default: db } = await import("../../server/database.js");

let server;
let base;

before(async () => {
  server = app.listen(0);
  await new Promise((r) => server.once("listening", r));
  base = `http://127.0.0.1:${server.address().port}/api`;
});

after(() => {
  server.close();
  db.close();
  fs.rmSync(dir, { recursive: true, force: true });
});

const call = async (method, url, body) => {
  const res = await fetch(base + url, { method, headers: { "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
  return { status: res.status, body: await res.json() };
};

async function finishedSession() {
  const exam = await call("POST", "/exams", { title: "t" });
  const student = await call("POST", "/students", { name: "s", email: `s${Math.random()}@x` });
  const s = await call("POST", "/sessions", { examId: exam.body.exam.id, studentId: student.body.student.id, condition: "NORMAL" });
  await call("POST", "/risk", { sessionId: s.body.session.id, timestamp: Date.now(), score: 42, level: "MEDIUM", reasons: [], components: {} });
  await call("POST", `/sessions/${s.body.session.id}/end`);
  return s.body.session.id;
}

test("existing rows survive: the old session is untouched and the new table is added alongside", () => {
  const old = db.prepare("SELECT * FROM exam_sessions WHERE id = 1").get();
  assert.equal(old.condition, "NORMAL");
  assert.equal(old.quality, "GOOD");
  assert.equal(old.approved, 1);
  assert.equal(old.status, "COMPLETED");
  assert.equal(db.prepare("SELECT title FROM exams WHERE id = 1").get().title, "old exam");
  assert.ok(db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='review_decisions'").get());
});

test("the session list reports no decision until one is recorded", async () => {
  const list = await call("GET", "/sessions");
  const old = list.body.sessions.find((s) => s.id === 1);
  assert.equal(old.review_decision, null);
  assert.equal(old.reviewed_at, null);
  assert.equal(old.review_entries, 0);
});

test("invalid requests are rejected and store nothing", async () => {
  const id = await finishedSession();
  for (const body of [{}, { decision: "APPROVED" }, { decision: "NOTE" }, { decision: "NOTE", note: "   " }, { decision: "CLEARED", note: 5 }, { decision: "CLEARED", note: "x".repeat(2001) }]) {
    assert.equal((await call("POST", `/sessions/${id}/decisions`, body)).status, 400, JSON.stringify(body).slice(0, 60));
  }
  assert.equal((await call("POST", "/sessions/999999/decisions", { decision: "CLEARED" })).status, 404);
  assert.equal((await call("GET", `/sessions/${id}`)).body.reviews.length, 0);
});

test("a running session cannot be reviewed yet", async () => {
  const exam = await call("POST", "/exams", { title: "t" });
  const student = await call("POST", "/students", { name: "s", email: `a${Math.random()}@x` });
  const s = await call("POST", "/sessions", { examId: exam.body.exam.id, studentId: student.body.student.id });
  const r = await call("POST", `/sessions/${s.body.session.id}/decisions`, { decision: "CLEARED" });
  assert.equal(r.status, 409);
});

test("decisions are append-only: history keeps every entry, notes do not change the status", async () => {
  const id = await finishedSession();
  const before = db.prepare("SELECT quality, approved, status FROM exam_sessions WHERE id = ?").get(id);
  const risk = db.prepare("SELECT COUNT(*) AS n FROM risk_results WHERE session_id = ?").get(id).n;

  const a = await call("POST", `/sessions/${id}/decisions`, { decision: "CLEARED", note: "  looked fine  " });
  assert.equal(a.status, 201);
  assert.equal(a.body.review.note, "looked fine");

  let row = (await call("GET", "/sessions")).body.sessions.find((s) => s.id === id);
  assert.equal(row.review_decision, "CLEARED");
  assert.ok(row.reviewed_at);

  assert.equal((await call("POST", `/sessions/${id}/decisions`, { decision: "NOTE", note: "second look" })).status, 201);
  row = (await call("GET", "/sessions")).body.sessions.find((s) => s.id === id);
  assert.equal(row.review_decision, "CLEARED", "a note is not a decision");
  assert.equal(row.review_entries, 2);

  assert.equal((await call("POST", `/sessions/${id}/decisions`, { decision: "FOLLOW_UP" })).status, 201);
  row = (await call("GET", "/sessions")).body.sessions.find((s) => s.id === id);
  assert.equal(row.review_decision, "FOLLOW_UP");

  const reviews = (await call("GET", `/sessions/${id}`)).body.reviews;
  assert.deepEqual(reviews.map((r) => [r.decision, r.note]), [["CLEARED", "looked fine"], ["NOTE", "second look"], ["FOLLOW_UP", null]]);
  assert.deepEqual(reviews[0], { ...a.body.review }, "the first entry is unchanged");

  assert.deepEqual(db.prepare("SELECT quality, approved, status FROM exam_sessions WHERE id = ?").get(id), before, "data-collection fields untouched");
  assert.equal(db.prepare("SELECT COUNT(*) AS n FROM risk_results WHERE session_id = ?").get(id).n, risk);
});

test("decisions on one session do not appear on another", async () => {
  const a = await finishedSession();
  const b = await finishedSession();
  await call("POST", `/sessions/${a}/decisions`, { decision: "FOLLOW_UP" });
  const list = (await call("GET", "/sessions")).body.sessions;
  assert.equal(list.find((s) => s.id === b).review_decision, null);
  assert.equal((await call("GET", `/sessions/${b}`)).body.reviews.length, 0);
});
