// Review-priority aid (src/review/reviewPriority.js): parity with the committed s14 scorer, plus edge cases.
import test from "node:test";
import assert from "node:assert/strict";
import fs from "fs";
import { segmentHeadDeviation, reviewFirst } from "../../src/review/reviewPriority.js";

const fixture = JSON.parse(fs.readFileSync(new URL("./fixtures/s14_head_1hz.json", import.meta.url), "utf8"));

test("reproduces s14 head_max_1hz on stored OEP windows (2 subjects)", () => {
  let compared = 0;
  for (const { start, samples, expected } of Object.values(fixture.subjects)) {
    const signals = samples.map((s) => ({ type: "HEAD_POSE_DEVIATION", timestamp: Math.round(s.t * 1000), value: { yaw: s.yaw ?? NaN, pitch: s.pitch ?? NaN, roll: s.roll ?? NaN } }));
    const segs = new Map(segmentHeadDeviation(signals, { startMs: Math.round(start * 1000) }).map((g) => [g.start, g]));
    for (const [t0, want] of expected) {
      const got = segs.get(Math.round(t0 * 1000));
      // No head sample in the window (face absent throughout): s14 scores it 0, the app lists no segment.
      const value = got ? got.maxDeg : 0;
      assert.ok(Math.abs(value - want) < 1e-6, `t0=${t0}: ${value} vs ${want}`);
      compared += 1;
    }
  }
  assert.ok(compared > 100);
});

test("empty, missing and malformed input", () => {
  assert.deepEqual(segmentHeadDeviation([]), []);
  assert.deepEqual(segmentHeadDeviation(null), []);
  assert.deepEqual(segmentHeadDeviation([{ type: "FACE_ABSENT", timestamp: 1 }]), []);
  assert.deepEqual(segmentHeadDeviation([{ type: "HEAD_POSE_DEVIATION", timestamp: 1, value: { yaw: "x" } }]), []);
});

test("single sample, axis reporting and review-first ordering", () => {
  const sig = (t, yaw, pitch, roll) => ({ type: "HEAD_POSE_DEVIATION", timestamp: t, value: { yaw, pitch, roll } });
  const segs = segmentHeadDeviation([sig(0, 2, 1, 0), sig(12000, 3, 25, 1), sig(15000, 30, 2, 1), sig(25000, 4, 4, 9)], { startMs: 0 });
  assert.deepEqual(segs.map((s) => [s.index, s.maxDeg, s.axis, s.samples]), [[0, 2, "yaw", 1], [1, 30, "yaw", 2], [2, 9, "roll", 1]]);
  assert.deepEqual(reviewFirst(segs).map((s) => s.index), [1]);
  assert.deepEqual(reviewFirst(segs, 1).map((s) => s.index), [1, 2, 0]);
});
