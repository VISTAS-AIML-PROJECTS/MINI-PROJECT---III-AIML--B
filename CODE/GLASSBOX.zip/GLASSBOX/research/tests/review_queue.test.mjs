// Review queue logic (src/review/reviewQueue.js): status, ordering, statistics, peak breakdown and evidence timeline.
import test from "node:test";
import assert from "node:assert/strict";
import {
  evidenceTimeline,
  peakBreakdown,
  queueStats,
  reviewStatus,
  sessionSpan,
  sortForReview,
} from "../../src/review/reviewQueue.js";

test("review status: running sessions cannot be pending; notes never change the status", () => {
  assert.equal(reviewStatus({ status: "ACTIVE" }), "IN_PROGRESS");
  assert.equal(reviewStatus({ status: "COMPLETED" }), "PENDING");
  assert.equal(reviewStatus({ status: "INTERRUPTED", review_decision: null }), "PENDING");
  assert.equal(reviewStatus({ status: "COMPLETED", review_decision: "CLEARED" }), "CLEARED");
  assert.equal(reviewStatus({ status: "COMPLETED", review_decision: "FOLLOW_UP" }), "FOLLOW_UP");
  assert.equal(reviewStatus({ status: "ACTIVE", review_decision: "CLEARED" }), "IN_PROGRESS");
});

test("ordering: highest peak first, sessions without an assessment last, ties newest first", () => {
  const order = sortForReview([
    { id: 1, peak_risk: 20 },
    { id: 2, peak_risk: null },
    { id: 3, peak_risk: 80 },
    { id: 4, peak_risk: 20 },
    { id: 5 },
    { id: 6, peak_risk: 0 },
  ]).map((s) => s.id);
  assert.deepEqual(order, [3, 4, 1, 6, 5, 2]);
});

test("statistics are counted from the stored rows, with 'today' in local time", () => {
  const now = new Date(2026, 9, 30, 15, 0, 0);
  const today = new Date(2026, 9, 30, 9, 0, 0).toISOString();
  const yesterday = new Date(2026, 9, 29, 9, 0, 0).toISOString();
  const s = queueStats(
    [
      { id: 1, status: "COMPLETED", started_at: today, peak_risk: 72, review_decision: "CLEARED", reviewed_at: today },
      { id: 2, status: "COMPLETED", started_at: today, peak_risk: 31 },
      { id: 3, status: "ACTIVE", started_at: today, peak_risk: 64 },
      { id: 4, status: "INTERRUPTED", started_at: yesterday, peak_risk: null, review_decision: "FOLLOW_UP", reviewed_at: yesterday },
    ],
    now
  );
  assert.deepEqual(s, { total: 4, sessionsToday: 3, pending: 1, flaggedHigh: 2, reviewedToday: 1 });
  assert.deepEqual(queueStats([], now), { total: 0, sessionsToday: 0, pending: 0, flaggedHigh: 0, reviewedToday: 0 });
});

test("peak breakdown reads the stored channels of the peak row (v2), or labels v1 components", () => {
  const v2 = peakBreakdown([
    { score: 20, level: "LOW", timestamp: 1, details: { channels: { headPoseDeviation: { score: 0.2 } } } },
    { score: 64, level: "HIGH", timestamp: 2, state: "OK", details: { channels: { headPoseDeviation: { score: 0.9 }, faceAbsence: { score: 0.4 }, gazeDeviation: { score: 0 }, focusLoss: { score: 1.4 } } } },
    { score: 64, level: "HIGH", timestamp: 3, details: { channels: {} } },
  ]);
  assert.equal(v2.kind, "v2");
  assert.equal(v2.score, 64);
  assert.equal(v2.timestamp, 2, "first row reaching the peak");
  assert.deepEqual(v2.items.map((i) => [i.key, i.value]), [["headPoseDeviation", 0.9], ["faceAbsence", 0.4], ["gazeDeviation", 0], ["focusLoss", 1]]);

  const v1 = peakBreakdown([{ score: 40, timestamp: 5, components: { faceAbsence: 0.5, multiSignalFusion: 0.3 } }]);
  assert.equal(v1.kind, "v1");
  assert.deepEqual(v1.items.map((i) => i.label), ["Face absence", "Multi-signal fusion (v1)"]);

  assert.equal(peakBreakdown([]), null);
  assert.equal(peakBreakdown([{ score: "x" }]), null);
});

test("timeline: episodes end at their stored timestamp, are clipped to the session, never vanish", () => {
  const start = 1_000_000;
  const end = start + 100_000;
  const segs = evidenceTimeline(
    [
      { id: 1, type: "FACE_ABSENCE_EPISODE", timestamp: start + 30_000, duration_ms: 10_000, strength: 1 },
      { id: 2, type: "FOCUS_LOSS_EPISODE", timestamp: start + 5_000, duration_ms: 20_000 },
      { id: 3, type: "GAZE_DEVIATION_EPISODE", timestamp: start + 50_000, duration_ms: 0 },
      { id: 4, type: "X", timestamp: "bad" },
    ],
    start,
    end
  );
  assert.equal(segs.length, 3);
  assert.ok(Math.abs(segs[0].leftPct - 20) < 1e-9);
  assert.ok(Math.abs(segs[0].widthPct - 10) < 1e-9);
  assert.equal(segs[1].leftPct, 0, "clipped at the session start");
  assert.ok(segs[2].widthPct > 0, "a zero-length episode stays visible");
  assert.deepEqual(evidenceTimeline(segs, 5, 5), []);
});

test("session span uses the end time when stored, otherwise the last stored row", () => {
  const s = { started_at: new Date(1_000_000).toISOString() };
  assert.deepEqual(sessionSpan({ ...s, ended_at: new Date(1_090_000).toISOString() }, [], [], []), { start: 1_000_000, end: 1_090_000 });
  assert.deepEqual(sessionSpan(s, [{ timestamp: 1_050_000 }], [{ timestamp: 1_060_000 }], [{ timestamp: 1_040_000 }]), { start: 1_000_000, end: 1_060_000 });
});
