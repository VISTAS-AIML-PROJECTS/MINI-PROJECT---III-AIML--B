"""Streams the (possibly truncated) OEP tar.gz and lists members; reads only small text files (gt.txt etc.) in memory.
Nothing is extracted to disk. Run with `python -I`."""
import tarfile, sys, json, zlib, io
path = sys.argv[1]
members = []; texts = {}
try:
    with tarfile.open(path, mode="r|gz") as tf:
        for m in tf:
            members.append((m.name, m.size, m.isdir()))
            if m.isfile() and m.size < 20000 and m.name.lower().endswith((".txt", ".csv", ".md", ".xml", ".json")):
                texts[m.name] = tf.extractfile(m).read().decode("utf8", "replace")
except (EOFError, tarfile.ReadError, zlib.error) as e:
    print("stream ended early:", type(e).__name__, e)
print("members read:", len(members))
json.dump(dict(members=members, texts=texts), open(sys.argv[2], "w"))
