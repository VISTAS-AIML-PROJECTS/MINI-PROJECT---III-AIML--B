"""Shared OEP helpers: ground-truth parsing (MMSS) and per-frame MediaPipe feature extraction at STEP-th frames."""
from pathlib import Path
import numpy as np, pandas as pd, cv2
from common import DATA, PROC
from glassbox_vision import Landmarker, extract_gaze_feature, extract_head_pose
EX = DATA / "raw" / "oep_extract"
STEP = 5   # 25 fps video -> 5 fps

def mmss(t):
    t = int(t); return (t // 100) * 60 + t % 100

def load_gt(path):
    iv = []
    for line in Path(path).read_text().splitlines():
        a = line.split()
        if len(a) >= 3: iv.append((mmss(a[0]), mmss(a[1]), int(a[2])))
    return iv

def cache_path(name): return PROC / f"oep_{name}.parquet"

def extract(sub_dir):
    cap = cv2.VideoCapture(str(sub_dir / "webcam.avi")); fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    lmk = Landmarker("IMAGE"); rows = []; i = 0
    while True:
        ok, bgr = cap.read()
        if not ok: break
        if i % STEP == 0:
            out = lmk.detect_rgb(cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)); r = dict(t=i / fps, det=int(out is not None))
            if out is not None:
                lm = out["landmarks"]; g = extract_gaze_feature(lm); h = extract_head_pose(out["matrix"]) if out["matrix"] is not None else None
                r["face_area"] = float((lm[:, 0].max() - lm[:, 0].min()) * (lm[:, 1].max() - lm[:, 1].min()))
                if g and h: r.update(gx=g["gazeX"], gy=g["gazeY"], rx=g["rx"], lx=g["lx"], ry=g["ry"], ly=g["ly"], yaw=h["yaw"], pitch=h["pitch"], roll=h["roll"])
            rows.append(r)
        i += 1
    return pd.DataFrame(rows)
