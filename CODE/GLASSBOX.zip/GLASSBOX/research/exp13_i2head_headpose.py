"""Exp 13 - I2Head replication of the head-pose component validation (NOT cheating validation).
Reads the user-downloaded zips (~/Downloads/user_XX.zip) directly; nothing is extracted. Per image: MediaPipe head pose (app's decomposition)
vs I2Head's magnetic-sensor HP_camera (3 translations + 3 angles; angle order undocumented). Within each session (8 per user) both are
expressed relative to the session median. The GT-axis -> MediaPipe-axis/sign match is chosen on the OTHER user(s) only (cross-fitted),
then MAE / Pearson r are computed on the held-out user. Gaze is NOT evaluated: the mapping from position_index to the 81-point grid
is not documented in the archive."""
import io, re, sys, json, zipfile
from pathlib import Path
import numpy as np, pandas as pd, cv2, scipy.io as sio
from common import RESULTS, PROC
from glassbox_vision import Landmarker, extract_head_pose
AX = ["roll", "yaw", "pitch"]
ZIPS = sorted(Path.home().joinpath("Downloads").glob("user_[0-9][0-9].zip"))
CACHE = PROC / "i2head_mediapipe.parquet"
cached = pd.read_parquet(CACHE) if CACHE.exists() else pd.DataFrame(columns=["user"])
lmk = None; parts = [cached]
for zp in ZIPS:
    u = int(zp.stem.split("_")[1])
    if u in set(cached.user): continue
    lmk = lmk or Landmarker("IMAGE"); z = zipfile.ZipFile(zp); rows = []
    for name in z.namelist():
        m = re.match(rf"user_{u:02d}/([^/]+)/position_index_(\d+)/image_(\d+)/\d+\.png$", name)
        if not m: continue
        hp = sio.loadmat(io.BytesIO(z.read(name.rsplit("/", 1)[0] + f"/HP_camera_{m.group(3)}.mat")))["HP_camera"].ravel()
        img = cv2.imdecode(np.frombuffer(z.read(name), np.uint8), cv2.IMREAD_COLOR)
        out = lmk.detect_rgb(cv2.cvtColor(img, cv2.COLOR_BGR2RGB)); r = dict(user=u, session=m.group(1), pos=int(m.group(2)), img=int(m.group(3)), det=int(out is not None),
                                                                           gt_a1=hp[3], gt_a2=hp[4], gt_a3=hp[5])
        if out is not None and out["matrix"] is not None: r.update({f"mp_{k}": v for k, v in extract_head_pose(out["matrix"]).items() if k in AX})
        rows.append(r)
    f = pd.DataFrame(rows); parts.append(f); print("user", u, len(f), "images, face found", round(f.det.mean(), 4), flush=True)
df = pd.concat(parts, ignore_index=True); df.to_parquet(CACHE)
d = df[df.det == 1].dropna(subset=[f"mp_{a}" for a in AX]).copy()
for c in [f"mp_{a}" for a in AX] + ["gt_a1", "gt_a2", "gt_a3"]: d[c + "_rel"] = d[c] - d.groupby(["user", "session"])[c].transform("median")
users = sorted(d.user.unique()); GT = ["gt_a1", "gt_a2", "gt_a3"]; rows = []
corr = lambda x, y: float(np.corrcoef(x, y)[0, 1])
for u in users:
    fitd = d[d.user != u] if len(users) > 1 else d; test = d[d.user == u]
    for g in GT:
        best = max(AX, key=lambda a: abs(corr(fitd[g + "_rel"], fitd[f"mp_{a}_rel"]))); sg = np.sign(corr(fitd[g + "_rel"], fitd[f"mp_{best}_rel"]))
        e = sg * test[f"mp_{best}_rel"] - test[g + "_rel"]
        rows.append(dict(user=u, gt_axis=g, mp_axis=best, sign=int(sg), mae_deg=float(e.abs().mean()), r=corr(test[g + "_rel"], sg * test[f"mp_{best}_rel"]),
                         gt_sd_deg=float(test[g + "_rel"].std()), n=len(test), cross_fitted=len(users) > 1))
T = pd.DataFrame(rows); T.to_csv(RESULTS / "exp13_i2head_headpose.csv", index=False)
json.dump(dict(users=[int(x) for x in users], images=int(len(df)), face_found=float(df.det.mean())), open(RESULTS / "exp13_i2head_meta.json", "w"), indent=1)
print(T.round(3).to_string(index=False))
