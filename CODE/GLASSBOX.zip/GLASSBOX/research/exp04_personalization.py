"""Exp 04 - Personalised vs non-personalised normalisation of MediaPipe gaze features (MPIIFaceGaze, 15 subjects).

Targets (oracle, from MPIIFaceGaze 3-D gaze annotations, camera frame):
  H : |h - mean_s(h)|      horizontal gaze-angle deviation from the subject's own mean   (deg)
  V : |v - mean_s(v)|      vertical gaze-angle deviation                                  (deg)
  A : angle(g, mean_s(g))  total angular deviation                                      (deg)
Positive = top 25 % of the pooled target over evaluation frames.

Scores computed from MediaPipe only (the signals GlassBox has):
  zx = |gx-mu|/sd ; zy = |gy-mu|/sd ; z = hypot(zx, zy)  (the app's GAZE_DEVIATION)
  with reference (mu, sd) =
    raw        : mu = 0.5 (iris centred), sd = 1 (no baseline at all)
    population : mean/sd of the 14 OTHER subjects (leave-one-subject-out)
    personal-K : mean/sd of the subject's first K usable frames (calibration), K in {10,30,100,300}
    personal-mean-only-K : personal mean, population sd
Learned alternative (HistGradientBoosting on [gx,gy,rx,lx,ry,ly,yaw,pitch,roll]) regressing the target:
    gbm_population : trained on other subjects only (LOSO)
    gbm_personal   : same + features centred on the subject's first-100-frame mean (few-shot calibration)
Evaluation uses frames with chronological index >= 300 only, identical for every method; calibration
frames never enter evaluation. Uncertainty: subject-level bootstrap (2000 resamples) of mean within-subject AUROC
and of the paired difference to the population baseline.
"""
import json, warnings
import numpy as np, pandas as pd, cv2
from sklearn.metrics import roc_auc_score
from sklearn.ensemble import HistGradientBoostingRegressor
from common import PROC, RESULTS, SEED
warnings.filterwarnings("ignore")

KS = [10, 30, 100, 300]; KMAX = 300; Q = 0.25
FEAT = ["gx", "gy", "rx", "lx", "ry", "ly", "yaw", "pitch", "roll"]
df = pd.read_parquet(PROC / "mpii_features.parquet")
n_all = len(df); df = df[(df.det == 1) & df.gx.notna() & df.yaw.notna()].copy()
df = df.sort_values(["subject", "order"]).reset_index(drop=True)
df["rank"] = df.groupby("subject").cumcount()
print(f"frames {n_all}, usable {len(df)}")

unit = lambda v: v / np.linalg.norm(v, axis=1, keepdims=True)
g = unit(df[["gt_x", "gt_y", "gt_z"]].values - df[["fc_x", "fc_y", "fc_z"]].values)
df["h"] = np.degrees(np.arctan2(g[:, 0], -g[:, 2])); df["v"] = np.degrees(np.arcsin(np.clip(g[:, 1], -1, 1)))
for s, idx in df.groupby("subject").indices.items():
    m = g[idx].mean(0); m /= np.linalg.norm(m)
    df.loc[idx, "T_A"] = np.degrees(np.arccos(np.clip(g[idx] @ m, -1, 1)))
    df.loc[idx, "T_H"] = np.abs(df.loc[idx, "h"] - df.loc[idx, "h"].mean())
    df.loc[idx, "T_V"] = np.abs(df.loc[idx, "v"] - df.loc[idx, "v"].mean())
subjects = sorted(df.subject.unique())
EV = df["rank"] >= KMAX
thr = {t: float(df.loc[EV, t].quantile(1 - Q)) for t in ("T_H", "T_V", "T_A")}
print("positive thresholds (deg):", {k: round(v, 2) for k, v in thr.items()})

def zs(sub, mu, sd, axis):
    zx = np.abs(sub.gx.values - mu[0]) / sd[0]; zy = np.abs(sub.gy.values - mu[1]) / sd[1]
    return {"x": zx, "y": zy, "c": np.hypot(zx, zy)}[axis]

def scores_for(s, axis):
    sub = df[df.subject == s]; ev = sub[sub["rank"] >= KMAX]
    oth = df[df.subject != s]
    pm = (oth.gx.mean(), oth.gy.mean()); ps = (oth.gx.std(), oth.gy.std())
    out = {"raw": zs(ev, (0.5, 0.5), (1, 1), axis), "population": zs(ev, pm, ps, axis)}
    for k in KS:
        cal = sub.iloc[:k]
        mu = (cal.gx.mean(), cal.gy.mean()); sd = (max(cal.gx.std(), 1e-3), max(cal.gy.std(), 1e-3))
        out[f"personal_K{k}"] = zs(ev, mu, sd, axis)
        out[f"personal_meanonly_K{k}"] = zs(ev, mu, ps, axis)
    return ev, out

def gbm_scores(s, target):
    sub = df[df.subject == s]; ev = sub[sub["rank"] >= KMAX]; oth = df[df.subject != s]
    m = HistGradientBoostingRegressor(max_iter=150, learning_rate=0.08, random_state=SEED).fit(oth[FEAT], oth[target])
    out = {"gbm_population": m.predict(ev[FEAT])}
    # personal: append features centred on the subject's own first-100 mean (and train the same way on other subjects)
    def centred(frame_sub, cal_n=100):
        cm = frame_sub.iloc[:cal_n][FEAT].mean()
        return pd.concat([frame_sub[FEAT], (frame_sub[FEAT] - cm).add_suffix("_c")], axis=1)
    Xtr = pd.concat([centred(df[df.subject == o]).iloc[KMAX:] for o in subjects if o != s])
    ytr = pd.concat([df[df.subject == o][target].iloc[KMAX:] for o in subjects if o != s])
    mp = HistGradientBoostingRegressor(max_iter=150, learning_rate=0.08, random_state=SEED).fit(Xtr, ytr)
    out["gbm_personal"] = mp.predict(centred(sub).iloc[KMAX:])
    return out

rng = np.random.default_rng(SEED)
rows = []
for tname, axes in (("T_H", ["x", "c"]), ("T_V", ["y", "c"]), ("T_A", ["c", "x"])):
    per = {}; pooled_parts = {}
    ys = {}
    for s in subjects:
        ev, sc = scores_for(s, axes[0])
        sc.update(gbm_scores(s, tname))
        y = (ev[tname] > thr[tname]).astype(int).values; ys[s] = y
        for m_, v in sc.items():
            pooled_parts.setdefault(m_, []).append(v)
            if y.min() != y.max(): per.setdefault(m_, {})[s] = roc_auc_score(y, v)
    yall = np.concatenate([ys[s] for s in subjects])
    ids_ok = sorted(per["population"].keys())
    boot = []
    for _ in range(2000):
        pick = rng.choice(ids_ok, len(ids_ok))
        boot.append({m_: np.mean([per[m_][i] for i in pick]) for m_ in per})
    B = pd.DataFrame(boot)
    for m_ in per:
        wa = np.mean([per[m_][i] for i in ids_ok]); d = B[m_] - B["population"]
        rows.append(dict(target=tname, score_axis=axes[0] if not m_.startswith("gbm") else "learned", method=m_,
                         within_subject_auc=wa, auc_lo=B[m_].quantile(.025), auc_hi=B[m_].quantile(.975),
                         pooled_auc=roc_auc_score(yall, np.concatenate(pooled_parts[m_])),
                         diff_vs_population=wa - np.mean([per["population"][i] for i in ids_ok]),
                         diff_lo=d.quantile(.025), diff_hi=d.quantile(.975),
                         diff_vs_gbm_population=(wa - np.mean([per["gbm_population"][i] for i in ids_ok])) if m_ == "gbm_personal" else np.nan,
                         gbm_diff_lo=(B["gbm_personal"] - B["gbm_population"]).quantile(.025) if m_ == "gbm_personal" else np.nan,
                         gbm_diff_hi=(B["gbm_personal"] - B["gbm_population"]).quantile(.975) if m_ == "gbm_personal" else np.nan))
    # also the combined-z (app) variant for the axis-specific targets, so the cost of gy is explicit
T = pd.DataFrame(rows)
T.to_csv(RESULTS / "exp04_personalization.csv", index=False)
json.dump(dict(thresholds_deg=thr, n_eval=int(EV.sum()), n_subjects=len(subjects), pos_rate=Q, K=KS, KMAX=KMAX),
          open(RESULTS / "exp04_meta.json", "w"), indent=1)
pd.set_option("display.width", 250); pd.set_option("display.max_rows", 200)
print(T.round(3).to_string(index=False))
