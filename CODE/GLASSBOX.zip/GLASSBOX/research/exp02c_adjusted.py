"""Exp 02c - Adjusted per-group detection gaps (logistic regression on race + gender + age), per variant/condition.
Reports the largest adjusted odds ratio vs. the most-detected reference group and the raw max-min gap with
Wilson/bootstrap-free simple SEs. Observational: FairFace images differ in source quality, pose, occlusion,
glasses, beards and expression, so gaps are NOT attributable to skin tone alone."""
import json
import numpy as np, pandas as pd
import statsmodels.formula.api as smf
from common import RESULTS
out = []
for variant in ("pad025", "pad125"):
    r = pd.read_csv(RESULTS / f"exp02_fairface_{variant}_per_image.csv")
    for cond in ("native", "dark"):
        r["y"] = r[f"{cond}_det"]
        m = smf.logit("y ~ C(race, Treatment('White')) + C(gender, Treatment('Male')) + C(age, Treatment('20-29'))", r).fit(disp=0)
        ci = m.conf_int(); orr = np.exp(m.params)
        for k in m.params.index[1:]:
            out.append(dict(variant=variant, condition=cond, term=k.replace("C(", "").replace(", Treatment(", "|ref=").replace("))", ")"),
                           odds_ratio=float(orr[k]), lo=float(np.exp(ci.loc[k, 0])), hi=float(np.exp(ci.loc[k, 1])), p=float(m.pvalues[k])))
        raw = r.groupby("race").y.mean()
        out.append(dict(variant=variant, condition=cond, term="RAW race max-min gap (pp)", odds_ratio=float((raw.max() - raw.min()) * 100),
                        lo=np.nan, hi=np.nan, p=np.nan))
D = pd.DataFrame(out); D.to_csv(RESULTS / "exp02c_adjusted.csv", index=False)
pd.set_option("display.width", 220); print(D.round(3).to_string())

# ---- low-light degradation per race: paired drop (native - dark), bootstrap CI, and difference vs all other groups
rng = np.random.default_rng(20261021); rows = []
for variant in ("pad025", "pad125"):
    r = pd.read_csv(RESULTS / f"exp02_fairface_{variant}_per_image.csv"); r["drop"] = r.native_det - r.dark_det
    for g, sub in r.groupby("race"):
        rest = r[r.race != g]
        bs = [ (rng.choice(sub["drop"].values, len(sub)).mean() - rng.choice(rest["drop"].values, len(rest)).mean()) * 100 for _ in range(2000)]
        rows.append(dict(variant=variant, race=g, n=len(sub), drop_pp=sub["drop"].mean() * 100,
                         drop_minus_rest_pp=(sub["drop"].mean() - rest["drop"].mean()) * 100,
                         lo=float(np.percentile(bs, 2.5)), hi=float(np.percentile(bs, 97.5)),
                         lo_bonf7=float(np.percentile(bs, 100 * 0.025 / 7)), hi_bonf7=float(np.percentile(bs, 100 - 100 * 0.025 / 7))))
Dr = pd.DataFrame(rows); Dr.to_csv(RESULTS / "exp02c_lowlight_drop.csv", index=False); print(Dr.round(2).to_string(index=False))
