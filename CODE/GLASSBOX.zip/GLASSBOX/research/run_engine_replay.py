"""Regenerates results/engine_replay.json: replays synthetic calm / look-away users through the Evidence->Fusion->Risk chain of
the baseline commit (76ea544, extracted with `git archive`) and of the working tree. Requires git, tar and node."""
import json, subprocess, tempfile, sys
from pathlib import Path
root = Path(__file__).resolve().parent.parent
BASE = "76ea544"
with tempfile.TemporaryDirectory() as tmp:
    arc = subprocess.run(["git", "archive", BASE, "src"], cwd=root, check=True, capture_output=True).stdout
    subprocess.run(["tar", "-x", "-C", tmp], input=arc, check=True)
    (Path(tmp) / "package.json").write_text('{"type":"module"}')
    def run(src):
        out = subprocess.run(["node", str(root / "research" / "tests" / "engine_replay.mjs"), str(src)], check=True, capture_output=True, text=True).stdout
        return json.loads(out)
    res = {f"legacy_{BASE}": run(Path(tmp) / "src"), "fixed": run(root / "src")}
(root / "research" / "results" / "engine_replay.json").write_text(json.dumps(res, indent=1))
for k, v in res.items(): print(k, {s: (v[s]["max_risk"]["mean"], v[s]["final_risk"]["mean"]) for s in v})

# robustness: calm user whose natural variability exceeds the calibration SD by a factor (fixed engines only)
import os
rob = {}
for sd in (1.0, 1.5, 2.0, 3.0):
    env = dict(os.environ, CALM_SD=str(sd))
    out = json.loads(subprocess.run(["node", str(root / "research" / "tests" / "engine_replay.mjs"), str(root / "src")], check=True, capture_output=True, text=True, env=env).stdout)
    rob[str(sd)] = {s_: out[s_]["max_risk"] for s_ in out}
(root / "research" / "results" / "engine_robustness.json").write_text(json.dumps(rob, indent=1))
for k, v in rob.items(): print("calm SD x", k, "peak risk calm", v["calm"]["mean"], "| glance", v["glance"]["mean"])
