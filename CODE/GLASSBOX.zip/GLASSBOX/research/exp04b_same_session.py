"""Exp 04b - Same-session calibration (deployment-faithful) vs population baseline on MPIIFaceGaze.

Exp 04 calibrates on a subject's first 300 frames, which span 2-12 *different days* (chronological file order) and
share a day with only 0.1-40 % of the evaluation frames, i.e. a stale, cross-session baseline. The GlassBox app instead
calibrates immediately before the exam. Here, for every (subject, day) session with >= 50 frames, the first K frames of
THAT session are the calibration set and the session's remaining frames (day_rank >= 30) are evaluated, identically for
all K and all methods. Target and positive threshold as exp04 (horizontal deviation T_H, top 25 % pooled over eval frames).
Subject-level bootstrap (2000) of mean within-subject AUROC; paired differences vs the population baseline."""
import warnings
import numpy as np, pandas as pd
from sklearn.metrics import roc_auc_score
from sklearn.ensemble import HistGradientBoostingRegressor
from common import RESULTS, SEED
from mpii_common import load
warnings.filterwarnings("ignore")
KS = [10, 20, 30]; KEV = 30; MIN_FRAMES = 50
FEAT = ["gx", "gy", "rx", "lx", "ry", "ly", "yaw", "pitch", "roll"]
df = load(); subjects = sorted(df.subject.unique())
sess_n = df.groupby(["subject", "day"]).day_rank.transform("max") + 1
df = df[sess_n >= MIN_FRAMES].copy()
ev_all = df[df.day_rank >= KEV]
thr = ev_all.T_H.quantile(0.75)
print(f"sessions: {df.groupby(['subject','day']).ngroups}, eval frames {len(ev_all)}, thr {thr:.2f} deg")

def centred(frame, K=30):
    out = []
    for _, g in frame.groupby(["subject", "day"], sort=False):
        cm = g.iloc[:K][FEAT].mean()
        out.append(pd.concat([g[FEAT], (g[FEAT] - cm).add_suffix("_c")], axis=1))
    return pd.concat(out)
C = centred(df)
rng = np.random.default_rng(SEED); per = {}
for s in subjects:
    sub = df[df.subject == s]; oth = df[df.subject != s]
    if len(sub) == 0: continue
    ev = sub[sub.day_rank >= KEV]; y = (ev.T_H > thr).astype(int).values
    if y.min() == y.max(): continue
    sc = {"raw": np.abs(ev.gx.values - 0.5), "population": np.abs(ev.gx.values - oth.gx.mean()) / oth.gx.std()}
    for K in KS:
        z = np.zeros(len(ev)); pos = 0
        for day, g in sub.groupby("day", sort=False):
            m = g.iloc[:K].gx.mean(); sd = max(g.iloc[:K].gx.std(), 1e-3)
            e = g[g.day_rank >= KEV]; z[pos:pos + len(e)] = np.abs(e.gx.values - m) / sd; pos += len(e)
        sc[f"personal_session_K{K}"] = z
        zm = np.zeros(len(ev)); pos = 0
        for day, g in sub.groupby("day", sort=False):
            m = g.iloc[:K].gx.mean(); e = g[g.day_rank >= KEV]; zm[pos:pos + len(e)] = np.abs(e.gx.values - m) / oth.gx.std(); pos += len(e)
        sc[f"personal_session_meanonly_K{K}"] = zm
    # learned: population vs same-session centring (K=30)
    otr = oth[oth.day_rank >= KEV]
    m0 = HistGradientBoostingRegressor(max_iter=150, learning_rate=0.08, random_state=SEED).fit(otr[FEAT], otr.T_H)
    sc["gbm_population"] = m0.predict(ev[FEAT])
    Xo = C.loc[otr.index]; m1 = HistGradientBoostingRegressor(max_iter=150, learning_rate=0.08, random_state=SEED).fit(Xo, otr.T_H)
    sc["gbm_session_centred_K30"] = m1.predict(C.loc[ev.index])
    for k, v in sc.items(): per.setdefault(k, {})[s] = roc_auc_score(y, v)
ids = sorted(per["population"]); B = []
for _ in range(2000):
    pick = rng.choice(ids, len(ids)); B.append({k: np.mean([per[k][i] for i in pick]) for k in per})
B = pd.DataFrame(B); rows = []
for k in per:
    wa = np.mean([per[k][i] for i in ids]); d = B[k] - B["population"]
    rows.append(dict(method=k, n_subjects=len(ids), within_subject_auc=wa, auc_lo=B[k].quantile(.025), auc_hi=B[k].quantile(.975),
                     diff_vs_population=wa - np.mean([per["population"][i] for i in ids]), diff_lo=d.quantile(.025), diff_hi=d.quantile(.975),
                     diff_vs_gbm_population=(wa - np.mean([per['gbm_population'][i] for i in ids])) if k == 'gbm_session_centred_K30' else np.nan,
                     gbm_diff_lo=(B[k] - B['gbm_population']).quantile(.025) if k == 'gbm_session_centred_K30' else np.nan,
                     gbm_diff_hi=(B[k] - B['gbm_population']).quantile(.975) if k == 'gbm_session_centred_K30' else np.nan))
T = pd.DataFrame(rows); T.to_csv(RESULTS / "exp04b_same_session.csv", index=False)
pd.set_option("display.width", 200); print(T.round(3).to_string(index=False))
