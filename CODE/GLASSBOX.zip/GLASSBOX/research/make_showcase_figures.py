"""Builds docs/project_showcase/figures/*.png strictly from saved results in research/results/ (no recomputation, no simulated data).
    python research/make_showcase_figures.py"""
import json, shutil
from pathlib import Path
import numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent.parent; R = ROOT / "research" / "results"; OUT = ROOT / "docs" / "project_showcase" / "figures"; OUT.mkdir(parents=True, exist_ok=True)
BLUE, ORANGE, MUTED, INK, SURF, GREY = "#2a78d6", "#eb6834", "#52514e", "#0b0b0b", "#fcfcfb", "#9a9a94"
plt.rcParams.update({"figure.facecolor": SURF, "axes.facecolor": SURF, "savefig.facecolor": SURF, "text.color": INK, "axes.labelcolor": MUTED,
                     "xtick.color": MUTED, "ytick.color": MUTED, "font.size": 10, "axes.spines.top": False, "axes.spines.right": False, "axes.edgecolor": "#c3c2b7"})
def save(fig, name): fig.tight_layout(rect=(0, 0, 1, 0.93)); fig.savefig(OUT / name, dpi=170); plt.close(fig); print("saved", name)

# 1. gaze estimator vs previous signal (exp09): within-subject AUROC with 95% subject-bootstrap CI
x9 = pd.read_csv(R / "exp09_linear_gaze.csv"); g = lambda p, m: x9[(x9.protocol == p) & (x9.method == m) & (x9.ref == "zx_population")].iloc[0]
fig, ax = plt.subplots(figsize=(7.2, 3.6)); ys = {"Cross-session calibration (K=100)": "cross", "Same-session calibration (K=30)": "same"}
for i, (lab, p) in enumerate(ys.items()):
    for j, (m, col, nm) in enumerate((("zx_personal", GREY, "previous iris-ratio signal"), ("lin_personal", BLUE, "new gaze-angle estimator"))):
        r = g(p, m); y = i + (0.14 if j else -0.14)
        ax.errorbar(r.within_subject_auc, y, xerr=[[r.within_subject_auc - r.auc_lo], [r.auc_hi - r.within_subject_auc]], fmt="o", color=col, capsize=3, label=nm if i == 0 else None)
        ax.text(r.auc_hi + 0.004, y, f"{r.within_subject_auc:.3f}", va="center", fontsize=9)
ax.set_yticks(range(2), list(ys)); ax.invert_yaxis(); ax.set_xlim(0.72, 0.95); ax.set_xlabel("within-subject AUROC (95% CI, 15 held-out subjects)")
ax.set_ylim(1.55, -0.55); ax.legend(frameon=False, loc="upper center", bbox_to_anchor=(0.5, -0.2), ncol=2, fontsize=9); fig.suptitle("Gaze estimator: improvement over the previous signal on held-out subjects", x=0.01, ha="left", fontsize=11); save(fig, "gaze_estimator_vs_previous.png")

# 2. head pose vs sensor ground truth (exp11)
u = pd.read_csv(R / "exp11_upna_headpose.csv"); u = u[u.estimator.str.startswith("fixed")]
fig, ax = plt.subplots(figsize=(7.2, 3.6)); axes = ["roll", "yaw", "pitch"]
for j, (sc, col, nm) in enumerate((("guided", BLUE, "guided single-axis rotations"), ("free", ORANGE, "free movement"))):
    for i, a in enumerate(axes):
        r = u[(u.gt_axis == a) & u.scope.str.startswith(sc)].iloc[0]; x = i + (0.12 if j else -0.12)
        ax.errorbar(x, r.mae_deg, yerr=[[r.mae_deg - r.mae_lo], [r.mae_hi - r.mae_deg]], fmt="o", color=col, capsize=3, label=nm if i == 0 else None)
        ax.text(x + 0.07, r.mae_deg, f"{r.mae_deg:.2f}", va="center", fontsize=9)
ax.set_xticks(range(3), [a.capitalize() for a in axes]); ax.set_ylabel("mean absolute error (degrees, 95% CI)"); ax.set_ylim(0, 1.6); ax.legend(frameon=False, fontsize=9, loc="upper left")
fig.suptitle("Head pose vs magnetic-sensor ground truth (UPNA, 10 users, relative rotation)", x=0.01, ha="left", fontsize=11); save(fig, "head_pose_error_upna.png")

# 3. OEP window-level comparison (exp14): forest plot against chance
e = pd.read_csv(R / "exp14_oep_improvements.csv").set_index("name")
rows = [("GlassBox engine (rule-based, real JS replay)", "engine risk (window max, real JS engines)", GREY), ("Logistic regression (LR) + temporal + extra signals", "LR (C by inner CV) | v1+extras+temporal", BLUE),
        ("Random forest, same features", "random forest | v1+extras+temporal", BLUE), ("Gradient boosting, same features", "gradient boosting | v1+extras+temporal", BLUE),
        ("Max head deviation heuristic (exploratory)", "heuristic: max head deviation / 30deg", ORANGE)]
fig, ax = plt.subplots(figsize=(7.6, 3.8))
for i, (lab, key, col) in enumerate(rows):
    r = e.loc[key]; ax.errorbar(r.auroc, i, xerr=[[r.auroc - r.auroc_lo], [r.auroc_hi - r.auroc]], fmt="o", color=col, capsize=3); ax.text(r.auroc_hi + 0.006, i, f"{r.auroc:.3f}", va="center", fontsize=9)
ax.axvline(0.5, color=MUTED, ls="--", lw=1); ax.text(0.502, -0.62, "chance", color=MUTED, fontsize=8)
ax.set_yticks(range(len(rows)), [r[0] for r in rows]); ax.invert_yaxis(); ax.set_xlim(0.38, 0.74); ax.set_xlabel("window-level AUROC (95% CI; 24 held-out subjects, 1,956 windows)")
fig.suptitle("OEP: webcam-derived signals vs annotated cheating intervals (leave-one-subject-out)", x=0.01, ha="left", fontsize=11); save(fig, "oep_window_auroc.png")

# 4. engine audit: synthetic regression test (clearly labelled)
rep = json.load(open(R / "engine_replay.json")); leg = rep[[k for k in rep if k.startswith("legacy")][0]]; fix = rep["fixed"]
fig, ax = plt.subplots(figsize=(7.2, 3.6)); w = 0.34
for i, (lab, d) in enumerate((("baseline commit 76ea544", leg), ("after audit fixes", fix))):
    for j, (sc, col, nm) in enumerate((("calm", BLUE, "calm synthetic user"), ("glance", ORANGE, "five 4-s look-aways"))):
        m = d[sc]["max_risk"]; x = i + (j - 0.5) * w
        ax.bar(x, m["mean"], w - 0.04, color=col, label=nm if i == 0 else None); ax.errorbar(x, m["mean"], yerr=[[m["mean"] - m["min"]], [m["max"] - m["mean"]]], color=INK, capsize=3, lw=1)
        ax.text(x, m["max"] + 1.2, f"{m['mean']:.1f}", ha="center", fontsize=9)
ax.set_xticks(range(2), ["baseline commit 76ea544", "after audit fixes"]); ax.set_ylabel("peak risk (mean, min-max)"); ax.set_ylim(0, 50); ax.legend(frameon=False, fontsize=9, loc="upper left")
fig.suptitle("Scoring-engine audit: synthetic regression test (not a validation)", x=0.01, ha="left", fontsize=11); save(fig, "engine_audit_synthetic.png")

# 5. copy existing research figures (already generated from saved outputs)
for f in ("fig1_leakage.png", "fig3_fairface.png", "fig4_same_session.png"):
    shutil.copy(ROOT / "docs" / "figures" / f, OUT / {"fig1_leakage.png": "evaluation_leakage_mendeley.png", "fig3_fairface.png": "fairface_detection_by_group.png", "fig4_same_session.png": "calibration_same_session.png"}[f])
print("done")
