"""Exp 01 - Suspicious-behaviour classification on the Mendeley proctoring-feature dataset
(Students suspicious behaviors detection dataset, CC BY 4.0, doi:10.17632/39xs8th543.1).

Purpose: quantify (a) how much of the headline accuracy comes from label-correlated /
leaky columns, and (b) how much optimistic bias random k-fold adds vs a temporally
blocked split, because the dataset has no subject IDs and rows are consecutive snapshots.
"""
import json, warnings
import numpy as np, pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.dummy import DummyClassifier
from sklearn.metrics import roc_auc_score, balanced_accuracy_score, f1_score
from common import RAW, RESULTS, SEED, block_bootstrap_ci

warnings.filterwarnings("ignore")
df = pd.read_csv(RAW / "mendeley_susp" / "susp.csv")
y = df["label"].values
n = len(df)

# --- feature engineering: categoricals -> ordinal/one-hot; explicit missing indicators
X = df.drop(columns=["label"]).copy()
X["head_pose_missing"] = X["head_pose"].isna().astype(int)
X["gaze_dir_missing"] = X["gaze_direction"].isna().astype(int)
for side in ("left", "right"):
    k = side[0]
    X[f"pupil_off_{k}x"] = X[f"pupil_{side}_x"] - X[f"{side}_eye_x"]
    X[f"pupil_off_{k}y"] = X[f"pupil_{side}_y"] - X[f"{side}_eye_y"]
X = pd.get_dummies(X, columns=["head_pose", "gaze_direction"], dummy_na=False, dtype=float)

OBJECT_COLS = [c for c in X.columns if c.startswith(("phone_", "hand_", "left_hand", "right_hand"))]
DERIVED = [c for c in X.columns if c.startswith("pupil_off_")]
GAZE_COLS = [c for c in X.columns if c.startswith(("gaze", "pupil_")) and c != "gaze_dir_missing" and c not in DERIVED]
HEADANG = ["head_pitch", "head_yaw", "head_roll"]
FACE = ["face_present", "no_of_face", "face_conf"]
sets = {
    "all_37": [c for c in X.columns if c not in DERIVED],
    "no_object_cues": [c for c in X.columns if c not in OBJECT_COLS and c not in DERIVED],
    # NOTE: includes the dataset's own scenario-aware gaze outputs (gaze_on_script, gaze_direction_*, gazePoint_*),
    # which GlassBox cannot compute (it has no notion of the exam-script region) -> optimistic upper bound
    "gaze_incl_script_flags": FACE + HEADANG + GAZE_COLS + ["gaze_dir_missing"],
    # strict: only quantities derivable from MediaPipe landmarks/pose without scenario knowledge:
    # face presence/count, head angles, and iris(pupil) offset relative to the eye corner-point (g_x/g_y analogue)
    "glassbox_strict": ["face_present", "no_of_face"] + HEADANG + ["pupil_off_lx", "pupil_off_ly", "pupil_off_rx", "pupil_off_ry"],
}

def models():
    return {
        "majority": DummyClassifier(strategy="prior"),
        "logreg": make_pipeline(SimpleImputer(strategy="median"), StandardScaler(),
                                LogisticRegression(max_iter=2000, C=1.0)),
        "random_forest": make_pipeline(SimpleImputer(strategy="median"),
                                       RandomForestClassifier(300, min_samples_leaf=3, n_jobs=-1, random_state=SEED)),
        "hist_gb": HistGradientBoostingClassifier(max_iter=200, learning_rate=0.05, random_state=SEED),
    }

def splits(kind, k=5, gap=50):
    if kind == "random":
        yield from StratifiedKFold(k, shuffle=True, random_state=SEED).split(np.zeros(n), y)
    else:  # contiguous blocks, with a purge gap on each side of the test block
        edges = np.linspace(0, n, k + 1).astype(int)
        for a, b in zip(edges[:-1], edges[1:]):
            te = np.arange(a, b)
            tr = np.r_[np.arange(0, max(a - gap, 0)), np.arange(min(b + gap, n), n)]
            yield tr, te

def rule_baseline():
    """Transparent rule in the spirit of GlassBox: face absent OR gaze off-script OR head not frontal."""
    off = (df.face_present == 0) | (df.gaze_on_script == 0) | (df.head_pose.fillna("forward") != "forward")
    return off.astype(float).values

rows = []
for split in ("random", "blocked"):
    for fs_name, cols in sets.items():
        for m_name, _ in models().items():
            oof = np.full(n, np.nan); oof_pred = np.zeros(n)
            for tr, te in splits(split):
                mdl = models()[m_name]
                mdl.fit(X.iloc[tr][cols], y[tr])
                # leakage diagnostics are computed separately below
                oof[te] = mdl.predict_proba(X.iloc[te][cols])[:, 1]
            ok = ~np.isnan(oof)
            pred = (oof[ok] >= 0.5).astype(int)
            auc = roc_auc_score(y[ok], oof[ok]) if m_name != "majority" else 0.5
            lo, hi = block_bootstrap_ci(lambda a, b: roc_auc_score(a, b), y[ok], oof[ok], 100) if m_name != "majority" else (0.5, 0.5)
            rows.append(dict(split=split, features=fs_name, model=m_name, n_features=len(cols), n_eval=int(ok.sum()),
                             auroc=auc, auroc_lo=lo, auroc_hi=hi,
                             bal_acc=(balanced_accuracy_score(y[ok], pred) if m_name != 'majority' else 0.5), f1=(f1_score(y[ok], pred) if m_name != 'majority' else 0.0)))
            print(rows[-1], flush=True)

rb = rule_baseline()
rule = dict(split="n/a", features="rule(face|gaze|head)", model="rule", auroc=roc_auc_score(y, rb),
            bal_acc=balanced_accuracy_score(y, rb.astype(int)), f1=f1_score(y, rb.astype(int)))
print(rule)
out = pd.DataFrame(rows)
out.to_csv(RESULTS / "exp01_susp_classification.csv", index=False)
json.dump(dict(rows=rows, rule_baseline=rule, n=n, pos_rate=float(y.mean())), open(RESULTS / "exp01_susp_classification.json", "w"), indent=1)

# ---- leakage diagnostics: how close is each test row to its nearest training row?
from sklearn.neighbors import NearestNeighbors
cols = sets["glassbox_strict"]; Z = StandardScaler().fit_transform(SimpleImputer(strategy="median").fit_transform(X[cols]))
diag = {}
for split in ("random", "blocked"):
    d_nn = []; dup = 0
    for tr, te in splits(split):
        nn = NearestNeighbors(n_neighbors=1).fit(Z[tr]); dist = nn.kneighbors(Z[te])[0][:, 0]; d_nn.extend(dist)
        trs = set(map(tuple, np.round(Z[tr], 6))); dup += sum(tuple(r) in trs for r in np.round(Z[te], 6))
    diag[split] = dict(median_nn_dist=float(np.median(d_nn)), p90_nn_dist=float(np.percentile(d_nn, 90)), test_rows_with_exact_dup_in_train=int(dup))
print(diag)
json.dump(diag, open(RESULTS / "exp01_leakage_nn.json", "w"), indent=1)
