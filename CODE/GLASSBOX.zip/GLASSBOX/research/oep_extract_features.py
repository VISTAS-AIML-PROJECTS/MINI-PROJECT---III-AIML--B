"""Extracts per-frame MediaPipe features for the given OEP subjects (numbers) into data/processed/oep_subjectN.parquet.
Usage: python research/oep_extract_features.py 1 2 3     (run several in parallel on disjoint subject lists)"""
import sys
from oep_common import EX, cache_path, extract
for n in sys.argv[1:]:
    d = EX / f"subject{n}"; cp = cache_path(f"subject{n}")
    if cp.exists(): print("cached", n, flush=True); continue
    f = extract(d); f.to_parquet(cp); print("done", n, len(f), "frames, face found", round(f.det.mean(), 3), flush=True)
