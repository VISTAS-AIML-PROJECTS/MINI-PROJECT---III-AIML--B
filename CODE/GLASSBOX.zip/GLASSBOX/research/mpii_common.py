"""Loads cached MPIIFaceGaze MediaPipe features and derives the oracle gaze targets used in exp04/exp06."""
import numpy as np, pandas as pd
from common import PROC
KMAX = 300

def load():
    df = pd.read_parquet(PROC / "mpii_features.parquet")
    df = df[(df.det == 1) & df.gx.notna() & df.yaw.notna()].copy()
    df = df.sort_values(["subject", "order"]).reset_index(drop=True)
    df["rank"] = df.groupby("subject").cumcount()
    df["day"] = df.frame.str.split("/").str[0]
    df["day_rank"] = df.groupby(["subject", "day"]).cumcount()
    g = df[["gt_x", "gt_y", "gt_z"]].values - df[["fc_x", "fc_y", "fc_z"]].values
    g = g / np.linalg.norm(g, axis=1, keepdims=True)
    df["h"] = np.degrees(np.arctan2(g[:, 0], -g[:, 2])); df["v"] = np.degrees(np.arcsin(np.clip(g[:, 1], -1, 1)))
    for s, idx in df.groupby("subject").indices.items():
        df.loc[idx, "T_H"] = np.abs(df.loc[idx, "h"] - df.loc[idx, "h"].mean())
        df.loc[idx, "T_V"] = np.abs(df.loc[idx, "v"] - df.loc[idx, "v"].mean())
        m = g[idx].mean(0); m /= np.linalg.norm(m)
        df.loc[idx, "T_A"] = np.degrees(np.arccos(np.clip(g[idx] @ m, -1, 1)))
    return df
