"""Exp 12b - sanity checks behind exp12's near-chance result: (1) label/time alignment (annotation end vs video length) per subject,
(2) MediaPipe face-detection rate, cheating prevalence, (3) standardised mean differences (cheating vs normal windows) per feature,
pooled and per subject group, (4) annotation-boundary shift test: AUROC of the head heuristic when labels are shifted by +-k seconds
(a large peak away from 0 s would indicate a timing offset)."""
import json
import numpy as np, pandas as pd
from sklearn.metrics import roc_auc_score
from common import RESULTS
import exp12_oep_models as E      # module-level code only loads data (the analysis is under __main__)

rows = []
for n, f in E.frames.items():
    iv = E.load_gt(E.EX / f"subject{n}" / "gt.txt")
    rows.append(dict(subject=n, group="real" if n in E.REAL else "actor", video_s=float(f.t.max()), gt_max_end_s=max(b for _, b, _ in iv),
                     n_intervals=len(iv), cheat_share=float(f.cheat.mean()), face_found=float(f.det.mean()),
                     types=",".join(str(t) for t in sorted({t for *_, t in iv}))))
A = pd.DataFrame(rows); A["gt_within_video"] = A.gt_max_end_s <= A.video_s + 1
A.to_csv(RESULTS / "exp12b_alignment.csv", index=False); print(A.to_string(index=False))

W = E.window_table(10, "personal")
feats = ["absent_frac", "z_h_max", "z_x_max", "h_yaw_max", "h_pitch_max", "h_roll_max", "hhat_std", "gx_std"]
def smd(d):
    a, b = d[d.y == 1], d[d.y == 0]; s = np.sqrt((a.var() + b.var()) / 2)
    return (a.mean() - b.mean()) / s.replace(0, np.nan)
S = pd.DataFrame({"all": smd(W[feats + ["y"]])[feats], "actors": smd(W[W.actor == 1][feats + ["y"]])[feats], "real": smd(W[W.actor == 0][feats + ["y"]])[feats]})
S.to_csv(RESULTS / "exp12b_effect_sizes.csv"); print("\nstandardised mean difference (cheating - normal windows):\n", S.round(3))

# label-shift test on the frame level: head-deviation (max over axes) vs label shifted by k seconds
sh = []
for k in (-20, -10, -5, -2, 0, 2, 5, 10, 20):
    ys, ss = [], []
    for n, f in E.frames.items():
        ev = f[f.t >= E.CAL_S].reset_index(drop=True); d = E.deviations(ev, n, "personal")
        score = d[[f"h_{a}" for a in E.HEAD]].max(axis=1).fillna(0).values
        lag = int(round(k * E.FPS)); y = np.roll(ev.cheat.values, lag)
        if lag > 0: y[:lag] = 0
        elif lag < 0: y[lag:] = 0
        ys.append(y); ss.append(score)
    sh.append(dict(shift_s=k, frame_auroc_head=float(roc_auc_score(np.concatenate(ys), np.concatenate(ss)))))
SH = pd.DataFrame(sh); SH.to_csv(RESULTS / "exp12b_label_shift.csv", index=False); print("\n", SH.round(3).to_string(index=False))
