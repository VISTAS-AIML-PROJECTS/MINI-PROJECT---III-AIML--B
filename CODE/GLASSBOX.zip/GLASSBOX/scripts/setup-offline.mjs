// Make the webcam demo independent of the network: copy the MediaPipe WASM runtime from node_modules and the
// face-landmarker model into public/mediapipe/ (gitignored), which visionTracker.js tries before the CDN.
//   npm run setup:offline
// The model is taken from data/models/face_landmarker.task when present (research/fetch_data.py downloads it),
// otherwise downloaded once from Google's model storage (Apache-2.0).
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const OUT = path.join(ROOT, "public", "mediapipe");
const WASM_SRC = path.join(ROOT, "node_modules", "@mediapipe", "tasks-vision", "wasm");
const MODEL_CACHE = path.join(ROOT, "data", "models", "face_landmarker.task");
const MODEL_URL = "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task";

fs.mkdirSync(path.join(OUT, "wasm"), { recursive: true });
for (const f of fs.readdirSync(WASM_SRC)) fs.copyFileSync(path.join(WASM_SRC, f), path.join(OUT, "wasm", f));
console.log(`copied MediaPipe WASM runtime -> ${path.relative(ROOT, path.join(OUT, "wasm"))}`);

const model = path.join(OUT, "face_landmarker.task");
if (fs.existsSync(MODEL_CACHE)) {
  fs.copyFileSync(MODEL_CACHE, model);
  console.log("copied face_landmarker.task from data/models");
} else if (!fs.existsSync(model)) {
  const res = await fetch(MODEL_URL);
  if (!res.ok) throw new Error(`model download failed: ${res.status}`);
  fs.writeFileSync(model, Buffer.from(await res.arrayBuffer()));
  console.log("downloaded face_landmarker.task");
}
console.log(`model: ${(fs.statSync(model).size / 1e6).toFixed(1)} MB. The app now loads MediaPipe locally.`);
