import express from "express";
import cors from "cors";
import { pathToFileURL } from "url";
import db from "./database.js";

const app = express();
const PORT = 5000;
const HOST = process.env.GLASSBOX_HOST || "127.0.0.1";

/*
 * Behavioural data stays on this machine: only the local front end may call
 * the API from a browser (any other web page the student has open cannot read
 * or write sessions), and the server listens on the loopback interface only.
 * Requests without an Origin header (curl, the API tests) are unaffected.
 */
const ALLOWED_ORIGINS = new Set(
  (
    process.env.GLASSBOX_ALLOWED_ORIGINS ||
    "http://localhost:5173,http://127.0.0.1:5173,http://localhost:4173,http://127.0.0.1:4173"
  )
    .split(",")
    .map((o) => o.trim())
    .filter(Boolean)
);

app.use(
  cors({
    origin(origin, callback) {
      callback(null, !origin || ALLOWED_ORIGINS.has(origin));
    },
  })
);
app.use(express.json({ limit: "1mb" }));

/* =========================================================
   DATABASE SETUP
   ========================================================= */

db.exec(`
  CREATE TABLE IF NOT EXISTS exams (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS exam_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    exam_id INTEGER NOT NULL,
    student_id INTEGER NOT NULL,
    condition TEXT NOT NULL DEFAULT 'UNSPECIFIED',
    quality TEXT NOT NULL DEFAULT 'PENDING',
    approved INTEGER NOT NULL DEFAULT 0,
    started_at TEXT NOT NULL,
    ended_at TEXT,
    status TEXT NOT NULL DEFAULT 'ACTIVE',
    FOREIGN KEY (exam_id) REFERENCES exams(id),
    FOREIGN KEY (student_id) REFERENCES students(id)
  );

  CREATE TABLE IF NOT EXISTS signals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL,
    type TEXT NOT NULL,
    source TEXT NOT NULL,
    timestamp INTEGER NOT NULL,
    value TEXT,
    confidence REAL,
    metadata TEXT,
    FOREIGN KEY (session_id) REFERENCES exam_sessions(id)
  );

  CREATE TABLE IF NOT EXISTS evidence (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL,
    type TEXT NOT NULL,
    timestamp INTEGER NOT NULL,
    duration_ms REAL,
    persistence_ms REAL,
    frequency REAL,
    strength REAL,
    decay_weight REAL,
    metadata TEXT,
    FOREIGN KEY (session_id) REFERENCES exam_sessions(id)
  );

  CREATE TABLE IF NOT EXISTS features (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL,
    timestamp INTEGER NOT NULL,

    gaze_frequency REAL,
    head_pose_frequency REAL,
    focus_loss_frequency REAL,
    face_absence_frequency REAL,

    gaze_duration_ms REAL,
    head_pose_duration_ms REAL,
    focus_loss_duration_ms REAL,
    face_absence_duration_ms REAL,

    gaze_strength REAL,
    head_pose_strength REAL,
    focus_loss_strength REAL,
    face_absence_strength REAL,

    gaze_magnitude REAL,
    head_pose_magnitude REAL,

    fusion_score REAL,
    fusion_confidence REAL,
    concurrence_count REAL,
    behavioral_activity REAL,

    FOREIGN KEY (session_id) REFERENCES exam_sessions(id)
  );

  CREATE TABLE IF NOT EXISTS fusion_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL,
    timestamp INTEGER NOT NULL,
    score REAL,
    confidence REAL,
    signal_count INTEGER,
    concurrent_signals TEXT,
    components TEXT,
    reasons TEXT,
    FOREIGN KEY (session_id) REFERENCES exam_sessions(id)
  );

  CREATE TABLE IF NOT EXISTS risk_results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL,
    timestamp INTEGER NOT NULL,
    score REAL,
    level TEXT,
    reasons TEXT,
    components TEXT,
    FOREIGN KEY (session_id) REFERENCES exam_sessions(id)
  );
`);

/*
 * Human review decisions for the Review queue. Append-only: every decision
 * or note is a new row and no row is ever updated or deleted, so the table is
 * an audit trail. Kept apart from exam_sessions.quality/approved, which label
 * data-collection quality, not a reviewer's judgement of a session.
 */
db.exec(`
  CREATE TABLE IF NOT EXISTS review_decisions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL,
    decision TEXT NOT NULL,
    note TEXT,
    created_at TEXT NOT NULL,
    FOREIGN KEY (session_id) REFERENCES exam_sessions(id)
  );

  CREATE INDEX IF NOT EXISTS idx_review_decisions_session
    ON review_decisions(session_id, id);
`);

const REVIEW_DECISIONS = ["CLEARED", "FOLLOW_UP", "NOTE"];
const MAX_REVIEW_NOTE_LENGTH = 2000;

/* =========================================================
   SAFE DATABASE MIGRATION
   ========================================================= */

function addColumnIfMissing(
  tableName,
  columnName,
  definition
) {
  const columns = db
    .prepare(`PRAGMA table_info(${tableName})`)
    .all();

  const exists = columns.some(
    (column) => column.name === columnName
  );

  if (!exists) {
    db.exec(
      `ALTER TABLE ${tableName} ADD COLUMN ${columnName} ${definition}`
    );

    console.log(
      `Database migration: added ${tableName}.${columnName}`
    );
  }
}

/*
 * Your existing glassbox.db may have been created
 * using the older schema.
 *
 * CREATE TABLE IF NOT EXISTS does NOT modify an
 * existing table, so we safely add the new columns here.
 */

// Session fields
addColumnIfMissing(
  "exam_sessions",
  "condition",
  "TEXT NOT NULL DEFAULT 'UNSPECIFIED'"
);

addColumnIfMissing(
  "exam_sessions",
  "quality",
  "TEXT NOT NULL DEFAULT 'PENDING'"
);

addColumnIfMissing(
  "exam_sessions",
  "approved",
  "INTEGER NOT NULL DEFAULT 0"
);

// Feature fields
addColumnIfMissing(
  "features",
  "gaze_duration_ms",
  "REAL DEFAULT 0"
);

addColumnIfMissing(
  "features",
  "head_pose_duration_ms",
  "REAL DEFAULT 0"
);

addColumnIfMissing(
  "features",
  "focus_loss_duration_ms",
  "REAL DEFAULT 0"
);

addColumnIfMissing(
  "features",
  "face_absence_duration_ms",
  "REAL DEFAULT 0"
);

addColumnIfMissing(
  "features",
  "gaze_strength",
  "REAL DEFAULT 0"
);

addColumnIfMissing(
  "features",
  "head_pose_strength",
  "REAL DEFAULT 0"
);

addColumnIfMissing(
  "features",
  "focus_loss_strength",
  "REAL DEFAULT 0"
);

addColumnIfMissing(
  "features",
  "face_absence_strength",
  "REAL DEFAULT 0"
);

// Assessment v2 fields (src/assessment/). Rows written by the
// v1 engine keep NULL here, so old sessions stay readable as-is.
addColumnIfMissing("risk_results", "state", "TEXT");
addColumnIfMissing("risk_results", "reliability", "REAL");
addColumnIfMissing("risk_results", "engine_version", "TEXT");
addColumnIfMissing("risk_results", "details", "TEXT");

console.log("GlassBox database schema ready.");

/* =========================================================
   HELPERS
   ========================================================= */

function nowISO() {
  return new Date().toISOString();
}

function parseJSON(value) {
  if (value === null || value === undefined) {
    return null;
  }

  if (typeof value === "object") {
    return value;
  }

  try {
    return JSON.parse(value);
  } catch {
    return value;
  }
}

function stringifyJSON(value) {
  if (
    value === null ||
    value === undefined
  ) {
    return null;
  }

  return JSON.stringify(value);
}

const RISK_LEVELS = ["LOW", "MEDIUM", "HIGH", "UNDETERMINED"];

/*
 * A session left ACTIVE with no new data for this long was not
 * ended by the app (tab closed, crash). It is reported as
 * INTERRUPTED when read; the stored row is not modified.
 */
const STALE_SESSION_MS = 5 * 60 * 1000;

function getSession(sessionId) {
  return db
    .prepare(
      `
      SELECT *
      FROM exam_sessions
      WHERE id = ?
      `
    )
    .get(sessionId);
}

/* =========================================================
   HEALTH
   ========================================================= */

app.get("/api/health", (req, res) => {
  res.json({
    success: true,
    status: "ok",
    message: "GlassBox backend is running.",
    timestamp: nowISO(),
  });
});

/* =========================================================
   EXAMS
   ========================================================= */

app.post("/api/exams", (req, res) => {
  try {
    const { title } = req.body;

    if (!title) {
      return res.status(400).json({
        success: false,
        message: "Exam title is required.",
      });
    }

    const createdAt = nowISO();

    const result = db
      .prepare(
        `
        INSERT INTO exams (
          title,
          created_at
        )
        VALUES (?, ?)
        `
      )
      .run(title, createdAt);

    const exam = db
      .prepare(
        `
        SELECT *
        FROM exams
        WHERE id = ?
        `
      )
      .get(result.lastInsertRowid);

    res.status(201).json({
      success: true,
      exam,
    });
  } catch (error) {
    console.error("Create exam error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to create exam.",
    });
  }
});

/* =========================================================
   STUDENTS
   ========================================================= */

app.post("/api/students", (req, res) => {
  try {
    const { name, email } = req.body;

    if (!name) {
      return res.status(400).json({
        success: false,
        message: "Student name is required.",
      });
    }

    const existingStudent = email
      ? db
          .prepare(
            `
            SELECT *
            FROM students
            WHERE email = ?
            `
          )
          .get(email)
      : null;

    if (existingStudent) {
      return res.json({
        success: true,
        student: existingStudent,
      });
    }

    const createdAt = nowISO();

    const result = db
      .prepare(
        `
        INSERT INTO students (
          name,
          email,
          created_at
        )
        VALUES (?, ?, ?)
        `
      )
      .run(
        name,
        email || null,
        createdAt
      );

    const student = db
      .prepare(
        `
        SELECT *
        FROM students
        WHERE id = ?
        `
      )
      .get(result.lastInsertRowid);

    res.status(201).json({
      success: true,
      student,
    });
  } catch (error) {
    console.error(
      "Create student error:",
      error
    );

    res.status(500).json({
      success: false,
      message: "Failed to create student.",
    });
  }
});

/* =========================================================
   START SESSION
   ========================================================= */

app.post("/api/sessions", (req, res) => {
  try {
    const {
      examId,
      studentId,
      condition = "UNSPECIFIED",
    } = req.body;

    if (!examId || !studentId) {
      return res.status(400).json({
        success: false,
        message:
          "examId and studentId are required.",
      });
    }

    const exam = db
      .prepare(
        `
        SELECT *
        FROM exams
        WHERE id = ?
        `
      )
      .get(examId);

    if (!exam) {
      return res.status(404).json({
        success: false,
        message: "Exam not found.",
      });
    }

    const student = db
      .prepare(
        `
        SELECT *
        FROM students
        WHERE id = ?
        `
      )
      .get(studentId);

    if (!student) {
      return res.status(404).json({
        success: false,
        message: "Student not found.",
      });
    }

    const startedAt = nowISO();

    const result = db
      .prepare(
        `
        INSERT INTO exam_sessions (
          exam_id,
          student_id,
          condition,
          quality,
          approved,
          started_at,
          status
        )
        VALUES (?, ?, ?, 'PENDING', 0, ?, 'ACTIVE')
        `
      )
      .run(
        examId,
        studentId,
        condition,
        startedAt
      );

    const session = getSession(
      result.lastInsertRowid
    );

    res.status(201).json({
      success: true,
      session,
    });
  } catch (error) {
    console.error(
      "Create session error:",
      error
    );

    res.status(500).json({
      success: false,
      message: "Failed to create session.",
    });
  }
});

/* =========================================================
   END SESSION
   ========================================================= */

app.post(
  "/api/sessions/:id/end",
  (req, res) => {
    try {
      const sessionId =
        Number(req.params.id);

      const session =
        getSession(sessionId);

      if (!session) {
        return res.status(404).json({
          success: false,
          message: "Session not found.",
        });
      }

      if (session.status !== "ACTIVE") {
        return res.json({
          success: true,
          session,
        });
      }

      const endedAt = nowISO();

      // navigator.sendBeacon on page unload sends ?reason=unload.
      const status =
        req.query.reason === "unload"
          ? "INTERRUPTED"
          : "COMPLETED";

      db.prepare(
        `
        UPDATE exam_sessions
        SET
          ended_at = ?,
          status = ?
        WHERE id = ?
        `
      ).run(
        endedAt,
        status,
        sessionId
      );

      const updatedSession =
        getSession(sessionId);

      res.json({
        success: true,
        session: updatedSession,
      });
    } catch (error) {
      console.error(
        "End session error:",
        error
      );

      res.status(500).json({
        success: false,
        message: "Failed to end session.",
      });
    }
  }
);

/* =========================================================
   UPDATE SESSION REVIEW
   ========================================================= */

app.patch(
  "/api/sessions/:id/review",
  (req, res) => {
    try {
      const sessionId =
        Number(req.params.id);

      const {
        quality,
        approved,
      } = req.body;

      const session =
        getSession(sessionId);

      if (!session) {
        return res.status(404).json({
          success: false,
          message: "Session not found.",
        });
      }

      const allowedQuality = [
        "PENDING",
        "GOOD",
        "REVIEW",
        "FAILED",
      ];

      const normalizedQuality =
        quality || session.quality;

      if (
        !allowedQuality.includes(
          normalizedQuality
        )
      ) {
        return res.status(400).json({
          success: false,
          message:
            "Invalid quality value.",
        });
      }

      const normalizedApproved =
        approved === undefined
          ? session.approved
          : approved
          ? 1
          : 0;

      db.prepare(
        `
        UPDATE exam_sessions
        SET
          quality = ?,
          approved = ?
        WHERE id = ?
        `
      ).run(
        normalizedQuality,
        normalizedApproved,
        sessionId
      );

      const updatedSession =
        getSession(sessionId);

      res.json({
        success: true,
        session: updatedSession,
      });
    } catch (error) {
      console.error(
        "Review session error:",
        error
      );

      res.status(500).json({
        success: false,
        message:
          "Failed to update session review.",
      });
    }
  }
);

/* =========================================================
   SIGNALS
   ========================================================= */

app.post("/api/signals", (req, res) => {
  try {
    const {
      sessionId,
      type,
      source,
      timestamp,
      value,
      confidence,
      metadata,
    } = req.body;

    if (
      !sessionId ||
      !type ||
      !source
    ) {
      return res.status(400).json({
        success: false,
        message:
          "sessionId, type and source are required.",
      });
    }

    const session =
      getSession(sessionId);

    if (!session) {
      return res.status(404).json({
        success: false,
        message: "Session not found.",
      });
    }

    const result = db
      .prepare(
        `
        INSERT INTO signals (
          session_id,
          type,
          source,
          timestamp,
          value,
          confidence,
          metadata
        )
        VALUES (?, ?, ?, ?, ?, ?, ?)
        `
      )
      .run(
        sessionId,
        type,
        source,
        timestamp ?? Date.now(),
        stringifyJSON(value),
        confidence ?? null,
        stringifyJSON(metadata)
      );

    res.status(201).json({
      success: true,
      signalId:
        result.lastInsertRowid,
    });
  } catch (error) {
    console.error(
      "Save signal error:",
      error
    );

    res.status(500).json({
      success: false,
      message: "Failed to save signal.",
    });
  }
});

/* =========================================================
   EVIDENCE
   ========================================================= */

app.post("/api/evidence", (req, res) => {
  try {
    const {
      sessionId,
      type,
      timestamp,
      durationMs,
      persistenceMs,
      frequency,
      strength,
      decayWeight,
      metadata,
    } = req.body;

    if (!sessionId || !type) {
      return res.status(400).json({
        success: false,
        message:
          "sessionId and type are required.",
      });
    }

    const session =
      getSession(sessionId);

    if (!session) {
      return res.status(404).json({
        success: false,
        message: "Session not found.",
      });
    }

    const result = db
      .prepare(
        `
        INSERT INTO evidence (
          session_id,
          type,
          timestamp,
          duration_ms,
          persistence_ms,
          frequency,
          strength,
          decay_weight,
          metadata
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `
      )
      .run(
        sessionId,
        type,
        timestamp ?? Date.now(),
        durationMs ?? null,
        persistenceMs ?? null,
        frequency ?? null,
        strength ?? null,
        decayWeight ?? null,
        stringifyJSON(metadata)
      );

    res.status(201).json({
      success: true,
      evidenceId:
        result.lastInsertRowid,
    });
  } catch (error) {
    console.error(
      "Save evidence error:",
      error
    );

    res.status(500).json({
      success: false,
      message: "Failed to save evidence.",
    });
  }
});

/* =========================================================
   FEATURES
   ========================================================= */

app.post("/api/features", (req, res) => {
  try {
    const {
      sessionId,
      timestamp,

      gazeFrequency,
      headPoseFrequency,
      focusLossFrequency,
      faceAbsenceFrequency,

      gazeDurationMs,
      headPoseDurationMs,
      focusLossDurationMs,
      faceAbsenceDurationMs,

      gazeStrength,
      headPoseStrength,
      focusLossStrength,
      faceAbsenceStrength,

      gazeMagnitude,
      headPoseMagnitude,

      fusionScore,
      fusionConfidence,
      concurrenceCount,
      behavioralActivity,
    } = req.body;

    if (!sessionId) {
      return res.status(400).json({
        success: false,
        message: "sessionId is required.",
      });
    }

    const session =
      getSession(sessionId);

    if (!session) {
      return res.status(404).json({
        success: false,
        message: "Session not found.",
      });
    }

    const result = db
      .prepare(
        `
        INSERT INTO features (
          session_id,
          timestamp,

          gaze_frequency,
          head_pose_frequency,
          focus_loss_frequency,
          face_absence_frequency,

          gaze_duration_ms,
          head_pose_duration_ms,
          focus_loss_duration_ms,
          face_absence_duration_ms,

          gaze_strength,
          head_pose_strength,
          focus_loss_strength,
          face_absence_strength,

          gaze_magnitude,
          head_pose_magnitude,

          fusion_score,
          fusion_confidence,
          concurrence_count,
          behavioral_activity
        )
        VALUES (
          ?, ?,
          ?, ?, ?, ?,
          ?, ?, ?, ?,
          ?, ?, ?, ?,
          ?, ?,
          ?, ?, ?, ?
        )
        `
      )
      .run(
        sessionId,
        timestamp ?? Date.now(),

        gazeFrequency ?? 0,
        headPoseFrequency ?? 0,
        focusLossFrequency ?? 0,
        faceAbsenceFrequency ?? 0,

        gazeDurationMs ?? 0,
        headPoseDurationMs ?? 0,
        focusLossDurationMs ?? 0,
        faceAbsenceDurationMs ?? 0,

        gazeStrength ?? 0,
        headPoseStrength ?? 0,
        focusLossStrength ?? 0,
        faceAbsenceStrength ?? 0,

        gazeMagnitude ?? 0,
        headPoseMagnitude ?? 0,

        fusionScore ?? 0,
        fusionConfidence ?? 0,
        concurrenceCount ?? 0,
        behavioralActivity ?? 0
      );

    res.status(201).json({
      success: true,
      featureId:
        result.lastInsertRowid,
    });
  } catch (error) {
    console.error(
      "Save features error:",
      error
    );

    res.status(500).json({
      success: false,
      message: "Failed to save features.",
    });
  }
});

/* =========================================================
   FUSION
   ========================================================= */

app.post("/api/fusion", (req, res) => {
  try {
    const {
      sessionId,
      timestamp,
      score,
      confidence,
      signalCount,
      concurrentSignals,
      components,
      reasons,
    } = req.body;

    if (!sessionId) {
      return res.status(400).json({
        success: false,
        message: "sessionId is required.",
      });
    }

    const session =
      getSession(sessionId);

    if (!session) {
      return res.status(404).json({
        success: false,
        message: "Session not found.",
      });
    }

    const result = db
      .prepare(
        `
        INSERT INTO fusion_events (
          session_id,
          timestamp,
          score,
          confidence,
          signal_count,
          concurrent_signals,
          components,
          reasons
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `
      )
      .run(
        sessionId,
        timestamp ?? Date.now(),
        score ?? 0,
        confidence ?? 0,
        signalCount ?? 0,
        stringifyJSON(
          concurrentSignals
        ),
        stringifyJSON(components),
        stringifyJSON(reasons)
      );

    res.status(201).json({
      success: true,
      fusionId:
        result.lastInsertRowid,
    });
  } catch (error) {
    console.error(
      "Save fusion error:",
      error
    );

    res.status(500).json({
      success: false,
      message: "Failed to save fusion.",
    });
  }
});

/* =========================================================
   RISK
   ========================================================= */

app.post("/api/risk", (req, res) => {
  try {
    const {
      sessionId,
      timestamp,
      score,
      level,
      reasons,
      components,
      state,
      reliability,
      engineVersion,
      details,
    } = req.body;

    if (!sessionId) {
      return res.status(400).json({
        success: false,
        message: "sessionId is required.",
      });
    }

    // A missing score must not be stored as 0 (Number(null) === 0).
    const numericScore =
      score === null || score === undefined || score === ""
        ? NaN
        : Number(score);

    if (
      !Number.isFinite(numericScore) ||
      numericScore < 0 ||
      numericScore > 100
    ) {
      return res.status(400).json({
        success: false,
        message: "score must be a number in [0, 100].",
      });
    }

    if (
      reliability !== undefined &&
      reliability !== null &&
      !(Number(reliability) >= 0 && Number(reliability) <= 1)
    ) {
      return res.status(400).json({
        success: false,
        message: "reliability must be in [0, 1].",
      });
    }

    if (
      level !== undefined &&
      !RISK_LEVELS.includes(level)
    ) {
      return res.status(400).json({
        success: false,
        message: "Invalid risk level.",
      });
    }

    const session =
      getSession(sessionId);

    if (!session) {
      return res.status(404).json({
        success: false,
        message: "Session not found.",
      });
    }

    const result = db
      .prepare(
        `
        INSERT INTO risk_results (
          session_id,
          timestamp,
          score,
          level,
          reasons,
          components,
          state,
          reliability,
          engine_version,
          details
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `
      )
      .run(
        sessionId,
        Number.isFinite(Number(timestamp))
          ? Number(timestamp)
          : Date.now(),
        numericScore,
        level ?? "LOW",
        stringifyJSON(reasons),
        stringifyJSON(components),
        state ?? null,
        reliability ?? null,
        engineVersion ?? null,
        stringifyJSON(details)
      );

    res.status(201).json({
      success: true,
      riskId:
        result.lastInsertRowid,
    });
  } catch (error) {
    console.error(
      "Save risk error:",
      error
    );

    res.status(500).json({
      success: false,
      message: "Failed to save risk.",
    });
  }
});

function effectiveStatus(row) {
  if (row.status !== "ACTIVE") {
    return row.status;
  }

  const last =
    row.last_activity ??
    new Date(row.started_at).getTime();

  return Date.now() - last > STALE_SESSION_MS
    ? "INTERRUPTED"
    : "ACTIVE";
}

/* =========================================================
   GET COMPLETE SESSION
   ========================================================= */

/*
 * List sessions (read-only) for the session-history page.
 * Returns summary counts and the peak risk score per session.
 */
app.get("/api/sessions", (req, res) => {
  try {
    const rows = db
      .prepare(
        `
        SELECT
          s.id,
          s.condition,
          s.status,
          s.started_at,
          s.ended_at,
          st.name AS student_name,
          e.title AS exam_title,
          (SELECT COUNT(*) FROM signals g WHERE g.session_id = s.id) AS signal_count,
          (SELECT COUNT(*) FROM evidence v WHERE v.session_id = s.id) AS evidence_count,
          (SELECT MAX(score) FROM risk_results r WHERE r.session_id = s.id) AS peak_risk,
          (SELECT score FROM risk_results r WHERE r.session_id = s.id ORDER BY timestamp DESC, id DESC LIMIT 1) AS final_risk,
          (SELECT state FROM risk_results r WHERE r.session_id = s.id ORDER BY timestamp DESC, id DESC LIMIT 1) AS final_state,
          (SELECT engine_version FROM risk_results r WHERE r.session_id = s.id ORDER BY timestamp DESC, id DESC LIMIT 1) AS engine_version,
          (SELECT decision FROM review_decisions d WHERE d.session_id = s.id AND d.decision <> 'NOTE' ORDER BY d.id DESC LIMIT 1) AS review_decision,
          (SELECT created_at FROM review_decisions d WHERE d.session_id = s.id AND d.decision <> 'NOTE' ORDER BY d.id DESC LIMIT 1) AS reviewed_at,
          (SELECT COUNT(*) FROM review_decisions d WHERE d.session_id = s.id) AS review_entries,
          (SELECT MAX(t) FROM (
             SELECT MAX(timestamp) AS t FROM signals WHERE session_id = s.id
             UNION ALL SELECT MAX(timestamp) FROM risk_results WHERE session_id = s.id
          )) AS last_activity
        FROM exam_sessions s
        LEFT JOIN students st ON st.id = s.student_id
        LEFT JOIN exams e ON e.id = s.exam_id
        ORDER BY s.id DESC
        LIMIT 200
        `
      )
      .all()
      .map((row) => ({
        ...row,
        status: effectiveStatus(row),
      }));

    res.json({ success: true, sessions: rows });
  } catch (error) {
    console.error("List sessions error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to list sessions.",
    });
  }
});

app.get(
  "/api/sessions/:id",
  (req, res) => {
    try {
      const sessionId =
        Number(req.params.id);

      const session =
        getSession(sessionId);

      if (!session) {
        return res.status(404).json({
          success: false,
          message: "Session not found.",
        });
      }

      const signals = db
        .prepare(
          `
          SELECT *
          FROM signals
          WHERE session_id = ?
          ORDER BY timestamp ASC
          `
        )
        .all(sessionId)
        .map((signal) => ({
          ...signal,
          value: parseJSON(
            signal.value
          ),
          metadata: parseJSON(
            signal.metadata
          ),
        }));

      const evidence = db
        .prepare(
          `
          SELECT *
          FROM evidence
          WHERE session_id = ?
          ORDER BY timestamp ASC
          `
        )
        .all(sessionId)
        .map((item) => ({
          ...item,
          metadata: parseJSON(
            item.metadata
          ),
        }));

      const features = db
        .prepare(
          `
          SELECT *
          FROM features
          WHERE session_id = ?
          ORDER BY timestamp ASC
          `
        )
        .all(sessionId);

      const fusion = db
        .prepare(
          `
          SELECT *
          FROM fusion_events
          WHERE session_id = ?
          ORDER BY timestamp ASC
          `
        )
        .all(sessionId)
        .map((item) => ({
          ...item,
          concurrent_signals:
            parseJSON(
              item.concurrent_signals
            ),
          components: parseJSON(
            item.components
          ),
          reasons: parseJSON(
            item.reasons
          ),
        }));

      const risk = db
        .prepare(
          `
          SELECT *
          FROM risk_results
          WHERE session_id = ?
          ORDER BY timestamp ASC
          `
        )
        .all(sessionId)
        .map((item) => ({
          ...item,
          reasons: parseJSON(
            item.reasons
          ),
          components: parseJSON(
            item.components
          ),
          details: parseJSON(
            item.details
          ),
        }));

      const lastActivity =
        Math.max(
          signals.at(-1)?.timestamp ?? 0,
          risk.at(-1)?.timestamp ?? 0
        ) || null;

      res.json({
        success: true,
        session: {
          ...session,
          status: effectiveStatus({
            ...session,
            last_activity: lastActivity,
          }),
        },
        signals,
        evidence,
        features,
        fusion,
        risk,
        reviews: db
          .prepare(
            "SELECT * FROM review_decisions WHERE session_id = ? ORDER BY id ASC"
          )
          .all(sessionId),
      });
    } catch (error) {
      console.error(
        "Get session error:",
        error
      );

      res.status(500).json({
        success: false,
        message:
          "Failed to retrieve session.",
      });
    }
  }
);

/* =========================================================
   REVIEW DECISIONS (append-only)
   ========================================================= */

app.post("/api/sessions/:id/decisions", (req, res) => {
  try {
    const sessionId = Number(req.params.id);
    const session = Number.isInteger(sessionId) ? getSession(sessionId) : null;

    if (!session) {
      return res.status(404).json({ success: false, message: "Session not found." });
    }

    const decision = req.body?.decision;
    const rawNote = req.body?.note;

    if (!REVIEW_DECISIONS.includes(decision)) {
      return res.status(400).json({ success: false, message: "Invalid decision." });
    }

    if (rawNote !== undefined && rawNote !== null && typeof rawNote !== "string") {
      return res.status(400).json({ success: false, message: "Note must be text." });
    }

    const note = typeof rawNote === "string" ? rawNote.trim() : "";

    if (note.length > MAX_REVIEW_NOTE_LENGTH) {
      return res.status(400).json({ success: false, message: "Note is too long." });
    }

    if (decision === "NOTE" && !note) {
      return res.status(400).json({ success: false, message: "A note needs text." });
    }

    const lastActivity = db
      .prepare(
        `SELECT MAX(t) AS t FROM (
           SELECT MAX(timestamp) AS t FROM signals WHERE session_id = ?
           UNION ALL SELECT MAX(timestamp) FROM risk_results WHERE session_id = ?
         )`
      )
      .get(sessionId, sessionId)?.t;

    if (effectiveStatus({ ...session, last_activity: lastActivity }) === "ACTIVE") {
      return res.status(409).json({
        success: false,
        message: "The session is still running; review it after it ends.",
      });
    }

    const createdAt = new Date().toISOString();
    const result = db
      .prepare(
        "INSERT INTO review_decisions (session_id, decision, note, created_at) VALUES (?, ?, ?, ?)"
      )
      .run(sessionId, decision, note || null, createdAt);

    res.status(201).json({
      success: true,
      review: {
        id: Number(result.lastInsertRowid),
        session_id: sessionId,
        decision,
        note: note || null,
        created_at: createdAt,
      },
    });
  } catch (error) {
    console.error("Review decision error:", error);
    res.status(500).json({ success: false, message: "Failed to record the review decision." });
  }
});

/* =========================================================
   START SERVER
   ========================================================= */

export default app;

// Listen only when started directly (node server/server.js), not when
// imported by the API tests.
if (
  process.argv[1] &&
  import.meta.url === pathToFileURL(process.argv[1]).href
) {
  app.listen(PORT, HOST, () => {
    console.log(
      `GlassBox server running on http://${HOST}:${PORT}`
    );
  });
}