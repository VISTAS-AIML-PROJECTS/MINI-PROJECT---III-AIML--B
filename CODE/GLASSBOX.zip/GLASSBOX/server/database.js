import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/*
 * GLASSBOX_DB_PATH lets tests run against a throw-away database
 * (research/tests/server_api.test.mjs); the app default is unchanged.
 */
const dbPath =
  process.env.GLASSBOX_DB_PATH ||
  path.join(
    __dirname,
    "..",
    "glassbox.db"
  );

const db = new Database(dbPath);

db.pragma("journal_mode = WAL");

console.log("GlassBox database connected.");
console.log(`Database file: ${dbPath}`);

export default db;