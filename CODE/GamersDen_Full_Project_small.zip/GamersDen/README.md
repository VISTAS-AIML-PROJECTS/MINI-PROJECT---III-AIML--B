# GamersDen — runnable full-stack starter

GamersDen is a Django REST + React/Vite app for gaming-centre discovery, owner console management, shared player-slot bookings, and checkout scaffolding.

## Requirements
- Python 3.10+
- Node.js 18+
- Optional: MySQL 8+ (SQLite is the zero-config default)
- Optional Razorpay test credentials

## Quick start (SQLite, fastest)
### Backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
python manage.py migrate --run-syncdb
python manage.py seed_demo
python manage.py runserver
```
API: http://127.0.0.1:8000/api/  
Admin: http://127.0.0.1:8000/admin/ (create a superuser with `python manage.py createsuperuser`)

### Frontend (new terminal)
```bash
cd frontend
npm install
npm run dev
```
Open the URL Vite prints (normally http://localhost:5173).

Demo accounts seeded by `seed_demo`:
- Customer: `gamer@example.com` / `GamerPass123!`
- Owner: `owner@example.com` / `OwnerPass123!`

The demo seed command is for local development only. Change passwords and remove demo data before deployment.

## MySQL
Create a database and user, then set:
```env
DB_ENGINE=mysql
DB_NAME=gamersden
DB_USER=gamersden_user
DB_PASSWORD=replace-me
DB_HOST=127.0.0.1
DB_PORT=3306
```
Install the optional MySQL driver with `pip install mysqlclient` (system build dependencies may be needed). Run migrations after configuration.

## Razorpay
Set the backend environment variables from `.env.example`. The server creates orders and verifies checkout signatures when Razorpay credentials are configured. Webhook endpoint: `POST /api/payments/webhook/` and set `RAZORPAY_WEBHOOK_SECRET`. Without credentials, checkout is clearly marked as unavailable; the app does not pretend a payment succeeded. Automated/local development may use `PAYMENT_MODE=mock`, which is rejected when `DEBUG=False`.

## Core behavior
- Customer and owner accounts have separate roles and role-checked endpoints.
- Owners manage their centre, consoles, games, sessions and bookings.
- Booking requests are serialized in a database transaction and check remaining player capacity.
- Shared bookings may join a compatible session; private bookings exclude other groups.
- A pending booking hold expires after 10 minutes; the frontend demo flow is intentionally small and can be extended with a scheduled cleanup task.
- Payment state is separate from booking state; a booking is confirmed only after a verified payment or explicit local mock-test payment.
- API uses Django session authentication + CSRF and Django password hashing.
- This is a runnable development baseline, not a security audit or production certification.

## Tests
```bash
cd backend
python manage.py test
```
