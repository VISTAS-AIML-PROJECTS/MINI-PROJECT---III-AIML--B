﻿const API = import.meta.env.VITE_API_URL || 'http://localhost:8001/api';
async function request(path, options={}) {
  const csrf = await getCsrf();
  const res = await fetch(`${API}${path}`, {credentials:'include', ...options, headers:{
    ...(options.body ? {'Content-Type':'application/json'} : {}),
    ...(csrf && options.method && options.method !== 'GET' ? {'X-CSRFToken':csrf} : {}),
    ...options.headers
  }});
  const data = await res.json().catch(()=>({}));
  if (!res.ok) throw new Error(data.detail || Object.values(data).flat().join(' ') || `Request failed (${res.status})`);
  return data;
}
let csrfToken='';
export async function getCsrf(){try{const r=await fetch(`${API}/csrf/`,{credentials:'include'});const d=await r.json();csrfToken=d.csrfToken||'';}catch{}return csrfToken;}
export const api={
  get:(p)=>request(p),
  post:(p,b)=>request(p,{method:'POST',body:JSON.stringify(b)}),
  patch:(p,b)=>request(p,{method:'PATCH',body:JSON.stringify(b)}),
  delete:(p)=>request(p,{method:'DELETE'}),
};

