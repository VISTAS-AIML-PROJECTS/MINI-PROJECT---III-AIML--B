
import React, { useEffect, useState } from 'react';
import {
  Gamepad2, Search, MapPin, Users, Clock, ArrowUpRight,
  LogIn, LogOut, CalendarDays, Monitor, Wallet, Plus,
  ShieldCheck, Zap, Menu, X
} from 'lucide-react';
import { api, getCsrf } from './api';

const money = n => `₹${Number(n || 0).toLocaleString('en-IN')}`;

const distanceKm = (a, b) => {
  if (
    a?.latitude == null || a?.longitude == null ||
    b?.latitude == null || b?.longitude == null
  ) return null;

  const rad = x => Number(x) * Math.PI / 180;
  const dLat = rad(Number(b.latitude) - Number(a.latitude));
  const dLon = rad(Number(b.longitude) - Number(a.longitude));
  const x =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(rad(Number(a.latitude))) *
    Math.cos(rad(Number(b.latitude))) *
    Math.sin(dLon / 2) ** 2;

  return 6371 * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
};

const bookingEndTime = b =>
  b.session_details?.ends_at ||
  b.session_details?.end_time ||
  b.ends_at ||
  b.end_time ||
  null;

const isUpcomingBooking = b => {
  const end = bookingEndTime(b);
  return Boolean(end && new Date(end).getTime() > Date.now());
};

function App() {
  const [user, setUser] = useState(null);
  const [centres, setCentres] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [games, setGames] = useState([]);
  const [query, setQuery] = useState('');
  const [view, setView] = useState('discover');
  const [modal, setModal] = useState('');
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);
  const [chosen, setChosen] = useState(null);
  const [players, setPlayers] = useState(1);
  const [privateMode, setPrivateMode] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState('customer');
  const [centreName, setCentreName] = useState('');
  const [address, setAddress] = useState('');
  const [consoles, setConsoles] = useState([]);
  const [ownerSessions, setOwnerSessions] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [ownerCentre, setOwnerCentre] = useState(null);
  const [userLocation, setUserLocation] = useState(null);
  const [locating, setLocating] = useState(false);
  const [ownerLatitude, setOwnerLatitude] = useState('');
  const [ownerLongitude, setOwnerLongitude] = useState('');

  const load = async () => {
    try {
      const [c, s, g] = await Promise.all([
        api.get('/centres/'),
        api.get('/sessions/'),
        api.get('/games/')
      ]);
      setCentres(c);
      setSessions(s);
      setGames(g);
    } catch (e) {
      setError('Cannot reach backend. Start Django at 127.0.0.1:8001. ' + e.message);
    }
  };

  useEffect(() => {
    getCsrf().then(() => load());
    api.get('/auth/me/').then(d => setUser(d.user)).catch(() => {});
  }, []);

  const refreshOwner = async () => {
    try {
      const [centre, c, s, b] = await Promise.all([
        api.get('/owner/centre/'),
        api.get('/owner/consoles/'),
        api.get('/owner/sessions/'),
        api.get('/owner/bookings/')
      ]);

      setOwnerCentre(centre);
      setOwnerLatitude(centre?.latitude ?? '');
      setOwnerLongitude(centre?.longitude ?? '');
      setConsoles(c);
      setOwnerSessions(s);
      setBookings(b);
    } catch (e) {
      setError(e.message);
    }
  };

  async function toggleCentre() {
    if (!ownerCentre?.id) return;
    setError('');

    try {
      const updated = await api.patch('/owner/centre/', {
        is_published: !ownerCentre.is_published
      });

      setOwnerCentre(updated);
      await load();
      setNotice(
        updated.is_published
          ? 'Your arena is now visible to customers.'
          : 'Your arena is hidden from customers.'
      );
    } catch (e) {
      setError(e.message);
    }
  }

  async function locateUser() {
    if (!navigator.geolocation) {
      setError('Location is not supported by this browser.');
      return;
    }

    setLocating(true);
    setError('');

    navigator.geolocation.getCurrentPosition(
      pos => {
        setUserLocation({
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude
        });
        setLocating(false);
        setNotice('Your location is enabled for nearby arena sorting.');
      },
      err => {
        setLocating(false);
        setError(
          err.code === 1
            ? 'Location permission was denied. Allow location access in your browser and try again.'
            : 'Could not get your location. Check device location settings and try again.'
        );
      },
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 60000 }
    );
  }

  async function locateOwner() {
    if (!navigator.geolocation) {
      setError('Location is not supported by this browser.');
      return;
    }

    setError('');

    navigator.geolocation.getCurrentPosition(
      pos => {
        setOwnerLatitude(pos.coords.latitude.toFixed(6));
        setOwnerLongitude(pos.coords.longitude.toFixed(6));
        setNotice('Coordinates filled in. Click Save map location to publish them.');
      },
      err => setError(
        err.code === 1
          ? 'Location permission was denied. Allow location access in your browser and try again.'
          : 'Could not get your location. Check device location settings and try again.'
      ),
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 60000 }
    );
  }

  async function saveOwnerLocation(e) {
    e.preventDefault();
    setError('');

    const lat = Number(ownerLatitude);
    const lon = Number(ownerLongitude);

    if (
      ownerLatitude === '' || ownerLongitude === '' ||
      !Number.isFinite(lat) || !Number.isFinite(lon) ||
      lat < -90 || lat > 90 || lon < -180 || lon > 180
    ) {
      setError('Enter valid coordinates: latitude −90 to 90 and longitude −180 to 180.');
      return;
    }

    try {
      const updated = await api.patch('/owner/centre/', {
        latitude: lat,
        longitude: lon
      });

      setOwnerCentre(updated);
      await load();
      setNotice('Map location saved. Customers can now find your arena by distance.');
    } catch (e) {
      setError(e.message);
    }
  }

  async function toggleConsole(c) {
    setError('');

    try {
      await api.patch(`/owner/consoles/${c.id}/`, {
        active: !c.active
      });
      await refreshOwner();
      await load();
      setNotice(`${c.name} is now ${c.active ? 'inactive' : 'active'}.`);
    } catch (e) {
      setError(e.message);
    }
  }

  async function toggleSession(s) {
    setError('');

    try {
      await api.patch(`/owner/sessions/${s.id}/`, {
        is_available: !s.is_available
      });
      await refreshOwner();
      await load();
      setNotice('Session availability updated.');
    } catch (e) {
      setError(e.message);
    }
  }

  useEffect(() => {
    if (user?.role === 'owner') refreshOwner();

    if (user?.role === 'customer') {
      api.get('/bookings/').then(setBookings).catch(() => {});
    }
  }, [user]);

  const filtered = centres
    .filter(c =>
      (c.name + ' ' + c.address).toLowerCase().includes(query.toLowerCase()) ||
      sessions.some(s =>
        s.centre_name === c.name &&
        s.game_name.toLowerCase().includes(query.toLowerCase())
      )
    )
    .sort((a, b) => {
      if (!userLocation) return 0;

      const da = distanceKm(userLocation, a);
      const db = distanceKm(userLocation, b);

      if (da == null) return 1;
      if (db == null) return -1;
      return da - db;
    });

  const filteredSessions = sessions.filter(s =>
    (!chosen || s.centre_name === chosen.name) &&
    (!query ||
      (s.centre_name + ' ' + s.game_name + ' ' + s.console_name)
        .toLowerCase()
        .includes(query.toLowerCase()))
  );

  async function authSubmit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');

    try {
      const d = modal === 'register'
        ? await api.post('/auth/register/', {
            name, email, password, role,
            centre_name: centreName, address
          })
        : await api.post('/auth/login/', { email, password });

      setUser(d.user);
      setModal('');
      setNotice(`Welcome ${d.user.name}`);
      setView(d.user.role === 'owner' ? 'owner' : 'discover');
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }

  async function logout() {
    try {
      await api.post('/auth/logout/', {});
    } catch {}

    setUser(null);
    setView('discover');
    setNotice('Signed out');
  }

  async function book(s) {
    if (!user) {
      setError('Please sign in as a customer to reserve player slots.');
      setModal('login');
      return;
    }

    setChosen(s);
    setModal('book');
    setPlayers(1);
    setPrivateMode(false);
    setError('');
  }

  async function createBooking() {
    setBusy(true);
    setError('');

    try {
      const b = await api.post('/booking/create/', {
        session: chosen.id,
        players: Number(players),
        is_private: privateMode
      });

      const order = await api.post('/payments/order/', {
        reference: b.reference
      });

      if (order.mode === 'mock') {
        const v = await api.post('/payments/verify/', {
          payment_id: order.payment_id,
          mock_success: true
        });

        setNotice(`Booking ${b.reference} confirmed in local mock mode.`);
        setModal('');
        setBookings(old => [v.booking, ...old]);
      } else {
        await new Promise((resolve, reject) => {
          const script = document.createElement('script');
          script.src = 'https://checkout.razorpay.com/v1/checkout.js';
          script.onload = resolve;
          script.onerror = () => reject(
            new Error('Could not load Razorpay Checkout. Check your connection.')
          );
          document.body.appendChild(script);
        });

        const checkout = new window.Razorpay({
          key: order.key_id,
          amount: order.amount,
          currency: order.currency,
          name: 'GamersDen',
          description: `Booking ${b.reference}`,
          order_id: order.order_id,
          handler: async response => {
            try {
              const verified = await api.post('/payments/verify/', {
                payment_id: order.payment_id,
                razorpay_order_id: response.razorpay_order_id,
                razorpay_payment_id: response.razorpay_payment_id,
                razorpay_signature: response.razorpay_signature
              });

              setNotice(`Booking ${verified.booking.reference} confirmed after payment verification.`);
              setBookings(old => [verified.booking, ...old]);
              setModal('');
              await load();
            } catch (err) {
              setError(err.message);
            }
          },
          modal: {
            ondismiss: () => setNotice(
              'Checkout closed. Your temporary hold may expire in 10 minutes.'
            )
          }
        });

        checkout.open();
      }

      await load();
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  }

  async function addConsole(e) {
    e.preventDefault();
    setError('');

    try {
      const form = new FormData(e.currentTarget);
      const selected = [...form.getAll('games')].map(Number);

      await api.post('/owner/consoles/', {
        name: form.get('name'),
        console_type: form.get('type'),
        max_players: Number(form.get('capacity')),
        pricing_model: form.get('pricing'),
        price: form.get('price'),
        session_minutes: Number(form.get('duration')),
        game_ids: selected
      });

      await refreshOwner();
      e.target?.reset?.();
      setNotice('Console added');
    } catch (e) {
      setError(e.message);
    }
  }

async function addSession(e) {
  e.preventDefault();
  setError('');
  setNotice('');

  try {
    const f = new FormData(e.currentTarget);
    const localStart = f.get('starts_at');
    const duration = Number(f.get('duration'));

    if (!localStart || !Number.isFinite(duration) || duration <= 0) {
      throw new Error('Please enter a valid session date, time and duration.');
    }

    // datetime-local represents the user's local wall-clock time.
    const start = new Date(localStart);

    if (Number.isNaN(start.getTime())) {
      throw new Error('Invalid session date or time.');
    }

    const end = new Date(start.getTime() + duration * 60000);

    if (start <= new Date()) {
      throw new Error('Please select a future session time.');
    }

    await api.post('/owner/sessions/', {
      console: Number(f.get('console')),
      game: Number(f.get('game')),
      starts_at: start.toISOString(),
      ends_at: end.toISOString(),
      capacity: Number(f.get('capacity')),
      is_available: true
    });

    await refreshOwner();
    await load();
    e.currentTarget.reset();
    setNotice('Session published successfully at the selected local time.');
  } catch (e) {
    setError(e.message);
  }
}


  const isOwner = user?.role === 'owner';
  const upcomingBookings = bookings.filter(isUpcomingBooking);

  return (
    <div className="app-shell">
      <header className="nav">
        <a className="brand" onClick={() => setView('discover')}>
          <span className="brand-mark"><Gamepad2 size={23} /></span>
          <span>
            GAMERS<span className="accent">DEN</span>
            <small>FIND YOUR ARENA</small>
          </span>
        </a>

        <nav>
          <button
            className={view === 'discover' ? 'nav-link active' : 'nav-link'}
            onClick={() => setView('discover')}
          >
            Discover
          </button>

          {user && (
            <button
              className={view === 'bookings' ? 'nav-link active' : 'nav-link'}
              onClick={() => setView('bookings')}
            >
              My bookings
            </button>
          )}

          {isOwner && (
            <button
              className={view === 'owner' ? 'nav-link active' : 'nav-link'}
              onClick={() => setView('owner')}
            >
              Owner studio
            </button>
          )}
        </nav>

        <div className="nav-actions">
          {user ? (
            <>
              <span className="user-pill">
                <span className="online-dot" />
                {user.name}
              </span>
              <button className="icon-btn" title="Sign out" onClick={logout}>
                <LogOut size={17} />
              </button>
            </>
          ) : (
            <>
              <button
                className="btn btn-ghost"
                onClick={() => { setModal('login'); setError(''); }}
              >
                Log in
              </button>
              <button
                className="btn btn-primary"
                onClick={() => { setModal('register'); setError(''); }}
              >
                Join the arena <ArrowUpRight size={16} />
              </button>
            </>
          )}
        </div>
      </header>

      <main>
        {view === 'discover' && (
          <>
            <section className="hero">
              <div className="hero-grid" />
              <div className="hero-copy">
                <div className="eyebrow">
                  <span className="pulse" /> THE NEXT LEVEL STARTS HERE
                </div>
                <h1>YOUR GAME.<br />YOUR <span className="gradient-text">ARENA.</span></h1>
                <p className="hero-sub">
                  Discover local gaming centres, claim your player slots, and get straight into the action.
                </p>

                <div className="hero-actions">
                  <button
                    className="btn btn-primary btn-large"
                    onClick={() => document.getElementById('discover')?.scrollIntoView({ behavior: 'smooth' })}
                  >
                    Explore arenas <ArrowUpRight size={18} />
                  </button>
                  <div className="proof">
                    <div className="avatar-stack">
                      <span>G</span><span>D</span><span>+</span>
                    </div>
                    <span>
                      <b>Find your squad.</b>
                      <small>Book solo or bring your team</small>
                    </span>
                  </div>
                </div>

                <div className="hero-stats">
                  <div><b>{centres.length.toString().padStart(2, '0')}</b><span>ARENAS</span></div>
                  <i />
                  <div><b>{sessions.length.toString().padStart(2, '0')}</b><span>SESSIONS</span></div>
                  <i />
                  <div><b>{games.length.toString().padStart(2, '0')}</b><span>GAMES</span></div>
                </div>
              </div>

              <div className="hero-art">
                <div className="orbit orbit-one" />
                <div className="orbit orbit-two" />
                <div className="hero-console">
                  <div className="console-top"><span /><span /><span /></div>
                  <Gamepad2 size={104} strokeWidth={1.1} />
                  <div className="console-light" />
                </div>
                <div className="floating-card fc-top">
                  <Zap size={15} /><span>READY TO PLAY</span><b>LET'S GO</b>
                </div>
                <div className="floating-card fc-bottom">
                  <Users size={17} />
                  <div><b>Shared sessions</b><small>Play together, pay your share</small></div>
                </div>
                <div className="hero-cross">✳</div>
              </div>
              <div className="hero-bottom-line" />
            </section>

            <section className="discover-section" id="discover">
              <div className="section-head">
                <div>
                  <div className="eyebrow">PICK YOUR PLAYGROUND</div>
                  <h2>Find your <span className="gradient-text">next arena.</span></h2>
                  <p>Real centres and live sessions from the GamersDen database.</p>
                </div>

                <div style={{
                  display: 'flex', gap: 10, alignItems: 'center',
                  flexWrap: 'wrap', justifyContent: 'flex-end'
                }}>
                  <div className="searchbox">
                    <Search size={18} />
                    <input
                      value={query}
                      onChange={e => setQuery(e.target.value)}
                      placeholder="Search centre, area, or game..."
                    />
                    <kbd>↵</kbd>
                  </div>
                  <button className="btn btn-card" onClick={locateUser} disabled={locating}>
                    <MapPin size={16} />
                    {locating ? 'Locating…' : userLocation ? 'Refresh my location' : 'Use my location'}
                  </button>
                </div>
              </div>

              {error && <div className="alert error">{error}<button onClick={() => setError('')}>×</button></div>}
              {notice && <div className="alert success">{notice}<button onClick={() => setNotice('')}>×</button></div>}

              <div className="centre-grid">
                {filtered.map((c, i) => (
                  <article className="centre-card" key={c.id}>
                    <div className={`centre-art art-${i % 3}`}>
                      <div className="art-lines" />
                      <span className="art-chip"><Monitor size={14} /> GAMING LOUNGE</span>
                      <span className="art-index">0{i + 1}</span>
                      <div className="art-glyph"><Gamepad2 size={66} /></div>
                    </div>

                    <div className="centre-info">
                      <div className="centre-title">
                        <div>
                          <h3>{c.name}</h3>
                          <p><MapPin size={14} />{c.address}</p>

                          {userLocation && distanceKm(userLocation, c) != null && (
                            <small style={{ display: 'block', marginTop: 6, color: 'var(--muted,#777)' }}>
                              {distanceKm(userLocation, c).toFixed(1)} km away
                            </small>
                          )}

                          {c.latitude != null && c.longitude != null && (
                            <a
                              href={`https://www.google.com/maps/dir/?api=1&destination=${c.latitude},${c.longitude}`}
                              target="_blank"
                              rel="noreferrer"
                              style={{ display: 'inline-block', marginTop: 6, fontSize: 13 }}
                            >
                              Open in Maps ↗
                            </a>
                          )}
                        </div>
                        <span className="available-tag"><span />LIVE</span>
                      </div>

                      <p className="centre-desc">
                        {c.description || 'A gaming destination ready for your next session.'}
                      </p>

                      <div className="card-meta">
                        <span>
                          <Monitor size={15} />
                          {[...new Set(sessions.filter(s => s.centre_name === c.name).map(s => s.console_name))].length || '—'} setups
                        </span>
                        <span>
                          <Gamepad2 size={15} />
                          {[...new Set(sessions.filter(s => s.centre_name === c.name).map(s => s.game_name))].length || '—'} games
                        </span>
                      </div>

                      <button
                        className="btn btn-card"
                        onClick={() => {
                          setChosen(c);
                          setQuery('');
                          document.getElementById('sessions')?.scrollIntoView({ behavior: 'smooth' });
                        }}
                      >
                        View sessions <ArrowUpRight size={16} />
                      </button>
                    </div>
                  </article>
                ))}
              </div>

              {filtered.length === 0 && (
                <div className="empty-state">
                  <Gamepad2 size={38} />
                  <h3>No arenas found</h3>
                  <p>Try another search, or start the backend and seed demo data.</p>
                  <button className="btn btn-ghost" onClick={() => { setQuery(''); load(); }}>
                    Reset search
                  </button>
                </div>
              )}

              <div className="section-head sessions-head" id="sessions">
                <div>
                  <div className="eyebrow">PLAYER SLOTS OPEN</div>
                  <h2>Sessions in the <span className="gradient-text">queue.</span></h2>
                  <p>Join a shared session or reserve a private run.</p>
                </div>
                <span className="count-pill">{filteredSessions.length} sessions listed</span>
              </div>

              <div className="session-list">
                {filteredSessions.map(s => (
                  <div className="session-row" key={s.id}>
                    <div className="session-icon"><Gamepad2 size={22} /></div>
                    <div className="session-main">
                      <b>{s.console_games?.length ? s.console_games.map(g => g.name).join(', ') : s.game_name}</b>
                      <span>{s.centre_name} · {s.console_name}</span>
                    </div>
                    <div className="session-time">
                      <Clock size={15} />
                      <span>{new Date(s.starts_at).toLocaleString([], {
                        weekday: 'short', hour: '2-digit', minute: '2-digit',
                        month: 'short', day: 'numeric'
                      })}</span>
                    </div>
                    <div className="capacity">
                      <div className="capacity-label">
                        <Users size={15} /><b>{s.available_players} slots left</b><span>/ {s.capacity}</span>
                      </div>
                      <div className="capacity-bar">
                        <span style={{ width: `${Math.min(100, (s.booked_players / s.capacity) * 100)}%` }} />
                      </div>
                    </div>
                    <div className="session-price">
                      <b>{money(s.price)}</b>
                      <small>{s.price_override ? 'session price' : 'console price'}</small>
                    </div>
                    <button
                      className="btn btn-primary reserve-btn"
                      disabled={!s.available_players}
                      onClick={() => book(s)}
                    >
                      {s.available_players ? 'Reserve' : 'Full'} <ArrowUpRight size={15} />
                    </button>
                  </div>
                ))}
              </div>

              {filteredSessions.length === 0 && (
                <div className="empty-inline">
                  No matching sessions. Ask a centre owner to publish availability.
                </div>
              )}
            </section>

            <section className="shared-banner">
              <div className="shared-icon"><Users size={30} /></div>
              <div>
                <div className="eyebrow">THE MORE, THE MERRIER</div>
                <h2>One console. <span className="gradient-text">Multiple squads.</span></h2>
                <p>
                  Book only the player slots you need. Other gamers can join compatible shared sessions — capacity stays protected.
                </p>
              </div>
              <div className="slot-demo">
                <div className="slot-dots">
                  <span className="filled" /><span className="filled" /><span /><span />
                </div>
                <b>2 <small>/ 4 PLAYERS</small></b>
                <span className="open-slots">2 slots open</span>
              </div>
            </section>
          </>
        )}

        {view === 'owner' && (
          <section className="dashboard">
            <div className="section-head">
              <div>
                <div className="eyebrow">CENTRE MANAGEMENT</div>
                <h2>Owner <span className="gradient-text">studio.</span></h2>
                <p>Your arena, your rules. Manage equipment and publish sessions.</p>
              </div>
              <span className="count-pill">OWNER ACCESS</span>
            </div>

            {error && <div className="alert error">{error}<button onClick={() => setError('')}>×</button></div>}
            {notice && <div className="alert success">{notice}<button onClick={() => setNotice('')}>×</button></div>}

            <div className="panel list-panel">
              <div className="panel-head">
                <h3>Centre visibility</h3>
                <span className="tag">{ownerCentre?.is_published ? 'PUBLISHED' : 'HIDDEN'}</span>
              </div>

              <div
                className="inventory-row centre-visibility-row"
                style={{
                  display: 'grid',
                  gridTemplateColumns: '32px minmax(0, 1fr) auto',
                  alignItems: 'center',
                  gap: 16,
                  width: '100%'
                }}
              >
                <ShieldCheck style={{ flexShrink: 0 }} />
                <div style={{
                  minWidth: 0, width: '100%', display: 'flex',
                  flexDirection: 'column', gap: 6, overflowWrap: 'anywhere'
                }}>
                  <b style={{ display: 'block', whiteSpace: 'normal' }}>
                    {ownerCentre?.name || 'Your arena'}
                  </b>
                  <span style={{ display: 'block', whiteSpace: 'normal', overflowWrap: 'anywhere' }}>
                    {ownerCentre?.address || 'Centre details unavailable'} · {ownerCentre?.is_published ? 'Visible in Discover' : 'Hidden from customer listings'}
                  </span>
                </div>
                <button
                  className="btn btn-card"
                  style={{ whiteSpace: 'nowrap', width: 'auto', justifySelf: 'end' }}
                  onClick={toggleCentre}
                  disabled={!ownerCentre}
                >
                  {ownerCentre?.is_published ? 'Hide arena' : 'Publish arena'}
                </button>
              </div>
            </div>

            <div className="panel list-panel">
              <div className="panel-head">
                <h3><MapPin size={18} /> Arena map location</h3>
                <span className="tag">NEARBY SEARCH</span>
              </div>
              <p className="muted">
                Set your arena coordinates so customers can sort centres by distance and open directions in Maps.
              </p>

              <form onSubmit={saveOwnerLocation} className="form-grid">
                <label>
                  Latitude
                  <input
                    type="number" step="any" min="-90" max="90"
                    value={ownerLatitude}
                    onChange={e => setOwnerLatitude(e.target.value)}
                    placeholder="e.g. 13.0827"
                    required
                  />
                </label>
                <label>
                  Longitude
                  <input
                    type="number" step="any" min="-180" max="180"
                    value={ownerLongitude}
                    onChange={e => setOwnerLongitude(e.target.value)}
                    placeholder="e.g. 80.2707"
                    required
                  />
                </label>
                <button type="button" className="btn btn-card" onClick={locateOwner}>
                  <MapPin size={16} /> Use this device's location
                </button>
                <button type="submit" className="btn btn-primary form-submit">
                  Save map location <ArrowUpRight size={16} />
                </button>
              </form>

              {ownerCentre?.latitude != null && ownerCentre?.longitude != null && (
                <p className="tiny-note">
                  Saved coordinates: {ownerCentre.latitude}, {ownerCentre.longitude} ·{' '}
                  <a
                    href={`https://www.google.com/maps/search/?api=1&query=${ownerCentre.latitude},${ownerCentre.longitude}`}
                    target="_blank"
                    rel="noreferrer"
                  >
                    Preview in Maps ↗
                  </a>
                </p>
              )}
            </div>

            <div className="metric-grid">
              <div className="metric"><span>Total consoles</span><b>{consoles.length}</b><Monitor /></div>
              <div className="metric"><span>Published sessions</span><b>{ownerSessions.length}</b><CalendarDays /></div>
              <div className="metric"><span>Bookings</span><b>{bookings.length}</b><Users /></div>
              <div className="metric">
                <span>Verified revenue</span><b>{money(0)}</b><Wallet />
                <small>Revenue summary API available</small>
              </div>
            </div>

            <div className="owner-columns">
              <div className="panel">
                <div className="panel-head">
                  <h3><Plus size={18} /> Add a console</h3>
                  <span className="tag">EQUIPMENT</span>
                </div>

                <form onSubmit={addConsole} className="form-grid">
                  <label>Console name<input name="name" required placeholder="PS5 Arena 02" /></label>
                  <label>
                    Console type
                    <select name="type">
                      <option>PS5</option><option>PS4</option><option>Xbox</option><option>PC</option>
                    </select>
                  </label>
                  <label>Player capacity<input name="capacity" type="number" min="1" max="16" defaultValue="4" required /></label>
                  <label>Price (INR)<input name="price" type="number" min="0" step=".01" defaultValue="150" required /></label>
                  <label>
                    Pricing model
                    <select name="pricing">
                      <option value="per_player">Per player</option>
                      <option value="per_session">Per session</option>
                    </select>
                  </label>
                  <label>
                    Session duration
                    <select name="duration">
                      <option value="60">60 minutes</option><option value="30">30 minutes</option>
                      <option value="90">90 minutes</option><option value="120">120 minutes</option>
                    </select>
                  </label>
                  <fieldset className="games-field">
                    <legend>Supported games</legend>
                    <div className="game-checks">
                      {games.map(g => (
                        <label key={g.id}>
                          <input type="checkbox" name="games" value={g.id} />{g.name}
                        </label>
                      ))}
                    </div>
                  </fieldset>
                  <button className="btn btn-primary form-submit">Add console <Plus size={16} /></button>
                </form>
              </div>

              <div className="panel">
                <div className="panel-head">
                  <h3><CalendarDays size={18} /> Publish a session</h3>
                  <span className="tag">AVAILABILITY</span>
                </div>

                <form onSubmit={addSession} className="form-grid">
                  <label>
                    Console
                    <select name="console" required>
                      {consoles.map(c => (
                        <option key={c.id} value={c.id}>{c.name} · {c.console_type}</option>
                      ))}
                    </select>
                  </label>
                  <label>
                    Game
                    <select name="game" required>
                      {games.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
                    </select>
                  </label>
                  <label className="full">Start date & time<input name="starts_at" type="datetime-local" required /></label>
                  <label>
                    Duration
                    <select name="duration">
                      <option value="60">60 minutes</option><option value="30">30 minutes</option>
                      <option value="90">90 minutes</option><option value="120">120 minutes</option>
                    </select>
                  </label>
                  <label>Capacity<input name="capacity" type="number" min="1" max="16" defaultValue="4" required /></label>
                  <button className="btn btn-primary form-submit">Publish availability <ArrowUpRight size={16} /></button>
                </form>
              </div>
            </div>

            <div className="panel list-panel">
              <div className="panel-head">
                <h3>Console inventory</h3>
                <span className="tag">{consoles.length} ITEMS</span>
              </div>

              {consoles.map(c => (
                <div
                  className="inventory-row"
                  key={c.id}
                  style={{
                    display: 'grid',
                    gridTemplateColumns: '36px minmax(0, 1fr) auto auto',
                    alignItems: 'center',
                    gap: 16,
                    width: '100%',
                    boxSizing: 'border-box',
                    padding: 16
                  }}
                >
                  <Monitor />
                  <div style={{ minWidth: 0, overflowWrap: 'anywhere' }}>
                    <b>{c.name}</b>
                    <span>{c.console_type} · {c.max_players} players · {c.games.map(g => g.name).join(', ') || 'No games selected'}</span>
                  </div>
                  <strong style={{ whiteSpace: 'nowrap' }}>
                    {money(c.price)}<small> / {c.pricing_model === 'per_player' ? 'player' : 'session'}</small>
                  </strong>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
                    <button className="btn btn-card" onClick={() => toggleConsole(c)}>
                      {c.active ? 'Deactivate' : 'Activate'}
                    </button>
                    <span className="tag">{c.active ? 'ACTIVE' : 'INACTIVE'}</span>
                  </div>
                </div>
              ))}

              {!consoles.length && <p className="empty-inline">No consoles yet. Add one above.</p>}
            </div>

            <div className="panel list-panel">
              <div className="panel-head">
                <h3>Session availability</h3>
                <span className="tag">{ownerSessions.length} SESSIONS</span>
              </div>

              {ownerSessions.map(s => (
                <div
                  className="inventory-row"
                  key={s.id}
                  style={{
                    display: 'grid',
                    gridTemplateColumns: '36px minmax(0, 1fr) auto',
                    alignItems: 'center',
                    gap: 16,
                    width: '100%',
                    boxSizing: 'border-box',
                    padding: 16
                  }}
                >
                  <CalendarDays />
                  <div style={{ minWidth: 0, overflowWrap: 'anywhere' }}>
                    <b>{s.game_name} · {s.console_name}</b>
                    <span>
                      {s.centre_name} · {new Date(s.starts_at).toLocaleString()} ·{' '}
                      {s.is_available ? 'Available for booking' : 'Unavailable'}
                    </span>
                  </div>
                  <button className="btn btn-card" onClick={() => toggleSession(s)}>
                    {s.is_available ? 'Disable' : 'Enable'}
                  </button>
                </div>
              ))}

              {!ownerSessions.length && <p className="empty-inline">No sessions created yet.</p>}
            </div>

            {/* Corrected Upcoming bookings panel */}
            <div className="panel list-panel">
              <div className="panel-head">
                <h3>Upcoming bookings</h3>
                <span className="tag">{upcomingBookings.length} UPCOMING</span>
              </div>

              {upcomingBookings.map(b => (
                <div className="inventory-row" key={b.id}>
                  <CalendarDays />
                  <div>
                    <b>{b.reference} · {b.session_details?.game_name || 'Gaming session'}</b>
                    <span>{b.players} players · {b.status}</span>
                  </div>
                  <strong>{money(b.amount)}</strong>
                </div>
              ))}

              {!upcomingBookings.length && (
                <p className="empty-inline">No upcoming bookings.</p>
              )}
            </div>
          </section>
        )}

        {view === 'bookings' && (
          <section className="dashboard">
            <div className="eyebrow">YOUR PLAY HISTORY</div>
            <h2>My <span className="gradient-text">bookings.</span></h2>
            <p className="muted">Your reservations and payment states.</p>

            {bookings.map(b => (
              <div className="booking-card" key={b.id}>
                <div className="session-icon"><CalendarDays /></div>
                <div>
                  <b>{b.reference}</b>
                  <p>{b.session_details?.game_name} · {b.session_details?.centre_name}</p>
                  <span>{b.players} player(s) · {b.status} · payment: {b.payment_status}</span>
                </div>
                <strong>{money(b.amount)}</strong>
              </div>
            ))}

            {!bookings.length && (
              <div className="empty-state">
                <CalendarDays />
                <h3>No bookings yet</h3>
                <p>Reserve your first player slots from Discover.</p>
                <button className="btn btn-primary" onClick={() => setView('discover')}>
                  Explore arenas
                </button>
              </div>
            )}
          </section>
        )}
      </main>

      <footer>
        <a className="brand" onClick={() => setView('discover')}>
          <span className="brand-mark"><Gamepad2 size={20} /></span>
          <span>GAMERS<span className="accent">DEN</span><small>FIND YOUR ARENA</small></span>
        </a>
        <span>BUILT FOR THE NEXT ROUND <b>✳</b></span>
        <span>© 2026 GAMERSDEN</span>
      </footer>

      {modal && (
        <div className="modal-backdrop">
          <div className="modal" onClick={e => e.stopPropagation()}>
            <button className="modal-close" onClick={() => setModal('')}><X size={19} /></button>

            {modal === 'book' ? (
              <>
                <div className="modal-symbol"><Gamepad2 /></div>
                <div className="eyebrow">LOCK IN YOUR SESSION</div>
                <h2>Claim your <span className="gradient-text">slots.</span></h2>
                <p className="muted">{chosen?.game_name} · {chosen?.centre_name} · {chosen?.console_name}</p>

                <div className="booking-summary">
                  <span>Available player slots</span>
                  <b>{chosen?.available_players} / {chosen?.capacity}</b>
                  <div className="capacity-bar">
                    <span style={{ width: `${(chosen?.booked_players / chosen?.capacity) * 100}%` }} />
                  </div>
                  <span>Session starts {chosen && new Date(chosen.starts_at).toLocaleString()}</span>
                </div>

                <label>
                  Number of players
                  <select
                    value={players}
                    disabled={privateMode}
                    onChange={e => setPlayers(Number(e.target.value))}
                  >
                    {Array.from({ length: Math.max(0, chosen?.available_players || 0) }, (_, i) => (
                      <option key={i} value={i + 1}>{i + 1} player{i ? 's' : ''}</option>
                    ))}
                  </select>
                </label>

                <label className="private-check">
                  <input
                    type="checkbox"
                    checked={privateMode}
                    onChange={e => {
                      setPrivateMode(e.target.checked);
                      if (e.target.checked) setPlayers(chosen?.capacity || 1);
                      else setPlayers(1);
                    }}
                  />
                  Make this a private session <small>(uses all slots)</small>
                </label>

                <div className="total-line">
                  <span>Estimated total</span>
                  <b>{money((chosen?.price || 0) * (chosen?.pricing_model === 'per_session' ? 1 : (players || 1)))}</b>
                </div>
                <p className="tiny-note">Final amount is recalculated by the server. Payment must be verified before confirmation.</p>
                {error && <div className="alert error">{error}</div>}

                <button
                  className="btn btn-primary btn-large wide"
                  disabled={busy || !players || players > chosen?.available_players}
                  onClick={createBooking}
                >
                  {busy ? 'Processing...' : 'Reserve & continue'} <ArrowUpRight size={17} />
                </button>
              </>
            ) : (
              <>
                <div className="modal-symbol"><Gamepad2 /></div>
                <div className="eyebrow">
                  {modal === 'register' ? 'CREATE YOUR PLAYER ID' : 'WELCOME BACK, PLAYER'}
                </div>
                <h2>
                  {modal === 'register' ? 'Join the' : 'Enter the'}{' '}
                  <span className="gradient-text">arena.</span>
                </h2>

                <form className="auth-form" onSubmit={authSubmit}>
                  {modal === 'register' && (
                    <>
                      <label>
                        Full name
                        <input value={name} onChange={e => setName(e.target.value)} required placeholder="Your gamer name" />
                      </label>
                      <label>
                        Account type
                        <select value={role} onChange={e => setRole(e.target.value)}>
                          <option value="customer">Gamer / customer</option>
                          <option value="owner">Gaming centre owner</option>
                        </select>
                      </label>

                      {role === 'owner' && (
                        <>
                          <label>
                            Gaming centre name
                            <input value={centreName} onChange={e => setCentreName(e.target.value)} required />
                          </label>
                          <label>
                            Centre address
                            <input value={address} onChange={e => setAddress(e.target.value)} required />
                          </label>
                        </>
                      )}
                    </>
                  )}

                  <label>
                    Email address
                    <input type="email" value={email} onChange={e => setEmail(e.target.value)} required placeholder="you@example.com" />
                  </label>
                  <label>
                    Password
                    <input type="password" value={password} onChange={e => setPassword(e.target.value)} required minLength={8} placeholder="At least 8 characters" />
                  </label>

                  {error && <div className="alert error">{error}</div>}

                  <button className="btn btn-primary btn-large wide" disabled={busy}>
                    {busy ? 'One moment...' : modal === 'register' ? 'Create account' : 'Log in'} <ArrowUpRight size={17} />
                  </button>
                </form>

                <p className="switch-auth">
                  {modal === 'register' ? 'Already have an account?' : 'New to GamersDen?'}{' '}
                  <button onClick={() => {
                    setModal(modal === 'register' ? 'login' : 'register');
                    setError('');
                  }}>
                    {modal === 'register' ? 'Log in' : 'Create account'}
                  </button>
                </p>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
