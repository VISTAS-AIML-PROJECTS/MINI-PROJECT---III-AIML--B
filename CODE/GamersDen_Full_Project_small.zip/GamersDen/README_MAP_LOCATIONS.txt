GamersDen map locations and nearby-centre patch

Includes owner coordinate editor, browser geolocation for owners, customer Use my location action, distance-sorted centre cards, km distance labels, Google Maps directions links, Centre latitude/longitude fields, serializer fields, and a migration.

Apply safely:
1. Back up the project and database.
2. Extract this ZIP into the GamersDen project root, preserving folders. It contains frontend/src/App.jsx, backend/core/models.py, backend/core/serializers.py, and backend/core/migrations/0002_centre_map_coordinates.py. Review/merge before replacing existing files.
3. Check that backend/core/migrations/0001_initial.py exists. If your migration numbering differs, update the dependency in 0002_centre_map_coordinates.py to your latest existing core migration.
4. In a backend terminal with .venv active, run: python manage.py migrate
5. Restart Django and Vite.
6. Sign in as the centre owner, open Owner Studio > Arena map location, click Use this device's location (or enter latitude/longitude manually), then click Save map location. Browser location permission is required.
7. As a customer, click Use my location on Discover and allow location permission. Centres with coordinates are sorted by distance and display km away. Centres without coordinates remain listed after mapped centres.

Privacy: customer location is used only in the current browser session and is not sent to the backend. Owner coordinates are saved to the centre record. Google Maps opens in a new tab. Browser geolocation normally requires localhost or HTTPS.
