from rest_framework import serializers
from django.contrib.auth.models import User
from .models import Profile, Centre, Game, Console, Session, Booking, Payment

class RegisterSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=150)
    email = serializers.EmailField()
    password = serializers.CharField(min_length=8, write_only=True)
    role = serializers.ChoiceField(choices=["customer","owner"])
    phone = serializers.CharField(required=False, allow_blank=True)
    centre_name = serializers.CharField(required=False, allow_blank=True)
    address = serializers.CharField(required=False, allow_blank=True)
    def validate_email(self, value):
        if User.objects.filter(username__iexact=value).exists(): raise serializers.ValidationError("An account with this email already exists.")
        return value.lower()
    def validate(self, attrs):
        if attrs["role"] == "owner" and (not attrs.get("centre_name") or not attrs.get("address")):
            raise serializers.ValidationError("Centre name and address are required for owner registration.")
        return attrs
    def create(self, data):
        user = User.objects.create_user(username=data["email"], email=data["email"], password=data["password"], first_name=data["name"])
        Profile.objects.create(user=user, role=data["role"], phone=data.get("phone",""))
        if data["role"] == "owner":
            Centre.objects.create(owner=user, name=data["centre_name"], address=data["address"])
        return user

class UserSerializer(serializers.ModelSerializer):
    role = serializers.SerializerMethodField()
    name = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = ["id", "username", "email", "name", "role"]

    def get_role(self, obj):
        return getattr(getattr(obj, "profile", None), "role", "customer")

    def get_name(self, obj):
        if not obj.is_authenticated:
            return ""
        return obj.get_full_name() or obj.username

class CentreSerializer(serializers.ModelSerializer):
    owner_name = serializers.CharField(source="owner.first_name", read_only=True)
    class Meta:
        model = Centre
        fields = ["id","name","address","description","opening_time","closing_time","is_published","latitude","longitude","owner_name"]

class GameSerializer(serializers.ModelSerializer):
    class Meta: model = Game; fields = ["id","name"]

class ConsoleSerializer(serializers.ModelSerializer):
    games = GameSerializer(many=True, read_only=True)
    game_ids = serializers.PrimaryKeyRelatedField(many=True, queryset=Game.objects.all(), source="games", write_only=True, required=False)
    centre_name = serializers.CharField(source="centre.name", read_only=True)
    class Meta:
        model = Console
        fields = ["id","centre","centre_name","name","console_type","max_players","games","game_ids","pricing_model","price","session_minutes","active"]
        read_only_fields = ["centre"]
    def validate(self, attrs):
        if attrs.get("max_players", 1) < 1: raise serializers.ValidationError("Player capacity must be at least 1.")
        if attrs.get("price", 0) < 0: raise serializers.ValidationError("Price cannot be negative.")
        return attrs

class SessionSerializer(serializers.ModelSerializer):
    console_name = serializers.CharField(source="console.name", read_only=True)
    centre_name = serializers.CharField(source="console.centre.name", read_only=True)
    game_name = serializers.CharField(source="game.name", read_only=True)
    console_games = GameSerializer(source="console.games", many=True, read_only=True)
    booked_players = serializers.SerializerMethodField()
    available_players = serializers.SerializerMethodField()
    price = serializers.SerializerMethodField()
    pricing_model = serializers.SerializerMethodField()
    class Meta:
        model = Session
        fields = ["id","console","console_name","centre_name","game","game_name","console_games","starts_at","ends_at","capacity","is_private","is_available","price_override","booked_players","available_players","price","pricing_model"]
    def get_booked_players(self,obj):
        from .services import active_players
        return active_players(obj)
    def get_available_players(self,obj):
        from .services import active_players
        return max(0, obj.capacity - active_players(obj))
    def get_price(self,obj): return str(obj.price_override if obj.price_override is not None else obj.console.price)
    def get_pricing_model(self,obj): return obj.console.pricing_model

class BookingSerializer(serializers.ModelSerializer):
    session_details = SessionSerializer(source="session", read_only=True)
    payment_status = serializers.SerializerMethodField()
    class Meta:
        model = Booking
        fields = ["id","reference","customer","session","session_details","players","is_private","status","amount","hold_expires_at","created_at","payment_status"]
        read_only_fields = fields
    def get_payment_status(self,obj):
        p=obj.payments.order_by("-created_at").first()
        return p.status if p else "not_started"
