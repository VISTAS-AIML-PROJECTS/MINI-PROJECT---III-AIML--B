from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [("core", "0001_initial")]
    operations = [
        migrations.AddField(model_name="centre", name="latitude", field=models.DecimalField(blank=True, decimal_places=6, max_digits=9, null=True)),
        migrations.AddField(model_name="centre", name="longitude", field=models.DecimalField(blank=True, decimal_places=6, max_digits=9, null=True)),
    ]
