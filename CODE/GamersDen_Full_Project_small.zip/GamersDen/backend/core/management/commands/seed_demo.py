from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from core.models import Centre, Console, Session


class Command(BaseCommand):
    help = "Safely hide the built-in demo arena without deleting bookings or database records."

    def handle(self, *args, **kwargs):
        owner = User.objects.filter(username="owner@example.com").first()
        if not owner:
            self.stdout.write(self.style.WARNING("No built-in demo owner found; nothing changed."))
            return

        centre = Centre.objects.filter(owner=owner).first()
        if not centre:
            self.stdout.write(self.style.WARNING("No built-in demo arena found; nothing changed."))
            return

        # Preserve records and booking history; only remove demo availability from public listings.
        if centre.is_published:
            centre.is_published = False
            centre.save(update_fields=["is_published"])

        Console.objects.filter(centre=centre).update(active=False)
        Session.objects.filter(console__centre=centre).update(is_available=False)

        self.stdout.write(self.style.SUCCESS(
            "Built-in demo arena hidden; its consoles and sessions disabled. No records or bookings were deleted."
        ))
