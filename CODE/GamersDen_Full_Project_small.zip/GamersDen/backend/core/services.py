from datetime import timedelta
from decimal import Decimal
from django.db import transaction
from django.utils import timezone
from rest_framework.exceptions import ValidationError
from .models import Session, Booking, Payment

def active_players(session):
    now = timezone.now()
    qs = Booking.objects.filter(session=session).filter(
        models_q_active(now)
    )
    return sum(qs.values_list("players", flat=True))

def models_q_active(now):
    from django.db.models import Q
    return (Q(status="confirmed") | Q(status="pending", hold_expires_at__gt=now))

@transaction.atomic
def create_booking(*, customer, session_id, players, is_private=False):
    # select_for_update serializes capacity checks on databases that support row locks.
    session = Session.objects.select_for_update().select_related("console").get(pk=session_id)
    if not session.is_available or not session.console.active:
        raise ValidationError("This session is not available.")
    if players < 1 or players > session.capacity:
        raise ValidationError("Choose a valid number of players.")
    now = timezone.now()
    active = Booking.objects.filter(session=session).filter(models_q_active(now))
    if active.filter(is_private=True).exists() or (session.is_private and active.exists()):
        raise ValidationError("This private session is already reserved.")
    if is_private and active.exists():
        raise ValidationError("A private session cannot be booked after another group has joined.")
    if is_private and players != session.capacity:
        raise ValidationError("A private booking must reserve all player slots.")
    if active_players(session) + players > session.capacity:
        raise ValidationError(f"Only {max(0, session.capacity-active_players(session))} player slots remain.")
    console = session.console
    unit_price = session.price_override if session.price_override is not None else console.price
    amount = unit_price * players if console.pricing_model == "per_player" else unit_price
    booking = Booking.objects.create(customer=customer, session=session, players=players, is_private=is_private,
        amount=amount.quantize(Decimal("0.01")), hold_expires_at=timezone.now()+timedelta(minutes=10))
    return booking

def expire_holds():
    now=timezone.now()
    Booking.objects.filter(status="pending", hold_expires_at__lte=now).update(status="expired")
    Payment.objects.filter(booking__status="expired", status__in=["initiated","pending"]).update(status="failed")
