from django.test import TestCase
from django.contrib.auth.models import User
from django.utils import timezone
from datetime import timedelta
from rest_framework.test import APIClient
from .models import Profile,Centre,Game,Console,Session,Booking
from .services import create_booking
from rest_framework.exceptions import ValidationError

class BookingCapacityTests(TestCase):
    def setUp(self):
        self.customer=User.objects.create_user("gamer@example.com",password="GamerPass123!")
        Profile.objects.create(user=self.customer,role="customer")
        self.owner=User.objects.create_user("owner@example.com",password="OwnerPass123!")
        Profile.objects.create(user=self.owner,role="owner")
        centre=Centre.objects.create(owner=self.owner,name="Test Centre",address="Chennai")
        game=Game.objects.create(name="EA Sports FC")
        console=Console.objects.create(centre=centre,name="PS5",console_type="PS5",max_players=4,price=100)
        console.games.add(game)
        self.session=Session.objects.create(console=console,game=game,starts_at=timezone.now()+timedelta(hours=2),
            ends_at=timezone.now()+timedelta(hours=3),capacity=4)
    def test_two_groups_can_fill_four_slots(self):
        a=create_booking(customer=self.customer,session_id=self.session.id,players=2)
        buser=User.objects.create_user("second@example.com",password="Password123!")
        Profile.objects.create(user=buser,role="customer")
        b=create_booking(customer=buser,session_id=self.session.id,players=2)
        self.assertEqual(a.players+b.players,4)
        with self.assertRaises(ValidationError):
            create_booking(customer=self.customer,session_id=self.session.id,players=1)
    def test_private_booking_excludes_other_group(self):
        create_booking(customer=self.customer,session_id=self.session.id,players=4,is_private=True)
        other=User.objects.create_user("other@example.com",password="Password123!")
        Profile.objects.create(user=other,role="customer")
        with self.assertRaises(ValidationError):
            create_booking(customer=other,session_id=self.session.id,players=1)
    def test_role_protected_owner_api(self):
        c=APIClient()
        c.force_authenticate(self.customer)
        response=c.get("/api/owner/consoles/")
        self.assertEqual(response.status_code,403)
