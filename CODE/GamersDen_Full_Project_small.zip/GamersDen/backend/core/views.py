import json, hmac, hashlib
from decimal import Decimal
from django.conf import settings
from django.contrib.auth import authenticate, login, logout
from django.db import transaction
from django.db.models import Q
from django.http import JsonResponse, HttpResponse
from django.utils import timezone
from rest_framework import status, viewsets
from rest_framework.exceptions import ValidationError
from rest_framework.decorators import api_view, permission_classes, action
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import Profile, Centre, Game, Console, Session, Booking, Payment
from .serializers import RegisterSerializer, UserSerializer, CentreSerializer, GameSerializer, ConsoleSerializer, SessionSerializer, BookingSerializer
from .permissions import IsOwner
from .services import create_booking, expire_holds

@api_view(["GET"])
@permission_classes([AllowAny])
def health(request): return Response({"status":"ok","service":"GamersDen API"})

@api_view(["GET"])
@permission_classes([AllowAny])
def csrf(request):
    from django.middleware.csrf import get_token
    return Response({"csrfToken":get_token(request)})

class RegisterView(APIView):
    permission_classes=[AllowAny]
    def post(self, request):
        s=RegisterSerializer(data=request.data); s.is_valid(raise_exception=True)
        user=s.save(); login(request,user)
        return Response({"user":UserSerializer(user).data},status=201)

class LoginView(APIView):
    permission_classes=[AllowAny]
    def post(self, request):
        email=(request.data.get("email") or "").lower()
        user=authenticate(request, username=email, password=request.data.get("password",""))
        if not user: return Response({"detail":"Invalid email or password."},status=400)
        login(request,user)
        return Response({"user":UserSerializer(user).data})

@api_view(["POST"])
def logout_view(request):
    logout(request); return Response({"status":"logged_out"})

@api_view(["GET"])
def me(request): return Response({"user":UserSerializer(request.user).data})

class CentreViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class=CentreSerializer
    permission_classes=[AllowAny]
    def get_queryset(self):
        qs=Centre.objects.filter(is_published=True).select_related("owner")
        q=self.request.query_params.get("q")
        if q: qs=qs.filter(Q(name__icontains=q)|Q(address__icontains=q)|Q(consoles__games__name__icontains=q)).distinct()
        return qs

class GameViewSet(viewsets.ReadOnlyModelViewSet):
    queryset=Game.objects.all().order_by("name"); serializer_class=GameSerializer; permission_classes=[AllowAny]

class SessionViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class=SessionSerializer; permission_classes=[AllowAny]
    def get_queryset(self):
        qs=Session.objects.filter(
    is_available=True,
    ends_at__gt=timezone.now(),
    console__active=True,
    console__centre__is_published=True).select_related("console", "console__centre", "game")
        centre=self.request.query_params.get("centre")
        if centre: qs=qs.filter(console__centre_id=centre)
        game=self.request.query_params.get("game")
        if game: qs=qs.filter(game_id=game)
        return qs

class OwnerCentreView(APIView):
    permission_classes=[IsOwner]
    def get(self,request):
        c=Centre.objects.filter(owner=request.user).first()
        return Response(CentreSerializer(c).data if c else {})
    def patch(self,request):
        c=Centre.objects.filter(owner=request.user).first()
        if not c:
            return Response({"detail":"No centre is registered for this owner."},status=404)
        s=CentreSerializer(c,data=request.data,partial=True); s.is_valid(raise_exception=True); s.save()
        return Response(s.data)

class OwnerConsoleViewSet(viewsets.ModelViewSet):
    serializer_class=ConsoleSerializer; permission_classes=[IsOwner]
    def get_queryset(self): return Console.objects.filter(centre__owner=self.request.user).prefetch_related("games")
    def perform_create(self,serializer):
        centre=Centre.objects.get(owner=self.request.user)
        serializer.save(centre=centre)

class OwnerSessionViewSet(viewsets.ModelViewSet):
    serializer_class=SessionSerializer; permission_classes=[IsOwner]
    def get_queryset(self): return Session.objects.filter(console__centre__owner=self.request.user).select_related("console","game")
    def perform_create(self,serializer):
        console=Console.objects.get(pk=self.request.data.get("console"),centre__owner=self.request.user)
        game=Game.objects.get(pk=self.request.data.get("game"))
        if not console.games.filter(pk=game.pk).exists(): raise ValidationError("Select a game supported by this console.")
        starts=serializer.validated_data["starts_at"]; ends=serializer.validated_data["ends_at"]
        if ends <= starts: raise ValidationError("Session end must be after start.")
        overlap=Session.objects.filter(console=console, starts_at__lt=ends, ends_at__gt=starts).exists()
        if overlap: raise ValidationError("This console already has an overlapping session.")
        serializer.save(console=console,capacity=console.max_players)

class OwnerBookingViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class=BookingSerializer; permission_classes=[IsOwner]
    def get_queryset(self): return Booking.objects.filter(session__console__centre__owner=self.request.user).select_related("session","customer")

class MyBookingViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class=BookingSerializer; permission_classes=[IsAuthenticated]
    def get_queryset(self): return Booking.objects.filter(customer=self.request.user).select_related("session","session__console","session__game")


class BookingCreateView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        if getattr(getattr(request.user, "profile", None), "role", None) != "customer":
            return Response(
                {"detail": "Only customer accounts can book sessions."},
                status=403
            )

        try:
            session_id = int(request.data["session"])
            players = int(request.data["players"])
            session = Session.objects.get(pk=session_id)

            if not session.is_available or session.ends_at <= timezone.now():
                return Response(
                    {"detail": "This session has ended or is no longer available."},
                    status=400
                )

            booking = create_booking(
                customer=request.user,
                session_id=session_id,
                players=players,
                is_private=bool(request.data.get("is_private", False))
            )

        except (KeyError, ValueError, Session.DoesNotExist):
            return Response(
                {"detail": "Invalid session or player count."},
                status=400
            )

        return Response(BookingSerializer(booking).data, status=201)


class PaymentOrderView(APIView):
    permission_classes=[IsAuthenticated]
    def post(self,request):
        booking=Booking.objects.filter(reference=request.data.get("reference"),customer=request.user).first()
        if not booking: return Response({"detail":"Booking not found."},status=404)
        if booking.status != "pending" or booking.hold_expires_at <= timezone.now():
            return Response({"detail":"Booking hold expired or is not payable."},status=400)
        if booking.payments.filter(status="paid").exists(): return Response({"detail":"Already paid."},status=409)
        payment=Payment.objects.create(booking=booking,amount=booking.amount,status="initiated")
        if settings.PAYMENT_MODE == "mock" and settings.DEBUG:
            return Response({"mode":"mock","payment_id":payment.id,"amount":str(payment.amount),"key_id":""})
        if not settings.RAZORPAY_KEY_ID or not settings.RAZORPAY_KEY_SECRET:
            payment.status="failed"; payment.save()
            return Response({"detail":"Razorpay is not configured. Add test keys to backend/.env."},status=503)
        import razorpay
        client=razorpay.Client(auth=(settings.RAZORPAY_KEY_ID,settings.RAZORPAY_KEY_SECRET))
        order=client.order.create({"amount":int(booking.amount*100),"currency":"INR","receipt":booking.reference,
            "notes":{"booking_reference":booking.reference,"customer_id":str(request.user.id)}})
        payment.provider_order_id=order["id"]; payment.status="pending"; payment.save()
        return Response({"mode":"razorpay","key_id":settings.RAZORPAY_KEY_ID,"order_id":order["id"],"amount":order["amount"],"currency":"INR","payment_id":payment.id})

class PaymentVerifyView(APIView):
    permission_classes=[IsAuthenticated]
    def post(self,request):
        payment=Payment.objects.filter(pk=request.data.get("payment_id"),booking__customer=request.user).select_related("booking").first()
        if not payment: return Response({"detail":"Payment not found."},status=404)
        booking=payment.booking
        if settings.PAYMENT_MODE=="mock" and settings.DEBUG and request.data.get("mock_success") is True:
            with transaction.atomic():
                payment.status="paid"; payment.provider_payment_id="LOCAL-TEST-"+str(payment.id); payment.save()
                booking.status="confirmed"; booking.save()
            return Response({"status":"paid","booking":BookingSerializer(booking).data})
        required=["razorpay_order_id","razorpay_payment_id","razorpay_signature"]
        if not all(request.data.get(k) for k in required): return Response({"detail":"Missing payment verification fields."},status=400)
        if request.data["razorpay_order_id"] != payment.provider_order_id: return Response({"detail":"Order mismatch."},status=400)
        body=f'{request.data["razorpay_order_id"]}|{request.data["razorpay_payment_id"]}'.encode()
        expected=hmac.new(settings.RAZORPAY_KEY_SECRET.encode(),body,hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected,request.data["razorpay_signature"]): return Response({"detail":"Invalid payment signature."},status=400)
        with transaction.atomic():
            payment.status="paid"; payment.provider_payment_id=request.data["razorpay_payment_id"]; payment.save()
            booking.status="confirmed"; booking.save()
        return Response({"status":"paid","booking":BookingSerializer(booking).data})

@api_view(["POST"])
@permission_classes([AllowAny])
def payment_webhook(request):
    secret=settings.RAZORPAY_WEBHOOK_SECRET
    if not secret: return Response({"detail":"Webhook secret is not configured."},status=503)
    signature=request.headers.get("X-Razorpay-Signature","")
    expected=hmac.new(secret.encode(),request.body,hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected,signature): return Response({"detail":"Invalid webhook signature."},status=400)
    event_id=request.headers.get("X-Razorpay-Event-Id","")
    if event_id and Payment.objects.filter(event_key=event_id).exists(): return Response({"status":"duplicate_ignored"})
    try: payload=json.loads(request.body)
    except ValueError: return Response({"detail":"Invalid JSON."},status=400)
    event=payload.get("event")
    entity=payload.get("payload",{}).get("payment",{}).get("entity",{})
    order_id=entity.get("order_id"); payment_id=entity.get("id")
    p=Payment.objects.filter(provider_order_id=order_id).select_related("booking").first()
    if p:
        if event=="payment.captured":
            p.status="paid"; p.provider_payment_id=payment_id
            if event_id: p.event_key=event_id
            p.save()
            p.booking.status="confirmed"; p.booking.save()
        elif event=="payment.failed":
            p.status="failed"
            if event_id: p.event_key=event_id
            p.save()
    return Response({"status":"processed"})

@api_view(["POST"])
def cancel_booking(request, reference):
    b=Booking.objects.filter(reference=reference,customer=request.user).first()
    if not b: return Response({"detail":"Booking not found."},status=404)
    if b.status not in ["pending","confirmed"]: return Response({"detail":"This booking cannot be cancelled."},status=400)
    b.status="cancelled"; b.save()
    # Refund is deliberately not auto-claimed: gateway refund needs merchant configuration.
    return Response({"status":"cancelled","refund_status":"manual_review_required"})

@api_view(["GET"])
def owner_summary(request):
    if getattr(getattr(request.user,"profile",None),"role",None)!="owner": return Response({"detail":"Owner account required."},status=403)
    from django.db.models import Sum, Count
    centre=Centre.objects.filter(owner=request.user).first()
    if not centre: return Response({})
    bookings=Booking.objects.filter(session__console__centre=centre)
    return Response({"centre":CentreSerializer(centre).data,"total_consoles":centre.consoles.count(),
        "active_consoles":centre.consoles.filter(active=True).count(),"bookings_today":bookings.filter(created_at__date=timezone.localdate()).count(),
        "upcoming_bookings":bookings.filter(status="confirmed",session__starts_at__gte=timezone.now()).count(),
        "verified_revenue":str(Payment.objects.filter(booking__in=bookings,status="paid").aggregate(v=__import__("django.db.models",fromlist=["Sum"]).Sum("amount"))["v"] or 0)})
