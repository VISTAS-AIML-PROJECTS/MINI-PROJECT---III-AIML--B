from rest_framework.permissions import BasePermission, SAFE_METHODS
def role(user):
    return getattr(getattr(user, "profile", None), "role", None)
class IsOwner(BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and role(request.user)=="owner")
class IsCustomer(BasePermission):
    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and role(request.user)=="customer")
