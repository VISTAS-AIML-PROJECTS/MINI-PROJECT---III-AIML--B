from django.contrib import admin
from .models import Profile,Centre,Game,Console,Session,Booking,Payment
admin.site.register([Profile,Centre,Game,Console,Session,Booking,Payment])
