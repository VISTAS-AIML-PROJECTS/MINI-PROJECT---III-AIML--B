from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views
router=DefaultRouter()
router.register("centres",views.CentreViewSet,basename="centre")
router.register("games",views.GameViewSet,basename="game")
router.register("sessions",views.SessionViewSet,basename="session")
router.register("owner/consoles",views.OwnerConsoleViewSet,basename="owner-console")
router.register("owner/sessions",views.OwnerSessionViewSet,basename="owner-session")
router.register("owner/bookings",views.OwnerBookingViewSet,basename="owner-booking")
router.register("bookings",views.MyBookingViewSet,basename="my-booking")
urlpatterns=[
 path("health/",views.health),path("csrf/",views.csrf),path("auth/register/",views.RegisterView.as_view()),
 path("auth/login/",views.LoginView.as_view()),path("auth/logout/",views.logout_view),path("auth/me/",views.me),
 path("owner/centre/",views.OwnerCentreView.as_view()),path("owner/summary/",views.owner_summary),
 path("booking/create/",views.BookingCreateView.as_view()),path("booking/<str:reference>/cancel/",views.cancel_booking),
 path("payments/order/",views.PaymentOrderView.as_view()),path("payments/verify/",views.PaymentVerifyView.as_view()),
 path("payments/webhook/",views.payment_webhook),path("",include(router.urls)),
]
