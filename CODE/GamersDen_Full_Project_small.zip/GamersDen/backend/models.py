import uuid
from django.db import models
from django.contrib.auth.models import User

class Profile(models.Model):
    CUSTOMER = "customer"
    OWNER = "owner"
    ROLE_CHOICES = [(CUSTOMER, "Customer"), (OWNER, "Owner")]
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="profile")
    role = models.CharField(max_length=12, choices=ROLE_CHOICES, default=CUSTOMER)
    phone = models.CharField(max_length=30, blank=True)
    def __str__(self): return f"{self.user.username} ({self.role})"

class Centre(models.Model):
    owner = models.OneToOneField(User, on_delete=models.CASCADE, related_name="centre")
    name = models.CharField(max_length=140)
    address = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    opening_time = models.TimeField(default="10:00")
    closing_time = models.TimeField(default="23:00")
    is_published = models.BooleanField(default=True)
    latitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    def __str__(self): return self.name

class Game(models.Model):
    name = models.CharField(max_length=100, unique=True)
    def __str__(self): return self.name

class Console(models.Model):
    centre = models.ForeignKey(Centre, on_delete=models.CASCADE, related_name="consoles")
    name = models.CharField(max_length=100)
    console_type = models.CharField(max_length=40, default="PS5")
    max_players = models.PositiveSmallIntegerField(default=4)
    games = models.ManyToManyField(Game, related_name="consoles", blank=True)
    pricing_model = models.CharField(max_length=20, choices=[("per_player","Per player"),("per_session","Per session")], default="per_player")
    price = models.DecimalField(max_digits=8, decimal_places=2, default=100)
    session_minutes = models.PositiveSmallIntegerField(default=60)
    active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    def __str__(self): return f"{self.centre.name} / {self.name}"

class Session(models.Model):
    console = models.ForeignKey(Console, on_delete=models.CASCADE, related_name="sessions")
    game = models.ForeignKey(Game, on_delete=models.PROTECT, related_name="sessions")
    starts_at = models.DateTimeField()
    ends_at = models.DateTimeField()
    capacity = models.PositiveSmallIntegerField()
    is_private = models.BooleanField(default=False)
    is_available = models.BooleanField(default=True)
    price_override = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    class Meta:
        ordering = ["starts_at"]
        indexes = [models.Index(fields=["console", "starts_at", "ends_at"])]
    def __str__(self): return f"{self.console.name} - {self.game.name} - {self.starts_at}"

def generate_booking_reference():
    return uuid.uuid4().hex[:12].upper()

class Booking(models.Model):
    PENDING = "pending"
    CONFIRMED = "confirmed"
    CANCELLED = "cancelled"
    EXPIRED = "expired"
    STATUS_CHOICES = [(PENDING,"Pending payment"),(CONFIRMED,"Confirmed"),(CANCELLED,"Cancelled"),(EXPIRED,"Expired")]
    reference = models.CharField(max_length=14, unique=True, default=generate_booking_reference)
    customer = models.ForeignKey(User, on_delete=models.PROTECT, related_name="bookings")
    session = models.ForeignKey(Session, on_delete=models.PROTECT, related_name="bookings")
    players = models.PositiveSmallIntegerField()
    is_private = models.BooleanField(default=False)
    status = models.CharField(max_length=12, choices=STATUS_CHOICES, default=PENDING)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    hold_expires_at = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        ordering = ["-created_at"]
    def __str__(self): return self.reference

class Payment(models.Model):
    INITIATED = "initiated"
    PENDING = "pending"
    PAID = "paid"
    FAILED = "failed"
    REFUNDED = "refunded"
    booking = models.ForeignKey(Booking, on_delete=models.PROTECT, related_name="payments")
    provider_order_id = models.CharField(max_length=100, blank=True)
    provider_payment_id = models.CharField(max_length=100, blank=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=12, default=INITIATED)
    event_key = models.CharField(max_length=150, blank=True, unique=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
