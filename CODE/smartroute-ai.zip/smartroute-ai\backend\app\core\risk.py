"""Risk engine.

Travel time to delivery is modelled as T ~ Normal(eta, sigma), sigma = eta * (0.15 + 0.35 * congestion) + 1.
From that model we derive:
  * delay probability  P(T > time-to-deadline)
  * CVaR_alpha lateness  E[T | T in worst alpha tail] - time-to-deadline (clipped at 0)
Composite risk = weighted mean of traffic, delay, distance and workload components (weights configurable).
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from statistics import NormalDist

from ..config import RiskWeights, settings

_N = NormalDist()
DISTANCE_SCALE_KM = 15.0
LEVELS = [(0.25, "LOW"), (0.5, "MEDIUM"), (0.75, "HIGH"), (1.01, "CRITICAL")]


def travel_sigma(eta_min: float, congestion: float) -> float:
    return eta_min * (0.15 + 0.35 * congestion) + 1.0


def delay_probability(eta_min: float, slack_min: float, congestion: float) -> float:
    """P(actual travel time > slack) under the Gaussian travel-time model."""
    return 1.0 - _N.cdf((slack_min - eta_min) / travel_sigma(eta_min, congestion))


def cvar_lateness(eta_min: float, slack_min: float, congestion: float, alpha: float = 0.1) -> float:
    """Expected lateness (minutes) in the worst `alpha` fraction of outcomes.

    For T ~ N(mu, s): CVaR_alpha(T) = mu + s * pdf(inv_cdf(1 - alpha)) / alpha.
    """
    s = travel_sigma(eta_min, congestion)
    cvar_t = eta_min + s * _N.pdf(_N.inv_cdf(1 - alpha)) / alpha
    return max(0.0, cvar_t - slack_min)


def level(score: float) -> str:
    return next(name for limit, name in LEVELS if score < limit)


@dataclass
class RiskBreakdown:
    traffic: float
    delay: float
    distance: float
    workload: float
    score: float
    level: str

    def dict(self) -> dict:
        return {k: round(v, 4) if isinstance(v, float) else v for k, v in asdict(self).items()}


def compute_risk(congestion: float, delay_p: float, km: float, load_after: int, capacity: int,
                 weights: RiskWeights | None = None) -> RiskBreakdown:
    w = weights or settings.risk_weights
    parts = {
        "traffic": max(0.0, min(1.0, congestion)),
        "delay": max(0.0, min(1.0, delay_p)),
        "distance": min(1.0, km / DISTANCE_SCALE_KM),
        "workload": min(1.0, load_after / capacity) if capacity else 1.0,
    }
    total_w = w.traffic + w.delay + w.distance + w.workload
    score = sum(getattr(w, k) * v for k, v in parts.items()) / total_w if total_w else 0.0
    return RiskBreakdown(**parts, score=score, level=level(score))
