"""PPO (clipped surrogate objective + GAE) for the dispatch MDP, implemented in NumPy.

Policy: a shared MLP scores each (order, partner) feature row; softmax over eligible partners.
        This is permutation-invariant and handles a variable number of partners.
Value:  an MLP over [mean, min] pooled candidate features.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

from ..core import scenario
from ..core.traffic import TrafficField
from ..config import settings
from .env import N_FEATURES, DispatchEnv, Observation
from .nn import MLP, Adam

HIDDEN = 64
REWARD_SCALE = 0.2  # keeps value targets O(1) for the critic


def softmax(z: np.ndarray) -> np.ndarray:
    e = np.exp(z - z.max())
    return e / e.sum()


def pool(x: np.ndarray) -> np.ndarray:
    return np.concatenate([x.mean(axis=0), x.min(axis=0)])


class Policy:
    def __init__(self, seed: int = 0):
        rng = np.random.default_rng(seed)
        self.actor = MLP([N_FEATURES, HIDDEN, HIDDEN, 1], rng)
        self.critic = MLP([2 * N_FEATURES, HIDDEN, 1], rng, out_scale=0.1)

    def probs(self, x: np.ndarray) -> np.ndarray:
        return softmax(self.actor.forward(x)[:, 0])

    def value(self, x: np.ndarray) -> float:
        return float(self.critic.forward(pool(x)[None])[0, 0])

    def act(self, x: np.ndarray, rng: np.random.Generator | None = None) -> tuple[int, float, np.ndarray]:
        p = self.probs(x)
        a = int(rng.choice(len(p), p=p)) if rng is not None else int(np.argmax(p))
        return a, float(np.log(p[a] + 1e-12)), p

    def save(self, path: Path, meta: dict | None = None) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        np.savez(path, **self.actor.state("a"), **self.critic.state("c"),
                 meta=np.array(repr(meta or {})))

    @classmethod
    def load(cls, path: Path) -> "Policy":
        pol = cls()
        with np.load(path, allow_pickle=False) as d:
            pol.actor.load("a", d)
            pol.critic.load("c", d)
        return pol


@dataclass
class Transition:
    x: np.ndarray
    a: int
    logp: float
    v: float
    r: float
    done: bool
    adv: float = 0.0
    ret: float = 0.0


@dataclass
class TrainConfig:
    iterations: int = 60
    episodes_per_iter: int = 24
    epochs: int = 4
    minibatch: int = 128
    gamma: float = 0.95
    lam: float = 0.95
    clip: float = 0.2
    lr: float = 1e-3
    entropy: float = 0.01
    seed: int = 0


@dataclass
class TrainLog:
    iteration: int
    mean_episode_reward: float
    policy_loss: float
    value_loss: float
    entropy: float


@dataclass
class TrainResult:
    policy: Policy
    logs: list[TrainLog] = field(default_factory=list)
    seconds: float = 0.0


def random_env(rng: np.random.Generator, risk_aware: bool) -> DispatchEnv:
    n_p, n_o = int(rng.integers(4, 13)), int(rng.integers(5, 26))
    partners, orders = scenario.generate(rng, n_p, n_o, preload=True, offline_frac=0.1)
    traffic = TrafficField(settings.city_lat, settings.city_lng, settings.city_radius_km,
                           level=float(rng.uniform(0.2, 1.0)), seed=int(rng.integers(1 << 30)))
    return DispatchEnv(partners, orders, 0.0, traffic, risk_aware)


def collect(policy: Policy, rng: np.random.Generator, n_episodes: int, risk_aware: bool):
    batch, ep_rewards = [], []
    for _ in range(n_episodes):
        env = random_env(rng, risk_aware)
        obs: Observation | None = env.reset()
        ep, total = [], 0.0
        while obs is not None:
            a, logp, _ = policy.act(obs.x, rng)
            v = policy.value(obs.x)
            nxt, r, _ = env.step(obs, a)
            ep.append(Transition(obs.x, a, logp, v, r * REWARD_SCALE, nxt is None))
            total += r
            obs = nxt
        ep_rewards.append(total)
        batch.extend(ep)
    return batch, ep_rewards


def compute_gae(batch: list[Transition], gamma: float, lam: float) -> None:
    gae = 0.0
    for t in reversed(range(len(batch))):
        tr = batch[t]
        next_v = 0.0 if tr.done else batch[t + 1].v
        if tr.done:
            gae = 0.0
        delta = tr.r + gamma * next_v - tr.v
        gae = delta + gamma * lam * gae
        tr.adv, tr.ret = gae, gae + tr.v


def update(policy: Policy, opt_a: Adam, opt_c: Adam, batch: list[Transition], cfg: TrainConfig,
           rng: np.random.Generator) -> tuple[float, float, float]:
    adv = np.array([t.adv for t in batch])
    adv = (adv - adv.mean()) / (adv.std() + 1e-8)
    pl = vl = ent = 0.0
    n_mb = 0
    for _ in range(cfg.epochs):
        idx = rng.permutation(len(batch))
        for s in range(0, len(idx), cfg.minibatch):
            mb = idx[s:s + cfg.minibatch]
            # --- actor: one forward over all candidate rows of the minibatch ---
            X = np.concatenate([batch[i].x for i in mb])
            seg = np.cumsum([0] + [len(batch[i].x) for i in mb])
            logits = policy.actor.forward(X)[:, 0]
            dlogits = np.zeros_like(logits)
            for k, i in enumerate(mb):
                tr = batch[i]
                z = logits[seg[k]:seg[k + 1]]
                p = softmax(z)
                logp_all = np.log(p + 1e-12)
                ratio = np.exp(logp_all[tr.a] - tr.logp)
                A = adv[i]
                clipped = (A > 0 and ratio > 1 + cfg.clip) or (A < 0 and ratio < 1 - cfg.clip)
                g = np.zeros_like(p)
                if not clipped:  # d(-ratio*A)/dlogits
                    onehot = np.zeros_like(p)
                    onehot[tr.a] = 1
                    g += -A * ratio * (onehot - p)
                H = -(p * logp_all).sum()
                g += cfg.entropy * p * (logp_all + H)  # d(-c*H)/dlogits
                dlogits[seg[k]:seg[k + 1]] = g / len(mb)
                pl += -min(ratio * A, np.clip(ratio, 1 - cfg.clip, 1 + cfg.clip) * A)
                ent += H
            gW, gb = policy.actor.backward(dlogits[:, None])
            opt_a.step(gW + gb)
            # --- critic ---
            P = np.stack([pool(batch[i].x) for i in mb])
            V = policy.critic.forward(P)[:, 0]
            R = np.array([batch[i].ret for i in mb])
            gW, gb = policy.critic.backward(((V - R) / len(mb))[:, None])
            opt_c.step(gW + gb)
            vl += float(0.5 * ((V - R) ** 2).mean())
            n_mb += 1
    n = cfg.epochs * len(batch)
    return pl / n, vl / max(n_mb, 1), ent / n


def train(risk_aware: bool, cfg: TrainConfig | None = None, progress=None) -> TrainResult:
    cfg = cfg or TrainConfig()
    rng = np.random.default_rng(cfg.seed)
    policy = Policy(cfg.seed)
    opt_a = Adam(policy.actor.params(), lr=cfg.lr)
    opt_c = Adam(policy.critic.params(), lr=cfg.lr, max_norm=5.0)
    res = TrainResult(policy)
    t0 = time.perf_counter()
    for it in range(cfg.iterations):
        batch, ep_r = collect(policy, rng, cfg.episodes_per_iter, risk_aware)
        compute_gae(batch, cfg.gamma, cfg.lam)
        pl, vl, ent = update(policy, opt_a, opt_c, batch, cfg, rng)
        log = TrainLog(it + 1, float(np.mean(ep_r)), pl, vl, ent)
        res.logs.append(log)
        if progress:
            progress(log)
    res.seconds = time.perf_counter() - t0
    return res
