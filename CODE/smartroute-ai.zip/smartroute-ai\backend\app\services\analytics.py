"""Analytics, data-backed insights, risk summary and reports (all computed from stored state)."""
from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone

import numpy as np
from sqlalchemy import select

from .. import db
from ..core.risk import LEVELS
from .simulation import simulation
from .views import assignment_dict, load_state

RISK_CATEGORIES = ["traffic", "delay", "distance", "workload"]


def _latest_evaluation(s) -> dict | None:
    row = s.scalars(select(db.TrainingRun).where(db.TrainingRun.kind == "evaluate", db.TrainingRun.status == "done")
                    .order_by(db.TrainingRun.id.desc())).first()
    return {"id": row.id, "started_at": row.started_at.isoformat(), **row.result} if row else None


def risk_summary() -> dict:
    w = simulation.ensure()
    traffic_cells = w.traffic.cells()
    with db.SessionLocal() as s:
        orders, partners = load_state(s, w.run_id, w.now)
        events = s.scalars(select(db.RiskEvent).where(db.RiskEvent.run_id == w.run_id)
                           .order_by(db.RiskEvent.id.desc()).limit(50)).all()
    active = [o for o in orders if o["base_status"] != "delivered"]
    cat = {c: round(float(np.mean([o["risk_parts"].get(c, 0) for o in active])), 4) if active else 0.0
           for c in RISK_CATEGORIES}
    deadline_risk = round(float(np.mean([o["minutes_to_deadline"] < 10 for o in active])), 4) if active else 0.0
    levels = Counter(o["risk_level"] for o in active)
    return {
        "sim_time": w.now,
        "categories": {**cat, "deadline": deadline_risk},
        "category_basis": {
            "traffic": "mean congestion on active routes", "delay": "mean P(miss deadline)",
            "distance": "mean route distance / 15 km", "workload": "mean partner load / capacity",
            "deadline": "share of active orders with < 10 min to deadline",
        },
        "overall": round(float(np.mean([o["risk"] for o in active])), 4) if active else 0.0,
        "levels": {name: levels.get(name, 0) for _, name in LEVELS},
        "affected_orders": sorted((o for o in active if o["risk_level"] in ("HIGH", "CRITICAL") or o["status"] in ("at_risk", "delayed")),
                                  key=lambda o: -o["risk"])[:25],
        "affected_partners": [p for p in partners if p["status"] in ("at_risk", "at_capacity")],
        "zones": sorted(traffic_cells, key=lambda c: -c["congestion"])[:8],
        "events": [{"id": e.id, "sim_time": e.sim_time, "category": e.category, "level": e.level,
                    "entity_type": e.entity_type, "entity_id": e.entity_id, "message": e.message, "action": e.action}
                   for e in events],
    }


def analytics() -> dict:
    w = simulation.ensure()
    with db.SessionLocal() as s:
        orders, partners = load_state(s, w.run_id, w.now)
        history = s.scalars(select(db.MetricSnapshot).where(db.MetricSnapshot.run_id == w.run_id)
                            .order_by(db.MetricSnapshot.id)).all()
        assigns = s.scalars(select(db.AssignmentRow).where(db.AssignmentRow.run_id == w.run_id)).all()
        evaluation = _latest_evaluation(s)
    delivered = [o for o in orders if o["base_status"] == "delivered"]
    pva = [{
        "id": o["id"], "planned_eta": round(o["planned_eta"] - o["assigned_at"], 1),
        "actual_eta": round(o["delivered_at"] - o["assigned_at"], 1),
        "planned_km": round(o["planned_km"], 2), "actual_km": round(o["actual_km"], 2),
        "late": o["delivered_at"] > o["deadline"], "algorithm": o["assigned_by"],
    } for o in delivered if o["planned_eta"] is not None]
    late = [o for o in delivered if o["delivered_at"] > o["deadline"]]
    causes = Counter("Plan already infeasible at assignment" if o["planned_eta"] is not None and o["planned_eta"] > o["deadline"]
                     else "Plan feasible, execution slower than planned" for o in late)
    by_algo: dict[str, list] = {}
    for a in assigns:
        by_algo.setdefault(a.algorithm, []).append(a)
    algo_live = {k: {"assignments": len(v), "avg_eta_min": round(float(np.mean([a.eta_min for a in v])), 2),
                     "avg_risk": round(float(np.mean([a.risk for a in v])), 4),
                     "feasible_rate": round(float(np.mean([a.feasible for a in v])), 4)} for k, v in by_algo.items()}
    step = max(1, len(history) // 200)  # downsample long runs for charts
    return {
        "sim_time": w.now,
        "kpis": simulation.kpis(),
        "history": [{"t": h.sim_time, **h.payload} for h in history[::step]],
        "partners": partners,
        "risk_distribution": Counter(o["risk_level"] for o in orders if o["base_status"] != "delivered"),
        "planned_vs_actual": pva,
        "planned_vs_actual_summary": {
            "n": len(pva),
            "mean_eta_deviation_min": round(float(np.mean([r["actual_eta"] - r["planned_eta"] for r in pva])), 2) if pva else None,
            "mean_km_deviation": round(float(np.mean([r["actual_km"] - r["planned_km"] for r in pva])), 3) if pva else None,
        },
        "delay_causes": dict(causes),
        "algorithms_live": algo_live,
        "evaluation": evaluation,
        "zones": sorted(w.traffic.cells(), key=lambda c: -c["congestion"])[:10],
    }


def insights() -> list[dict]:
    """Each insight is emitted only when its supporting numbers hold; evidence is returned with it."""
    w = simulation.ensure()
    out = []
    with db.SessionLocal() as s:
        orders, partners = load_state(s, w.run_id, w.now)
        evaluation = _latest_evaluation(s)
    active = [o for o in orders if o["base_status"] != "delivered"]
    hot = {c["zone"] for c in w.traffic.cells() if c["congestion"] >= 0.7}
    if hot and active:
        in_hot = [o["risk"] for o in active if w.traffic.zone_name(o["drop"]["lat"], o["drop"]["lng"]) in hot]
        other = [o["risk"] for o in active if w.traffic.zone_name(o["drop"]["lat"], o["drop"]["lng"]) not in hot]
        if in_hot and other and np.mean(in_hot) > np.mean(other):
            out.append({"kind": "risk", "text": f"High-traffic zones ({', '.join(sorted(hot)[:4])}) are associated with higher "
                        f"delivery risk: {np.mean(in_hot):.2f} vs {np.mean(other):.2f} for other active orders.",
                        "evidence": {"orders_in_hot_zones": len(in_hot), "orders_elsewhere": len(other)}})
    online = [p for p in partners if p["online"]]
    if online:
        mean_u = float(np.mean([p["utilization"] for p in online]))
        for p in sorted(online, key=lambda p: -p["utilization"]):
            if p["utilization"] >= mean_u + 0.25:
                out.append({"kind": "workload", "text": f"Partner {p['id']} currently has above-average workload "
                            f"({p['load']}/{p['capacity']} vs fleet average {mean_u:.0%}).",
                            "evidence": {"partner": p["id"], "utilization": p["utilization"], "fleet_mean": round(mean_u, 4)}})
                break
        idle = [p for p in online if p["load"] == 0]
        pending = [o for o in orders if o["base_status"] == "pending"]
        if pending and idle:
            out.append({"kind": "dispatch", "text": f"{len(pending)} order(s) are waiting while {len(idle)} partner(s) are idle. "
                        "Run an assignment or enable auto-assign.", "evidence": {"pending": len(pending), "idle": len(idle)}})
    overdue = [o["id"] for o in orders if o["base_status"] == "pending" and o["minutes_to_deadline"] < 0]
    if overdue:
        out.append({"kind": "alert", "text": f"{len(overdue)} pending order(s) have already passed their deadline "
                    f"({', '.join(overdue[:5])}).", "evidence": {"orders": overdue}})
    delivered = [o for o in orders if o["base_status"] == "delivered"]
    if len(delivered) >= 5:
        rate = float(np.mean([o["delivered_at"] <= o["deadline"] for o in delivered]))
        out.append({"kind": "performance", "text": f"Simulation result: {rate:.0%} of {len(delivered)} delivered orders arrived on time.",
                    "evidence": {"delivered": len(delivered)}})
    if evaluation and "smartroute" in evaluation.get("results", {}) and "hungarian" in evaluation["results"]:
        sr, hu = evaluation["results"]["smartroute"]["avg_risk"], evaluation["results"]["hungarian"]["avg_risk"]
        diff = hu["mean"] - sr["mean"]
        n = evaluation.get("scenarios")
        if abs(diff) > sr["ci95"] + hu["ci95"]:
            verb = "reduced" if diff > 0 else "increased"
            out.append({"kind": "evaluation", "text": f"Simulation result: risk-aware SmartRoute AI {verb} average assignment risk "
                        f"compared with Hungarian ({sr['mean']:.3f} vs {hu['mean']:.3f}, {n} scenarios).", "evidence": {"sr": sr, "hungarian": hu}})
        else:
            out.append({"kind": "evaluation", "text": f"Simulation result: no statistically clear difference in average assignment risk "
                        f"between SmartRoute AI ({sr['mean']:.3f}) and Hungarian ({hu['mean']:.3f}) over {n} scenarios.",
                        "evidence": {"sr": sr, "hungarian": hu}})
    return out


def report() -> dict:
    w = simulation.ensure()
    a = analytics()
    with db.SessionLocal() as s:
        run = s.get(db.SimulationRun, w.run_id)
        n_assign = len(s.scalars(select(db.AssignmentRow.id).where(db.AssignmentRow.run_id == w.run_id)).all())
        recent = [assignment_dict(r) for r in s.scalars(select(db.AssignmentRow).where(db.AssignmentRow.run_id == w.run_id)
                                                        .order_by(db.AssignmentRow.id.desc()).limit(20))]
    return {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "data_notice": "Synthetic Simulation Data - not real-world operational data.",
        "run": {"id": run.id, "started_at": run.started_at.isoformat(), "seed": run.seed,
                "simulated_minutes": round(w.now, 1), "algorithm": simulation.cfg.algorithm,
                "traffic_level": round(w.traffic.level, 2), "order_rate_per_hour": simulation.cfg.order_rate_per_hour},
        "counts": {"orders": a["kpis"]["active_orders"] + a["kpis"]["delivered_orders"], "partners": len(a["partners"]),
                   "assignments": n_assign, "delivered": a["kpis"]["delivered_orders"]},
        "kpis": a["kpis"],
        "workload": [{"id": p["id"], "load": p["load"], "capacity": p["capacity"], "completed": p["completed"],
                      "on_time_rate": p["on_time_rate"], "distance_km": p["distance_km"]} for p in a["partners"]],
        "planned_vs_actual": a["planned_vs_actual_summary"],
        "delay_causes": a["delay_causes"],
        "algorithms_live": a["algorithms_live"],
        "evaluation": a["evaluation"],
        "recent_assignments": recent,
        "recommendations": insights(),
    }
