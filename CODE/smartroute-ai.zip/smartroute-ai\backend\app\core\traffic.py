"""Synthetic traffic engine: a grid of congestion values in [0, 0.95] over the service area.

Congestion = level x static hotspot pattern + AR(1) noise. Hotspots model busy corridors; the
level (0..1) is the scenario knob ("traffic level" in the UI). Synthetic, not real traffic data.
"""
from __future__ import annotations

import math

import numpy as np

SCENARIOS = {"light": 0.3, "normal": 0.55, "heavy": 0.8, "gridlock": 1.0}


class TrafficField:
    def __init__(self, center_lat: float, center_lng: float, radius_km: float, level: float = 0.55,
                 n: int = 8, seed: int = 0):
        self.n = n
        self.level = level
        self.rng = np.random.default_rng(seed)
        dlat = radius_km / 111.0
        dlng = radius_km / (111.0 * math.cos(math.radians(center_lat)))
        self.lat0, self.lat1 = center_lat - dlat, center_lat + dlat
        self.lng0, self.lng1 = center_lng - dlng, center_lng + dlng
        ys, xs = np.mgrid[0:n, 0:n] / (n - 1)
        pattern = np.zeros((n, n))
        for _ in range(4):  # hotspot corridors
            cy, cx, s = self.rng.uniform(0.15, 0.85), self.rng.uniform(0.15, 0.85), self.rng.uniform(0.15, 0.3)
            pattern += np.exp(-((ys - cy) ** 2 + (xs - cx) ** 2) / (2 * s * s))
        self.pattern = 0.25 + 0.75 * pattern / pattern.max()
        self.noise = np.zeros((n, n))
        self.grid = self._compose()

    def _compose(self) -> np.ndarray:
        return np.clip(self.level * self.pattern + self.noise, 0.0, 0.95)

    def set_level(self, level: float) -> None:
        self.level = float(np.clip(level, 0.0, 1.0))
        self.grid = self._compose()

    def step(self, dt_min: float) -> None:
        """Evolve the AR(1) noise term; correlation decays over ~20 simulated minutes."""
        rho = math.exp(-dt_min / 20.0)
        self.noise = rho * self.noise + math.sqrt(1 - rho * rho) * self.rng.normal(0, 0.08, self.noise.shape)
        self.grid = self._compose()

    def cell(self, lat: float, lng: float) -> tuple[int, int]:
        r = int((lat - self.lat0) / (self.lat1 - self.lat0) * self.n)
        c = int((lng - self.lng0) / (self.lng1 - self.lng0) * self.n)
        return min(max(r, 0), self.n - 1), min(max(c, 0), self.n - 1)

    def at(self, lat: float, lng: float) -> float:
        return float(self.grid[self.cell(lat, lng)])

    def mean_along(self, lat1: float, lng1: float, lat2: float, lng2: float, samples: int = 6) -> float:
        t = np.linspace(0, 1, samples)
        return float(np.mean([self.at(lat1 + (lat2 - lat1) * k, lng1 + (lng2 - lng1) * k) for k in t]))

    def zone_name(self, lat: float, lng: float) -> str:
        r, c = self.cell(lat, lng)
        return f"{chr(65 + c)}{r + 1}"

    def cells(self) -> list[dict]:
        dlat, dlng = (self.lat1 - self.lat0) / self.n, (self.lng1 - self.lng0) / self.n
        return [
            {"zone": f"{chr(65 + c)}{r + 1}", "congestion": round(float(self.grid[r, c]), 3),
             "bounds": [[self.lat0 + r * dlat, self.lng0 + c * dlng], [self.lat0 + (r + 1) * dlat, self.lng0 + (c + 1) * dlng]]}
            for r in range(self.n) for c in range(self.n)
        ]
