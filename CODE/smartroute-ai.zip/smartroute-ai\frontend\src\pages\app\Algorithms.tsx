import { Cpu, FlaskConical } from 'lucide-react'
import { useEffect, useState } from 'react'
import { Bar, BarChart, CartesianGrid, Cell, ErrorBar, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { ALGO_COLOR, ALGO_LABEL, ALGO_SHORT, api, type Evaluation } from '../../api'
import { PageHeader } from '../../components/Layout'
import { Card, Empty, ErrorBanner, Loading, SyntheticNotice } from '../../components/ui'
import { num, pct } from '../../format'
import { useAction, useApi, useSim } from '../../hooks'

interface Run { id: number; kind: string; algorithm: string; status: string; seconds: number | null; started_at: string; config: Record<string, unknown>; result: Record<string, unknown> }
interface TrainLog { iteration: number; mean_episode_reward: number }
interface JobState { busy: boolean; job: string | null; progress: Record<string, number> | null; error: string | null }

const ROWS: [string, string, 1 | -1, (v: number) => string][] = [
  ['avg_eta_min', 'Average travel time (min)', -1, v => num(v, 1)],
  ['total_km', 'Total distance (km)', -1, v => num(v, 1)],
  ['expected_on_time_rate', 'Expected on-time rate', 1, v => pct(v, 1)],
  ['deadline_feasible_rate', 'Deadline-feasible rate', 1, v => pct(v, 1)],
  ['avg_risk', 'Average risk', -1, v => num(v, 3)],
  ['avg_cvar_late_min', 'Tail lateness CVaR₀.₁ (min)', -1, v => num(v, 1)],
  ['workload_balance', 'Workload balance (Jain)', 1, v => num(v, 3)],
  ['utilization', 'Partner utilization', 1, v => pct(v, 1)],
]
const ORDER = ['nearest', 'hungarian', 'riskaware_hungarian', 'ppo', 'smartroute']

/** Two results differ "clearly" only if their 95% intervals do not overlap. */
const clearlyBetter = (a: { mean: number; ci95: number }, b: { mean: number; ci95: number }, dir: 1 | -1) =>
  dir * (a.mean - b.mean) > a.ci95 + b.ci95

export default function Algorithms() {
  const { version } = useSim()
  const [job, setJob] = useState<JobState | null>(null)
  const [iters, setIters] = useState(40)
  const [algo, setAlgo] = useState<'ppo' | 'smartroute'>('smartroute')
  const [scen, setScen] = useState(30)
  const act = useAction()
  const [tick, setTick] = useState(0)

  useEffect(() => {
    let alive = true
    const poll = async () => {
      const s = await api.get<JobState>('/jobs/status').catch(() => null)
      if (!alive || !s) return
      setJob(s)
      if (s.busy) setTimeout(poll, 1000)
      else setTick(t => t + 1)
    }
    poll()
    return () => { alive = false }
  }, [version, act.busy])
  const { data } = useApi<{ runs: Run[]; shipped: { algorithm: string; seconds: number; logs: TrainLog[] }[] }>('/training-runs', [tick])
  const evalRun = data?.runs.find(r => r.kind === 'evaluate' && r.status === 'done')
  const ev = evalRun?.result as unknown as Evaluation | undefined
  const algos = ev ? ORDER.filter(a => a in ev.results) : []

  const start = (path: string, body: unknown) => act.run('Starting job…', async () => { await api.post(path, body); setJob({ busy: true, job: path, progress: null, error: null }); setTick(t => t + 1) })
  const trainRuns = data?.runs.filter(r => r.kind === 'train' && r.status === 'done') ?? []
  const curves = [
    ...(data?.shipped ?? []).map(s => ({ name: `${ALGO_LABEL[s.algorithm]} (shipped, ${s.logs.length} it)`, logs: s.logs, color: ALGO_COLOR[s.algorithm] })),
    ...trainRuns.slice(0, 2).map(r => ({ name: `${ALGO_LABEL[r.algorithm]} run #${r.id}`, logs: (r.result.logs as TrainLog[]) ?? [], color: r.algorithm === 'ppo' ? '#f59e0b' : '#14b8a6' })),
  ]

  return (
    <>
      <PageHeader title="Algorithm Center" crumb="Decide" />
      <div className="content">
        <SyntheticNotice>All numbers are simulation results on synthetic scenarios. They do not represent real-world delivery performance.</SyntheticNotice>
        {act.error && <ErrorBanner error={act.error} onClose={act.clearError} />}
        {job?.busy && <div className="notice info" role="status"><span className="spinner" style={{ width: 16, height: 16, borderWidth: 2 }} />
          {job.job?.includes('train') ? 'Training model…' : 'Running evaluation…'} {job.progress?.iteration != null && `iteration ${job.progress.iteration}/${job.progress.of} · mean episode reward ${job.progress.mean_episode_reward}`}</div>}
        {job?.error && <div className="notice" role="alert">{job.error}</div>}

        <Card title="Multi-scenario evaluation" right={
          <div className="row">
            <label className="row" style={{ fontSize: 12.5 }}>Scenarios <select className="select" value={scen} onChange={e => setScen(Number(e.target.value))}>{[10, 30, 60, 100].map(n => <option key={n}>{n}</option>)}</select></label>
            <button className="btn primary" disabled={job?.busy || !!act.busy} onClick={() => start('/evaluate', { scenarios: scen })}><FlaskConical size={14} />Run evaluation</button>
          </div>}>
          {!data ? <Loading label="Loading analytics…" /> : !ev ? <Empty title="No evaluation yet" hint="Run an evaluation to compare algorithms on identical scenarios." /> : (
            <>
              <p className="muted" style={{ marginBottom: 10 }}>
                {ev.scenarios} randomly generated scenarios (seed {ev.seed}; 4–12 partners, 5–25 orders, random traffic 0.2–1.0, existing workloads).
                Every algorithm sees exactly the same scenarios. Values are mean ± 95% confidence interval.
                Bold teal = clearly better than <em>every</em> other algorithm (non-overlapping intervals); otherwise differences are not statistically clear.
              </p>
              <div className="table-wrap">
                <table className="t">
                  <thead><tr><th>Metric</th>{algos.map(a => <th key={a} className="num">{ALGO_LABEL[a]}</th>)}</tr></thead>
                  <tbody>
                    {ROWS.map(([k, label, dir, f]) => (
                      <tr key={k}><td>{label}</td>{algos.map(a => {
                        const m = ev.results[a][k]
                        const wins = algos.every(b => b === a || clearlyBetter(m, ev.results[b][k], dir))
                        return <td key={a} className="num" style={wins ? { color: 'var(--teal)', fontWeight: 700 } : undefined}>{f(m.mean)} <span className="faint">± {f(m.ci95)}</span></td>
                      })}</tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="grid g2" style={{ marginTop: 14 }}>
                {(['expected_on_time_rate', 'avg_risk'] as const).map(k => (
                  <div key={k}>
                    <strong style={{ fontSize: 12.5 }}>{ROWS.find(r => r[0] === k)![1]}</strong>
                    <ResponsiveContainer width="100%" height={200}>
                      <BarChart data={algos.map(a => ({ name: ALGO_SHORT[a], v: ev.results[a][k].mean, e: ev.results[a][k].ci95 }))} margin={{ left: -14, right: 8 }}>
                        <CartesianGrid stroke="#eef2f7" vertical={false} />
                        <XAxis dataKey="name" fontSize={11} interval={0} />
                        <YAxis fontSize={11} domain={[0, k === 'avg_risk' ? 'auto' : 1]} />
                        <Tooltip formatter={(v) => Number(v).toFixed(3)} />
                        <Bar dataKey="v" name="mean" isAnimationActive={false}>
                          {algos.map(a => <Cell key={a} fill={ALGO_COLOR[a]} />)}
                          <ErrorBar dataKey="e" width={6} stroke="#0b1324" />
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                ))}
              </div>
              <Interpretation ev={ev} />
            </>
          )}
        </Card>

        <div className="grid g2">
          <Card title="How each algorithm decides">
            <dl className="stack" style={{ margin: 0 }}>
              <div><strong>Nearest Partner</strong><p className="muted">Each order (earliest deadline first) goes to the eligible partner physically closest to the pickup. Ignores traffic, deadlines and workload.</p></div>
              <div><strong>Hungarian Algorithm</strong><p className="muted">Exact minimum-cost matching (scipy linear_sum_assignment) over a cost matrix of travel time, distance, risk, workload and lateness; partners expanded into capacity slots.</p></div>
              <div><strong>PPO</strong><p className="muted">A NumPy actor-critic trained with Proximal Policy Optimization (clipped objective, GAE) in a dispatch MDP. Base reward: on-time, travel time, distance, workload. Chooses one order at a time.</p></div>
              <div><strong>SmartRoute AI</strong><p className="muted">Risk-aware matching: Hungarian cost + CVaR₀.₁ tail-lateness + delay probability, with the risk-aware PPO policy's log-probability as a learned prior (β = 2), solved exactly.</p></div>
              <div><strong>Not implemented</strong><p className="muted">Graph Attention Networks (GAT) and SHAP are not used. Explanations are labelled “surrogate feature explanation”.</p></div>
            </dl>
          </Card>
          <Card title="Training" right={<Cpu size={15} className="faint" />}>
            <div className="row" style={{ marginBottom: 10 }}>
              <label className="field">Model<select className="select" value={algo} onChange={e => setAlgo(e.target.value as 'ppo' | 'smartroute')}>
                <option value="smartroute">Risk-aware PPO (SmartRoute prior)</option><option value="ppo">PPO (base reward)</option></select></label>
              <label className="field">Iterations<select className="select" value={iters} onChange={e => setIters(Number(e.target.value))}>{[10, 40, 100, 250].map(n => <option key={n}>{n}</option>)}</select></label>
              <button className="btn dark" style={{ alignSelf: 'flex-end' }} disabled={job?.busy || !!act.busy} onClick={() => start('/train', { algorithm: algo, iterations: iters })}>Train model</button>
            </div>
            <p className="faint" style={{ fontSize: 12, marginBottom: 8 }}>Training replaces the active weights. ~0.4 s per iteration (24 episodes). Shipped weights: 250 iterations each. Re-run the evaluation afterwards — fewer iterations usually perform worse.</p>
            {curves.length === 0 ? <Empty title="No training logs" /> : (
              <ResponsiveContainer width="100%" height={220}>
                <LineChart margin={{ left: -10, right: 8 }}>
                  <CartesianGrid stroke="#eef2f7" vertical={false} />
                  <XAxis dataKey="iteration" type="number" fontSize={11} allowDuplicatedCategory={false} />
                  <YAxis fontSize={11} />
                  <Tooltip formatter={(v) => Number(v).toFixed(2)} />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                  {curves.map(c => <Line key={c.name} data={c.logs} dataKey="mean_episode_reward" name={c.name} stroke={c.color} dot={false} isAnimationActive={false} />)}
                </LineChart>
              </ResponsiveContainer>
            )}
            <p className="faint" style={{ fontSize: 11.5 }}>Mean episode reward per iteration (higher is better). Base and risk-aware rewards are on different scales and are not directly comparable.</p>
          </Card>
        </div>
      </div>
    </>
  )
}

function Interpretation({ ev }: { ev: Evaluation }) {
  const r = ev.results
  if (!r.smartroute || !r.hungarian) return null
  const lines: string[] = []
  for (const [k, label, dir] of ROWS.slice(0, 7)) {
    const s = r.smartroute[k], h = r.hungarian[k]
    if (clearlyBetter(s, h, dir)) lines.push(`SmartRoute AI is clearly better than Hungarian on ${label.toLowerCase()}.`)
    else if (clearlyBetter(h, s, dir)) lines.push(`Hungarian is clearly better than SmartRoute AI on ${label.toLowerCase()}.`)
  }
  if (!lines.length) lines.push('SmartRoute AI and Hungarian are not clearly different on any headline metric in this evaluation.')
  if (r.nearest) {
    const sn = r.smartroute.expected_on_time_rate, nn = r.nearest.expected_on_time_rate
    if (clearlyBetter(sn, nn, 1)) lines.push(`SmartRoute AI has a clearly higher expected on-time rate than Nearest Partner (${pct(sn.mean)} vs ${pct(nn.mean)}).`)
  }
  if (r.ppo && r.hungarian && clearlyBetter(r.ppo.total_km, r.hungarian.total_km, -1)) lines.push('Standalone PPO drives clearly fewer kilometres than Hungarian.')
  return (
    <div className="notice info" style={{ marginTop: 12 }}>
      <div><strong>Interpretation (generated from the table):</strong>
        <ul style={{ margin: '4px 0 0', paddingLeft: 18 }}>
          {lines.map(l => <li key={l}>{l}</li>)}
        </ul>
      </div>
    </div>
  )
}
