from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import JSON, Boolean, DateTime, Float, ForeignKey, Integer, String, create_engine
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker

from .config import settings

engine = create_engine(settings.database_url, connect_args={"check_same_thread": False}
                       if settings.database_url.startswith("sqlite") else {})
SessionLocal = sessionmaker(engine, expire_on_commit=False)


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(80))
    role: Mapped[str] = mapped_column(String(40), default="dispatcher")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class SimulationRun(Base):
    __tablename__ = "simulation_runs"
    id: Mapped[int] = mapped_column(primary_key=True)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    seed: Mapped[int] = mapped_column(Integer)
    n_partners: Mapped[int] = mapped_column(Integer)
    algorithm: Mapped[str] = mapped_column(String(40))
    traffic_level: Mapped[float] = mapped_column(Float)
    order_rate: Mapped[float] = mapped_column(Float)
    sim_time: Mapped[float] = mapped_column(Float, default=0.0)
    status: Mapped[str] = mapped_column(String(20), default="idle")


class OrderRow(Base):
    __tablename__ = "orders"
    pk: Mapped[int] = mapped_column(primary_key=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("simulation_runs.id"), index=True)
    id: Mapped[str] = mapped_column(String(16), index=True)
    priority: Mapped[str] = mapped_column(String(10))
    pickup_name: Mapped[str] = mapped_column(String(60))
    drop_name: Mapped[str] = mapped_column(String(60))
    pickup_lat: Mapped[float] = mapped_column(Float)
    pickup_lng: Mapped[float] = mapped_column(Float)
    drop_lat: Mapped[float] = mapped_column(Float)
    drop_lng: Mapped[float] = mapped_column(Float)
    created_at: Mapped[float] = mapped_column(Float)
    deadline: Mapped[float] = mapped_column(Float)
    status: Mapped[str] = mapped_column(String(16), index=True)
    partner_id: Mapped[str | None] = mapped_column(String(16), nullable=True)
    assigned_by: Mapped[str | None] = mapped_column(String(40), nullable=True)
    assigned_at: Mapped[float | None] = mapped_column(Float, nullable=True)
    planned_eta: Mapped[float | None] = mapped_column(Float, nullable=True)
    planned_km: Mapped[float | None] = mapped_column(Float, nullable=True)
    planned_risk: Mapped[float | None] = mapped_column(Float, nullable=True)
    eta: Mapped[float | None] = mapped_column(Float, nullable=True)
    delivered_at: Mapped[float | None] = mapped_column(Float, nullable=True)
    actual_km: Mapped[float] = mapped_column(Float, default=0.0)
    risk: Mapped[float] = mapped_column(Float, default=0.0)
    delay_prob: Mapped[float] = mapped_column(Float, default=0.0)
    risk_parts: Mapped[dict] = mapped_column(JSON, default=dict)


class PartnerRow(Base):
    __tablename__ = "partners"
    pk: Mapped[int] = mapped_column(primary_key=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("simulation_runs.id"), index=True)
    id: Mapped[str] = mapped_column(String(16), index=True)
    name: Mapped[str] = mapped_column(String(60))
    lat: Mapped[float] = mapped_column(Float)
    lng: Mapped[float] = mapped_column(Float)
    capacity: Mapped[int] = mapped_column(Integer)
    speed_kmh: Mapped[float] = mapped_column(Float)
    online: Mapped[bool] = mapped_column(Boolean, default=True)
    completed: Mapped[int] = mapped_column(Integer, default=0)
    on_time: Mapped[int] = mapped_column(Integer, default=0)
    distance_km: Mapped[float] = mapped_column(Float, default=0.0)
    route: Mapped[list] = mapped_column(JSON, default=list)
    trail: Mapped[list] = mapped_column(JSON, default=list)


class AssignmentRow(Base):
    __tablename__ = "assignments"
    id: Mapped[int] = mapped_column(primary_key=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("simulation_runs.id"), index=True)
    batch_id: Mapped[str] = mapped_column(String(40), index=True)
    order_id: Mapped[str] = mapped_column(String(16), index=True)
    partner_id: Mapped[str] = mapped_column(String(16))
    algorithm: Mapped[str] = mapped_column(String(40))
    sim_time: Mapped[float] = mapped_column(Float)
    confidence: Mapped[float | None] = mapped_column(Float, nullable=True)
    eta_min: Mapped[float] = mapped_column(Float)
    km: Mapped[float] = mapped_column(Float)
    risk: Mapped[float] = mapped_column(Float)
    risk_level: Mapped[str] = mapped_column(String(10))
    delay_prob: Mapped[float] = mapped_column(Float)
    feasible: Mapped[bool] = mapped_column(Boolean)
    load_after: Mapped[int] = mapped_column(Integer)
    capacity: Mapped[int] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class ExplanationRow(Base):
    __tablename__ = "explanations"
    id: Mapped[int] = mapped_column(primary_key=True)
    assignment_id: Mapped[int] = mapped_column(ForeignKey("assignments.id"), unique=True)
    payload: Mapped[dict] = mapped_column(JSON)


class TrafficSnapshot(Base):
    __tablename__ = "traffic"
    id: Mapped[int] = mapped_column(primary_key=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("simulation_runs.id"), index=True)
    sim_time: Mapped[float] = mapped_column(Float)
    level: Mapped[float] = mapped_column(Float)
    mean_congestion: Mapped[float] = mapped_column(Float)
    max_congestion: Mapped[float] = mapped_column(Float)


class RiskEvent(Base):
    __tablename__ = "risk_events"
    id: Mapped[int] = mapped_column(primary_key=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("simulation_runs.id"), index=True)
    sim_time: Mapped[float] = mapped_column(Float)
    category: Mapped[str] = mapped_column(String(20))  # traffic | delay | distance | workload | deadline
    level: Mapped[str] = mapped_column(String(10))
    entity_type: Mapped[str] = mapped_column(String(10))
    entity_id: Mapped[str] = mapped_column(String(16))
    message: Mapped[str] = mapped_column(String(300))
    action: Mapped[str] = mapped_column(String(300))


class MetricSnapshot(Base):
    __tablename__ = "metrics"
    id: Mapped[int] = mapped_column(primary_key=True)
    run_id: Mapped[int] = mapped_column(ForeignKey("simulation_runs.id"), index=True)
    sim_time: Mapped[float] = mapped_column(Float)
    payload: Mapped[dict] = mapped_column(JSON)


class TrainingRun(Base):
    __tablename__ = "training_runs"
    id: Mapped[int] = mapped_column(primary_key=True)
    kind: Mapped[str] = mapped_column(String(20))  # train | evaluate
    algorithm: Mapped[str] = mapped_column(String(40))
    status: Mapped[str] = mapped_column(String(20))
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    seconds: Mapped[float | None] = mapped_column(Float, nullable=True)
    config: Mapped[dict] = mapped_column(JSON, default=dict)
    result: Mapped[dict] = mapped_column(JSON, default=dict)


def init_db() -> None:
    Base.metadata.create_all(engine)
    with SessionLocal() as s:
        if not s.query(User).first():
            s.add(User(name="Demo Dispatcher", role="dispatcher"))
            s.commit()
