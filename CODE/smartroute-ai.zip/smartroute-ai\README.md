---
title: SmartRoute AI
emoji: 🚚
colorFrom: green
colorTo: blue
sdk: docker
app_port: 7860
pinned: false
short_description: Explainable, risk-aware last-mile delivery dispatch (demo)
---

# SmartRoute AI

**AI-Powered Dynamic Last-Mile Delivery Intelligence**: a research prototype of an AI-assisted dispatcher. It assigns delivery orders to partners using traffic, ETA, deadlines, workload, capacity and risk, and explains every decision.

> **All data is synthetic.** Orders, partners, locations and traffic come from a built-in simulator around a fictional service area. Every performance number in the app is a *simulation result*, not real-world delivery data.

## Quick start

Requirements: Python 3.12+ (tested on 3.14), Node 20+ (tested on 26), Google Chrome (only needed for E2E tests).

```bash
# 1. Backend  (http://127.0.0.1:8000, API docs at /docs)
cd backend
pip install -r requirements-dev.txt
SMARTROUTE_DEMO_PASSWORD=choose-a-password python -m uvicorn app.main:app --host 127.0.0.1 --port 8000

# 2. Frontend (http://127.0.0.1:5173). Proxies /api to the backend.
cd frontend
npm install
npm run dev
```

Open http://127.0.0.1:5173, then go to **Launch Live Demo** or **Explore Dashboard**. Sign in as `dispatcher` with the password you set.
If `SMARTROUTE_DEMO_PASSWORD` is not set, a random password is generated and printed in the backend log.

## Authentication

The public website is open. The dispatcher console (`/app/*`) and every API route except `/api/health` and `/api/auth/login` require sign-in.

- There is one demo account. Its password comes only from `SMARTROUTE_DEMO_PASSWORD` and is held in memory as a scrypt hash.
- Sessions are HMAC-SHA256-signed bearer tokens that expire after 12 hours. They are kept in the browser's `sessionStorage`, so closing the tab signs you out.
- Sign-in locks for 5 minutes after 5 failed attempts from one IP.
- Set `SMARTROUTE_SECRET_KEY` so sessions survive restarts. Without it, a random key is used and a restart signs everyone out.

## Deploy (free, one service)

The `Dockerfile` builds the React app and serves it from FastAPI, so the website, console and API share one URL.

**Render (free web service)**
1. Push this repository to GitHub.
2. In Render, choose New → Blueprint and select the repo. `render.yaml` is detected.
3. Enter `SMARTROUTE_DEMO_PASSWORD` when prompted. The secret key is generated for you.

Free instances sleep after 15 minutes idle; the first request then takes about a minute.

**Hugging Face Spaces (Docker SDK, free)**: create a Docker Space and push this repo to it. Add `SMARTROUTE_DEMO_PASSWORD` and `SMARTROUTE_SECRET_KEY` under Settings → Variables and secrets. Port 7860 is the default.

The free tiers have no persistent disk: the SQLite database lives in `/tmp` and resets on every restart or redeploy. The simulation reseeds itself, and the shipped models and benchmark are baked into the image.

Production build: `cd frontend && npm run build && npm run preview` (the preview server also proxies `/api`).

## What is implemented

| Capability | Implementation | Where |
|---|---|---|
| Distance / ETA engine | Haversine × 1.3 road factor; queue-aware ETA; speed falls with congestion (up to 50%) | `backend/app/core/geo.py`, `candidate.py` |
| Traffic simulation | 8×8 congestion grid: hotspot corridors × level + AR(1) noise | `core/traffic.py` |
| Risk engine | Travel time ~ Normal(ETA, σ). Delay probability, CVaR₀.₁ tail lateness, weighted composite risk (weights configurable) | `core/risk.py` |
| Nearest Partner | Baseline: closest eligible partner to the pickup | `algorithms/nearest.py` |
| Hungarian Algorithm | Exact min-cost matching (`scipy.optimize.linear_sum_assignment`) over capacity-slot-expanded cost matrices | `algorithms/hungarian.py` |
| RL environment | Dispatch MDP: per-(order, partner) feature rows, masked variable action set, base and risk-aware rewards | `rl/env.py`, `rl/reward.py` |
| PPO | NumPy actor-critic: clipped objective, GAE(λ), Adam, gradient-checked backprop | `rl/nn.py`, `rl/ppo.py` |
| SmartRoute AI | Hungarian cost + CVaR + delay-probability terms, plus the risk-aware PPO policy's log-probability as a learned prior (β = 2), solved exactly | `algorithms/smartroute.py` |
| Explainability | Fact-checked reasons vs every alternative, exact cost breakdown, feature-ablation attribution on the policy (**surrogate explanation, not SHAP**) | `app/explain.py` |
| Live simulation | Server-side clock (1 tick/s), Poisson arrivals, partner movement, auto-assignment batches, risk events | `services/simulation.py` |
| Evaluation | All algorithms on identical held-out scenarios, mean ± 95% CI | `rl/benchmark.py` |

**Not implemented:** Graph Attention Networks and SHAP. The UI labels them that way.

**Why NumPy instead of PyTorch:** PyTorch's DLLs were blocked by Windows Application Control on the development machine. PPO is therefore implemented directly in NumPy, and `tests/test_rl.py` verifies its gradients against finite differences.

## Honest results (shipped weights, 60 held-out scenarios, seed 2026)

| | Nearest | Hungarian | PPO | SmartRoute AI |
|---|---|---|---|---|
| Expected on-time | 53.5% ± 4.9 | 80.5% ± 4.2 | 71.3% ± 6.0 | 80.7% ± 4.1 |
| Deadline-feasible | 50.9% ± 6.0 | 87.3% ± 5.4 | 77.0% ± 7.5 | 87.2% ± 5.1 |
| Average risk | 0.486 | 0.355 | 0.391 | 0.355 |
| Total distance (km) | 95.6 | 89.4 | 86.7 | 90.1 |

SmartRoute AI and Hungarian are **not statistically distinguishable** on this benchmark. Both are clearly better than Nearest Partner. Standalone PPO drives the fewest kilometres but meets fewer deadlines. β was tuned on a different seed (12345) to avoid test-set leakage. Re-run the evaluation from **Algorithm Center → Run evaluation**.

## Tests

```bash
cd backend && python -m pytest -q          # 59 unit + API/integration + auth tests
cd frontend && npx playwright test          # 14 E2E tests (system Chrome; backend must use SMARTROUTE_DEMO_PASSWORD=e2e-local-pass or the same env var)
```

E2E coverage: the full generate → assign → explain → map → analytics flow, the live simulation clock, the Smart Demo pipeline, reports, a friendly error state, and every route at 320–1440 px. Each route is checked for zero console errors, zero failed API calls and no horizontal overflow.

Re-train the shipped models (about 4 minutes): `cd backend && python -m app.rl.train_cli 250`

## Architecture

```
backend/app
  api/         ops.py, ai.py, sim.py      HTTP routes (thin)
  services/    simulation, analytics, training, views
  algorithms/  nearest, hungarian, learned (PPO), smartroute, registry
  rl/          env, reward, nn, ppo, benchmark, weights/
  core/        domain, geo, traffic, risk, candidate, scenario
  db.py        SQLAlchemy models (users, orders, partners, assignments, explanations,
               traffic, risk_events, simulation_runs, metrics, training_runs)
frontend/src
  api.ts, hooks.tsx      typed API client; sim status polled only while running
  components/            Layout, OpsMap (Leaflet), OpsView, Decision, ui primitives
  pages/app/*            13 application pages (code-split)
  pages/public/*         marketing site + SVG hero
```

## Configuration

| Variable | Default |
|---|---|
| `SMARTROUTE_DATABASE_URL` | `sqlite:///backend/data/smartroute.db` |
| `SMARTROUTE_CORS_ORIGINS` | `http://localhost:5173,http://127.0.0.1:5173` |
| `SMARTROUTE_MODEL_DIR` | `backend/app/rl/weights` |
| `SMARTROUTE_SEED` | `42` |
| `SMARTROUTE_DEMO_USER` / `SMARTROUTE_DEMO_PASSWORD` | `dispatcher` / random, printed at startup |
| `SMARTROUTE_SECRET_KEY` | random per process |
| `SMARTROUTE_FRONTEND_DIST` | `frontend/dist` (served by FastAPI if present) |
| `VITE_TILE_URL` / `VITE_TILE_ATTRIBUTION` | OpenStreetMap standard tiles (keyless; respect the OSM tile usage policy, and use a keyed provider in production) |

## Known limitations

- A single shared demo account (no user management or roles).
- On free hosting the database resets whenever the service restarts.
- Road distance is approximated (no road graph), and traffic is synthetic.
- Risk weights and the cost weights are design choices, not calibrated values.
- Risk-weight changes in Settings last only for the life of the server process.
- One simulation world per server process.
