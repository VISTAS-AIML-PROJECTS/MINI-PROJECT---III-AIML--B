import type { Order, Partner } from '../../api'
import { PageHeader } from '../../components/Layout'
import OpsView from '../../components/OpsView'
import { Card, Empty, SyntheticNotice } from '../../components/ui'
import { clock, riskColor } from '../../format'
import { useApi, useSim } from '../../hooks'

const WINDOW = 90 // minutes shown on the timeline

/** Dispatcher timeline: each partner's upcoming deliveries (live ETA) against their deadlines. */
function Timeline({ now }: { now: number }) {
  const { data: o } = useApi<{ orders: Order[] }>('/orders')
  const { data: p } = useApi<{ partners: Partner[] }>('/partners')
  if (!o || !p) return null
  const byId = new Map(o.orders.map(x => [x.id, x]))
  const rows = p.partners.filter(x => x.online)
  const x = (t: number) => `${Math.max(0, Math.min(1, (t - now) / WINDOW)) * 100}%`
  const ticks = [0, 15, 30, 45, 60, 75, 90]
  return (
    <Card title="Partner timeline" right={<span className="faint" style={{ fontSize: 12 }}>Next {WINDOW} min · ● ETA · │ deadline</span>}>
      {rows.every(r => r.route.length === 0) ? <Empty title="No routes in progress" hint="Assign orders to see each partner's delivery sequence." /> : (
        <div style={{ overflowX: 'auto' }}>
          <div style={{ minWidth: 560 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '64px 1fr', fontSize: 11, color: 'var(--faint)' }}>
              <span />
              <div style={{ position: 'relative', height: 16 }}>
                {ticks.map(t => <span key={t} style={{ position: 'absolute', left: `${(t / WINDOW) * 100}%`, transform: 'translateX(-50%)' }}>{clock(now + t)}</span>)}
              </div>
            </div>
            {rows.map(pt => {
              const drops = pt.route.filter(s => s.kind === 'dropoff').map(s => byId.get(s.order_id)).filter((v): v is Order => !!v && v.eta != null)
              return (
                <div key={pt.id} style={{ display: 'grid', gridTemplateColumns: '64px 1fr', alignItems: 'center', height: 30 }}>
                  <span className="mono" style={{ fontSize: 12 }}>{pt.id}</span>
                  <div style={{ position: 'relative', height: 18, background: 'var(--surface-2)', borderRadius: 4 }}>
                    {drops.length > 0 && <div style={{ position: 'absolute', left: 0, width: x(Math.max(...drops.map(d => d.eta!))), top: 8, height: 2, background: '#cbd5e1' }} />}
                    {drops.map(d => (
                      <span key={d.id}>
                        <span title={`${d.id} deadline ${clock(d.deadline)}`} style={{ position: 'absolute', left: x(d.deadline), top: 0, bottom: 0, width: 2, background: '#0b1324', opacity: 0.35 }} />
                        <span title={`${d.id} ETA ${clock(d.eta!)} · risk ${d.risk.toFixed(2)}`} style={{ position: 'absolute', left: x(d.eta!), top: 3, width: 12, height: 12, marginLeft: -6, borderRadius: '50%', background: riskColor(d.risk), border: '2px solid #fff' }} />
                      </span>
                    ))}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}
    </Card>
  )
}

export default function LiveMap() {
  const { sim } = useSim()
  return (
    <>
      <PageHeader title="Live Map" crumb="Operate" />
      <div className="content">
        <SyntheticNotice>Partner positions move only when the backend simulation advances. Dashed lines are planned routes; solid dark lines are the paths actually driven.</SyntheticNotice>
        <OpsView now={sim?.sim_time ?? 0} height={620} filters />
        <Timeline now={sim?.sim_time ?? 0} />
      </div>
    </>
  )
}
