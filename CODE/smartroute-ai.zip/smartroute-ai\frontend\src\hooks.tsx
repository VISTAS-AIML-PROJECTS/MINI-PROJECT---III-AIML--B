import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from 'react'
import { api, ApiError, type SimStatus } from './api'

/* Simulation status is polled only while the simulation is running. Every page keys its data
   fetches on `version`, which changes on each simulation tick or explicit refresh. */
interface SimCtx { sim: SimStatus | null; version: number; error: ApiError | null; refresh: () => void }
const Ctx = createContext<SimCtx>({ sim: null, version: 0, error: null, refresh: () => {} })
const POLL_MS = 1500

export function SimProvider({ children }: { children: ReactNode }) {
  const [sim, setSim] = useState<SimStatus | null>(null)
  const [version, setVersion] = useState(0)
  const [error, setError] = useState<ApiError | null>(null)
  const load = useCallback(async () => {
    try {
      const s = await api.get<SimStatus>('/simulation/status')
      setSim(prev => (prev && prev.sim_time === s.sim_time && prev.status === s.status && prev.run_id === s.run_id ? prev : s))
      setError(null)
    } catch (e) {
      if (e instanceof ApiError) setError(e)
    }
  }, [])
  const refresh = useCallback(() => { setVersion(v => v + 1); load() }, [load])
  useEffect(() => { load() }, [load])
  useEffect(() => {
    if (sim?.status !== 'running' || document.hidden) return
    const id = setInterval(load, POLL_MS)
    return () => clearInterval(id)
  }, [sim?.status, load])
  // a new tick (sim_time) or new run invalidates page data
  const tickKey = `${sim?.run_id}:${sim?.sim_time}`
  const last = useRef(tickKey)
  useEffect(() => { if (last.current !== tickKey) { last.current = tickKey; setVersion(v => v + 1) } }, [tickKey])
  return <Ctx.Provider value={{ sim, version, error, refresh }}>{children}</Ctx.Provider>
}

export const useSim = () => useContext(Ctx)

/** GET a resource; refetches when the simulation ticks. Keeps previous data during refetch. */
export function useApi<T>(path: string | null, extraDeps: unknown[] = []) {
  const { version } = useSim()
  const [data, setData] = useState<T | null>(null)
  const [error, setError] = useState<ApiError | null>(null)
  const [loading, setLoading] = useState(true)
  useEffect(() => {
    if (!path) return
    const ctl = new AbortController()
    setLoading(true)
    api.get<T>(path, ctl.signal)
      .then(d => { setData(d); setError(null) })
      .catch(e => { if (e instanceof ApiError) setError(e) })
      .finally(() => { if (!ctl.signal.aborted) setLoading(false) })
    return () => ctl.abort()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [path, version, ...extraDeps])
  return { data, error, loading: loading && data === null, refreshing: loading }
}

/** Wrap a mutating call with busy + error state. */
export function useAction() {
  const [busy, setBusy] = useState<string | null>(null)
  const [error, setError] = useState<ApiError | null>(null)
  const run = useCallback(async <T,>(label: string, fn: () => Promise<T>): Promise<T | undefined> => {
    setBusy(label)
    setError(null)
    try {
      return await fn()
    } catch (e) {
      setError(e instanceof ApiError ? e : new ApiError(0, 'Unexpected error.'))
      return undefined
    } finally {
      setBusy(null)
    }
  }, [])
  return { busy, error, run, clearError: () => setError(null) }
}
