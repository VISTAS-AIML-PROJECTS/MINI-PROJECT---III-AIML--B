"""Vercel serverless entry point: exposes the FastAPI app from ../backend."""
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "backend"))
os.environ.setdefault("SMARTROUTE_DATABASE_URL", "sqlite:////tmp/smartroute.db")  # only /tmp is writable

from app.db import init_db  # noqa: E402
from app.main import app, seed_shipped_benchmark  # noqa: E402,F401

# Lifespan events are not guaranteed on serverless; initialise at import (idempotent).
init_db()
seed_shipped_benchmark()
