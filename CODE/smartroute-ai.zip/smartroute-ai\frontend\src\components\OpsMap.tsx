import 'leaflet/dist/leaflet.css'
import { useEffect, useMemo, useRef, useState } from 'react'
import { CircleMarker, MapContainer, Polyline, Rectangle, TileLayer, Tooltip, useMap, ZoomControl } from 'react-leaflet'
import type { LatLngBoundsExpression } from 'leaflet'
import type { Order, Partner, TrafficCell } from '../api'
import { congestionColor, riskColor } from '../format'

// Keyless OpenStreetMap tiles by default (fine for demos; respect the OSM tile usage policy).
// For production set VITE_TILE_URL / VITE_TILE_ATTRIBUTION to a provider you hold a key for.
const TILE_URL = import.meta.env.VITE_TILE_URL ?? 'https://tile.openstreetmap.org/{z}/{x}/{y}.png'
const TILE_ATTRIBUTION = import.meta.env.VITE_TILE_ATTRIBUTION ?? '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'

export type Selection = { type: 'order' | 'partner'; id: string } | null

const PARTNER_COLOR: Record<string, string> = {
  available: '#15803d', busy: '#0d9488', at_capacity: '#d97706', at_risk: '#dc2626', offline: '#94a3b8',
}
const ORDER_COLOR: Record<string, string> = {
  pending: '#2563eb', assigned: '#6d5bd0', in_transit: '#0d9488', at_risk: '#ea580c', delayed: '#dc2626', delivered: '#94a3b8',
}

function FitOnce({ bounds }: { bounds: LatLngBoundsExpression | null }) {
  const map = useMap()
  const done = useRef(false)
  useEffect(() => {
    if (bounds && !done.current) { map.fitBounds(bounds, { padding: [20, 20] }); done.current = true }
  }, [bounds, map])
  return null
}

function FocusOn({ point }: { point: [number, number] | null }) {
  const map = useMap()
  useEffect(() => { if (point) map.panTo(point, { animate: true }) }, [point, map])
  return null
}

export default function OpsMap({ orders, partners, cells, selected, onSelect, showDelivered = false, height }: {
  orders: Order[]; partners: Partner[]; cells: TrafficCell[]; selected: Selection; onSelect: (s: Selection) => void
  showDelivered?: boolean; height?: number
}) {
  const [layers, setLayers] = useState({ traffic: true, routes: true, trails: true, orders: true })
  const toggle = (k: keyof typeof layers) => setLayers(l => ({ ...l, [k]: !l[k] }))
  const visibleOrders = useMemo(() => orders.filter(o => showDelivered || o.base_status !== 'delivered'), [orders, showDelivered])
  const hubs = useMemo(() => {
    const m = new Map<string, [number, number]>()
    orders.forEach(o => m.set(o.pickup.name, [o.pickup.lat, o.pickup.lng]))
    return [...m.entries()]
  }, [orders])
  const bounds = useMemo<LatLngBoundsExpression | null>(() => {
    if (!cells.length) return null
    return [cells[0].bounds[0], cells[cells.length - 1].bounds[1]]
  }, [cells])

  const selOrder = selected?.type === 'order' ? orders.find(o => o.id === selected.id) : undefined
  const selPartnerId = selected?.type === 'partner' ? selected.id : selOrder?.partner_id
  const focus: [number, number] | null = selected?.type === 'partner'
    ? (() => { const p = partners.find(x => x.id === selected.id); return p ? [p.lat, p.lng] : null })()
    : selOrder ? [selOrder.drop.lat, selOrder.drop.lng] : null

  return (
    <div className="map-card card" style={height ? { minHeight: height } : undefined}>
      <MapContainer className="map" style={height ? { minHeight: height } : undefined} center={[12.9716, 77.5946]} zoom={13}
        scrollWheelZoom preferCanvas attributionControl zoomControl={false}>
        <TileLayer url={TILE_URL} maxZoom={19} attribution={TILE_ATTRIBUTION} />
        <ZoomControl position="bottomright" />
        <FitOnce bounds={bounds} />
        <FocusOn point={focus} />
        {layers.traffic && cells.map(c => (
          <Rectangle key={c.zone} bounds={c.bounds} interactive={false}
            pathOptions={{ stroke: false, fillColor: congestionColor(c.congestion), fillOpacity: 0.08 + c.congestion * 0.22 }} />
        ))}
        {layers.trails && partners.map(p => p.trail.length > 1 && (
          <Polyline key={`t${p.id}`} positions={p.trail} interactive={false}
            pathOptions={{ color: '#0b1324', weight: p.id === selPartnerId ? 4 : 2, opacity: p.id === selPartnerId ? 0.7 : 0.18 }} />
        ))}
        {layers.routes && partners.map(p => p.route.length > 0 && (
          <Polyline key={`r${p.id}`} positions={[[p.lat, p.lng], ...p.route.map(s => [s.lat, s.lng] as [number, number])]}
            interactive={false}
            pathOptions={{ color: p.id === selPartnerId ? '#0d9488' : '#6d5bd0', weight: p.id === selPartnerId ? 4 : 2,
              opacity: selPartnerId && p.id !== selPartnerId ? 0.15 : 0.6, dashArray: '6 6' }} />
        ))}
        {selOrder && (
          <Polyline positions={[[selOrder.pickup.lat, selOrder.pickup.lng], [selOrder.drop.lat, selOrder.drop.lng]]}
            pathOptions={{ color: '#d97706', weight: 3, dashArray: '2 6' }} />
        )}
        {hubs.map(([name, pos]) => (
          <CircleMarker key={name} center={pos} radius={9} pathOptions={{ color: '#0b1324', weight: 3, fillColor: '#f59e0b', fillOpacity: 1 }}>
            <Tooltip direction="top">{name} (pickup hub)</Tooltip>
          </CircleMarker>
        ))}
        {layers.orders && visibleOrders.map(o => {
          const sel = selOrder?.id === o.id
          return (
            <CircleMarker key={o.id} center={[o.drop.lat, o.drop.lng]} radius={sel ? 8 : 5}
              eventHandlers={{ click: () => onSelect({ type: 'order', id: o.id }) }}
              pathOptions={{ color: sel ? '#0b1324' : '#fff', weight: sel ? 3 : 1.5, fillColor: ORDER_COLOR[o.status] ?? '#64748b', fillOpacity: 0.95 }}>
              <Tooltip direction="top">{o.id} · {o.status.replace('_', ' ')} · risk {o.risk.toFixed(2)}</Tooltip>
            </CircleMarker>
          )
        })}
        {partners.map(p => {
          const sel = p.id === selPartnerId
          return (
            <CircleMarker key={p.id} center={[p.lat, p.lng]} radius={sel ? 11 : 8}
              eventHandlers={{ click: () => onSelect({ type: 'partner', id: p.id }) }}
              pathOptions={{ color: sel ? '#0b1324' : riskColor(p.risk), weight: sel ? 4 : 2.5, fillColor: PARTNER_COLOR[p.status], fillOpacity: 1 }}>
              <Tooltip direction="top" permanent={sel}>{p.id} · {p.load}/{p.capacity} · {p.status.replace('_', ' ')}</Tooltip>
            </CircleMarker>
          )
        })}
      </MapContainer>
      <div className="map-toolbar" role="group" aria-label="Map layers">
        {(Object.keys(layers) as (keyof typeof layers)[]).map(k => (
          <button key={k} className={`btn sm ${layers[k] ? 'dark' : ''}`} aria-pressed={layers[k]} onClick={() => toggle(k)}>
            {k === 'trails' ? 'Actual paths' : k === 'routes' ? 'Planned routes' : k[0].toUpperCase() + k.slice(1)}
          </button>
        ))}
      </div>
      <div className="map-legend" aria-label="Map legend">
        <span><i style={{ background: '#f59e0b', border: '2px solid #0b1324' }} />Hub</span>
        <span><i style={{ background: PARTNER_COLOR.available }} />Partner available</span>
        <span><i style={{ background: PARTNER_COLOR.busy }} />Busy</span>
        <span><i style={{ background: PARTNER_COLOR.at_capacity }} />At capacity</span>
        <span><i style={{ background: ORDER_COLOR.pending }} />Pending order</span>
        <span><i style={{ background: ORDER_COLOR.at_risk }} />At risk</span>
        <span><i style={{ background: 'rgba(220,38,38,.35)', borderRadius: 2 }} />Congestion</span>
      </div>
    </div>
  )
}
