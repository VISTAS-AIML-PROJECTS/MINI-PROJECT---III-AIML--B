"""Request validation models (Pydantic)."""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field, field_validator, model_validator

Algorithm = Literal["nearest", "hungarian", "ppo", "smartroute"]
Priority = Literal["low", "normal", "high", "urgent"]


class AssignRequest(BaseModel):
    order_ids: list[str] | None = Field(default=None, max_length=200)
    apply: bool = False
    traffic_level: float | None = Field(default=None, ge=0, le=1)
    risk_sensitivity: Literal["low", "medium", "high"] = "medium"

    @field_validator("order_ids")
    @classmethod
    def _ids(cls, v):
        import re
        if v is not None and not all(re.fullmatch(r"O\d{3,6}", x) for x in v):
            raise ValueError("order_ids must look like 'O104'")
        return v


class CompareRequest(BaseModel):
    order_ids: list[str] | None = Field(default=None, max_length=200)
    traffic_level: float | None = Field(default=None, ge=0, le=1)
    risk_sensitivity: Literal["low", "medium", "high"] = "medium"
    algorithms: list[Algorithm] = Field(default_factory=lambda: ["nearest", "hungarian", "ppo", "smartroute"])


class GenerateOrders(BaseModel):
    count: int = Field(default=5, ge=1, le=50)
    priority: Priority | None = None


class PartnerPatch(BaseModel):
    online: bool


class SimConfigIn(BaseModel):
    n_partners: int | None = Field(default=None, ge=1, le=40)
    initial_orders: int | None = Field(default=None, ge=0, le=100)
    order_rate_per_hour: float | None = Field(default=None, ge=0, le=300)
    traffic_level: float | None = Field(default=None, ge=0, le=1)
    algorithm: Algorithm | None = None
    auto_assign: bool | None = None
    batch_every_min: float | None = Field(default=None, ge=1, le=30)
    minutes_per_tick: float | None = Field(default=None, ge=0.25, le=10)
    seed: int | None = Field(default=None, ge=0, le=2**31 - 1)


class StepRequest(BaseModel):
    minutes: float = Field(default=1.0, gt=0, le=60)


class TrainRequest(BaseModel):
    algorithm: Literal["ppo", "smartroute"] = "smartroute"
    iterations: int = Field(default=40, ge=2, le=500)


class EvaluateRequest(BaseModel):
    scenarios: int = Field(default=30, ge=5, le=200)
    seed: int = Field(default=2026, ge=0, le=2**31 - 1)


class RiskWeightsIn(BaseModel):
    traffic: float = Field(ge=0, le=1)
    delay: float = Field(ge=0, le=1)
    distance: float = Field(ge=0, le=1)
    workload: float = Field(ge=0, le=1)

    @model_validator(mode="after")
    def _nonzero(self):
        if self.traffic + self.delay + self.distance + self.workload <= 0:
            raise ValueError("At least one risk weight must be greater than zero.")
        return self
