import { Link } from 'react-router-dom'
import type { Order, Partner, RiskEvent, RiskLevel, TrafficCell } from '../../api'
import { PageHeader } from '../../components/Layout'
import { Bar, Card, Empty, ErrorState, Kpi, Loading, RiskBadge, StatusBadge, SyntheticNotice } from '../../components/ui'
import { clock, pct, riskColor, title } from '../../format'
import { useApi } from '../../hooks'

interface RiskSummary {
  sim_time: number; categories: Record<string, number>; category_basis: Record<string, string>; overall: number
  levels: Record<RiskLevel, number>; affected_orders: Order[]; affected_partners: Partner[]; zones: TrafficCell[]; events: RiskEvent[]
}

const LEVEL_OF = (s: number): RiskLevel => (s < 0.25 ? 'LOW' : s < 0.5 ? 'MEDIUM' : s < 0.75 ? 'HIGH' : 'CRITICAL')

function recommend(o: Order): string {
  if (o.base_status === 'pending') return o.minutes_to_deadline < 0 ? 'Overdue and unassigned — assign immediately.' : 'Assign now with SmartRoute AI to secure capacity.'
  const top = Object.entries(o.risk_parts).filter(([k]) => k !== 'score' && k !== 'level').sort((a, b) => Number(b[1]) - Number(a[1]))[0]?.[0]
  if (top === 'delay') return 'High delay probability — notify customer or reassign to a closer partner.'
  if (top === 'traffic') return 'Route crosses congested zones — monitor; avoid adding work to this partner.'
  if (top === 'workload') return 'Partner is heavily loaded — route new orders elsewhere.'
  return 'Long route — consider a partner closer to the pickup hub.'
}

export default function Risk() {
  const { data, error, loading } = useApi<RiskSummary>('/risk')
  return (
    <>
      <PageHeader title="Risk Center" crumb="Monitor" />
      <div className="content">
        <SyntheticNotice>Risk is computed from a Gaussian travel-time model on synthetic traffic. Component weights are configurable in Settings.</SyntheticNotice>
        {error ? <ErrorState error={error} /> : loading || !data ? <Loading label="Calculating risk…" /> : (
          <>
            <div className="kpis">
              <Kpi label="Overall active risk" value={<span style={{ color: riskColor(data.overall) }}>{data.overall.toFixed(2)}</span>} sub={LEVEL_OF(data.overall)} />
              {(['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'] as RiskLevel[]).map(l => <Kpi key={l} label={`${l} orders`} value={data.levels[l] ?? 0} />)}
            </div>
            <div className="grid g2">
              <Card title="Risk categories" right={<span className="faint" style={{ fontSize: 12 }}>0 = none · 1 = maximum</span>}>
                <div className="stack">
                  {Object.entries(data.categories).map(([k, v]) => (
                    <div key={k}>
                      <div className="meter-row"><strong>{title(k)} risk</strong><Bar value={v} color={riskColor(v)} /><span className="mono">{v.toFixed(2)}</span></div>
                      <div className="faint" style={{ fontSize: 11.5, marginLeft: 150 }}>{data.category_basis[k]}</div>
                    </div>
                  ))}
                </div>
              </Card>
              <Card title="Congested zones" right={<Link to="/app/map" className="btn sm">View on map</Link>}>
                <div className="stack">
                  {data.zones.map(z => (
                    <div key={z.zone} className="meter-row"><span className="mono">Zone {z.zone}</span><Bar value={z.congestion} color={riskColor(z.congestion)} /><span className="mono">{pct(z.congestion)}</span></div>
                  ))}
                </div>
              </Card>
            </div>
            <div className="grid g2">
              <Card title={`Affected orders (${data.affected_orders.length})`} flush>
                {data.affected_orders.length === 0 ? <Empty title="No high-risk orders" hint="Orders appear here when risk is HIGH/CRITICAL or they are at risk of delay." /> : (
                  <div className="list">
                    {data.affected_orders.map(o => (
                      <div key={o.id} className="list-item" style={{ cursor: 'default' }}>
                        <div style={{ flex: 1 }}>
                          <div className="row"><strong className="mono">{o.id}</strong><StatusBadge status={o.status} /><RiskBadge level={o.risk_level} score={o.risk} /></div>
                          <div className="faint" style={{ fontSize: 12 }}>Delay p {pct(o.delay_prob)} · {o.partner_id ?? 'unassigned'} · due {clock(o.deadline)}</div>
                          <div style={{ fontSize: 12.5, marginTop: 4 }}><strong>Recommended:</strong> {recommend(o)}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </Card>
              <Card title={`Affected partners (${data.affected_partners.length})`} flush>
                {data.affected_partners.length === 0 ? <Empty title="No partners at risk or at capacity" /> : (
                  <div className="list">
                    {data.affected_partners.map(p => (
                      <div key={p.id} className="list-item" style={{ cursor: 'default' }}>
                        <div style={{ flex: 1 }}>
                          <div className="row"><strong className="mono">{p.id}</strong><StatusBadge status={p.status} /><RiskBadge level={p.risk_level} score={p.risk} /></div>
                          <div className="faint" style={{ fontSize: 12 }}>{p.load}/{p.capacity} orders · {p.active_orders.join(', ')}</div>
                          <div style={{ fontSize: 12.5, marginTop: 4 }}><strong>Recommended:</strong> {p.status === 'at_capacity' ? 'No new orders until a delivery completes.' : 'Review the at-risk order on this route; consider reassignment.'}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </Card>
            </div>
            <Card title="Risk events" flush>
              {data.events.length === 0 ? <Empty title="No risk events yet" hint="Events are logged when an entity newly crosses a risk threshold." /> : (
                <div className="table-wrap" style={{ maxHeight: 360 }}>
                  <table className="t">
                    <thead><tr><th>Time</th><th>Category</th><th>Level</th><th>Entity</th><th>Message</th><th>Recommended action</th></tr></thead>
                    <tbody>{data.events.map(e => (
                      <tr key={e.id}><td className="mono">{clock(e.sim_time)}</td><td>{title(e.category)}</td><td><RiskBadge level={e.level} /></td>
                        <td className="mono">{e.entity_id}</td><td style={{ whiteSpace: 'normal' }}>{e.message}</td><td style={{ whiteSpace: 'normal' }}>{e.action}</td></tr>
                    ))}</tbody>
                  </table>
                </div>
              )}
            </Card>
          </>
        )}
      </div>
    </>
  )
}
