import { Activity, BrainCircuit, Clock, Gauge, Package, Route, ShieldAlert, Truck } from 'lucide-react'
import { Link } from 'react-router-dom'
import { Area, AreaChart, CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import type { Insight, Kpis } from '../../api'
import { PageHeader } from '../../components/Layout'
import OpsView from '../../components/OpsView'
import { Card, Empty, Kpi, SyntheticNotice } from '../../components/ui'
import { clock, mins, num, pct } from '../../format'
import { useApi, useSim } from '../../hooks'

export default function Dashboard() {
  const { sim } = useSim()
  const k = sim?.kpis
  const { data: ins } = useApi<{ insights: Insight[] }>('/insights')
  const { data: an } = useApi<{ history: (Kpis & { t: number })[] }>('/analytics')
  return (
    <>
      <PageHeader title="Operations Dashboard" crumb="Operate" />
      <div className="content">
        <SyntheticNotice />
        <div className="kpis k8" aria-label="Key performance indicators">
          <Kpi icon={<Package size={13} />} label="Active Orders" value={k?.active_orders ?? '—'} sub={k && `${k.pending_orders} pending`} />
          <Kpi icon={<Truck size={13} />} label="Available Partners" value={k ? `${k.available_partners}/${k.online_partners}` : '—'} sub="with free capacity / online" />
          <Kpi icon={<Clock size={13} />} label="On-Time Rate" value={pct(k?.on_time_rate)} sub={k && `${k.delivered_orders} delivered`} />
          <Kpi icon={<Activity size={13} />} label="Average ETA" value={mins(k?.avg_eta_min)} sub="active assigned orders" />
          <Kpi icon={<Route size={13} />} label="Total Distance" value={k ? `${num(k.total_distance_km, 1)} km` : '—'} sub="driven this run" />
          <Kpi icon={<ShieldAlert size={13} />} label="Average Risk" value={num(k?.avg_risk, 2)} sub="active orders, 0–1" />
          <Kpi icon={<Gauge size={13} />} label="Partner Utilization" value={pct(k?.utilization)} sub="load / capacity" />
          <Kpi icon={<BrainCircuit size={13} />} label="AI Assignments" value={k?.ai_assignments ?? '—'} sub="by PPO / SmartRoute AI" />
        </div>
        <OpsView now={sim?.sim_time ?? 0} height={520} />
        <div className="grid g2">
          <Card title="Operational trend" right={<span className="faint" style={{ fontSize: 12 }}>Simulation result</span>}>
            {an && an.history.length > 1 ? (
              <ResponsiveContainer width="100%" height={220}>
                <AreaChart data={an.history} margin={{ left: -18, right: 8 }}>
                  <CartesianGrid stroke="#eef2f7" vertical={false} />
                  <XAxis dataKey="t" tickFormatter={clock} fontSize={11} minTickGap={30} />
                  <YAxis fontSize={11} allowDecimals={false} />
                  <Tooltip labelFormatter={v => `Sim time ${clock(Number(v))}`} />
                  <Area type="monotone" dataKey="active_orders" name="Active orders" stroke="#6d5bd0" fill="#6d5bd0" fillOpacity={0.12} />
                  <Area type="monotone" dataKey="delivered_orders" name="Delivered" stroke="#0d9488" fill="#0d9488" fillOpacity={0.12} />
                </AreaChart>
              </ResponsiveContainer>
            ) : <Empty title="No history yet" hint="Run the simulation to build a timeline." />}
          </Card>
          <Card title="Risk & utilization" right={<span className="faint" style={{ fontSize: 12 }}>Simulation result</span>}>
            {an && an.history.length > 1 ? (
              <ResponsiveContainer width="100%" height={220}>
                <LineChart data={an.history} margin={{ left: -18, right: 8 }}>
                  <CartesianGrid stroke="#eef2f7" vertical={false} />
                  <XAxis dataKey="t" tickFormatter={clock} fontSize={11} minTickGap={30} />
                  <YAxis fontSize={11} domain={[0, 1]} />
                  <Tooltip labelFormatter={v => `Sim time ${clock(Number(v))}`} formatter={(v) => Number(v).toFixed(2)} />
                  <Line type="monotone" dataKey="avg_risk" name="Avg risk" stroke="#ea580c" dot={false} />
                  <Line type="monotone" dataKey="utilization" name="Utilization" stroke="#0d9488" dot={false} />
                  <Line type="monotone" dataKey="traffic_mean" name="Mean congestion" stroke="#94a3b8" dot={false} strokeDasharray="4 3" />
                </LineChart>
              </ResponsiveContainer>
            ) : <Empty title="No history yet" hint="Run the simulation to build a timeline." />}
          </Card>
        </div>
        <Card title="Business insights" right={<Link to="/app/analytics" className="btn sm">Analytics</Link>}>
          {ins?.insights.length ? (
            <ul style={{ margin: 0, paddingLeft: 18, display: 'grid', gap: 6 }}>
              {ins.insights.map((i, n) => <li key={n}>{i.text}</li>)}
            </ul>
          ) : <Empty title="No insights yet" hint="Insights appear only when the underlying data supports them." />}
        </Card>
      </div>
    </>
  )
}
