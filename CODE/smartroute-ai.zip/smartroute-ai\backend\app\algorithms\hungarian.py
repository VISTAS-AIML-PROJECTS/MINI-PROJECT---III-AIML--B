"""Hungarian-algorithm baseline (exact min-cost matching via app.algorithms.lsa).

Each partner is expanded into one column per free capacity slot. Slot k (0-based) is costed as if
k other new orders were queued ahead of it (k x average job minutes): a static approximation
since a one-shot matching cannot see how routes grow. Results are then replayed through the
shared sequential evaluator so metrics are comparable with the other algorithms.
"""
from __future__ import annotations

import numpy as np
from .lsa import linear_sum_assignment

from ..core.candidate import Candidate, eligible, evaluate
from ..core.domain import PRIORITY_WEIGHT
from ..core.geo import route_minutes
from .base import ordered, run_sequential

# Cost weights (minutes-equivalent). Configurable; chosen for this simulation, not calibrated.
WEIGHTS = {"travel": 1.0, "distance": 2.0, "risk": 30.0, "workload": 10.0, "lateness": 3.0}
INFEASIBLE = 1e6


def cost_components(c: Candidate, priority: str) -> dict:
    late = max(0.0, c.eta_min - c.slack_min)
    return {
        "travel": WEIGHTS["travel"] * c.eta_min,
        "distance": WEIGHTS["distance"] * c.km,
        "risk": WEIGHTS["risk"] * c.risk.score,
        "workload": WEIGHTS["workload"] * c.load_after / c.capacity,
        "lateness": WEIGHTS["lateness"] * late * PRIORITY_WEIGHT[priority],
    }


def build_cost_matrix(partners, orders, now, traffic):
    elig = eligible(partners)
    orders = ordered(orders)
    queue = {p.id: route_minutes(p, traffic)[0] for p in elig}
    base = [[evaluate(p, o, now, traffic) for p in elig] for o in orders]
    jobs = [c.eta_min - queue[c.partner_id] for row in base for c in row]
    avg_job = float(np.median(jobs)) if jobs else 0.0
    cols = [(p, k) for p in elig for k in range(p.remaining_capacity)]
    cost = np.full((len(orders), len(cols)), INFEASIBLE)
    for i, o in enumerate(orders):
        for j, (p, k) in enumerate(cols):
            c = evaluate(p, o, now, traffic, extra_queue_min=k * avg_job) if k else base[i][elig.index(p)]
            c.load_after += k
            cost[i, j] = sum(cost_components(c, o.priority).values())
    return orders, elig, cols, cost, base


def assign_hungarian(partners, orders, now, traffic):
    orders_s, elig, cols, cost, base = build_cost_matrix(partners, orders, now, traffic)
    plan: dict[str, str] = {}
    total = 0.0
    if cost.size:
        rows, cs = linear_sum_assignment(cost)
        for r, c in zip(rows, cs):
            if cost[r, c] < INFEASIBLE:
                plan[orders_s[r].id] = cols[c][0].id
                total += float(cost[r, c])

    def choose(order, cands, _elig):
        pid = plan.get(order.id)
        return next((i for i, c in enumerate(cands) if c.partner_id == pid), -1), None

    res = run_sequential("hungarian", partners, orders, now, traffic, choose)
    res.extras = {
        "total_cost": round(total, 2),
        "weights": WEIGHTS,
        "slots": len(cols),
        # Display matrix: orders x partners at slot 0 (first free slot).
        "cost_matrix": {
            "orders": [o.id for o in orders_s],
            "partners": [p.id for p in elig],
            "values": [[round(sum(cost_components(c, o.priority).values()), 2) for c in row]
                       for o, row in zip(orders_s, base)],
            "selected": plan,
        },
    }
    return res
