import {
  Activity, BarChart3, BrainCircuit, ClipboardList, FileText, FlaskConical, Gauge, LayoutDashboard, Map, Menu,
  LogOut, Pause, Play, Settings, ShieldAlert, Sparkles, Truck, Workflow,
} from 'lucide-react'
import { useEffect, useState, type ReactNode } from 'react'
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom'
import { api, session } from '../api'
import { clock } from '../format'
import { useSim } from '../hooks'

export const NAV = [
  { group: 'Operate', items: [
    { to: '/app', label: 'Dashboard', icon: LayoutDashboard, end: true },
    { to: '/app/map', label: 'Live Map', icon: Map },
    { to: '/app/orders', label: 'Orders', icon: ClipboardList },
    { to: '/app/partners', label: 'Partners', icon: Truck },
  ] },
  { group: 'Decide', items: [
    { to: '/app/assign', label: 'Assignments', icon: Sparkles },
    { to: '/app/decisions', label: 'AI Decisions', icon: BrainCircuit },
    { to: '/app/algorithms', label: 'Algorithms', icon: FlaskConical },
  ] },
  { group: 'Monitor', items: [
    { to: '/app/risk', label: 'Risk Center', icon: ShieldAlert },
    { to: '/app/simulation', label: 'Simulation', icon: Activity },
    { to: '/app/analytics', label: 'Analytics', icon: BarChart3 },
    { to: '/app/reports', label: 'Reports', icon: FileText },
    { to: '/app/settings', label: 'Settings', icon: Settings },
  ] },
]
const ALL = NAV.flatMap(g => g.items)
const MOBILE = ['/app', '/app/map', '/app/orders', '/app/assign']

function Logo() {
  return (
    <svg width="28" height="28" viewBox="0 0 32 32" aria-hidden="true">
      <rect width="32" height="32" rx="8" fill="#16243f" />
      <path d="M8 23c4-10 12-4 16-14" stroke="#2dd4bf" strokeWidth="3" fill="none" strokeLinecap="round" />
      <circle cx="8" cy="23" r="3" fill="#f59e0b" /><circle cx="24" cy="9" r="3" fill="#2dd4bf" />
    </svg>
  )
}

export function SimControl() {
  const { sim, refresh } = useSim()
  const [busy, setBusy] = useState(false)
  if (!sim) return null
  const running = sim.status === 'running'
  const toggle = async () => {
    setBusy(true)
    try { await api.post(running ? '/simulation/pause' : sim.status === 'paused' ? '/simulation/resume' : '/simulation/start') } finally { setBusy(false); refresh() }
  }
  return (
    <>
      <span className={`status-pill ${sim.status}`} aria-live="polite"><span className="dot" />
        {running ? 'Live' : sim.status === 'paused' ? 'Paused' : 'Ready'} · <span className="mono">{clock(sim.sim_time)}</span>
      </span>
      <button className="btn sm" onClick={toggle} disabled={busy} aria-label={running ? 'Pause simulation' : 'Run simulation'}>
        {running ? <Pause size={14} /> : <Play size={14} />}{running ? 'Pause' : 'Run'}
      </button>
    </>
  )
}

export function PageHeader({ title, crumb, actions }: { title: string; crumb?: string; actions?: ReactNode }) {
  return (
    <header className="topbar">
      <div>
        {crumb && <div className="crumb">{crumb}</div>}
        <h1>{title}</h1>
      </div>
      <div className="topbar-right">
        {actions}
        <SimControl />
        <Link className="btn sm primary" to="/app/demo"><Workflow size={14} />Smart Demo</Link>
      </div>
    </header>
  )
}

export default function Layout() {
  const [drawer, setDrawer] = useState(false)
  const { pathname } = useLocation()
  const { error } = useSim()
  useEffect(() => { setDrawer(false) }, [pathname])
  useEffect(() => {
    const cur = ALL.find(i => (i.end ? pathname === i.to : pathname.startsWith(i.to)))
    document.title = `${cur?.label ?? (pathname.endsWith('demo') ? 'Smart Demo' : 'App')} · SmartRoute AI`
  }, [pathname])
  return (
    <div className="shell">
      <a href="#main" className="skip-link">Skip to content</a>
      <aside className="sidebar" aria-label="Primary">
        <Link to="/" className="brand"><Logo /><span className="brand-text"><strong>SMARTROUTE AI</strong><small>Delivery Intelligence</small></span></Link>
        <nav className="nav">
          {NAV.map(g => (
            <div className="nav-group" key={g.group}>
              <div className="nav-label">{g.group}</div>
              {g.items.map(i => (
                <NavLink key={i.to} to={i.to} end={i.end} title={i.label}><i.icon size={17} /><span>{i.label}</span></NavLink>
              ))}
            </div>
          ))}
        </nav>
        <div className="sidebar-foot">
          <Gauge size={12} /> Research prototype · synthetic data
          <button className="btn sm" style={{ marginTop: 10, width: '100%', background: 'transparent', color: 'inherit', borderColor: '#2b3b5c' }}
            onClick={() => { session.clear(); window.location.assign('/login') }}><LogOut size={13} />Sign out</button>
        </div>
      </aside>
      <div className="main">
        {error && error.status === 0 && (
          <div className="notice" role="alert" style={{ margin: '12px 24px 0', background: 'var(--crit-bg)', color: '#7f1d1d' }}>
            <strong>{error.message}</strong>&nbsp;{error.action}
          </div>
        )}
        <main id="main" style={{ display: 'contents' }}><Outlet /></main>
      </div>
      <nav className="mobile-nav" aria-label="Mobile">
        {MOBILE.map(to => {
          const i = ALL.find(x => x.to === to)!
          return <NavLink key={to} to={to} end={i.end}><i.icon size={19} />{i.label}</NavLink>
        })}
        <button onClick={() => setDrawer(true)} aria-haspopup="dialog" aria-expanded={drawer}><Menu size={19} />More</button>
      </nav>
      {drawer && (
        <div className="drawer" role="dialog" aria-modal="true" aria-label="All pages" onClick={() => setDrawer(false)}
          onKeyDown={e => e.key === 'Escape' && setDrawer(false)}>
          <div className="sheet" onClick={e => e.stopPropagation()}>
            {ALL.map(i => <NavLink key={i.to} to={i.to} end={i.end}><i.icon size={20} />{i.label}</NavLink>)}
            <NavLink to="/app/demo"><Workflow size={20} />Smart Demo</NavLink>
            <NavLink to="/"><Logo />Website</NavLink>
            <a href="/login" onClick={() => session.clear()}><LogOut size={20} />Sign out</a>
          </div>
        </div>
      )}
    </div>
  )
}
