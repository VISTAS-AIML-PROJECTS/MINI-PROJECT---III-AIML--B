"""Minimal NumPy MLP with manual backprop and Adam (PyTorch DLLs are blocked on the dev machine)."""
from __future__ import annotations

import numpy as np


class MLP:
    """Dense layers with tanh hidden activations and a linear output."""

    def __init__(self, sizes: list[int], rng: np.random.Generator, out_scale: float = 0.01):
        self.W, self.b = [], []
        for i, (a, b) in enumerate(zip(sizes[:-1], sizes[1:])):
            scale = out_scale if i == len(sizes) - 2 else np.sqrt(1.0 / a)
            self.W.append(rng.normal(0, scale, (a, b)))
            self.b.append(np.zeros(b))
        self._cache: list[np.ndarray] = []

    def forward(self, x: np.ndarray) -> np.ndarray:
        self._cache = [x]
        for i, (W, b) in enumerate(zip(self.W, self.b)):
            x = x @ W + b
            if i < len(self.W) - 1:
                x = np.tanh(x)
            self._cache.append(x)
        return x

    def backward(self, dout: np.ndarray) -> tuple[list[np.ndarray], list[np.ndarray]]:
        gW, gb = [None] * len(self.W), [None] * len(self.b)
        d = dout
        for i in reversed(range(len(self.W))):
            if i < len(self.W) - 1:
                d = d * (1 - self._cache[i + 1] ** 2)
            gW[i] = self._cache[i].T @ d
            gb[i] = d.sum(axis=0)
            d = d @ self.W[i].T
        return gW, gb

    def input_grad(self, dout: np.ndarray) -> np.ndarray:
        """d(output)/d(input) given upstream grad, using the last forward cache."""
        d = dout
        for i in reversed(range(len(self.W))):
            if i < len(self.W) - 1:
                d = d * (1 - self._cache[i + 1] ** 2)
            d = d @ self.W[i].T
        return d

    def params(self) -> list[np.ndarray]:
        return self.W + self.b

    def state(self, prefix: str) -> dict[str, np.ndarray]:
        return {f"{prefix}{k}": v for k, v in enumerate(self.params())}

    def load(self, prefix: str, data) -> None:
        n = len(self.W)
        for k in range(2 * n):
            arr = data[f"{prefix}{k}"]
            (self.W if k < n else self.b)[k % n][...] = arr


class Adam:
    def __init__(self, params: list[np.ndarray], lr: float = 3e-4, b1=0.9, b2=0.999, eps=1e-8, max_norm=0.5):
        self.p, self.lr, self.b1, self.b2, self.eps, self.max_norm = params, lr, b1, b2, eps, max_norm
        self.m = [np.zeros_like(x) for x in params]
        self.v = [np.zeros_like(x) for x in params]
        self.t = 0

    def step(self, grads: list[np.ndarray]) -> None:
        norm = np.sqrt(sum(float((g ** 2).sum()) for g in grads))
        if norm > self.max_norm:
            grads = [g * self.max_norm / norm for g in grads]
        self.t += 1
        for i, (p, g) in enumerate(zip(self.p, grads)):
            self.m[i] = self.b1 * self.m[i] + (1 - self.b1) * g
            self.v[i] = self.b2 * self.v[i] + (1 - self.b2) * g * g
            mh = self.m[i] / (1 - self.b1 ** self.t)
            vh = self.v[i] / (1 - self.b2 ** self.t)
            p -= self.lr * mh / (np.sqrt(vh) + self.eps)
