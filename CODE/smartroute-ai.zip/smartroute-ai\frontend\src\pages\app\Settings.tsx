import { CheckCircle2, XCircle } from 'lucide-react'
import { Fragment, useState } from 'react'
import { api } from '../../api'
import { PageHeader } from '../../components/Layout'
import { Card, ErrorBanner, Loading } from '../../components/ui'
import { title } from '../../format'
import { useAction, useApi, useSim } from '../../hooks'

type Weights = { traffic: number; delay: number; distance: number; workload: number }

export default function Settings() {
  const { refresh } = useSim()
  const { data } = useApi<Weights>('/settings/risk-weights')
  const { data: health } = useApi<{ status: string; models: Record<string, boolean> }>('/health')
  const [local, setW] = useState<Weights | null>(null)
  const w = local ?? data
  const [saved, setSaved] = useState(false)
  const act = useAction()
  const total = w ? w.traffic + w.delay + w.distance + w.workload : 0
  const save = () => act.run('Saving…', async () => { setW(await api.put<Weights>('/settings/risk-weights', w)); setSaved(true); refresh() })

  return (
    <>
      <PageHeader title="Settings" crumb="Monitor" />
      <div className="content">
        {act.error && <ErrorBanner error={act.error} onClose={act.clearError} />}
        <div className="grid g2">
          <Card title="Risk score weights">
            {!w ? <Loading /> : (
              <form className="stack" onSubmit={e => { e.preventDefault(); save() }}>
                <p className="muted" style={{ fontSize: 13 }}>Risk = (w<sub>t</sub>·traffic + w<sub>d</sub>·delay probability + w<sub>s</sub>·distance + w<sub>w</sub>·workload) / Σw. These weights are configurable design choices, not empirically calibrated values.</p>
                {(Object.keys(w) as (keyof Weights)[]).map(k => (
                  <label key={k} className="field">{title(k)} weight: {w[k].toFixed(2)} ({total ? ((w[k] / total) * 100).toFixed(0) : 0}% of score)
                    <input type="range" min={0} max={1} step={0.05} value={w[k]} onChange={e => { setSaved(false); setW({ ...w, [k]: Number(e.target.value) }) }} />
                  </label>
                ))}
                {total === 0 && <div className="notice" role="alert">At least one weight must be greater than zero.</div>}
                <div className="row">
                  <button className="btn primary" type="submit" disabled={!!act.busy || total === 0}>Save weights</button>
                  <button className="btn" type="button" onClick={() => { setSaved(false); setW({ traffic: 0.25, delay: 0.4, distance: 0.15, workload: 0.2 }) }}>Restore defaults</button>
                  {saved && <span className="muted" role="status">Saved — live risk recalculated.</span>}
                </div>
                <p className="faint" style={{ fontSize: 12 }}>Weights apply to this server process (reset on restart). The trained PPO policies were trained with the default weights.</p>
              </form>
            )}
          </Card>
          <Card title="System status">
            {!health ? <Loading /> : (
              <dl className="kv">
                <dt>API</dt><dd>{health.status === 'ok' ? 'Healthy' : health.status}</dd>
                {Object.entries(health.models).map(([m, ok]) => (
                  <Fragment key={m}><dt>{m === 'ppo' ? 'PPO weights' : 'Risk-aware PPO weights'}</dt>
                    <dd style={{ color: ok ? 'var(--low)' : 'var(--crit)' }}>{ok ? <CheckCircle2 size={14} /> : <XCircle size={14} />} {ok ? 'Loaded' : 'Not trained'}</dd></Fragment>
                ))}
                <dt>Data source</dt><dd>Synthetic simulator</dd>
                <dt>Database</dt><dd>SQLite (SQLAlchemy)</dd>
                <dt>Map tiles</dt><dd>© OpenStreetMap contributors</dd>
              </dl>
            )}
          </Card>
        </div>
      </div>
    </>
  )
}
