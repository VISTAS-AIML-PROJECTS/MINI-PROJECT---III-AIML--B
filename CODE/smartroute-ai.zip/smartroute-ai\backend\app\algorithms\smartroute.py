"""SmartRoute AI: risk-aware global matching guided by the risk-aware PPO policy.

1. For every (order, partner, capacity-slot) the Hungarian cost is extended with risk terms:
   CVaR_0.1 tail lateness and priority-weighted delay probability (from the Gaussian travel-time model).
2. A learned prior from the risk-aware PPO policy is subtracted: beta * log pi(partner | order, state).
   pi is evaluated once per order on the current fleet state (not re-evaluated as routes grow).
3. The combined matrix is solved exactly with the Hungarian algorithm, then replayed through the shared
   evaluator. With beta = 0 this reduces to "risk-aware Hungarian" (reported separately in evaluation).
"""
from __future__ import annotations

import numpy as np
from .lsa import linear_sum_assignment

from ..core.candidate import eligible, evaluate
from ..core.domain import PRIORITY_WEIGHT
from ..core.geo import route_minutes
from ..rl.env import features
from ..rl.ppo import Policy
from .base import ordered, run_sequential
from .hungarian import INFEASIBLE, cost_components

RISK_WEIGHTS = {"cvar_tail": 1.0, "delay_prob": 20.0}
POLICY_BETA = 2.0  # chosen on held-out seed 12345 among {0, 2, 5, 10}


RISK_SENSITIVITY = {"low": 0.5, "medium": 1.0, "high": 2.0}  # multiplies every risk term


def smart_components(c, priority: str, logp: float | None, beta: float, risk_scale: float = 1.0) -> dict:
    comps = cost_components(c, priority)
    comps["risk"] *= risk_scale
    comps["cvar_tail"] = risk_scale * RISK_WEIGHTS["cvar_tail"] * c.cvar_late_min
    comps["delay_prob"] = risk_scale * RISK_WEIGHTS["delay_prob"] * c.delay_prob * PRIORITY_WEIGHT[priority]
    if logp is not None and beta:
        comps["policy_prior"] = -beta * logp
    return comps


def assign_smartroute(partners, orders, now, traffic, policy: Policy | None, beta: float = POLICY_BETA,
                      name: str = "smartroute", risk_scale: float = 1.0):
    elig = eligible(partners)
    orders_s = ordered(orders)
    queue = {p.id: route_minutes(p, traffic)[0] for p in elig}
    base = [[evaluate(p, o, now, traffic) for p in elig] for o in orders_s]
    logps, xs = [], {}
    for n, (o, row) in enumerate(zip(orders_s, base)):
        if policy is not None and row:
            xs[o.id] = features(o, row, elig, orders_s[n + 1:])
            pr = policy.probs(xs[o.id])
            logps.append(np.log(pr + 1e-9))
        else:
            logps.append(np.zeros(len(row)))
    jobs = [c.eta_min - queue[c.partner_id] for row in base for c in row]
    avg_job = float(np.median(jobs)) if jobs else 0.0
    cols = [(j, p, k) for j, p in enumerate(elig) for k in range(p.remaining_capacity)]
    cost = np.full((len(orders_s), len(cols)), INFEASIBLE)
    for i, o in enumerate(orders_s):
        for col, (j, p, k) in enumerate(cols):
            c = evaluate(p, o, now, traffic, extra_queue_min=k * avg_job) if k else base[i][j]
            c.load_after += k
            cost[i, col] = sum(smart_components(c, o.priority, float(logps[i][j]), beta if policy else 0, risk_scale).values())
    plan: dict[str, str] = {}
    total = 0.0
    if cost.size:
        for r, c in zip(*linear_sum_assignment(cost)):
            if cost[r, c] < INFEASIBLE:
                plan[orders_s[r].id] = cols[c][1].id
                total += float(cost[r, c])
    elig_ids = [p.id for p in elig]
    prior = {o.id: dict(zip([p.id for p in elig], np.exp(lp).round(4).tolist())) for o, lp in zip(orders_s, logps)}

    def choose(order, cands, _elig):
        pid = plan.get(order.id)
        idx = next((i for i, c in enumerate(cands) if c.partner_id == pid), -1)
        conf = prior.get(order.id, {}).get(pid) if policy is not None else None
        choose.last_probs = [prior.get(order.id, {}).get(c.partner_id, 0.0) for c in cands] if policy else None
        # Policy inputs were computed on the pre-matching fleet; map rows to the current candidates.
        x = xs.get(order.id)
        choose.last_x = x[[elig_ids.index(c.partner_id) for c in cands]] if x is not None else None
        return idx, conf

    res = run_sequential(name, partners, orders, now, traffic, choose)
    res.extras = {"policy_x_basis": "pre-matching fleet state", "total_cost": round(total, 2), "risk_weights": RISK_WEIGHTS, "policy_beta": beta if policy else 0.0, "risk_scale": risk_scale}
    return res
