import { defineConfig } from '@playwright/test'

export const E2E_PASSWORD = process.env.SMARTROUTE_DEMO_PASSWORD ?? 'e2e-local-pass'

// Uses the locally installed Google Chrome (no browser download needed).
export default defineConfig({
  testDir: './e2e',
  timeout: 90_000,
  workers: 1,
  reporter: [['list']],
  use: { baseURL: 'http://127.0.0.1:5173', channel: 'chrome', headless: true, screenshot: 'only-on-failure' },
  webServer: [
    { command: 'python -m uvicorn app.main:app --host 127.0.0.1 --port 8000', cwd: '../backend', env: { SMARTROUTE_DEMO_PASSWORD: E2E_PASSWORD }, url: 'http://127.0.0.1:8000/api/health', reuseExistingServer: true, timeout: 60_000 },
    { command: 'npx vite --host 127.0.0.1 --port 5173 --strictPort', url: 'http://127.0.0.1:5173', reuseExistingServer: true, timeout: 60_000 },
  ],
})
