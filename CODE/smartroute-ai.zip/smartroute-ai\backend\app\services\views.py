"""Read models: DB rows -> API dictionaries (with derived display statuses)."""
from __future__ import annotations

from sqlalchemy import select

from .. import db
from ..core.risk import level

AT_RISK_P = 0.5


def order_status(r: db.OrderRow, now: float) -> str:
    if r.status == "delivered":
        return "delayed" if r.delivered_at > r.deadline else "delivered"
    if now > r.deadline:
        return "delayed"
    if r.status in ("assigned", "in_transit") and r.delay_prob >= AT_RISK_P:
        return "at_risk"
    return r.status


def order_dict(r: db.OrderRow, now: float) -> dict:
    return {
        "id": r.id, "priority": r.priority, "status": order_status(r, now), "base_status": r.status,
        "pickup": {"name": r.pickup_name, "lat": r.pickup_lat, "lng": r.pickup_lng},
        "drop": {"name": r.drop_name, "lat": r.drop_lat, "lng": r.drop_lng},
        "created_at": r.created_at, "deadline": r.deadline, "minutes_to_deadline": round(r.deadline - now, 1),
        "partner_id": r.partner_id, "assigned_by": r.assigned_by, "assigned_at": r.assigned_at,
        "eta": r.eta, "eta_min": round(r.eta - now, 1) if r.eta is not None and r.status != "delivered" else None,
        "planned_eta": r.planned_eta, "planned_km": r.planned_km, "planned_risk": r.planned_risk,
        "delivered_at": r.delivered_at, "actual_km": round(r.actual_km, 3),
        "risk": round(r.risk, 4), "risk_level": level(r.risk), "risk_parts": r.risk_parts or {},
        "delay_prob": round(r.delay_prob, 4),
    }


def partner_dict(r: db.PartnerRow, orders_at_risk: set[str]) -> dict:
    load = sum(1 for s in r.route if s["kind"] == "dropoff")
    on_route = sorted({s["order_id"] for s in r.route})
    if not r.online:
        status = "offline"
    elif load >= r.capacity:
        status = "at_capacity"
    elif orders_at_risk & set(on_route):
        status = "at_risk"
    elif load:
        status = "busy"
    else:
        status = "available"
    return {
        "id": r.id, "name": r.name, "status": status, "online": r.online, "lat": r.lat, "lng": r.lng,
        "capacity": r.capacity, "load": load, "utilization": round(load / r.capacity, 4),
        "speed_kmh": round(r.speed_kmh, 1), "completed": r.completed, "on_time": r.on_time,
        "on_time_rate": round(r.on_time / r.completed, 4) if r.completed else None,
        "distance_km": round(r.distance_km, 2), "active_orders": on_route, "route": r.route, "trail": r.trail,
    }


def load_state(s, run_id: int, now: float) -> tuple[list[dict], list[dict]]:
    orows = s.scalars(select(db.OrderRow).where(db.OrderRow.run_id == run_id).order_by(db.OrderRow.id)).all()
    orders = [order_dict(r, now) for r in orows]
    at_risk = {o["id"] for o in orders if o["status"] in ("at_risk", "delayed") and o["base_status"] != "delivered"}
    prows = s.scalars(select(db.PartnerRow).where(db.PartnerRow.run_id == run_id).order_by(db.PartnerRow.id)).all()
    partners = [partner_dict(r, at_risk) for r in prows]
    # attach live risk for partners: max risk among their active orders
    by_id = {o["id"]: o for o in orders}
    for p in partners:
        risks = [by_id[o]["risk"] for o in p["active_orders"] if o in by_id]
        p["risk"] = round(max(risks), 4) if risks else 0.0
        p["risk_level"] = level(p["risk"])
        etas = [by_id[o]["eta_min"] for o in p["active_orders"] if o in by_id and by_id[o]["eta_min"] is not None]
        p["avg_eta_min"] = round(sum(etas) / len(etas), 1) if etas else None
    return orders, partners


def assignment_dict(r: db.AssignmentRow) -> dict:
    return {
        "id": r.id, "batch_id": r.batch_id, "order_id": r.order_id, "partner_id": r.partner_id,
        "algorithm": r.algorithm, "sim_time": r.sim_time, "confidence": r.confidence,
        "eta_min": round(r.eta_min, 2), "km": round(r.km, 3), "risk": round(r.risk, 4), "risk_level": r.risk_level,
        "delay_prob": round(r.delay_prob, 4), "feasible": r.feasible, "load_after": r.load_after, "capacity": r.capacity,
    }
