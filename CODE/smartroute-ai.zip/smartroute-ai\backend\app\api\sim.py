"""Simulation control endpoints."""
from dataclasses import asdict

from fastapi import APIRouter, Depends

from .. import auth
from ..schemas import SimConfigIn, StepRequest
from ..services.simulation import SimConfig, simulation

router = APIRouter(prefix="/api/simulation", dependencies=[Depends(auth.require_user)])


def status():
    w = simulation.ensure()
    return {"status": simulation.status, "run_id": w.run_id, "sim_time": round(w.now, 2), "config": asdict(simulation.cfg),
            "traffic_level": w.traffic.level, "kpis": simulation.kpis()}


@router.get("/status")
def get_status():
    return status()


@router.post("/start")
def start(body: SimConfigIn | None = None):
    if body:
        simulation.configure(**body.model_dump())
    simulation.set_status("running")
    return status()


@router.post("/pause")
def pause():
    simulation.set_status("paused")
    return status()


@router.post("/resume")
def resume():
    simulation.set_status("running")
    return status()


@router.post("/step")
def step(body: StepRequest | None = None):
    simulation.step((body or StepRequest()).minutes)
    return status()


@router.post("/reset")
def reset(body: SimConfigIn | None = None):
    cfg = SimConfig(**{**asdict(simulation.cfg), **{k: v for k, v in (body.model_dump() if body else {}).items() if v is not None}})
    simulation.reset(cfg)
    return status()


@router.put("/config")
def config(body: SimConfigIn):
    simulation.configure(**body.model_dump())
    return status()
