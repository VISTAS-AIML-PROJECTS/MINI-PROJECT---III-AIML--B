"""Dispatch MDP.

Episode: a batch of pending orders processed earliest-deadline-first.
State:   for the current order, one feature row per eligible partner (location-derived ETA,
         distance, traffic, delay probability, CVaR tail, workload, capacity, deadline slack,
         priority, composite risk) - the partner set is variable, the policy scores each row.
Action:  index of the eligible partner to receive the order (ineligible partners are masked out).
Reward:  see reward.py (base or risk-aware).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from ..core.candidate import Candidate, apply, eligible, evaluate
from ..core.domain import PRIORITY_WEIGHT, Order, Partner
from ..core.geo import haversine_km
from ..core.traffic import TrafficField
from .reward import UNASSIGNABLE_PENALTY, reward, reward_components

FEATURES = [
    "eta", "eta_vs_best", "distance", "distance_vs_best", "traffic", "delay_prob", "cvar_tail",
    "load_after", "free_capacity", "slack", "priority", "feasible", "risk", "risk_vs_best", "n_eligible",
    "demand_pressure", "future_demand_near",
]
N_FEATURES = len(FEATURES)


def context(cands: list[Candidate], partners: list[Partner], upcoming: list[Order]) -> tuple[float, np.ndarray]:
    """Look-ahead context: demand pressure on the fleet and how much upcoming demand sits near each
    partner (pickups within ~2 km of where the partner's route ends)."""
    free = sum(p.remaining_capacity for p in partners)
    pressure = len(upcoming) / free if free else 2.0
    near = np.zeros(len(partners))
    if upcoming:
        for i, p in enumerate(partners):
            lat, lng = p.end_position()
            near[i] = np.mean([np.exp(-haversine_km(lat, lng, o.pickup_lat, o.pickup_lng) / 2.0) for o in upcoming])
    return min(pressure, 2.0), near


def features(order: Order, cands: list[Candidate], partners: list[Partner] | None = None,
             upcoming: list[Order] | None = None) -> np.ndarray:
    pressure, near = context(cands, partners or [], upcoming or []) if partners else (0.0, np.zeros(len(cands)))
    eta = np.array([c.eta_min for c in cands])
    km = np.array([c.km for c in cands])
    risk = np.array([c.risk.score for c in cands])
    rows = []
    for c, e, k, r, nr in zip(cands, eta, km, risk, near):
        rows.append([
            e / 60.0, (e - eta.min()) / 30.0, k / 10.0, (k - km.min()) / 10.0, c.congestion,
            c.delay_prob, min(c.cvar_late_min / 30.0, 2.0), c.load_after / c.capacity,
            (c.capacity - c.load_after) / 5.0, np.clip(c.slack_min / 60.0, -2, 3),
            PRIORITY_WEIGHT[order.priority] / 2.0, float(c.feasible), r, r - risk.min(), len(cands) / 20.0,
            pressure, nr,
        ])
    return np.asarray(rows, dtype=np.float64)


@dataclass
class Observation:
    order: Order
    partners: list[Partner]
    candidates: list[Candidate]
    x: np.ndarray


class DispatchEnv:
    def __init__(self, partners: list[Partner], orders: list[Order], now: float,
                 traffic: TrafficField | None, risk_aware: bool):
        self.fleet = [p.clone() for p in partners]
        self.orders = sorted(orders, key=lambda o: (o.deadline, o.id))
        self.now, self.traffic, self.risk_aware = now, traffic, risk_aware
        self.i = 0
        self.skipped_penalty = 0.0

    def _advance(self) -> Observation | None:
        while self.i < len(self.orders):
            o = self.orders[self.i]
            elig = eligible(self.fleet)
            if elig:
                cands = [evaluate(p, o, self.now, self.traffic) for p in elig]
                return Observation(o, elig, cands, features(o, cands, elig, self.orders[self.i + 1:]))
            self.skipped_penalty += UNASSIGNABLE_PENALTY
            self.i += 1
        return None

    def reset(self) -> Observation | None:
        return self._advance()

    def step(self, obs: Observation, action: int) -> tuple[Observation | None, float, dict]:
        c = obs.candidates[action]
        r = reward(c, obs.order.priority, self.risk_aware)
        info = {"components": reward_components(c, obs.order.priority, self.risk_aware), "candidate": c}
        apply(obs.partners[action], obs.order)
        self.i += 1
        nxt = self._advance()
        # Orders left without any eligible partner are charged to the action that preceded them.
        r += self.skipped_penalty
        self.skipped_penalty = 0.0
        return nxt, r, info
