import { ArrowRight, Search } from 'lucide-react'
import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import type { Order, Partner, RiskEvent, TrafficCell } from '../api'
import { clock, km, mins, pct, title } from '../format'
import { useApi } from '../hooks'
import OpsMap, { type Selection } from './OpsMap'
import { Bar, Empty, ErrorState, Loading, PriorityBadge, RiskBadge, StatusBadge } from './ui'

interface OpsData { orders: Order[]; partners: Partner[]; cells: TrafficCell[]; events: RiskEvent[] }

export function useOpsData() {
  const o = useApi<{ orders: Order[] }>('/orders')
  const p = useApi<{ partners: Partner[] }>('/partners')
  const t = useApi<{ cells: TrafficCell[] }>('/traffic')
  const r = useApi<{ events: RiskEvent[] }>('/risk')
  const error = o.error ?? p.error ?? t.error
  const data: OpsData | null = o.data && p.data && t.data
    ? { orders: o.data.orders, partners: p.data.partners, cells: t.data.cells, events: r.data?.events ?? [] } : null
  return { data, error, loading: !data && !error }
}

export function OrderDetail({ o, now }: { o: Order; now: number }) {
  return (
    <div className="stack">
      <div className="row"><strong className="mono" style={{ fontSize: 16 }}>{o.id}</strong><StatusBadge status={o.status} /><PriorityBadge p={o.priority} /></div>
      <dl className="kv">
        <dt>Pickup</dt><dd>{o.pickup.name}</dd>
        <dt>Destination</dt><dd>{o.drop.name}</dd>
        <dt>Deadline</dt><dd>{clock(o.deadline)} <span className="muted">({o.minutes_to_deadline >= 0 ? `${mins(o.minutes_to_deadline)} left` : `${mins(-o.minutes_to_deadline)} overdue`})</span></dd>
        <dt>Distance (planned)</dt><dd>{km(o.planned_km)}</dd>
        <dt>ETA</dt><dd>{o.eta != null ? `${clock(o.eta)} (${mins(o.eta - now)})` : o.delivered_at != null ? `Delivered ${clock(o.delivered_at)}` : 'Not assigned'}</dd>
        <dt>Risk</dt><dd><RiskBadge level={o.risk_level} score={o.risk} /></dd>
        <dt>Delay probability</dt><dd>{pct(o.delay_prob)}</dd>
        <dt>Assigned partner</dt><dd className="mono">{o.partner_id ?? '—'}</dd>
        <dt>Assigned by</dt><dd>{o.assigned_by ? title(o.assigned_by) : '—'}</dd>
      </dl>
      {Object.keys(o.risk_parts).length > 0 && (
        <div className="stack" style={{ gap: 6 }}>
          <strong style={{ fontSize: 12.5 }}>Risk components</strong>
          {['traffic', 'delay', 'distance', 'workload'].map(k => (
            <div className="meter-row" key={k}><span>{title(k)}</span><Bar value={o.risk_parts[k] ?? 0} /><span className="mono">{(o.risk_parts[k] ?? 0).toFixed(2)}</span></div>
          ))}
        </div>
      )}
      {o.base_status === 'pending' && <Link className="btn primary" to={`/app/assign?order=${o.id}`}>Run SmartRoute AI for {o.id}<ArrowRight size={14} /></Link>}
      {o.assigned_by && <Link className="btn" to={`/app/decisions?order=${o.id}`}>Why this partner?<ArrowRight size={14} /></Link>}
    </div>
  )
}

export function PartnerDetail({ p, orders }: { p: Partner; orders: Order[] }) {
  const mine = orders.filter(o => p.active_orders.includes(o.id))
  return (
    <div className="stack">
      <div className="row"><strong className="mono" style={{ fontSize: 16 }}>{p.id}</strong><StatusBadge status={p.status} /></div>
      <dl className="kv">
        <dt>Current location</dt><dd className="mono">{p.lat.toFixed(4)}, {p.lng.toFixed(4)}</dd>
        <dt>Workload</dt><dd>{p.load}/{p.capacity}</dd>
        <dt>Utilization</dt><dd>{pct(p.utilization)}</dd>
        <dt>Avg ETA (active)</dt><dd>{mins(p.avg_eta_min)}</dd>
        <dt>On-time rate</dt><dd>{p.on_time_rate == null ? 'No deliveries yet' : `${pct(p.on_time_rate)} of ${p.completed}`}</dd>
        <dt>Risk</dt><dd><RiskBadge level={p.risk_level} score={p.risk} /></dd>
        <dt>Distance driven</dt><dd>{km(p.distance_km)}</dd>
      </dl>
      <strong style={{ fontSize: 12.5 }}>Current route ({p.route.length} stops)</strong>
      {p.route.length === 0 ? <span className="muted">No stops — idle.</span> : (
        <ol style={{ margin: 0, paddingLeft: 18, fontSize: 13 }}>
          {p.route.map((s, i) => {
            const o = mine.find(x => x.id === s.order_id)
            return <li key={i}>{s.kind === 'pickup' ? 'Pick up' : 'Deliver'} <span className="mono">{s.order_id}</span>
              {s.kind === 'dropoff' && o?.eta != null && <span className="muted"> · ETA {clock(o.eta)}</span>}</li>
          })}
        </ol>
      )}
    </div>
  )
}

export default function OpsView({ now, height = 560, filters = false }: { now: number; height?: number; filters?: boolean }) {
  const { data, error, loading } = useOpsData()
  const [sel, setSel] = useState<Selection>(null)
  const [tab, setTab] = useState<'orders' | 'partners' | 'alerts'>('orders')
  const [q, setQ] = useState('')
  const [status, setStatus] = useState('active')
  const [showDelivered, setShowDelivered] = useState(false)

  const orders = useMemo(() => {
    if (!data) return []
    const rank: Record<string, number> = { delayed: 0, at_risk: 1, pending: 2, assigned: 3, in_transit: 4, delivered: 5 }
    return data.orders
      .filter(o => status === 'all' || (status === 'active' ? o.base_status !== 'delivered' : o.status === status))
      .filter(o => !q || o.id.toLowerCase().includes(q.toLowerCase()) || (o.partner_id ?? '').toLowerCase().includes(q.toLowerCase()))
      .sort((a, b) => rank[a.status] - rank[b.status] || b.risk - a.risk)
  }, [data, q, status])
  if (error) return <ErrorState error={error} />
  if (loading || !data) return <Loading label="Loading operations…" />
  const selOrder = sel?.type === 'order' ? data.orders.find(o => o.id === sel.id) : undefined
  const selPartner = sel?.type === 'partner' ? data.partners.find(p => p.id === sel.id) : undefined

  return (
    <div className="ops">
      <div className="card left-pane" style={{ display: 'flex', flexDirection: 'column', minHeight: 0 }}>
        <div className="tabs" role="tablist" aria-label="Operations lists">
          {(['orders', 'partners', 'alerts'] as const).map(t => (
            <button key={t} role="tab" aria-selected={tab === t} onClick={() => setTab(t)}>
              {title(t)} <span className="faint">{t === 'orders' ? orders.length : t === 'partners' ? data.partners.length : data.events.length}</span>
            </button>
          ))}
        </div>
        {tab === 'orders' && (
          <div className="row" style={{ padding: 10, borderBottom: '1px solid var(--line)' }}>
            <label className="row" style={{ flex: 1, minWidth: 120 }}><Search size={14} className="faint" /><span className="sr-only">Search orders</span>
              <input className="input" style={{ flex: 1 }} placeholder="Search order or partner" value={q} onChange={e => setQ(e.target.value)} /></label>
            {filters && (
              <label><span className="sr-only">Status filter</span>
                <select className="select" value={status} onChange={e => setStatus(e.target.value)}>
                  {['active', 'all', 'pending', 'assigned', 'in_transit', 'at_risk', 'delayed', 'delivered'].map(s => <option key={s} value={s}>{title(s)}</option>)}
                </select></label>
            )}
          </div>
        )}
        <div className="list" style={{ maxHeight: height - 90 }}>
          {tab === 'orders' && (orders.length === 0 ? <Empty title="No active deliveries" hint="Start a simulation or generate orders." /> :
            orders.map(o => (
              <button key={o.id} className="list-item" aria-current={sel?.id === o.id} onClick={() => setSel({ type: 'order', id: o.id })}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div className="row"><strong className="mono">{o.id}</strong><PriorityBadge p={o.priority} /></div>
                  <div className="faint" style={{ fontSize: 12 }}>{o.pickup.name} · due {clock(o.deadline)}{o.partner_id && ` · ${o.partner_id}`}</div>
                </div>
                <div className="stack" style={{ alignItems: 'flex-end', gap: 4 }}><StatusBadge status={o.status} /><RiskBadge level={o.risk_level} /></div>
              </button>
            )))}
          {tab === 'partners' && data.partners.map(p => (
            <button key={p.id} className="list-item" aria-current={sel?.id === p.id} onClick={() => setSel({ type: 'partner', id: p.id })}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="row"><strong className="mono">{p.id}</strong><StatusBadge status={p.status} /></div>
                <div style={{ marginTop: 6 }}><Bar value={p.utilization} color={p.utilization >= 1 ? 'var(--amber)' : undefined} /></div>
              </div>
              <span className="mono" style={{ fontSize: 12 }}>{p.load}/{p.capacity}</span>
            </button>
          ))}
          {tab === 'alerts' && (data.events.length === 0 ? <Empty title="No risk alerts" hint="Alerts appear when an order, partner or zone crosses a risk threshold." /> :
            data.events.map(e => (
              <button key={e.id} className="list-item" onClick={() => e.entity_type !== 'zone' && setSel({ type: e.entity_type as 'order' | 'partner', id: e.entity_id })}>
                <div style={{ flex: 1 }}>
                  <div className="row"><RiskBadge level={e.level} /><span className="faint mono" style={{ fontSize: 11 }}>{clock(e.sim_time)}</span></div>
                  <div style={{ fontSize: 12.5, marginTop: 4 }}>{e.message}</div>
                </div>
              </button>
            )))}
        </div>
      </div>
      <div style={{ minWidth: 0, display: 'flex', flexDirection: 'column', gap: 8 }}>
        {filters && (
          <label className="row" style={{ fontSize: 12.5 }}><input type="checkbox" checked={showDelivered} onChange={e => setShowDelivered(e.target.checked)} />Show delivered orders</label>
        )}
        <OpsMap orders={data.orders} partners={data.partners} cells={data.cells} selected={sel} onSelect={setSel} height={height} showDelivered={showDelivered} />
      </div>
      <div className="card right-pane">
        <div className="card-h"><h2>{selOrder ? 'Order details' : selPartner ? 'Partner details' : 'Details'}</h2>
          {sel && <div className="right"><button className="btn sm ghost" onClick={() => setSel(null)} aria-label="Clear selection">✕</button></div>}</div>
        <div className="card-b">
          {selOrder ? <OrderDetail o={selOrder} now={now} /> : selPartner ? <PartnerDetail p={selPartner} orders={data.orders} /> :
            <Empty title="Select an order or partner" hint="Click a marker on the map or an item in the list to see its ETA, risk, workload and route." />}
        </div>
      </div>
    </div>
  )
}
