"""Assignment, comparison, training and evaluation endpoints."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select

from .. import auth, db
from ..algorithms import registry
from ..algorithms.smartroute import RISK_SENSITIVITY
from ..explain import explain
from ..schemas import AssignRequest, CompareRequest, EvaluateRequest, TrainRequest
from ..services import training
from ..services.simulation import simulation

router = APIRouter(prefix="/api", dependencies=[Depends(auth.require_user)])


def _no_orders():
    raise HTTPException(422, detail={"message": "Unable to calculate assignment.",
                                     "reason": "There are no pending orders to assign.",
                                     "action": "Generate orders or start the simulation."})


def _run(name: str, req: AssignRequest | CompareRequest):
    try:
        res, orders, traffic = simulation.run_algorithm(name, req.order_ids, req.traffic_level,
                                                       RISK_SENSITIVITY[req.risk_sensitivity])
    except registry.ModelNotTrained as e:
        raise HTTPException(409, detail={"message": "Unable to calculate assignment.", "reason": str(e),
                                         "action": "Train the model from the Algorithm Center."})
    if not orders:
        _no_orders()
    if not res.decisions:
        raise HTTPException(422, detail={"message": "Unable to calculate assignment.",
                                         "reason": "No delivery partners are currently available.",
                                         "action": "Bring a partner online or reset the simulation."})
    return res, orders


def _payload(res, orders):
    by_id = {o.id: o for o in orders}
    pol = registry.policy(res.algorithm) if res.algorithm in ("ppo", "smartroute") else None
    return {
        "algorithm": res.algorithm, "label": registry.ALGORITHMS.get(res.algorithm, res.algorithm),
        "metrics": res.metrics, "runtime_ms": round(res.runtime_ms, 1), "unassigned": res.unassigned,
        "decisions": [explain(d, by_id[d.order_id], res.algorithm, pol, res.extras.get("risk_scale", 1.0))
                      for d in res.decisions],
        "extras": res.extras, "data_notice": "Simulation Result on Synthetic Simulation Data",
    }


@router.post("/assign/{algorithm}")
def assign(algorithm: str, req: AssignRequest):
    if algorithm not in registry.ALGORITHMS:
        raise HTTPException(404, detail={"message": "Unknown algorithm.", "reason": f"Choose one of {list(registry.ALGORITHMS)}."})
    if req.apply and req.traffic_level is not None:
        raise HTTPException(422, detail={"message": "Cannot apply a what-if result.",
                                         "reason": "Assignments computed under a hypothetical traffic level cannot be committed.",
                                         "action": "Remove traffic_level or set apply=false."})
    res, orders = _run(algorithm, req)
    out = _payload(res, orders)
    if req.apply:
        out["committed"] = simulation.commit(res, orders)
    return out


@router.post("/compare")
def compare(req: CompareRequest):
    results, skipped = [], []
    for name in req.algorithms:
        try:
            res, orders = _run(name, req)
        except HTTPException as e:
            if e.status_code == 409:
                skipped.append({"algorithm": name, "reason": e.detail["reason"]})
                continue
            raise
        results.append({"algorithm": name, "label": registry.ALGORITHMS[name], "metrics": res.metrics,
                        "runtime_ms": round(res.runtime_ms, 1),
                        "assignments": {d.order_id: d.partner_id for d in res.decisions}})
    return {"results": results, "skipped": skipped, "data_notice": "Simulation Result on Synthetic Simulation Data"}


@router.post("/train", status_code=202)
def train(req: TrainRequest):
    try:
        return {"run_id": training.start_training(req.algorithm, req.iterations)}
    except training.Busy as e:
        raise HTTPException(409, detail={"message": "Training not started.", "reason": str(e)})


@router.post("/evaluate", status_code=202)
def evaluate(req: EvaluateRequest):
    try:
        return {"run_id": training.start_evaluation(req.scenarios, req.seed)}
    except training.Busy as e:
        raise HTTPException(409, detail={"message": "Evaluation not started.", "reason": str(e)})


@router.get("/jobs/status")
def job_status():
    return {k: v for k, v in training.state.items()}


@router.get("/training-runs")
def training_runs():
    with db.SessionLocal() as s:
        rows = s.scalars(select(db.TrainingRun).order_by(db.TrainingRun.id.desc()).limit(30)).all()
    return {
        "runs": [{"id": r.id, "kind": r.kind, "algorithm": r.algorithm, "status": r.status, "seconds": r.seconds,
                  "started_at": r.started_at.isoformat(), "config": r.config, "result": r.result} for r in rows],
        "shipped": training.shipped_training_logs(),
    }
