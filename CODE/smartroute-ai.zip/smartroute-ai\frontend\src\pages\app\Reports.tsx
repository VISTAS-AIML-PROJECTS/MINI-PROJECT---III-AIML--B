import { Download, FileText, Printer } from 'lucide-react'
import { useState } from 'react'
import { ALGO_LABEL, api, type Assignment, type Evaluation, type Insight, type Kpis } from '../../api'
import { PageHeader } from '../../components/Layout'
import { Card, Empty, ErrorBanner, Loading, SyntheticNotice } from '../../components/ui'
import { mins, num, pct } from '../../format'
import { useAction } from '../../hooks'

interface Report {
  generated_at: string; data_notice: string
  run: { id: number; started_at: string; seed: number; simulated_minutes: number; algorithm: string; traffic_level: number; order_rate_per_hour: number }
  counts: { orders: number; partners: number; assignments: number; delivered: number }
  kpis: Kpis; workload: { id: string; load: number; capacity: number; completed: number; on_time_rate: number | null; distance_km: number }[]
  planned_vs_actual: { n: number; mean_eta_deviation_min: number | null; mean_km_deviation: number | null }
  delay_causes: Record<string, number>; algorithms_live: Record<string, { assignments: number; avg_eta_min: number; avg_risk: number; feasible_rate: number }>
  evaluation: Evaluation | null; recent_assignments: Assignment[]; recommendations: Insight[]
}

function download(name: string, text: string, type: string) {
  const url = URL.createObjectURL(new Blob([text], { type }))
  const a = Object.assign(document.createElement('a'), { href: url, download: name })
  a.click()
  URL.revokeObjectURL(url)
}

export default function Reports() {
  const [rep, setRep] = useState<Report | null>(null)
  const act = useAction()
  const generate = () => act.run('Generating report…', async () => setRep(await api.get<Report>('/reports/summary')))
  const csv = (r: Report) => ['partner_id,load,capacity,completed,on_time_rate,distance_km',
    ...r.workload.map(w => [w.id, w.load, w.capacity, w.completed, w.on_time_rate ?? '', w.distance_km].join(','))].join('\n')
  const evAlgos = rep?.evaluation ? ['nearest', 'hungarian', 'ppo', 'smartroute'].filter(a => a in rep.evaluation!.results) : []

  return (
    <>
      <PageHeader title="Reports" crumb="Monitor" actions={rep && (
        <div className="row">
          <button className="btn sm" onClick={() => window.print()}><Printer size={14} />Print / PDF</button>
          <button className="btn sm" onClick={() => download(`smartroute-report-run${rep.run.id}.json`, JSON.stringify(rep, null, 2), 'application/json')}><Download size={14} />JSON</button>
          <button className="btn sm" onClick={() => download(`smartroute-workload-run${rep.run.id}.csv`, csv(rep), 'text/csv')}><Download size={14} />Workload CSV</button>
        </div>)} />
      <div className="content">
        {act.error && <ErrorBanner error={act.error} onClose={act.clearError} />}
        <Card title="Operations report" right={<button className="btn primary" onClick={generate} disabled={!!act.busy}><FileText size={14} />{rep ? 'Regenerate' : 'Generate report'}</button>}>
          {act.busy ? <Loading label={act.busy} /> : !rep ? <Empty title="No report generated" hint="Generate a report from the stored results of the current simulation run." /> : (
            <article className="stack" style={{ gap: 18 }}>
              <SyntheticNotice>{rep.data_notice}</SyntheticNotice>
              <div className="grid g2">
                <dl className="kv">
                  <dt>Date</dt><dd>{new Date(rep.generated_at).toLocaleString()}</dd>
                  <dt>Simulation run</dt><dd>#{rep.run.id} (seed {rep.run.seed})</dd>
                  <dt>Simulation period</dt><dd>{num(rep.run.simulated_minutes, 0)} simulated minutes</dd>
                  <dt>Algorithm used</dt><dd>{ALGO_LABEL[rep.run.algorithm]}</dd>
                  <dt>Traffic level</dt><dd>{pct(rep.run.traffic_level)}</dd>
                </dl>
                <dl className="kv">
                  <dt>Number of orders</dt><dd>{rep.counts.orders} ({rep.counts.delivered} delivered)</dd>
                  <dt>Number of partners</dt><dd>{rep.counts.partners}</dd>
                  <dt>Assignments made</dt><dd>{rep.counts.assignments}</dd>
                  <dt>Average ETA</dt><dd>{mins(rep.kpis.avg_eta_min)}</dd>
                  <dt>Distance driven</dt><dd>{num(rep.kpis.total_distance_km, 1)} km</dd>
                  <dt>Average risk</dt><dd>{num(rep.kpis.avg_risk, 3)}</dd>
                  <dt>On-time rate</dt><dd>{pct(rep.kpis.on_time_rate, 1)}</dd>
                  <dt>Planned vs actual</dt><dd>{rep.planned_vs_actual.n ? `${num(rep.planned_vs_actual.mean_eta_deviation_min)} min mean ETA deviation` : '—'}</dd>
                </dl>
              </div>
              <div>
                <h3 style={{ fontSize: 14, marginBottom: 6 }}>Workload distribution</h3>
                <div className="table-wrap">
                  <table className="t">
                    <thead><tr><th>Partner</th><th className="num">Current load</th><th className="num">Completed</th><th className="num">On-time</th><th className="num">Distance</th></tr></thead>
                    <tbody>{rep.workload.map(w => <tr key={w.id}><td className="mono">{w.id}</td><td className="num">{w.load}/{w.capacity}</td><td className="num">{w.completed}</td><td className="num">{pct(w.on_time_rate)}</td><td className="num">{num(w.distance_km, 1)} km</td></tr>)}</tbody>
                  </table>
                </div>
              </div>
              <div>
                <h3 style={{ fontSize: 14, marginBottom: 6 }}>Algorithm comparison</h3>
                {!rep.evaluation ? <p className="muted">No evaluation stored.</p> : (
                  <div className="table-wrap">
                    <table className="t">
                      <thead><tr><th>Metric ({rep.evaluation.scenarios} scenarios, mean ± 95% CI)</th>{evAlgos.map(a => <th key={a} className="num">{ALGO_LABEL[a]}</th>)}</tr></thead>
                      <tbody>
                        {([['avg_eta_min', 'Avg travel time (min)', 1], ['total_km', 'Total distance (km)', 1], ['expected_on_time_rate', 'Expected on-time (%)', 100], ['avg_risk', 'Avg risk', 1], ['workload_balance', 'Workload balance', 1]] as [string, string, number][]).map(([k, l, s]) => (
                          <tr key={k}><td>{l}</td>{evAlgos.map(a => <td key={a} className="num">{(rep.evaluation!.results[a][k].mean * s).toFixed(2)} ± {(rep.evaluation!.results[a][k].ci95 * s).toFixed(2)}</td>)}</tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
              <div>
                <h3 style={{ fontSize: 14, marginBottom: 6 }}>Recommendations</h3>
                {rep.recommendations.length === 0 ? <p className="muted">No data-supported recommendations for this run yet.</p> :
                  <ul style={{ margin: 0, paddingLeft: 18, display: 'grid', gap: 4 }}>{rep.recommendations.map((r, i) => <li key={i}>{r.text}</li>)}</ul>}
              </div>
            </article>
          )}
        </Card>
      </div>
    </>
  )
}
