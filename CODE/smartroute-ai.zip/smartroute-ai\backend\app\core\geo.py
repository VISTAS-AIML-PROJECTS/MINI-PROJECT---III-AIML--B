"""Distance and ETA engine.

Road distance is approximated as great-circle distance x ROAD_FACTOR (no road graph is used).
Travel time slows linearly with the congestion sampled along the segment.
"""
from __future__ import annotations

import math
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .domain import Partner
    from .traffic import TrafficField

EARTH_RADIUS_KM = 6371.0
ROAD_FACTOR = 1.3  # straight-line -> road-distance approximation
SERVICE_MIN = 2.0  # minutes spent at each pickup / dropoff
MAX_SLOWDOWN = 0.5  # congestion 1.0 halves speed


def haversine_km(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lng2 - lng1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * EARTH_RADIUS_KM * math.asin(math.sqrt(a))


def road_km(lat1: float, lng1: float, lat2: float, lng2: float) -> float:
    return haversine_km(lat1, lng1, lat2, lng2) * ROAD_FACTOR


def effective_speed(speed_kmh: float, congestion: float) -> float:
    return speed_kmh * (1.0 - MAX_SLOWDOWN * max(0.0, min(1.0, congestion)))


def travel_minutes(lat1, lng1, lat2, lng2, speed_kmh: float, traffic: "TrafficField | None" = None) -> float:
    km = road_km(lat1, lng1, lat2, lng2)
    cong = traffic.mean_along(lat1, lng1, lat2, lng2) if traffic else 0.0
    return km / effective_speed(speed_kmh, cong) * 60.0


def route_minutes(partner: "Partner", traffic: "TrafficField | None") -> tuple[float, float]:
    """(minutes, km) to finish every stop already in the partner's route."""
    lat, lng = partner.lat, partner.lng
    minutes = km = 0.0
    for s in partner.route:
        minutes += travel_minutes(lat, lng, s.lat, s.lng, partner.speed_kmh, traffic) + SERVICE_MIN
        km += road_km(lat, lng, s.lat, s.lng)
        lat, lng = s.lat, s.lng
    return minutes, km
