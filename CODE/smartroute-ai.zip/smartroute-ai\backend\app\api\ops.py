"""Operational read/write endpoints: orders, partners, assignments, traffic, risk, metrics, analytics."""
from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel, Field
from sqlalchemy import select

from .. import auth, db
from ..config import settings
from ..schemas import GenerateOrders, PartnerPatch, RiskWeightsIn
from ..services import analytics as A
from ..services.simulation import simulation
from ..services.views import assignment_dict, load_state

public = APIRouter(prefix="/api")
router = APIRouter(prefix="/api", dependencies=[Depends(auth.require_user)])


class LoginIn(BaseModel):
    username: str = Field(min_length=1, max_length=64)
    password: str = Field(min_length=1, max_length=256)


@public.post("/auth/login")
def login(body: LoginIn, request: Request):
    ip = request.client.host if request.client else "unknown"
    if auth.rate_limited(ip):
        raise HTTPException(429, detail={"message": "Too many sign-in attempts.", "reason": "Sign-in is temporarily locked.",
                                         "action": "Wait 5 minutes and try again."})
    if not auth.check_password(body.username, body.password):
        auth.record_failure(ip)
        raise HTTPException(401, detail={"message": "Sign-in failed.", "reason": "Incorrect username or password."})
    return {"token": auth.issue_token(body.username), "user": body.username, "expires_in": auth.TOKEN_TTL_S}


@router.get("/auth/me")
def me(user: str = Depends(auth.require_user)):
    return {"user": user}


def _state():
    w = simulation.ensure()
    with db.SessionLocal() as s:
        return w, *load_state(s, w.run_id, w.now)


@public.get("/health")
def health():
    from ..algorithms import registry
    return {"status": "ok", "models": {k: registry.policy(k) is not None for k in ("ppo", "smartroute")}}


@router.get("/orders")
def orders(status: str | None = Query(default=None, max_length=20)):
    w, orders, _ = _state()
    if status:
        orders = [o for o in orders if o["status"] == status]
    return {"sim_time": w.now, "orders": orders, "data_notice": "Synthetic Simulation Data"}


@router.post("/orders/generate", status_code=201)
def generate_orders(body: GenerateOrders):
    new = simulation.add_orders(body.count, body.priority)
    return {"created": [o.id for o in new]}


@router.get("/partners")
def partners():
    w, _, partners = _state()
    return {"sim_time": w.now, "partners": partners, "data_notice": "Synthetic Simulation Data"}


@router.patch("/partners/{partner_id}")
def patch_partner(partner_id: str, body: PartnerPatch):
    try:
        simulation.set_partner_online(partner_id, body.online)
    except KeyError:
        raise HTTPException(404, detail={"message": "Partner not found.", "reason": f"No partner with id {partner_id}."})
    except ValueError as e:
        raise HTTPException(409, detail={"message": "Unable to take partner offline.", "reason": str(e)})
    return {"id": partner_id, "online": body.online}


@router.get("/assignments")
def assignments(limit: int = Query(default=100, ge=1, le=1000), algorithm: str | None = Query(default=None, max_length=20)):
    w = simulation.ensure()
    with db.SessionLocal() as s:
        q = select(db.AssignmentRow).where(db.AssignmentRow.run_id == w.run_id)
        if algorithm:
            q = q.where(db.AssignmentRow.algorithm == algorithm)
        rows = s.scalars(q.order_by(db.AssignmentRow.id.desc()).limit(limit)).all()
    return {"assignments": [assignment_dict(r) for r in rows]}


@router.get("/assignments/{assignment_id}/explanation")
def explanation(assignment_id: int):
    with db.SessionLocal() as s:
        row = s.scalars(select(db.ExplanationRow).where(db.ExplanationRow.assignment_id == assignment_id)).first()
    if not row:
        raise HTTPException(404, detail={"message": "Explanation not found.", "reason": f"No assignment {assignment_id}."})
    return row.payload


@router.get("/traffic")
def traffic():
    w = simulation.ensure()
    return {"sim_time": w.now, "level": w.traffic.level, "cells": w.traffic.cells(),
            "data_notice": "Synthetic traffic field (not real traffic data)"}


@router.get("/risk")
def risk():
    return A.risk_summary()


@router.get("/metrics")
def metrics():
    return simulation.kpis()


@router.get("/analytics")
def analytics():
    return A.analytics()


@router.get("/insights")
def insights():
    return {"insights": A.insights()}


@router.get("/reports/summary")
def report():
    return A.report()


@router.get("/settings/risk-weights")
def get_weights():
    return settings.risk_weights.__dict__


@router.put("/settings/risk-weights")
def put_weights(body: RiskWeightsIn):
    for k, v in body.model_dump().items():
        setattr(settings.risk_weights, k, v)
    simulation.configure()  # recompute live risk with new weights
    return settings.risk_weights.__dict__
