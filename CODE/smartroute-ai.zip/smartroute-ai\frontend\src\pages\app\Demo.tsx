import { CheckCircle2, Loader2, Play, XCircle } from 'lucide-react'
import { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { ALGO_LABEL, api, ApiError, type AssignResponse, type Explanation, type Kpis } from '../../api'
import Decision from '../../components/Decision'
import { PageHeader } from '../../components/Layout'
import { Card, ErrorBanner, SyntheticNotice } from '../../components/ui'
import { mins, num, pct } from '../../format'
import { useSim } from '../../hooks'

type StepState = 'todo' | 'active' | 'done' | 'fail'
const STEPS = [
  'Generate orders', 'Generate traffic', 'Calculate risk', 'Run baseline', 'Run Hungarian', 'Run SmartRoute AI',
  'Assign orders', 'Generate explanation', 'Update dashboard', 'Show metrics',
] as const

/** Runs the real pipeline end-to-end through the public API — no scripted results. */
export default function Demo() {
  const { refresh } = useSim()
  const [state, setState] = useState<StepState[]>(STEPS.map(() => 'todo'))
  const [log, setLog] = useState<string[]>([])
  const [running, setRunning] = useState(false)
  const [error, setError] = useState<ApiError | null>(null)
  const [cmp, setCmp] = useState<AssignResponse[]>([])
  const [exp, setExp] = useState<Explanation | null>(null)
  const [kpis, setKpis] = useState<Kpis | null>(null)
  const cancelled = useRef(false)
  useEffect(() => () => { cancelled.current = true }, [])

  const step = async <T,>(i: number, fn: () => Promise<T>, msg: (r: T) => string): Promise<T> => {
    if (cancelled.current) throw new ApiError(0, 'Demo cancelled.')
    setState(s => s.map((v, j) => (j === i ? 'active' : v)))
    try {
      const r = await fn()
      setState(s => s.map((v, j) => (j === i ? 'done' : v)))
      setLog(l => [...l, `✓ ${STEPS[i]} — ${msg(r)}`])
      await new Promise(res => setTimeout(res, 450)) // pacing so each stage is readable
      return r
    } catch (e) {
      setState(s => s.map((v, j) => (j === i ? 'fail' : v)))
      throw e
    }
  }

  const start = async () => {
    cancelled.current = false
    setRunning(true); setError(null); setLog([]); setCmp([]); setExp(null); setKpis(null)
    setState(STEPS.map(() => 'todo'))
    try {
      await api.post('/simulation/pause')
      await step(0, () => api.post<{ created: string[] }>('/orders/generate', { count: 8 }), r => `${r.created.length} synthetic orders created (${r.created[0]}…${r.created.at(-1)})`)
      await step(1, () => api.post<{ traffic_level: number }>('/simulation/step', { minutes: 1 }), r => `traffic field advanced one minute (level ${pct(r.traffic_level)})`)
      await step(2, () => api.get<{ overall: number; levels: Record<string, number> }>('/risk'), r => `overall active risk ${r.overall.toFixed(2)} · HIGH+CRITICAL ${(r.levels.HIGH ?? 0) + (r.levels.CRITICAL ?? 0)}`)
      const runs: AssignResponse[] = []
      for (const [i, a] of [[3, 'nearest'], [4, 'hungarian'], [5, 'smartroute']] as const) {
        const r = await step(i, () => api.post<AssignResponse>(`/assign/${a}`, {}), r =>
          `${r.metrics.assigned} assigned · avg ETA ${mins(r.metrics.avg_eta_min)} · expected on-time ${pct(r.metrics.expected_on_time_rate)} · risk ${num(r.metrics.avg_risk, 3)}`)
        runs.push(r)
        setCmp([...runs])
      }
      const applied = await step(6, () => api.post<AssignResponse>('/assign/smartroute', { apply: true }), r => `${r.committed?.length ?? 0} assignments committed by ${ALGO_LABEL.smartroute}`)
      const first = applied.committed?.[0]
      if (first) {
        const e = await step(7, () => api.get<Explanation>(`/assignments/${first.assignment_id}/explanation`), e => `${e.order_id} → ${e.partner_id}: ${e.reasons.length} feature-based reasons`)
        setExp(e)
      } else {
        await step(7, async () => null, () => 'no assignment to explain (no eligible partners)')
      }
      await step(8, async () => { refresh(); return null }, () => 'dashboard data refreshed')
      const k = await step(9, () => api.get<Kpis>('/metrics'), k => `${k.active_orders} active orders · utilization ${pct(k.utilization)} · ${k.ai_assignments} AI assignments`)
      setKpis(k)
    } catch (e) {
      setError(e instanceof ApiError ? e : new ApiError(0, 'Demo failed.'))
    } finally {
      setRunning(false)
    }
  }

  return (
    <>
      <PageHeader title="Smart Demo" crumb="Guided walkthrough" />
      <div className="content">
        <SyntheticNotice>The demo calls the real backend API at every stage. Results differ between runs because the simulation state changes.</SyntheticNotice>
        <Card title="START SMART DEMO" right={<button className="btn primary lg" onClick={start} disabled={running}>{running ? <Loader2 size={16} className="spin" /> : <Play size={16} />}{running ? 'Running…' : 'Start Smart Demo'}</button>}>
          <ol className="pipeline" aria-label="Demo pipeline" style={{ listStyle: 'none', margin: 0, padding: 0 }}>
            {STEPS.map((s, i) => (
              <li key={s} className={`pipe-step ${state[i] === 'todo' ? '' : state[i]}`} aria-current={state[i] === 'active' ? 'step' : undefined}>
                {state[i] === 'done' ? <CheckCircle2 size={14} /> : state[i] === 'fail' ? <XCircle size={14} /> : <span className="mono">{i + 1}</span>}{s}
              </li>
            ))}
          </ol>
          {log.length > 0 && <pre className="mono" aria-live="polite" style={{ marginTop: 14, background: 'var(--ink)', color: '#c9d3e6', padding: 12, borderRadius: 8, fontSize: 12, whiteSpace: 'pre-wrap' }}>{log.join('\n')}</pre>}
          {error && <div style={{ marginTop: 10 }}><ErrorBanner error={error} /></div>}
        </Card>
        {cmp.length > 0 && (
          <Card title="Same orders, three algorithms (simulation result)">
            <div className="table-wrap">
              <table className="t">
                <thead><tr><th>Algorithm</th><th className="num">Assigned</th><th className="num">Avg ETA</th><th className="num">Distance</th><th className="num">Expected on-time</th><th className="num">Avg risk</th><th className="num">Balance</th></tr></thead>
                <tbody>{cmp.map(r => (
                  <tr key={r.algorithm}><td>{r.label}</td><td className="num">{r.metrics.assigned}</td><td className="num">{mins(r.metrics.avg_eta_min)}</td><td className="num">{num(r.metrics.total_km, 1)} km</td>
                    <td className="num">{pct(r.metrics.expected_on_time_rate)}</td><td className="num">{num(r.metrics.avg_risk, 3)}</td><td className="num">{num(r.metrics.workload_balance, 3)}</td></tr>
                ))}</tbody>
              </table>
            </div>
            <p className="faint" style={{ fontSize: 12, marginTop: 6 }}>One snapshot only — see the Algorithm Center for the multi-scenario evaluation.</p>
          </Card>
        )}
        {(exp || kpis) && (
          <div className="grid g2">
            {exp && <Card title="Generated explanation"><Decision e={exp} /></Card>}
            {kpis && (
              <Card title="Updated metrics" right={<Link className="btn sm" to="/app">Open dashboard</Link>}>
                <dl className="kv">
                  <dt>Active orders</dt><dd>{kpis.active_orders}</dd><dt>Pending</dt><dd>{kpis.pending_orders}</dd>
                  <dt>Available partners</dt><dd>{kpis.available_partners}/{kpis.online_partners}</dd>
                  <dt>Average ETA</dt><dd>{mins(kpis.avg_eta_min)}</dd><dt>Average risk</dt><dd>{num(kpis.avg_risk, 3)}</dd>
                  <dt>Utilization</dt><dd>{pct(kpis.utilization)}</dd><dt>AI assignments</dt><dd>{kpis.ai_assignments}</dd>
                </dl>
              </Card>
            )}
          </div>
        )}
      </div>
    </>
  )
}
