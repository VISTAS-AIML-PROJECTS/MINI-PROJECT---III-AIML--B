// Centralised API client + shared types for the SmartRoute AI backend.

export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'
export type AlgorithmId = 'nearest' | 'hungarian' | 'ppo' | 'smartroute'
export type OrderStatus = 'pending' | 'assigned' | 'in_transit' | 'delivered' | 'delayed' | 'at_risk'
export type PartnerStatus = 'available' | 'busy' | 'at_capacity' | 'offline' | 'at_risk'

export interface Place { name: string; lat: number; lng: number }
export interface Order {
  id: string; priority: 'low' | 'normal' | 'high' | 'urgent'; status: OrderStatus; base_status: string
  pickup: Place; drop: Place; created_at: number; deadline: number; minutes_to_deadline: number
  partner_id: string | null; assigned_by: string | null; assigned_at: number | null
  eta: number | null; eta_min: number | null; planned_eta: number | null; planned_km: number | null
  planned_risk: number | null; delivered_at: number | null; actual_km: number
  risk: number; risk_level: RiskLevel; risk_parts: Record<string, number>; delay_prob: number
}
export interface RouteStop { order_id: string; kind: 'pickup' | 'dropoff'; lat: number; lng: number }
export interface Partner {
  id: string; name: string; status: PartnerStatus; online: boolean; lat: number; lng: number
  capacity: number; load: number; utilization: number; speed_kmh: number; completed: number; on_time: number
  on_time_rate: number | null; distance_km: number; active_orders: string[]; route: RouteStop[]
  trail: [number, number][]; risk: number; risk_level: RiskLevel; avg_eta_min: number | null
}
export interface Kpis {
  sim_time: number; active_orders: number; pending_orders: number; delivered_orders: number
  available_partners: number; online_partners: number; on_time_rate: number | null; avg_eta_min: number | null
  total_distance_km: number; avg_risk: number; utilization: number; ai_assignments: number; traffic_mean: number
}
export interface SimConfig {
  n_partners: number; initial_orders: number; order_rate_per_hour: number; traffic_level: number
  algorithm: AlgorithmId; auto_assign: boolean; batch_every_min: number; minutes_per_tick: number; seed: number
}
export interface SimStatus { status: 'idle' | 'running' | 'paused'; run_id: number; sim_time: number; config: SimConfig; traffic_level: number; kpis: Kpis }
export interface TrafficCell { zone: string; congestion: number; bounds: [[number, number], [number, number]] }
export interface Candidate {
  order_id: string; partner_id: string; eta_min: number; pickup_min: number; km: number; congestion: number
  slack_min: number; delay_prob: number; cvar_late_min: number; load_after: number; capacity: number; feasible: boolean
  risk: { traffic: number; delay: number; distance: number; workload: number; score: number; level: RiskLevel }
}
export interface Reason { kind: 'positive' | 'tradeoff' | 'info'; feature: string; text: string }
export interface CostSide { partner_id: string; components: Record<string, number>; total: number }
export interface Explanation {
  order_id: string; partner_id: string; algorithm: string; confidence: number | null; confidence_basis: string | null
  decision: Candidate; reasons: Reason[]
  cost_breakdown: { basis: string; chosen: CostSide; runner_up: CostSide | null } | null
  policy_attribution: { method: string; note: string; features: { feature: string; label: string; value: number; impact: number }[] } | null
  alternatives: Candidate[]
}
export interface AssignMetrics {
  assigned: number; unassigned: number; avg_eta_min: number; total_km: number; expected_on_time_rate: number
  deadline_feasible_rate: number; avg_risk: number; avg_cvar_late_min: number; workload_balance: number; utilization: number
}
export interface AssignResponse {
  algorithm: AlgorithmId; label: string; metrics: AssignMetrics; runtime_ms: number; unassigned: string[]
  decisions: Explanation[]; extras: Record<string, unknown> & {
    cost_matrix?: { orders: string[]; partners: string[]; values: number[][]; selected: Record<string, string> }
  }
  committed?: { assignment_id: number; order_id: string; partner_id: string }[]; data_notice: string
}
export interface Assignment {
  id: number; batch_id: string; order_id: string; partner_id: string; algorithm: string; sim_time: number
  confidence: number | null; eta_min: number; km: number; risk: number; risk_level: RiskLevel; delay_prob: number
  feasible: boolean; load_after: number; capacity: number
}
export interface MetricStat { mean: number; ci95: number }
export interface Evaluation { id: number; scenarios: number; seed: number; started_at: string; results: Record<string, Record<string, MetricStat>> }
export interface Insight { kind: string; text: string; evidence: Record<string, unknown> }
export interface RiskEvent { id: number; sim_time: number; category: string; level: RiskLevel; entity_type: string; entity_id: string; message: string; action: string }

export class ApiError extends Error {
  reason?: string
  action?: string
  status: number
  constructor(status: number, message: string, reason?: string, action?: string) {
    super(message)
    this.status = status
    this.reason = reason
    this.action = action
  }
}

const TOKEN_KEY = 'smartroute.token'
export const session = {
  get: () => { try { return sessionStorage.getItem(TOKEN_KEY) } catch { return null } },
  set: (t: string) => { try { sessionStorage.setItem(TOKEN_KEY, t) } catch { /* storage unavailable: session lasts for this page only */ } },
  clear: () => { try { sessionStorage.removeItem(TOKEN_KEY) } catch { /* ignore */ } },
}

async function request<T>(method: string, path: string, body?: unknown, signal?: AbortSignal): Promise<T> {
  let res: Response
  const token = session.get()
  try {
    res = await fetch(`/api${path}`, {
      method, signal,
      headers: {
        ...(body === undefined ? {} : { 'Content-Type': 'application/json' }),
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: body === undefined ? undefined : JSON.stringify(body),
    })
  } catch (e) {
    if ((e as Error).name === 'AbortError') throw e
    throw new ApiError(0, 'Cannot reach the SmartRoute AI server.', 'The backend API is not responding.',
      'Start the backend (see README) and retry.')
  }
  const data = await res.json().catch(() => null)
  if (res.status === 401 && path !== '/auth/login') {
    session.clear()
    window.location.assign(`/login?next=${encodeURIComponent(window.location.pathname + window.location.search)}`)
  }
  if (!res.ok) {
    const err = data?.error ?? {}
    throw new ApiError(res.status, err.message ?? `Request failed (${res.status}).`, err.reason, err.action)
  }
  return data as T
}

export const api = {
  get: <T,>(path: string, signal?: AbortSignal) => request<T>('GET', path, undefined, signal),
  post: <T,>(path: string, body: unknown = {}) => request<T>('POST', path, body),
  put: <T,>(path: string, body: unknown) => request<T>('PUT', path, body),
  patch: <T,>(path: string, body: unknown) => request<T>('PATCH', path, body),
}

export const ALGO_LABEL: Record<string, string> = {
  nearest: 'Nearest Partner', hungarian: 'Hungarian', ppo: 'PPO', smartroute: 'SmartRoute AI',
  riskaware_hungarian: 'Risk-aware Hungarian (ablation)',
}
export const ALGO_SHORT: Record<string, string> = {
  nearest: 'Nearest', hungarian: 'Hungarian', ppo: 'PPO', smartroute: 'SmartRoute', riskaware_hungarian: 'Risk-aware H.',
}
export const ALGO_COLOR: Record<string, string> = {
  nearest: '#94a3b8', hungarian: '#6d5bd0', ppo: '#d97706', smartroute: '#0d9488', riskaware_hungarian: '#2563eb',
}
