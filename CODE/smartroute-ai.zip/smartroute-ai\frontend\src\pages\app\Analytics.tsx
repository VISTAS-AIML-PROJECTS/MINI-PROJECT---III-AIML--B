import { Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart, ReferenceLine, ResponsiveContainer, Scatter, ScatterChart, Tooltip, XAxis, YAxis, ZAxis } from 'recharts'
import { ALGO_COLOR, ALGO_LABEL, type Evaluation, type Kpis, type Partner, type TrafficCell } from '../../api'
import { PageHeader } from '../../components/Layout'
import { Card, Empty, ErrorState, Kpi, Loading, SyntheticNotice } from '../../components/ui'
import { clock, mins, num, pct, riskColor } from '../../format'
import { useApi } from '../../hooks'

interface PVA { id: string; planned_eta: number; actual_eta: number; planned_km: number; actual_km: number; late: boolean; algorithm: string }
interface AnalyticsData {
  sim_time: number; kpis: Kpis; history: (Kpis & { t: number })[]; partners: Partner[]
  risk_distribution: Record<string, number>; planned_vs_actual: PVA[]
  planned_vs_actual_summary: { n: number; mean_eta_deviation_min: number | null; mean_km_deviation: number | null }
  delay_causes: Record<string, number>; algorithms_live: Record<string, { assignments: number; avg_eta_min: number; avg_risk: number; feasible_rate: number }>
  evaluation: Evaluation | null; zones: TrafficCell[]
}
const LEVEL_COLOR: Record<string, string> = { LOW: '#15803d', MEDIUM: '#d97706', HIGH: '#ea580c', CRITICAL: '#dc2626' }
const tickClock = (v: number) => clock(v)

export default function Analytics() {
  const { data: a, error, loading } = useApi<AnalyticsData>('/analytics')
  if (error) return <><PageHeader title="Analytics" crumb="Monitor" /><div className="content"><ErrorState error={error} /></div></>
  if (loading || !a) return <><PageHeader title="Analytics" crumb="Monitor" /><div className="content"><Loading label="Loading analytics…" /></div></>
  const k = a.kpis
  const delivered = a.partners.reduce((s, p) => s + p.completed, 0)
  const evAlgos = a.evaluation ? ['nearest', 'hungarian', 'ppo', 'smartroute'].filter(x => x in a.evaluation!.results) : []
  const maxEta = Math.max(10, ...a.planned_vs_actual.map(r => Math.max(r.planned_eta, r.actual_eta)))
  return (
    <>
      <PageHeader title="Analytics" crumb="Monitor" />
      <div className="content">
        <SyntheticNotice>All values below are simulation results for the current synthetic run.</SyntheticNotice>
        <h2 style={{ fontSize: 15 }}>Operational KPIs</h2>
        <div className="kpis">
          <Kpi label="On-time delivery" value={pct(k.on_time_rate)} sub={`${k.delivered_orders} delivered`} />
          <Kpi label="Average ETA" value={mins(k.avg_eta_min)} sub="active orders" />
          <Kpi label="Average distance" value={delivered ? `${num(k.total_distance_km / delivered, 2)} km` : '—'} sub="driven per delivery" />
          <Kpi label="Average risk" value={num(k.avg_risk, 2)} />
          <Kpi label="Utilization" value={pct(k.utilization)} />
        </div>
        <Card title="KPIs over simulated time">
          {a.history.length < 2 ? <Empty title="No history yet" hint="Run the simulation to collect metrics." /> : (
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={a.history} margin={{ left: -14, right: 8 }}>
                <CartesianGrid stroke="#eef2f7" vertical={false} />
                <XAxis dataKey="t" tickFormatter={tickClock} fontSize={11} minTickGap={30} />
                <YAxis fontSize={11} domain={[0, 1]} />
                <Tooltip labelFormatter={v => clock(Number(v))} formatter={(v) => (v == null ? '—' : Number(v).toFixed(2))} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Line dataKey="on_time_rate" name="On-time rate" stroke="#0d9488" dot={false} connectNulls />
                <Line dataKey="avg_risk" name="Avg risk" stroke="#ea580c" dot={false} />
                <Line dataKey="utilization" name="Utilization" stroke="#6d5bd0" dot={false} />
                <Line dataKey="traffic_mean" name="Mean congestion" stroke="#94a3b8" strokeDasharray="4 3" dot={false} />
              </LineChart>
            </ResponsiveContainer>
          )}
        </Card>

        <h2 style={{ fontSize: 15 }}>Planned vs actual</h2>
        <div className="grid g2">
          <Card title="Planned vs actual delivery time" right={<span className="faint" style={{ fontSize: 12 }}>{a.planned_vs_actual_summary.n} delivered</span>}>
            {a.planned_vs_actual.length === 0 ? <Empty title="No completed deliveries" hint="Planned and actual times are compared once orders are delivered." /> : (
              <>
                <ResponsiveContainer width="100%" height={260}>
                  <ScatterChart margin={{ left: -6, right: 12, bottom: 10 }}>
                    <CartesianGrid stroke="#eef2f7" />
                    <XAxis type="number" dataKey="planned_eta" name="Planned" unit=" min" fontSize={11} domain={[0, maxEta]} label={{ value: 'Planned ETA (min)', position: 'insideBottom', offset: -4, fontSize: 11 }} />
                    <YAxis type="number" dataKey="actual_eta" name="Actual" unit=" min" fontSize={11} domain={[0, maxEta]} />
                    <ZAxis range={[40, 40]} />
                    <ReferenceLine segment={[{ x: 0, y: 0 }, { x: maxEta, y: maxEta }]} stroke="#94a3b8" strokeDasharray="4 4" />
                    <Tooltip cursor={{ strokeDasharray: '3 3' }} formatter={(v) => `${Number(v).toFixed(1)} min`} />
                    <Scatter data={a.planned_vs_actual} name="Deliveries">
                      {a.planned_vs_actual.map(r => <Cell key={r.id} fill={r.late ? '#dc2626' : '#0d9488'} />)}
                    </Scatter>
                  </ScatterChart>
                </ResponsiveContainer>
                <p className="faint" style={{ fontSize: 12 }}>Dashed line = actual equals plan. Points above it took longer than planned. Red = delivered after deadline.
                  Mean deviation: {a.planned_vs_actual_summary.mean_eta_deviation_min?.toFixed(1)} min, {a.planned_vs_actual_summary.mean_km_deviation?.toFixed(2)} km.</p>
              </>
            )}
          </Card>
          <Card title="Planned vs actual distance (latest 15)" flush>
            {a.planned_vs_actual.length === 0 ? <Empty title="No completed deliveries" /> : (
              <div className="table-wrap">
                <table className="t">
                  <thead><tr><th>Order</th><th>Algorithm</th><th className="num">Planned ETA</th><th className="num">Actual</th><th className="num">Planned km</th><th className="num">Actual km</th></tr></thead>
                  <tbody>{a.planned_vs_actual.slice(-15).reverse().map(r => (
                    <tr key={r.id}><td className="mono">{r.id}</td><td>{ALGO_LABEL[r.algorithm] ?? r.algorithm}</td><td className="num">{r.planned_eta.toFixed(1)}</td>
                      <td className="num" style={{ color: r.actual_eta > r.planned_eta + 2 ? 'var(--crit)' : undefined }}>{r.actual_eta.toFixed(1)}</td>
                      <td className="num">{r.planned_km.toFixed(2)}</td><td className="num">{r.actual_km.toFixed(2)}</td></tr>
                  ))}</tbody>
                </table>
              </div>
            )}
            <p className="faint" style={{ fontSize: 11.5, padding: '8px 12px' }}>Planned km is the marginal distance at assignment; actual km is the distance driven while the order was on board or next, shared between concurrent orders.</p>
          </Card>
        </div>

        <h2 style={{ fontSize: 15 }}>Algorithm KPIs</h2>
        <div className="grid g2">
          <Card title="Evaluation (multi-scenario)" right={a.evaluation && <span className="faint" style={{ fontSize: 12 }}>{a.evaluation.scenarios} scenarios · mean</span>}>
            {!a.evaluation ? <Empty title="No evaluation yet" hint="Run one from the Algorithm Center." /> : (
              <ResponsiveContainer width="100%" height={230}>
                <BarChart data={[
                  { m: 'On-time', ...Object.fromEntries(evAlgos.map(x => [x, a.evaluation!.results[x].expected_on_time_rate.mean])) },
                  { m: 'Feasible', ...Object.fromEntries(evAlgos.map(x => [x, a.evaluation!.results[x].deadline_feasible_rate.mean])) },
                  { m: 'Risk', ...Object.fromEntries(evAlgos.map(x => [x, a.evaluation!.results[x].avg_risk.mean])) },
                  { m: 'Balance', ...Object.fromEntries(evAlgos.map(x => [x, a.evaluation!.results[x].workload_balance.mean])) },
                ]} margin={{ left: -14, right: 8 }}>
                  <CartesianGrid stroke="#eef2f7" vertical={false} />
                  <XAxis dataKey="m" fontSize={11} /><YAxis fontSize={11} domain={[0, 1]} />
                  <Tooltip formatter={(v) => Number(v).toFixed(3)} /><Legend wrapperStyle={{ fontSize: 11 }} />
                  {evAlgos.map(x => <Bar key={x} dataKey={x} name={ALGO_LABEL[x]} fill={ALGO_COLOR[x]} isAnimationActive={false} />)}
                </BarChart>
              </ResponsiveContainer>
            )}
          </Card>
          <Card title="This run — by assigning algorithm" flush>
            {Object.keys(a.algorithms_live).length === 0 ? <Empty title="No assignments yet" /> : (
              <div className="table-wrap">
                <table className="t">
                  <thead><tr><th>Algorithm</th><th className="num">Assignments</th><th className="num">Avg planned ETA</th><th className="num">Avg risk</th><th className="num">Feasible</th></tr></thead>
                  <tbody>{Object.entries(a.algorithms_live).map(([n, v]) => (
                    <tr key={n}><td>{ALGO_LABEL[n] ?? n}</td><td className="num">{v.assignments}</td><td className="num">{mins(v.avg_eta_min)}</td><td className="num">{v.avg_risk.toFixed(3)}</td><td className="num">{pct(v.feasible_rate)}</td></tr>
                  ))}</tbody>
                </table>
              </div>
            )}
            <p className="faint" style={{ fontSize: 11.5, padding: '8px 12px' }}>Live rows are not a controlled comparison: each algorithm saw different orders and traffic. Use the evaluation for comparisons.</p>
          </Card>
        </div>

        <h2 style={{ fontSize: 15 }}>Partner KPIs</h2>
        <Card title="Completed orders, workload and on-time rate">
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={a.partners.map(p => ({ id: p.id, completed: p.completed, load: p.load }))} margin={{ left: -14, right: 8 }}>
              <CartesianGrid stroke="#eef2f7" vertical={false} />
              <XAxis dataKey="id" fontSize={11} /><YAxis fontSize={11} allowDecimals={false} />
              <Tooltip /><Legend wrapperStyle={{ fontSize: 11 }} />
              <Bar dataKey="completed" name="Completed" fill="#0d9488" isAnimationActive={false} />
              <Bar dataKey="load" name="Current workload" fill="#6d5bd0" isAnimationActive={false} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <h2 style={{ fontSize: 15 }}>Risk analytics</h2>
        <div className="grid g3">
          <Card title="Risk distribution (active)">
            {Object.values(a.risk_distribution).every(v => !v) ? <Empty title="No active orders" /> : (
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'].map(l => ({ l, n: a.risk_distribution[l] ?? 0 }))} margin={{ left: -20, right: 8 }}>
                  <XAxis dataKey="l" fontSize={11} /><YAxis fontSize={11} allowDecimals={false} /><Tooltip />
                  <Bar dataKey="n" name="Orders" isAnimationActive={false}>{['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'].map(l => <Cell key={l} fill={LEVEL_COLOR[l]} />)}</Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </Card>
          <Card title="High-congestion zones">
            <div className="stack">
              {a.zones.slice(0, 6).map(z => (
                <div key={z.zone} className="row between"><span className="mono">Zone {z.zone}</span><span className="badge" style={{ color: riskColor(z.congestion) }}>{pct(z.congestion)} congestion</span></div>
              ))}
            </div>
          </Card>
          <Card title="Delay causes (late deliveries)">
            {Object.keys(a.delay_causes).length === 0 ? <Empty title="No late deliveries" /> : (
              <div className="stack">
                {Object.entries(a.delay_causes).map(([c, n]) => <div key={c} className="row between"><span>{c}</span><strong>{n}</strong></div>)}
                <p className="faint" style={{ fontSize: 11.5 }}>Classified by comparing the planned ETA at assignment with the deadline.</p>
              </div>
            )}
          </Card>
        </div>
      </div>
    </>
  )
}
