"""Live simulation engine. Holds the authoritative world state in memory and mirrors it to the
database after every change so API reads go through the DB."""
from __future__ import annotations

import math
import threading
import time
import uuid
from dataclasses import dataclass, field

import numpy as np
from sqlalchemy import delete, select

from .. import db
from ..algorithms import registry
from ..algorithms.base import AssignmentResult
from ..config import settings
from ..core import scenario
from ..core.candidate import apply
from ..core.domain import Order, Partner, Stop
from ..core.geo import SERVICE_MIN, effective_speed, haversine_km, road_km, travel_minutes
from ..core.risk import compute_risk, cvar_lateness, delay_probability, level
from ..core.traffic import TrafficField
from ..explain import explain

TRAIL_LEN = 40


@dataclass
class SimConfig:
    n_partners: int = 12
    initial_orders: int = 14
    order_rate_per_hour: float = 40.0
    traffic_level: float = 0.55
    algorithm: str = "smartroute"
    auto_assign: bool = True
    batch_every_min: float = 3.0
    minutes_per_tick: float = 1.0
    seed: int = settings.seed


@dataclass
class World:
    run_id: int
    now: float
    partners: list[Partner]
    orders: dict[str, Order]
    traffic: TrafficField
    rng: np.random.Generator
    next_order: int
    last_batch: float = 0.0
    service_left: dict[str, float] = field(default_factory=dict)  # partner -> minutes still at a stop
    active_events: set[tuple[str, str]] = field(default_factory=set)


class Simulation:
    def __init__(self) -> None:
        self.lock = threading.RLock()
        self.cfg = SimConfig()
        self.status = "idle"  # idle | running | paused
        self.last_tick = time.monotonic()
        self.world: World | None = None

    # ------------------------------------------------------------------ lifecycle
    def reset(self, cfg: SimConfig | None = None) -> None:
        with self.lock:
            if cfg:
                self.cfg = cfg
            c = self.cfg
            rng = np.random.default_rng(c.seed)
            partners, orders = scenario.generate(rng, c.n_partners, c.initial_orders)
            if partners:
                partners[-1].online = False  # one partner off-shift to show OFFLINE handling
            traffic = TrafficField(settings.city_lat, settings.city_lng, settings.city_radius_km,
                                   level=c.traffic_level, seed=c.seed)
            with db.SessionLocal() as s:
                run = db.SimulationRun(seed=c.seed, n_partners=c.n_partners, algorithm=c.algorithm,
                                       traffic_level=c.traffic_level, order_rate=c.order_rate_per_hour)
                s.add(run)
                s.commit()
                run_id = run.id
            self.world = World(run_id, 0.0, partners, {o.id: o for o in orders}, traffic, rng,
                               next_order=101 + len(orders))
            self.status = "idle"
            self._refresh_live()
            self._persist(full=True)

    def ensure(self) -> World:
        if self.world is None:
            self.reset()
        return self.world

    def set_status(self, status: str) -> None:
        with self.lock:
            self.ensure()
            self.status = status
            self.last_tick = time.monotonic()
            self._persist_run()

    def configure(self, **kw) -> None:
        with self.lock:
            w = self.ensure()
            for k, v in kw.items():
                if v is not None and hasattr(self.cfg, k):
                    setattr(self.cfg, k, v)
            if kw.get("traffic_level") is not None:
                w.traffic.set_level(kw["traffic_level"])
            self._refresh_live()
            self._persist()

    # ------------------------------------------------------------------ orders / partners
    def add_orders(self, count: int, priority: str | None = None) -> list[Order]:
        with self.lock:
            w = self.ensure()
            new = []
            for _ in range(count):
                o = scenario.make_order(w.rng, f"O{w.next_order:03d}", w.now)
                if priority:
                    o.priority = priority
                    lo, hi = scenario.DEADLINE_WINDOW[priority]
                    o.deadline = w.now + float(w.rng.uniform(lo, hi))
                w.next_order += 1
                w.orders[o.id] = o
                new.append(o)
            self._refresh_live()
            self._persist()
            return new

    def set_partner_online(self, pid: str, online: bool) -> Partner:
        with self.lock:
            w = self.ensure()
            p = next((p for p in w.partners if p.id == pid), None)
            if p is None:
                raise KeyError(pid)
            if not online and p.route:
                raise ValueError("Partner still has orders on their route; reassign or wait until they finish.")
            p.online = online
            self._persist()
            return p

    # ------------------------------------------------------------------ assignment
    def pending(self, order_ids: list[str] | None = None) -> list[Order]:
        w = self.ensure()
        ids = set(order_ids) if order_ids else None
        return [o for o in w.orders.values() if o.status == "pending" and (ids is None or o.id in ids)]

    def run_algorithm(self, name: str, order_ids: list[str] | None = None, traffic_level: float | None = None,
                      risk_scale: float = 1.0) -> tuple[AssignmentResult, list[Order], TrafficField]:
        """Run an algorithm on the current state without changing it."""
        with self.lock:
            w = self.ensure()
            orders = self.pending(order_ids)
            traffic = w.traffic
            if traffic_level is not None:  # what-if scenario on a copy of the traffic field
                traffic = TrafficField.__new__(TrafficField)
                traffic.__dict__.update({k: (v.copy() if isinstance(v, np.ndarray) else v)
                                         for k, v in w.traffic.__dict__.items()})
                traffic.set_level(traffic_level)
            res = registry.run(name, w.partners, orders, w.now, traffic, risk_scale)
            res.extras.setdefault("risk_scale", risk_scale)
            return res, orders, traffic

    def commit(self, res: AssignmentResult, orders: list[Order]) -> list[dict]:
        """Apply an algorithm result to the live world and store assignments + explanations."""
        with self.lock:
            w = self.ensure()
            by_id = {o.id: o for o in orders}
            pmap = {p.id: p for p in w.partners}
            batch = uuid.uuid4().hex[:12]
            pol = registry.policy("smartroute" if res.algorithm == "smartroute" else "ppo") \
                if res.algorithm in ("ppo", "smartroute") else None
            stored = []
            with db.SessionLocal() as s:
                for d in res.decisions:
                    o, p = by_id[d.order_id], pmap[d.partner_id]
                    if o.status != "pending" or p.remaining_capacity <= 0:
                        continue  # state changed since the plan was made
                    apply(p, o)
                    c = d.chosen
                    o.status, o.partner_id, o.assigned_by, o.assigned_at = "assigned", p.id, res.algorithm, w.now
                    o.planned_eta, o.planned_km, o.planned_risk = w.now + c.eta_min, c.km, c.risk.score
                    row = db.AssignmentRow(run_id=w.run_id, batch_id=batch, order_id=o.id, partner_id=p.id,
                                           algorithm=res.algorithm, sim_time=w.now, confidence=d.confidence,
                                           eta_min=c.eta_min, km=c.km, risk=c.risk.score, risk_level=c.risk.level,
                                           delay_prob=c.delay_prob, feasible=c.feasible, load_after=c.load_after,
                                           capacity=c.capacity)
                    s.add(row)
                    s.flush()
                    s.add(db.ExplanationRow(assignment_id=row.id, payload=explain(d, o, res.algorithm, pol, res.extras.get("risk_scale", 1.0))))
                    stored.append({"assignment_id": row.id, "order_id": o.id, "partner_id": p.id})
                s.commit()
            w.last_batch = w.now
            self._refresh_live()
            self._persist()
            return stored

    # ------------------------------------------------------------------ time step
    def catch_up(self, tick_seconds: float = 1.0, max_ticks: int = 30) -> None:
        """Lazy clock: while running, advance one tick per elapsed `tick_seconds` of wall time.
        Called on every API request, so it works without a background task (serverless-friendly)."""
        with self.lock:
            if self.status != "running":
                return
            due = int((time.monotonic() - self.last_tick) / tick_seconds)
            if due <= 0:
                return
            self.last_tick += due * tick_seconds
            for _ in range(min(due, max_ticks)):  # ponytail: long gaps are capped, not replayed
                self.step()

    def step(self, minutes: float | None = None) -> None:
        with self.lock:
            w = self.ensure()
            dt = minutes or self.cfg.minutes_per_tick
            w.now += dt
            w.traffic.step(dt)
            # Poisson order arrivals
            for _ in range(int(w.rng.poisson(self.cfg.order_rate_per_hour / 60.0 * dt))):
                o = scenario.make_order(w.rng, f"O{w.next_order:03d}", w.now)
                w.next_order += 1
                w.orders[o.id] = o
            for p in w.partners:
                self._move(w, p, dt)
            if self.cfg.auto_assign and w.now - w.last_batch >= self.cfg.batch_every_min and self.pending():
                try:
                    res, orders, _ = self.run_algorithm(self.cfg.algorithm)
                    self.commit(res, orders)
                except registry.ModelNotTrained:
                    res, orders, _ = self.run_algorithm("hungarian")
                    self.commit(res, orders)
            self._refresh_live()
            self._persist()

    def _move(self, w: World, p: Partner, dt: float) -> None:
        budget = dt
        while budget > 1e-9 and p.route:
            wait = w.service_left.get(p.id, 0.0)
            if wait > 0:
                used = min(wait, budget)
                w.service_left[p.id] = wait - used
                budget -= used
                if w.service_left[p.id] > 1e-9:
                    break
                self._complete_stop(w, p)
                continue
            s = p.route[0]
            km_left = road_km(p.lat, p.lng, s.lat, s.lng)
            speed = effective_speed(p.speed_kmh, w.traffic.at(p.lat, p.lng))
            reach = speed * budget / 60.0
            if reach >= km_left:
                budget -= km_left / speed * 60.0
                self._travel(w, p, s.lat, s.lng, km_left)
                w.service_left[p.id] = SERVICE_MIN
            else:
                f = reach / km_left
                self._travel(w, p, p.lat + (s.lat - p.lat) * f, p.lng + (s.lng - p.lng) * f, reach)
                budget = 0

    def _travel(self, w: World, p: Partner, lat: float, lng: float, km: float) -> None:
        p.lat, p.lng = lat, lng
        p.distance_km += km
        p.trail = (p.trail + [(round(lat, 6), round(lng, 6))])[-TRAIL_LEN:]
        # Distance is shared between orders on board and the order the partner is heading to.
        ids = {s.order_id for s in p.route if (o := w.orders.get(s.order_id)) and o.status == "in_transit"}
        if p.route and p.route[0].order_id in w.orders:
            ids.add(p.route[0].order_id)
        for oid in ids:
            w.orders[oid].actual_km += km / len(ids)

    def _complete_stop(self, w: World, p: Partner) -> None:
        s = p.route.pop(0)
        w.service_left.pop(p.id, None)
        o = w.orders.get(s.order_id)
        if o is None:
            return
        if s.kind == "pickup":
            o.status = "in_transit"
        else:
            o.status, o.delivered_at, o.eta = "delivered", w.now, w.now
            p.completed += 1
            p.on_time += int(not o.late)

    # ------------------------------------------------------------------ live risk / ETA
    def _refresh_live(self) -> None:
        w = self.world
        for p in w.partners:
            t, (lat, lng) = w.service_left.get(p.id, 0.0), (p.lat, p.lng)
            load = p.load
            for s in p.route:
                t += travel_minutes(lat, lng, s.lat, s.lng, p.speed_kmh, w.traffic) + SERVICE_MIN
                lat, lng = s.lat, s.lng
                o = w.orders.get(s.order_id)
                if o and s.kind == "dropoff":
                    slack = o.deadline - w.now
                    cong = w.traffic.mean_along(p.lat, p.lng, s.lat, s.lng)
                    eta_rel = t - SERVICE_MIN
                    o.eta = w.now + eta_rel
                    o.delay_prob = delay_probability(eta_rel, slack, cong)
                    rb = compute_risk(cong, o.delay_prob, o.planned_km or 0, load, p.capacity)
                    o.risk, o.risk_parts = rb.score, rb.dict()
        for o in w.orders.values():
            if o.status == "pending":
                cong = w.traffic.mean_along(o.pickup_lat, o.pickup_lng, o.drop_lat, o.drop_lng)
                direct = travel_minutes(o.pickup_lat, o.pickup_lng, o.drop_lat, o.drop_lng, 24, w.traffic)
                o.eta = None
                o.delay_prob = delay_probability(direct + 10, o.deadline - w.now, cong)  # +10 min pickup allowance
                rb = compute_risk(cong, o.delay_prob, road_km(o.pickup_lat, o.pickup_lng, o.drop_lat, o.drop_lng), 0, 1)
                o.risk, o.risk_parts = rb.score, rb.dict()
        self._risk_events()

    def _risk_events(self) -> None:
        """Emit an event when an entity newly crosses a risk threshold (state transitions only)."""
        w = self.world
        now_active: set[tuple[str, str]] = set()
        events = []
        for o in w.orders.values():
            if o.status in ("assigned", "in_transit"):
                if o.delay_prob >= 0.5:
                    now_active.add(("delay", o.id))
                    if ("delay", o.id) not in w.active_events:
                        events.append(("delay", level(o.delay_prob), "order", o.id,
                                       f"{o.id} has a {o.delay_prob:.0%} probability of missing its deadline "
                                       f"(partner {o.partner_id}).",
                                       "Consider reassigning to a closer partner or notifying the customer."))
            elif o.status == "pending" and w.now > o.deadline:
                now_active.add(("deadline", o.id))
                if ("deadline", o.id) not in w.active_events:
                    events.append(("deadline", "CRITICAL", "order", o.id, f"{o.id} passed its deadline unassigned.",
                                   "Assign immediately or bring an offline partner online."))
        for p in w.partners:
            if p.online and p.load >= p.capacity:
                now_active.add(("workload", p.id))
                if ("workload", p.id) not in w.active_events:
                    events.append(("workload", "MEDIUM", "partner", p.id, f"{p.id} is at full capacity ({p.load}/{p.capacity}).",
                                   "Route new orders to partners with free capacity."))
        for cell in w.traffic.cells():
            if cell["congestion"] >= 0.8:
                now_active.add(("traffic", cell["zone"]))
                if ("traffic", cell["zone"]) not in w.active_events:
                    events.append(("traffic", "HIGH", "zone", cell["zone"],
                                   f"Zone {cell['zone']} congestion at {cell['congestion']:.0%}.",
                                   "Expect slower ETAs through this zone; risk-aware assignment will penalise it."))
        w.active_events = now_active
        if events:
            with db.SessionLocal() as s:
                s.add_all(db.RiskEvent(run_id=w.run_id, sim_time=w.now, category=c, level=lv, entity_type=et,
                                       entity_id=eid, message=m, action=a) for c, lv, et, eid, m, a in events)
                s.commit()

    # ------------------------------------------------------------------ persistence
    def kpis(self) -> dict:
        w = self.ensure()
        orders = list(w.orders.values())
        active = [o for o in orders if o.status in ("pending", "assigned", "in_transit")]
        delivered = [o for o in orders if o.status == "delivered"]
        online = [p for p in w.partners if p.online]
        with_eta = [o.eta - w.now for o in active if o.eta is not None]
        return {
            "sim_time": round(w.now, 1),
            "active_orders": len(active),
            "pending_orders": sum(o.status == "pending" for o in orders),
            "delivered_orders": len(delivered),
            "available_partners": sum(1 for p in online if p.load < p.capacity),
            "online_partners": len(online),
            "on_time_rate": round(sum(not o.late for o in delivered) / len(delivered), 4) if delivered else None,
            "avg_eta_min": round(float(np.mean(with_eta)), 2) if with_eta else None,
            "total_distance_km": round(sum(p.distance_km for p in w.partners), 2),
            "avg_risk": round(float(np.mean([o.risk for o in active])), 4) if active else 0.0,
            "utilization": round(float(np.mean([p.load / p.capacity for p in online])), 4) if online else 0.0,
            "ai_assignments": sum(1 for o in orders if o.assigned_by in ("ppo", "smartroute")),
            "traffic_mean": round(float(w.traffic.grid.mean()), 3),
        }

    def _persist_run(self) -> None:
        w = self.world
        with db.SessionLocal() as s:
            run = s.get(db.SimulationRun, w.run_id)
            run.sim_time, run.status, run.algorithm = w.now, self.status, self.cfg.algorithm
            run.traffic_level, run.order_rate = w.traffic.level, self.cfg.order_rate_per_hour
            s.commit()

    def _persist(self, full: bool = False) -> None:
        w = self.world
        with db.SessionLocal() as s:
            s.execute(delete(db.PartnerRow).where(db.PartnerRow.run_id == w.run_id))
            s.add_all(db.PartnerRow(run_id=w.run_id, id=p.id, name=p.name, lat=p.lat, lng=p.lng, capacity=p.capacity,
                                    speed_kmh=p.speed_kmh, online=p.online, completed=p.completed, on_time=p.on_time,
                                    distance_km=p.distance_km, trail=p.trail,
                                    route=[{"order_id": x.order_id, "kind": x.kind, "lat": x.lat, "lng": x.lng} for x in p.route])
                      for p in w.partners)
            existing = {r.id: r for r in s.scalars(select(db.OrderRow).where(db.OrderRow.run_id == w.run_id))}
            for o in w.orders.values():
                vals = {k: getattr(o, k) for k in (
                    "priority", "pickup_name", "drop_name", "pickup_lat", "pickup_lng", "drop_lat", "drop_lng",
                    "created_at", "deadline", "status", "partner_id", "assigned_by", "assigned_at", "planned_eta",
                    "planned_km", "planned_risk", "eta", "delivered_at", "actual_km", "risk", "delay_prob", "risk_parts")}
                row = existing.get(o.id)
                if row is None:
                    s.add(db.OrderRow(run_id=w.run_id, id=o.id, **vals))
                elif row.status != "delivered" or full:
                    for k, v in vals.items():
                        setattr(row, k, v)
            s.add(db.MetricSnapshot(run_id=w.run_id, sim_time=w.now, payload=self.kpis()))
            if full or int(w.now) % 5 == 0:
                s.add(db.TrafficSnapshot(run_id=w.run_id, sim_time=w.now, level=w.traffic.level,
                                         mean_congestion=float(w.traffic.grid.mean()),
                                         max_congestion=float(w.traffic.grid.max())))
            run = s.get(db.SimulationRun, w.run_id)
            run.sim_time, run.status = w.now, self.status
            s.commit()


simulation = Simulation()
