"""Reward functions for the dispatch MDP. Each returns named components so they can be tested
and shown in the UI. Coefficients are design choices for this simulation, not calibrated values."""
from __future__ import annotations

from ..core.candidate import Candidate
from ..core.domain import PRIORITY_WEIGHT

UNASSIGNABLE_PENALTY = -3.0


def base_components(c: Candidate, priority: str) -> dict[str, float]:
    pw = PRIORITY_WEIGHT[priority]
    late = max(0.0, c.eta_min - c.slack_min)
    return {
        "on_time": pw if c.feasible else -pw * (1.0 + min(late / 15.0, 3.0)),
        "travel_time": -c.eta_min / 30.0,
        "distance": -c.km / 10.0,
        "workload": -0.5 * (c.load_after / c.capacity) ** 2,
    }


def risk_components(c: Candidate, priority: str) -> dict[str, float]:
    return {
        "risk": -1.5 * c.risk.score,
        "cvar_tail": -0.5 * min(c.cvar_late_min / 15.0, 3.0),
        "delay_prob": -PRIORITY_WEIGHT[priority] * c.delay_prob,
    }


def reward_components(c: Candidate, priority: str, risk_aware: bool) -> dict[str, float]:
    comps = base_components(c, priority)
    if risk_aware:
        comps.update(risk_components(c, priority))
    return comps


def reward(c: Candidate, priority: str, risk_aware: bool) -> float:
    return sum(reward_components(c, priority, risk_aware).values())
