"""Assignment with trained PPO policies.

* ``ppo``        - policy trained with the base reward (time, distance, deadline, workload).
* ``smartroute`` - policy trained with the risk-aware reward (adds composite risk, delay
                   probability and a CVaR tail-lateness penalty) plus a deterministic safety
                   filter: if any eligible partner is deadline-feasible, infeasible partners are
                   masked out before the policy chooses.
Both act greedily (argmax) at inference.
"""
from __future__ import annotations

import numpy as np

from ..rl.env import features
from ..rl.ppo import Policy
from .base import run_sequential


class PolicyChooser:
    def __init__(self, policy: Policy, safety_filter: bool):
        self.policy, self.safety_filter = policy, safety_filter
        self.last_probs: list[float] | None = None
        self.upcoming = []

    def __call__(self, order, cands, elig):
        self.last_x = features(order, cands, elig, self.upcoming)
        p = self.policy.probs(self.last_x)
        if self.safety_filter:
            feasible = np.array([c.feasible for c in cands])
            if feasible.any():
                p = np.where(feasible, p, 0.0)
                p = p / p.sum()
        self.last_probs = [round(float(x), 4) for x in p]
        a = int(np.argmax(p))
        return a, float(p[a])


def assign_policy(name: str, policy: Policy, safety_filter: bool, partners, orders, now, traffic):
    return run_sequential(name, partners, orders, now, traffic, PolicyChooser(policy, safety_filter))
