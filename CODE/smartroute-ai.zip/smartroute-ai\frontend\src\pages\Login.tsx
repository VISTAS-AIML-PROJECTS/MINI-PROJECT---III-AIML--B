import { LogIn } from 'lucide-react'
import { useState, type FormEvent } from 'react'
import { Link, Navigate, useNavigate, useSearchParams } from 'react-router-dom'
import { api, ApiError, session } from '../api'
import { ErrorBanner } from '../components/ui'

export default function Login() {
  const [params] = useSearchParams()
  const nav = useNavigate()
  const next = params.get('next')?.startsWith('/app') ? params.get('next')! : '/app'
  const [user, setUser] = useState('dispatcher')
  const [pw, setPw] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<ApiError | null>(null)
  if (session.get()) return <Navigate to={next} replace />

  const submit = async (e: FormEvent) => {
    e.preventDefault()
    setBusy(true); setError(null)
    try {
      const r = await api.post<{ token: string }>('/auth/login', { username: user, password: pw })
      session.set(r.token)
      nav(next, { replace: true })
    } catch (err) {
      setError(err instanceof ApiError ? err : new ApiError(0, 'Sign-in failed.'))
    } finally {
      setBusy(false)
    }
  }
  return (
    <div style={{ minHeight: '100vh', display: 'grid', placeItems: 'center', background: 'var(--ink)', padding: 16 }}>
      <main className="card" style={{ width: '100%', maxWidth: 380, padding: 24 }}>
        <Link to="/" className="row" style={{ textDecoration: 'none', color: 'var(--text)', marginBottom: 18 }}>
          <svg width="28" height="28" viewBox="0 0 32 32" aria-hidden="true"><rect width="32" height="32" rx="8" fill="#16243f" /><path d="M8 23c4-10 12-4 16-14" stroke="#2dd4bf" strokeWidth="3" fill="none" strokeLinecap="round" /><circle cx="8" cy="23" r="3" fill="#f59e0b" /><circle cx="24" cy="9" r="3" fill="#2dd4bf" /></svg>
          <strong style={{ letterSpacing: '.05em' }}>SMARTROUTE AI</strong>
        </Link>
        <h1 style={{ fontSize: 20, marginBottom: 4 }}>Sign in</h1>
        <p className="muted" style={{ marginBottom: 16 }}>Dispatcher console access.</p>
        <form className="stack" style={{ gap: 12 }} onSubmit={submit}>
          <label className="field">Username<input className="input" autoComplete="username" value={user} onChange={e => setUser(e.target.value)} required /></label>
          <label className="field">Password<input className="input" type="password" autoComplete="current-password" value={pw} onChange={e => setPw(e.target.value)} required autoFocus /></label>
          {error && <ErrorBanner error={error} />}
          <button className="btn primary lg" type="submit" disabled={busy}><LogIn size={16} />{busy ? 'Signing in…' : 'Sign in'}</button>
        </form>
      </main>
    </div>
  )
}
