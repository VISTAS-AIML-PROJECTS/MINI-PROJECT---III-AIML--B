"""Train both PPO policies and write weights + training curves.  Usage: python -m app.rl.train_cli [iterations]"""
import json
import sys

from ..config import settings
from .ppo import TrainConfig, train


def main(iterations: int = 250) -> None:
    settings.model_dir.mkdir(parents=True, exist_ok=True)
    for name, risk_aware in (("ppo", False), ("smartroute", True)):
        cfg = TrainConfig(iterations=iterations)
        res = train(risk_aware, cfg, progress=lambda l: print(name, l.iteration, round(l.mean_episode_reward, 2), flush=True)
                    if l.iteration % 25 == 0 else None)
        res.policy.save(settings.model_dir / f"{name}.npz")
        (settings.model_dir / f"{name}_log.json").write_text(json.dumps({
            "algorithm": name, "risk_aware": risk_aware, "seconds": round(res.seconds, 1),
            "config": cfg.__dict__, "logs": [l.__dict__ for l in res.logs]}, indent=1))
        print(name, "done", round(res.seconds, 1), "s")


if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else 250)
