"""Run every algorithm on the same held-out synthetic scenarios and average the metrics."""
from __future__ import annotations

import numpy as np

from .ppo import random_env

METRIC_KEYS = ["avg_eta_min", "total_km", "expected_on_time_rate", "deadline_feasible_rate", "avg_risk",
               "avg_cvar_late_min", "workload_balance", "utilization", "assigned", "unassigned"]
DEFAULT_ALGOS = ["nearest", "hungarian", "riskaware_hungarian", "ppo", "smartroute"]


def benchmark(algorithms: list[str] | None = None, n: int = 50, seed: int = 2026) -> dict:
    """seed 12345 was used to pick SmartRoute's beta; reported numbers use a different seed."""
    from ..algorithms import registry

    algos = [a for a in (algorithms or DEFAULT_ALGOS)
             if a not in ("ppo", "smartroute") or registry.policy(a) is not None]
    rng = np.random.default_rng(seed)  # fixed seed -> identical scenarios for every algorithm
    rows = {k: [] for k in algos}
    for _ in range(n):
        env = random_env(rng, False)
        for name in algos:
            m = registry.run(name, env.fleet, env.orders, 0, env.traffic).metrics
            rows[name].append([m[k] for k in METRIC_KEYS])
    out = {}
    for name, r in rows.items():
        arr = np.asarray(r, dtype=float)
        out[name] = {k: {"mean": round(float(arr[:, i].mean()), 4),
                         "ci95": round(float(1.96 * arr[:, i].std(ddof=1) / np.sqrt(n)), 4) if n > 1 else 0.0}
                     for i, k in enumerate(METRIC_KEYS)}
    return {"scenarios": n, "seed": seed, "results": out}
