"""Explanations built only from the features the algorithm actually used.

* Reasons: factual comparisons of the chosen candidate against every eligible alternative
  (a statement is emitted only when the data supports it; trade-offs are reported too).
* Cost breakdown (Hungarian / SmartRoute): exact additive cost components, chosen vs runner-up.
* Policy attribution (PPO / SmartRoute prior): feature ablation on the trained policy - each feature
  column is replaced by its mean across candidates and the drop in the chosen partner's
  log-probability is measured. This is a local surrogate explanation, NOT SHAP.
"""
from __future__ import annotations

import numpy as np

from .algorithms.base import Decision
from .algorithms.hungarian import cost_components
from .algorithms.smartroute import POLICY_BETA, smart_components
from .core.domain import Order
from .rl.env import FEATURES
from .rl.ppo import Policy

FEATURE_LABELS = {
    "eta": "Delivery ETA", "eta_vs_best": "ETA gap to fastest", "distance": "Added distance",
    "distance_vs_best": "Distance gap to shortest", "traffic": "Traffic on route", "delay_prob": "Delay probability",
    "cvar_tail": "Tail lateness (CVaR)", "load_after": "Workload after assignment", "free_capacity": "Free capacity",
    "slack": "Time to deadline", "priority": "Order priority", "feasible": "Deadline feasible",
    "risk": "Composite risk", "risk_vs_best": "Risk gap to safest", "n_eligible": "Eligible partners",
    "demand_pressure": "Fleet demand pressure", "future_demand_near": "Upcoming demand nearby",
}


def _rank(values: list[float], v: float) -> int:
    return 1 + sum(1 for x in values if x < v - 1e-9)


def reasons(d: Decision) -> list[dict]:
    c, alts = d.chosen, d.alternatives
    n = len(alts)
    others = [a for a in alts if a.partner_id != c.partner_id]
    out: list[dict] = []

    def add(kind, feature, text):
        out.append({"kind": kind, "feature": feature, "text": text})

    if not others:
        add("info", "n_eligible", "Only one eligible partner was available.")
    eta_r = _rank([a.eta_min for a in alts], c.eta_min)
    if others:
        best_eta = min(alts, key=lambda a: a.eta_min)
        if eta_r == 1:
            add("positive", "eta", f"Fastest estimated delivery of {n} eligible partners ({c.eta_min:.0f} min).")
        else:
            add("tradeoff", "eta", f"Not the fastest: {best_eta.partner_id} could deliver "
                                   f"{c.eta_min - best_eta.eta_min:.1f} min sooner (rank {eta_r}/{n}).")
        risk_r = _rank([a.risk.score for a in alts], c.risk.score)
        if risk_r == 1:
            add("positive", "risk", f"Lowest composite risk among eligible partners ({c.risk.score:.2f}, {c.risk.level}).")
        elif c.risk.score <= float(np.median([a.risk.score for a in alts])):
            add("positive", "risk", f"Below-median risk ({c.risk.score:.2f}, rank {risk_r}/{n}).")
        else:
            add("tradeoff", "risk", f"Higher risk than {risk_r - 1} alternative(s) ({c.risk.score:.2f}).")
        km_r = _rank([a.km for a in alts], c.km)
        if km_r == 1:
            add("positive", "distance", f"Shortest added distance ({c.km:.1f} km).")
        mean_load = np.mean([a.load_after / a.capacity for a in others])
        if c.load_after / c.capacity < mean_load - 1e-9:
            add("positive", "load_after", f"Better workload balance: {c.load_after}/{c.capacity} after assignment "
                                          f"vs {mean_load:.0%} average utilisation of alternatives.")
        elif c.load_after / c.capacity > mean_load + 1e-9:
            add("tradeoff", "load_after", f"Heavier workload than average: {c.load_after}/{c.capacity} after assignment.")
        mean_cong = np.mean([a.congestion for a in others])
        if c.congestion < mean_cong - 0.02:
            add("positive", "traffic", f"Lighter traffic on route ({c.congestion:.0%} vs {mean_cong:.0%} average).")
        elif c.congestion > mean_cong + 0.02:
            add("tradeoff", "traffic", f"Heavier traffic on route ({c.congestion:.0%} vs {mean_cong:.0%} average).")
    add("positive", "free_capacity", f"Has capacity: {c.load_after}/{c.capacity} orders after assignment.")
    if c.feasible:
        add("positive", "feasible", f"Deadline feasible: ETA {c.eta_min:.0f} min vs {c.slack_min:.0f} min remaining "
                                    f"(delay probability {c.delay_prob:.0%}).")
    elif not any(a.feasible for a in alts):
        add("tradeoff", "feasible", f"No eligible partner can meet the deadline; this choice is late by "
                                    f"{c.eta_min - c.slack_min:.0f} min (expected).")
    else:
        add("tradeoff", "feasible", f"Deadline not feasible for this partner (late by {c.eta_min - c.slack_min:.0f} min) "
                                    f"although a feasible partner existed.")
    return out


def cost_breakdown(d: Decision, order: Order, algorithm: str, risk_scale: float = 1.0) -> dict | None:
    if algorithm not in ("hungarian", "smartroute", "riskaware_hungarian"):
        return None
    probs = {a.partner_id: p for a, p in zip(d.alternatives, d.probabilities or [])}

    def comps(c):
        if algorithm == "hungarian":
            return cost_components(c, order.priority)
        lp = float(np.log(probs.get(c.partner_id, 0) + 1e-9)) if probs else None
        return smart_components(c, order.priority, lp, POLICY_BETA if algorithm == "smartroute" else 0, risk_scale)

    rows = {a.partner_id: {k: round(v, 2) for k, v in comps(a).items()} for a in d.alternatives}
    totals = {k: round(sum(v.values()), 2) for k, v in rows.items()}
    others = sorted((t, pid) for pid, t in totals.items() if pid != d.partner_id)
    return {
        "basis": "Additive cost at decision time (first free slot); the matching minimises the batch total.",
        "chosen": {"partner_id": d.partner_id, "components": rows[d.partner_id], "total": totals[d.partner_id]},
        "runner_up": {"partner_id": others[0][1], "components": rows[others[0][1]], "total": others[0][0]} if others else None,
    }


def policy_attribution(d: Decision, policy: Policy | None) -> dict | None:
    if policy is None or d.policy_x is None:
        return None
    x = d.policy_x
    a = [c.partner_id for c in d.alternatives].index(d.partner_id)
    base = np.log(policy.probs(x)[a] + 1e-12)
    attrs = []
    for j, f in enumerate(FEATURES):
        xa = x.copy()
        xa[:, j] = x[:, j].mean()
        delta = base - np.log(policy.probs(xa)[a] + 1e-12)
        attrs.append({"feature": f, "label": FEATURE_LABELS[f], "value": round(float(x[a, j]), 4),
                      "impact": round(float(delta), 4)})
    attrs.sort(key=lambda r: -abs(r["impact"]))
    return {
        "method": "Surrogate feature explanation: feature ablation on the PPO policy (not SHAP)",
        "note": "impact = drop in log-probability of the chosen partner when the feature is replaced by its "
                "mean across candidates. Positive = the feature pushed the policy towards this partner.",
        "features": attrs,
    }


def explain(d: Decision, order: Order, algorithm: str, policy: Policy | None, risk_scale: float = 1.0) -> dict:
    return {
        "order_id": d.order_id,
        "partner_id": d.partner_id,
        "algorithm": algorithm,
        "confidence": d.confidence,
        "confidence_basis": None if d.confidence is None else (
            "PPO prior probability of the chosen partner (pre-matching state); the final choice is made by the "
            "risk-aware matching, so a low prior means the matching overrode the policy"
            if algorithm == "smartroute" else "policy probability of the chosen partner"),
        "decision": d.chosen.dict(),
        "reasons": reasons(d),
        "cost_breakdown": cost_breakdown(d, order, algorithm, risk_scale),
        "policy_attribution": policy_attribution(d, policy),
        "alternatives": sorted((a.dict() for a in d.alternatives), key=lambda r: r["eta_min"]),
    }
