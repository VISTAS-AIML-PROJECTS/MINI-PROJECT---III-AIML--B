"""Plain domain objects shared by the simulator, algorithms and RL environment (no DB coupling)."""
from __future__ import annotations

import copy
from dataclasses import dataclass, field

PRIORITY_WEIGHT = {"low": 0.5, "normal": 1.0, "high": 1.5, "urgent": 2.0}
PRIORITIES = list(PRIORITY_WEIGHT)


@dataclass
class Stop:
    order_id: str
    kind: str  # "pickup" | "dropoff"
    lat: float
    lng: float


@dataclass
class Order:
    id: str
    priority: str
    pickup_lat: float
    pickup_lng: float
    drop_lat: float
    drop_lng: float
    created_at: float  # simulation minutes
    deadline: float  # absolute simulation minutes
    pickup_name: str = ""
    drop_name: str = ""
    status: str = "pending"  # pending | assigned | in_transit | delivered
    partner_id: str | None = None
    assigned_by: str | None = None
    assigned_at: float | None = None
    planned_eta: float | None = None  # absolute minute the plan expects delivery
    planned_km: float | None = None
    planned_risk: float | None = None
    delivered_at: float | None = None
    actual_km: float = 0.0
    risk: float = 0.0
    delay_prob: float = 0.0
    risk_parts: dict = field(default_factory=dict)  # live RiskBreakdown components
    eta: float | None = None  # live absolute ETA

    @property
    def late(self) -> bool:
        return self.delivered_at is not None and self.delivered_at > self.deadline


@dataclass
class Partner:
    id: str
    name: str
    lat: float
    lng: float
    capacity: int
    speed_kmh: float = 24.0
    online: bool = True
    route: list[Stop] = field(default_factory=list)
    completed: int = 0
    on_time: int = 0
    distance_km: float = 0.0
    trail: list[tuple[float, float]] = field(default_factory=list)  # actual positions driven

    @property
    def load(self) -> int:
        """Orders currently held or queued (each order contributes one dropoff stop)."""
        return sum(1 for s in self.route if s.kind == "dropoff")

    @property
    def remaining_capacity(self) -> int:
        return max(0, self.capacity - self.load) if self.online else 0

    def end_position(self) -> tuple[float, float]:
        if self.route:
            return self.route[-1].lat, self.route[-1].lng
        return self.lat, self.lng

    def clone(self) -> "Partner":
        return copy.deepcopy(self)
