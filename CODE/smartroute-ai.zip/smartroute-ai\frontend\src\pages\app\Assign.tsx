import { Check, Play } from 'lucide-react'
import { useMemo, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { ALGO_COLOR, ALGO_LABEL, api, ApiError, type AlgorithmId, type AssignResponse, type Order } from '../../api'
import Decision from '../../components/Decision'
import { PageHeader } from '../../components/Layout'
import { Card, Empty, ErrorBanner, Loading, Seg, SyntheticNotice } from '../../components/ui'
import { km, mins, num, pct } from '../../format'
import { useAction, useApi, useSim } from '../../hooks'

const ALGOS: AlgorithmId[] = ['nearest', 'hungarian', 'ppo', 'smartroute']
const TRAFFIC = [
  { value: 'current', label: 'Current' }, { value: '0.3', label: 'Light' }, { value: '0.55', label: 'Normal' },
  { value: '0.8', label: 'Heavy' }, { value: '1', label: 'Gridlock' },
]
type Sens = 'low' | 'medium' | 'high'
// Metric, direction (1 = higher is better), formatter
const METRICS: [keyof AssignResponse['metrics'], string, 1 | -1, (v: number) => string][] = [
  ['avg_eta_min', 'Avg travel time', -1, v => mins(v)],
  ['total_km', 'Total distance', -1, v => km(v)],
  ['expected_on_time_rate', 'Expected on-time', 1, v => pct(v)],
  ['deadline_feasible_rate', 'Deadline feasible', 1, v => pct(v)],
  ['avg_risk', 'Avg risk', -1, v => num(v, 3)],
  ['avg_cvar_late_min', 'Tail lateness (CVaR)', -1, v => mins(v)],
  ['workload_balance', 'Workload balance (Jain)', 1, v => num(v, 3)],
  ['assigned', 'Orders assigned', 1, v => String(v)],
]

export default function Assign() {
  const { refresh } = useSim()
  const [params] = useSearchParams()
  const { data: od } = useApi<{ orders: Order[] }>('/orders')
  const pending = useMemo(() => (od?.orders ?? []).filter(o => o.base_status === 'pending'), [od])
  const [chosen, setOrder] = useState<string>(params.get('order') ?? 'all')
  // fall back to "all" once the chosen order is no longer pending
  const order = chosen === 'all' || !od || pending.some(o => o.id === chosen) ? chosen : 'all'
  const [strategy, setStrategy] = useState<'compare' | AlgorithmId>('compare')
  const [traffic, setTraffic] = useState('current')
  const [sens, setSens] = useState<Sens>('medium')
  const [results, setResults] = useState<AssignResponse[] | null>(null)
  const [skipped, setSkipped] = useState<string[]>([])
  const [focus, setFocus] = useState<AlgorithmId>('smartroute')
  const [accepted, setAccepted] = useState<string | null>(null)
  const act = useAction()


  const body = () => ({
    order_ids: order === 'all' ? undefined : [order], risk_sensitivity: sens,
    traffic_level: traffic === 'current' ? undefined : Number(traffic),
  })
  const runAll = () => act.run(strategy === 'compare' ? 'Running all 4 algorithms on the same snapshot…' : `Running ${ALGO_LABEL[strategy]}…`, async () => {
    setAccepted(null)
    const algos = strategy === 'compare' ? ALGOS : [strategy]
    const out: AssignResponse[] = []
    const skip: string[] = []
    let firstError: unknown = null
    for (const a of algos) {
      try { out.push(await api.post<AssignResponse>(`/assign/${a}`, body())) } catch (e) {
        firstError ??= e
        const err = e as ApiError
        skip.push(`${ALGO_LABEL[a]} skipped: ${err.reason ?? err.message}`)
      }
    }
    if (!out.length) throw firstError // every algorithm failed for the same reason: show it once
    setResults(out); setSkipped(skip)
    setFocus(out.some(r => r.algorithm === 'smartroute') ? 'smartroute' : out[0]?.algorithm)
  })
  const accept = (algo: AlgorithmId) => act.run(`Committing ${ALGO_LABEL[algo]} assignments…`, async () => {
    const r = await api.post<AssignResponse>(`/assign/${algo}`, { ...body(), apply: true })
    setAccepted(`${r.committed?.length ?? 0} assignment(s) committed using ${ALGO_LABEL[algo]}. The plan was recomputed on the latest state before committing.`)
    setResults(null)
    refresh()
  })

  const best = (key: keyof AssignResponse['metrics'], dir: 1 | -1) => {
    if (!results || results.length < 2) return null
    const vals = results.map(r => r.metrics[key])
    const target = dir === 1 ? Math.max(...vals) : Math.min(...vals)
    return results.filter(r => Math.abs(r.metrics[key] - target) < 1e-9).map(r => r.algorithm)
  }
  const focused = results?.find(r => r.algorithm === focus)
  const decisionFor = (r: AssignResponse) => (order === 'all' ? r.decisions[0] : r.decisions.find(d => d.order_id === order))
  const whatIf = traffic !== 'current'

  return (
    <>
      <PageHeader title="SmartRoute AI Assignment Engine" crumb="Decide" />
      <div className="content">
        <SyntheticNotice>Results are a simulation result on the current synthetic snapshot. Previews never change state until you accept.</SyntheticNotice>
        <Card title="Configure">
          <div className="grid g4" style={{ alignItems: 'end' }}>
            <label className="field">Order
              <select className="select" value={order} onChange={e => setOrder(e.target.value)}>
                <option value="all">All pending orders ({pending.length})</option>
                {pending.map(o => <option key={o.id} value={o.id}>{o.id} · {o.priority} · {o.pickup.name}</option>)}
              </select>
            </label>
            <label className="field">Assignment strategy
              <select className="select" value={strategy} onChange={e => setStrategy(e.target.value as typeof strategy)}>
                <option value="compare">Compare all four</option>
                {ALGOS.map(a => <option key={a} value={a}>{ALGO_LABEL[a]}</option>)}
              </select>
            </label>
            <div className="field">Traffic scenario<Seg label="Traffic scenario" value={traffic} options={TRAFFIC} onChange={setTraffic} /></div>
            <div className="field">Risk sensitivity (SmartRoute)<Seg<Sens> label="Risk sensitivity" value={sens} onChange={setSens}
              options={[{ value: 'low', label: 'Low ×0.5' }, { value: 'medium', label: 'Medium ×1' }, { value: 'high', label: 'High ×2' }]} /></div>
          </div>
          <div className="row" style={{ marginTop: 14 }}>
            <button className="btn primary lg" onClick={runAll} disabled={!!act.busy || pending.length === 0}><Play size={16} />{strategy === 'compare' ? 'Run all algorithms' : `Run ${ALGO_LABEL[strategy]}`}</button>
            {pending.length === 0 && od && <span className="muted">No pending orders. <Link to="/app/orders">Generate orders</Link> or run the simulation.</span>}
            {whatIf && <span className="badge b-amber">What-if traffic: results can be previewed but not committed</span>}
          </div>
        </Card>
        {act.busy && <Card><Loading label={act.busy} /></Card>}
        {act.error && <ErrorBanner error={act.error} onClose={act.clearError} />}
        {accepted && <div className="notice info" role="status"><Check size={16} />{accepted} <Link to="/app/decisions">View decisions</Link></div>}
        {skipped.map(s => <div key={s} className="notice">{s}</div>)}
        {results && !act.busy && (
          <>
            <div className="cmp">
              {results.map(r => (
                <div key={r.algorithm} className={`card ${focus === r.algorithm ? 'win' : ''}`}>
                  <div className="card-h">
                    <span style={{ width: 10, height: 10, borderRadius: 3, background: ALGO_COLOR[r.algorithm] }} />
                    <h3>{r.label}</h3>
                    <span className="right faint mono" style={{ fontSize: 11 }}>{r.runtime_ms.toFixed(0)} ms</span>
                  </div>
                  <div className="card-b stack">
                    {METRICS.map(([k, label, dir, f]) => {
                      const b = best(k, dir)
                      return (
                        <div key={k} className="row between" style={{ fontSize: 13 }}>
                          <span className="muted">{label}</span>
                          <strong style={{ color: b?.includes(r.algorithm) ? 'var(--teal)' : undefined }}>{f(r.metrics[k])}{b?.includes(r.algorithm) ? ' ★' : ''}</strong>
                        </div>
                      )
                    })}
                    <div className="row">
                      <button className="btn sm" onClick={() => setFocus(r.algorithm)} aria-pressed={focus === r.algorithm}>Explain</button>
                      <button className="btn sm primary" disabled={whatIf || !!act.busy} onClick={() => accept(r.algorithm)}><Check size={13} />Accept & assign</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <p className="faint" style={{ fontSize: 12 }}>★ best on this snapshot. One snapshot is anecdotal — see the Algorithm Center for the multi-scenario evaluation with confidence intervals.</p>
            <div className="grid g2">
              <Card title={`Decision — ${focused ? ALGO_LABEL[focused.algorithm] : ''}`} right={order === 'all' && focused && <span className="faint" style={{ fontSize: 12 }}>Showing first decision (earliest deadline); see AI Decisions for all</span>}>
                {focused && decisionFor(focused) ? <Decision e={decisionFor(focused)!} /> : <Empty title="No decision for this order" hint="The algorithm could not assign it (no eligible partner)." />}
              </Card>
              <div className="stack" style={{ gap: 16 }}>
                <Card title="Same order, different algorithms">
                  <div className="table-wrap">
                    <table className="t">
                      <thead><tr><th>Algorithm</th><th>Partner</th><th className="num">ETA</th><th className="num">Risk</th><th>Feasible</th></tr></thead>
                      <tbody>
                        {results.map(r => {
                          const d = decisionFor(r)
                          return <tr key={r.algorithm} onClick={() => setFocus(r.algorithm)}><td>{r.label}</td><td className="mono">{d?.partner_id ?? '—'}</td>
                            <td className="num">{d ? mins(d.decision.eta_min) : '—'}</td><td className="num">{d ? d.decision.risk.score.toFixed(2) : '—'}</td><td>{d ? (d.decision.feasible ? 'Yes' : 'No') : '—'}</td></tr>
                        })}
                      </tbody>
                    </table>
                  </div>
                </Card>
                {results.find(r => r.algorithm === 'hungarian')?.extras.cost_matrix && <CostMatrix r={results.find(r => r.algorithm === 'hungarian')!} />}
              </div>
            </div>
          </>
        )}
        {!results && !act.busy && <Card><Empty title="No assignment run yet" hint="Choose orders and a strategy, then run. Every algorithm is evaluated on the same snapshot." /></Card>}
      </div>
    </>
  )
}

function CostMatrix({ r }: { r: AssignResponse }) {
  const m = r.extras.cost_matrix!
  const total = r.extras.total_cost as number
  return (
    <Card title="Hungarian cost matrix" right={<span className="faint" style={{ fontSize: 12 }}>Total cost {total.toFixed(1)} · first free slot shown</span>}>
      <div className="table-wrap" style={{ maxHeight: 320 }}>
        <table className="matrix">
          <thead><tr><th>Order</th>{m.partners.map(p => <th key={p} className="mono">{p}</th>)}</tr></thead>
          <tbody>
            {m.orders.map((o, i) => (
              <tr key={o}><th className="mono">{o}</th>
                {m.values[i].map((v, j) => <td key={j} className={m.selected[o] === m.partners[j] ? 'sel' : ''}>{v.toFixed(0)}</td>)}</tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="faint" style={{ fontSize: 11.5, marginTop: 6 }}>Cost = travel time + 2×km + 30×risk + 10×workload + 3×priority-weighted lateness (minute-equivalents; configurable weights). Highlighted cells are the optimal matching.</p>
    </Card>
  )
}
