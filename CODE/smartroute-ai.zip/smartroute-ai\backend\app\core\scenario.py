"""Synthetic scenario generator (all entities are SYNTHETIC SIMULATION DATA)."""
from __future__ import annotations

import math

import numpy as np

from ..config import settings
from .domain import PRIORITIES, Order, Partner, Stop

HUBS = [
    ("Hub North", 0.55, 0.10),
    ("Hub Central", 0.0, 0.0),
    ("Hub South-East", -0.45, 0.50),
]
DEADLINE_WINDOW = {"urgent": (25, 40), "high": (35, 55), "normal": (45, 90), "low": (70, 120)}
PRIORITY_P = [0.2, 0.45, 0.25, 0.1]  # low, normal, high, urgent
DROP_RADIUS_KM = 3.5  # each hub serves its surrounding area


def _offset(lat: float, lng: float, north_km: float, east_km: float) -> tuple[float, float]:
    return lat + north_km / 111.0, lng + east_km / (111.0 * math.cos(math.radians(lat)))


def random_point(rng: np.random.Generator, radius_km: float | None = None) -> tuple[float, float]:
    r = (radius_km or settings.city_radius_km) * math.sqrt(rng.uniform(0, 1))
    a = rng.uniform(0, 2 * math.pi)
    return _offset(settings.city_lat, settings.city_lng, r * math.cos(a), r * math.sin(a))


def hub_locations() -> list[tuple[str, float, float]]:
    rad = settings.city_radius_km
    return [(name, *_offset(settings.city_lat, settings.city_lng, fy * rad, fx * rad)) for name, fy, fx in HUBS]


def make_order(rng: np.random.Generator, oid: str, now: float) -> Order:
    hub_name, plat, plng = hub_locations()[rng.integers(len(HUBS))]
    r, a = DROP_RADIUS_KM * math.sqrt(rng.uniform(0.02, 1)), rng.uniform(0, 2 * math.pi)
    dlat, dlng = _offset(plat, plng, r * math.cos(a), r * math.sin(a))
    prio = PRIORITIES[rng.choice(len(PRIORITIES), p=PRIORITY_P)]
    lo, hi = DEADLINE_WINDOW[prio]
    return Order(id=oid, priority=prio, pickup_lat=plat, pickup_lng=plng, drop_lat=dlat, drop_lng=dlng,
                 created_at=now, deadline=now + float(rng.uniform(lo, hi)), pickup_name=hub_name,
                 drop_name=f"Customer drop {oid[-3:]}")


def make_partner(rng: np.random.Generator, pid: str, preload: bool = False) -> Partner:
    lat, lng = random_point(rng)
    p = Partner(id=pid, name=f"Rider {pid}", lat=lat, lng=lng, capacity=int(rng.integers(3, 6)),
                speed_kmh=float(rng.uniform(22, 30)))
    if preload:  # existing committed work (used for RL/evaluation diversity)
        for k in range(int(rng.integers(0, 3))):
            dlat, dlng = random_point(rng)
            p.route.append(Stop(f"X{pid}{k}", "dropoff", dlat, dlng))
    return p


def generate(rng: np.random.Generator, n_partners: int, n_orders: int, now: float = 0.0,
             preload: bool = False, offline_frac: float = 0.0) -> tuple[list[Partner], list[Order]]:
    partners = [make_partner(rng, f"P{i + 1:03d}", preload) for i in range(n_partners)]
    for p in partners:
        p.online = bool(rng.uniform() >= offline_frac)
    orders = [make_order(rng, f"O{i + 101:03d}", now) for i in range(n_orders)]
    return partners, orders
