"""Baseline: give each order (earliest deadline first) to the eligible partner physically closest
to its pickup point."""
from ..core.geo import haversine_km
from .base import run_sequential


def choose_nearest(order, cands, elig):
    d = [haversine_km(p.lat, p.lng, order.pickup_lat, order.pickup_lng) for p in elig]
    return min(range(len(d)), key=d.__getitem__), None


def assign_nearest(partners, orders, now, traffic):
    return run_sequential("nearest", partners, orders, now, traffic, choose_nearest)
