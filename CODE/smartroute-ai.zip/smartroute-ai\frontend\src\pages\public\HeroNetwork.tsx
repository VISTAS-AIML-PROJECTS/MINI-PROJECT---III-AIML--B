import { useMemo, useState } from 'react'

/* Lightweight SVG illustration of warehouse -> partners -> customers. Pure SVG (no WebGL);
   motion is skipped for users who prefer reduced motion. Illustrative only, not live data. */
const W = 520, H = 380
const HUB = { x: 260, y: 190 }
const PARTNERS = [{ x: 150, y: 110 }, { x: 380, y: 95 }, { x: 410, y: 260 }, { x: 140, y: 280 }]
const CUSTOMERS = [
  [{ x: 60, y: 60 }, { x: 95, y: 170 }], [{ x: 300, y: 40 }, { x: 470, y: 60 }],
  [{ x: 480, y: 330 }, { x: 330, y: 340 }], [{ x: 60, y: 350 }, { x: 220, y: 345 }],
]
const RISK = ['#2dd4bf', '#f59e0b', '#2dd4bf', '#ef4444']

export default function HeroNetwork() {
  const reduced = useMemo(() => typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches, [])
  const [hover, setHover] = useState<number | null>(null)
  return (
    <svg viewBox={`0 0 ${W} ${H}`} width="100%" role="img" aria-label="Illustration: a hub dispatching orders to four delivery partners who deliver to customers, with one congested zone">
      <defs>
        <radialGradient id="jam"><stop offset="0" stopColor="#ef4444" stopOpacity=".35" /><stop offset="1" stopColor="#ef4444" stopOpacity="0" /></radialGradient>
        <pattern id="grid" width="26" height="26" patternUnits="userSpaceOnUse"><path d="M26 0H0V26" fill="none" stroke="#1b2b4b" strokeWidth="1" /></pattern>
      </defs>
      <rect width={W} height={H} fill="url(#grid)" rx="12" />
      <circle cx="110" cy="300" r="90" fill="url(#jam)" />
      <text x="40" y="232" fill="#fca5a5" fontSize="11" fontFamily="Inter">congested zone</text>
      {PARTNERS.map((p, i) => {
        const route = `M${HUB.x},${HUB.y} L${p.x},${p.y} ${CUSTOMERS[i].map(c => `L${c.x},${c.y}`).join(' ')}`
        const active = hover === null || hover === i
        return (
          <g key={i} opacity={active ? 1 : 0.25} onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)} style={{ cursor: 'default' }}>
            <path id={`r${i}`} d={route} fill="none" stroke={RISK[i]} strokeWidth="2.5" strokeDasharray="6 6" opacity=".75">
              {!reduced && <animate attributeName="stroke-dashoffset" from="24" to="0" dur="1.2s" repeatCount="indefinite" />}
            </path>
            {CUSTOMERS[i].map((c, j) => <circle key={j} cx={c.x} cy={c.y} r="6" fill="#0e1a31" stroke="#c9d3e6" strokeWidth="2" />)}
            <circle r="9" fill={RISK[i]} stroke="#0b1324" strokeWidth="3" cx={reduced ? p.x : undefined} cy={reduced ? p.y : undefined}>
              {!reduced && <animateMotion dur={`${6 + i}s`} repeatCount="indefinite" keyPoints="0;1;0" keyTimes="0;0.5;1" calcMode="linear"><mpath href={`#r${i}`} /></animateMotion>}
            </circle>
          </g>
        )
      })}
      <rect x={HUB.x - 20} y={HUB.y - 20} width="40" height="40" rx="8" fill="#f59e0b" stroke="#0b1324" strokeWidth="3" />
      <text x={HUB.x} y={HUB.y + 4} textAnchor="middle" fontSize="11" fontWeight="700" fill="#0b1324" fontFamily="Inter">HUB</text>
      <g fontFamily="Inter" fontSize="11">
        <rect x="12" y="12" width="210" height="58" rx="8" fill="#0b1324" stroke="#22345a" />
        <text x="24" y="32" fill="#2dd4bf" fontWeight="700">AI DECISION (illustration)</text>
        <text x="24" y="50" fill="#c9d3e6">Order → partner with lower ETA,</text>
        <text x="24" y="63" fill="#c9d3e6">lower risk, free capacity</text>
      </g>
      <g fontFamily="Inter" fontSize="10.5" fill="#9fb0d0">
        <circle cx="330" cy="368" r="4" fill="#2dd4bf" /><text x="338" y="372">low risk</text>
        <circle cx="390" cy="368" r="4" fill="#f59e0b" /><text x="398" y="372">medium</text>
        <circle cx="448" cy="368" r="4" fill="#ef4444" /><text x="456" y="372">high</text>
      </g>
    </svg>
  )
}
