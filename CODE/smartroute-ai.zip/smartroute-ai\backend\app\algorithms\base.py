"""Shared assignment framework: every algorithm is replayed through the same sequential evaluator
(orders by deadline, routes updated after each assignment) so metrics are comparable."""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Callable

import numpy as np

from ..core.candidate import Candidate, apply, eligible, evaluate
from ..core.domain import Order, Partner
from ..core.traffic import TrafficField

# chooser(order, candidates, eligible_partners) -> (index into candidates, confidence or None)
Chooser = Callable[[Order, list[Candidate], list[Partner]], tuple[int, float | None]]


@dataclass
class Decision:
    order_id: str
    partner_id: str
    chosen: Candidate
    alternatives: list[Candidate]
    confidence: float | None = None
    probabilities: list[float] | None = None
    policy_x: np.ndarray | None = None  # policy input rows (for faithful ablation explanations)


@dataclass
class AssignmentResult:
    algorithm: str
    decisions: list[Decision]
    unassigned: list[str]
    metrics: dict
    runtime_ms: float
    extras: dict = field(default_factory=dict)
    partners_after: list[Partner] = field(default_factory=list)


def ordered(orders: list[Order]) -> list[Order]:
    return sorted(orders, key=lambda o: (o.deadline, o.id))


def run_sequential(algorithm: str, partners: list[Partner], orders: list[Order], now: float,
                   traffic: TrafficField | None, chooser: Chooser) -> AssignmentResult:
    t0 = time.perf_counter()
    fleet = [p.clone() for p in partners]
    decisions, unassigned = [], []
    queue = ordered(orders)
    for n, o in enumerate(queue):
        chooser.upcoming = queue[n + 1:]  # look-ahead available to choosers that use it
        elig = eligible(fleet)
        if not elig:
            unassigned.append(o.id)
            continue
        cands = [evaluate(p, o, now, traffic) for p in elig]
        idx, conf = chooser(o, cands, elig)
        if idx is None or idx < 0:
            unassigned.append(o.id)
            continue
        probs = getattr(chooser, "last_probs", None)
        x = getattr(chooser, "last_x", None)
        decisions.append(Decision(o.id, elig[idx].id, cands[idx], cands, conf, probs, x))
        apply(elig[idx], o)
    return AssignmentResult(algorithm, decisions, unassigned, summarize(decisions, unassigned, fleet),
                            (time.perf_counter() - t0) * 1000, partners_after=fleet)


def jain(values: list[float]) -> float:
    """Jain's fairness index: 1.0 = perfectly even utilisation."""
    x = np.asarray(values, dtype=float)
    return float(x.sum() ** 2 / (len(x) * (x ** 2).sum())) if len(x) and (x ** 2).sum() > 0 else 1.0


def summarize(decisions: list[Decision], unassigned: list[str], fleet: list[Partner]) -> dict:
    online = [p for p in fleet if p.online]
    util = [p.load / p.capacity for p in online]
    c = [d.chosen for d in decisions]
    mean = lambda xs: float(np.mean(xs)) if xs else 0.0  # noqa: E731
    return {
        "assigned": len(decisions),
        "unassigned": len(unassigned),
        "avg_eta_min": round(mean([x.eta_min for x in c]), 2),
        "total_km": round(sum(x.km for x in c), 2),
        "expected_on_time_rate": round(mean([1 - x.delay_prob for x in c]), 4),
        "deadline_feasible_rate": round(mean([float(x.feasible) for x in c]), 4),
        "avg_risk": round(mean([x.risk.score for x in c]), 4),
        "avg_cvar_late_min": round(mean([x.cvar_late_min for x in c]), 2),
        "workload_balance": round(jain(util), 4),
        "utilization": round(mean(util), 4),
    }
