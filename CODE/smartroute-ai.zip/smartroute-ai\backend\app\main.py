"""FastAPI application: CORS, safe error handling, lazy simulation clock."""
import json
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from .api import ai, ops, sim
from .config import settings
from .db import SessionLocal, TrainingRun, init_db
from .services.simulation import simulation

log = logging.getLogger("smartroute")


def seed_shipped_benchmark() -> None:
    """Expose the benchmark computed with the shipped weights until the user runs a new evaluation."""
    path = settings.model_dir / "benchmark.json"
    with SessionLocal() as s:
        if path.exists() and not s.query(TrainingRun).filter_by(kind="evaluate").first():
            res = json.loads(path.read_text())
            s.add(TrainingRun(kind="evaluate", algorithm="all", status="done", result=res,
                              config={"scenarios": res["scenarios"], "seed": res["seed"], "source": "shipped weights"}))
            s.commit()


@asynccontextmanager
async def lifespan(_: FastAPI):
    init_db()
    seed_shipped_benchmark()
    simulation.ensure()
    yield


app = FastAPI(title="SmartRoute AI API", version="1.0.0", lifespan=lifespan)
@app.middleware("http")
async def advance_clock(request: Request, call_next):
    if request.url.path.startswith("/api/"):
        simulation.catch_up()
    return await call_next(request)


app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origins, allow_methods=["GET", "POST", "PUT", "PATCH"],
                   allow_headers=["Content-Type", "Authorization"])


@app.exception_handler(StarletteHTTPException)
async def http_error(_: Request, exc: StarletteHTTPException):
    detail = exc.detail if isinstance(exc.detail, dict) else {"message": str(exc.detail)}
    return JSONResponse(status_code=exc.status_code, content={"error": detail})


@app.exception_handler(RequestValidationError)
async def validation_error(_: Request, exc: RequestValidationError):
    problems = [f"{'.'.join(str(x) for x in e['loc'][1:])}: {e['msg']}" for e in exc.errors()]
    return JSONResponse(status_code=422, content={"error": {"message": "Invalid request.", "reason": "; ".join(problems)}})


@app.exception_handler(Exception)
async def unhandled(_: Request, exc: Exception):
    log.exception("unhandled error", exc_info=exc)  # stack trace stays in the server log
    return JSONResponse(status_code=500, content={"error": {"message": "Something went wrong on the server.",
                                                            "reason": "An unexpected error occurred.",
                                                            "action": "Retry, or reset the simulation."}})


for r in (ops.public, ops.router, ai.router, sim.router):
    app.include_router(r)

# Production: serve the built React app from the same origin (single deployable service).
if settings.frontend_dist.is_dir():
    from fastapi.responses import FileResponse
    from fastapi.staticfiles import StaticFiles

    _dist = settings.frontend_dist.resolve()
    app.mount("/assets", StaticFiles(directory=_dist / "assets"), name="assets")

    @app.get("/{path:path}", include_in_schema=False)
    async def spa(path: str):
        if path.startswith("api/"):
            raise StarletteHTTPException(404, detail="Not found")
        f = (_dist / path).resolve()
        if path and f.is_file() and f.is_relative_to(_dist):  # blocks ../ traversal
            return FileResponse(f)
        return FileResponse(_dist / "index.html")
