"""Runtime configuration. Everything overridable via environment variables (SMARTROUTE_*)."""
import os
from dataclasses import dataclass, field
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent


def _env(name: str, default: str) -> str:
    return os.environ.get(f"SMARTROUTE_{name}", default)


@dataclass
class RiskWeights:
    """Weights of the composite risk score. Configurable, not empirically derived."""
    traffic: float = 0.25
    delay: float = 0.40
    distance: float = 0.15
    workload: float = 0.20


@dataclass
class Settings:
    database_url: str = _env("DATABASE_URL", f"sqlite:///{BASE_DIR / 'data' / 'smartroute.db'}")
    cors_origins: list[str] = field(
        default_factory=lambda: _env("CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173").split(",")
    )
    model_dir: Path = Path(_env("MODEL_DIR", str(BASE_DIR / "app" / "rl" / "weights")))
    seed: int = int(_env("SEED", "42"))
    # Synthetic city centre (Bengaluru-like coordinates; all data is synthetic).
    city_lat: float = 12.9716
    city_lng: float = 77.5946
    city_radius_km: float = 4.5
    risk_weights: RiskWeights = field(default_factory=RiskWeights)
    demo_user: str = _env("DEMO_USER", "dispatcher")
    demo_password: str = _env("DEMO_PASSWORD", "")
    secret_key: str = _env("SECRET_KEY", "")
    frontend_dist: Path = Path(_env("FRONTEND_DIST", str(BASE_DIR.parent / "frontend" / "dist")))


settings = Settings()
