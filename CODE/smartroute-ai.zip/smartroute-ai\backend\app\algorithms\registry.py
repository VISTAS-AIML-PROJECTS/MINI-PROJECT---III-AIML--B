"""Single entry point for running any implemented assignment algorithm."""
from __future__ import annotations

from ..config import settings
from ..rl.ppo import Policy
from .hungarian import assign_hungarian
from .learned import assign_policy
from .nearest import assign_nearest
from .smartroute import assign_smartroute

ALGORITHMS = {
    "nearest": "Nearest Partner",
    "hungarian": "Hungarian Algorithm",
    "ppo": "PPO (base reward)",
    "smartroute": "SmartRoute AI (risk-aware PPO + CVaR matching)",
}

_policies: dict[str, Policy | None] = {}


def policy(name: str) -> Policy | None:
    """Lazy-load trained weights; None if the model has not been trained yet."""
    if name not in _policies:
        path = settings.model_dir / f"{name}.npz"
        _policies[name] = Policy.load(path) if path.exists() else None
    return _policies[name]


def reload_policies() -> None:
    _policies.clear()


class ModelNotTrained(RuntimeError):
    pass


def run(name: str, partners, orders, now, traffic, risk_scale: float = 1.0):
    if name == "nearest":
        return assign_nearest(partners, orders, now, traffic)
    if name == "hungarian":
        return assign_hungarian(partners, orders, now, traffic)
    if name == "riskaware_hungarian":  # ablation: SmartRoute without the learned prior
        return assign_smartroute(partners, orders, now, traffic, None, name="riskaware_hungarian", risk_scale=risk_scale)
    pol = policy(name)
    if pol is None:
        raise ModelNotTrained(f"The {ALGORITHMS.get(name, name)} model has not been trained yet.")
    if name == "ppo":
        return assign_policy("ppo", pol, False, partners, orders, now, traffic)
    if name == "smartroute":
        return assign_smartroute(partners, orders, now, traffic, pol, risk_scale=risk_scale)
    raise KeyError(name)
