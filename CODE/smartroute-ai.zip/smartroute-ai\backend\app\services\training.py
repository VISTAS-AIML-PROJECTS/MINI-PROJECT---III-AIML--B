"""Background training / evaluation jobs (one at a time), recorded in the training_runs table."""
from __future__ import annotations

import json
import threading
import time

from .. import db
from ..algorithms import registry
from ..config import settings
from ..rl.benchmark import benchmark
from ..rl.ppo import TrainConfig, train

_lock = threading.Lock()
state: dict = {"busy": False, "job": None, "progress": None, "error": None}


class Busy(RuntimeError):
    pass


def _start(job: str, target) -> int:
    if not _lock.acquire(blocking=False):
        raise Busy("Another training or evaluation job is already running.")
    with db.SessionLocal() as s:
        row = db.TrainingRun(kind=job.split(":")[0], algorithm=job.split(":")[1], status="running")
        s.add(row)
        s.commit()
        run_id = row.id
    state.update(busy=True, job=job, progress=None, error=None, run_id=run_id)

    def wrapper():
        t0 = time.perf_counter()
        try:
            result, config = target()
            status = "done"
        except Exception as e:  # recorded for the UI; never re-raised into the server
            result, config, status = {}, {}, "failed"
            state["error"] = "The job failed. Check the server log for details."
            import logging
            logging.getLogger("smartroute").exception("job %s failed: %s", job, e)
        with db.SessionLocal() as s:
            row = s.get(db.TrainingRun, run_id)
            row.status, row.seconds, row.result, row.config = status, round(time.perf_counter() - t0, 1), result, config
            s.commit()
        state.update(busy=False)
        _lock.release()

    threading.Thread(target=wrapper, daemon=True).start()
    return run_id


def start_training(algorithm: str, iterations: int) -> int:
    def target():
        cfg = TrainConfig(iterations=iterations)
        res = train(algorithm == "smartroute", cfg,
                    progress=lambda l: state.update(progress={"iteration": l.iteration, "of": iterations,
                                                              "mean_episode_reward": round(l.mean_episode_reward, 3)}))
        settings.model_dir.mkdir(parents=True, exist_ok=True)
        res.policy.save(settings.model_dir / f"{algorithm}.npz")
        logs = [l.__dict__ for l in res.logs]
        (settings.model_dir / f"{algorithm}_log.json").write_text(json.dumps(
            {"algorithm": algorithm, "risk_aware": algorithm == "smartroute", "seconds": round(res.seconds, 1),
             "config": cfg.__dict__, "logs": logs}, indent=1))
        registry.reload_policies()
        return {"logs": logs}, cfg.__dict__

    return _start(f"train:{algorithm}", target)


def start_evaluation(scenarios: int, seed: int) -> int:
    def target():
        state["progress"] = {"scenarios": scenarios}
        return benchmark(n=scenarios, seed=seed), {"scenarios": scenarios, "seed": seed}

    return _start("evaluate:all", target)


def shipped_training_logs() -> list[dict]:
    out = []
    for name in ("ppo", "smartroute"):
        p = settings.model_dir / f"{name}_log.json"
        if p.exists():
            out.append(json.loads(p.read_text()))
    return out
