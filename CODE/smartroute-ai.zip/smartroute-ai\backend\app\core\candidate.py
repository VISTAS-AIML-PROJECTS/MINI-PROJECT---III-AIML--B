"""Evaluate assigning one order to one partner: the shared feature set every algorithm,
the RL state and the explainer are built from."""
from __future__ import annotations

from dataclasses import dataclass

from .domain import Order, Partner, Stop
from .geo import SERVICE_MIN, road_km, route_minutes, travel_minutes
from .risk import RiskBreakdown, compute_risk, cvar_lateness, delay_probability
from .traffic import TrafficField


@dataclass
class Candidate:
    order_id: str
    partner_id: str
    eta_min: float  # minutes from now until the order would be delivered
    pickup_min: float  # minutes from now until pickup
    km: float  # marginal road km this order adds to the partner's route
    congestion: float
    slack_min: float  # minutes from now until the deadline
    delay_prob: float
    cvar_late_min: float
    load_after: int
    capacity: int
    risk: RiskBreakdown

    @property
    def feasible(self) -> bool:
        return self.eta_min <= self.slack_min

    def dict(self) -> dict:
        return {
            "order_id": self.order_id, "partner_id": self.partner_id,
            "eta_min": round(self.eta_min, 2), "pickup_min": round(self.pickup_min, 2),
            "km": round(self.km, 3), "congestion": round(self.congestion, 3),
            "slack_min": round(self.slack_min, 2), "delay_prob": round(self.delay_prob, 4),
            "cvar_late_min": round(self.cvar_late_min, 2), "load_after": self.load_after,
            "capacity": self.capacity, "feasible": self.feasible, "risk": self.risk.dict(),
        }


def evaluate(partner: Partner, order: Order, now: float, traffic: TrafficField | None,
             extra_queue_min: float = 0.0) -> Candidate:
    queue_min, _ = route_minutes(partner, traffic)
    elat, elng = partner.end_position()
    km1 = road_km(elat, elng, order.pickup_lat, order.pickup_lng)
    km2 = road_km(order.pickup_lat, order.pickup_lng, order.drop_lat, order.drop_lng)
    to_pick = travel_minutes(elat, elng, order.pickup_lat, order.pickup_lng, partner.speed_kmh, traffic)
    deliver = travel_minutes(order.pickup_lat, order.pickup_lng, order.drop_lat, order.drop_lng, partner.speed_kmh, traffic)
    if traffic:
        c1 = traffic.mean_along(elat, elng, order.pickup_lat, order.pickup_lng)
        c2 = traffic.mean_along(order.pickup_lat, order.pickup_lng, order.drop_lat, order.drop_lng)
        cong = (c1 * km1 + c2 * km2) / (km1 + km2) if km1 + km2 > 0 else c2
    else:
        cong = 0.0
    pickup_min = queue_min + extra_queue_min + to_pick
    eta = pickup_min + SERVICE_MIN + deliver
    slack = order.deadline - now
    dp = delay_probability(eta, slack, cong)
    load_after = partner.load + 1
    return Candidate(
        order_id=order.id, partner_id=partner.id, eta_min=eta, pickup_min=pickup_min, km=km1 + km2,
        congestion=cong, slack_min=slack, delay_prob=dp, cvar_late_min=cvar_lateness(eta, slack, cong),
        load_after=load_after, capacity=partner.capacity,
        risk=compute_risk(cong, dp, km1 + km2, load_after, partner.capacity),
    )


def eligible(partners: list[Partner]) -> list[Partner]:
    return [p for p in partners if p.online and p.remaining_capacity > 0]


def apply(partner: Partner, order: Order) -> None:
    """Append the order's pickup and dropoff to the partner's route."""
    partner.route.append(Stop(order.id, "pickup", order.pickup_lat, order.pickup_lng))
    partner.route.append(Stop(order.id, "dropoff", order.drop_lat, order.drop_lng))
