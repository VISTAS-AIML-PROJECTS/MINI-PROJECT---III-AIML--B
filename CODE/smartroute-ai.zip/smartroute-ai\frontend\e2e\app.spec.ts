import { expect, test as base, type APIRequestContext, type Page } from '@playwright/test'
import { E2E_PASSWORD } from '../playwright.config'

let TOKEN = ''
/** Every page starts signed in; every API helper call carries the bearer token. */
const test = base.extend({
  page: async ({ page }, use) => {
    await page.addInitScript(t => sessionStorage.setItem('smartroute.token', t), TOKEN)
    await use(page)
  },
  request: async ({ playwright }, use) => {
    const ctx = await playwright.request.newContext({ baseURL: 'http://127.0.0.1:5173', extraHTTPHeaders: { Authorization: `Bearer ${TOKEN}` } })
    await use(ctx)
    await ctx.dispose()
  },
})

const APP_ROUTES = ['/app', '/app/map', '/app/orders', '/app/partners', '/app/assign', '/app/decisions', '/app/algorithms',
  '/app/risk', '/app/simulation', '/app/analytics', '/app/reports', '/app/settings', '/app/demo']
const SITE_ROUTES = ['/', '/product', '/how-it-works', '/technology', '/ai', '/about', '/login']
const WIDTHS = [320, 375, 390, 414, 768, 1024, 1280, 1440]

/** Collect console errors, page errors and failed API calls for the whole test. */
function watch(page: Page) {
  const problems: string[] = []
  page.on('console', m => { if (m.type() === 'error') problems.push(`console: ${m.text()}`) })
  page.on('pageerror', e => problems.push(`pageerror: ${e.message}`))
  page.on('response', r => { if (r.url().includes('/api/') && r.status() >= 500) problems.push(`api ${r.status()} ${r.url()}`) })
  page.on('requestfailed', r => {
    const err = r.failure()?.errorText ?? ''
    if (!err.includes('ERR_ABORTED')) problems.push(`requestfailed ${r.url()} ${err}`)
  })
  return problems
}

const reset = (request: APIRequestContext, n_partners = 12, initial_orders = 14, seed = 42) =>
  request.post('/api/simulation/reset', { data: { n_partners, initial_orders, seed } })

base.beforeAll(async ({ playwright }) => {
  const ctx = await playwright.request.newContext({ baseURL: 'http://127.0.0.1:5173' })
  const r = await ctx.post('/api/auth/login', { data: { username: 'dispatcher', password: E2E_PASSWORD } })
  expect(r.ok(), 'E2E login failed: start the backend with SMARTROUTE_DEMO_PASSWORD matching the tests').toBeTruthy()
  TOKEN = (await r.json()).token
  await reset(await playwright.request.newContext({ baseURL: 'http://127.0.0.1:5173', extraHTTPHeaders: { Authorization: `Bearer ${TOKEN}` } }))
})

base('sign-in flow guards the console', async ({ page }) => {
  await page.goto('/app/orders')
  await expect(page).toHaveURL(/\/login\?next=%2Fapp%2Forders/)
  await page.getByLabel('Password').fill('definitely-wrong')
  await page.getByRole('button', { name: 'Sign in' }).click()
  await expect(page.getByText('Incorrect username or password.')).toBeVisible()
  await page.getByLabel('Password').fill(E2E_PASSWORD)
  await page.getByRole('button', { name: 'Sign in' }).click()
  await expect(page.getByRole('heading', { name: 'Orders', level: 1 })).toBeVisible()
  await page.getByRole('button', { name: 'Sign out' }).click()
  await expect(page).toHaveURL(/\/login/)
})

test('core flow: generate → assign → explanation → map → analytics', async ({ page }) => {
  const problems = watch(page)
  await page.goto('/')
  await expect(page.getByRole('heading', { name: 'SMARTROUTE AI', level: 1 })).toBeVisible()
  await page.getByRole('link', { name: 'Explore Dashboard' }).click()
  await expect(page.getByRole('heading', { name: 'Operations Dashboard' })).toBeVisible()
  await expect(page.getByText('Active Orders').first()).toBeVisible()

  await page.goto('/app/orders')
  await expect(page.locator('table.t tbody tr').first()).toBeVisible()
  const before = await page.locator('table.t tbody tr').count()
  await page.getByRole('button', { name: 'Generate orders' }).click()
  await expect(page.locator('table.t tbody tr')).toHaveCount(before + 5)

  await page.goto('/app/assign')
  await page.getByRole('button', { name: 'Run all algorithms' }).click()
  for (const label of ['Nearest Partner', 'Hungarian Algorithm', 'PPO (base reward)', 'SmartRoute AI (risk-aware PPO + CVaR matching)']) {
    await expect(page.getByRole('heading', { name: label })).toBeVisible()
  }
  await expect(page.getByText('WHY THIS PARTNER?')).toBeVisible()
  await expect(page.getByText('Surrogate feature explanation', { exact: false }).first()).toBeVisible()
  await expect(page.getByText('Hungarian cost matrix')).toBeVisible()
  await page.locator('.cmp .card').last().getByRole('button', { name: 'Accept & assign' }).click()
  await expect(page.getByText(/assignment\(s\) committed using SmartRoute AI/)).toBeVisible()

  await page.getByRole('link', { name: 'View decisions' }).click()
  await expect(page.getByRole('heading', { name: 'AI Decisions' })).toBeVisible()
  await expect(page.getByText('WHY THIS PARTNER?')).toBeVisible()
  await expect(page.getByText('Learned prior (PPO probability)')).toBeVisible()

  await page.goto('/app/map')
  await expect(page.locator('.leaflet-container')).toBeVisible()
  await page.getByRole('tab', { name: /Partners/ }).click()
  await page.locator('.list-item').first().click()
  await expect(page.getByRole('heading', { name: 'Partner details' })).toBeVisible()

  await page.goto('/app/analytics')
  await expect(page.getByRole('heading', { name: 'Operational KPIs' })).toBeVisible()
  await expect(page.getByText('Planned vs actual delivery time')).toBeVisible()
  expect(problems).toEqual([])
})

test('simulation runs on the backend and the clock advances', async ({ page, request }) => {
  const problems = watch(page)
  const simTime = async () => (await (await request.get('/api/simulation/status')).json()).sim_time as number
  await page.goto('/app/simulation')
  const t0 = await simTime()
  await page.getByRole('button', { name: 'Step 5 min' }).click()
  await expect.poll(simTime).toBeGreaterThan(t0)
  await page.getByRole('button', { name: /^(Start|Resume)$/ }).click()
  await expect(page.locator('.status-pill.running')).toBeVisible()
  const t1 = await simTime()
  await expect.poll(simTime, { timeout: 8000 }).toBeGreaterThan(t1)
  await page.locator('.card').getByRole('button', { name: 'Pause' }).click()
  await expect(page.locator('.status-pill.paused')).toBeVisible()
  expect(problems).toEqual([])
})

test('smart demo completes every stage with real API calls', async ({ page }) => {
  const problems = watch(page)
  await page.goto('/app/demo')
  await page.getByRole('button', { name: 'Start Smart Demo' }).click()
  await expect(page.locator('.pipe-step.done')).toHaveCount(10, { timeout: 60_000 })
  await expect(page.getByText('Generated explanation')).toBeVisible()
  await expect(page.getByText('Same orders, three algorithms')).toBeVisible()
  expect(problems).toEqual([])
})

test('reports generate from stored results', async ({ page }) => {
  const problems = watch(page)
  await page.goto('/app/reports')
  await page.getByRole('button', { name: 'Generate report' }).click()
  await expect(page.getByText('Workload distribution')).toBeVisible()
  await expect(page.getByText('Synthetic Simulation Data', { exact: false }).first()).toBeVisible()
  expect(problems).toEqual([])
})

test('errors are explained, not raw codes', async ({ page, request }) => {
  await reset(request, 1, 3, 3) // the only partner is off-shift
  await page.goto('/app/assign')
  await page.getByRole('button', { name: 'Run all algorithms' }).click()
  const alert = page.getByRole('alert').filter({ hasText: 'Unable to calculate assignment.' })
  await expect(alert).toHaveCount(1)
  await expect(alert).toContainText('No delivery partners are currently available.')
  await expect(alert).toContainText('Bring a partner online or reset the simulation.')
  await reset(request)
})

for (const width of WIDTHS) {
  test(`all routes render without errors or overflow at ${width}px`, async ({ page }) => {
    const problems = watch(page)
    await page.setViewportSize({ width, height: 900 })
    for (const route of [...SITE_ROUTES, ...APP_ROUTES]) {
      await page.goto(route)
      await expect(page.locator('h1').first()).toBeVisible()
      await page.waitForLoadState('networkidle')
      const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth)
      expect(overflow, `${route} horizontal overflow at ${width}px`).toBeLessThanOrEqual(0)
      if (width === 390 || width === 1440) {
        await page.screenshot({ path: `test-results/shots/${width}${route === '/' ? '_home' : route.replace(/\//g, '_')}.png` })
      }
    }
    expect(problems).toEqual([])
  })
}
