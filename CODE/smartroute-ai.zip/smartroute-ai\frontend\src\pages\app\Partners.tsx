import { Power } from 'lucide-react'
import { useMemo, useState } from 'react'
import { api, type Order, type Partner } from '../../api'
import { PageHeader } from '../../components/Layout'
import { PartnerDetail } from '../../components/OpsView'
import { Bar, Card, DataTable, ErrorBanner, ErrorState, Loading, RiskBadge, StatusBadge, SyntheticNotice, type Column } from '../../components/ui'
import { km, mins, pct, title } from '../../format'
import { useAction, useApi, useSim } from '../../hooks'

const STATUSES = ['available', 'busy', 'at_capacity', 'offline', 'at_risk']

export default function Partners() {
  const { refresh } = useSim()
  const { data, error, loading } = useApi<{ partners: Partner[] }>('/partners')
  const { data: od } = useApi<{ orders: Order[] }>('/orders')
  const act = useAction()
  const [status, setStatus] = useState('')
  const [sel, setSel] = useState<string | null>(null)
  const rows = useMemo(() => (data?.partners ?? []).filter(p => !status || p.status === status), [data, status])
  const toggle = (p: Partner) => act.run('Updating partner…', async () => { await api.patch(`/partners/${p.id}`, { online: !p.online }); refresh() })

  const cols: Column<Partner>[] = [
    { key: 'id', label: 'Partner ID', render: p => <span className="mono">{p.id}</span>, sort: p => p.id },
    { key: 'status', label: 'Status', render: p => <StatusBadge status={p.status} />, sort: p => STATUSES.indexOf(p.status) },
    { key: 'cap', label: 'Capacity', render: p => p.capacity, sort: p => p.capacity, num: true },
    { key: 'load', label: 'Workload', render: p => `${p.load}/${p.capacity}`, sort: p => p.load, num: true },
    { key: 'util', label: 'Utilization', render: p => <div style={{ width: 90 }}><Bar value={p.utilization} /></div>, sort: p => p.utilization },
    { key: 'loc', label: 'Location', render: p => <span className="mono faint">{p.lat.toFixed(3)}, {p.lng.toFixed(3)}</span> },
    { key: 'active', label: 'Active orders', render: p => <span className="mono">{p.active_orders.join(', ') || '—'}</span>, sort: p => p.active_orders.length },
    { key: 'eta', label: 'Avg ETA', render: p => mins(p.avg_eta_min), sort: p => p.avg_eta_min ?? 1e9, num: true },
    { key: 'ontime', label: 'On-time', render: p => pct(p.on_time_rate), sort: p => p.on_time_rate ?? -1, num: true },
    { key: 'risk', label: 'Risk', render: p => <RiskBadge level={p.risk_level} score={p.risk} />, sort: p => p.risk },
    { key: 'act', label: '', render: p => (
      <button className="btn sm" onClick={e => { e.stopPropagation(); toggle(p) }} disabled={!!act.busy} aria-label={`${p.online ? 'Take offline' : 'Bring online'} ${p.id}`}>
        <Power size={13} />{p.online ? 'Set offline' : 'Set online'}</button>) },
  ]
  const selected = data?.partners.find(p => p.id === sel)
  return (
    <>
      <PageHeader title="Delivery Partners" crumb="Operate" />
      <div className="content">
        <SyntheticNotice>Partners are simulated riders with synthetic capacities and speeds.</SyntheticNotice>
        {act.error && <ErrorBanner error={act.error} onClose={act.clearError} />}
        <div className="row" role="group" aria-label="Status filters">
          <button className={`btn sm ${status === '' ? 'dark' : ''}`} onClick={() => setStatus('')}>All {data?.partners.length ?? ''}</button>
          {STATUSES.map(s => <button key={s} className={`btn sm ${status === s ? 'dark' : ''}`} aria-pressed={status === s} onClick={() => setStatus(status === s ? '' : s)}>
            {title(s).toUpperCase()} {(data?.partners ?? []).filter(p => p.status === s).length}</button>)}
        </div>
        <div className={selected ? 'grid with-side' : ''}>
          <Card title="Fleet" flush>
            {error ? <ErrorState error={error} /> : loading ? <Loading label="Loading partners…" /> : (
              <DataTable caption="Delivery partners" rows={rows} columns={cols} rowKey={p => p.id} selected={sel} onRow={p => setSel(p.id)}
                mobile={p => (<>
                  <div className="row between"><strong className="mono">{p.id}</strong><StatusBadge status={p.status} /></div>
                  <Bar value={p.utilization} />
                  <div className="faint" style={{ fontSize: 12 }}>{p.load}/{p.capacity} orders · on-time {pct(p.on_time_rate)} · {km(p.distance_km)} driven</div>
                </>)} />
            )}
          </Card>
          {selected && (
            <Card title="Partner details" right={<button className="btn sm ghost" onClick={() => setSel(null)} aria-label="Close details">✕</button>}>
              <PartnerDetail p={selected} orders={od?.orders ?? []} />
              <button className="btn" style={{ marginTop: 12 }} onClick={() => toggle(selected)} disabled={!!act.busy}><Power size={14} />{selected.online ? 'Set offline' : 'Set online'}</button>
            </Card>
          )}
        </div>
      </div>
    </>
  )
}
