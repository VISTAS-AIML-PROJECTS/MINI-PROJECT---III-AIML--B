import { lazy, Suspense, type ReactNode } from 'react'
import { BrowserRouter, Link, Navigate, Route, Routes, useLocation } from 'react-router-dom'
import { session } from './api'
import Layout from './components/Layout'
import { Loading } from './components/ui'
import { SimProvider } from './hooks'
import Home, { About, AIIntelligence, HowItWorks, Problem, Product, SiteLayout, Solution, Technology } from './pages/public/Site'

// App pages are code-split: the public site never downloads map/chart bundles.
const Dashboard = lazy(() => import('./pages/app/Dashboard'))
const LiveMap = lazy(() => import('./pages/app/LiveMap'))
const Orders = lazy(() => import('./pages/app/Orders'))
const Partners = lazy(() => import('./pages/app/Partners'))
const Assign = lazy(() => import('./pages/app/Assign'))
const Decisions = lazy(() => import('./pages/app/Decisions'))
const Algorithms = lazy(() => import('./pages/app/Algorithms'))
const Risk = lazy(() => import('./pages/app/Risk'))
const Simulation = lazy(() => import('./pages/app/Simulation'))
const Analytics = lazy(() => import('./pages/app/Analytics'))
const Reports = lazy(() => import('./pages/app/Reports'))
const Settings = lazy(() => import('./pages/app/Settings'))
const Demo = lazy(() => import('./pages/app/Demo'))
const Login = lazy(() => import('./pages/Login'))

function RequireAuth({ children }: { children: ReactNode }) {
  const loc = useLocation()
  return session.get() ? <>{children}</> : <Navigate to={`/login?next=${encodeURIComponent(loc.pathname + loc.search)}`} replace />
}

const S = ({ children }: { children: ReactNode }) => <Suspense fallback={<div className="content"><Loading /></div>}>{children}</Suspense>

function NotFound() {
  return (
    <div className="state" style={{ minHeight: '60vh' }}>
      <h3>Page not found</h3><p>The page you requested does not exist.</p>
      <Link className="btn primary" to="/">Go to home</Link>
    </div>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<SiteLayout />}>
          <Route index element={<Home />} />
          <Route path="product" element={<><Product h1 /><Problem /><Solution /></>} />
          <Route path="how-it-works" element={<HowItWorks h1 />} />
          <Route path="technology" element={<Technology h1 />} />
          <Route path="ai" element={<AIIntelligence h1 />} />
          <Route path="about" element={<About h1 />} />
        </Route>
        <Route path="login" element={<S><Login /></S>} />
        <Route path="app" element={<RequireAuth><SimProvider><Layout /></SimProvider></RequireAuth>}>
          <Route index element={<S><Dashboard /></S>} />
          <Route path="map" element={<S><LiveMap /></S>} />
          <Route path="orders" element={<S><Orders /></S>} />
          <Route path="partners" element={<S><Partners /></S>} />
          <Route path="assign" element={<S><Assign /></S>} />
          <Route path="decisions" element={<S><Decisions /></S>} />
          <Route path="algorithms" element={<S><Algorithms /></S>} />
          <Route path="risk" element={<S><Risk /></S>} />
          <Route path="simulation" element={<S><Simulation /></S>} />
          <Route path="analytics" element={<S><Analytics /></S>} />
          <Route path="reports" element={<S><Reports /></S>} />
          <Route path="settings" element={<S><Settings /></S>} />
          <Route path="demo" element={<S><Demo /></S>} />
          <Route path="*" element={<NotFound />} />
        </Route>
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  )
}
