export const pct = (v: number | null | undefined, d = 0) => (v == null ? '—' : `${(v * 100).toFixed(d)}%`)
export const num = (v: number | null | undefined, d = 1) => (v == null ? '—' : v.toFixed(d))
export const mins = (v: number | null | undefined) => (v == null ? '—' : `${v.toFixed(v < 10 ? 1 : 0)} min`)
export const km = (v: number | null | undefined) => (v == null ? '—' : `${v.toFixed(1)} km`)
/** Simulated clock: simulation starts at 09:00 on a synthetic day. */
export const clock = (simMin: number) => {
  const t = 9 * 60 + simMin
  const h = Math.floor(t / 60) % 24
  const m = Math.floor(t % 60)
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`
}
export const title = (s: string) => s.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())
export const riskColor = (score: number) =>
  score < 0.25 ? '#15803d' : score < 0.5 ? '#d97706' : score < 0.75 ? '#ea580c' : '#dc2626'
export const congestionColor = (c: number) =>
  c < 0.35 ? '#22c55e' : c < 0.55 ? '#eab308' : c < 0.75 ? '#f97316' : '#dc2626'
