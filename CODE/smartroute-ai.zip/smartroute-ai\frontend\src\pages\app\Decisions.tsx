import { useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { ALGO_LABEL, type Assignment, type Explanation } from '../../api'
import Decision from '../../components/Decision'
import { PageHeader } from '../../components/Layout'
import { Card, Empty, ErrorState, Loading, RiskBadge, SyntheticNotice } from '../../components/ui'
import { clock, mins, pct } from '../../format'
import { useApi } from '../../hooks'

export default function Decisions() {
  const [params] = useSearchParams()
  const [algo, setAlgo] = useState('')
  const [q, setQ] = useState(params.get('order') ?? '')
  const { data, error, loading } = useApi<{ assignments: Assignment[] }>(`/assignments?limit=300${algo ? `&algorithm=${algo}` : ''}`)
  const rows = useMemo(() => (data?.assignments ?? []).filter(a => !q || a.order_id.includes(q.toUpperCase()) || a.partner_id.includes(q.toUpperCase())), [data, q])
  const [picked, setSel] = useState<number | null>(null)
  const sel = rows.some(r => r.id === picked) ? picked : rows[0]?.id ?? null
  const exp = useApi<Explanation>(sel != null ? `/assignments/${sel}/explanation` : null)

  return (
    <>
      <PageHeader title="AI Decisions" crumb="Decide" />
      <div className="content">
        <SyntheticNotice>Every decision below was produced by an implemented algorithm and stored with the exact features it used.</SyntheticNotice>
        <div className="grid split">
          <Card title="Decision log" flush right={
            <div className="row">
              <label><span className="sr-only">Search</span><input className="input" style={{ width: 120 }} placeholder="O104 / P007" value={q} onChange={e => setQ(e.target.value)} /></label>
              <label><span className="sr-only">Algorithm</span><select className="select" value={algo} onChange={e => setAlgo(e.target.value)}>
                <option value="">All</option>{['nearest', 'hungarian', 'ppo', 'smartroute'].map(a => <option key={a} value={a}>{ALGO_LABEL[a]}</option>)}</select></label>
            </div>}>
            {error ? <ErrorState error={error} /> : loading ? <Loading label="Loading decisions…" /> : rows.length === 0 ?
              <Empty title="No decisions yet" hint="Run an assignment or start the simulation with auto-assign." /> : (
              <div className="list" style={{ maxHeight: 680 }}>
                {rows.map(a => (
                  <button key={a.id} className="list-item" aria-current={sel === a.id} onClick={() => setSel(a.id)}>
                    <div style={{ flex: 1 }}>
                      <div className="row"><strong className="mono">{a.order_id} → {a.partner_id}</strong></div>
                      <div className="faint" style={{ fontSize: 12 }}>{ALGO_LABEL[a.algorithm]} · {clock(a.sim_time)} · ETA {mins(a.eta_min)}{a.confidence != null && ` · ${a.algorithm === 'smartroute' ? 'prior' : 'conf'} ${pct(a.confidence)}`}</div>
                    </div>
                    <RiskBadge level={a.risk_level} />
                  </button>
                ))}
              </div>
            )}
          </Card>
          <Card title="Explanation">
            {sel == null ? <Empty title="Select a decision" /> : exp.error ? <ErrorState error={exp.error} /> : !exp.data ? <Loading label="Generating explanation…" /> : <Decision e={exp.data} />}
          </Card>
        </div>
      </div>
    </>
  )
}
