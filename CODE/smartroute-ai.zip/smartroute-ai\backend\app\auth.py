"""Authentication: one demo account, scrypt-hashed password, HMAC-signed bearer tokens.

Credentials come only from environment variables (SMARTROUTE_DEMO_USER, SMARTROUTE_DEMO_PASSWORD,
SMARTROUTE_SECRET_KEY). If no password is configured, a random one is generated at startup and
printed to the server log, so the API is never left open.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import logging
import secrets
import threading
import time
from collections import defaultdict, deque

from fastapi import HTTPException, Request

from .config import settings

log = logging.getLogger("smartroute")
TOKEN_TTL_S = 12 * 3600
MAX_FAILS, FAIL_WINDOW_S = 5, 300  # per client IP

_secret = (settings.secret_key or secrets.token_hex(32)).encode()
_password = settings.demo_password
if not _password:
    _password = secrets.token_urlsafe(12)
    log.warning("SMARTROUTE_DEMO_PASSWORD not set; generated one for this run: user=%s password=%s",
                settings.demo_user, _password)
    print(f"[SmartRoute AI] login  user={settings.demo_user}  password={_password}", flush=True)
_salt = secrets.token_bytes(16)
_hash = hashlib.scrypt(_password.encode(), salt=_salt, n=2**14, r=8, p=1)
del _password

_fails: dict[str, deque] = defaultdict(deque)
_fails_lock = threading.Lock()


def _b64(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode().rstrip("=")


def _sign(payload: str) -> str:
    return _b64(hmac.new(_secret, payload.encode(), hashlib.sha256).digest())


def check_password(user: str, password: str) -> bool:
    ok_user = hmac.compare_digest(user.encode(), settings.demo_user.encode())
    ok_pw = hmac.compare_digest(hashlib.scrypt(password.encode(), salt=_salt, n=2**14, r=8, p=1), _hash)
    return ok_user and ok_pw


def issue_token(user: str) -> str:
    payload = f"{user}|{int(time.time()) + TOKEN_TTL_S}"
    return f"{_b64(payload.encode())}.{_sign(payload)}"


def verify_token(token: str) -> str | None:
    try:
        p64, sig = token.split(".", 1)
        payload = base64.urlsafe_b64decode(p64 + "=" * (-len(p64) % 4)).decode()
        if not hmac.compare_digest(sig, _sign(payload)):
            return None
        user, exp = payload.rsplit("|", 1)
        return user if int(exp) > time.time() else None
    except (ValueError, UnicodeDecodeError):
        return None


def rate_limited(ip: str) -> bool:
    now = time.time()
    with _fails_lock:
        q = _fails[ip]
        while q and now - q[0] > FAIL_WINDOW_S:
            q.popleft()
        return len(q) >= MAX_FAILS


def record_failure(ip: str) -> None:
    with _fails_lock:
        _fails[ip].append(time.time())


def require_user(request: Request) -> str:
    header = request.headers.get("authorization", "")
    user = verify_token(header[7:]) if header.lower().startswith("bearer ") else None
    if not user:
        raise HTTPException(401, detail={"message": "Please sign in.", "reason": "Your session is missing or has expired.",
                                         "action": "Sign in again to continue."})
    return user
