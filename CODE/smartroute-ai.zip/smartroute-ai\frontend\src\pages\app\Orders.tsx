import { Plus, Search } from 'lucide-react'
import { useMemo, useState } from 'react'
import { api, type Order, type RiskLevel } from '../../api'
import { PageHeader } from '../../components/Layout'
import { OrderDetail } from '../../components/OpsView'
import { Card, DataTable, Empty, ErrorBanner, ErrorState, Loading, PriorityBadge, RiskBadge, StatusBadge, SyntheticNotice, type Column } from '../../components/ui'
import { clock, km, mins, title } from '../../format'
import { useAction, useApi, useSim } from '../../hooks'

const STATUSES = ['pending', 'assigned', 'in_transit', 'delivered', 'delayed', 'at_risk']
const PRIOS = ['low', 'normal', 'high', 'urgent']
const RISKS: RiskLevel[] = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL']

export default function Orders() {
  const { sim, refresh } = useSim()
  const now = sim?.sim_time ?? 0
  const { data, error, loading } = useApi<{ orders: Order[] }>('/orders')
  const act = useAction()
  const [q, setQ] = useState('')
  const [status, setStatus] = useState('')
  const [prio, setPrio] = useState('')
  const [risk, setRisk] = useState('')
  const [sel, setSel] = useState<string | null>(null)
  const [count, setCount] = useState(5)

  const rows = useMemo(() => (data?.orders ?? []).filter(o =>
    (!status || o.status === status) && (!prio || o.priority === prio) && (!risk || o.risk_level === risk) &&
    (!q || [o.id, o.partner_id ?? '', o.pickup.name, o.drop.name].some(s => s.toLowerCase().includes(q.toLowerCase())))), [data, q, status, prio, risk])

  const cols: Column<Order>[] = [
    { key: 'id', label: 'Order ID', render: o => <span className="mono">{o.id}</span>, sort: o => o.id },
    { key: 'priority', label: 'Priority', render: o => <PriorityBadge p={o.priority} />, sort: o => PRIOS.indexOf(o.priority) },
    { key: 'pickup', label: 'Pickup', render: o => o.pickup.name, sort: o => o.pickup.name },
    { key: 'drop', label: 'Destination', render: o => o.drop.name },
    { key: 'deadline', label: 'Deadline', render: o => clock(o.deadline), sort: o => o.deadline },
    { key: 'km', label: 'Distance', render: o => km(o.planned_km), sort: o => o.planned_km ?? 1e9, num: true },
    { key: 'eta', label: 'ETA', render: o => (o.eta_min != null ? mins(o.eta_min) : '—'), sort: o => o.eta_min ?? 1e9, num: true },
    { key: 'risk', label: 'Risk', render: o => <RiskBadge level={o.risk_level} score={o.risk} />, sort: o => o.risk },
    { key: 'partner', label: 'Partner', render: o => <span className="mono">{o.partner_id ?? '—'}</span>, sort: o => o.partner_id ?? '' },
    { key: 'status', label: 'Status', render: o => <StatusBadge status={o.status} />, sort: o => STATUSES.indexOf(o.status) },
  ]
  const generate = () => act.run('Generating orders…', async () => { await api.post('/orders/generate', { count }); refresh() })
  const selected = data?.orders.find(o => o.id === sel)
  const counts = useMemo(() => Object.fromEntries(STATUSES.map(s => [s, (data?.orders ?? []).filter(o => o.status === s).length])), [data])

  return (
    <>
      <PageHeader title="Orders" crumb="Operate" actions={
        <div className="row">
          <label className="sr-only" htmlFor="gen-count">Number of orders</label>
          <select id="gen-count" className="select" value={count} onChange={e => setCount(Number(e.target.value))}>{[1, 5, 10, 20].map(n => <option key={n}>{n}</option>)}</select>
          <button className="btn primary" onClick={generate} disabled={!!act.busy}><Plus size={14} />{act.busy ?? 'Generate orders'}</button>
        </div>} />
      <div className="content">
        <SyntheticNotice />
        {act.error && <ErrorBanner error={act.error} onClose={act.clearError} />}
        <div className="row" role="group" aria-label="Quick status filters">
          <button className={`btn sm ${status === '' ? 'dark' : ''}`} onClick={() => setStatus('')}>All {data?.orders.length ?? ''}</button>
          {STATUSES.map(s => <button key={s} className={`btn sm ${status === s ? 'dark' : ''}`} aria-pressed={status === s} onClick={() => setStatus(status === s ? '' : s)}>{title(s)} {counts[s]}</button>)}
        </div>
        <div className={selected ? 'grid with-side' : ''}>
          <Card title="Order management" right={
            <div className="row">
              <label className="row"><Search size={14} className="faint" /><span className="sr-only">Search</span>
                <input className="input" placeholder="Search ID, partner, place" value={q} onChange={e => setQ(e.target.value)} /></label>
              <label><span className="sr-only">Priority filter</span><select className="select" value={prio} onChange={e => setPrio(e.target.value)}><option value="">All priorities</option>{PRIOS.map(p => <option key={p} value={p}>{title(p)}</option>)}</select></label>
              <label><span className="sr-only">Risk filter</span><select className="select" value={risk} onChange={e => setRisk(e.target.value)}><option value="">All risk levels</option>{RISKS.map(r => <option key={r}>{r}</option>)}</select></label>
            </div>} flush>
            {error ? <ErrorState error={error} /> : loading ? <Loading label="Loading orders…" /> : rows.length === 0 ? <Empty title="No matching orders" hint="Adjust filters or generate new orders." /> : (
              <DataTable caption="Orders" rows={rows} columns={cols} rowKey={o => o.id} selected={sel} onRow={o => setSel(o.id)} initialSort={{ key: 'deadline', dir: 1 }}
                mobile={o => (<>
                  <div className="row between"><strong className="mono">{o.id}</strong><StatusBadge status={o.status} /></div>
                  <div className="row"><PriorityBadge p={o.priority} /><RiskBadge level={o.risk_level} score={o.risk} /></div>
                  <div className="faint" style={{ fontSize: 12 }}>{o.pickup.name} → {o.drop.name} · due {clock(o.deadline)} · {o.partner_id ?? 'unassigned'}</div>
                </>)} />
            )}
          </Card>
          {selected && (
            <Card title="Order details" right={<button className="btn sm ghost" onClick={() => setSel(null)} aria-label="Close details">✕</button>}>
              <OrderDetail o={selected} now={now} />
            </Card>
          )}
        </div>
      </div>
    </>
  )
}
