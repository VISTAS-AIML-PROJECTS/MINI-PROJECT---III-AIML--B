import { Pause, Play, RotateCcw, SkipForward } from 'lucide-react'
import { useRef, useState } from 'react'
import { ALGO_LABEL, api, type AlgorithmId, type SimConfig } from '../../api'
import { PageHeader } from '../../components/Layout'
import OpsView from '../../components/OpsView'
import { Card, ErrorBanner, Kpi, Loading, StatusBadge, SyntheticNotice } from '../../components/ui'
import { clock, mins, num, pct } from '../../format'
import { useAction, useSim } from '../../hooks'

export default function Simulation() {
  const { sim, refresh } = useSim()
  const act = useAction()
  const [local, setCfg] = useState<SimConfig | null>(null)
  const cfg = local ?? sim?.config ?? null
  const pending = useRef<{ patch: Partial<SimConfig>; timer?: ReturnType<typeof setTimeout> }>({ patch: {} })
  if (!sim || !cfg) return <><PageHeader title="Simulation" crumb="Monitor" /><div className="content"><Loading label="Loading simulation…" /></div></>

  const call = (label: string, path: string, body?: unknown) => act.run(label, async () => { await api.post(path, body ?? {}); refresh() })
  // Debounced: slider drags send one request after the user stops moving.
  const live = (patch: Partial<SimConfig>) => {
    setCfg({ ...cfg, ...patch })
    const p = pending.current
    p.patch = { ...p.patch, ...patch }
    clearTimeout(p.timer)
    p.timer = setTimeout(() => {
      const body = p.patch
      p.patch = {}
      act.run('Updating simulation…', async () => { await api.put('/simulation/config', body); refresh() })
    }, 300)
  }
  const k = sim.kpis
  return (
    <>
      <PageHeader title="Live Simulation" crumb="Monitor" />
      <div className="content">
        <SyntheticNotice>The backend advances the world once per second while running; the map shows the backend state, not a client-side animation.</SyntheticNotice>
        {act.error && <ErrorBanner error={act.error} onClose={act.clearError} />}
        <Card title="Controls" right={<><StatusBadge status={sim.status} /><span className="mono">Sim clock {clock(sim.sim_time)} · run #{sim.run_id}</span></>}>
          <div className="row" style={{ marginBottom: 14 }}>
            {sim.status === 'idle' && <button className="btn primary" onClick={() => call('Starting…', '/simulation/start')} disabled={!!act.busy}><Play size={14} />Start</button>}
            {sim.status === 'running' && <button className="btn" onClick={() => call('Pausing…', '/simulation/pause')} disabled={!!act.busy}><Pause size={14} />Pause</button>}
            {sim.status === 'paused' && <button className="btn primary" onClick={() => call('Resuming…', '/simulation/resume')} disabled={!!act.busy}><Play size={14} />Resume</button>}
            <button className="btn" onClick={() => call('Running simulation…', '/simulation/step', { minutes: 5 })} disabled={!!act.busy || sim.status === 'running'}><SkipForward size={14} />Step 5 min</button>
            <button className="btn" onClick={() => call('Resetting…', '/simulation/reset', { n_partners: cfg.n_partners, initial_orders: cfg.initial_orders, seed: cfg.seed })} disabled={!!act.busy}><RotateCcw size={14} />Reset</button>
            {act.busy && <span className="muted" role="status">{act.busy}</span>}
          </div>
          <div className="grid g4">
            <label className="field">Simulation speed ({cfg.minutes_per_tick} sim-min / second)
              <input type="range" min={0.5} max={5} step={0.5} value={cfg.minutes_per_tick} onChange={e => live({ minutes_per_tick: Number(e.target.value) })} /></label>
            <label className="field">Traffic level ({pct(cfg.traffic_level)})
              <input type="range" min={0} max={1} step={0.05} value={cfg.traffic_level} onChange={e => live({ traffic_level: Number(e.target.value) })} /></label>
            <label className="field">Order load ({cfg.order_rate_per_hour} orders / hour)
              <input type="range" min={0} max={120} step={5} value={cfg.order_rate_per_hour} onChange={e => live({ order_rate_per_hour: Number(e.target.value) })} /></label>
            <label className="field">Batch interval ({cfg.batch_every_min} min)
              <input type="range" min={1} max={10} step={1} value={cfg.batch_every_min} onChange={e => live({ batch_every_min: Number(e.target.value) })} /></label>
            <label className="field">Auto-assign algorithm
              <select className="select" value={cfg.algorithm} onChange={e => live({ algorithm: e.target.value as AlgorithmId })}>
                {(['nearest', 'hungarian', 'ppo', 'smartroute'] as AlgorithmId[]).map(a => <option key={a} value={a}>{ALGO_LABEL[a]}</option>)}</select></label>
            <label className="field">Auto-assign
              <select className="select" value={cfg.auto_assign ? 'on' : 'off'} onChange={e => live({ auto_assign: e.target.value === 'on' })}><option value="on">On</option><option value="off">Off (manual dispatch)</option></select></label>
            <label className="field">Partners on reset
              <input className="input" type="number" min={1} max={40} value={cfg.n_partners} onChange={e => setCfg({ ...cfg, n_partners: Math.max(1, Math.min(40, Number(e.target.value))) })} /></label>
            <label className="field">Random seed on reset
              <input className="input" type="number" min={0} value={cfg.seed} onChange={e => setCfg({ ...cfg, seed: Math.max(0, Number(e.target.value)) })} /></label>
          </div>
          <p className="faint" style={{ fontSize: 12, marginTop: 8 }}>Risk level is driven by traffic and order load. Partner count and seed apply on Reset.</p>
        </Card>
        <div className="kpis">
          <Kpi label="Active orders" value={k.active_orders} sub={`${k.pending_orders} pending`} />
          <Kpi label="Delivered" value={k.delivered_orders} />
          <Kpi label="On-time rate" value={pct(k.on_time_rate)} sub="Simulation result" />
          <Kpi label="Avg ETA" value={mins(k.avg_eta_min)} />
          <Kpi label="Avg risk" value={num(k.avg_risk, 2)} />
          <Kpi label="Mean congestion" value={pct(k.traffic_mean)} />
        </div>
        <OpsView now={sim.sim_time} height={480} />
      </div>
    </>
  )
}
