import { AlertCircle, CheckCircle2, Info } from 'lucide-react'
import { ALGO_LABEL, type Explanation } from '../api'
import { km, mins, pct, title } from '../format'
import { RiskBadge } from './ui'

const ICON = { positive: CheckCircle2, tradeoff: AlertCircle, info: Info }

/** "AI DECISION" + "WHY THIS PARTNER?" built entirely from the backend explanation payload. */
export default function Decision({ e, compact = false }: { e: Explanation; compact?: boolean }) {
  const d = e.decision
  const learned = e.algorithm === 'ppo' || e.algorithm === 'smartroute'
  return (
    <article className="decision" aria-label={`Decision for ${e.order_id}`}>
      <div className="decision-h">
        <span className="tag">{learned ? 'AI DECISION' : 'ALGORITHM DECISION'}</span>
        <strong>{e.order_id} → {e.partner_id}</strong>
        <span className="badge" style={{ marginLeft: 'auto', background: '#1d2a45', color: '#c9d3e6', borderColor: '#2b3b5c' }}>{ALGO_LABEL[e.algorithm] ?? e.algorithm}</span>
      </div>
      <div className="card-b stack">
        <dl className="kv">
          <dt>Order</dt><dd className="mono">{e.order_id}</dd>
          <dt>Partner</dt><dd className="mono">{e.partner_id}</dd>
          {e.confidence != null && <><dt title={e.confidence_basis ?? ''}>{e.algorithm === 'smartroute' ? 'Learned prior (PPO probability)' : 'Confidence (policy probability)'}</dt><dd>{pct(e.confidence)}</dd></>}
          <dt>Estimated travel time</dt><dd>{mins(d.eta_min)}</dd>
          <dt>Added distance</dt><dd>{km(d.km)}</dd>
          <dt>Risk</dt><dd><RiskBadge level={d.risk.level} score={d.risk.score} /></dd>
          <dt>Workload after</dt><dd>{d.load_after}/{d.capacity}</dd>
          <dt>Deadline feasible</dt><dd style={{ color: d.feasible ? 'var(--low)' : 'var(--crit)' }}>{d.feasible ? 'YES' : 'NO'} <span className="muted">({mins(d.slack_min)} left)</span></dd>
          <dt>Delay probability</dt><dd>{pct(d.delay_prob)}</dd>
          {!compact && <><dt>Tail lateness CVaR<sub>0.1</sub></dt><dd>{mins(d.cvar_late_min)}</dd></>}
        </dl>
        {e.algorithm === 'smartroute' && e.confidence_basis && <p className="faint" style={{ fontSize: 11.5 }}>{e.confidence_basis}.</p>}
        <div>
          <h3 style={{ fontSize: 13, margin: '6px 0 4px' }}>WHY THIS PARTNER?</h3>
          {e.reasons.map((r, i) => {
            const I = ICON[r.kind]
            return <div key={i} className={`reason ${r.kind}`}><I size={15} aria-label={r.kind} /><span>{r.text}</span></div>
          })}
        </div>
        {!compact && e.cost_breakdown && <CostTable cb={e.cost_breakdown} />}
        {!compact && e.policy_attribution && <Attribution a={e.policy_attribution} />}
        {!compact && e.alternatives.length > 1 && (
          <details>
            <summary style={{ cursor: 'pointer', fontWeight: 600, fontSize: 13 }}>All {e.alternatives.length} eligible partners considered</summary>
            <div className="table-wrap" style={{ marginTop: 8 }}>
              <table className="t">
                <thead><tr><th>Partner</th><th className="num">ETA</th><th className="num">km</th><th className="num">Delay p</th><th>Risk</th><th className="num">Load</th><th>Feasible</th></tr></thead>
                <tbody>
                  {e.alternatives.map(a => (
                    <tr key={a.partner_id} className={a.partner_id === e.partner_id ? 'sel' : ''}>
                      <td className="mono">{a.partner_id}</td><td className="num">{a.eta_min.toFixed(1)}</td><td className="num">{a.km.toFixed(1)}</td>
                      <td className="num">{pct(a.delay_prob)}</td><td><RiskBadge level={a.risk.level} score={a.risk.score} /></td>
                      <td className="num">{a.load_after}/{a.capacity}</td><td>{a.feasible ? 'Yes' : 'No'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </details>
        )}
      </div>
    </article>
  )
}

function CostTable({ cb }: { cb: NonNullable<Explanation['cost_breakdown']> }) {
  const keys = Object.keys(cb.chosen.components)
  return (
    <div>
      <h3 style={{ fontSize: 13, margin: '6px 0 2px' }}>Cost breakdown (exact)</h3>
      <p className="faint" style={{ fontSize: 11.5, marginBottom: 6 }}>{cb.basis} Lower is better.</p>
      <div className="table-wrap">
        <table className="t">
          <thead><tr><th>Component</th><th className="num">{cb.chosen.partner_id} (chosen)</th>{cb.runner_up && <th className="num">{cb.runner_up.partner_id} (runner-up)</th>}</tr></thead>
          <tbody>
            {keys.map(k => {
              const a = cb.chosen.components[k], b = cb.runner_up?.components[k]
              return (
                <tr key={k}><td>{title(k)}</td><td className="num" style={{ fontWeight: b != null && a < b ? 700 : 400 }}>{a.toFixed(2)}</td>
                  {cb.runner_up && <td className="num">{b?.toFixed(2)}</td>}</tr>
              )
            })}
            <tr><td><strong>Total</strong></td><td className="num"><strong>{cb.chosen.total.toFixed(2)}</strong></td>{cb.runner_up && <td className="num">{cb.runner_up.total.toFixed(2)}</td>}</tr>
          </tbody>
        </table>
      </div>
      {cb.runner_up && cb.runner_up.total < cb.chosen.total && (
        <p className="faint" style={{ fontSize: 11.5, marginTop: 4 }}>
          The runner-up is cheaper in isolation; the matching chose {cb.chosen.partner_id} because it lowers the total cost of the whole batch.
        </p>
      )}
    </div>
  )
}

function Attribution({ a }: { a: NonNullable<Explanation['policy_attribution']> }) {
  const top = a.features.slice(0, 8)
  const max = Math.max(1e-6, ...top.map(f => Math.abs(f.impact)))
  return (
    <div>
      <h3 style={{ fontSize: 13, margin: '6px 0 2px' }}>{a.method}</h3>
      <p className="faint" style={{ fontSize: 11.5, marginBottom: 6 }}>{a.note}</p>
      {top.map(f => {
        const w = (Math.abs(f.impact) / max) * 50
        return (
          <div className="attr-row" key={f.feature}>
            <span>{f.label}</span>
            <div className="attr-track" role="img" aria-label={`${f.label} impact ${f.impact.toFixed(3)}`}>
              <span style={f.impact >= 0 ? { left: '50%', width: `${w}%`, background: 'var(--teal)' } : { right: '50%', width: `${w}%`, background: 'var(--amber)' }} />
            </div>
            <span className="mono" style={{ textAlign: 'right' }}>{f.impact >= 0 ? '+' : ''}{f.impact.toFixed(2)}</span>
          </div>
        )
      })}
    </div>
  )
}
