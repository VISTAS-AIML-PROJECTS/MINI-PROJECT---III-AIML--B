"""Exact rectangular linear sum assignment (Hungarian method with potentials, O(n^2 m)).

Drop-in for scipy.optimize.linear_sum_assignment on minimisation problems; avoids the SciPy
dependency (its DLLs are blocked on the dev machine and it bloats serverless bundles).
"""
from __future__ import annotations

import numpy as np


def linear_sum_assignment(cost) -> tuple[np.ndarray, np.ndarray]:
    c = np.asarray(cost, dtype=float)
    if c.size == 0:
        return np.array([], dtype=int), np.array([], dtype=int)
    transposed = c.shape[0] > c.shape[1]
    if transposed:
        c = c.T
    n, m = c.shape  # n <= m: every row gets a column
    u, v = np.zeros(n + 1), np.zeros(m + 1)
    p = np.zeros(m + 1, dtype=int)  # p[j] = row (1-based) matched to column j; 0 = free
    way = np.zeros(m + 1, dtype=int)
    for i in range(1, n + 1):
        p[0] = i
        j0 = 0
        minv = np.full(m + 1, np.inf)
        used = np.zeros(m + 1, dtype=bool)
        while True:
            used[j0] = True
            i0 = p[j0]
            free = ~used[1:]
            cur = c[i0 - 1] - u[i0] - v[1:]
            better = free & (cur < minv[1:])
            minv[1:][better] = cur[better]
            way[1:][better] = j0
            cand = np.where(free, minv[1:], np.inf)
            j1 = int(np.argmin(cand)) + 1
            delta = cand[j1 - 1]
            u[p[used]] += delta
            v[used] -= delta
            minv[1:][free] -= delta
            j0 = j1
            if p[j0] == 0:
                break
        while j0:  # augment along the alternating path
            j1 = way[j0]
            p[j0] = p[j1]
            j0 = j1
    rows = np.array([p[j] - 1 for j in range(1, m + 1) if p[j]], dtype=int)
    cols = np.array([j - 1 for j in range(1, m + 1) if p[j]], dtype=int)
    if transposed:
        rows, cols = cols, rows
    order = np.argsort(rows)
    return rows[order], cols[order]
