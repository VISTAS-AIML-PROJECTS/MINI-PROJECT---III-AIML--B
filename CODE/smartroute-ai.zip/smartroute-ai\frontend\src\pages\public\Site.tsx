import {
  ArrowRight, BarChart3, BrainCircuit, CheckCircle2, Clock, GitCompare, Layers, Map, Menu, Network, Route, Scale,
  ShieldAlert, Sparkles, TrafficCone, X, type LucideIcon,
} from 'lucide-react'
import { useEffect, useState, type ReactNode } from 'react'
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom'
import HeroNetwork from './HeroNetwork'

const LINKS = [
  ['/product', 'Product'], ['/how-it-works', 'How It Works'], ['/technology', 'Technology'],
  ['/ai', 'AI Intelligence'], ['/about', 'About'],
] as const

export function SiteLayout() {
  const [open, setOpen] = useState(false)
  const { pathname } = useLocation()
  useEffect(() => { setOpen(false); window.scrollTo(0, 0) }, [pathname])
  useEffect(() => {
    const t = LINKS.find(([to]) => to === pathname)?.[1]
    document.title = t ? `${t} · SmartRoute AI` : 'SmartRoute AI — AI-Powered Dynamic Last-Mile Delivery Intelligence'
  }, [pathname])
  return (
    <div className="site">
      <a href="#main" className="skip-link">Skip to content</a>
      <header className="site-nav">
        <div className="inner" style={{ position: 'relative' }}>
          <Link to="/" className="brand" style={{ padding: 0 }} aria-label="SmartRoute AI home">
            <svg width="28" height="28" viewBox="0 0 32 32" aria-hidden="true"><rect width="32" height="32" rx="8" fill="#16243f" /><path d="M8 23c4-10 12-4 16-14" stroke="#2dd4bf" strokeWidth="3" fill="none" strokeLinecap="round" /><circle cx="8" cy="23" r="3" fill="#f59e0b" /><circle cx="24" cy="9" r="3" fill="#2dd4bf" /></svg>
            <strong style={{ letterSpacing: '.05em' }}>SMARTROUTE AI</strong>
          </Link>
          <nav className={open ? 'open' : ''} aria-label="Website">
            {LINKS.map(([to, label]) => <NavLink key={to} to={to}>{label}</NavLink>)}
            <NavLink to="/app/demo">Live Demo</NavLink>
          </nav>
          <Link to="/app" className="btn primary sm cta" style={{ marginLeft: 'auto' }}>Open Dashboard</Link>
          <button className="menu-btn" aria-label="Menu" aria-expanded={open} onClick={() => setOpen(o => !o)}>{open ? <X size={18} /> : <Menu size={18} />}</button>
        </div>
      </header>
      <main id="main"><Outlet /></main>
      <footer className="footer">
        <div className="inner">
          <span>© {new Date().getFullYear()} SmartRoute AI · Research prototype. All operational data shown is synthetic.</span>
          <span>Map data © OpenStreetMap contributors</span>
        </div>
      </footer>
    </div>
  )
}

const Section = ({ eyebrow, title, lead, children, band, id, h1 }: { eyebrow: string; title: string; lead?: ReactNode; children?: ReactNode; band?: boolean; id?: string; h1?: boolean }) => (
  <div className={band ? 'band' : ''} id={id}>
    <section className="section">
      <span className="eyebrow">{eyebrow}</span>
      {h1 ? <h1 className="title" style={{ fontSize: 'clamp(28px, 4vw, 40px)', margin: '8px 0 10px' }}>{title}</h1> : <h2 className="title">{title}</h2>}
      {lead && <p className="lead">{lead}</p>}
      {children && <div style={{ marginTop: 28 }}>{children}</div>}
    </section>
  </div>
)

const Feature = ({ icon, title, children }: { icon: ReactNode; title: string; children: ReactNode }) => (
  <div className="card feature"><div className="icon-box">{icon}</div><h3>{title}</h3><p>{children}</p></div>
)

function Hero() {
  return (
    <div className="hero">
      <div className="inner">
        <div>
          <span className="eyebrow"><Sparkles size={14} />Last-mile decision intelligence</span>
          <h1>SMARTROUTE AI</h1>
          <h2>AI-Powered Dynamic Last-Mile Delivery Intelligence</h2>
          <ul>
            {['Optimize assignments.', 'Reduce delivery risk.', 'Balance workloads.', 'Make every delivery decision explainable.'].map(t =>
              <li key={t}><CheckCircle2 size={17} color="#2dd4bf" />{t}</li>)}
          </ul>
          <div className="row">
            <Link to="/app/demo" className="btn primary lg">Launch Live Demo<ArrowRight size={16} /></Link>
            <Link to="/app" className="btn lg" style={{ background: 'transparent', color: '#fff', borderColor: '#3b4c70' }}>Explore Dashboard</Link>
          </div>
        </div>
        <div className="hero-viz"><HeroNetwork /></div>
      </div>
    </div>
  )
}

export function Problem() {
  return (
    <Section eyebrow="The problem" title="Static dispatch rules break under real-world dynamics"
      lead="Traditional assignment often sends an order to whoever is closest or next in line. That ignores what actually determines whether a delivery lands on time.">
      <div className="vs">
        <div className="card col">
          <strong>Conventional dispatch</strong>
          <ol>
            <li>Order arrives</li><li>Nearest or round-robin partner</li><li>Route is planned once</li><li>Delays discovered after they happen</li>
          </ol>
          <div className="row" style={{ marginTop: 12, gap: 6 }}>
            {['Changing traffic', 'Simultaneous orders', 'Deadlines', 'Uneven workload', 'Inefficient routes', 'Operational risk'].map(t => <span key={t} className="badge b-crit">{t}</span>)}
          </div>
        </div>
        <div className="card col" style={{ borderColor: 'var(--teal)' }}>
          <strong>SmartRoute AI</strong>
          <ol>
            <li>Orders batched with traffic, ETA and deadline</li><li>Risk scored per order–partner pair</li><li>Assignment optimised across the whole batch</li><li>Every decision explained, then monitored and re-evaluated</li>
          </ol>
          <div className="row" style={{ marginTop: 12, gap: 6 }}>
            {['Traffic-aware ETA', 'Delay probability', 'Capacity-aware', 'Workload balance', 'Explainable'].map(t => <span key={t} className="badge b-teal">{t}</span>)}
          </div>
        </div>
      </div>
    </Section>
  )
}

export function Solution() {
  const inputs = [[TrafficCone, 'Traffic'], [Route, 'Distance'], [Clock, 'ETA'], [Clock, 'Deadline'], [Scale, 'Workload'], [ShieldAlert, 'Risk']] as const
  return (
    <Section band eyebrow="The solution" title="Continuously evaluate every order–partner pair"
      lead="For every pending order and every eligible partner, SmartRoute AI computes the same feature set and turns it into an assignment and an explanation.">
      <div className="row" style={{ gap: 10, alignItems: 'stretch' }}>
        {inputs.map(([I, t], n) => (
          <span key={t} className="row" style={{ gap: 10 }}>
            <span className="card" style={{ padding: '10px 14px', display: 'flex', gap: 8, alignItems: 'center', fontWeight: 600 }}><span className="icon-box" style={{ width: 28, height: 28 }}><I size={18} /></span>{t}</span>
            {n < inputs.length - 1 && <strong className="faint">+</strong>}
          </span>
        ))}
        <strong style={{ fontSize: 22, alignSelf: 'center' }}>→</strong>
        <span className="card" style={{ padding: '10px 14px', background: 'var(--ink)', color: '#fff', fontWeight: 700 }}>AI Assignment + Explanation</span>
      </div>
    </Section>
  )
}

const PIPE: [string, string][] = [
  ['Orders', 'Pending orders are batched earliest-deadline first with pickup hub, drop-off, priority and deadline.'],
  ['Partner availability', 'Only online partners with free capacity are eligible; each keeps a route of queued stops.'],
  ['Traffic', 'A synthetic congestion grid evolves over time (AR(1) noise around hotspot corridors) and slows travel by up to 50%.'],
  ['ETA', 'Time to finish the partner’s queue + travel to pickup + delivery leg, using congestion sampled along each segment.'],
  ['Risk engine', 'Travel time is modelled as Normal(ETA, σ). Delay probability, CVaR₀.₁ tail lateness and a weighted composite risk are derived.'],
  ['AI state', '17 features per order–partner pair (ETA, gaps to best, distance, traffic, delay p, CVaR, load, capacity, slack, priority, demand context).'],
  ['DRL agent', 'A PPO actor-critic scores each eligible partner; the risk-aware policy acts as a learned prior inside the matching.'],
  ['Assignment', 'An exact Hungarian matching over capacity slots minimises total batch cost including risk terms.'],
  ['Explainability', 'Factual comparisons vs. every alternative, exact cost breakdown, and feature-ablation attribution on the policy.'],
  ['Monitoring', 'Live ETA and delay probability are recomputed every tick; risk events fire when thresholds are crossed.'],
]

export function HowItWorks({ h1 }: { h1?: boolean }) {
  const [i, setI] = useState(0)
  return (
    <Section h1={h1} eyebrow="How it works" title="From order to explained, monitored assignment"
      lead="Select a stage to see what the system actually computes at that point.">
      <div className="flow" role="list">
        {PIPE.map(([t], n) => (
          <button key={t} role="listitem" className="flow-step" aria-pressed={i === n} onClick={() => setI(n)}>
            <div className="n">{String(n + 1).padStart(2, '0')}</div><strong>{t}</strong>
          </button>
        ))}
      </div>
      <div className="card" style={{ marginTop: 14, padding: 18 }} aria-live="polite">
        <strong>{PIPE[i][0]}</strong><p className="muted" style={{ marginTop: 6 }}>{PIPE[i][1]}</p>
      </div>
    </Section>
  )
}

export function Technology({ h1 }: { h1?: boolean }) {
  const tech: [LucideIcon, string, string, boolean][] = [
    [BrainCircuit, 'Deep Reinforcement Learning', 'Dispatch MDP with variable partner sets and action masking.', true],
    [Layers, 'PPO', 'Clipped surrogate objective, GAE(λ), Adam — implemented in NumPy with gradient-checked backprop.', true],
    [ShieldAlert, 'Risk-aware reward', 'Adds composite risk, delay probability and CVaR tail-lateness penalties.', true],
    [GitCompare, 'Hungarian Algorithm', 'Exact min-cost matching via SciPy over capacity-expanded cost matrices.', true],
    [TrafficCone, 'Traffic simulation', 'Time-varying synthetic congestion field over the service area.', true],
    [Clock, 'ETA estimation', 'Queue-aware, congestion-aware travel time with a road-distance factor.', true],
    [ShieldAlert, 'CVaR', 'Closed-form CVaR₀.₁ of lateness under the Gaussian travel-time model (verified against Monte Carlo).', true],
    [Sparkles, 'Explainable AI', 'Surrogate feature explanation by ablation on the policy + exact cost breakdowns. Not SHAP.', true],
    [BarChart3, 'Analytics', 'Planned vs actual, partner KPIs, risk analytics and multi-scenario evaluation with 95% CIs.', true],
    [Network, 'Graph Attention Networks', 'Not implemented. The permutation-invariant per-pair policy is used instead.', false],
  ]
  return (
    <Section h1={h1} band eyebrow="Technology" title="What is implemented — and what is not"
      lead="Every capability marked Implemented runs in this build and is covered by automated tests.">
      <div className="grid g3">
        {tech.map(([I, t, d, ok]) => (
          <div key={t} className="card feature">
            <div className="row between"><div className="icon-box"><I size={18} /></div><span className={`badge ${ok ? 'b-low' : ''}`}>{ok ? 'Implemented' : 'Not implemented'}</span></div>
            <h3>{t}</h3><p>{d}</p>
          </div>
        ))}
      </div>
    </Section>
  )
}

export function AIIntelligence({ h1 }: { h1?: boolean }) {
  return (
    <Section h1={h1} eyebrow="AI intelligence" title="Decisions you can audit"
      lead="SmartRoute AI never shows a reason that the underlying numbers do not support. Each statement is generated from the stored features of the actual decision.">
      <div className="grid g2">
        <div className="card" style={{ overflow: 'hidden' }}>
          <div className="decision-h" style={{ background: 'var(--ink)', color: '#fff', padding: '12px 16px' }}><span className="tag" style={{ color: 'var(--teal-2)', fontSize: 11, letterSpacing: '.1em', fontWeight: 700 }}>EXAMPLE FORMAT</span></div>
          <div className="card-b stack">
            <p className="muted" style={{ fontSize: 13 }}>Explanations are produced for every assignment and include:</p>
            {['Factual comparisons against every eligible alternative (fastest, lowest risk, shortest distance…)', 'Trade-offs it accepted (e.g. “Not the fastest: P004 could deliver 2.1 min sooner”)', 'Deadline feasibility with delay probability', 'Exact additive cost breakdown vs the runner-up (matching algorithms)', 'Feature-ablation attribution on the PPO policy (learned algorithms)'].map(t =>
              <div key={t} className="reason positive"><CheckCircle2 size={15} /><span>{t}</span></div>)}
            <Link to="/app/demo" className="btn primary" style={{ alignSelf: 'flex-start' }}>See a real explanation<ArrowRight size={14} /></Link>
          </div>
        </div>
        <div className="grid" style={{ gap: 12 }}>
          <Feature icon={<Scale size={18} />} title="Honest comparisons">Algorithms are compared on identical synthetic scenarios with 95% confidence intervals. Differences are only called out when intervals do not overlap.</Feature>
          <Feature icon={<ShieldAlert size={18} />} title="Risk you can tune">Composite risk weights and SmartRoute’s risk sensitivity are adjustable; explanations update with the weights used.</Feature>
          <Feature icon={<Map size={18} />} title="Backend-driven simulation">Every moving marker on the map is the backend’s simulated state — no decorative animation in the operations views.</Feature>
        </div>
      </div>
    </Section>
  )
}

export function About({ h1 }: { h1?: boolean }) {
  return (
    <Section h1={h1} band eyebrow="About" title="About SmartRoute AI"
      lead="SmartRoute AI is a research prototype of an AI-assisted dispatcher for last-mile delivery. It demonstrates how reinforcement learning, exact optimisation and risk modelling can be combined into one explainable decision-support workflow.">
      <div className="grid g3">
        <Feature icon={<BarChart3 size={18} />} title="Synthetic by design">Orders, partners, locations and traffic are generated by a simulator around a fictional service area. No real customers, drivers or traffic feeds are used.</Feature>
        <Feature icon={<GitCompare size={18} />} title="Measured, not claimed">Performance figures are simulation results from the built-in evaluation. They are not real-world delivery statistics.</Feature>
        <Feature icon={<Layers size={18} />} title="Open architecture">FastAPI + SQLAlchemy + SQLite backend, NumPy/SciPy algorithms, React + Leaflet + Recharts frontend.</Feature>
      </div>
    </Section>
  )
}

export function Product({ h1 }: { h1?: boolean }) {
  const items: [LucideIcon, string, string][] = [
    [Map, 'Live operations map', 'Partners, orders, planned routes, actual paths, hubs and congestion in one view with linked lists and details.'],
    [Sparkles, 'AI assignment engine', 'Run Nearest, Hungarian, PPO and SmartRoute AI side by side on the same snapshot, then accept the plan you prefer.'],
    [BrainCircuit, 'Decision explanations', 'Why this partner, which trade-offs were made, and how each feature influenced the policy.'],
    [ShieldAlert, 'Risk center', 'Traffic, delay, distance, workload and deadline risk with affected orders, partners and recommended actions.'],
    [Clock, 'Dispatcher timeline', 'Each partner’s upcoming deliveries against their deadlines.'],
    [BarChart3, 'Analytics & reports', 'Planned vs actual, partner KPIs, algorithm evaluation, data-backed insights and exportable reports.'],
  ]
  return (
    <Section h1={h1} eyebrow="Product" title="One workspace for the whole dispatch loop"
      lead="See → Understand → Decide → Act → Measure. Built around the dispatcher, not the algorithm.">
      <div className="grid g3">{items.map(([I, t, d]) => <Feature key={t} icon={<I size={18} />} title={t}>{d}</Feature>)}</div>
    </Section>
  )
}

export default function Home() {
  return (
    <>
      <Hero />
      <Problem />
      <Solution />
      <HowItWorks />
      <Technology />
      <AIIntelligence />
      <div className="section" style={{ textAlign: 'center' }}>
        <h2 className="title">See it decide.</h2>
        <p className="lead" style={{ margin: '0 auto 20px' }}>Run the full pipeline — orders, traffic, risk, three algorithms, assignment and explanation — in under a minute.</p>
        <Link to="/app/demo" className="btn primary lg">Start Smart Demo<ArrowRight size={16} /></Link>
      </div>
    </>
  )
}
